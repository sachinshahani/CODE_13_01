<div class="alert alert-danger" style="display:none"></div>
<form action="{{route('superadmin.storeBatch')}}" method="post">
 @csrf

<input type="hidden" name="product_id" id="product_id" value="{{ $product_detail->id ?? ''}}" />
	<div class="row g-3">
		<div class="col-xxl-6">
			<div>
				<label for="actual_yield" class="form-label">Actual yield(in MT)</label>
				<input type="text" class="form-control" value="{{ $product_detail->actual_yield ?? ''}}" name="actual_yield" id="actual_yield" required>
			</div>
		</div><!--end col-->
		<div class="col-xxl-6">
			<div>
				<label for="harvest_date" class="form-label">Harvest date</label>
				<input type="date" class="form-control" value="{{ $product_detail->harvest_date ?? ''}}" name="harvest_date" id="harvest_date" required>
			</div>
		</div><!--end col-->

		 <div class="col-xxl-6">
			<div>
				<label for="sowing_date" class="form-label">Sowing date</label>
				<input type="date" class="form-control" value="{{ $product_detail->sowing_date ?? ''}}" name="sowing_date" id="sowing_date" required>
			</div>
		</div><!--end col-->


		<div class="col-lg-12">
			<div class="hstack gap-2 justify-content-end">
				<button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
				<button type="button" id="formSubmit" class="btn btn-primary">Update</button>
			</div>
		</div><!--end col-->
	</div><!--end row-->
</form>

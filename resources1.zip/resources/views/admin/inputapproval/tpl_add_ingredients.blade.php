<div class="alert alert-danger" style="display:none"></div>
<form action="{{route('superadmin.storeIngredients')}}" method="post">
 @csrf 
<input type="hidden" name="at_input_approval_unit_reg_detail_id" id="at_input_approval_unit_reg_detail_id" value="{{$result->getUnitsDetails->id}}" />
<input type="hidden" name="at_input_approval_reg_details_id" id="at_input_approval_reg_details_id" value="{{$result->getRegistrationDetails->id}}" />
<input type="hidden" name="at_input_product_category_id" id="at_input_product_category_id" value="{{$result->at_input_product_category_id}}" />
<input type="hidden" name="at_input_sub_product_category_id" id="at_input_sub_product_category_id" value="{{$result->at_input_sub_product_category_id}}" />
 
<input type="hidden" name="ingredient_id" id="ingredient_id" value="{{ $batch_detail->id ?? ''}}" />
<input type="hidden" name="product_id" id="product_id" value="{{ $result->id ?? ''}}" />
	<div class="row g-3">
		<div class="col-xxl-6">
			<div>
				<label for="ingredient_name" class="form-label">Ingredient name</label>
				<input type="text" class="form-control" value="{{ $batch_detail->ingredient_name ?? ''}}" name="ingredient_name" id="ingredient_name" required>
			</div>
		</div><!--end col-->
		<div class="col-xxl-6">
			<div>
				<label for="percentage" class="form-label">Percentage</label>
				<input type="text" maxlength="3" class="form-control numbersonly" value="{{ $batch_detail->percentage ?? ''}}" name="percentage" id="percentage" required>
			</div>
		</div><!--end col-->
		 
	 
		<div class="col-lg-12">
			<div class="hstack gap-2 justify-content-end">
				<button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
				<button type="button" id="formSubmit" class="btn btn-primary">Submit</button>
			</div>
		</div><!--end col-->
	</div><!--end row-->
</form>
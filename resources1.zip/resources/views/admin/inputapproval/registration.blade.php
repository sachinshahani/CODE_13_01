@extends('admin.layouts.app')
@section('content')

<style>
.overlay {
    background: rgb(0 0 0 / 50%);
    position: fixed;
    top: 0;
    z-index: 11111;
    left: 0;
    right: 0;
    bottom: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    display: none;
}

.loader {
    position: fixed !important;
    left: 50% !important;
    margin-left: -4em !important;
    top: 20em !important;
}

.wrapper {
    max-width: 1240px;
    margin: 0 auto;
}

.white-bg {
    background-color: white;
    /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
    border-bottom: 5px solid #ff9800;
    margin-bottom: 15px;
}

.auth-one-bg .slide .carousel-indicators {
    bottom: 25px;
}

.auth-page-wrapper .auth-page-content {
    padding-bottom: 0px !important;
}

.auth-page-content .card {
    margin-bottom: 0rem;
}

.data-tabs .wrapper .nav-tabs button {
    font-size: 17px;
    color: black;
}

.data-tabs .wrapper .nav-tabs .active {
    background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
    */ color: white;
    background: orange;
    border-radius: 0px;
}

.carousel-caption.d-none.d-md-block {
    background-color: #000000bf;
    left: 0;
    width: 100%;
    bottom: 0;
}

.carousel-indicators {
    display: none;
}

.custom-banner-caption {
    color: white !important;
}

.announcement-heading {
    font-size: 1.2em;
    font-weight: 600;
}

.data-tabs .tab-pane ul li {
    font-size: 1em;
    padding: 5px 0;

}

.main-logo {
    padding: 10px;
}

.data-tabs .nav-item .nav-link {
    background-image: none;
}

/* .right-sec{
        box-shadow: 5px 10px 18px #888888;
    } */
.navbar-brand-box {
    background: #fff;
}

[data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
    color: white !important;
}

.header-buttons .btn-primary {
    margin-right: 10px;
    padding: 6px 15px;
    font-weight: 600;
    background-color: #207005;
    border: none;
    box-shadow: 0px 2px 7px #888888;
}

.header-buttons .btn-secondary {
    margin-right: 10px;
    padding: 6px 15px;
    font-weight: 600;
    background-color: #72a055;
    border: none;
    box-shadow: 0px 2px 7px #888888;
}


.right-sec {
    border-left: 5px solid #ede7e7;
}

.tabdiv {
    background: white;
    padding: 20px;
    margin-top: 10px;
    border: 10px solid #dfdbd5;
}

.nav-tabs {
    border-bottom: 0px;
}

div#myTabContent {
    border: 1px solid #cccccc;
}

.frontfooter footer {
    padding: 20px calc(1.5rem / 2);
    position: static;
    color: #000;
    height: 60px;
    background-color: #f9f9f9;
    margin-top: 30px;
    border-top: 1px solid #e1dfdf;
}

span.logo-sm img {
    width: 69px;
}

.seperatesec {
    margin-top: 20px;
}

.simplebar-content li.nav-item:hover {
    background: #4caf50;
}

.sectitle {
    font-size: 14px;
}

.required {
    color: red;
}

.customtextarea {
    height: 120px;
}

ul.boxsection {
    margin: 0;
    padding: 0;
}

ul.boxsection li {
    list-style-type: none;
    padding: 7px 0;
    border-bottom: 1px solid #efeded;
}

.boxcard .col:nth-child(1) {
    background: #effcfb;
}

.boxcard .col:nth-child(2) {
    background: #fdfdfd;
}

.boxcard .col:nth-child(3) {
    background: #effcfb;
}

.boxcard .col:nth-child(4) {
    background: #fdfdfd;
}

.boxcard .col:nth-child(5) {
    background: #effcfb;
}

/* --registration-form css  */
.custom-tab-content {
    padding-top: 0 !important;
    padding-bottom: 0px !important;
}

.custom-tab-nav {
    background: white;

}

.custom-tab-nav .nav-link {
    border-radius: 0 !important;
    border-bottom: 1px solid #e9ebec;
    border-right: 1px solid #e9ebec;
    font-size: 14px;
    padding: 10px;
}

.custom-tab-nav .nav-link.active,
.custom-tab-nav .show>.nav-link {
    color: rgb(255, 255, 255) !important;
    background-color: #2c8c6d;
    border-bottom: #2c8c6d !important;
    /* border-bottom: #207005 !important; */
    position: relative;
}

.custom-tab-nav .nav-link:hover,
.custom-tab-nav .nav-link:focus {
    border-bottom: 1px solid #207005;
    border-radius: 0;
    font-size: 14px;
    transition: background-color 0.20s linear;
}

.custom-tab-nav .nav-link.active:after {
    content: "";
    position: absolute;
    bottom: -16px;
    left: 50%;
    border: 8px solid transparent;
    border-top-color: #2c8c6d;
    z-index: 999;
}

.reg-form-btns {
    margin-bottom: 15px;
}

.reg-form-btns .btn-secondary {
    color: #fff;
    background-color: #405189;
    border-color: #405189;
}

.btn-soft-success:active,
.btn-soft-success:focus,
.btn-soft-success:hover {
    border: none;
}

.custom-tab-nav ul {
    padding: 0px;
    margin: 0px;
}

.custom-tab-nav ul li {
    padding: 0px;
    margin: 0px;
    display: inline-block;
    list-style: none;
}

/* -------  */
.btn-email {
    font-size: 13px;
    padding: 1px 7px;
    line-height: 17px;

}

.btn-mailsend {
    font-size: 13px;
    padding: 1px 7px;
    line-height: 17px;
}

.btn-verify {
    font-size: 13px;
    padding: 1px 7px;
    line-height: 34px;
}

.inputEmail .input-group-append {
    display: flex;
    align-items: end;
}

.inputEmail .validateEmailId {
    border-radius: 4px 0 0 4px;
}

.input-group-append .verifiEmail_otp,
.input-group-append .resendEmail_otp {
    margin-left: 10px;
}

.login-pass.otp-email {
    margin-top: 5px
}

.login-pass.otp-email .inp-b {
    border-radius: 0 4px 4px 0
}
</style>

<div class="overlay">
    <div class="loader"></div>
</div>
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">New Registration-Input Approval</h4> 
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1">New Registration-Input Approval  </h4>
                <div class="flex-shrink-0">
                    @if (session('error'))
                    <div class="alert alert-danger">
                        {{ session('error') }}
                    </div>
                    @endif
                    @if (session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                    @endif
                    @if($errors)
                    @foreach ($errors->all() as $error)
                    <div class="alert alert-danger">{{ $error }}</div>
                    @endforeach
                    @endif
                </div>
            </div>

            <div class="card-body">
                <div class="live-preview">
                    <form action="{{ route('superadmin.storeNewRegistration') }}" class="commonform1"
                        method="POST" enctype="multipart/form-data" id="commonform1" autocomplete="off">
                        @csrf 
                        <div class="row seperatesec white-inner">

                            <div class="sectitle">
                                <label for="labelInput" class="form-label blue-ht">Registration Details</label>
                            </div>

                            <div class="col-xxl-3 col-md-3 gy-3">
                                <div>
                                    <label class="form-label"> Date of Registration : <span class="required">*</span></label>
                                    <input type="text" class="form-control" name="registration_date" id="registration_date" readonly value="{{date('d/m/Y')}}">

                                </div>
                            </div>
                             
                            
                            <div class="col-xxl-3 col-md-3 gy-3">
                                <div>
                                    <label class="form-label"> Name of Company  : <span class="required">*</span></label>
                                    <input type="text" class="form-control" name="company_name" id="company_name" required value="">

                                </div>
                            </div>
							 
							
							 <div class="sectitle gy-3">
                                <label for="labelInput" class="form-label blue-ht">Mailing Address</label>
                            </div>
							
							<div class="col-xxl-3 col-md-3">
                                <div>
                                    <label class="form-label"> Address  : <span class="required">*</span></label>
                                    <textarea class="form-control customtextarea valid" name="address" required="" aria-invalid="false"></textarea>
                                </div>
                            </div>

							<div class="col-xxl-7 col-md-9">
							<div class="row">
							<div class="col-xxl-3 col-md-4">
								<div>
									<label for="labelInput" class="form-label">State <span	class="required">*</span></label>										 
									 <select class="form-select state" name="ref_state_id"	id="state"  required>
										<option value="">-Select State-</option>
										@forelse(getAllState() as $state)
											<option value="{{ $state->id }}">{{ $state->state_name }}</option>
										@empty
										@endforelse
									</select>
								</div>
							</div>
							<div class="col-xxl-3 col-md-4">
								<div>
									<label for="labelInput" class="form-label">District <span
											class="required">*</span></label>											 
									<select class="form-select district" name="ref_district_id" id="district"  required>
										<option value="">Select District</option>
										
									</select>
								</div>
							</div>
							<div class="col-xxl-3 col-md-4">
								<div>
									<label for="labelInput" class="form-label">Taluka/Mandal
										<span class="required">*</span></label>
									 
									<select class="form-select block_tehsil" name="ref_block_tehsil_id" id="block_tehsil"  required>
										<option value="">Select Taluka/Mandal</option>
										
									</select>
								</div>
							</div>
							<div class="col-xxl-3 col-md-4 gy-0">
								<div>
									<label class="form-label">Village </label>
									<select class="form-select village" name="ref_block_tehsil_id" id="village"   required>
										<option value="">Select Village</option>
										 
									</select>
								</div>
							</div>
 
							<div class="col-xxl-3 col-md-4 gy-3">
								<div>
									<label for="labelInput" class="form-label">Pin Code<span
											class="required">*</span></label>
									<input type="text" class="form-control numbersonly"
										id="placeholderInput"  name="pincode"
										value=""  required 
										maxlength="6" />
								</div>
							</div>
							</div>
							</div>
						</div>
					<div class="row seperatesec white-inner">
							
							 <div class="sectitle">
                                <label for="labelInput" class="form-label blue-ht">Contact Person Details</label>
                            </div>
							<div class="col-xxl-3 col-md-3 gy-3">
								<div>
									<label class="form-label">Name of Contact Person<span class="required">*
										</span></label>
									<input type="text" class="form-control" name="producer_name"
										id="producer_name" required
										value="">
								</div>
							</div>
							<div class="col-xxl-3 col-md-3 gy-3">
								<div>
									<label class="form-label">Contact Number<span
											class="required">*
										</span></label>
									<input type="text" class="form-control numbersonly"
										value=""  required
										id="phone" name="phone"
										 maxlength="10" >
								</div>
							</div>
							<div class="col-xxl-3 col-md-3 gy-3">
								<div>
									<label class="form-label">PAN<span class="required">
										</span></label>
									<input type="text" class="form-control" name="pan_number"
										id="pan_number"
										value="">
								</div>
							</div>
							<div class="col-xxl-3 col-md-3 gy-3">
								<div>
									<label class="form-label">Fax<span class="required">
										</span></label>
									<input type="text" class="form-control numbersonly" name="fax"
										id="fax" maxlength="10"
										value="">
								</div>
							</div>
							<div class="col-xxl-3 col-md-3 gy-3">
								<div>
									<label class="form-label">Email<span class="required">
										</span></label>
									<input type="email" class="form-control" name="email_id"
										id="email_id"  required
										value="">
								</div>
							</div>
							
							<div class="col-xxl-3 col-md-3 gy-3">
								<div>
									<label class="form-label">Mobile<span class="required">
										</span></label>
									<input type="text" class="form-control numbersonly" name="mobile"
										id="mobile" required maxlength="10"
										value="">
								</div>
							</div>
							<div class="col-xxl-3 col-md-3 gy-3">
								<div>
									<label class="form-label">Validity Start from<span class="required">
										</span></label>
									<input type="date" class="form-control" name="validity_start_from"
										id="validity_start_from" required
										value="">
								</div>
							</div>
							<div class="col-xxl-3 col-md-3 gy-3">
								<div>
									<label class="form-label">Validity End To<span class="required">
										</span></label>
									<input type="date" class="form-control" name="validity_end"
										id="validity_end" required
										value="">
								</div>
							</div>
						
						</div>
						<!-- END seperatesec ROW -->
						
						 <div class="row seperatesec white-inner">

                            <div class="sectitle">
                                <label for="labelInput" class="form-label blue-ht">Enter Unit Registration Details</label>
								<i style="float: right;" data-type="wm" onclick="addNew();" class="mdi mdi-plus btn btn-soft-success add-more"
                                                        data-toggle="tooltip" title="Add Row"></i>
                            </div>

                            <div class="col-xxl-12 col-md-12 gy-3">
                                 <div class=" table-responsive">
									<table id="deptUser" class="table table-bordered table-striped align-middle" style="width:100%">
										<thead>
											<tr>
												<th>Unit Name</th>
												<th>License No.</th>
												<th>License Validity</th>
												<th>Additional Certification</th>
												<th>Installed Capacity(MT/Day)</th>
												<th>Estimated Production(In MT)</th>
												<th>Address</th>
												<th>City/Town</th>
												<th>State</th>
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
											<tr id="row_0">
												<td>
													<input style="width:200px;" type="text" class="form-control" name="unit_registration[0][unit_name]" id="unit_name" value=""  required>
												</td>
												<td>
													<input style="width:200px;" type="text" class="form-control" name="unit_registration[0][license_no]" id="license_no" value=""  required>
												</td>
												<td>
													<input style="width: 126px;" type="date" class="form-control" name="unit_registration[0][license_validity_upto]" id="license_validity_upto" value=""  required>
												</td>
												<td>
													<select style="width:120px;" class="form-control" multiple name="unit_registration[0][additional_certification][]" id="additional_certification" required>
														<option value="1">ISO 22000</option>
														<option value="2">ISO 9000</option>
														<option value="3">HACCP</option>
														<option value="4">Other</option>
													</select>
													
												</td>
												<td>
													<input type="text" class="form-control numbersonly" name="unit_registration[0][installed_capacity]" id="installed_capacity" value=""  required>
												</td>
												<td>
													<input type="text" class="form-control numbersonly" name="unit_registration[0][estimated_production_in_mt]" id="estimated_production_in_mt" value="" required>
												</td>
												<td>
													<textarea style="width:200px;" class="form-control" name="unit_registration[0][address]" id="unit_address"></textarea>
													
												</td>
												<td>
													<input style="width: 130px;" type="text" class="form-control" name="unit_registration[0][ref_district_id]" id="ref_district_id" value="" required>
												</td>
												<td>
													<select style="width: 130px;" class="form-select" name="unit_registration[0][ref_state_id]" id="ref_state_id"  required>
														<option value="">-Select-</option>
														@forelse(getAllState() as $state)
															<option value="{{ $state->id }}">{{ $state->state_name }}</option>
														@empty
														@endforelse
													</select>													
												</td>
												<td>
													<i data-type="wm" class="mdi mdi-minus btn btn-soft-danger "
                                                            data-toggle="tooltip" title="Remove Row"></i>
												</td>
												
											</tr>
										</tbody>
									</table>
								</div>
                            </div>
							
						</div>
						<!-- END seperatesec ROW -->
						<div class="row">
							<div class="col-lg-12 gy-4">
								<div class="hstack gap-2">
									<button type="submit" class="btn btn-primary">
										Submit Application
									</button>							   

								</div>
							</div>

						</div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@push('script')

<div id="addNew"  style="display:none">
<table>
<tr id="row_row_id">
	<td>
	<input style="width:200px;" type="text" class="form-control" name="unit_registration[row_id][unit_name]" id="unit_name" value=""  required>
</td>
<td>
	<input style="width:200px;" type="text" class="form-control" name="unit_registration[row_id][license_no]" id="license_no" value=""  required>
</td>
<td>
	<input style="width: 126px;" type="date" class="form-control" name="unit_registration[row_id][license_validity_upto]" id="license_validity_upto" value=""  required>
</td>
<td>
	<select style="width:120px;" class="form-control" multiple name="unit_registration[row_id][additional_certification][]" id="additional_certification" required>
		<option value="1">ISO 22000</option>
		<option value="2">ISO 9000</option>
		<option value="3">HACCP</option>
		<option value="4">Other</option>
	</select>
</td>
<td>
	<input type="text" class="form-control numbersonly" name="unit_registration[row_id][installed_capacity]" id="installed_capacity" value=""  required>
</td>
<td>
	<input type="text" class="form-control numbersonly" name="unit_registration[row_id][estimated_production_in_mt]" id="estimated_production_in_mt" value="" required>
</td>
<td>
	<textarea style="width:200px;" class="form-control" name="unit_registration[row_id][address]" id="unit_address"></textarea>
	
</td>
<td>
	<input style="width: 130px;" type="text" class="form-control" name="unit_registration[row_id][ref_district_id]" id="ref_district_id" value="" required>
</td>
<td>
	<select style="width: 130px;" class="form-select" name="unit_registration[row_id][ref_state_id]" id="ref_state_id"  required>
		<option value="">-Select-</option>
		@forelse(getAllState() as $state)
			<option value="{{ $state->id }}">{{ $state->state_name }}</option>
		@empty
		@endforelse
	</select>													
</td>
<td>
	<i data-type="wm" class="mdi mdi-minus btn btn-soft-danger "
			data-toggle="tooltip" title="Remove Row"></i>
</td>
</tr>
</table>
</div>

<script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
<script type="text/javascript">


// email verification 

$(".btn-email").click(function(e) {
    e.preventDefault();
    var user_email = $('#email_id1').val();


    if (user_email != "") {
        $(".overlay").show();
        $.ajax({
            type: 'POST',
            url: "{{ route('superadmin.usermanagement.email_mobile_OTP') }}",
            data: {
                'user_email': user_email
            },
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(resp) {
                if (resp == 1) {

                    Swal.fire({
                        text: "Please verify OTP send on Email id",
                        icon: 'success',
                        confirmButtonText: 'OK'
                    }).then((result) => {
                        $('.otp-email').show(500);
                        $('#email_id1').val(user_email);
                        $('#email_id1').prop('readonly', true);
                        $('.btn-email').hide(500);
                        $('.btn-mailsend').show(100);
                    });

                }
                $(".overlay").hide();
            }
        });
    } else {
        Swal.fire("", "Please enter Email ID", "error");
    }
});


$(".verifiEmail_otp").click(function(e) {
    e.preventDefault();
    var email_otp = $('#email_otp1').val();
    $(".overlay").show();
    if (email_otp != "") {

        $.ajax({
            type: 'POST',
            url: "{{ route('superadmin.usermanagement.email_mobile_OTP_check') }}",
            data: {
                'email_otp': email_otp
            },
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(html) {
                if (html == 0) {
                    Swal.fire("", "Please enter Valid OTP", "error");
                } else {
                    $('#email_otp').prop('readonly', true);
                    $('.otp-email1').hide(500);
                    $('.btn-email').hide(500);
                    $('.btn-verify').show(500);
                    $('.visitorCat').hide(500);
                    $('.visitorCat1').hide(500);
                    $('.user_detail_page').show(500);
                    $('#email_id').prop('readonly', true);
                    $('.btn-mailsend').hide();
                    $('.login-pass').hide();
                }
                $(".overlay").hide();
            }
        });
    } else {
        Swal.fire("", "Please enter OTP", "error");
    }
});

$(".resendEmail_otp").click(function(e) {
    e.preventDefault();
    var user_email = $('#email_id1').val();

    $.ajax({
        type: 'POST',
        url: "{{ route('superadmin.usermanagement.email_mobile_OTP') }}",
        data: {
            'user_email': user_email
        },
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        success: function(html) {
            Swal.fire("", "Re OTP Send!!", "success");
        }
    });
});

// end-----





$("#commonform1").validate({
    rules: {
        // user_password: { 
        // 	required: true,
        // 	minlength: 8,
        // 	maxlength: 10,
        // } ,
        mobile: {
            required: true,
        }
    },
    messages: {
        // user_password: { 
        // 	required:"This field is required and should be 8 digits, contains upper,lowerCase,and a special Character"   
        // },
        mobile: {
            required: "This field is required",
        }
    }

});

function CheckPassword(inputtxt) {
    if (inputtxt.value.length > 0) {
        var decimal = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
        if (inputtxt.value.match(decimal)) {
            return true;
        } else {
            Swal.fire('',
                'Password should be 8 digits,contains upperCase letter,lowerCase letter,and a special Character',
                'warning');
            $("#user_password").val('');
            return false;
        }
    }
}

function phonenumber(inputtxt) {
    var phoneno = /^\d{10}$/;
    if (inputtxt.value.match(phoneno)) {
        return true;
    } else {
        Swal.fire('', 'Please enter a valid mobile number.', 'warning');
        $("#mobile").val('');
        return false;
    }
}


function addNew()
{  
	var rowCount = $('#deptUser tbody tr').length; 
	var row = $('#addNew table > tbody ').html().replaceAll('row_id',rowCount);	
	$('#deptUser tbody').append(row);
}

</script>
 
@endpush
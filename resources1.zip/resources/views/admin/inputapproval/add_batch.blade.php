@extends('admin.layouts.app')
@section('content')
<div class="row">
	<div class="col-12">
		<div class="page-title-box d-sm-flex align-items-center justify-content-between">
			<h4 class="mb-sm-0">View Batch of the Product</h4>
			<div class="page-title-right">
				<ol class="breadcrumb m-0">
					<li class="breadcrumb-item"><a href="javascript: void(0);">Admin</a></li>
					<li class="breadcrumb-item active">View Batch of the Product</li>
				</ol>
			</div>
		</div>
	</div>
</div>
<div class="clearfix"></div>

<div class="col-md-12 mt-2">
	@if (session('success'))
	<div class="alert alert-success" id="validate">
		{{ session('success') }}
	</div>
	@endif
	@if (session('importErrors'))
	<div class="alert alert-danger">
		<p>Following Errors Occured While Uploading the list, Please fix and upload again</p>
		<ul>
			@foreach(session('importErrors') as $failure)

			@foreach($failure->errors() as $f)
			<li>{{ $f .' at row '.$failure->row() }}</li>
			@endforeach

			@endforeach
		</ul>
	</div>
	@endif
</div>

<div class="row">
	<div class="col-lg-12">
		<div class="card">
			 
			<div class="card-body">
			 <div class="sectitle">
				<label for="labelInput" class="form-label blue-ht">Unit Details</label>
			</div>
			<div class="table-responsive">
				<table class="table table-bordered table-striped align-middle dataTable no-footer" width="100%">
                    <thead>
						<tr>
							<th>Registration No.</th>
							<th>Unit Registration No.</th>
							<th>Unit Name</th>								 
						</tr>
                    </thead>
					<tbody>
						<tr>
							<td>{{$result->getRegistrationDetails->registration_no}}</td>
							<td>{{$result->getUnitsDetails->unit_reg_number}}</td>
							<td>{{$result->getUnitsDetails->unit_name}}</td>
						</tr>
					</tbody>
                </table>
			</div>
			
			<div class="sectitle pt-4">
				<label for="labelInput" class="form-label blue-ht">Product Details</label>
			</div>
			<input type="hidden" name="unit_id" id="unit_id" value="{{$result->getUnitsDetails->id}}" />
			<input type="hidden" name="reg_id" id="reg_id" value="{{$result->getRegistrationDetails->id}}" />
			<div class="table-responsive">
				<table class="table table-bordered table-striped align-middle dataTable no-footer" width="100%">
                    <thead>
						<tr>
							<th>Category Name</th>
							<th>Subcategory Name</th>
							<th>Brand Name</th>								 
							<th>Shelf Life</th>								 
							<th>Description</th>								 
						</tr>
                    </thead>
					<tbody>
						<tr>
							<td>{{get_product_cat_name($result->at_input_product_category_id)}}</td>
							<td>{{get_product_subcat_name($result->at_input_sub_product_category_id)}}</td>
							<td>{{$result->product_name}}</td>
							<td>{{$result->self_life}}</td>
							<td>{{$result->product_desc}}</td>
						</tr>
					</tbody>
                </table>
			</div>
			
			<div class="sectitle pt-4">
				<label for="labelInput" class="form-label blue-ht">Batch Details</label>
				<a href="javascript:void(0);" onclick="showAddBatch();" style="float: right;" class="bt" >Add new Batch</a>
				 
			</div>
			<div class="table-responsive">
				<table id="table_batch_list" class="table table-bordered table-striped align-middle dataTable no-footer" width="100%">
                    <thead>
						<tr>
							<th>Batch No.</th>
							<th>Batch tentative date</th>
							<th>Qty. to be Produced(In MT)</th>								 
							<th>Action</th>								 
						</tr>
                    </thead>
					<tbody>
						@forelse($batch_list as $value)
						<tr id="row_{{$value->id}}">
							<td>{{$value->batch_no}}</td>
							<td>{{date('d/m/Y',strtotime($value->batch_date))}}</td>
							<td>{{$value->batch_qty_mt}}</td>
							<td><a href="javascript:void(0);" class="deletedata" data-value="{{$value->id}}" data-href="{{route('superadmin.deleteBatch',$value->id)}}" >Delete</a> 
							| <a href="javascript:void(0)" onclick="showAddBatch('{{$value->id}}')">Edit</a></td>
						</tr>
						@empty
							 
						@endforelse
					</tbody>
                </table>
			</div>
			
			
			</div>
		</div>
	</div>
	<!--end col-->
</div>
<!--end row-->
@endsection

@push('script')

<!-- Grids in modals -->
 
<div class="modal fade" id="addBatchModalgrid" tabindex="-1" aria-labelledby="addBatchModalgridLabel" aria-modal="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addBatchModalgridLabel">Add Batch</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="batch_popup">
                
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">

//var table  =  $('#table_batch_list').DataTable();

function showAddBatch(batch_id='')
{
	var reg_id = $('#reg_id').val();
	var unit_id = $('#unit_id').val();
	$.ajax({
		  url: "{{ route('superadmin.addEditbatch') }}",
		  method: "POST",
		  cache: false,
		  data: {
			  'batch_id': batch_id, 'reg_id':reg_id,'unit_id':unit_id,
		  },
		  headers: {
			  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
		  },
		  success: function (result) {
			  console.log(result);
			  $('#batch_popup').html(result);
			  $('#addBatchModalgrid').modal('show');
		  }
	  });
	
	
}

 $(document).on('click','#formSubmit',function(e){
		e.preventDefault();
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
			}
		});
		$.ajax({
			url: "{{route('superadmin.storeBatch')}}",
			method: 'post',
			data: {
				at_input_approval_reg_details_id: $('#at_input_approval_reg_details_id').val(),
				at_input_approval_unit_reg_detail_id: $('#at_input_approval_unit_reg_detail_id').val(),
				at_input_product_category_id: $('#at_input_product_category_id').val(),
				at_input_sub_product_category_id: $('#at_input_sub_product_category_id').val(),
				product_name: $('#product_name').val(),
				batch_no: $('#batch_no').val(),
				batch_date: $('#batch_date').val(),
				batch_qty_mt: $('#batch_qty_mt').val(),
				batch_id: $('#batch_id').val(),
				product_id: $('#product_id').val(),
			},
			success: function(result){
				if(result.errors)
				{
					$('.alert-danger').html('');

					$.each(result.errors, function(key, value){
						$('.alert-danger').show();
						$('.alert-danger').append('<li>'+value+'</li>');
					});
				}
				else
				{					 
					if($("#row_" + $('#batch_id').val()).length === 1) {					  
						$('#table_batch_list > tbody > tr#row_' + $("#batch_id").val()).replaceWith(result.data);
					 }else{
						$('#table_batch_list > tbody').append(result.data);
					 }
					$('.alert-danger').hide();
					$('#addBatchModalgrid').modal('hide');
					$('#batch_popup').html('');
				}
			}
		});
	});

  
$(document).on('click', '.deletedata', function() {
	 var id=$(this).attr('data-value');
Swal.fire({
  title: 'Are you sure?',
  text: "You won't be able to revert this!",
  icon: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Yes, delete it!'
}).then((result) => {
  if (result.value) {
	   $.ajax({
        url: $(this).attr('data-href'),
        method: "DELETE",
        dataType: 'json',
        data: {
            'id': id,
        },
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        success: function(result) {		 
           $('#row_'+id).remove();			 
			Swal.fire(
			'Deleted!',
			'Record Deleted Successfully..',
			'success'
			)

        }
    });

  }
})

});
</script>
@endpush


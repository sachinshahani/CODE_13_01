 
<html><head>
    <meta charset="utf-8">
    <title>STATEMENT OF COMPLIANCE</title>
  </head>
<body>
      <div class="row">
	<div class="col-lg-12">
		<div class="card">
			<div class="card-body">
			
    <table border="0" cellspacing="0" cellpadding="0" style="width:100%;margin: 0 auto;margin-top:0px;border-collapse: collapse;">
        <tbody>
        <tr>
          <td style="text-align:center;padding-top:10px;vertical-align: text-top;padding-left:15px ;">
            <p style="font-family:'Arial';margin: 0;font-weight: bold;font-size: 20px;">
              STATEMENT OF COMPLIANCE
            </p>
          </td>
        </tr>
        <tr>
          <td>
            <p style="font-family:'Arial';padding: 3px 3px;margin: 0;font-size:14px;line-height: 18px;margin-top: 30px;">
              No. <span style="font-weight: 600;">{{$approval_reg_details->registration_no ?? ''}}</span>
            </p>
          </td>
        </tr>
        <tr>
          <td>
            <p style="font-family:'Arial';padding: 3px 3px;margin: 0;font-size:14px;line-height: 18px;margin-top: 15px;">
              For.   <span style="font-weight: 600;">{{$approval_reg_details->company_name ?? ''}}</span>
            </p>
          </td>
        </tr>
        <tr>
          <td>
            <p style="font-family:'Arial';padding: 3px 3px;margin: 0;font-size:14px;line-height: 18px;font-weight: 600;margin-top: 30px;">
              Operator Address</p>
          </td>
        </tr>
        <tr>
          <td style="padding-left:25px;">
            <p style="font-family:'Arial';padding: 0px 3px;margin: 0;font-size:14px;line-height: 18px;font-weight: 600;margin-top: 15px;">
                {{$approval_reg_details->address ?? ''}}
            </p>
            <p style="font-family:'Arial';padding: 0px 3px;margin: 0;font-size:14px;line-height: 18px;font-weight: 600;">
              State:  {{ getStateName($approval_reg_details->ref_state_id) }}
            </p>
            <p style="font-family:'Arial';padding: 0px 3px;margin: 0;font-size:14px;line-height: 18px;font-weight: 600;">
              District: {{ getDisName($approval_reg_details->ref_state_id) }}
            </p>
            <p style="font-family:'Arial';padding: 0px 3px;margin: 0;font-size:14px;line-height: 18px;font-weight: 600;">
              Taluk Amini: {{ getTalukName($approval_reg_details->ref_block_tehsil_id) }}
            </p>
          </td>
        </tr>
        <tr>
          <td>
            <p style="font-family:'Arial';padding: 3px 3px;margin: 0;font-size:14px;line-height: 18px;margin-top:50px;">
              Based on a signed contract and external inspection carried out in the <span style="font-weight: 600;">{{$approval_reg_details->registration_date}}</span> ,M/s. <span style="font-weight: 600;">{{$approval_reg_details->producer_name}}</span> ,herewith confirms that the products mentioned in the list attached are manufactured by the
              above mentioned company, is in compliance for use in organic production as allowed/restricted product under
              NPOP.</p>
          </td>
        </tr>
        <tr>
          <td>
            <p style="font-family:'Arial';padding:2px 3px 0;margin: 0;font-size:14px;line-height: 18px;margin-top: 30px;">
              Date of Issue : <span style="font-weight: 600;">{{$approval_reg_details->validity_start_from ?? ''}}</span>
            </p>
            <p style="font-family:'Arial';padding:2px 3px 0;margin: 0;font-size:14px;line-height: 18px;">
              Valid upto : <span style="font-weight: 600;">{{$approval_reg_details->validity_start_from ?? ''}}</span>
            </p>
            <p style="font-family:'Arial';padding: 2px 3px 0;margin: 0;font-size:14px;line-height: 18px;">
              Place : <span style="font-weight: 600;">{{$approval_reg_details->address ?? ''}}</span>
            </p>
          </td>
        </tr>
        <tr>
          <td style="width: 40%;float:right;">
            <p style="font-family:'Arial';padding: 2px 3px 0;margin: 0;font-size:14px;line-height: 18px;">
              Seal____________________________________
            </p>
            <p style="font-family:'Arial';padding: 2px 3px 0;margin: 0;font-size:14px;line-height: 18px;">
              Authorized Signatory
            </p>
            <p style="font-family:'Arial';padding: 2px 3px 0;margin: 0;font-size:14px;line-height: 18px;">
              M/s <span style="font-weight: 600;">{{$approval_reg_details->producer_name}}</span>
            </p>
          </td>
        </tr>
    </tbody>

    </table>
    <table border="0" cellspacing="0" cellpadding="0" style="width:100%;margin: 0 auto;margin-top:50px;border-collapse: collapse;">
        <tbody>
        <tr>
          <td style="text-align: right;">
            <p style="font-family:'Arial';padding: 3px 3px;margin: 0;font-size:12px;line-height: 18px;margin-top:30px;">
              Annexure
            </p>
          </td>
        </tr>
        <tr>
          <td style="text-align:left;padding-top:10px;vertical-align: text-top;">
            <p style="font-family:'Arial';margin: 0;font-weight: bold;font-size: 18px;">
              Production Detail(s)
            </p>
          </td>
        </tr>
        <tr>
          <td>
            <p style="font-family:'Arial';padding: 3px 3px;margin: 0;font-size:14px;line-height: 18px;margin-top:20px;">
              No. <span style="font-weight: 600;">{{$approval_reg_details->registration_no ?? ''}}</span>
            </p>
          </td>
        </tr>
        <tr>
          <td>
            <table border="1" cellspacing="0" cellpadding="0" style="width:100%;margin: 0 auto;margin-top:50px;border-collapse: collapse;">
              <thead>
                <tr>
                  <th style="text-align: left;width: 12%;">
                    <p style="font-family:'Arial';padding: 3px 3px;margin: 0;font-size:14px;line-height: 18px;">
                      Name of Production Unit
                    </p>
                  </th>
                  <th style="text-align: left;width: 12%;">
                    <p style="font-family:'Arial';padding: 3px 3px;margin: 0;font-size:14px;line-height: 18px;">
                      Brand Name
                    </p>
                  </th>
                  <th style="text-align: left;width:20%;">
                    <p style="font-family:'Arial';padding: 3px 3px;margin: 0;font-size:14px;line-height: 18px;">
                      Category of the product (Microbinal preparations/herbal preparations/biodynamic preparations/manure)
                    </p>
                  </th>
                  <th style="text-align: left;">
                    <p style="font-family:'Arial';padding: 3px 3px;margin: 0;font-size:14px;line-height: 18px;">
                      Use for nutrient/pest control/growth enhancement
                    </p>
                  </th>
                  <th style="text-align: left;width: 18%;">
                    <p style="font-family:'Arial';padding: 3px 3px;margin: 0;font-size:14px;line-height: 18px;">
                      List of ingredients
                    </p>
                  </th>
                  <th style="text-align: left;">
                    <p style="font-family:'Arial';padding: 3px 3px;margin: 0;font-size:14px;line-height: 18px;">
                      Estimated Quantity (in MT)
                    </p>
                  </th>
                  <th style="text-align: left;width: 11%;">
                    <p style="font-family:'Arial';padding: 3px 3px;margin: 0;font-size:14px;line-height: 18px;">
                      Shelf life of the Product
                      (In Months)
                    </p>
                  </th>
                </tr>
              </thead>
              <tbody>
                @forelse($approval_reg_details->getUnitRegDetailsWithIngredient as $key => $val)
					 @forelse($val->getProductsDetails as $key => $productval)
                <tr>
                  <td>
                    <p style="font-family:'Arial';padding: 3px 3px;margin: 0;font-size:14px;line-height: 18px;">
                     {{$val->unit_name ?? ''}}
                    </p>
                  </td>
                  <td>
                    <p style="font-family:'Arial';padding: 3px 3px;margin: 0;font-size:14px;line-height: 18px;">
                        {{$productval->product_name ?? ''}}
                    </p>
                  </td>
                  <td>
                    <p style="font-family:'Arial';padding: 3px 3px;margin: 0;font-size:14px;line-height: 18px;">
                        {{ (!empty($productval->at_input_product_category_id)) ? getInputProductCategoryById($productval->at_input_product_category_id)->category_name : ''}}
                    </p>
                </td>
                  <td>
                    <p style="font-family:'Arial';padding: 3px 3px;margin: 0;font-size:14px;line-height: 18px;">                       
					  {{ (!empty($productval->at_proudct_use_id)) ? getProudctUseById($productval->at_proudct_use_id)->use_for : ''}}
                    </p>
                  </td>
                  <td style="padding: 3px;">
                    <p style="font-family:'Arial';padding: 3px 3px;margin: 0;font-size:14px;line-height: 18px;font-weight: 600;border: 1px solid #000;">
                      Ingredient Name(s)
                    </p>
						@forelse($productval->getIngredient as $key => $ingredientval)
							<p style="font-family:'Arial';padding: 3px 3px;margin: 0;font-size:14px;line-height: 18px;border: 1px solid #000;border-top: 0;">
								{{$ingredientval->ingredient_name}}
							</p>
						@empty
						@endforelse
                  </td>
                  <td>
                    <p style="font-family:'Arial';padding: 3px 3px;margin: 0;font-size:14px;line-height: 18px;text-align: right;">
                        {{ number_format($val->estimated_production_in_mt,2)}}
                    </p>
                  </td>
                  <td>
                    <p style="font-family:'Arial';padding: 3px 3px;margin: 0;font-size:14px;line-height: 18px;text-align: right;">
                    {{$productval->self_life}}
                    </p>
                  </td>
                </tr>
                 
             
				  @empty
				  @endforelse
					  
              @empty
              @endforelse
				</tbody>
            </table>
          </td>
        </tr>
      </tbody>
    </table>
</div>
</div>
</div>
  </body>
  </html>


 

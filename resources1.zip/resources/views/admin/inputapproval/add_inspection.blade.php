@extends('admin.layouts.app')
@section('content')

<style>
.overlay {
    background: rgb(0 0 0 / 50%);
    position: fixed;
    top: 0;
    z-index: 11111;
    left: 0;
    right: 0;
    bottom: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    display: none;
}

.loader {
    position: fixed !important;
    left: 50% !important;
    margin-left: -4em !important;
    top: 20em !important;
}

.wrapper {
    max-width: 1240px;
    margin: 0 auto;
}

.white-bg {
    background-color: white;
    /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
    border-bottom: 5px solid #ff9800;
    margin-bottom: 15px;
}

.auth-one-bg .slide .carousel-indicators {
    bottom: 25px;
}

.auth-page-wrapper .auth-page-content {
    padding-bottom: 0px !important;
}

.auth-page-content .card {
    margin-bottom: 0rem;
}

.data-tabs .wrapper .nav-tabs button {
    font-size: 17px;
    color: black;
}

.data-tabs .wrapper .nav-tabs .active {
    background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
    */ color: white;
    background: orange;
    border-radius: 0px;
}

.carousel-caption.d-none.d-md-block {
    background-color: #000000bf;
    left: 0;
    width: 100%;
    bottom: 0;
}

.carousel-indicators {
    display: none;
}

.custom-banner-caption {
    color: white !important;
}

.announcement-heading {
    font-size: 1.2em;
    font-weight: 600;
}

.data-tabs .tab-pane ul li {
    font-size: 1em;
    padding: 5px 0;

}

.main-logo {
    padding: 10px;
}

.data-tabs .nav-item .nav-link {
    background-image: none;
}

/* .right-sec{
        box-shadow: 5px 10px 18px #888888;
    } */
.navbar-brand-box {
    background: #fff;
}

[data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
    color: white !important;
}

.header-buttons .btn-primary {
    margin-right: 10px;
    padding: 6px 15px;
    font-weight: 600;
    background-color: #207005;
    border: none;
    box-shadow: 0px 2px 7px #888888;
}

.header-buttons .btn-secondary {
    margin-right: 10px;
    padding: 6px 15px;
    font-weight: 600;
    background-color: #72a055;
    border: none;
    box-shadow: 0px 2px 7px #888888;
}


.right-sec {
    border-left: 5px solid #ede7e7;
}

.tabdiv {
    background: white;
    padding: 20px;
    margin-top: 10px;
    border: 10px solid #dfdbd5;
}

.nav-tabs {
    border-bottom: 0px;
}

div#myTabContent {
    border: 1px solid #cccccc;
}

.frontfooter footer {
    padding: 20px calc(1.5rem / 2);
    position: static;
    color: #000;
    height: 60px;
    background-color: #f9f9f9;
    margin-top: 30px;
    border-top: 1px solid #e1dfdf;
}

span.logo-sm img {
    width: 69px;
}

.seperatesec {
    margin-top: 20px;
}

.simplebar-content li.nav-item:hover {
    background: #4caf50;
}

.sectitle {
    font-size: 14px;
}

.required {
    color: red;
}

.customtextarea {
    height: 120px;
}

ul.boxsection {
    margin: 0;
    padding: 0;
}

ul.boxsection li {
    list-style-type: none;
    padding: 7px 0;
    border-bottom: 1px solid #efeded;
}

.boxcard .col:nth-child(1) {
    background: #effcfb;
}

.boxcard .col:nth-child(2) {
    background: #fdfdfd;
}

.boxcard .col:nth-child(3) {
    background: #effcfb;
}

.boxcard .col:nth-child(4) {
    background: #fdfdfd;
}

.boxcard .col:nth-child(5) {
    background: #effcfb;
}

/* --registration-form css  */
.custom-tab-content {
    padding-top: 0 !important;
    padding-bottom: 0px !important;
}

.custom-tab-nav {
    background: white;

}

.custom-tab-nav .nav-link {
    border-radius: 0 !important;
    border-bottom: 1px solid #e9ebec;
    border-right: 1px solid #e9ebec;
    font-size: 14px;
    padding: 10px;
}

.custom-tab-nav .nav-link.active,
.custom-tab-nav .show>.nav-link {
    color: rgb(255, 255, 255) !important;
    background-color: #2c8c6d;
    border-bottom: #2c8c6d !important;
    /* border-bottom: #207005 !important; */
    position: relative;
}

.custom-tab-nav .nav-link:hover,
.custom-tab-nav .nav-link:focus {
    border-bottom: 1px solid #207005;
    border-radius: 0;
    font-size: 14px;
    transition: background-color 0.20s linear;
}

.custom-tab-nav .nav-link.active:after {
    content: "";
    position: absolute;
    bottom: -16px;
    left: 50%;
    border: 8px solid transparent;
    border-top-color: #2c8c6d;
    z-index: 999;
}

.reg-form-btns {
    margin-bottom: 15px;
}

.reg-form-btns .btn-secondary {
    color: #fff;
    background-color: #405189;
    border-color: #405189;
}

.btn-soft-success:active,
.btn-soft-success:focus,
.btn-soft-success:hover {
    border: none;
}

.custom-tab-nav ul {
    padding: 0px;
    margin: 0px;
}

.custom-tab-nav ul li {
    padding: 0px;
    margin: 0px;
    display: inline-block;
    list-style: none;
}

/* -------  */
.btn-email {
    font-size: 13px;
    padding: 1px 7px;
    line-height: 17px;

}

.btn-mailsend {
    font-size: 13px;
    padding: 1px 7px;
    line-height: 17px;
}

.btn-verify {
    font-size: 13px;
    padding: 1px 7px;
    line-height: 34px;
}

.inputEmail .input-group-append {
    display: flex;
    align-items: end;
}

.inputEmail .validateEmailId {
    border-radius: 4px 0 0 4px;
}

.input-group-append .verifiEmail_otp,
.input-group-append .resendEmail_otp {
    margin-left: 10px;
}

.login-pass.otp-email {
    margin-top: 5px
}

.login-pass.otp-email .inp-b {
    border-radius: 0 4px 4px 0
}
</style>

<div class="overlay">
    <div class="loader"></div>
</div>
  
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1">Inspection-non-confirmities entry</h4>
                <div class="flex-shrink-0">
                    @if (session('error'))
                    <div class="alert alert-danger">
                        {{ session('error') }}
                    </div>
                    @endif
                    @if (session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                    @endif
                    @if($errors)
                    @foreach ($errors->all() as $error)
                    <div class="alert alert-danger">{{ $error }}</div>
                    @endforeach
                    @endif
                </div>
            </div>

            <div class="card-body">
                <div class="live-preview">
                    <form action="{{ route('superadmin.storeNewInspection',$id) }}" class="commonform1"
                        method="POST" enctype="multipart/form-data" id="commonform1" autocomplete="off">
                        @csrf 
                        <div class="row seperatesec white-inner">
							<div class="sectitle">
                                <label for="labelInput" class="form-label blue-ht">Operator Details</label>
                            </div>
                            
                            <div class="col-xxl-3 col-md-3 gy-3">
                                <div>
                                    <label class="form-label"> Registration No: <span class="required">*</span></label>
                                    <input type="text" class="form-control" name="registration_no" id="registration_no" readonly required value="{{$data->registration_no}}">

                                </div>
                            </div>
                             
                            
                            <div class="col-xxl-3 col-md-3 gy-3">
                                <div>
                                    <label class="form-label"> Operator name  : <span class="required">*</span></label>
                                    <input type="text" class="form-control" name="company_name" id="company_name" readonly required value="{{$data->company_name}}">

                                </div>
                            </div>
							 
						 
						</div>
					<div class="row seperatesec white-inner">
							
							 <div class="sectitle">
                                <label for="labelInput" class="form-label blue-ht">Inspection Entry</label>
                            </div>
							<div class="col-xxl-3 col-md-3 gy-3">
								<div>
									<label class="form-label">Area/Department/Function<span class="required">*
										</span></label>
									<input type="text" class="form-control" name="area_dept"
										id="area_dept" required
										value="">
								</div>
							</div>
							<div class="col-xxl-3 col-md-3 gy-3">
								<div>
									<label class="form-label">Inspected By<span
											class="required">*
										</span></label>
									<input type="text" class="form-control"
										value=""  required
										id="auditor_name" name="auditor_name"
										   >
								</div>
							</div>
 
							<div class="col-xxl-3 col-md-3 gy-3">
								<div>
									<label class="form-label">Inspected from date<span class="required">
										</span></label>
									<input type="date" class="form-control" name="ins_from_date"
										id="ins_from_date" required
										value="">
								</div>
							</div>
							<div class="col-xxl-3 col-md-3 gy-3">
								<div>
									<label class="form-label">Inspected To date<span class="required">
										</span></label>
									<input type="date" class="form-control" name="ins_to_date"
										id="ins_to_date" required
										value="">
								</div>
							</div>
							
							<div class="col-xxl-3 col-md-4 gy-3">
								<div>
									<label class="form-label">Observation<span class="required">
										</span></label>
									<textarea class="form-control" name="observations" id="observations" ></textarea>
								</div>
							</div>
						
						</div>
						<!-- END seperatesec ROW -->
						
						 <div class="row seperatesec white-inner">

                            <div class="sectitle">
                                <label for="labelInput" class="form-label blue-ht">Enter Inspection Details</label>
								<i style="float: right;" data-type="wm" onclick="addNew();" class="mdi mdi-plus btn btn-soft-success add-more"
                                                        data-toggle="tooltip" title="Add Row"></i>
                            </div>

                            <div class="col-xxl-12 col-md-12 gy-3">
                                 <div class=" table-responsive">
									<table id="deptUser" class="table table-bordered table-striped align-middle" style="width:100%">
										<thead>
											<tr>
												<th>Grade</th>
												<th>Description</th>
												<th>Deadline date</th>											 
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
											<tr id="row_0">
												<td>
													<select style="width:120px;" class="form-control" name="unit_registration[0][grade]" id="grade" required>
														<option value="Major">Major</option>
														<option value="Minor">Minor</option>														 
													</select>
												</td>
												<td>
													<textarea style="width:200px;" class="form-control" name="unit_registration[0][description]" id="description"></textarea>
												</td>
												<td>
													<input style="width: 126px;" type="date" class="form-control" name="unit_registration[0][dead_line_date]" id="dead_line_date" value=""  required>
												</td>
												<td>
													<i data-type="wm" class="mdi mdi-minus btn btn-soft-danger "
                                                            data-toggle="tooltip" title="Remove Row"></i>
												</td>
												
											</tr>
										</tbody>
									</table>
								</div>
                            </div>
							
						</div>
						<!-- END seperatesec ROW -->
						<div class="row">
							<div class="col-lg-12 gy-4">
								<div class="hstack gap-2">
									<button type="submit" class="btn btn-primary">
										Submit Application
									</button>							   

								</div>
							</div>

						</div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@push('script')

<div id="addNew"  style="display:none">
<table>
<tr id="row_row_id">
	<td>
		<select style="width:120px;" class="form-control" name="unit_registration[row_id][grade]" id="grade" required>
			<option value="Major">Major</option>
			<option value="Minor">Minor</option>														 
		</select>
	</td>
	<td>
		<textarea style="width:200px;" class="form-control" name="unit_registration[row_id][description]" id="description"></textarea>
	</td>
	<td>
		<input style="width: 126px;" type="date" class="form-control" name="unit_registration[row_id][dead_line_date]" id="dead_line_date" value=""  required>
	</td>
 
<td>
	<i data-type="wm" class="mdi mdi-minus btn btn-soft-danger " onclick="removeRow(row_id)"
			data-toggle="tooltip" title="Remove Row"></i>
</td>
</tr>
</table>
</div>

<script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
<script type="text/javascript">

 
 
function addNew()
{  
	var rowCount = $('#deptUser tbody tr').length; 
	var row = $('#addNew table > tbody ').html().replaceAll('row_id',rowCount);	
	$('#deptUser tbody').append(row);
}

function removeRow(id)
{	 
	$('tr#row_'+id).remove();
}

</script>
 
@endpush
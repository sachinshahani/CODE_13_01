@extends('admin.layouts.app')
@section('content')

<style>
.overlay {
    background: rgb(0 0 0 / 50%);
    position: fixed;
    top: 0;
    z-index: 11111;
    left: 0;
    right: 0;
    bottom: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    display: none;
}

.loader {
    position: fixed !important;
    left: 50% !important;
    margin-left: -4em !important;
    top: 20em !important;
}

.wrapper {
    max-width: 1240px;
    margin: 0 auto;
}

.white-bg {
    background-color: white;
    /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
    border-bottom: 5px solid #ff9800;
    margin-bottom: 15px;
}

.auth-one-bg .slide .carousel-indicators {
    bottom: 25px;
}

.auth-page-wrapper .auth-page-content {
    padding-bottom: 0px !important;
}

.auth-page-content .card {
    margin-bottom: 0rem;
}

.data-tabs .wrapper .nav-tabs button {
    font-size: 17px;
    color: black;
}

.data-tabs .wrapper .nav-tabs .active {
    background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
    */ color: white;
    background: orange;
    border-radius: 0px;
}

.carousel-caption.d-none.d-md-block {
    background-color: #000000bf;
    left: 0;
    width: 100%;
    bottom: 0;
}

.carousel-indicators {
    display: none;
}

.custom-banner-caption {
    color: white !important;
}

.announcement-heading {
    font-size: 1.2em;
    font-weight: 600;
}

.data-tabs .tab-pane ul li {
    font-size: 1em;
    padding: 5px 0;

}

.main-logo {
    padding: 10px;
}

.data-tabs .nav-item .nav-link {
    background-image: none;
}

/* .right-sec{
        box-shadow: 5px 10px 18px #888888;
    } */
.navbar-brand-box {
    background: #fff;
}

[data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
    color: white !important;
}

.header-buttons .btn-primary {
    margin-right: 10px;
    padding: 6px 15px;
    font-weight: 600;
    background-color: #207005;
    border: none;
    box-shadow: 0px 2px 7px #888888;
}

.header-buttons .btn-secondary {
    margin-right: 10px;
    padding: 6px 15px;
    font-weight: 600;
    background-color: #72a055;
    border: none;
    box-shadow: 0px 2px 7px #888888;
}


.right-sec {
    border-left: 5px solid #ede7e7;
}

.tabdiv {
    background: white;
    padding: 20px;
    margin-top: 10px;
    border: 10px solid #dfdbd5;
}

.nav-tabs {
    border-bottom: 0px;
}

div#myTabContent {
    border: 1px solid #cccccc;
}

.frontfooter footer {
    padding: 20px calc(1.5rem / 2);
    position: static;
    color: #000;
    height: 60px;
    background-color: #f9f9f9;
    margin-top: 30px;
    border-top: 1px solid #e1dfdf;
}

span.logo-sm img {
    width: 69px;
}

.seperatesec {
    margin-top: 20px;
}

.simplebar-content li.nav-item:hover {
    background: #4caf50;
}

.sectitle {
    font-size: 14px;
}

.required {
    color: red;
}

.customtextarea {
    height: 120px;
}

ul.boxsection {
    margin: 0;
    padding: 0;
}

ul.boxsection li {
    list-style-type: none;
    padding: 7px 0;
    border-bottom: 1px solid #efeded;
}

.boxcard .col:nth-child(1) {
    background: #effcfb;
}

.boxcard .col:nth-child(2) {
    background: #fdfdfd;
}

.boxcard .col:nth-child(3) {
    background: #effcfb;
}

.boxcard .col:nth-child(4) {
    background: #fdfdfd;
}

.boxcard .col:nth-child(5) {
    background: #effcfb;
}

/* --registration-form css  */
.custom-tab-content {
    padding-top: 0 !important;
    padding-bottom: 0px !important;
}

.custom-tab-nav {
    background: white;

}

.custom-tab-nav .nav-link {
    border-radius: 0 !important;
    border-bottom: 1px solid #e9ebec;
    border-right: 1px solid #e9ebec;
    font-size: 14px;
    padding: 10px;
}

.custom-tab-nav .nav-link.active,
.custom-tab-nav .show>.nav-link {
    color: rgb(255, 255, 255) !important;
    background-color: #2c8c6d;
    border-bottom: #2c8c6d !important;
    /* border-bottom: #207005 !important; */
    position: relative;
}

.custom-tab-nav .nav-link:hover,
.custom-tab-nav .nav-link:focus {
    border-bottom: 1px solid #207005;
    border-radius: 0;
    font-size: 14px;
    transition: background-color 0.20s linear;
}

.custom-tab-nav .nav-link.active:after {
    content: "";
    position: absolute;
    bottom: -16px;
    left: 50%;
    border: 8px solid transparent;
    border-top-color: #2c8c6d;
    z-index: 999;
}

.reg-form-btns {
    margin-bottom: 15px;
}

.reg-form-btns .btn-secondary {
    color: #fff;
    background-color: #405189;
    border-color: #405189;
}

.btn-soft-success:active,
.btn-soft-success:focus,
.btn-soft-success:hover {
    border: none;
}

.custom-tab-nav ul {
    padding: 0px;
    margin: 0px;
}

.custom-tab-nav ul li {
    padding: 0px;
    margin: 0px;
    display: inline-block;
    list-style: none;
}

/* -------  */
.btn-email {
    font-size: 13px;
    padding: 1px 7px;
    line-height: 17px;

}

.btn-mailsend {
    font-size: 13px;
    padding: 1px 7px;
    line-height: 17px;
}

.btn-verify {
    font-size: 13px;
    padding: 1px 7px;
    line-height: 34px;
}

.inputEmail .input-group-append {
    display: flex;
    align-items: end;
}

.inputEmail .validateEmailId {
    border-radius: 4px 0 0 4px;
}

.input-group-append .verifiEmail_otp,
.input-group-append .resendEmail_otp {
    margin-left: 10px;
}

.login-pass.otp-email {
    margin-top: 5px
}

.login-pass.otp-email .inp-b {
    border-radius: 0 4px 4px 0
}
</style>

<div class="overlay">
    <div class="loader"></div>
</div>
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Add New Product details to registration</h4> 
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1">Add New Product details to registration</h4>
                <div class="flex-shrink-0">
                    @if (session('error'))
                    <div class="alert alert-danger">
                        {{ session('error') }}
                    </div>
                    @endif
                    @if (session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                    @endif
                    @if($errors)
                    @foreach ($errors->all() as $error)
                    <div class="alert alert-danger">{{ $error }}</div>
                    @endforeach
                    @endif
                </div>
            </div>

            <div class="card-body">
                <div class="live-preview">
                    <form action="{{ route('superadmin.storeProduct') }}" class="commonform1"
                        method="POST" enctype="multipart/form-data" id="commonform1" autocomplete="off">
                        @csrf 
						<input type="hidden" name="renew" value="{{$renew}}" />
						 <input type="hidden" name="unit_id" value="{{$unit_id}}" />
						 <input type="hidden" name="reg_id" value="{{$result->at_input_approval_reg_details_id}}" />
                        <div class="row seperatesec white-inner">

                            <div class="sectitle">
                                <label for="labelInput" class="form-label blue-ht">Registration Details</label>
                            </div>

                            <div class="col-xxl-3 col-md-3 gy-3">
                                <div>
                                    <label class="form-label">Registration No.: <span class="required">*</span></label>
                                    <input type="text" class="form-control" name="at_input_approval_reg_details_id" id="at_input_approval_reg_details_id" readonly value="{{$result->registration_no}}">

                                </div>
                            </div>
                             
                            
                            <div class="col-xxl-3 col-md-3 gy-3">
                                <div>
                                    <label class="form-label">Unit Registration No.: <span class="required">*</span></label>
                                    <input type="text" class="form-control" name="at_input_approval_unit_reg_detail_id" id="at_input_approval_unit_reg_detail_id" readonly value="{{$result->unit_reg_number}}">

                                </div>
                            </div>
							 
							
							 <div class="sectitle gy-3">
                                <label for="labelInput" class="form-label blue-ht">Add product Details</label>
                            </div>
							 
							<div class="col-xxl-3 col-md-3 gy-3">
								<div>
									<label for="labelInput" class="form-label">Product Category <span	class="required">*</span></label>										 
									 <select class="form-select" name="at_input_product_category_id" id="at_input_product_category_id"  required onchange="getSubCat(this.value);">
										<option value="">-Select Category-</option>
										@forelse($categories as $value)
											<option value="{{ $value->id }}">{{ $value->category_name }}</option>
										@empty
										@endforelse
									</select>
								</div>
							</div>
							<div class="col-xxl-3 col-md-3 gy-3">
								<div>
									<label for="labelInput" class="form-label">Product Sub-Category <span
											class="required">*</span></label>											 
									<select class="form-select" name="at_input_sub_product_category_id" id="at_input_sub_product_category_id"  required>
										<option value="">Select Sub-Category</option>
										
									</select>
								</div>
							</div>
							<div class="col-xxl-3 col-md-3 gy-3">
								<div>
									<label class="form-label">Brand Name<span class="required">*
										</span></label>
									<input type="text" class="form-control" name="product_name"
										id="product_name" required
										value="">
								</div>
							</div>
							<div class="col-xxl-3 col-md-3 gy-3">
								<div>
									<label class="form-label">Self life of product(in month)<span class="required">*
										</span></label>
									<input type="number" class="form-control" name="self_life"
										id="self_life" required
										value="">
								</div>
							</div>
							
							<div class="col-xxl-3 col-md-3 gy-3">
								<div>
									<label class="form-label">Use of product </label>
									<select class="form-select" name="at_proudct_use_id" id="at_proudct_use_id"  >
										<option value="">Select</option>
										 @forelse($use_of_products as $value)
											<option value="{{ $value->id }}">{{ $value->use_for }}</option>
										@empty
										@endforelse
									</select>
								</div>
							</div>
 
							<div class="col-xxl-3 col-md-3 gy-3">
								<div>
									<label class="form-label">Product permitted/restricted</label>
									<select class="form-select" name="at_input_approval_proudct_mode_id" id="at_input_approval_proudct_mode_id"   required>
										<option value="">Select product mode</option>
										 @forelse($product_modes as $value)
											<option value="{{ $value->id }}">{{ $value->product_mode }}</option>
										@empty
										@endforelse
									</select>
								</div>
							</div>
							<div class="col-xxl-12 col-md-12 gy-3">
								<div>
									<label class="form-label">Description<span class="required">*
										</span></label>
									<textarea class="form-control customtextarea valid" name="product_desc" required="" aria-invalid="false"></textarea>
								</div>
							</div>
							 
						</div>
					  
						 
						<!-- END seperatesec ROW -->
						<div class="row">
							<div class="col-lg-12 gy-4">
								<div class="hstack gap-2">
									<button type="submit" class="btn btn-primary">
										Submit
									</button>							   

								</div>
							</div>

						</div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@push('script')
 

<script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
<script type="text/javascript">

 

$("#commonform1").validate({
    rules: {
        // user_password: { 
        // 	required: true,
        // 	minlength: 8,
        // 	maxlength: 10,
        // } ,
        mobile: {
            required: true,
        }
    },
    messages: {
        // user_password: { 
        // 	required:"This field is required and should be 8 digits, contains upper,lowerCase,and a special Character"   
        // },
        mobile: {
            required: "This field is required",
        }
    }

});

function CheckPassword(inputtxt) {
    if (inputtxt.value.length > 0) {
        var decimal = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
        if (inputtxt.value.match(decimal)) {
            return true;
        } else {
            Swal.fire('',
                'Password should be 8 digits,contains upperCase letter,lowerCase letter,and a special Character',
                'warning');
            $("#user_password").val('');
            return false;
        }
    }
}

function phonenumber(inputtxt) {
    var phoneno = /^\d{10}$/;
    if (inputtxt.value.match(phoneno)) {
        return true;
    } else {
        Swal.fire('', 'Please enter a valid mobile number.', 'warning');
        $("#mobile").val('');
        return false;
    }
}

function getSubCat(cat_id)
{
	$.ajax({
		  url: "{{ route('superadmin.getSubcategory') }}",
		  method: "POST",
		  dataType: 'json',
		  data: {
			  'cat_id': cat_id,
		  },
		  headers: {
			  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
		  },
		  success: function (result) {			  
			  var option = '';
			  option += '<option value="">Select Sub-Category</option>';			  
			  $.each(result.data, function (i, item) {
				  option += "<option value='" + item.id + "'>" + item.sub_product_category_name + "</option>";

			  });
			  $('#at_input_sub_product_category_id').html(option);
		  }
	  });
}
 
</script>
 
@endpush
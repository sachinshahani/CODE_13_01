<div class="alert alert-danger" style="display:none"></div>
<form action="{{route('superadmin.storeBatch')}}" method="post">
 @csrf 
<input type="hidden" name="at_input_approval_unit_reg_detail_id" id="at_input_approval_unit_reg_detail_id" value="{{$result->getUnitsDetails->id}}" />
<input type="hidden" name="at_input_approval_reg_details_id" id="at_input_approval_reg_details_id" value="{{$result->getRegistrationDetails->id}}" />
<input type="hidden" name="at_input_product_category_id" id="at_input_product_category_id" value="{{$result->at_input_product_category_id}}" />
<input type="hidden" name="at_input_sub_product_category_id" id="at_input_sub_product_category_id" value="{{$result->at_input_sub_product_category_id}}" />
<input type="hidden" name="product_name" id="product_name" value="{{$result->product_name}}" />
<input type="hidden" name="batch_id" id="batch_id" value="{{ $batch_detail->id ?? ''}}" />
<input type="hidden" name="product_id" id="product_id" value="{{ $result->id ?? ''}}" />
	<div class="row g-3">
		<div class="col-xxl-6">
			<div>
				<label for="batch_no" class="form-label">Batch No.</label>
				<input type="text" class="form-control" value="{{ $batch_detail->batch_no ?? ''}}" name="batch_no" id="batch_no" required>
			</div>
		</div><!--end col-->
		<div class="col-xxl-6">
			<div>
				<label for="batch_date" class="form-label">Batch Tentative Date</label>
				<input type="date" class="form-control" value="{{ $batch_detail->batch_date ?? ''}}" name="batch_date" id="batch_date" required>
			</div>
		</div><!--end col-->
		<div class="col-xxl-6">
			<div>
				<label for="batch_qty_mt" class="form-label">Qty. to be Produced(In MT)</label>
				<input type="number" class="form-control" value="{{ $batch_detail->batch_qty_mt ?? ''}}" name="batch_qty_mt" id="batch_qty_mt" required>
			</div>
		</div><!--end col-->
		 
		 
	 
		<div class="col-lg-12">
			<div class="hstack gap-2 justify-content-end">
				<button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
				<button type="button" id="formSubmit" class="btn btn-primary">Submit</button>
			</div>
		</div><!--end col-->
	</div><!--end row-->
</form>
@extends('admin.layouts.app')
@section('content')

<style>
.overlay {
    background: rgb(0 0 0 / 50%);
    position: fixed;
    top: 0;
    z-index: 11111;
    left: 0;
    right: 0;
    bottom: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    display: none;
}

.loader {
    position: fixed !important;
    left: 50% !important;
    margin-left: -4em !important;
    top: 20em !important;
}

.wrapper {
    max-width: 1240px;
    margin: 0 auto;
}

.white-bg {
    background-color: white;
    /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
    border-bottom: 5px solid #ff9800;
    margin-bottom: 15px;
}

.auth-one-bg .slide .carousel-indicators {
    bottom: 25px;
}

.auth-page-wrapper .auth-page-content {
    padding-bottom: 0px !important;
}

.auth-page-content .card {
    margin-bottom: 0rem;
}

.data-tabs .wrapper .nav-tabs button {
    font-size: 17px;
    color: black;
}

.data-tabs .wrapper .nav-tabs .active {
    background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
    */ color: white;
    background: orange;
    border-radius: 0px;
}

.carousel-caption.d-none.d-md-block {
    background-color: #000000bf;
    left: 0;
    width: 100%;
    bottom: 0;
}

.carousel-indicators {
    display: none;
}

.custom-banner-caption {
    color: white !important;
}

.announcement-heading {
    font-size: 1.2em;
    font-weight: 600;
}

.data-tabs .tab-pane ul li {
    font-size: 1em;
    padding: 5px 0;

}

.main-logo {
    padding: 10px;
}

.data-tabs .nav-item .nav-link {
    background-image: none;
}

/* .right-sec{
        box-shadow: 5px 10px 18px #888888;
    } */
.navbar-brand-box {
    background: #fff;
}

[data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
    color: white !important;
}

.header-buttons .btn-primary {
    margin-right: 10px;
    padding: 6px 15px;
    font-weight: 600;
    background-color: #207005;
    border: none;
    box-shadow: 0px 2px 7px #888888;
}

.header-buttons .btn-secondary {
    margin-right: 10px;
    padding: 6px 15px;
    font-weight: 600;
    background-color: #72a055;
    border: none;
    box-shadow: 0px 2px 7px #888888;
}


.right-sec {
    border-left: 5px solid #ede7e7;
}

.tabdiv {
    background: white;
    padding: 20px;
    margin-top: 10px;
    border: 10px solid #dfdbd5;
}

.nav-tabs {
    border-bottom: 0px;
}

div#myTabContent {
    border: 1px solid #cccccc;
}

.frontfooter footer {
    padding: 20px calc(1.5rem / 2);
    position: static;
    color: #000;
    height: 60px;
    background-color: #f9f9f9;
    margin-top: 30px;
    border-top: 1px solid #e1dfdf;
}

span.logo-sm img {
    width: 69px;
}

.seperatesec {
    margin-top: 20px;
}

.simplebar-content li.nav-item:hover {
    background: #4caf50;
}

.sectitle {
    font-size: 14px;
}

.required {
    color: red;
}

.customtextarea {
    height: 120px;
}

ul.boxsection {
    margin: 0;
    padding: 0;
}

ul.boxsection li {
    list-style-type: none;
    padding: 7px 0;
    border-bottom: 1px solid #efeded;
}

.boxcard .col:nth-child(1) {
    background: #effcfb;
}

.boxcard .col:nth-child(2) {
    background: #fdfdfd;
}

.boxcard .col:nth-child(3) {
    background: #effcfb;
}

.boxcard .col:nth-child(4) {
    background: #fdfdfd;
}

.boxcard .col:nth-child(5) {
    background: #effcfb;
}

/* --registration-form css  */
.custom-tab-content {
    padding-top: 0 !important;
    padding-bottom: 0px !important;
}

.custom-tab-nav {
    background: white;

}

.custom-tab-nav .nav-link {
    border-radius: 0 !important;
    border-bottom: 1px solid #e9ebec;
    border-right: 1px solid #e9ebec;
    font-size: 14px;
    padding: 10px;
}

.custom-tab-nav .nav-link.active,
.custom-tab-nav .show>.nav-link {
    color: rgb(255, 255, 255) !important;
    background-color: #2c8c6d;
    border-bottom: #2c8c6d !important;
    /* border-bottom: #207005 !important; */
    position: relative;
}

.custom-tab-nav .nav-link:hover,
.custom-tab-nav .nav-link:focus {
    border-bottom: 1px solid #207005;
    border-radius: 0;
    font-size: 14px;
    transition: background-color 0.20s linear;
}

.custom-tab-nav .nav-link.active:after {
    content: "";
    position: absolute;
    bottom: -16px;
    left: 50%;
    border: 8px solid transparent;
    border-top-color: #2c8c6d;
    z-index: 999;
}

.reg-form-btns {
    margin-bottom: 15px;
}

.reg-form-btns .btn-secondary {
    color: #fff;
    background-color: #405189;
    border-color: #405189;
}

.btn-soft-success:active,
.btn-soft-success:focus,
.btn-soft-success:hover {
    border: none;
}

.custom-tab-nav ul {
    padding: 0px;
    margin: 0px;
}

.custom-tab-nav ul li {
    padding: 0px;
    margin: 0px;
    display: inline-block;
    list-style: none;
}

/* -------  */
.btn-email {
    font-size: 13px;
    padding: 1px 7px;
    line-height: 17px;

}

.btn-mailsend {
    font-size: 13px;
    padding: 1px 7px;
    line-height: 17px;
}

.btn-verify {
    font-size: 13px;
    padding: 1px 7px;
    line-height: 34px;
}

.inputEmail .input-group-append {
    display: flex;
    align-items: end;
}

.inputEmail .validateEmailId {
    border-radius: 4px 0 0 4px;
}

.input-group-append .verifiEmail_otp,
.input-group-append .resendEmail_otp {
    margin-left: 10px;
}

.login-pass.otp-email {
    margin-top: 5px
}

.login-pass.otp-email .inp-b {
    border-radius: 0 4px 4px 0
}
</style>

<div class="overlay">
    <div class="loader"></div>
</div>
  <div class="row">
	<div class="col-12">
		<div class="page-title-box d-sm-flex align-items-center justify-content-between">
			<h4 class="mb-sm-0">Renew-Input approval</h4>
			<div class="page-title-right">
				<ol class="breadcrumb m-0">
					<li class="breadcrumb-item"><a href="javascript: void(0);">Admin</a></li>
					<li class="breadcrumb-item active">Renew-Input approval</li>
				</ol>
			</div>
		</div>
	</div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
                <div class="flex-shrink-0">
                    @if (session('error'))
                    <div class="alert alert-danger">
                        {{ session('error') }}
                    </div>
                    @endif
                    @if (session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                    @endif
                    @if($errors)
                    @foreach ($errors->all() as $error)
                    <div class="alert alert-danger">{{ $error }}</div>
                    @endforeach
                    @endif
                </div>
            

            <div class="card-body">
                <div class="live-preview">
                     
                        <div class="row seperatesec white-inner">
							<div class="sectitle">
                                <label for="labelInput" class="form-label blue-ht">Registration Details</label>
                            </div>
							
							<div class="table-responsive">
								<table class="table table-bordered table-striped align-middle " width="50%" id="datatable_">
									<thead style="vertical-align: middle;">
										<tr>
											<th>Company Name:</th><td>{{$data->company_name}}</td>											 											 
											<th>Address:</th><td>{{$data->address}}<br>City: {{getDistrictID($data->ref_district_id)->district_name}}<br>State: {{get_state_name($data->ref_state_id)}}<br>Pincode: {{$data->pincode}}</td>											 											 
										</tr>
										<tr>											 
											<th>Contact Person</th><td>{{$data->producer_name}}</td>												 
											<th>Contact Details</th><td>Telephone: {{$data->phone}} <br>Mobile: {{$data->mobile}} </td>												 
										</tr>
									</thead>									

								</table>
							</div>                            
						</div>
					<div class="row seperatesec white-inner">
							<div class="card-header">
								<h5 class="card-title mb-0" style="float: left">Unit Details</h5>
								<button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addUnitModalgrid" style="float: right">Add Unit</button>
							 
							</div>
							 
							<div class="table-responsive">
								<table class="table table-bordered table-striped align-middle dataTable no-footer" width="100%" id="datatable">
									<thead>
											<tr>
												<th>
													Unit Registration No.
												</th>
												<th>
													Unit Name
												</th>
												<th>
													Product Details
												</th>
												 
												<th>
													Action
												</th>
											</tr>
											
										</thead>
										<tbody>
											@forelse($data->getUnitRegDetails as $value)
											<tr>
												<td>{{$value->unit_reg_number}}</td>
												<td>{{$value->unit_name}}</td>
												<td>
													<table class="table table-bordered table-striped align-middle dataTable" width="100%">
														<thead>
															<tr>
																<th>Product Name</th>												 
																<th>Action</th>
															</tr>
														</thead>
														<tbody>
														@forelse($value->getProductsDetails as $productValue)
															<tr>
																<td>{{$productValue->product_name}}</td>
																<td>
																	<a href="{{route('superadmin.addIngredients',$productValue->id)}}">View Ingredient</a> |
																	<a href="{{route('superadmin.addBatch',$productValue->id)}}">View Batch</a> | 																	 
																	<a href="javascript:void(0);" class="deletedata" data-value="{{$productValue->id}}" data-href="{{route('superadmin.deleteProduct',$productValue->id)}}">Remove</a>
																</td>
															</tr>
															@empty
														<tr>
															<td colspan="2">No records found..</td>
														</tr>	
														@endforelse
														</tbody>
													</table>
												</td>
												
												 
												<td>
													<a href="javascript:void(0);" class="deletedata" data-value="{{$value->id}}" data-href="{{route('superadmin.deleteUnit',$value->id)}}">Remove Unit</a> |
													<a href="{{route('superadmin.addProduct',[$value->id,'renew'])}}">Add Products</a>
												</td>
											</tr>
											@empty
											<tr>
												<td colspan="4">No records found..</td>
											</tr>	
											@endforelse
										</tbody>

								</table>
							</div>
						 
						
							<div class="card-header text-center">
								 <a class="btn btn-primary" href="{{route('superadmin.applicationGenerateRenewalCertificate',$data->id)}}" >Proceed to Generate Renewal Certificate</a>
							</div>
						</div>
						<!-- END seperatesec ROW -->
						 
						 
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@push('script')
 
 <!-- Grids in modals -->

<div class="modal fade" id="addUnitModalgrid" tabindex="-1" aria-labelledby="addUnitModalgridLabel" aria-modal="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addUnitModalgridLabel">Add Unit</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
			<div class="alert alert-danger" style="display:none"></div>
                <form name="addUnitFrm" id="addUnitFrm" method="POST">
				 @csrf 
					<input type="hidden" name="at_input_approval_reg_details_id" value="{{$data->id}}" />
                    <div class="row g-3">
						<div class="col-xxl-6 col-md-6">
							<div>
								<label class="form-label">Unit Name: <span class="required">*</span></label>
								<input type="text" class="form-control" name="unit_name" id="unit_name"  value="" required>

							</div>
						</div>
                             
                            
						<div class="col-xxl-6 col-md-6">
							<div>
								<label class="form-label">License No.: <span class="required">*</span></label>
								<input type="text" class="form-control" name="license_no" id="license_no"  value="" required>

							</div>
						</div>
                        <div class="col-xxl-6  col-md-6">
                            <div>
                                <label for="address" class="form-label">Address</label>
                                <textarea   class="form-control" id="address" name="address" ></textarea>
                            </div>
                        </div><!--end col-->
                        <div class="col-xxl-6  col-md-6">
                            <div>
                                <label for="lastName" class="form-label">Installed Capacity (MT/Day)</label>
                                <input type="number" class="form-control" id="installed_capacity" name="installed_capacity" >
                            </div>
                        </div><!--end col-->
                        <div class="col-lg-12">
                            <label for="genderInput" class="form-label">Additional Certificate</label>
                            <div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" name="additional_certification[]" id="inlineRadio1" value="1">
                                    <label class="form-check-label" for="inlineRadio1">ISO 22000</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" name="additional_certification[]" id="inlineRadio2" value="2">
                                    <label class="form-check-label" for="inlineRadio2">ISO 9000</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" name="additional_certification[]" id="inlineRadio3" value="3">
                                    <label class="form-check-label" for="inlineRadio3">HACCP</label>
                                </div>
								<div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" name="additional_certification[]" id="inlineRadio3" value="4">
                                    <label class="form-check-label" for="inlineRadio3">Other</label>
                                </div>
                            </div>
                        </div><!--end col-->
                        <div class="col-xxl-6 col-md-6">
                            <div>
                                <label for="estimated_production_in_mt" class="form-label">Estimated Production (in M.T.)</label>
                                <input type="number" class="form-control" id="estimated_production_in_mt" name="estimated_production_in_mt" >
                            </div>
                        </div><!--end col-->
                        <div class="col-xxl-6 col-md-6">
                            <div>
                                <label for="license_validity_upto" class="form-label">License Validity</label>
                                <input type="date" class="form-control" id="license_validity_upto" name="license_validity_upto" value="">
                            </div>
                        </div><!--end col-->
						<div class="col-xxl-3 col-md-6">
								<div>
									<label for="labelInput" class="form-label">State <span	class="required">*</span></label>										 
									 <select class="form-select state" name="ref_state_id"	id="state"  required>
										<option value="">-Select State-</option>
										@forelse(getAllState() as $state)
											<option value="{{ $state->id }}">{{ $state->state_name }}</option>
										@empty
										@endforelse
									</select>
								</div>
							</div>
							<div class="col-xxl-3 col-md-6">
								<div>
									<label for="labelInput" class="form-label">District <span
											class="required">*</span></label>											 
									<select class="form-select district" name="ref_district_id" id="district"  required>
										<option value="">Select District</option>
										
									</select>
								</div>
							</div>
							<div class="col-xxl-3 col-md-6">
								<div>
									<label for="labelInput" class="form-label">Taluka/Mandal
										<span class="required">*</span></label>
									 
									<select class="form-select block_tehsil" name="ref_block_tehsil_id" id="block_tehsil"  required>
										<option value="">Select Taluka/Mandal</option>
										
									</select>
								</div>
							</div>
						<div class="col-xxl-3 col-md-6 gy-3">
								<div>
									<label for="labelInput" class="form-label">Pin Code<span
											class="required">*</span></label>
									<input type="text" class="form-control numbersonly"
										id="placeholderInput"  name="pincode"
										value=""  required 
										maxlength="6" />
								</div>
							</div>
                        <div class="col-lg-12">
                            <div class="hstack gap-2 justify-content-end">
                                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                                <button type="button" id="formSubmit" class="btn btn-primary">Submit</button>
                            </div>
                        </div><!--end col-->
                    </div><!--end row-->
                </form>
            </div>
        </div>
    </div>
</div>

<script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
<script type="text/javascript">

$(document).on('click','#formSubmit',function(e){
	e.preventDefault();
	$.ajaxSetup({
		headers: {
			'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
		}
	});
	$.ajax({
		url: "{{route('superadmin.storeApplicationUnit')}}",
		method: 'post',
		data: $('#addUnitFrm').serialize(),
		success: function(result){
			if(result.errors)
			{
				$('.alert-danger').html('');

				$.each(result.errors, function(key, value){
					$('.alert-danger').show();
					$('.alert-danger').append('<li>'+value+'</li>');
				});
			}
			else
			{	 
				$('.alert-danger').hide();
				alert(result.success);
				$('#addUnitModalgrid').modal('hide');
				location.reload(true);
				 
			}
		}
	});
});


$(document).on('click', '.deletedata', function() {
	 var id=$(this).attr('data-value');
Swal.fire({
  title: 'Are you sure?',
  text: "You won't be able to revert this!",
  icon: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Yes, delete it!'
}).then((result) => {
  if (result.value) {
	   $.ajax({
        url: $(this).attr('data-href'),
        method: "DELETE",
        dataType: 'json',
        data: {
            'id': id,
        },
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        success: function(result) {
            table_schedule.draw();
				Swal.fire(
				'Deleted!',
				'Record Deleted Successfully..',
				'success'
				)

        }
    });

  }
})

});




</script>
 
@endpush
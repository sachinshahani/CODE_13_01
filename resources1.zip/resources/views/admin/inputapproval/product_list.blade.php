@extends('admin.layouts.app')
@section('content')
<div class="row">
	<div class="col-12">
		<div class="page-title-box d-sm-flex align-items-center justify-content-between">
			<h4 class="mb-sm-0">List of Products Registered</h4>
			<div class="page-title-right">
			 	<ol class="breadcrumb m-0">
              <li class="breadcrumb-item"><a href="{{route('superadmin.dashboard')}}">Dashboard</a></li>
              <li class="breadcrumb-item active">Input Approval</li>
            </ol>
			</div>
		</div>
	</div>
</div>
<div class="clearfix"></div>

<div class="col-md-12 mt-2">
	@if (session('success'))
	<div class="alert alert-success" id="validate">
		{{ session('success') }}
	</div>
	@endif
	@if (session('importErrors'))
	<div class="alert alert-danger">
		<p>Following Errors Occured While Uploading the list, Please fix and upload again</p>
		<ul>
			@foreach(session('importErrors') as $failure)

			@foreach($failure->errors() as $f)
			<li>{{ $f .' at row '.$failure->row() }}</li>
			@endforeach

			@endforeach
		</ul>
	</div>
	@endif
</div>

<div class="row">
	<div class="col-lg-12">
		<div class="card">
			<div class="card-header">
				<h5 class="card-title mb-0" style="float: left">List of Products Registered</h5>

				

			</div>
			<div class="card-body">
			<div class="table-responsive">
				<table class="table table-bordered table-striped align-middle dataTable no-footer" width="100%" id="datatable">
                    <thead>
                            <tr>
                                <th width="10">
                                    sr.no
                                </th>
								<th>Unit Name</td>
								<th>Unit Reg. No</td>
                                <th>
                                    Product Category Name
                                </th>
                                <th>
                                    Product Sub-Category Name
                                </th>
								<th>
                                    Brand Name
                                </th>
								 
                                <th>
                                    Action
                                </th>

                            </tr>
                        </thead>

                </table>
			</div>
			</div>
		</div>
	</div>
	<!--end col-->
</div>
<!--end row-->
@endsection

@push('script')

<script type="text/javascript">
// DataTables Core and Extensions
 var table_schedule =  $('#datatable').DataTable({
        processing: true,
        serverSide: true,
       // autoWidth: true,
       // responsive: true,
		"order": [
				[1, "asc"]
			],
        ajax: '#',
        columns: [
            {data: 'DT_RowIndex', name: 'DT_RowIndex'},
			{data: 'unit_name', name: 'unit_name'},
			{data: 'unit_reg_no', name: 'unit_reg_no'},			 
			{data: 'category_name', name: 'category_name'},
			{data: 'sub_category_name', name: 'sub_category_name'},
			{data: 'brand_name', name: 'brand_name'},			            
			{data: 'action', name: 'action', orderable: true, searchable: true}
        ]
    });
$(document).on('click', '.deletedata', function() {
	 var id=$(this).attr('data-value');
Swal.fire({
  title: 'Are you sure?',
  text: "You won't be able to revert this!",
  icon: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Yes, delete it!'
}).then((result) => {
  if (result.value) {
	   $.ajax({
        url: $(this).attr('data-href'),
        method: "DELETE",
        dataType: 'json',
        data: {
            'id': id,
        },
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        success: function(result) {
            table_schedule.draw();
				Swal.fire(
				'Deleted!',
				'Record Deleted Successfully..',
				'success'
				)

        }
    });

  }
})

});
</script>
@endpush


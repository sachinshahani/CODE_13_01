@extends('admin.layouts.app')
@section('content')
<!-----farmer detail ----->
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0" style="float: left">
                    Farmer Data
                </h5>
            </div>
            <div class="card-body table-responsive">
                <table id="activity" class="table table-bordered table-striped align-middle" style="width:100%">
                    <thead>
                        <tr>
                            <th>S.No:</th>
                            <th>Registration No:</th>
                            <th>Registration Date:</th>
                            <th>Farmer Name:</th>
                            <th>Email:</th>
                            <th>Gender:</th>
                            <th>State:</th>
                            <th>District</th>
                            <th>Taluka/Mandal:</th>
                            <th>Village:</th>
                            
                        </tr>
                    </thead>
                    <tbody>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!--end col-->
</div>
<!-----farmer detail end----->


<!-----farm detail----->
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0" style="float: left">
                    Farm Data
                </h5>



            </div>
            <div class="card-body table-responsive">
                <table id="activity" class="table table-bordered table-striped align-middle" style="width:100%">
                    <thead>
                        <tr>
                            <th>S.No:</th>
                            <th>Registration No:</th>
                            <th>Farm Name:</th>
                            <th>Owner Farmer ID:</th>
                            <th>Total Area:</th>
                            <th>Area In Ha :</th>
                            <th>Farm Processing:</th>
                            <th>Survay No:</th>
                            <th>Organic Status:</th>
                            <th>Completed Three Years Pgs:</th>
                            
                        </tr>
                    </thead>
                    <tbody>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!--end col-->
</div>

<!-----farm detail end----->







@endsection
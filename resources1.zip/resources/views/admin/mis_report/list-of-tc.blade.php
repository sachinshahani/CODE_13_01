@extends('admin.layouts.app')

@section('content')
<style>
    .customtextarea {
        height: 80px;
    }
</style> <!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">List of TC Issued

            </h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="{{route('superadmin.dashboard')}}">Dashboard</a></li>
              <li class="breadcrumb-item active">MIS report</li>
                </ol>
            </div>
        </div>
    </div>
</div>
<div>

    <div class="row white-inner">


        <div class="col-xxl-2 col-md-4 gy-3">
            <div>
                <label class="form-label">TC type: <span class="required"></span></label>
                <select class="form-select state" name="export" id="export" required>
                    <option value="">--Select--</option>
                    <option value="All">All</option>
                    <option value="Domestic">Domestic</option>
                    <option value="Export">Export</option>


                </select>
            </div>
        </div>
        <div class="col-xxl-2 col-md-4 gy-3">
            <div>
                <label class="form-label">Operator Type: <span class="required"></span></label>
                <select class="form-select state" name="operatorType" id="operatorType" required>
                    <option value="">Select </option>
                    <option value="2">Grower Group</option>
                    <option value="3">INDIVIDUAL PRODUCER</option>
                    <option value="4">WILD</option>
                    <option value="5">TRADER</option>
                    <option value="6">PROCESSOR</option>

                </select>

            </div>
        </div>

        

        <!-- <div class="col-xxl-2 col-md-4 gy-3">
            <div>
                <label class="form-label">Operator Registration No.<span class="required"></span></label>
                <input type="text" class="form-control" id="registration_no" name="registration_no" value="">
            </div>
        </div>

        <div class="col-xxl-2 col-md-4 gy-3">
            <div>
                <label class="form-label">Product: <span class="required"></span></label>
                <input type="text" class="form-control" id="product" name="product" value="">
            </div>
        </div> -->


        <div class="col-xxl-2 col-md-4 gy-3">
            <div>
                <label class="form-label">From Date: <span class="required"></span></label>
                <input type="date" class="form-control" id="from_date" name="from_date" value="">
            </div>
        </div>


        <div class="col-xxl-2 col-md-4 gy-3">
            <div>
                <label class="form-label">To Date: <span class="required"></span></label>
                <input type="date" class="form-control" id="to_date" name="to_date" value="">
            </div>
        </div>
        <!-- <div class="col-xxl-2 col-md-4 gy-3">
            <div>
                <label class="form-label">Month: <span class="required"></span></label>
                <select class="form-select state" name="export" id="export" required>
                    <option value="">--Select--</option>
                    <option value="1">Jan</option>
                    <option value="2">Feb</option>
                    <option value="3">March</option>
                    <option value="4">April</option>
                    <option value="5">May</option>
                    <option value="6">June</option>
                    <option value="7">July</option>
                    <option value="8">August</option>
                    <option value="9">September</option>
                    <option value="10">October</option>
                    <option value="11">November</option>
                    <option value="12">December</option>


                </select>
            </div>
        </div>

        <div class="col-xxl-2 col-md-4 gy-3">
            <div>
                <label class="form-label">Year: <span class="required"></span></label>
                <select class="form-select state" name="export" id="export" required>
                    <option value="">--Select--</option>
                    <option value="1">2020</option>
                    <option value="2">2021</option>
                    <option value="3">2022</option>


                </select>
            </div>
        </div> -->


        <div class="col-xxl-1 col-md-4 gy-2">
            <div class="text-center">
                <button type="submit" id="searchBtn" class="btn btn-primary" style="margin: 36px;">Search</button>
            </div>
        </div>
    </div>


</div>

<div class="row">

    <div class="col-lg-12">
        <div class="card">

            <div class="card-body table-responsive">
                <p>List of TC</p>
                <table id="searchResultsTable" class="table table-bordered table-striped align-middle dataTable" style="width:100%">
                    <thead>
                        <tr>
                            <th>S.No.</th>
                            <th>Transaction Certificate No..</th>
                            <th>TC Issue date</th>
                            <th>Buyer Name</th>
                            <th>Seller Name</th>
                            <th>Country Name</th>
                            <th>Seller Scope No.</th>
                            <th>Total Quantity (in MT)</th>
                            <th>Value (in Rs.)</th>

                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td colspan="9">No Record found.</td>

                        </tr>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!--end col-->
</div>

<script>
    $(document).ready(function () {
        
        $('#searchBtn').click(function (e) {
            // alert($('#from_date').val());
            //return false;
            e.preventDefault();
            $.ajax({
                url: '{{ route("listOfTcSearch") }}',
                method: 'POST',
                data: {

                    from_date: $('#from_date').val(),
                    to_date: $('#to_date').val(),
                    operatorType: $('#operatorType').val(),
                    registration_no: $('#registration_no').val(),
                    export: $('#export').val(),

                },
                success: function (response) {
                    console.log(response);
                    console.log(response.data.length);
                    //return false;
                    $('#searchResultsTable tbody').empty();
                    if (response.msg == 'success') {

                        var tbody = '';
                        for (var i = 0, j = 1; i < response.data.length; i++) {

                            tbody += '<tr><td>' + j++ + '</td><td>' + response.data[i]['tc_no'] + '</td><td>' + response.data[i]['date_of_tc'] + '</td><td>' + response.data[i]['buyer_name'] + '</td><td>' + response.data[i]['seller_name'] + '</td><td>' + response.data[i]['country_name'] + '</td><td>' + response.data[i]['seller_no'] + '</td><td>' + response.data[i]['total_qunt'] + '</td><td>' + response.data[i]['value'] + '</td></tr>';
                        }
                        $('#searchResultsTable tbody').append(tbody);
                    }
                    if (response.msg == 'error') {
                        $('#searchResultsTable tbody').append('<tr><td colspan="9">No Data found.</td></tr>');
                    }

                },
                error: function (xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        });
    });
</script>




@endsection
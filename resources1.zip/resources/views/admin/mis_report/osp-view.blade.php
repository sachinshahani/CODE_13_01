@extends('admin.layouts.app')

@section('content')

<style>
    .customtextarea {
        height: 80px;
    }
</style> <!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">
               OSP DETAILS FOR:
            </h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">List of OSP</li>
                </ol>
            </div>
        </div>
    </div>
</div>
<div>

<div>
      
            <div class="row white-inner">
                
               
                <div class="col-xxl-2 col-md-4 gy-3">
                    <div>
                        <label class="form-label">Select Year<span class="required"></span></label>

                        <select class="form-select state" name="state" id="state" >
                            <option value="">--Select--</option>
                            
                            <option value="">2021</option>
                            <option value="">2022</option>
                            <option value="">2023</option>
                            
                           
                            
                           

                        </select>
                    </div>
                </div>
            
             
                <div class="col-xxl-1 col-md-4 gy-2">
                        <div class="text-center">
                            <button type="submit" id="searchBtn" class="btn btn-primary" style="margin: 36px;">Search</button>
                        </div>
                </div>

                


            </div>
            
     
    </div>
    <div class="row">

        <div class="col-lg-12">
            <div class="card">

                <div class="card-body table-responsive">
                    <p>List of Register Farmer:</p>
                    <table id="searchResultsTable" class="table table-bordered table-striped align-middle dataTable" style="width:100%">
                        <thead>
                            <tr>

                                <th>S.No</th>
                                <th>Source Organic Planting</th>
                                <th>Inputs used in Production</th>
                                <th>Contamination Control(Buffer Zone)</th>
                                <th>Pest & Weed Management (Input Used)</th>
                                <th>Nutrient Management(Input Used)</th>
                                <th>Choice of Crops</th>
                                <th>Area Coverd by Crop(In Ha)</th>
                                <th>Date Of Creation</th>
                                
                              

                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td colspan="9">No Record found.</td>

                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!--end col-->
    </div>




























@endsection
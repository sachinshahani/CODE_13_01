@extends('admin.layouts.app')
@section('content')
<!-----farmer detail ----->
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0" style="float: left">
                    Farmer Data
                </h5>
            </div>
            <div class="card-body table-responsive">
                <table id="activity" class="table table-bordered table-striped align-middle" style="width:100%">
                    <thead>
                        <tr>
                            <th>S.No:</th>
                            <th>Registration No:</th>
                            <th>Registration Date:</th>
                            <th>Farmer Name:</th>
                            <th>Email:</th>
                            <th>Gender:</th>
                            <th>State:</th>
                            <th>District</th>
                           
                            <th>Village:</th>

                        </tr>
                    </thead>
                    <tbody>
                    @foreach($data as $index => $farmer)
                        <tr>
                            <td>{{ $index + 1 }}</td>
                            <td>{{ $farmer->registration_no }}</td>
                            <td>{{$farmer->created_at}}</td>
                            <td>{{ $farmer->farmer_first_name }}</td>
                            <td>{{$farmer->email_id}}</td>
                            <td>{{$farmer->gender}}</td>
                            <td>{{get_state_name($farmer->ref_state_id)}}</td>
                            <td>{{get_district_name_by_id($farmer->ref_district_id)}}</td>
                           
                            <td>{{get_village_name_by_id($farmer->ref_village_id)}}</td>


                        </tr>
                    </tbody>
                    @endforeach
                </table>
               
				{{$data->links("pagination::bootstrap-4")}}
            </div>
        </div>
    </div>
    <!--end col-->
</div>
<!-----farmer detail end----->


<!-----farm detail----->
<!-- <div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0" style="float: left">
                    Farm Data
                </h5>



            </div>
            <div class="card-body table-responsive">
                <table id="activity" class="table table-bordered table-striped align-middle" style="width:100%">
                    <thead>
                        <tr>
                            <th>S.No:</th>
                            <th>Registration No:</th>
                            <th>Farm Name:</th>
                            <th>Owner Farmer ID:</th>
                            <th>Total Area:</th>
                            <th>Area In Ha :</th>
                            <th>Farm Processing:</th>
                            <th>Survay No:</th>
                            <th>Organic Status:</th>
                            <th>Completed Three Years Pgs:</th>

                        </tr>
                    </thead>
                    <tbody>
                    @foreach($farms as $index => $farm)
                        <tr>
                            <td>{{ $index + 1 }}</td>
                            <td>{{$farm->registration_no}}</td>
                            <td>{{$farm->farm_name}}</td>
                            <td>{{$farm->owner_farmerid}}</td>
                            <td>{{$farm->total_area}}</td>
                            <td>{{$farm->area_in_ha}}</td>
                            <td>{{$farm->farm_processing}}</td>
                            <td>{{$farm->survay_no}}</td>
                            <td>{{$farm->ref_organic_status_master_id}}</td>
                            <td>{{$farm->completed_three_years_pgs}}</td>


                        </tr>

                    </tbody>
                    @endforeach
                </table>
              
				{{$farms->links("pagination::bootstrap-4")}}
            </div>
        </div>
    </div>
 
</div> -->

<!-----farm detail end----->







@endsection
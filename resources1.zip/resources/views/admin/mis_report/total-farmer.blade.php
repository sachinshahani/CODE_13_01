@extends('admin.layouts.app')

@section('content')
<style>
    .customtextarea {
        height: 80px;
    }
</style> <!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Total Farmers (Active)
            </h4>

            <div class="page-title-right">
               	<ol class="breadcrumb m-0">
              <li class="breadcrumb-item"><a href="{{route('superadmin.dashboard')}}">Dashboard</a></li>
              <li class="breadcrumb-item active">MIS report</li>
            </ol>
            </div>
        </div>
    </div>
</div>

<div>

    <div class="row white-inner">


        <div class="col-xxl-2 col-md-4 gy-3">
            <div>
                <label class="form-label">State<span class="required"></span></label>

                <select class="form-select state" name="state" id="state">
                    <option value="">--Select--</option>
                    @forelse(getAllState() as $state)
                    <option value="{{$state->id}}" @selected(old('state')==$state->id) >{{$state->state_name}}</option>
                    @empty
                    @endforelse



                </select>
            </div>
        </div>
      
        <div class="col-xxl-1 col-md-4 gy-2">
            <div class="text-center">
                <button type="submit" id="searchBtn" class="btn btn-primary" style="margin: 36px;">Search</button>
            </div>
        </div>




    </div>


</div>
<div class="row">

    <div class="col-lg-12">
        <div class="card">

            <div class="card-body table-responsive">
                <p>State Wise Total Farmers:</p>
                <table id="searchResultsTable" class="table table-bordered table-striped align-middle dataTable"
                    style="width:100%">
                    <thead>
                        <tr>

                            <!-- <th>S.No</th> -->
                               <th>State</th> 
                            <th>No of grower group</th>
                            <th>No of farmers in grower group</th>
                            <th>No of individual producers</th>
                            <th>No of farmers in individual</th>
                            <th>Total Farmers:</th>



                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <!-- <td>1</td> -->
                            <td id='state'></td>
                            <td id='ics'></td>
                            <td id='ipp'></td>
                            <td id='ics_count'></td>
                            <td id='ip_count'></td>
                            <td id='tot_count'></td>

                        </tr>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!--end col-->
</div>

<script>
    $(document).ready(function () {
        $('#searchBtn').click(function (e) {
            // alert($('#from_date').val());
            //return false;
            e.preventDefault();
            $.ajax({
                url: '{{route("totalFarmerSearch")}}',
                method: 'POST',
                data: {
                    state: $('#state').val(),
                },
                success: function (response) {
                    // console.log(response.state.);
                    $('#state').html(response.state);
                    $('#ics').html(response.gg);
                    $('#ipp').html(response.ipp);
                    $('#ics_count').html(response.ics);
                    $('#ip_count').html(response.ip);
                    $('#tot_count').html(response.total_count);
                   // console.log(response.data.length);
                    //return false;
                    // $('#searchResultsTable tbody').empty();
                    // if(response.msg=='success'){

                    //     var tbody = '';
                    //     for(var i = 0,j=1; i < response.data.length; i++) {

                    //          tbody += '<tr><td>' + j++ + '</td><td>' + response.data[i]['no_far_of_ics'] + '</td><td>' + response.data[i]['no_far_of_indi_prod']+'</td><td>' +response.data[i]['tot_far'] + '</td></tr>';
                    //     }
                    //     $('#searchResultsTable tbody').append(tbody);
                    // } 
                    // if(response.msg=='error'){
                    //     $('#searchResultsTable tbody').append('<tr><td colspan="4">No Data found.</td></tr>');
                    // }

                },
                error: function (xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        });
    });
</script>
@endsection
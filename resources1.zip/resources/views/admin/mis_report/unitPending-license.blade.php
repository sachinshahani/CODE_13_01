@extends('admin.layouts.app')

@section('content')
<style> .customtextarea { height: 80px; } </style> <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Processing Unit
                                Pending for License Renewal
                            
                </h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                         <li class="breadcrumb-item"><a href="{{route('superadmin.dashboard')}}">Dashboard</a></li>
              <li class="breadcrumb-item active">MIS report</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div>
        
            <div class="row white-inner">
                <div class="col-xxl-2 col-md-4 gy-3">
                    <div>
                        <label class="form-label">Registration No:<span class="required"></span></label>
                        <input type="text" class="form-control" id="registration_no" name="registration_no" value="">
                       

                    </div>
                </div>
                
                
                <div class="col-xxl-1 col-md-4 gy-2">
                    <div class="text-center">
                        <button type="submit" id="searchBtn" class="btn btn-primary"
                            style="margin: 36px;">Search</button>
                    </div>
                </div>

                


            </div>
            
      
    </div>
    <div class="row">

        <div class="col-lg-12">
            <div class="card">

                <div class="card-body table-responsive">
                    <p>No.of Scope Issed:</p>
                    <table id="searchResultsTable" class="table table-bordered table-striped align-middle dataTable" style="width:100%">
                        <thead>
                            <tr>
                                <th>S.No.</th>
                                <th>Registration No.</th>
                                <th>Unit Name</th>
                                <th>Licence Number</th>
                                <th>Licence Authority</th>
                                <th>Validity Start Date</th>
                                <th>Validity End Date</th>
                                <th>Installed Capacity(MT/Day)</th>
                                <th>Contact Details</th>
                                <th>No.of Day(s)</th>

                            </tr>
                        </thead>
                        <tbody>
                        <tr>
                                <td colspan="10">No Record found.</td>

                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!--end col-->
    </div>
    <script>
    $(document).ready(function() {
        $('#searchBtn').click(function(e) {
           // alert($('#from_date').val());
            //return false;
            e.preventDefault();
            $.ajax({
                url: '{{route("unitPendingForLicenseRenewalSearch")}}',
                method: 'POST',
                data: {

                    registration_no: $('#registration_no').val(),
                   
               
                },
                success: function(response) {
                         console.log(response);
                         console.log(response.data.length);
                         //return false;
                        $('#searchResultsTable tbody').empty();
                        if(response.msg=='success'){
                         
                            var tbody = '';
                            for(var i = 0,j=1; i < response.data.length; i++) {
                     
                                tbody += '<tr><td>' + j++ + '</td><td>' + response.data[i]['reg_no'] + '</td><td>'  + response.data[i]['unit_name']+'</td><td>'+response.data[i]['lice_no'] +'</td><td>' +response.data[i]['lice_auth'] +'</td><td>'  +response.data[i]['start_date'] +'</td><td>' +response.data[i]['end_date'] +'</td><td>'  + response.data[i]['install_cap']  + '</td><td>' + response.data[i]['contact_detail'] + '</td><td>' + response.data[i]['no_of_day'] +'</td></tr>';
                            }
                            $('#searchResultsTable tbody').append(tbody);
                        }
                        if(response.msg=='error'){
                            $('#searchResultsTable tbody').append('<tr><td colspan="10">No Data found.</td></tr>');
                        }
                       
                    },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        });
    });
</script>

    @endsection
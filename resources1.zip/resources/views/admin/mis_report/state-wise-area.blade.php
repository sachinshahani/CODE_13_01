@extends('admin.layouts.app')

@section('content')
<style> .customtextarea { height: 80px; } </style> <!-- start page title --> <div class="row"> <div class="col-12"> <div
    class="page-title-box d-sm-flex align-items-center justify-content-between"> <h4 class="mb-sm-0">State Wise Area
    </h4>

    <div class="page-title-right">
        <ol class="breadcrumb m-0">
          <li class="breadcrumb-item"><a href="{{route('superadmin.dashboard')}}">Dashboard</a></li>
              <li class="breadcrumb-item active">MIS report</li>
        </ol>
    </div>
    </div>
    </div>
    </div>
    
    <div>
      
            <div class="row white-inner">
                
                <div class="col-xxl-2 col-md-4 gy-3">
                    <div>
                        <label class="form-label">State<span class="required"></span></label>
                        <select class="form-select state" name="state" id="state" required>
                            <option value="">--Select--</option>
                            @forelse(getAllState() as $state)
                                                    <option value="{{$state->id}}" @selected(old('state')==$state->
                                                        id) >{{$state->state_name}}</option>
                                                    @empty
                                                    @endforelse
                            
                           

                        </select>
                    </div>
                </div>
             
                <div class="col-xxl-2 col-md-4 gy-3">
                    <div>
                        <label class="form-label">Operator Type: <span class="required"></span></label>
                        <select class="form-select state" name="operatorType" id="operatorType" required>
                        <option value="">--Select--</option>
                            <option value="2">Grower Group</option>
                            <option value="3">INDIVIDUAL PRODUCER</option>
                            <option value="4">WILD</option>
                            {{-- <option value="5">TRADER</option>
                            <option value="6">PROCESSOR</option> --}}

                        </select>
                    </div>
                </div>

               
        
                
                <div class="col-xxl-1 col-md-4 gy-2">
                    <div class="text-center">
                        <button type="submit" id="searchBtn" class="btn btn-primary"
                            style="margin: 36px;">Search</button>
                    </div>
                </div>

                


            </div>
            
       
    </div>

    <div>
        <div class="row">

            <div class="col-lg-12">
                <div class="card">

                    <div class="card-body table-responsive">
                        <p>List of State Wise Area</p>
                        <table id="searchResultsTable" class="table table-bordered table-striped align-middle dataTable" style="width:100%">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>State</th>
                                    <th>Organic Area(Ha)</th>
                                    <th>In Conversion Area(Ha)</th>


                                </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td colspan="4">No Record found.</td>

                            </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!--end col-->
        </div>

        <script>
    $(document).ready(function() {
        $('#searchBtn').click(function(e) {
           // alert($('#from_date').val());
            //return false;
            e.preventDefault();
            $.ajax({
                url: '{{route("stateWiseAreaSearch")}}',
                method: 'POST',
                data: {
                    state: $('#state').val(),
                    operatorType: $('#operatorType').val(),
               
                },
                success: function(response) {
                         console.log(response);
                         console.log(response.data.length);
                         //return false;
                        $('#searchResultsTable tbody').empty();
                        if(response.msg=='success'){
                         
                            var tbody = '';
                            for(var i = 0,j=1; i < response.data.length; i++) {
                     
                                 tbody += '<tr><td>' + j++ + '</td><td>' + response.data[i]['state'] + '</td><td>' + response.data[i]['org_area']+'</td><td>'+response.data[i]['conver_area'] + '</td></tr>';
                            }
                            $('#searchResultsTable tbody').append(tbody);
                        }
                        if(response.msg=='error'){
                            $('#searchResultsTable tbody').append('<tr><td colspan="4">No Data found.</td></tr>');
                        }
                       
                    },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        });
    });
</script>

        @endsection
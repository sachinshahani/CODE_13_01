@extends('admin.layouts.app')

@section('content')
<style> .customtextarea { height: 80px; } </style> <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">List of PTC Issued						

                </h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                         <li class="breadcrumb-item"><a href="{{route('superadmin.dashboard')}}">Dashboard</a></li>
              <li class="breadcrumb-item active">MIS report</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div>
       
            <div class="row white-inner">
                <div class="col-xxl-2 col-md-4 gy-3">
                    <div>
                        <label class="form-label">Operator Type: <span class="required"></span></label>
                        <select class="form-select state" name="ref_state_id" id="change_dive" required>
                        <option value="">--Select--</option>
                            <option value="open">All</option>
                            <option value="6">PROCESSOR</option>
                            <option value="5">TRADER</option>

                        </select>

                    </div>
                </div>
               
                
                <!-- <div class="col-xxl-2 col-md-4 gy-3">
                    <div>
                        <label class="form-label">Registration No: <span class="required"></span></label>
                        <input type="text" class="form-control" id="" name="" value="">
                    </div>
                </div> -->

            
                <div class="col-xxl-2 col-md-4 gy-3">
                    <div>
                        <label class="form-label">From Date: <span class="required"></span></label>
                        <input type="date" class="form-control" id="" name="" value="">
                    </div>
                </div>

              
                <div class="col-xxl-2 col-md-4 gy-3">
                    <div>
                        <label class="form-label">To Date: <span class="required"></span></label>
                        <input type="date" class="form-control" id="" name="" value="">
                    </div>
                </div>

                

                <div class="col-xxl-1 col-md-4 gy-2">
                    
                        <div class="text-center">
                            <button type="submit" id="searchBtn" class="btn btn-primary" style="margin: 36px;">Search</button>
                        </div>


                </div>

                


            </div>
            
       
    </div>

    <div class="row">

        <div class="col-lg-12">
            <div class="card">

                <div class="card-body table-responsive">
                    <p>PTC List:</p>
                    <table id="searchResultsTable" class="table table-bordered table-striped align-middle dataTable" style="width:100%">
                        <thead>
                            <tr>
                                <th>S.No.</th>
                                <th>PTC No.</th>
                                <th>Date of PTC</th>
                                <th>Buyer Name</th>
                                <th>Seller Name</th>
                                <th>Country Name</th>
                                <th>Seller Scope No.</th>
                                <th>Total Quantity (in MT)</th>
                                <th>Value (in Rs.)</th>

                            </tr>
                        </thead>
                        <tbody>
                            
                            <tr>
                                <td colspan="9">No Record found.</td>

                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!--end col-->
    </div>




    <script>
    $(document).ready(function () {
        
        $('#searchBtn').click(function (e) {
            // alert($('#from_date').val());
            //return false;
            e.preventDefault();
            $.ajax({
                url: '{{ route("listOfPtcSearch") }}',
                method: 'POST',
                data: {

                    from_date: $('#from_date').val(),
                    to_date: $('#to_date').val(),
                    operatorType: $('#operatorType').val(),
                    registration_no: $('#registration_no').val(),
                    export: $('#export').val(),

                },
                success: function (response) {
                    console.log(response);
                    console.log(response.data.length);
                    //return false;
                    $('#searchResultsTable tbody').empty();
                    if (response.msg == 'success') {

                        var tbody = '';
                        for (var i = 0, j = 1; i < response.data.length; i++) {

                            tbody += '<tr><td>' + j++ + '</td><td>' + response.data[i]['tc_no'] + '</td><td>' + response.data[i]['date_of_tc'] + '</td><td>' + response.data[i]['buyer_name'] + '</td><td>' + response.data[i]['seller_name'] + '</td><td>' + response.data[i]['country_name'] + '</td><td>' + response.data[i]['seller_no'] + '</td><td>' + response.data[i]['total_qunt'] + '</td><td>' + response.data[i]['value'] + '</td></tr>';
                        }
                        $('#searchResultsTable tbody').append(tbody);
                    }
                    if (response.msg == 'error') {
                        $('#searchResultsTable tbody').append('<tr><td colspan="9">No Data found.</td></tr>');
                    }

                },
                error: function (xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        });
    });
</script>
@endsection




@extends('admin.layouts.app')

@section('content')
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">
            Operator List
                    </li>
            </h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <!-- <li class="breadcrumb-item"><a href="javascript: void(0);"> User Management</a></li> -->
                    <li class="breadcrumb-item active">Operator List
                    </li>
                </ol>
            </div>
        </div>
    </div>
</div>
<div class="clearfix"></div>

<div class="col-md-12 mt-2">
    @if (session('success'))
    <div class="alert alert-success" id="validate">
        {{ session('success') }}
    </div>
    @endif

    @if (session('importErrors'))
    <div class="alert alert-danger">
        <p>Following Errors Occured While Uploading the list, Please fix and upload again</p>
        <ul>
            @foreach (session('importErrors') as $failure)
            @foreach ($failure->errors() as $f)
            <li>{{ $f . ' at row ' . $failure->row() }}</li>
            @endforeach
            @endforeach
        </ul>
    </div>
    @endif
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0" style="float: left">

   
                Operator List

                </h5>

                <div class="row justify-content-end mb-2">
                    <!-- <div class="col-md-3 text-right">
                        <select class="form-select" name="operator_status" id="search" data-label-msg="Status" required>
                            <option value="0">Select status</option>
                            <option value="0">All</option>
                            <option value="1">Suspend</option>
                            <option value="2">Terminate</option>
                        </select>
                    </div> -->
                    {{-- <div class="col-1">
                            <button class="btn btn-primary" type="button" id="filter"> Submit </button>
                        </div> --}}

                </div>

            </div>
            <div class="card-body table-responsive">
                <table id="activity" class="table table-bordered table-striped align-middle" style="width:100%">
                    <thead>
                        <tr>
                            <th>S.No:</th>
                            <th>Registration No:</th>
                            <th>Operator Type:</th>
                            <th>Operator Name:</th>
                            <th>Farmer</th>
                            <th>Registration Date</th>
                            <!-- <th>Action</th> -->
                        </tr>
                    </thead>
                    <tbody>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!--end col-->
</div>
<!--end row-->

@endsection



@push('script')
<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

var table = $('#activity').DataTable({
    dom: 'Bfrtip',
    lengthMenu: [
        [10, 25, 50, -1],
        [10, 25, 50, "All"]
    ],
    processing: true,
    serverSide: true,
    ajax: {
        url: '{{ route("superadmin.ActivityHistory") }}', 
        type: 'GET',
        data: function(d) {
            d._token = "{{ csrf_token() }}";
            d.operator_status = $("#search").val(); // Send operator_status parameter
        }
    },
    columns: [
        { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: true },
        { data: 'reg_no', name: 'reg_no', orderable: true },
        { data: 'ref_operator_type_id', name: 'ref_operator_type_id', orderable: true },
        { data: 'name', name: 'name', orderable: true },
        { data: 'farmer', name: 'farmer', orderable: true },
        { data: 'created_on', name: 'created_on', orderable: true },
        // { data: 'action', name: 'name', orderable: false },
    ],
    buttons: [
        'excelHtml5',
        {
            extend: 'csvHtml5',
            title: function() {
                return "REPORTS";
            },
            titleAttr: 'CSV REPORTS'
        },
        {
            extend: 'pdfHtml5',
            title: function() {
                return "PDF REPORTS";
            },
            orientation: 'landscape',
            pageSize: 'A4',
            titleAttr: 'PDF REPORTS'
        }
    ]
});

</script>
@endpush
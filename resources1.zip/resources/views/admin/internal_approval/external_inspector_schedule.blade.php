@extends('admin.layouts.app')
@section('content')
    <style>
        .has-error {
            border: 1px solid red;
        }

        .errormsg {
            color: red;
            font-size: 14px !important;
        }
    </style>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Schedule for External Inspection</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Schedule for External Inspection</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>

    <form action="{{route('superadmin.schedulestore')}}" method="POST" class="row">
        @csrf
       
        <input type="text" class="form-control" name="id" value="{{$userId}}">

        <div class="col-md-6 mb-3">
            <label for="inspector_name" class="form-label">Inspector Name</label>
            <select name="inspector_name" id="inspector_name" class="form-control">
                <option value="">Select Inspector</option>
                <!-- Options go here -->
                @forelse($user as $user)
                <option value="{{ $user->first_name }}"
                    @if (isset($user->firt_name) && $user->firt_name == $user->id) selected @endif>
                    {{ $user->first_name }}</option>
            @empty
            @endforelse
            </select>
        </div>

        <div class="col-md-6 mb-3">
            <label for="inspector_name" class="form-label">Operator</label>
            <select name="operator_type" id="operator_type" class="form-control">
                <option value="">Select Operator</option>
                <!-- Options go here -->
                @forelse($operator as $operator)
                <option value="{{ $operator->operator_type }}"
                    @if (isset($operator->operator_type) && $operator->operator_type == $operator->id) selected @endif>
                    {{ $operator->operator_type }}</option>
            @empty
            @endforelse
            </select>
        </div>
    
        <div class="col-md-6 mb-3">
            <label for="inspection_date" class="form-label">From Date</label>
            <input type="date" class="form-control" name="from_date" required>
        </div>
    
        <div class="col-md-6 mb-3">
            <label for="inspection_time" class="form-label">To Date</label>
            <input type="date" class="form-control" name="to_date" required>
        </div>
    
        <div class="col-md-6 mb-3">
            <label for="comments" class="form-label">Comments/Notes</label>
            <textarea class="form-control" name="comments" rows="3" placeholder="Optional"></textarea>
        </div>
    
        <div class="col-12 text-center">
            <button type="submit" class="btn btn-primary">Schedule Inspector</button>
        </div>
    </form>
    
@endsection

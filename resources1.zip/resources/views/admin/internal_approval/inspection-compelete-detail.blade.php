@extends('admin.layouts.app')

@section('content')
    <style>
        .view-details {
            margin-top: 15px;
            border: 1px solid lightgrey;
            padding: 5px 15px;
            border-radius: 0.25rem
        }

        .view-details td {
            padding: 10px 0
        }

        .view-details td:nth-child(1),
        .view-details td:nth-child(3) {
            width: 35%;
            padding-right: 15px
        }

        .table-width td:nth-child(1) {
            width: 46%;
            padding-right: 15px
        }

        .view-details td:nth-child(3) {
            padding-left: 15px
        }

        .view-details table {
            width: 100%
        }

        .sectitle .borderbottom {
            display: block;
            background: #30956b;
            width: 50px;
            height: 4px
        }

        .repeat-sec {
            border: 1px solid lightgrey;
            padding: 15px 15px;
            border-radius: 0.25rem;
            margin: 15px
        }

        .repeat-sec:nth-child(odd) {
            background: #f5f5f5
        }

        .repeat-sec:nth-child(even) {
            background: #fcfcfc
        }

        .odd-bd {
            background: #78cd721f
        }

        .even-bd {
            background: #f8664c1a
        }
    </style>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Farmer Inspection Detail</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Farmer Inspection Detail</li>
                    </ol>
                </div>

            </div>

            <a href="{{route('superadmin.generatePdf',$fid)}}" class="btn btn-primary mb-2" target="_blank">Download PDF</a>
        </div>
    </div>
    <!-- end page title -->
    <div class="row">
        <div class="col-lg-6">
            {{-- first part  --}}
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1">
                                Farmer Registration Details

                            </h4>
                        </div>
                        <!-- end card header -->
                        <div class="card-body">
                            <div class="live-preview">

                                <div class="row seperatesec">
                                    <div class="col-xxl-12 col-md-12">
                                        <div class="sectitle">
                                            <label for="labelInput" class="form-label">Farmer Details</label>
                                            <div class="borderbottom"></div>
                                        </div>
                                        <div class="sectitle">
                                            <label for="labelInput" class="form-label">Farmer Photo :
                                                @if (isset($regDetail->farmerPhoto) && !empty($regDetail->farmerPhoto))
                                                    <a target="_BLANK"
                                                        href="{{ asset('public/farmers/' . $regDetail->farmerPhoto) }}"
                                                        class="text-decoration-underline">See Doc</a>
                                                @else
                                                    N/A
                                                @endif
                                            </label>
                                        </div>
                                        <div class="table-responsive view-details mb-4">
                                            <table>
                                                <tbody>
                                                    <tr>
                                                        <td><b>Registration No :</b></td>
                                                        <td>{{ $regDetail->registration_no ?? 'N/A' }}</td>
                                                        <td><b>Registration Date :</b></td>
                                                        <td>{{ \Carbon\Carbon::parse($regDetail->registration_date)->format('d-m-Y') ?? '' }}
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>First Name :</b></td>
                                                        <td>{{ $regDetail->farmer_first_name ?? '' }}</td>
                                                        <td><b>Middle Name :</b></td>
                                                        <td>{{ $regDetail->farmer_middle_name ?? '' }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Last Name :</b></td>
                                                        <td>{{ $regDetail->farmer_last_name ?? '' }}</td>
                                                        <td><b>Email ID :</b></td>
                                                        <td>{{ $regDetail->email_id ?? '' }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Gender :</b></td>
                                                        <td>{{ $regDetail->email_id == 'M' ? 'Male' : ($regDetail->email_id == 'F' ? 'Female' : '') }}</td>

                                                        <td><b>PAN Card :</b></td>
                                                        <td>
                                                            @if (isset($regDetail->farmerDocs->pan_card_image_path) && !empty($regDetail->farmerDocs->pan_card_image_path))
                                                                <a target="_BLANK"
                                                                    href="{{ asset('public/farmers/' . $regDetail->farmerDocs->pan_card_image_path) }}"
                                                                    class="text-decoration-underline">See Doc</a>
                                                            @else
                                                                'N/A'
                                                            @endif
                                                        </td>
                                                        {{-- <td><b>Father Husband Flag :</b></td>
                                                    <td>{{ $regDetail->father_husband_flag??'' }}</td> --}}
                                                    </tr>
                                                    {{-- <tr>
                                                    <td><b>Father/Husband First Name :</b></td>
                                                    <td>{{ $regDetail->father_husband_first_name??'' }}</td>
                                                    <td><b>Father/Husband Middle Name :</b></td>
                                                    <td>{{ $regDetail->father_husband_first_name??'' }}</td>
                                                </tr> --}}
                                                    <tr>
                                                        {{-- <td><b>Father/Husband Last Name :</b></td>
                                                    <td>zbbzbz</td> --}}

                                                    </tr>
                                                    <tr>
                                                        <td><b>Aadhaar Card :</b></td>
                                                        <td>
                                                            @if (isset($regDetail->farmerDocs->aadhar_card_image_path) && !empty($regDetail->farmerDocs->aadhar_card_image_path))
                                                                <a target="_BLANK"
                                                                    href="{{ asset('public/farmers/' . $regDetail->farmerDocs->aadhar_card_image_path) }}"
                                                                    class="text-decoration-underline">See Doc</a>
                                                            @else
                                                                'N/A'
                                                            @endif
                                                        </td>
                                                        <td><b>Mobile Number :</b></td>
                                                        <td>{{ $regDetail->mobile_no ?? '' }}</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="col-xxl-6 col-md-6">
                                        <div class="sectitle">
                                            <label for="labelInput" class="form-label">Address</label>
                                            <div class="borderbottom"></div>
                                        </div>
                                        <div class="table-responsive view-details  mb-4">
                                            <table>
                                                <tbody>
                                                    <tr>
                                                        <td><b>State :</b></td>
                                                        <td>{{ get_state_name($regDetail->ref_state_id) ?? '' }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>District :</b></td>
                                                        <td>{{ get_district_name_by_id($regDetail->ref_district_id) ?? '' }}
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Taluka/Mandal :</b></td>
                                                        <td>{{ getBlockTehsilByID($regDetail->ref_block_tehsil_id) ?? '' }}
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Village :</b></td>
                                                        <td>{{ get_village_name_by_id($regDetail->ref_village_id) ?? '' }}
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Pin Code :</b></td>
                                                        <td>{{ $regDetail->pin ?? '' }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Landmark :</b></td>
                                                        <td>{{ $regDetail->landmark ?? '' }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Address :</b></td>
                                                        <td>{{ $regDetail->farmer_address ?? '' }}</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="col-xxl-6 col-md-6">
                                        <div class="sectitle">
                                            <label for="labelInput" class="form-label">Bank Details</label>
                                            <div class="borderbottom"></div>
                                        </div>
                                        <div class="table-responsive view-details  mb-4">
                                            <table>
                                                <tbody>
                                                    <tr>
                                                        <td><b>Bank Name :</b></td>
                                                        <td>{{ $regDetail->farmerBankDetail->bank_name ?? '' }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Account Number :</b></td>
                                                        <td>{{ $regDetail->farmerBankDetail->account_number ?? '' }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>IFSC Code :</b></td>
                                                        <td>{{ $regDetail->farmerBankDetail->branch_name ?? '' }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Branch Name :</b></td>
                                                        <td>{{ $regDetail->farmerBankDetail->branch_name ?? '' }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Address :</b></td>
                                                        <td>{{ $regDetail->farmerBankDetail->bank_address ?? '' }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Pin Code :</b></td>
                                                        <td>{{ $regDetail->farmerBankDetail->pincode ?? '' }}</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    @if (isset($regDetail->farmerLandDetail) && $regDetail->farmerLandDetail->count() > 0)
                                        @forelse ($regDetail->farmerLandDetail as $key=> $farmdetail)
                                            <div class="col-xxl-12 col-md-12">
                                                <div class="repeat-sec">
                                                    <div class="row">
                                                        <div class="col-xxl-6 col-md-6">
                                                            <div class="sectitle">
                                                                <label for="labelInput" class="form-label">Farm Details
                                                                    {{ $key + 1 }}</label>
                                                                <div class="borderbottom"></div>
                                                            </div>
                                                            <div class="table-responsive view-details  mb-4">
                                                                <table>
                                                                    <tbody>
                                                                        <tr>
                                                                            <td><b>Registration No :</b></td>
                                                                            <td>{{ $farmdetail->registration_no ?? 'N/A' }}
                                                                            </td>

                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Owner Farmer ID :</b></td>
                                                                            <td>{{ $farmdetail->owner_farmerid ?? '' }}
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Farmer Name :</b></td>
                                                                            <td>{{ $farmdetail->farm_name ?? '' }}</td>
                                                                        </tr>
                                                                        {{-- <tr>

                                                                        <td><b>Landmark :</b></td>
                                                                        <td>0</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Pin :</b></td>
                                                                            <td>0</td>
                                                                        </tr>
                                                                        <tr>
                                                                        <td><b>Farm No :</b></td>
                                                                        <td>0</td>
                                                                        </tr> --}}
                                                                        <tr>
                                                                            <td><b>Area(in Ha):</b></td>
                                                                            <td>{{ $farmdetail->area_in_ha ?? '' }}</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Total Area (in Ha):</b></td>
                                                                            <td>{{ $farmdetail->total_area ?? '' }}</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Survey No :</b></td>
                                                                            <td>{{ $farmdetail->survay_no ?? '' }}</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Farm Processing :</b></td>
                                                                            <td>{{ $farmdetail->farm_processing ?? '' }}
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Completed Three Years PGS
                                                                                    :</b></td>
                                                                            <td>{{ $farmdetail->completed_three_years_pgs == 'Y' ? 'Yes' : 'No' }}
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>PGS Certificate :</b></td>
                                                                            <td>{{ $farmdetail->pgs_certificate ?? '' }}
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Organic Status :</b></td>
                                                                            <td>{{ getRefOrganicStatusMasterByID($farmdetail->ref_organic_status_master_id) }}
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                        <div class="col-xxl-6 col-md-6">
                                                            <div class="sectitle">
                                                                <label for="labelInput" class="form-label">Address</label>
                                                                <div class="borderbottom"></div>
                                                            </div>
                                                            <div class="table-responsive view-details table-width  mb-4">
                                                                <table>
                                                                    <tbody>
                                                                        <tr>
                                                                            <td><b>State :</b></td>
                                                                            <td>{{ get_state_name($farmdetail->ref_state_id) }}
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>District :</b></td>
                                                                            <td>{{ get_district_name_by_id($farmdetail->ref_district_id) }}
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Taluka/Mandal :</b></td>
                                                                            <td>{{ getBlockTehsilByID($farmdetail->ref_block_tehsil_id) }}
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Village :</b></td>
                                                                            <td>{{ get_village_name_by_id($farmdetail->ref_village_id) }}
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Pin Code :</b></td>
                                                                            <td>{{ $farmdetail->pin ?? '' }}</td>
                                                                        </tr>

                                                                        <tr>
                                                                            <td><b>Address :</b></td>
                                                                            <td>{{ $regDetail->farmer_address ?? '' }}</td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                        <div class="col-xxl-12 col-md-12">
                                                            <div class="repeat-sec">
                                                                <div class="row">
                                                                    <div class="col-xxl-12 col-md-12">

                                                                        <div class="sectitle">
                                                                            <label for="labelInput"
                                                                                class="form-label">Farmer
                                                                                Standing Crop Details : </label>
                                                                            <div class="borderbottom"></div>
                                                                        </div>
                                                                        @forelse (farmerStandingCorpDetail(['at_farmer_details_id'=>$regDetail->id,'at_farm_details_id'=>$farmdetail->id]) as  $key=>  $farmstandetail)
                                                                            <div
                                                                                class="table-responsive view-details mb-4 {{ $key % 2 == 0 ? 'odd-bd' : 'even-bd' }}">
                                                                                <table>
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td><b>HS code :</b>
                                                                                            </td>
                                                                                            <td>{{ getRefHscodeByID($farmstandetail->ref_hscode_id) ?? '' }}
                                                                                            </td>
                                                                                            <td><b>Season:</b>
                                                                                            </td>
                                                                                            <td>{{ $farmstandetail->season_name ?? '' }}
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><b>Crop Area(in Ha):</b>
                                                                                            </td>
                                                                                            <td>{{ $farmstandetail->crop_area ?? '' }}
                                                                                            </td>
                                                                                            <td><b>Organic Status
                                                                                                    :</b></td>
                                                                                            <td>{{ getRefOrganicStatusMasterByID($farmstandetail->organic_status) }}
                                                                                            </td>
                                                                                        </tr>

                                                                                    </tbody>
                                                                                </table>
                                                                                <br>
                                                                                <div class="col-xxl-12 col-md-12">

                                                                                    <div class="row">
                                                                                        <div class="col-xxl-12 col-md-12">

                                                                                            <div class="sectitle">
                                                                                                <label for="labelInput"
                                                                                                    class="form-label">Geo
                                                                                                    Tagging Details :
                                                                                                </label>
                                                                                                <div class="borderbottom">
                                                                                                </div>
                                                                                            </div>
                                                                                            <div
                                                                                                class="table-responsive  mb-4">
                                                                                                <table>
                                                                                                    <tbody>
                                                                                                        <tr>
                                                                                                            <td><b>Latitude
                                                                                                                    :</b>
                                                                                                            </td>
                                                                                                            <td>
                                                                                                                @forelse(getTaggingDetail(['at_farmer_reg_details_id'=>$regDetail->id]) as $geotagDet)
                                                                                                                    {{ $geotagDet->latitude ?? '' }}

                                                                                                                @empty
                                                                                                                @endforelse
                                                                                                            </td>
                                                                                                            <td><b>Longitude
                                                                                                                    :</b>
                                                                                                            </td>
                                                                                                            <td>
                                                                                                                @forelse(getTaggingDetail(['at_farmer_reg_details_id'=>$regDetail->id]) as $geotagDet)
                                                                                                                    {{ $geotagDet->longitude ?? '' }}

                                                                                                                @empty
                                                                                                                @endforelse
                                                                                                            </td>
                                                                                                        </tr>


                                                                                                    </tbody>
                                                                                                </table>
                                                                                            </div>

                                                                                        </div>
                                                                                    </div>

                                                                                </div>
                                                                            </div>
                                                                        @empty
                                                                        @endforelse

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-xxl-12 col-md-12">
                                                            <div class="repeat-sec">
                                                                <div class="row">
                                                                    <div class="col-xxl-12 col-md-12">

                                                                        <div class="sectitle">
                                                                            <label for="labelInput"
                                                                                class="form-label">Farmer
                                                                                Proposed Crop Details:</label>
                                                                            <div class="borderbottom"></div>
                                                                        </div>
                                                                        @forelse (farmerProposedCorpDetail(['at_farmer_details_id'=>$regDetail->id,'at_farm_details_id'=>$farmdetail->id]) as $key=> $farmprodetail)
                                                                            <div
                                                                                class="table-responsive view-details mb-4 {{ $key % 2 == 0 ? 'odd-bd' : 'even-bd' }}">
                                                                                <table>
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td><b>HS code :</b>
                                                                                            </td>
                                                                                            <td>{{ getRefHscodeByID($farmprodetail->ref_hscode_id) ?? '' }}
                                                                                            </td>
                                                                                            <td><b>Season Name :</b>
                                                                                            </td>
                                                                                            <td>{{ $farmprodetail->season_name ?? '' }}
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><b>Crop Area(in Ha) :</b>
                                                                                            </td>
                                                                                            <td>{{ $farmprodetail->crop_area ?? '' }}
                                                                                            </td>
                                                                                            <td><b>Organic Status
                                                                                                    :</b></td>
                                                                                            <td>{{ getRefOrganicStatusMasterByID($farmprodetail->organic_status) }}
                                                                                            </td>
                                                                                        </tr>

                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                        @empty
                                                                        @endforelse
                                                                        {{-- <div
                                                                            class="table-responsive view-details mb-4 even-bd">
                                                                            <table>
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <td><b>HS code :</b>
                                                                                        </td>
                                                                                        <td>test</td>
                                                                                        <td><b>Season Name :</b>
                                                                                        </td>
                                                                                        <td>Kharif</td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td><b>Crop Area :</b>
                                                                                        </td>
                                                                                        <td>258</td>
                                                                                        <td><b>Organic Status
                                                                                                :</b></td>
                                                                                        <td>1st Year Convirsion
                                                                                        </td>
                                                                                    </tr>

                                                                                </tbody>
                                                                            </table>
                                                                        </div> --}}
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>



                                        @empty
                                        @endforelse
                                    @endif
                                </div>
                                <div class="col-xxl-12 col-md-12">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label">Farmer Docs : </label>
                                        <div class="borderbottom"></div>
                                    </div>
                                    <div class="table-responsive view-details mb-4">
                                        <table>
                                            <tbody>
                                                <tr>
                                                    <td><b>Land Image:</b></td>
                                                    <td>
                                                        @if (isset($regDetail->farmerDocs->land_documents_image_path) &&
                                                                !empty($regDetail->farmerDocs->land_documents_image_path))
                                                            <a target="_BLANK"
                                                                href="{{ asset('public/farmers/' . $regDetail->farmerDocs->land_documents_image_path) }}"
                                                                class="text-decoration-underline">See Doc</a>
                                                        @else
                                                            N/A
                                                        @endif

                                                    </td>
                                                    <td><b>Passbook Image :</b></td>
                                                    <td>
                                                        @if (isset($regDetail->farmerDocs->passbook_image_path) && !empty($regDetail->farmerDocs->passbook_image_path))
                                                            <a target="_BLANK"
                                                                href="{{ asset('public/farmers/' . $regDetail->farmerDocs->land_documents_image_path) }}"
                                                                class="text-decoration-underline">See Doc</a>
                                                        @else
                                                            N/A
                                                        @endif
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><b>Contact Person Sign Image :</b></td>
                                                    <td>
                                                        @if (isset($regDetail->farmerDocs->contact_person_sign_image_path) &&
                                                                !empty($regDetail->farmerDocs->contact_person_sign_image_path))
                                                            <a target="_BLANK"
                                                                href="{{ asset('public/farmers/' . $regDetail->farmerDocs->contact_person_sign_image_path) }}"
                                                                class="text-decoration-underline">See Doc</a>
                                                        @else
                                                            N/A
                                                        @endif
                                                    </td>
                                                    <td><b>Live Signature Image :</b></td>
                                                    <td>
                                                        @if (isset($regDetail->farmerDocs->live_signature_image_path) &&
                                                                !empty($regDetail->farmerDocs->live_signature_image_path))
                                                            <a target="_BLANK"
                                                                href="{{ asset('public/farmers/' . $regDetail->farmerDocs->live_signature_image_path) }}"
                                                                class="text-decoration-underline">See Doc</a>
                                                        @else
                                                            N/A
                                                        @endif
                                                    </td>
                                                </tr>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="col-xxl-12 col-md-12">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label">Farmer OSP Details : </label>
                                        <div class="borderbottom"></div>
                                    </div>
                                    <div class="table-responsive view-details mb-4">
                                        <table>
                                            <tbody>
                                                <tr>
                                                    <td><b>Organic System Plan:</b></td>
                                                    <td>{{ $regDetail->farmerOSPDetail->source_of_organic_system_plan ?? 'N/A' }}
                                                    </td>
                                                    <td><b>Cropping Pattern :</b></td>
                                                    <td>{{ $regDetail->farmerOSPDetail->cropping_pattern ?? 'N/A' }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><b>Main Crop :</b></td>
                                                    <td>{{ $regDetail->farmerOSPDetail->covered_area_main_corp ?? 'N/A' }}
                                                    </td>
                                                    <td><b>Inter Crop :</b></td>
                                                    <td>{{ $regDetail->farmerOSPDetail->covered_area_inter_corp ?? 'N/A' }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><b>Off Farm :</b></td>
                                                    <td>{{ $regDetail->farmerOSPDetail->off_farm ?? 'N/A' }}</td>
                                                    <td><b>On Farm:</b></td>
                                                    <td>{{ $regDetail->farmerOSPDetail->on_farm ?? 'N/A' }}</td>
                                                </tr>
                                                <tr>
                                                    <td><b>Contamination Control :</b></td>
                                                    <td>{{ $regDetail->farmerOSPDetail->contamination_control ?? 'N/A' }}
                                                    </td>
                                                    <td><b>Pest Weed Management :</b></td>
                                                    <td>{{ $regDetail->farmerOSPDetail->pease_weed_management ?? 'N/A' }}
                                                    </td>


                                                </tr>
                                                <tr>
                                                    <td><b>Nutrient Management :</b></td>
                                                    <td>{{ $regDetail->farmerOSPDetail->nutrient_management ?? 'N/A' }}

                                                    </td>

                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        {{-- second part  --}}
        <div class="col-lg-6">

            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1">
                                Farmer Inspection Details

                            </h4>
                        </div>
                        <!-- end card header -->
                        <div class="card-body">
                            <div class="live-preview">

                                <div class="row seperatesec">
                                    <div class="col-xxl-12 col-md-12">
                                        <div class="sectitle">
                                            <label for="labelInput" class="form-label">Farmer Details</label>
                                            <div class="borderbottom"></div>
                                        </div>
                                        <div class="sectitle">
                                            <label for="labelInput" class="form-label">Farmer Photo :
                                                @if (isset($regDetail->farmerPhoto) && !empty($regDetail->farmerPhoto))
                                                    <a target="_BLANK"
                                                        href="{{ asset('public/farmers/' . $regDetail->farmerPhoto) }}"
                                                        class="text-decoration-underline">See Doc</a>
                                                @else
                                                    N/A
                                                @endif
                                            </label>
                                        </div>
                                        <div class="table-responsive view-details mb-4">
                                            <table>
                                                <tbody>
                                                    <tr>
                                                        <td><b>Registration No :</b></td>
                                                        <td>{{ $regDetail->registration_no ?? 'N/A' }}</td>
                                                        <td><b>Registration Date :</b></td>
                                                        <td>{{ \Carbon\Carbon::parse($regDetail->registration_date)->format('d-m-Y') ?? '' }}
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>First Name :</b></td>
                                                        <td>{{ $regDetail->farmer_first_name ?? '' }}</td>
                                                        <td><b>Farmer Middle Name :</b></td>
                                                        <td>{{ $regDetail->farmer_middle_name ?? '' }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Last Name :</b></td>
                                                        <td>{{ $regDetail->farmer_last_name ?? '' }}</td>
                                                        <td><b>Email ID :</b></td>
                                                        <td>{{ $regDetail->email_id ?? '' }}</td>

                                                   
                                                    </tr>
                                                    <tr>
                                                        <td><b>Gender :</b></td>
                                                        <td>{{ $regDetail->gender == 'M' ? 'Male' : ($regDetail->gender == 'F' ? 'Female' : '') }}</td>    

                                                        <td><b>PAN Card :</b></td>
                                                        <td>
                                                            @if (isset($regDetail->farmerDocs->pan_card_image_path) && !empty($regDetail->farmerDocs->pan_card_image_path))
                                                                <a target="_BLANK"
                                                                    href="{{ asset('public/farmers/' . $regDetail->farmerDocs->pan_card_image_path) }}"
                                                                    class="text-decoration-underline">See Doc</a>
                                                            @else
                                                                'N/A'
                                                            @endif
                                                        </td>
                                                        {{-- <td><b>Father Husband Flag :</b></td>
                                                    <td>{{ $regDetail->father_husband_flag??'' }}</td> --}}
                                                    </tr>
                                                    {{-- <tr>
                                                    <td><b>Father/Husband First Name :</b></td>
                                                    <td>{{ $regDetail->father_husband_first_name??'' }}</td>
                                                    <td><b>Father/Husband Middle Name :</b></td>
                                                    <td>{{ $regDetail->father_husband_first_name??'' }}</td>
                                                </tr> --}}
                                                    <tr>
                                                        {{-- <td><b>Father/Husband Last Name :</b></td>
                                                    <td>zbbzbz</td> --}}

                                                    </tr>
                                                    <tr>
                                                        <td><b>Aadhaar Card :</b></td>
                                                        <td>
                                                            @if (isset($regDetail->farmerDocs->aadhar_card_image_path) && !empty($regDetail->farmerDocs->aadhar_card_image_path))
                                                                <a target="_BLANK"
                                                                    href="{{ asset('public/farmers/' . $regDetail->farmerDocs->aadhar_card_image_path) }}"
                                                                    class="text-decoration-underline">See Doc</a>
                                                            @else
                                                                'N/A'
                                                            @endif
                                                        </td>
                                                        <td><b>Mobile Number :</b></td>
                                                        <td>{{ $regDetail->mobile_no ?? '' }}</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="col-xxl-12 col-md-12">
                                        <div class="sectitle">
                                            <label for="labelInput" class="form-label">Address</label>
                                            <div class="borderbottom"></div>
                                        </div>
                                        <div class="table-responsive view-details  mb-4">
                                            <table>
                                                <tbody>
                                                    <tr>
                                                        <td><b>State :</b></td>
                                                        <td>{{ get_state_name($regDetail->ref_state_id) ?? '' }}</td>
                                                        <td><b>District :</b></td>
                                                        <td>{{ get_district_name_by_id($regDetail->ref_district_id) ?? '' }}
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td><b>Taluka/Mandal :</b></td>
                                                        <td>{{ getBlockTehsilByID($regDetail->ref_block_tehsil_id) ?? '' }}
                                                        </td>
                                                        <td><b>Village :</b></td>
                                                        <td>{{ get_village_name_by_id($regDetail->ref_village_id) ?? '' }}
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Pin Code :</b></td>
                                                        <td>{{ $regDetail->pin ?? '' }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>landmark :</b></td>
                                                        <td>{{ $regDetail->landmark ?? '' }}</td>
                                                        <td><b>Address :</b></td>
                                                        <td>{{ $regDetail->farmer_address ?? '' }}</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    {{-- <div class="col-xxl-6 col-md-6">
                                        <div class="sectitle">
                                            <label for="labelInput" class="form-label">Bank Detail</label>
                                            <div class="borderbottom"></div>
                                        </div>
                                        <div class="table-responsive view-details  mb-4">
                                            <table>
                                                <tbody>
                                                    <tr>
                                                        <td><b>Bank Name :</b></td>
                                                        <td>{{ $regDetail->farmerBankDetail->bank_name ?? '' }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Account Number :</b></td>
                                                        <td>{{ $regDetail->farmerBankDetail->account_number ?? '' }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>IFSC Code :</b></td>
                                                        <td>{{ $regDetail->farmerBankDetail->branch_name ?? '' }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Branch Name :</b></td>
                                                        <td>{{ $regDetail->farmerBankDetail->branch_name ?? '' }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Address :</b></td>
                                                        <td>{{ $regDetail->farmerBankDetail->bank_address ?? '' }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Pin Code :</b></td>
                                                        <td>{{ $regDetail->farmerBankDetail->pincode ?? '' }}</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div> --}}
                                    @if (isset($regDetail->farmerLandDetail) && $regDetail->farmerLandDetail->count() > 0)
                                        @forelse ($regDetail->farmerLandDetail as $key=> $farmdetail)
                                            <div class="col-xxl-12 col-md-12">
                                                <div class="repeat-sec">
                                                    <div class="row">
                                                        <div class="col-xxl-6 col-md-6">
                                                            <div class="sectitle">
                                                                <label for="labelInput" class="form-label">Farm Details
                                                                    {{ $key + 1 }}</label>
                                                                <div class="borderbottom"></div>
                                                            </div>
                                                            <div class="table-responsive view-details  mb-4">
                                                                <table>
                                                                    <tbody>
                                                                        <tr>
                                                                            <td><b>Registration No :</b></td>
                                                                            <td>{{ $farmdetail->registration_no ?? 'N/A' }}
                                                                            </td>

                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Owner Farmer ID :</b></td>
                                                                            <td>{{ $farmdetail->owner_farmerid ?? '' }}
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Farmer Name :</b></td>
                                                                            <td>{{ $farmdetail->farm_name ?? '' }}</td>
                                                                        </tr>
                                                                        {{-- <tr>

                                                                        <td><b>Landmark :</b></td>
                                                                        <td>0</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Pin :</b></td>
                                                                            <td>0</td>
                                                                        </tr>
                                                                        <tr>
                                                                        <td><b>Farm No :</b></td>
                                                                        <td>0</td>
                                                                        </tr> --}}
                                                                        <tr>
                                                                            <td><b>Area (In Ha) :</b></td>
                                                                            <td>{{ $farmdetail->area_in_ha ?? '' }}</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Total Area (In Ha):</b></td>
                                                                            <td>{{ $farmdetail->total_area ?? '' }}</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Survay No :</b></td>
                                                                            <td>{{ $farmdetail->survay_no ?? '' }}</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Farm Processing :</b></td>
                                                                            <td>{{ $farmdetail->farm_processing ?? '' }}
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Completed Three Years PGS
                                                                                    :</b></td>
                                                                            <td>{{ $farmdetail->completed_three_years_pgs == 'Y' ? 'Yes' : 'No' }}
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>PGS Certificate :</b></td>
                                                                            <td>{{ $farmdetail->pgs_certificate ?? '' }}
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Organic Status :</b></td>
                                                                            <td>{{ getRefOrganicStatusMasterByID($farmdetail->ref_organic_status_master_id) }}
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                        <div class="col-xxl-6 col-md-6">
                                                            <div class="sectitle">
                                                                <label for="labelInput" class="form-label">Address</label>
                                                                <div class="borderbottom"></div>
                                                            </div>
                                                            <div class="table-responsive view-details table-width  mb-4">
                                                                <table>
                                                                    <tbody>
                                                                        <tr>
                                                                            <td><b>State :</b></td>
                                                                            <td>{{ get_state_name($farmdetail->ref_state_id) }}
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>District :</b></td>
                                                                            <td>{{ get_district_name_by_id($farmdetail->ref_district_id) }}
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Taluka/Mandal :</b></td>
                                                                            <td>{{ getBlockTehsilByID($farmdetail->ref_block_tehsil_id) }}
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Village :</b></td>
                                                                            <td>{{ get_village_name_by_id($farmdetail->ref_village_id) }}
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Pin Code :</b></td>
                                                                            <td>{{ $farmdetail->pin ?? '' }}</td>
                                                                        </tr>

                                                                        <tr>
                                                                            <td><b>Address :</b></td>
                                                                            <td>{{ $regDetail->farmer_address ?? '' }}
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Date/ Time :</b></td>
                                                                            <td>{{ $farInspDetail->inspection_date ?? '' }}/
                                                                                {{ $farInspDetail->inspection_time ?? '' }}
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Location :</b></td>
                                                                            <td>{{ $farInspDetail->location_track ?? '' }}
                                                                            </td>
                                                                        </tr>

                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                        <div class="col-xxl-12 col-md-12">
                                                            <div class="repeat-sec">
                                                                <div class="row">
                                                                    <div class="col-xxl-12 col-md-12">

                                                                        <div class="sectitle">
                                                                            <label for="labelInput"
                                                                                class="form-label">Farmer
                                                                                Standing Crop Details : </label>
                                                                            <div class="borderbottom"></div>
                                                                        </div>
                                                                        @forelse (farmerStandingCorpDetail(['at_farmer_details_id'=>$regDetail->id,'at_farm_details_id'=>$farmdetail->id]) as  $key=>  $farmstandetail)
                                                                            <div
                                                                                class="table-responsive view-details mb-4 {{ $key % 2 == 0 ? 'odd-bd' : 'even-bd' }}">
                                                                                <table>
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td><b>HS code :</b>
                                                                                            </td>
                                                                                            <td>{{ getRefHscodeByID($farmstandetail->ref_hscode_id) ?? '' }}
                                                                                            </td>
                                                                                            <td><b>Season Name :</b>
                                                                                            </td>
                                                                                            <td>{{ $farInspDetail->season_name ?? '' }}
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><b>Crop Area(in Ha):</b>
                                                                                            </td>
                                                                                            <td>{{ $farmstandetail->crop_area ?? '' }}
                                                                                            </td>
                                                                                            <td><b>Organic Status
                                                                                                    :</b></td>
                                                                                            <td>{{ getRefOrganicStatusMasterByID($farmstandetail->organic_status) }}
                                                                                            </td>
                                                                                        </tr>

                                                                                    </tbody>
                                                                                </table>
                                                                                <br>
                                                                                <div class="col-xxl-12 col-md-12">

                                                                                    <div class="row">
                                                                                        <div class="col-xxl-12 col-md-12">

                                                                                            <div class="sectitle">
                                                                                                <label for="labelInput"
                                                                                                    class="form-label">Geo
                                                                                                    Tagging Details :
                                                                                                </label>
                                                                                                <div class="borderbottom">
                                                                                                </div>
                                                                                            </div>
                                                                                            <div
                                                                                                class="table-responsive  mb-4">
                                                                                                <table>
                                                                                                    <tbody>
                                                                                                        <tr>
                                                                                                            <td><b>Latitude
                                                                                                                    :</b>
                                                                                                            </td>
                                                                                                            <td>
                                                                                                                @forelse(getTaggingDetail(['at_farmer_reg_details_id'=>$regDetail->id]) as $geotagDet)
                                                                                                                    {{ $geotagDet->latitude ?? '' }}

                                                                                                                @empty
                                                                                                                @endforelse
                                                                                                            </td>
                                                                                                            <td><b>Longitude
                                                                                                                    :</b>
                                                                                                            </td>
                                                                                                            <td>
                                                                                                                @forelse(getTaggingDetail(['at_farmer_reg_details_id'=>$regDetail->id]) as $geotagDet)
                                                                                                                    {{ $geotagDet->longitude ?? '' }}

                                                                                                                @empty
                                                                                                                @endforelse
                                                                                                            </td>
                                                                                                        </tr>


                                                                                                    </tbody>
                                                                                                </table>
                                                                                            </div>

                                                                                        </div>
                                                                                    </div>

                                                                                </div>
                                                                            </div>
                                                                        @empty
                                                                        @endforelse

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-xxl-12 col-md-12">
                                                            <div class="sectitle">
                                                                <label for="labelInput" class="form-label">Farmer Docs :
                                                                </label>
                                                                <div class="borderbottom"></div>
                                                            </div>
                                                            <div class="table-responsive view-details mb-4">
                                                                <table>
                                                                    <tbody>
                                                                        <tr>
                                                                            <td><b>Land Image:</b></td>
                                                                            <td>
                                                                                @if (isset($regDetail->farmerDocs->land_documents_image_path) &&
                                                                                        !empty($regDetail->farmerDocs->land_documents_image_path))
                                                                                    <a target="_BLANK"
                                                                                        href="{{ asset('public/farmers/' . $regDetail->farmerDocs->land_documents_image_path) }}"
                                                                                        class="text-decoration-underline">See
                                                                                        Doc</a>
                                                                                @else
                                                                                    N/A
                                                                                @endif

                                                                            </td>
                                                                            <td><b>Passbook Image :</b></td>
                                                                            <td>
                                                                                @if (isset($regDetail->farmerDocs->passbook_image_path) && !empty($regDetail->farmerDocs->passbook_image_path))
                                                                                    <a target="_BLANK"
                                                                                        href="{{ asset('public/farmers/' . $regDetail->farmerDocs->land_documents_image_path) }}"
                                                                                        class="text-decoration-underline">See
                                                                                        Doc</a>
                                                                                @else
                                                                                    N/A
                                                                                @endif
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Contact Person Sign Image :</b></td>
                                                                            <td>
                                                                                @if (isset($regDetail->farmerDocs->contact_person_sign_image_path) &&
                                                                                        !empty($regDetail->farmerDocs->contact_person_sign_image_path))
                                                                                    <a target="_BLANK"
                                                                                        href="{{ asset('public/farmers/' . $regDetail->farmerDocs->contact_person_sign_image_path) }}"
                                                                                        class="text-decoration-underline">See
                                                                                        Doc</a>
                                                                                @else
                                                                                    N/A
                                                                                @endif
                                                                            </td>
                                                                            <td><b>Live Signature Image :</b></td>
                                                                            <td>
                                                                                @if (isset($regDetail->farmerDocs->live_signature_image_path) &&
                                                                                        !empty($regDetail->farmerDocs->live_signature_image_path))
                                                                                    <a target="_BLANK"
                                                                                        href="{{ asset('public/farmers/' . $regDetail->farmerDocs->live_signature_image_path) }}"
                                                                                        class="text-decoration-underline">See
                                                                                        Doc</a>
                                                                                @else
                                                                                    N/A
                                                                                @endif
                                                                            </td>
                                                                        </tr>

                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                        <div class="col-xxl-12 col-md-12">
                                                            <div class="sectitle">
                                                                <label for="labelInput" class="form-label">Farmer OSP
                                                                    Details : </label>
                                                                <div class="borderbottom"></div>
                                                            </div>
                                                            <div class="table-responsive view-details mb-4">
                                                                <table>
                                                                    <tbody>
                                                                        <tr>
                                                                            <td><b>Organic System Plan:</b></td>
                                                                            <td>{{ $regDetail->farmerOSPDetail->source_of_organic_system_plan ?? 'N/A' }}
                                                                            </td>
                                                                            <td><b>Cropping Pattern :</b></td>
                                                                            <td>{{ $regDetail->farmerOSPDetail->cropping_pattern ?? 'N/A' }}
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Main Crop :</b></td>
                                                                            <td>{{ $regDetail->farmerOSPDetail->covered_area_main_corp ?? 'N/A' }}
                                                                            </td>
                                                                            <td><b>Inter Crop :</b></td>
                                                                            <td>{{ $regDetail->farmerOSPDetail->covered_area_inter_corp ?? 'N/A' }}
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Off Farm :</b></td>
                                                                            <td>{{ $regDetail->farmerOSPDetail->off_farm ?? 'N/A' }}
                                                                            </td>
                                                                            <td><b>On Farm:</b></td>
                                                                            <td>{{ $regDetail->farmerOSPDetail->on_farm ?? 'N/A' }}
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Contamination Control :</b></td>
                                                                            <td>{{ $regDetail->farmerOSPDetail->contamination_control ?? 'N/A' }}
                                                                            </td>
                                                                            <td><b>Pest Weed Management :</b></td>
                                                                            <td>{{ $regDetail->farmerOSPDetail->pease_weed_management ?? 'N/A' }}
                                                                            </td>


                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Nutrient Management :</b></td>
                                                                            <td>{{ $regDetail->farmerOSPDetail->nutrient_management ?? 'N/A' }}

                                                                            </td>

                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                        <div class="col-xxl-12 col-md-12">
                                                            <div class="repeat-sec">
                                                                <div class="row">
                                                                    <div class="col-xxl-12 col-md-12">

                                                                        <div class="sectitle">
                                                                            <label for="labelInput"
                                                                                class="form-label">Farmer
                                                                                Plot Details:</label>
                                                                            <div class="borderbottom"></div>
                                                                        </div>
                                                                        @forelse ($farPlotDetail as $key => $fpd)
                                                                            <div
                                                                                class="table-responsive view-details mb-4 even-bd">
                                                                                <table>
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td><b> Plot Name:</b>
                                                                                            </td>
                                                                                            <td>{{ $fpd->plot_no ?? '' }}
                                                                                            </td>
                                                                                            <td><b>Area(In Ha):</b>
                                                                                            </td>
                                                                                            <td>{{ $fpd->area ?? '' }}
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><b>Main Crop :</b>
                                                                                            </td>
                                                                                            <td>{{ $fpd->main_crop ?? '' }}
                                                                                            </td>
                                                                                            <td><b>Inter Crop:</b></td>
                                                                                            <td>{{ $fpd->inter_crop }}
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><b>Product :</b>
                                                                                            </td>
                                                                                            <td>{{ $fpd->product ?? '' }}
                                                                                            </td>
                                                                                            <td><b>Quantity:</b></td>
                                                                                            <td>{{ $fpd->quantity ?? '' }}
                                                                                            </td>
                                                                                        </tr>

                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                        @empty
                                                                        @endforelse

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-xxl-12 col-md-12">
                                                            <div class="repeat-sec">
                                                                <div class="row">
                                                                    <div class="col-xxl-12 col-md-12">

                                                                        <div class="sectitle">
                                                                            <label for="labelInput"
                                                                                class="form-label">Farmer
                                                                                Proposed Crop Details:</label>
                                                                            <div class="borderbottom"></div>
                                                                        </div>
                                                                        @forelse (farmerProposedCorpDetail(['at_farmer_details_id'=>$regDetail->id,'at_farm_details_id'=>$farmdetail->id]) as $key=> $farmprodetail)
                                                                            <div
                                                                                class="table-responsive view-details mb-4 {{ $key % 2 == 0 ? 'odd-bd' : 'even-bd' }}">
                                                                                <table>
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td><b>HS code :</b>
                                                                                            </td>
                                                                                            <td>{{ getRefHscodeByID($farmprodetail->ref_hscode_id) ?? '' }}
                                                                                            </td>
                                                                                            <td><b>Season Name :</b>
                                                                                            </td>
                                                                                            <td>{{ $farmprodetail->season_name ?? '' }}
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><b>Crop Area :</b>
                                                                                            </td>
                                                                                            <td>{{ $farmprodetail->crop_area ?? '' }}
                                                                                            </td>
                                                                                            <td><b>Organic Status
                                                                                                    :</b></td>
                                                                                            <td>{{ getRefOrganicStatusMasterByID($farmprodetail->organic_status) }}
                                                                                            </td>
                                                                                        </tr>

                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                        @empty
                                                                        @endforelse

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-xxl-12 col-md-12">

                                                        <div class="row">
                                                            <div class="col-xxl-12 col-md-12">
                                                                <div class="sectitle">
                                                                    <label for="labelInput" class="form-label">Farmer
                                                                        CheckList Details:</label>
                                                                    <div class="borderbottom"></div>
                                                                </div>
                                                                @forelse ($farCheckList as $key => $fcl)
                                                                    <div
                                                                        class="table-responsive view-details mb-4 even-bd">
                                                                        <div class="sectitle">
                                                                            <label for="labelInput" class="form-label">
                                                                                @if ($fcl->type == 1)
                                                                                    {{ 'Animal Husbandry' }}
                                                                                @elseif($fcl->type == 2)
                                                                                    {{ 'Farm Management' }}
                                                                                @elseif($fcl->type == 3)
                                                                                    {{ 'Post Harvest Measures and Processing' }}
                                                                                @elseif($fcl->type == 4)
                                                                                    {{ 'Risk Management' }}
                                                                                @endif
                                                                            </label>
                                                                            <div class="borderbottom"></div>
                                                                        </div>
                                                                        <table>
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td><b> CheckList Name:</b>
                                                                                    </td>
                                                                                    <td>{{ getCheckPointsById($fcl->ref_insepction_checklist_id) ?? '' }}
                                                                                    </td>
                                                                                    <td><b>CheckList Point :</b>
                                                                                    </td>
                                                                                    <td>{{ $fcl->check_points_flag ?? '' }}
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td><b>Remarks :</b>
                                                                                    </td>
                                                                                    <td>{{ $fcl->check_points_remarks ?? '' }}
                                                                                    </td>

                                                                                </tr>

                                                                            </tbody>
                                                                        </table>
                                                                    </div>
                                                                @empty
                                                                @endforelse

                                                            </div>
                                                        </div>

                                                    </div>

                                                    <div class="col-xxl-12 col-md-12">

                                                        <div class="row">
                                                            <div class="col-xxl-12 col-md-12">

                                                                <div class="sectitle">
                                                                    <label for="labelInput"
                                                                        class="form-label">Non-Conformity Observed
                                                                        Details:</label>
                                                                    <div class="borderbottom"></div>
                                                                </div>
                                                                @forelse ($nonConDetail as $key => $fncd)
                                                                    <div
                                                                        class="table-responsive view-details mb-4 even-bd">

                                                                        <table>
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td><b> Grade:</b>
                                                                                    </td>
                                                                                    <td>{{ $fncd->grade ?? '' }}
                                                                                    </td>
                                                                                    <td><b>Description :</b>
                                                                                    </td>
                                                                                    <td>{{ $fncd->description ?? '' }}
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td><b>Date :</b>
                                                                                    </td>
                                                                                    <td>{{ $fncd->submission_date_corrective_action ?? '' }}
                                                                                    </td>

                                                                                </tr>

                                                                            </tbody>
                                                                        </table>
                                                                    </div>
                                                                @empty
                                                                @endforelse

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-xxl-12 col-md-12">

                                                        <div class="row">
                                                            <div class="col-xxl-12 col-md-12">

                                                                <div class="sectitle">
                                                                    <label for="labelInput" class="form-label">Approval/
                                                                        Recommendation:</label>
                                                                    <div class="borderbottom"></div>
                                                                </div>

                                                                <div class="table-responsive view-details mb-4 even-bd">

                                                                    <table>
                                                                        <tbody>
                                                                            <tr>
                                                                                <td><b> Compliance with previous
                                                                                        conditions:</b>
                                                                                </td>
                                                                                <td>{{ $appInspDetail->compliance_with_previous_conditions ?? '' }}
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td><b>Compliance this Year :</b>
                                                                                </td>
                                                                                <td>{{ $appInspDetail->compliance_this_year ?? '' }}
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td><b>Comments by Internal Inspector :</b>
                                                                                </td>
                                                                                <td>{{ $appInspDetail->comments_by_internal_inspector ?? '' }}
                                                                                </td>

                                                                            </tr>
                                                                            <tr>
                                                                                <td><b>Farmer Signature :</b>
                                                                                </td>
                                                                                <td>
                                                                                    @if (isset($appInspDetail->farmer_signature) && !empty($appInspDetail->farmer_signature))
                                                                                        <a target="_BLANK"
                                                                                            href="{{ asset('public/farmers/' . $appInspDetail->farmer_signature) }}"
                                                                                            class="text-decoration-underline">See
                                                                                            Doc</a>
                                                                                    @else
                                                                                        N/A
                                                                                    @endif
                                                                                </td>

                                                                            </tr>
                                                                            <tr>
                                                                                <td><b>Inspector Signature :</b>
                                                                                </td>
                                                                                <td>
                                                                                    @if (isset($appInspDetail->inspector_signature) && !empty($appInspDetail->inspector_signature))
                                                                                        <a target="_BLANK"
                                                                                            href="{{ asset('public/farmers/' . $appInspDetail->inspector_signature) }}"
                                                                                            class="text-decoration-underline">See
                                                                                            Doc</a>
                                                                                    @else
                                                                                        N/A
                                                                                    @endif
                                                                                </td>

                                                                            </tr>

                                                                        </tbody>
                                                                    </table>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>

                                            </div>
                                        @empty
                                        @endforelse
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
@if($oper_type!='' && $oper_type==7)
    <div class="row">
        <div class="col-lg-12">

            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1">
                                Remarks:

                            </h4>
                        </div>
                        <!-- end card header -->
                        <div class="card-body">
                            <div class="live-preview">

                                <div class="row seperatesec">
                                    <form method="post" enctype="multipart/form-data" id="registration" action="{{ route('superadmin.internalApprovalPost') }}">
                                        @csrf
                                        <input type="hidden" name="fid" value="{{ $_GET['fid'] }}" >
                                        <div class="col-xxl-4 col-md-4 gy-4 ">
                                            <div>
                                                <label for="basiInput" class="form-label">Status<span
                                                        class="required">*</span>
                                                </label>

                                                <select class="form-select id_proof" name="status" required>
                                                    <option value="">-Select-</option>
                                                    <option value="approved" @selected($regDetail->approval_flag==1)>Approved
                                                    </option>
                                                    <option value="rejected" @selected($regDetail->cancellation_flag==1)>Rejected

                                                    </option>
                                                </select>

                                            </div>
                                        </div>

                                        <div class="col-xxl-6 col-md-6 gy-6">
                                            <div>
                                                <label class="form-label">Submit Your Remarks:<span class="required">
                                                        *</span></label>
                                                <textarea placeholder="Address of The Inspector" class="form-control customtextarea" name="approved_remark" required>{{ $regDetail->approved_remark??'' }}</textarea>
                                            </div>
                                        </div>
                                        @if($regDetail->cancellation_flag=='' && $regDetail->approval_flag=='')
                                        <div class="row">
                                            <div class="col-xxl-4 col-md-4 gy-4 ">
                                                <div class="hstack gap-2">

                                                    <button type="submit" id="submitbtn"
                                                        class="btn btn-primary submit-button">Submit</button>

                                                </div>
                                            </div>
                                        </div>
                                        @endif

                                    </form>

                                </div>


                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>



    </div>
    @endif
@endsection
@push('script')
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>
@endpush

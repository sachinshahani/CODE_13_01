@extends('admin.layouts.app')
@section('content')

<div class="card-body table-responsive">
    <table id="searchResultsTable" class="table table-bordered table-striped align-middle" style="width:100%">
        <thead>
            <tr>
                <th>S.No.</th>
                <th>Registration No</th>
                <th>Scope Certificate No.</th>
                <th>Scope Validity</th>
                <th>Operator Name</th>
                <th>Date Of Registration</th>
                <th>Contact Person Details</th>
                <th>Address</th>
                {{-- <th>State</th> --}}

            </tr>
        </thead>
        <tbody>

        </tbody>
    </table>
</div>

@endsection
@push('script')
        <script>
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var table = $('#searchResultsTable').DataTable({
                dom: 'Bfrtip',
                lengthMenu: [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
                processing: true,
                serverSide: true,
                ajax: {
                    url: '{{ route('superadmin.GrowerGroupSearch') }}',
                    type: 'GET',
                    data: function(d) {
                        d.state = $('#state').val();
                        d.from_date = $('#from_date').val();
                        d.to_date = $('#to_date').val();
                        d.operator = $('#operator').val();
                    },
                    error: function(xhr, error, code) {
                        console.log(xhr.responseText); // This will print the error response
                    }
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: true
                    },
                    {
                        data: 'reg_no',
                        name: 'reg_no',
                        orderable: true
                    },
                    {
                        data: 'scope_no',
                        name: 'scope_no',
                        orderable: true
                    },
                    {
                        data: 'scope_validity',
                        name: 'scope_validity',
                        orderable: true
                    },

                    {
                        data: 'operator_name',
                        name: 'operator_name',
                        orderable: true
                    },
                    {
                        data: 'reg_date',
                        name: 'reg_date',
                        orderable: true
                    },
                    {
                        data: 'contact_details',
                        name: 'contact_details',
                        orderable: true
                    },
                    // {
                    //     data: 'contact_mobile',
                    //     name: 'contact_mobile',
                    //     orderable: true
                    // },
                    {
                        data: 'address',
                        name: 'address',
                        orderable: true
                    },

                ],
                paging: false,
                buttons: [
                    'excelHtml5',
                    {
                        extend: 'csvHtml5',
                        title: function() {
                            return "REPORTS";
                        },
                        titleAttr: 'CSV REPORTS'
                    },
                    {
                        extend: 'pdfHtml5',
                        title: function() {
                            return "PDF REPORTS";
                        },
                        orientation: 'landscape',
                        pageSize: 'A4',
                        titleAttr: 'PDF REPORTS'
                    }
                ],
                language: {
                    emptyTable: "No Record found."
                }
            });

            $('#state, #from_date, #to_date, #operator').change(function() {
                table.draw();
            });
        </script>
    @endpush

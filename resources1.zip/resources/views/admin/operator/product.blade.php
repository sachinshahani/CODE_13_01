@extends('admin.layouts.app')
@section('content')

<div class="card-body table-responsive">
    <table id="searchResultsTable" class="table table-bordered table-striped align-middle" style="width:100%">
        <thead>
            <tr>
                <th>S.No.</th>
                <th>HSCODE</th>
                <th>Product Name</th>
                <th>HSCode Discription </th>
                <th>Category</th>


            </tr>
        </thead>
        <tbody>

        </tbody>
    </table>
</div>

@endsection
@push('script')
        <script>
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var table = $('#searchResultsTable').DataTable({
                dom: 'Bfrtip',
                lengthMenu: [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
                processing: true,
                serverSide: true,
                ajax: {
                    url: '{{ route('superadmin.ProductsSearch') }}',
                    type: 'GET',
                    data: function(d) {
                        d.state = $('#state').val();
                        d.from_date = $('#from_date').val();
                        d.to_date = $('#to_date').val();
                        d.operator = $('#operator').val();
                    },
                    error: function(xhr, error, code) {
                        console.log(xhr.responseText); // This will print the error response
                    }
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: true
                    },
                    {
                        data: 'hs_code',
                        name: 'hs_code',
                        orderable: true
                    },

                    {
                        data: 'product_name',
                        name: 'product_name',
                        orderable: true
                    },
                    {
                        data: 'hscode_description',
                        name: 'hscode_description',
                        orderable: true
                    },
                    {
                        data: 'ref_category_id',
                        name: 'ref_category_id',
                        orderable: true
                    },
                   

                ],
                paging: true,
                buttons: [
                    'excelHtml5',
                    {
                        extend: 'csvHtml5',
                        title: function() {
                            return "REPORTS";
                        },
                        titleAttr: 'CSV REPORTS'
                    },
                    {
                        extend: 'pdfHtml5',
                        title: function() {
                            return "PDF REPORTS";
                        },
                        orientation: 'landscape',
                        pageSize: 'A4',
                        titleAttr: 'PDF REPORTS'
                    }
                ],
                language: {
                    emptyTable: "No Record found."
                }
            });

            $('#state, #from_date, #to_date, #operator').change(function() {
                table.draw();
            });
        </script>
    @endpush

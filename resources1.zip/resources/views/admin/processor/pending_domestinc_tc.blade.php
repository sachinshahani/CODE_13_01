@extends('admin.layouts.app')
@section('content')

<style>
    .table th {
    background-color: #7fa9f5;
    color: black;
}
</style>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">List Of Transaction certificate</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">LIST OF TRANSACTION CERTIFICATE</li>
                </ol>
            </div>
        </div>
    </div>
</div>
<!-- end page title -->
<div class="row  white-inner">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <div class="sectitle">
                    <label for="labelInput" class="form-label blue-ht">Search</label>
                </div>
                <form action="" class="commonform1 " method="POST" id="commonform1" autocomplete="off">
                    @csrf
                    <div class="row">
                        <div class="col-xxl-3 col-md-6">
                            <div class="d-sm-flex align-items-center justify-content-between">
                                <span class="">
                                    <label for="">Operator Name/TC Application no.</label>                  
                                </span>
                            </div>
                        </div>
                        <div class="col-xxl-3 col-md-6">
                                <span class="form-text">
                                    <input type="text" class="form-control" id="search" name="search" required value="">
                                </span>
                        </div>
                        <div class="col-xxl-3 col-md-6">
                            <div>
                                <span class="form-text">
                                    <button type="submit" class="btn btn-primary float-left">Submit</button>
                                </span>
                                <span class="form-text">
                                    <button type="reset" class="btn btn-primary">Reset</button>
                                </span>
                            </div>
                        </div>
                    </div>
                </form><br>
                <div class="card-body table-responsive">
                    <table id="pendingTC" class="table table-bordered table-striped align-middle" style="width:100%">
                        <thead>
                            <tr>
                                <th>Sn No.</th>
                                <th>TC Application No.</th>
                                <th>Date of Application</th>
                                <th>Seller</th>
                                <th>Buyer</th>
                                <th>Country</th>
                                <th>Status</th>
                                <th>TC Type</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!--end col-->
</div>
@endsection
@push('script')
<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

var table = $('#pendingTC').DataTable({
    dom: 'Bfrtip',
    lengthMenu: [
        [10, 25, 50, -1],
        [10, 25, 50, "All"]
    ],
    processing: true,
    serverSide: true,
    ajax: {
        url: '{{ route("superadmin.domesticPendingTC") }}', 
        type: 'GET',
        data: function(d) {
            d._token = "{{ csrf_token() }}";
            d.operator_status = $("#search").val(); // Send operator_status parameter
        }
    },
    columns: [
        { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: true },
        { data: 'tc_application_no', name: 'tc_application_no', orderable: true },
        { data: 'tc_date', name: 'tc_date', orderable: true },
        { data: 'seller_scn', name: 'seller_scn', orderable: true },
        { data: 'source_from', name: 'source_from', orderable: true },
        { data: 'country', name: 'country', orderable: true },
        { data: 'nop_status', name: 'nop_status', orderable: false },
        { data: 'tc_type', name: 'tc_type', orderable: false },
        { data: 'action', name: 'name', orderable: false },
    ],
    buttons: [
        'excelHtml5',
        {
            extend: 'csvHtml5',
            title: function() {
                return "REPORTS";
            },
            titleAttr: 'CSV REPORTS'
        },
        {
            extend: 'pdfHtml5',
            title: function() {
                return "PDF REPORTS";
            },
            orientation: 'landscape',
            pageSize: 'A4',
            titleAttr: 'PDF REPORTS'
        }
    ]
});
</script>
@endpush
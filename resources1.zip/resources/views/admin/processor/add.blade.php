@extends('admin.layouts.app')
@section('content')
<!-- start page title -->
<style>
    /* Add your styling here */
     .inner-table {
      display: none;
      margin-top: -5px;
      margin-left: 40px;

    }

    .inner-table th, .inner-table td {
      padding: 10px;
      text-align: center;
      border: 1px solid #ddd;
    }

    .inner-table th {
      background-color: #7fa9f5;
      color: black;
    }
  </style>
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Apply For Domestic TC </h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Apply For Domestic TC</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <nav>
            <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">
                <a class="nav-link active" id="step0-tab" href="{{ route('superadmin.packingDetailsForDomesticTCPurchase', $batch_details->at_user_id ) }}">Add Product</a>
                <a class="nav-link" id="step2-tab" href="{{ route('superadmin.packingDetailsForDomesticTCPurchase', $batch_details->at_user_id) }}">Packing Details</a>
                <a class="nav-link " id="step3-tab" href="javascript:void(0);">TC Details</a>
            </div>
        </nav>
          <div class="tab-content py-2 custom-tab-content">
            <div class="tab-pane fade show active" id="step0">
                <div class="card">
                    <div class="card-body">
                        <div class="live-preview">
                            <div class="row seperatesec white-inner">
                               <!--  <div class="sectitle">
                                    <label for="labelInput" class="form-label blue-ht">Product Details</label>
                                </div> -->
                                <div class="sectitle">
                                    <label for="labelInput" class="form-label blue-ht">Batch Details</label>
                                </div>
                                <form id="domesticTcForm" action="{{ route('superadmin.packingDetailsForDomesticTCPurchase', $batch_details->at_user_id ) }}" method="get">
                                    @csrf
                                    <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped align-middle dataTable no-footer" width="100%" id="datatable">
                                            <thead>
                                                <tr>
                                                    <th>Select</th>
                                                    <th>Product(s)</th>
                                                    <th>Status(s)</th>
                                                    <th>Total Quantity (In MT)</th>
                                                    <th>Quantity Sourced (In MT)</th>
                                                    <th colspan="3">Available Quantity (In MT)</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                             @foreach ($product as $productData)
                                                <tr class="pro-tr">
                                                    <td><input type="checkbox" onchange="toggleTable()"></td>
                                                    <td>{{$productData->product}}</td>
                                                    <td>{{$productData->organic_status}}</td>
                                                    <td>{{$productData->quantity}}</td>
                                                    <td>{{$productData->percentage}}</td>
                                                    <td>{{$productData->quantity}}</td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <table class="inner-table">
                                                            <tr>
                                                                <th>Select Lot ID</th>
                                                                <th>Product</th>
                                                                <th>Organic Status</th>
                                                                <th>Total Quantity (In MT)</th>
                                                                <th>Use Quantity(Including this application in MT)</th>
                                                                <th>Available Quantity (In MT)</th>
                                                                <th>Quantity for this TC(in MT)</th>
                                                                <th>Add</th>
                                                                </tr>
                                                            @if( $productData->at_user_id == $batch_details->at_user_id)
                                                                <tr>
                                                                    <td><input type="checkbox" name="selectBatchID" checked="">&nbsp;&nbsp;&nbsp;&nbsp;{{$batch_details->batch_id}}</td>
                                                                    <td>{{$batch_details->product_name}}</td>
                                                                    <td>{{$productData->organic_status}}</td>
                                                                    <td>{{$batch_details->total_quantity}}</td>
                                                                    <td>{{$productData->quantity}}</td>
                                                                    <td>{{$productData->quantity}}</td>
                                                                    <td><input type="text" name="qtyFortc" value=""></td>
                                                                    <td><a href="javascript:;" class="btn btn-soft-primary" onclick="saveProduct()"><b>Add</a></td>
                                                                </tr>
                                                            @endif
                                                        </table>
                                                    </td>
                                                </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                        <!--// Start Inner table// -->

                                           <!-- // End Inner table // -->
                                    </div>
                                 </div>
                                 <div style="text-align: center;">
                                    <button type="submit" class="btn btn-primary float-right">Proceed</button>
                                    <button type="reset" class="btn btn-primary float-left" onclick="window.location='{{ route('superadmin.packingDetailsForDomesticTCPurchase', $batch_details->at_user_id) }}'; return false;">Delete</button>
                                 </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
<script>
    function toggleTable() {
      var innerTable = document.querySelector('.inner-table');
      innerTable.style.display = (innerTable.style.display === 'none' || innerTable.style.display === '') ? 'table' : 'none';
    }
  </script>
  <script>
    function saveProduct() {
        var formData = $('#domesticTcForm').serialize();
        $.ajax({
            type: 'POST',
            url: '{{ route("superadmin.storeApplyForDomesticTCPurchase") }}',
            data: formData,
            success: function (response) {
                    console.log(response);
                    // Display console data in SweetAlert
                    Swal.fire({
                        title: 'Success',
                        html: '<pre>' + JSON.stringify(response, null, 2) + '</pre>',
                        icon: 'success',
                        confirmButtonText: 'OK'
                    });
                },
                error: function (error) {
                    console.log(error);
                    // Display error in SweetAlert
                    Swal.fire({
                        title: 'Error',
                        text: 'There was an error processing your request.',
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                }
            });
        }
</script>

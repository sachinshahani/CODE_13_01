@extends('admin.layouts.app')
@section('content')
<style>
    .pdf_maindiv {
        border: 1px solid #cccccc;
        width: 100%;
        float: left;
        padding: 3%;
    }
    .pdf_heading {
        font-size: 15px;
        color: #000;
        padding: 26px 0 12px 0px;
        position: relative;
        width: 100%;
        float: left;

        /* Hide rows initially */
        .hidden{
            display: none;
        }
    }
</style>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Application for Transaction Certificate</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Application for Transaction Certificate</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">

            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                    <a class="nav-link " id="step1-tab" href="{{ route('superadmin.domestictc') }}">Add Product</a>
                    <a class="nav-link active" id="step2-tab" href="javascript:void(0);">Packing Details</a>
                    <a class="nav-link " id="step3-tab" href="javascript:void(0);">TC Details</a>

                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    {{-- <div class="card">

                        <div class="card-body"> --}}
                            {{-- <label for="labelInput" class="form-label blue-ht">Packing Detail(s) Entry</label> --}}
                            <div class="live-preview">
                                <div class="flex-shrink-0">
                                    @if (session('error'))
                                    <div class="alert alert-danger">
                                        {{ session('error') }}
                                    </div>
                                    @endif
                                    @if (session('success'))
                                    <div class="alert alert-success">
                                        {{ session('success') }}
                                    </div>
                                    @endif
                                    @if($errors)
                                    @foreach ($errors->all() as $error)
                                    <div class="alert alert-danger">{{ $error }}</div>
                                    @endforeach
                                    @endif
                                </div>
                                <div class="row white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label  blue-ht">Packing Detail(s) Entry</label>
                                    </div>
                                    <form method="post" action="{{ route('superadmin.domesticTCDetails', $product[0]->at_user_id)}}" >
                                        @csrf
                                        <div class="col-xxl-12 col-md-12 ">
                                            <label for="labelInput" class="form-label blue-ht">Operators details</label>
                                        </div>
                                      
                                        <div class="col-xxl-12 col-md-9 ms-3">
                                            <div class="row  ">
                                               <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                    <tr>
                                                        <td class="pdf_txt1">Operator Name :</td>
                                                        <td class="pdf_box">{{$user->first_name}}</td>

                                                        <td class="pdf_txt1">Operator Scope certificate Number :</td>
                                                        <td class="pdf_box">{{$trans[0]->transaction_certificate_no}}</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="pdf_txt1">Operator Type  :</td>
                                                        <td class="pdf_box">{{$trans[0]->operator_type}}</td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div>
                                        <div class="table-responsive">
                                            <table class="table table-bordered table-striped align-middle dataTable no-footer"
                                                width="100%" id="datatable_">
                                                <thead>
                                                    <tr>
                                                        <th>S.No.</th>
                                                        <th>Product /TC</th>
                                                        <th>Status</th>
                                                        <th>Total Quantity (in MT)</th>
                                                        <th>Remaning Sourced (in MT)</th>
                                                        <th>Sourced Quantity (in MT)</th>
                                                        <th>Packing Entered</th>
                                                        <th>Action</th>
                                                    </tr>

                                                </thead>
                                                <tbody>
                                                    @foreach($product as $productData)
                                                    <tr>
                                                        <td>{{$loop->iteration}}</td>
                                                        <td>{{$productData->product}}</td>
                                                        <td>{{$productData->organic_status}}</td>
                                                        <td>{{$productData->quantity}}</td>
                                                        <td>{{$trans[0]->rem_qty}}</td>
                                                        <td>{{$trans[0]->quantity_for_tc}}</td>
                                                        <td>no</td>
                                                        <td><a href="" onclick="getLots();">Add/Edit</a></td>
                                                    </tr>

                                                    @endforeach
                                                </tbody>

                                            </table>
                                        </div>

                                        <div class="col-xxl-12 col-md-12 ">
                                            <label for="labelInput" class="form-label blue-ht">Add Products Value Detail(s)</label>
                                        </div>
                                      
                                        <div class="col-xxl-12 col-md-9 ms-3">
                                            <div class="row  ">
                                               <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                    <tr>
                                                        <td class="pdf_txt1">Product Name :</td>
                                                        <td class="pdf_box">{{$user->first_name}}</td>

                                                        <td class="pdf_txt1">Trader Name :</td>
                                                        <td class="pdf_box"><input type="text" name="traderName" id="traderName"></td>

                                                        <td class="pdf_txt1">Value INR :</td>
                                                        <td class="pdf_box"><input type="text" name="valueINR" id="valueINR"></td>
                                                    </tr>
                                                </table>
                                            </div><br>
                                        </div>
                                        <div class="col-xxl-12 col-md-12 add-edit-div">
                                            <label for="labelInput" class="form-label blue-ht">Add/Edit Packing details</label>
                                        </div>
                                        <div class="col-xxl-12 col-md-12 add-edit-div ">
                                            <div class="row  ">
                                             <input type="hidden" name="trans_id" value="">
                                                <table class="table_pdf">
                                                    <tr>
                                                        <td class="pdf_txt1">Total Quantity Sourced (in Kg) :</td>
                                                        <td class="pdf_box"></td>

                                                        <td class="pdf_txt1">Remaining Quantity (in Kg) :</td>
                                                        <td class="pdf_box"><input type="text" name="traderName" id="traderName"></td>
                                                    </tr>
                                                </table>        
                                                <div class="table-responsive">
                                                    <table class="table table-bordered table-striped align-middle dataTable no-footer"
                                                        width="100%" id="datatable_">
                                                        <thead>
                                                            <tr>
                                                                <th>S.No.</th>
                                                                <th>Packing Type </th>
                                                                <th>No. of units</th>
                                                                <th>Qty. (Pack size in Kg).</th>
                                                                <th>Total Qty. (in Kg)</th>

                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            @foreach($trans as $transData)
                                                            <tr>
                                                                <td><input name="" type="checkbox">
                                                                <td>
                                                                    <select class="form-select" name="">
                                                                    <option value="">Select Packing Type</option>
                                                                    </select>
                                                                </td>
                                                                <td></td>
                                                                <td></td>
                                                                <td></td>
                                                            </tr>
                                                            @endforeach
                                                        </tbody>
                                                    </table>
                                                </div>
                                                <div style="text-align: center;">
                                                    <span id="successmsg" class="badge badge-soft-success"></span>
                                                        <button type="submit" class="btn btn-primary mt-2">Save</button>
                                                </div>
                                            </div>
                                        </div>
                                    <div style="text-align: center;">
                                        <span id="successmsg" class="badge badge-soft-success"></span><br>
                                        <a href="{{ route('superadmin.domestictc') }}" class="btn btn-primary mt-2">Back to Add Product</a>
                                       
                                        {{-- <a href="{{ route('superadmin.TcDetail') }}" class="btn btn-primary mt-2 ">Proceed</a> --}}
                                            <button type="submit" class="btn btn-primary mt-2 proceed" {{ (isset($packDet->id) && $packDet!='')?'':'disabled' }} >Proceed</button>
                                        {{-- @else
                                            <a href="javascript:void(0);" class="btn btn-primary mt-2 proceed" onclick="chkAddEditPacking();">Proceed</a>
                                        @endif --}}
                                        {{-- <a href="javascript:void(0);" class="btn btn-danger mt-2">Delete</a> --}}
                                    </div>
                                    </form>
                                </div>

                            </div>
                        {{-- </div>
                    </div> --}}
                </div>
            </div>
        </div>
    @endsection
    @push('script')
        <div class="modal fade" id="addBatchModalgrid" tabindex="-1" aria-labelledby="addBatchModalgridLabel"
            aria-modal="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addBatchModalgridLabel">Edit Product</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body" id="batch_popup">

                    </div>
                </div>
            </div>
        </div>
    @endpush
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Get all elements with the class 'toggle-row'
        const toggleRows = document.querySelectorAll('.toggle-row');

        // Add click event listener to each row
        toggleRows.forEach(row => {
            row.addEventListener('click', () => {
                // Toggle the 'hidden' class on the clicked row
                row.classList.toggle('hidden');
            });
        });
    });
</script>


@extends('admin.layouts.app')
@section('content')
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Batch Creation</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Batch Creation</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">

            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                    <a class="nav-link " id="step0-tab"
                        href="{{ route('superadmin.batchCreation', auth()->user()->id) }}">Product Details</a>
                    <a class="nav-link active" id="step2-tab" href="javascript:void(0);">Processed Details</a>
                    <a class="nav-link" id="step3-tab" href="javascript:void(0);">Source Details</a>
                    <a class="nav-link " id="step4-tab" href="javascript:void(0);">Preview</a>
                    <a class="nav-link" id="step3-tab" href="javascript:void(0);">Batch Details</a>
                    <!-- <a class="nav-link" id="step4-tab"
                            href="javascript:void(0);">Product Details</a> -->
                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step2">

                    <div class="card">

                        <div class="card-body">
                            <div class="live-preview">

                                <form action="{{ route('superadmin.batchCreationsave') }}" class="commonform1 "
                                    method="POST" enctype="multipart/form-data" id="commonform1" autocomplete="off">
                                    @csrf

                                    <div class="row">
                                        <div class="col-xxl-3 col-md-6">
                                            <div>
                                                <label class="form-label" for="scopeCertificateNo">Scope Certificate
                                                    No</label>
                                                <span class="form-text">
                                                    <input type="text" class="form-control" id="scopeCertificateNo"
                                                        name="scope_certificate_no" required readonly
                                                        value="{{ $list->scope_certificate_no ?? '' }}">
                                                </span>
                                            </div>
                                        </div>

                                        <div class="col-xxl-3 col-md-6">
                                            <div>
                                                <label class="form-label" for="email">Processing Unit Name:</label>

                                                <span class="form-text">
                                                    <input type="text" class="form-control" id="unit_name" placeholder=""
                                                        name="unit_name" required readonly value="{{ $user->first_name ?? '' }}">
                                                </span>

                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-6">
                                            <div>
                                                <label class="form-label" for="code">HS Code:</label>
                                                <span class="form-text">
                                                    <input type="text" class="form-control" id="hs_code" placeholder=""
                                                        name="hs_code" required readonly
                                                        value="{{ getHscodeById($hscd->ref_hscode_id ?? '') }}">
                                                </span>
                                            </div>
                                        </div>

                                        <div class="col-xxl-3 col-md-6">
                                            <div>
                                                <label class="form-label" for="product">Product Name</label>
                                                <span class="form-text">
                                                    <input type="text" class="form-control" id="product" name="product"
                                                        required readonly value="{{ $org_st->product_processor_name ?? '' }}">
                                                </span>
                                            </div>
                                        </div>

                                    </div>
                                    <br>
                                    <div class="row">
                                        <div class="col-xxl-3 col-md-6">
                                            <div>
                                                <label class="form-label" for="scopeCertificateNo">Organic Status</label>
                                                <!-- <select class="form-control" name="organic_status" id="organic_status">
                                                    <option value="">-Select-</option>
                                                    <option value="organic status">organic status</option>


                                                </select> -->
                                                <input type="hidden" class="form-control" id="organic_status"
                                                name="organic_status" required
                                                value="{{ ($org_st->organic_status ?? '') }}">

                                                <input type="text" class="form-control" id="organic_status_"
                                                    name="organic_status_" required readonly
                                                    value="{{ getRefOrganicStatuscodeByname($org_st->organic_status ?? '') }}">
                                            </div>
                                        </div>

                                        <div class="col-xxl-3 col-md-6">
                                            <div>
                                                <label class="form-label" for="Quantity">Enter Batch Quantity (In MT)<span
                                                        class="required">*</span></label>

                                                <input type="text" class="form-control numbersonly" id="quantity"
                                                    name="quantity"  maxlength="3" required value="">


                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-6">
                                            <div>
                                                <label class="form-label" for="Percentage">Conversion Percentage:<span
                                                        class="required">*</span></label>

                                                <input type="text" class="form-control numbersonly" id="percentage"
                                                    name="percentage"  maxlength="3" required value="">

                                            </div>
                                        </div>

                                        <div class="col-xxl-3 col-md-6">
                                            <div>
                                                <label class="form-label" for="date">Processing Date:<span
                                                        class="required">*</span></label>

                                                <input type="date" class="form-control" id="processing_date"
                                                    name="processing_date" required value="">

                                            </div>
                                        </div>



                                    </div>
                                    <br>
                                    <div class="row">
                                        <div class="col-xxl-3 col-md-6">
                                            <div>
                                                <label class="form-label" for="email">Expiry Date:<span
                                                        class="required">*</span></label>

                                                <input type="date" class="form-control" id="expiry_date"
                                                    name="expiry_date" required value="">

                                            </div>
                                        </div>

                                        <div class="col-xxl-6 col-md-6">
                                            <div>
                                                <label class="form-label" for="date">By-Product along with this
                                                    Batch<span class="required">*</span></label>


                                            </div>

                                            <label for="no">Yes:</label>
                                            <input type="radio" id="yes" name="byProduct" value="yes">

                                            <label for="no">No:</label>
                                            <input type="radio" id="yes" name="byProduct" value="no"
                                                checked>
                                        </div>

                                    </div>

                                    <div class="row">
                                        <div class="col-lg-12 gy-4">
                                            <div class="hstack gap-2">
                                                <button type="submit" class="btn btn-primary">Submit</button>
                                            </div>
                                        </div>
                                    </div>

                                </form>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    </div>
    </div>

    <script>
        const today = new Date();
        const yyyy = today.getFullYear();
        let mm = today.getMonth() + 1;
        let dd = today.getDate();
        if (mm < 10) mm = '0' + mm;
        if (dd < 10) dd = '0' + dd;
        const todayDate = yyyy + '-' + mm + '-' + dd;
        document.getElementById('processing_date').setAttribute('min', todayDate);
        document.getElementById('expiry_date').setAttribute('min', todayDate);
    </script>
@endsection

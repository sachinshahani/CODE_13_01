@extends('admin.layouts.app')
@section('content')
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Batch Creation</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Batch Creation</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">

            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                    <a class="nav-link " id="step0-tab"
                        href="{{ route('superadmin.batchCreation', auth()->user()->id) }}">Product Details</a>
                    <a class="nav-link" id="step2-tab"
                        href="{{ route('superadmin.batchCreationindex', ['at_user_id' => auth()->user()->id]) }}">Processed
                        Details</a>
                    <a class="nav-link active" id="step3-tab" href="javascript:void(0);">Source Details</a>
                    <a class="nav-link " id="step4-tab" href="javascript:void(0);">Preview</a>
                    <a class="nav-link" id="step4-tab" href="javascript:void(0);">Batch Details</a>
                    <!-- <a class="nav-link" id="step4-tab"
                                        href="javascript:void(0);">Product Details</a> -->
                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step3">

                    <div class="card">

                        <div class="card-body">
                            <div class="live-preview">

                                <style>
                                    .customtextarea {
                                        height: 80px;
                                    }
                                </style> <!-- start page title -->


                                <form action="{{ route('superadmin.batchCreationPreviewDetails', auth()->user()->id) }}"
                                    class="commonform1 " method="POST" enctype="multipart/form-data" id="commonform1"
                                    autocomplete="off">
                                    @csrf
                                    <div>
                                        <div class="row white-inner">

                                      <div class="row">

                                            <div class="col-lg-12">
                                                <div class="card">

                                                    <div class="card-body table-responsive">

                                                        <table id="searchResultsTable1" class="table table-bordered table-striped align-middle" style="width:100%">
                                                            <thead>
                                                                <tr>
                                                                    <th>TC No.</th>
                                                                    <th>Product</th>
                                                                    <th>Available Quantity (in MT)</th>
                                                                    <th>Quantity Source (in MT)</th>
                                                                    {{-- <th>Action</th> --}}

                                                                </tr>
                                                            </thead>
                                                            @forelse ($Sourcedata as $val)
                                                            <tbody>

                                                                <tr>
                                                                    <td>{{$val->tc_no ?? ''}}</td>
                                                                    <td>
                                                                        @if (!empty($val->product_code))
                                                                        {{ getHscodeProductName($val->product_code) }}
                                                                        @else
                                                                        N/A <!-- or some default value -->
                                                                        @endif
                                                                    </td>

                                                                    <td>{{$val->available_quantity ?? ''}}</td>
                                                                    <td>{{$val->quantity_source ?? ''}}</td>
                                                                </tr>


                                                            </tbody>
                                                            @empty

                                                            @endforelse

                                                        </table>
                                                    </div>
                                                </div>
                                            </div>

                                        </div> 

                                            {{-- <b>
                                                <h6 class="mb-sm-0">Search Product</h6>
                                            </b>


                                            <div class="col-xxl-2 col-md-4 gy-3 ">
                                                <div>
                                                    <label class="form-label">Enter Product Code:: <span
                                                            class="required"></span></label>
                                                    <input type="text" class="form-control" id="registration_no"
                                                        name="registration_no" value="">
                                                </div>
                                            </div>

                                            <div class="col-xxl-1 col-md-4 gy-2">
                                                <div class="text-center">
                                                    <button type="submit" id="searchBtn" class="btn btn-primary"
                                                        style="margin: 36px;">Search</button>
                                                </div>
                                            </div> --}}

                                        </div>


                                    </div>

                                    <div class="row  white-inner">

                                        <div class="col-lg-12">
                                            <div class="card">

                                                <div class="card-body table-responsive">
                                                    <b>
                                                        <p>Deatils of Transaction Certificate :</p>
                                                    </b>
                                                    <table id="searchResultsTable"
                                                        class="table table-bordered table-striped align-middle"
                                                        style="width:100%">
                                                        <thead>
                                                            <tr>
                                                                <th>S.No.</th>
                                                                <th>Transaction Certificate No..</th>
                                                                <th>Product Name</th>
                                                                <th>Organic Status</th>
                                                                <th>Total Quantity (in MT)</th>
                                                                <th>Used Quantity (in MT)</th>
                                                                <th>Available Quantity (in MT)</th>
                                                                <th>Quantity Source (in MT)</th>
                                                                <th>Action</th>

                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr>


                                                            </tr>

                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <!--end col-->
                                    </div>

                                    <div class="row ">
                                        <div class="col-lg-12 gy-4">
                                            <div class="hstack gap-2 ">
                                                <button type="submit" class="btn btn-primary">Save to Preview</button>
                                            </div>
                                        </div>
                                    </div>

                                </form>
                             
                                <input type="hidden" name="bId" id="bId" value="{{$batchId->id}}">

                                <script>
                                    $(document).ready(function() {
                                        var searchResultsTable = $('#searchResultsTable').DataTable({
                                            processing: true,
                                            serverSide: true,
                                            lengthMenu: [
                                                [10, 25, 50, 100, -1],
                                                [10, 25, 50, 100, "All"]
                                            ],
                                            order: [
                                                [0, 'asc']
                                            ],
                                            ajax: {
                                                url: '{{ route('Search') }}',
                                                type: 'GET',
                                                data: function(d) {

                                                    d._token = "{{ csrf_token() }}";
                                                    d.registration_no = $('#registration_no').val();
                                                }
                                            },
                                            columns: [{
                                                    data: 'DT_RowIndex',
                                                    name: 'DT_RowIndex',
                                                    searchable: false
                                                },
                                                {
                                                    data: 'tc_no',
                                                    name: 'tc_no'
                                                },
                                                {
                                                    data: 'product_name',
                                                    name: 'product_name'
                                                },
                                                {
                                                    data: 'organic_status',
                                                    name: 'organic_status'
                                                },
                                                {
                                                    data: 'total_qnt',
                                                    name: 'total_qnt'
                                                },
                                                {
                                                    data: 'used_qnt',
                                                    name: 'used_qnt'
                                                },
                                                {
                                                    data: 'available_qnt',
                                                    name: 'available_qnt'
                                                },
                                                {
                                                    data: 'qnt_source',
                                                    name: 'qnt_source',
                                                    dataType: 'html'
                                                },
                                                {
                                                    data: 'action',
                                                    name: 'action',
                                                    orderable: false,
                                                    searchable: false
                                                }
                                            ]
                                        });

                                        // Event handler for the search button
                                        $('#searchBtn').click(function(e) {
                                            e.preventDefault();
                                            searchResultsTable.ajax.reload();
                                        });
                                    });
        

                                    $(document).on('click', '.saveButton', function() {
                                        // alert('hi');
                                        var $inputField = $(this);
                                        var rowId = $inputField.data('id');
                                      // alert(rowId);
                                        var tcNo = $inputField.data('tcno');
                                        var procode = $inputField.data('procode');
                                        var qty = $inputField.data('qty');
                                        var usedqty = $inputField.data('usedqty');
                                        var available_qnt = $inputField.data('available_qnt');
                                        var qntSourceValue = $('#qnt_source'+ rowId).val();
                                        var batchId = $('#bId').val();
                                        //alert(qntSourceValue);

                                        $.ajax({
                                            url: '{{ route('superadmin.saveQuantitySource') }}',
                                            type: 'POST',
                                            data: {
                                                _token: "{{ csrf_token() }}",
                                              //  row_id: rowId,
                                                tc_no: tcNo,
                                                pro_code : procode,
                                                total_quantity : qty,
                                                used_quantity : usedqty,
                                                available_qnt : available_qnt,
                                                qnt_source: qntSourceValue,
                                                batch_id: batchId,
                                               // batch_details_id: batchDetailsId,

                                            },
                                            success: function(response) {
                                                
                                                Swal.fire('Alert',response.message,'success');
                                                location.reload();
                                            },
                                            error: function(xhr, status, error) {

                                                console.error('Error saving quantity source:', error);
                                            }
                                        });
                                    });
                                </script>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
   
    <script type="text/javascript">
      
        function validateQuantity(inputElement) {
           
            var enteredValue = parseFloat(inputElement.value);
            
            var availableQty = parseFloat(inputElement.getAttribute('data-available'));
    
            
            if (enteredValue > availableQty) {             
                Swal.fire({
                    title: 'Quantity Exceeded',
                    text: 'Entered quantity is greater than the available quantity (' + availableQty + ')',
                    icon: 'warning',  
                    confirmButtonText: 'OK'
                });    
               
                inputElement.value = availableQty;
            }
        }
    </script>
    


@endsection

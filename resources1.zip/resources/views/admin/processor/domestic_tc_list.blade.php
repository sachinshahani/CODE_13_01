@extends('admin.layouts.app')
@section('content')
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Application for Transaction Certificate</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Application for Transaction Certificate</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <!-- end page title -->
    <div class="row">
        <div class="col-lg-12">
            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">
                    <a class="nav-link" id="step1-tab" href="{{ route('superadmin.domestictc') }}">Add Product</a>
                    <a class="nav-link" id="step2-tab" href="javascript:void(0);">Packing Details</a>
                    <a class="nav-link active" id="step3-tab" href="javascript:void(0);">TC Details</a>
                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">
                        <div class="row seperatesec  white-inner">
                            <!-- end card header -->
                            <div class="table-responsive text-center">
                              <a href="{{route('superadmin.viewTcApplication', $id = 213)}}"  class="btn btn-soft-primary">Click here to preview the domestic transactioin certificate application</a>
                            </div>
                        </div>
                    </div>
                    <div style="text-align: center;">
                        <span id="successmsg" class="badge badge-soft-success"></span><br>
                         <button type="submit" class="btn btn-primary mt-2">Edit</button>
                        <a href="{{route('superadmin.viewTcApplication',$id = 213)}}" class="btn btn-primary mt-2">Forword to CB</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('script')
@endpush
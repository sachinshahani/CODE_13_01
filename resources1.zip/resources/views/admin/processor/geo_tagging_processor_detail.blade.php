@extends('admin.layouts.app')
@section('content')

    <style>
        .wrapper {
            max-width: 1240px;
            margin: 0 auto;
        }

        .white-bg {
            background-color: white;
            /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
            border-bottom: 5px solid #ff9800;
            margin-bottom: 15px;
        }

        .auth-one-bg .slide .carousel-indicators {
            bottom: 25px;
        }

        .auth-page-wrapper .auth-page-content {
            padding-bottom: 0px !important;
        }

        .auth-page-content .card {
            margin-bottom: 0rem;
        }

        .data-tabs .wrapper .nav-tabs button {
            font-size: 17px;
            color: black;
        }

        .data-tabs .wrapper .nav-tabs .active {
            background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
            */ color: white;
            background: orange;
            border-radius: 0px;
        }

        .carousel-caption.d-none.d-md-block {
            background-color: #000000bf;
            left: 0;
            width: 100%;
            bottom: 0;
        }

        .carousel-indicators {
            display: none;
        }

        .custom-banner-caption {
            color: white !important;
        }

        .announcement-heading {
            font-size: 1.2em;
            font-weight: 600;
        }

        .data-tabs .tab-pane ul li {
            font-size: 1em;
            padding: 5px 0;

        }

        .main-logo {
            padding: 10px;
        }

        .data-tabs .nav-item .nav-link {
            background-image: none;
        }

        /* .right-sec{
        box-shadow: 5px 10px 18px #888888;
    } */
        .navbar-brand-box {
            background: #fff;
        }

        [data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
            color: white !important;
        }

        .header-buttons .btn-primary {
            margin-right: 10px;
            padding: 6px 15px;
            font-weight: 600;
            background-color: #207005;
            border: none;
            box-shadow: 0px 2px 7px #888888;
        }

        .header-buttons .btn-secondary {
            margin-right: 10px;
            padding: 6px 15px;
            font-weight: 600;
            background-color: #72a055;
            border: none;
            box-shadow: 0px 2px 7px #888888;
        }


        .right-sec {
            border-left: 5px solid #ede7e7;
        }

        .tabdiv {
            background: white;
            padding: 20px;
            margin-top: 10px;
            border: 10px solid #dfdbd5;
        }

        .nav-tabs {
            border-bottom: 0px;
        }

        div#myTabContent {
            border: 1px solid #cccccc;
        }

        .frontfooter footer {
            padding: 20px calc(1.5rem / 2);
            position: static;
            color: #000;
            height: 60px;
            background-color: #f9f9f9;
            margin-top: 30px;
            border-top: 1px solid #e1dfdf;
        }

        span.logo-sm img {
            width: 69px;
        }

        .seperatesec {
            margin-top: 20px;
        }

        .simplebar-content li.nav-item:hover {
            background: #4caf50;
        }

        .sectitle {
            font-size: 14px;
        }

        .required {
            color: red;
        }

        .customtextarea {
            height: 120px;
        }

        ul.boxsection {
            margin: 0;
            padding: 0;
        }

        ul.boxsection li {
            list-style-type: none;
            padding: 7px 0;
            border-bottom: 1px solid #efeded;
        }

        .boxcard .col:nth-child(1) {
            background: #effcfb;
        }

        .boxcard .col:nth-child(2) {
            background: #fdfdfd;
        }

        .boxcard .col:nth-child(3) {
            background: #effcfb;
        }

        .boxcard .col:nth-child(4) {
            background: #fdfdfd;
        }

        .boxcard .col:nth-child(5) {
            background: #effcfb;
        }

        /* --registration-form css  */
        .custom-tab-content {
            padding-top: 0 !important;
            padding-bottom: 0px !important;
        }

        .custom-tab-nav {
            background: white;

        }

        .custom-tab-nav .nav-link {
            border-radius: 0 !important;
            border-bottom: 1px solid #e9ebec;
            border-right: 1px solid #e9ebec;
            font-size: 14px;
            padding: 10px;
        }

        .custom-tab-nav .nav-link.active,
        .custom-tab-nav .show>.nav-link {
            color: rgb(255, 255, 255) !important;
            background-color: #2c8c6d;
            border-bottom: #2c8c6d !important;
            /* border-bottom: #207005 !important; */
            position: relative;
        }

        .custom-tab-nav .nav-link:hover,
        .custom-tab-nav .nav-link:focus {
            border-bottom: 1px solid #207005;
            border-radius: 0;
            font-size: 14px;
            transition: background-color 0.20s linear;
        }

        .custom-tab-nav .nav-link.active:after {
            content: "";
            position: absolute;
            bottom: -16px;
            left: 50%;
            border: 8px solid transparent;
            border-top-color: #2c8c6d;
            z-index: 999;
        }

        .reg-form-btns {
            margin-bottom: 15px;
        }

        .reg-form-btns .btn-secondary {
            color: #fff;
            background-color: #405189;
            border-color: #405189;
        }

        .btn-soft-success:active,
        .btn-soft-success:focus,
        .btn-soft-success:hover {
            border: none;
        }

        .custom-tab-nav ul {
            padding: 0px;
            margin: 0px;
        }

        .custom-tab-nav ul li {
            padding: 0px;
            margin: 0px;
            display: inline-block;
            list-style: none;
        }
    </style>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">processor Profile / प्रोसेसर प्रोफ़ाइल</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">processor Profile</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">
            <form method="post" enctype="multipart/form-data" id="registration"
                action="{{ route('superadmin.processorUseredit.step1save', $userdetails->id) }}">
                @csrf
                <nav>
                    <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                        <a class="nav-link" id="step1-tab" data-bs-toggle="tab_"
                            href="{{ route('superadmin.processorUseredit', $userdetails->id) }}">General Information</a>

                        <a class="nav-link active" id="step3-tab" data-bs-toggle="tab_"
                            href="{{ route('superadmin.processorUseredit.step1', $userdetails->id) }}">Geo Tagging of
                            Processing Details</a>
                        <a class="nav-link" id="step4-tab" data-bs-toggle="tab_"
                            href="{{ route('superadmin.processorUseredit.step2', $userdetails->id) }}">Products Details</a>
                        <a class="nav-link" id="step4-tab" data-bs-toggle="tab_"
                            href="{{ route('superadmin.processorUseredit.step3', $userdetails->id) }}">List of Documents</a>
                    </div>
                </nav>
                <div class="tab-content py-4 custom-tab-content">
                    <div class="tab-pane fade show active" id="step1">
                        <!-- <div class="card">
                                    <div class="card-header align-items-center d-flex">
                                        <h4 class="card-title mb-0 flex-grow-1">
                                        Processor Unit Details
                                        </h4>

                                    </div>

                                    <div class="card-body">
                                        <div class="live-preview">
                                            <div class="row seperatesec_">
                                                 <div class="col-xxl-4 col-md-4">
                <div>
                 <label class="form-label">Number of Processor Unit<span class="required"> *</span></label>
                 <input type="text" class="form-control" id="name" placeholder="Enter the Number of Processor Unit" name="name">
                </div>
               </div>
              </diV>
             </diV>
            </diV>
           </diV> -->

                        <div class="card">
                            <div class="card-header align-items-center d-flex">
                                <h4 class="card-title mb-0 flex-grow-1">
                                    प्रसंस्करण इकाइयों की जियो टैगिंग/Geo Tagging of Processing Units
                                </h4>
                                <div class="flex-shrink-0">
                                    @if (session('error'))
                                        <div class="alert alert-danger">
                                            {{ session('error') }}
                                        </div>
                                    @endif
                                    @if (session('success'))
                                        <div class="alert alert-success">
                                            {{ session('success') }}
                                        </div>
                                    @endif
                                    @if ($errors)
                                        @foreach ($errors->all() as $error)
                                            <div class="alert alert-danger">{{ $error }}</div>
                                        @endforeach
                                    @endif
                                </div>
                            </div>
                            <!-- end card header -->
                            <div class="card-body">
                                <div class="live-preview">

                                    @forelse($GeoTaggingProcessorDetails as $key=> $GeoTagging)
                                        @if ($key == 0)
                                            <div class="row white-inner">
                                                <div class="col-xxl-3 col-md-4 gy-3">
                                                    {{-- <div>
                                                        <label class="form-label">Enter the number of Processing Units/प्रोसेसिंग यूनिट की संख्या<span
                                                                class="required"> *</span></label>
                                                        <input type="text" class="form-control numbersonly"
                                                            id="number_of_processing_unit" placeholder="Processing Unit"
                                                            value="{{ $GeoTagging->number_of_processing_unit ?? '' }}"
                                                            name="number_of_processing_unit" maxlength="5">
                                                    </div> --}}




                                                    <div>
                                                        <label class="form-label">प्रोसेसिंग यूनिट की संख्या/Enter the number of Processing Units<span
                                                                class="required"> *</span></label>
                                                        <input type="text" class="form-control numbersonly"
                                                            id="number_of_processing_unit" placeholder="Processing Unit"
                                                            value="1"
                                                            name="number_of_processing_unit" maxlength="5" readonly>
                                                    </div>
                                                </div>
                                            </div>
                                        @endif
                                        <div class="row white-inner seperatesec after-add-more" id="row{{ $GeoTagging->id }}">

                                            <input type="hidden" class="form-control" value="{{ $GeoTagging->id }}"
                                                name="row_id[]" />
                                            <div class="col-xxl-3 col-md-3 gy-3 d-none">
                                                <div>
                                                    <label class="form-label">प्रोसेसिंग यूनिट आईडी/Processing Unit ID<span class="required">
                                                            *</span></label>
                                                    <input type="text" class="form-control"
                                                        value="{{ $GeoTagging->processing_unit_id ?? '' }}" id="unit_id"
                                                        placeholder="Processor Unit ID" name="processing_unit_id[]">
                                                </div>
                                            </div>

                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">प्रसंस्करण इकाइयों का नाम/Name of the Processing Units<span
                                                            class="required"> *</span></label>
                                                    <input type="text" class="form-control"
                                                        value="{{ $GeoTagging->processing_units_name ?? '' }}" id="unit_name"
                                                        placeholder="Enter the Name of the Processor Units "
                                                        name="processing_units_name[]">
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">एफएसएसएआई लाइसेंस नंबर/FSSAI License No<span class="required">
                                                            *</span></label>
                                                    <input type="text" class="form-control numbersonly"
                                                        value="{{ $GeoTagging->fssai_license_number ?? '' }}"
                                                        id="fssai_license_number" placeholder="FSSAI License Number"
                                                        name="fssai_license_number[]" maxlength="14">
                                                </div>
                                            </div>
                                            <!-- <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">लाइसेंस दस्तावेज़/License Document<span class="">
                                                        </span></label>
                                                    <input type="file" class="form-control" name="license_document[]">
                                                    @if (!empty($GeoTagging->license_document))
                                                        <input type="hidden" name="license_document_edit[]"
                                                            value="{{ $GeoTagging->license_document ?? '' }}">
                                                        <a target="_BLANK"
                                                            href="{{ asset('public/processor/license_document/' . $GeoTagging->license_document) }}"
                                                            class="text-decoration-underline">See Doc</a>
                                                            <p>Upload only PDF up to 1MB</p>   
                                                    @endif
                                                </div>
                                            </div> -->
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">एफएसएसएआई लाइसेंस की वैधता दिनांक से/FSSAI License Validity From <span
                                                            class="required"> *</span></label>
                                                    <input type="date" class="form-control"
                                                        value="{{ $GeoTagging->license_validity_from ?? '' }}"
                                                        id="fssai_license_validity" placeholder="FSSAI License Validity"
                                                        name="license_validity_from[]">
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">एफएसएसएआई लाइसेंस की वैधता दिनांक तक/FSSAI License Validity To  <span
                                                            class="required"> *</span></label>
                                                    <input type="date" class="form-control"
                                                        value="{{ $GeoTagging->license_validity_to ?? '' }}"
                                                        id="fssai_license_validity" placeholder="FSSAI License Validity"
                                                        name="license_validity_to[]">
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label"> प्रोसेसिंग लाइनों की संख्या/No. of Processing Lines<span
                                                            class="required"> *</span></label>
                                                    <input type="text" class="form-control numbersonly"
                                                        id="fssai_license_number" placeholder="No. of Processing Lines"
                                                        name="no_of_processing_lines[]" maxlength="6" required
                                                        value="{{ $GeoTagging->no_of_processing_lines ?? '' }}">
                                                </div>
                                            </div>

                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">समझौते की स्थिति/Status of Agreement<span class="">
                                                            </span></label>
                                                    <input type="text" class="form-control"
                                                        value="{{ $GeoTagging->agreement_status ?? '' }}"
                                                        id="status_of_agreement" placeholder="Status of Agreement"
                                                        name="agreement_status[]">
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">उत्पादों की संख्या/Number of Products<span
                                                            class="required"> *</span></label>
                                                    <input type="number" class="form-control"
                                                        value="{{ $GeoTagging->number_of_product ?? '' }}"
                                                        id="number_of_products" placeholder="Number of Products"
                                                        name="number_of_product[]" required>
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">अतिरिक्त प्रमाणपत्र/Additional Certificate<span
                                                            class="required"> </span></label>
                                                    <input type="file" class="form-control"
                                                        name="additional_certificate[]" id="additional_certificate">
                                                    @if (!empty($GeoTagging->additional_certificate))
                                                        <input type="hidden" name="additional_certificate_edit[]"
                                                            value="{{ $GeoTagging->additional_certificate ?? '' }}" >
                                                        <a target="_BLANK"
                                                            href="{{ asset('public/processor/additional_certificate/' . $GeoTagging->additional_certificate) }}"
                                                            class="text-decoration-underline">See Doc</a>
                                                    @endif
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">प्रोसेसिंग यूनिट की जियो टैगिंग/Geo Tagging of Processing
                                                        Unit<span class="required"> *</span></label>
                                                    <input type="text" class="form-control"
                                                        value="{{ $GeoTagging->geo_tagging_processing_unit ?? '' }}"
                                                        name="geo_tagging_processing_unit[]"
                                                        id="geo_tagging_of_processor_unit" 
                                                        placeholder="Geo Tagging of Processing Unit" required>
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">प्रतिबिंबित फार्म/Reflect Farm<span class="">
                                                        </span></label>
                                                    <select class="form-select" name="reflect_farm[]">
                                                        <option value="">--Select--</option>
                                                        <option value="Non Organic Area"
                                                            {{ $GeoTagging->reflect_farm == 'Non Organic Area' ? 'selected' : '' }}>
                                                            Non Organic Area</option>
                                                        <option value="Organic Area"
                                                            {{ $GeoTagging->reflect_farm == 'Organic Area' ? 'selected' : '' }}>
                                                            Organic Area</option>

                                                    </select>
                                                </div>
                                            </div>

                                            <!-- <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">टैगिंग के बाद फार्म फोटो दर्शाएँ/Reflect Farm Image after Tagging <span
                                                            class=""> </span></label>
                                                    <input type="file" class="form-control"
                                                        name="image_after_tagging[]"
                                                        id="image_after_tagging">
                                                    @if (!empty($GeoTagging->image_after_tagging))
                                                        <input type="hidden"
                                                            name="image_after_tagging[]"
                                                            value="{{ $GeoTagging->image_after_tagging ?? '' }}">
                                                        <a target="_BLANK"
                                                            href="{{ asset('public/processor/image_after_tagging/' . $GeoTagging->image_after_tagging) }}"
                                                            class="text-decoration-underline">See Doc</a>
                                                    @endif
                                                </div>
                                            </div> -->
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">प्रोसेसिंग यूनिट की कुल क्षमता/Total Capacity of
                                                        Processing Units(MT)<span class="required"> *</span></label>
                                                    <input type="text" class="form-control numbersonly"
                                                        value="{{ $GeoTagging->total_capacity ?? '' }}"
                                                        name="total_capacity[]"
                                                        id="total_capacity"
                                                        placeholder="Total Capacity of Processor Unit" maxlength="5" required>
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">जैविक प्रोसेसिंग के अंतर्गत स्थापित क्षमता/Installed Capacity Under
                                                        Organic Processing(MT)<span class="required"> *</span></label>
                                                    <input type="text" class="form-control numbersonly"
                                                        value="{{ $GeoTagging->installed_capacity_under_organic ?? '' }}"
                                                        name="installed_capacity_under_organic[]"
                                                        id="installed_capacity_under_organic"
                                                        placeholder="Total Installed Capacity Under Organic Processing" maxlength="5" required>
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">दैनिक प्रोसेसिंग क्षमता/Daily Processing
                                                        Capacity(MT)<span class="required"> </span></label>
                                                    <input type="text" class="form-control numbersonly"
                                                        value="{{ $GeoTagging->daily_processing_capacity ?? '' }}"
                                                        name="daily_processing_capacity[]" id="daily_processing_capacity"
                                                        placeholder="Daily Processing Capacity" maxlength="5" >
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">प्रोसेसिंग के प्रकार/Types of Processing<span class="required">
                                                        </span></label>
                                                    <select class="form-select" name="processing_type[]" >
                                                        <option value="">--Select--</option>
                                                        <option value="Parallel"
                                                            {{ $GeoTagging->processing_type == 'Parallel' ? 'selected' : '' }}>
                                                            Parallel</option>
                                                            <option value="other"
                                                            {{ $GeoTagging->processing_type == 'other' ? 'selected' : '' }}>
                                                            other</option>

                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">पता/Address<span class="required">
                                                            *</span></label>
                                                    <textarea name="address[]" id="address" required class="form-control">{{ $GeoTagging->address ?? '' }}</textarea>
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">प्रोसेसिंग यूनिट की फोटो/Photo of Processing Unit<span
                                                            class=""> </span></label>
                                                    <input type="file" class="form-control upload_document1"
                                                        name="processing_unit_image[]" id="processing_unit_image">
                                                    @if (!empty($GeoTagging->processing_unit_image))
                                                        <input type="hidden" name="processing_unit_image_edit[]"
                                                            value="{{ $GeoTagging->processing_unit_image ?? '' }}">
                                                        <a target="_BLANK"
                                                            href="{{ asset('public/processor/processing_unit_image/' . $GeoTagging->processing_unit_image) }}"
                                                            class="text-decoration-underline">See Doc</a>
                                                    @endif
                                                      <p>Supported formats:jpg, jpeg. Upto 1MB</p>
                                                </div>
                                            </div>


                                            <div class="mt-2 text-sm-end">
                                                @php
                                                    $token = $GeoTagging->id . '#rgvv';

                                                    $token = Crypt::encryptString($token);
                                                @endphp
                                                <div class="form-group change">
                                                    <label for="">&nbsp;</label><br />
                                                    <a class="mdi mdi-delete btn btn-soft-danger "
                                                        href="javascript:void(0);"
                                                        onclick="confirmDelete_('{{ $GeoTagging->id }}')"
                                                        alt="Remove"></a>

                                                </div>
                                            </div>

                                            <!---->
                                        </div>

                                    @empty

                                        <div class="row white-inner">
                                            <div class="col-xxl-3 col-md-4 gy-3">
                                                <div>
                                                    <label class="form-label">प्रोसेसिंग यूनिट की संख्या/Number of Processing Unit<span
                                                            class="required"> *</span></label>
                                                    <input type="text" class="form-control numbersonly"
                                                        id="number_of_processor_unit" placeholder="Processing Unit"
                                                        name="number_of_processing_unit" maxlength="5" value="1" readonly>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="after-add-more seperatesec ">
                                            <input type="hidden" class="form-control" value="" name="row_id[]" />

                                            <div class="row seperatesec white-inner">
                                                <div class="col-xxl-3 col-md-3 gy-3 d-none">
                                                    <div>
                                                        <label class="form-label">प्रोसेसिंग यूनिट आईडी/Processing Unit ID<span
                                                                class="required"> *</span></label>
                                                        <input type="text" class="form-control" id="unit_id" required
                                                            placeholder="Processor Unit ID" name="processing_unit_id[]">
                                                    </div>
                                                </div>

                                                <div class="col-xxl-3 col-md-3 gy-3">
                                                    <div>
                                                        <label class="form-label">Name of the Processing Units<span
                                                                class="required"> *</span></label>
                                                        <input type="text" class="form-control" id="unit_name"
                                                            placeholder="Enter the Name of the Processor Units "
                                                            name="processing_units_name[]">
                                                    </div>
                                                </div>
                                                <div class="col-xxl-3 col-md-3 gy-3">
                                                    <div>
                                                        <label class="form-label">एफएसएसएआई लाइसेंस नंबर/FSSAI License No<span
                                                                class=""> *</span></label>
                                                        {{-- <input type="text" class="form-control"
                                                            id="fssai_license_number" placeholder="FSSAI License Number"
                                                            name="fssai_license_number[]"> --}}

                                                            <input type="text" maxlength="14" class="form-control  fssai_license_number numbersonly" id="fssai_license_number" placeholder="FSSAI License Number" name="fssai_license_number[]" required>
                                                            <label for="agreement_status" class="success fssi_success d-none" style="color:green">License Verified.</label>

                                                    </div>
                                                </div>
                                                <div class="col-xxl-3 col-md-3 gy-3">
                                                    <div>
                                                        <label class="form-label">लाइसेंस दस्तावेज़/License Document<span class="required">
                                                            </span></label>
                                                        <input type="file" class="form-control upload_document"
                                                            name="license_document[]">
                                                            <p>Upload only PDF up to 1MB</p>

                                                    </div>
                                                </div>
                                                <div class="col-xxl-3 col-md-3 gy-3">
                                                    <div>
                                                        <label class="form-label">एफएसएसएआई लाइसेंस की वैधता दिनांक से/FSSAI License Validity From <span
                                                                class="required"> *</span></label>
                                                        <input type="date" 
                                                            class="form-control fssai_license_validity_from"
                                                            id="fssai_license_validity"
                                                            placeholder="FSSAI License Validity"
                                                            name="license_validity_from[]" required>
                                                    </div>
                                                </div>
                                                <div class="col-xxl-3 col-md-3 gy-3">
                                                    <div>
                                                        <label class="form-label">एफएसएसएआई लाइसेंस की वैधता दिनांक तक/FSSAI License Validity To  <span
                                                                class="required"> *</span></label>
                                                        {{-- <input type="date"
                                                            class="form-control fssai_license_validity_to" value=""
                                                            id="fssai_license_validity"
                                                            placeholder="FSSAI License Validity"
                                                            name="license_validity_to[]"
                                                            onchange="endDateFunction(this);"> --}}


                                                            <input type="date" class="form-control license_validity" id="license_validity" placeholder="FSSAI License Validity" name="license_validity[]" readonly required>
                                                    </div>
                                                </div>
                                                <div class="col-xxl-3 col-md-3 gy-3">
                                                    <div>
                                                        <label class="form-label">प्रोसेसिंग लाइनों की संख्या/No. of Processing Lines1<span
                                                                class="required"> </span></label>
                                                        <input type="text" class="form-control numbersonly"
                                                            id="fssai_license_number"
                                                            placeholder="No. of Processing Lines"
                                                            name="no_of_processing_lines[]" maxlength="6" >
                                                    </div>
                                                </div>

                                                <div class="col-xxl-3 col-md-3 gy-3">
                                                    <div>
                                                        <label class="form-label">समझौते की स्थिति/Status of Agreement<span
                                                                class="required"> </span></label>
                                                        <input type="text" class="form-control"
                                                            id="status_of_agreement" placeholder="Status of Agreement"
                                                            name="agreement_status[]">
                                                    </div>
                                                </div>
                                                <div class="col-xxl-3 col-md-3 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">उत्पादों की संख्या/Number of Products<span
                                                                class="required"> </span></label>
                                                        <input type="number" class="form-control"
                                                            placeholder="Number of Products" name="number_of_product[]">
                                                    </div>
                                                </div>
                                                <div class="col-xxl-3 col-md-3 gy-3">
                                                    <div>
                                                        <label class="form-label">अतिरिक्त प्रमाणपत्र/Additional Certificate<span
                                                                class="required"> </span></label>
                                                        <input type="file" class="form-control"
                                                            name="additional_certificate[]" id="additional_certificate">
                                                    </div>
                                                </div>
                                                <div class="col-xxl-3 col-md-3 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">प्रोसेसिंग यूनिट की जियो टैगिंग/Geo Tagging of Processing Unit<span class=""> </span></label>
                                                        <input type="text" class="form-control"
                                                            name="geo_tagging_processing_unit[]"
                                                            id="geo_tagging_of_processor_unit"
                                                            placeholder="Geo Tagging of Processing Unit">
                                                    </div>
                                                </div>
                                                <div class="col-xxl-3 col-md-3 gy-3">
                                                    <div>
                                                        <label class="form-label">प्रतिबिंबित फार्म/Reflect Farm<span class="">
                                                            </span></label>
                                                        <select class="form-select" name="reflect_farm[]">
                                                            <option value="">--Select--</option>
                                                            <option value="Non Organic Area">Non Organic Area</option>
                                                            <option value="Organic Area">Organic Area</option>

                                                        </select>
                                                    </div>
                                                </div>
                                                <!-- <div class="col-xxl-3 col-md-3 gy-3">
                                                    <div>
                                                        <label class="form-label">टैगिंग के बाद फार्म फोटो दर्शाएँ/Reflect Farm Image after Tagging <span
                                                                class=""> </span></label>
                                                        <input type="file" class="form-control"
                                                            name="image_after_tagging[]"
                                                            id="reflect_farm_image_after_tagging">
                                                    </div>
                                                </div> -->
                                                <div class="col-xxl-3 col-md-3 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">प्रोसेसिंग यूनिट की कुल क्षमता/Total Capacity of
                                                            Processing Unit<span class="required"> *</span></label>
                                                        <input type="text" class="form-control"
                                                            name="total_capacity[]"
                                                            id="total_capacity_of_Processor_unit"
                                                            placeholder="Total Capacity of Processor Unit">
                                                    </div>
                                                </div>
                                                <div class="col-xxl-3 col-md-3 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">जैविक प्रोसेसिंग के अंतर्गत स्थापित क्षमता/Installed Capacity Under Organic Processing(MT)<span class="required">
                                                                *</span></label>
                                                        <input type="text" class="form-control"
                                                            name="installed_capacity_under_organic[]"
                                                            id="installed_capacity_under_organic_processing"
                                                            placeholder="Total Installed Capacity Under Organic Processing">
                                                    </div>
                                                </div>
                                                <div class="col-xxl-3 col-md-3 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">दैनिक प्रोसेसिंग क्षमता/Daily Processing
                                                            Capacity (MT)<span class="required"> </span></label>
                                                        <input type="text" class="form-control"
                                                            name="daily_processing_capacity[]"
                                                            id="daily_processing_capacity"
                                                            placeholder="Daily Processing Capacity">
                                                    </div>
                                                </div>
                                                <div class="col-xxl-3 col-md-3 gy-3">
                                                    <div>
                                                        <label class="form-label">प्रोसेसिंग के प्रकार/Types of Processing<span
                                                                class="required"> </span></label>
                                                        <select class="form-select" name="processing_type[]">
                                                            <option value="">--Select--</option>
                                                            <option value="Parallel">Parallel</option>

                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-xxl-3 col-md-3 gy-3">
                                                    <div>
                                                        <label class="form-label">Address<span class="required">
                                                            </span></label>
                                                        <textarea name="address[]" id="address" class="form-control"></textarea>
                                                    </div>
                                                </div>
                                                <div class="col-xxl-3 col-md-3 gy-3">
                                                    <div>
                                                        <label class="form-label">प्रोसेसिंग यूनिट की फोटो/Photo of Processing Unit<span
                                                                class=""> </span></label>
                                                        <input type="file" class="form-control upload_document1"
                                                            name="processing_unit_image[]"
                                                            id="photo_of_processing_unit">
                                                            <p>Supported formats:jpg, jpeg. Upto 1MB</p>
                                                    </div>
                                                </div>
                                                <div class="mt-2 text-sm-end">
                                                    <div class="form-group change">
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    @endforelse
                                    {{-- <div class="mt-2 text-sm-end">
                                        <div class="form-group change">
                                            <label for="">&nbsp;</label><br />
                                            <i data-type="wm" class="mdi mdi-plus btn btn-soft-success add-more"
                                                data-toggle="tooltip" title="Add Row"></i>
                                        </div>
                                    </div> --}}
                                    <!--address sec end-->

                                    <div class="row">
                                        <div class="col-lg-12 gy-4">
                                            <div class="hstack gap-2">
                                                <a href="{{ route('superadmin.processorUseredit', $userdetails->id) }}"
                                                    class="btn btn-soft-success">
                                                    Back
                                                </a>
                                                <button type="submit" class="btn btn-primary">
                                                    Save
                                                </button>
                                                <a href="{{ route('superadmin.processorUseredit.step2', $userdetails->id) }}"
                                                    class="btn btn-soft-success">
                                                    Next
                                                </a>

                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>



@endsection
@push('script')
    <script>
        $('.upload_document').on('change', function() {
            var $this = $(this);
            var file = $this[0].files[0];
            var fileType = file.type;
            var fileSize = file.size;
            var allowedTypes = ['application/pdf'];

            // Check for file type
            if (!allowedTypes.includes(fileType)) {
                Swal.fire({
                    icon: 'error',
                    title: 'Invalid File Extension',
                    text: 'Please upload PDF only.',
                });
                $this.val("");
                return false;
            }

            // Check for file size
            if (fileSize > 1000000) { // 2 MB in bytes
                Swal.fire({
                    icon: 'error',
                    title: 'File Size Too Large',
                    text: 'Please upload files of size 1 MB or less only.',
                });
                $this.val("");
                return false;
            }
        });





        $('.upload_document1').on('change', function() {
    var $this = $(this);
    var file = $this[0].files[0];
    var fileType = file.type;
    var fileSize = file.size;
    var allowedTypes = ['image/jpeg', 'image/jpg'];

    // Check for file type
    if (!allowedTypes.includes(fileType)) {
        Swal.fire({
            icon: 'error',
            title: 'Invalid File Extension',
            text: 'Please upload JPEG, JPG only.',
        });
        $this.val("");
        return false;
    }

    // Check for file size (1 MB = 1,048,576 bytes)
    if (fileSize > 1048576) {
        Swal.fire({
            icon: 'error',
            title: 'File Size Too Large',
            text: 'Please upload files of size 1 MB or less only.',
        });
        $this.val("");
        return false;
    }
});



        function confirmDelete_(id) {

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.value) {
                    $.ajax({
                        url: "{{ route('superadmin.processorUseredit.deleteGeoProcessor') }}",
                        method: "POST",
                        dataType: 'json',
                        data: {
                            'id': id,
                        },
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function(result) {
                            $('#row' + id).remove();
                            Swal.fire(
                                'Deleted!',
                                'Record Deleted Successfully..',
                                'success'
                            );

                        }
                    });

                }
            })
        }

        function endDateFunction(input) {
            var end_date = input.value;
            var start_date = document.getElementsByClassName('fssai_license_validity_from');

            if (start_date.length > 0) {
                var d1 = Date.parse(start_date[0].value);
            }
            var d2 = Date.parse(end_date);
            if (d1 > d2) {
                Swal.fire('', 'End date should not be less than start date.', 'warning');
                $('input[name="fssai_license_validity_to[]"]').val('');
                return false;
            }
        }


        $(document).ready(function() {
            $("body").on("click", ".add-more", function() {
                var html = $(".after-add-more").first().clone().find("input").val("").end().find("select")
                    .val("").end().find("textarea").val("").end().find("file").val("").end().find("a")
                    .remove().end();

                $(html).find(".change").html(
                    "<label for=''>&nbsp;</label><br/><a class='mdi mdi-delete btn btn-soft-danger remove'></a>"
                    );
                $(".after-add-more").last().after(html);
            });

            $("body").on("click", ".remove", function() {
                $(this).parents(".after-add-more").remove();
            });
        });


            $(document).on('blur', '.fssai_license_number', function() {
                var th = $(this);
                var license_number = this.value;

             $.ajax({
                type: 'POST',
                url: "{{ route('superadmin.trader.getFSSAIDetails') }}",
                data: {
                    'license_number': license_number
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    if (response) {
                        var res = JSON.parse(response);

                        if (res.productDetails) {
                            var productList = res.productDetails.find(productDetail => productDetail.groupName === "Food Services" && productDetail.kobName === "Hawker (Itinerant / Mobile food vendor)");
                            if (productList) {
                                var products = "";

                                productList.productList.forEach(function(product) {

                                    products += "Product Name: " + product.productName + "\n";
                                    products += "-----------------------------------------\n";
                                });


                                $('.fss_pro').val(products);
                            }
                        }

                        if (res.expiryDate !== undefined) {
                            var dateAr = res.expiryDate.split('-');
                            var newDate = dateAr[2] + '-' + dateAr[1] + '-' + dateAr[0].slice(-2);
                            $(th).parent().parent().parent().find('input[name="license_validity[]"]').val(newDate);
                            $(th).parent().parent().parent().find('textarea[name="address[]"]').val(res.premiseAddress);
                            $(th).parent().parent().parent().find('textarea[name="company[]"]').val(res.companyName);
                            $(th).parent().parent().parent().find('textarea[name="licenseActiveFlag[]"]').val(res.licenseActiveFlag);
                            $(th).parent().parent().parent().find('input[name="fssai_license_record[]"]').val(response);
                            $(".fssi_success").removeClass("d-none");
                        } else {
                            $(".fssi_success").addClass("d-none");
                            Swal.fire(
                                'Warning!',
                                'Invalid FSSAI License Number .',
                                'warning'
                            );
                        }
                    }
                }
            });
    });

    function viewLicense(id) {
        //alert(id);
        $("#myModal").modal('show');

    }
    </script>
@endpush

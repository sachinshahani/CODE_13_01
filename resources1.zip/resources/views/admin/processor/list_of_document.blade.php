@extends('admin.layouts.app')
@section('content')



<style>
    .wrapper {
        max-width: 1240px;
        margin: 0 auto;
    }

    .white-bg {
        background-color: white;
        /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
        border-bottom: 5px solid #ff9800;
        margin-bottom: 15px;
    }

    .auth-one-bg .slide .carousel-indicators {
        bottom: 25px;
    }

    .auth-page-wrapper .auth-page-content {
        padding-bottom: 0px !important;
    }

    .auth-page-content .card {
        margin-bottom: 0rem;
    }

    .data-tabs .wrapper .nav-tabs button {
        font-size: 17px;
        color: black;
    }

    .data-tabs .wrapper .nav-tabs .active {
        background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
        */ color: white;
        background: orange;
        border-radius: 0px;
    }

    .carousel-caption.d-none.d-md-block {
        background-color: #000000bf;
        left: 0;
        width: 100%;
        bottom: 0;
    }

    .carousel-indicators {
        display: none;
    }

    .custom-banner-caption {
        color: white !important;
    }

    .announcement-heading {
        font-size: 1.2em;
        font-weight: 600;
    }

    .data-tabs .tab-pane ul li {
        font-size: 1em;
        padding: 5px 0;

    }

    .main-logo {
        padding: 10px;
    }

    .data-tabs .nav-item .nav-link {
        background-image: none;
    }

    /* .right-sec{
        box-shadow: 5px 10px 18px #888888;
    } */
    .navbar-brand-box {
        background: #fff;
    }

    [data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
        color: white !important;
    }

    .header-buttons .btn-primary {
        margin-right: 10px;
        padding: 6px 15px;
        font-weight: 600;
        background-color: #207005;
        border: none;
        box-shadow: 0px 2px 7px #888888;
    }

    .header-buttons .btn-secondary {
        margin-right: 10px;
        padding: 6px 15px;
        font-weight: 600;
        background-color: #72a055;
        border: none;
        box-shadow: 0px 2px 7px #888888;
    }


    .right-sec {
        border-left: 5px solid #ede7e7;
    }

    .tabdiv {
        background: white;
        padding: 20px;
        margin-top: 10px;
        border: 10px solid #dfdbd5;
    }

    .nav-tabs {
        border-bottom: 0px;
    }

    div#myTabContent {
        border: 1px solid #cccccc;
    }

    .frontfooter footer {
        padding: 20px calc(1.5rem / 2);
        position: static;
        color: #000;
        height: 60px;
        background-color: #f9f9f9;
        margin-top: 30px;
        border-top: 1px solid #e1dfdf;
    }

    span.logo-sm img {
        width: 69px;
    }

    .seperatesec {
        margin-top: 20px;
    }

    .simplebar-content li.nav-item:hover {
        background: #4caf50;
    }

    .sectitle {
        font-size: 14px;
    }

    .required {
        color: red;
    }

    .customtextarea {
        height: 120px;
    }

    ul.boxsection {
        margin: 0;
        padding: 0;
    }

    ul.boxsection li {
        list-style-type: none;
        padding: 7px 0;
        border-bottom: 1px solid #efeded;
    }

    .boxcard .col:nth-child(1) {
        background: #effcfb;
    }

    .boxcard .col:nth-child(2) {
        background: #fdfdfd;
    }

    .boxcard .col:nth-child(3) {
        background: #effcfb;
    }

    .boxcard .col:nth-child(4) {
        background: #fdfdfd;
    }

    .boxcard .col:nth-child(5) {
        background: #effcfb;
    }

    /* --registration-form css  */
    .custom-tab-content {
        padding-top: 0 !important;
        padding-bottom: 0px !important;
    }

    .custom-tab-nav {
        background: white;

    }

    .custom-tab-nav .nav-link {
        border-radius: 0 !important;
        border-bottom: 1px solid #e9ebec;
        border-right: 1px solid #e9ebec;
        font-size: 14px;
        padding: 10px;
    }

    .custom-tab-nav .nav-link.active,
    .custom-tab-nav .show>.nav-link {
        color: rgb(255, 255, 255) !important;
        background-color: #2c8c6d;
        border-bottom: #2c8c6d !important;
        /* border-bottom: #207005 !important; */
        position: relative;
    }

    .custom-tab-nav .nav-link:hover,
    .custom-tab-nav .nav-link:focus {
        border-bottom: 1px solid #207005;
        border-radius: 0;
        font-size: 14px;
        transition: background-color 0.20s linear;
    }

    .custom-tab-nav .nav-link.active:after {
        content: "";
        position: absolute;
        bottom: -16px;
        left: 50%;
        border: 8px solid transparent;
        border-top-color: #2c8c6d;
        z-index: 999;
    }

    .reg-form-btns {
        margin-bottom: 15px;
    }

    .reg-form-btns .btn-secondary {
        color: #fff;
        background-color: #405189;
        border-color: #405189;
    }

    .btn-soft-success:active,
    .btn-soft-success:focus,
    .btn-soft-success:hover {
        border: none;
    }

    .custom-tab-nav ul {
        padding: 0px;
        margin: 0px;
    }

    .custom-tab-nav ul li {
        padding: 0px;
        margin: 0px;
        display: inline-block;
        list-style: none;
    }
</style>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">processor Profile</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">processor Profile</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <form method="post" enctype="multipart/form-data" id="registration" action="{{ route('superadmin.processorUseredit.finalSave', $userdetails->id) }}">
            @csrf
            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                    <a class="nav-link" id="step1-tab" data-bs-toggle="tab_" href="{{ route('superadmin.processorUseredit', $userdetails->id) }}">General Information</a>

                    <a class="nav-link" id="step3-tab" data-bs-toggle="tab_" href="{{ route('superadmin.processorUseredit.step1', $userdetails->id) }}">Geo Tagging of
                        Processing Details</a>
                    <a class="nav-link" id="step4-tab" data-bs-toggle="tab_" href="{{ route('superadmin.processorUseredit.step2', $userdetails->id) }}">Products Details</a>
                    <a class="nav-link active" id="step4-tab" data-bs-toggle="tab_" href="{{ route('superadmin.processorUseredit.step3', $userdetails->id) }}">List of Documents</a>
                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1">
                                दस्तावेज़ों की सूची/List of Documents
                            </h4>

                        </div>
                        <div class="flex-shrink-0">
                            @if (session('error'))
                            <div class="alert alert-danger">
                                {{ session('error') }}
                            </div>
                            @endif
                            @if (session('success'))
                            <div class="alert alert-success">
                                {{ session('success') }}
                            </div>
                            @endif
                            @if ($errors)
                            @foreach ($errors->all() as $error)
                            <div class="alert alert-danger">{{ $error }}</div>
                            @endforeach
                            @endif
                        </div>
                        <!-- end card header -->
                        <div class="card-body">
                            <div class="live-preview">

                                <div class="row white-inner">
                                    @if (!empty($processor_document))
                                    <input type="hidden" class="form-control" value="{{ $processor_document->id }}" name="row_id" />
                                    @endif
                                    <div class="col-xxl-3 col-md-6 gy-3">
                                        <div>
                                            {{-- <label class="form-label">आधार कार्ड/Aadhar Card<span class="required"> </span></label> --}}
                                            <label class="form-label">अतिरिक्त दस्तावेज़ अपलोड करें/Upload Additional Document<span class="required"> </span></label>
                                            <input type="file" class="form-control upload_document" id="aadhar_card" name="aadhar_card_image_path">
                                            @if (!empty($processor_document->aadhar_card_image_path))
                                            <input type="hidden" name="aadhar_card_image_path_edit" value="{{ $processor_document->aadhar_card_image_path ?? '' }}">
                                            <a target="_BLANK" href="{{ asset('public/processor/documents/aadhar_card/' . $processor_document->aadhar_card_image_path) }}" class="text-decoration-underline">See Doc</a>
                                            @endif
                                            <p>Upload only PDF up to 1MB</p>
                                        </div>
                                    </div>
                                    {{-- <div class="col-xxl-3 col-md-6 gy-3">
                                        <div>
                                            <label class="form-label">पैन/PAN <span class="required"> </span></label>
                                            <input type="file" class="form-control upload_document" name="pan_card_image_path" id="pan_card">
                                            @if (!empty($processor_document->pan_card_image_path))
                                            <input type="hidden" name="pan_card_image_path_edit" value="{{ $processor_document->pan_card_image_path ?? '' }}">
                                            <a target="_BLANK" href="{{ asset('public/processor/documents/pan_card/' . $processor_document->pan_card_image_path) }}" class="text-decoration-underline">See Doc</a>
                                            @endif
                                            <p>Upload only PDF up to 1MB</p>
                                        </div>
                                    </div> --}}
                                    <!-- <div class="col-xxl-3 col-md-6 gy-3">
                                            <div>
                                                <label class="form-label">ISO 22000<span class="required">
                                                    </span></label>
                                                <input type="file" class="form-control upload_document" name="passbook_image_path"
                                                    id="bank_copy_passbook">
                                                @if (!empty($processor_document->passbook_image_path))
                                                    <input type="hidden" name="passbook_image_path_edit"
                                                        value="{{ $processor_document->passbook_image_path ?? '' }}">
                                                    <a target="_BLANK"
                                                        href="{{ asset('public/processor/documents/bank_copy_passbook/' . $processor_document->passbook_image_path) }}"
                                                        class="text-decoration-underline">See Doc</a>
                                                @endif
                                                <p>Upload only PDF up to 1MB</p>
                                            </div>
                                        </div>
                                    <div class="col-xxl-3 col-md-6 gy-3">
                                            <div>
                                                <label class="form-label">ISO 9000<span
                                                        class="required"> </span></label>
                                                <input type="file" class="form-control upload_document"
                                                    name="contact_person_sign_image_path"
                                                    id="contact_person_sign_thumb_Impression">
                                                @if (!empty($processor_document->contact_person_sign_image_path))
                                                    <input type="hidden" name="contact_person_sign_image_path_edit"
                                                        value="{{ $processor_document->contact_person_sign_image_path ?? '' }}">
                                                    <a target="_BLANK"
                                                        href="{{ asset('public/processor/documents/contact_person_sign_thumb_impression/' . $processor_document->contact_person_sign_image_path) }}"
                                                        class="text-decoration-underline">See Doc</a>
                                                @endif
                                                <p>Upload only PDF up to 1MB</p>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-6 gy-3">
                                            <div>
                                                <label class="form-label">HACCP<span
                                                        class="required"> </span></label>
                                                <input type="file" class="form-control upload_document"
                                                    name="live_signature_image_path" id="live_signature_thumb_impression">
                                                @if (!empty($processor_document->live_signature_image_path))
                                                    <input type="hidden" name="live_signature_image_path_edit"
                                                        value="{{ $processor_document->live_signature_image_path ?? '' }}">
                                                    <a target="_BLANK"
                                                        href="{{ asset('public/processor/documents/live_signature_thumb_impression/' . $processor_document->live_signature_image_path) }}"
                                                        class="text-decoration-underline">See Doc</a>
                                                @endif
                                                <p>Upload only PDF up to 1MB</p>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-6 gy-3">
                                            <div>
                                                <label class="form-label">Layout of processing unit<span
                                                        class="required"> </span></label>
                                                <input type="file" class="form-control upload_document"
                                                    name="live_signature_image_path" id="live_signature_thumb_impression">
                                                @if (!empty($processor_document->live_signature_image_path))
                                                    <input type="hidden" name="live_signature_image_path_edit"
                                                        value="{{ $processor_document->live_signature_image_path ?? '' }}">
                                                    <a target="_BLANK"
                                                        href="{{ asset('public/processor/documents/live_signature_thumb_impression/' . $processor_document->live_signature_image_path) }}"
                                                        class="text-decoration-underline">See Doc</a>
                                                @endif
                                                <p>Upload only PDF up to 1MB</p>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-6 gy-3">
                                            <div>
                                                <label class="form-label">Other<span
                                                        class="required"> </span></label>
                                                <input type="file" class="form-control upload_document"
                                                    name="live_signature_image_path" id="live_signature_thumb_impression">
                                                @if (!empty($processor_document->live_signature_image_path))
                                                    <input type="hidden" name="live_signature_image_path_edit"
                                                        value="{{ $processor_document->live_signature_image_path ?? '' }}">
                                                    <a target="_BLANK"
                                                        href="{{ asset('public/processor/documents/live_signature_thumb_impression/' . $processor_document->live_signature_image_path) }}"
                                                        class="text-decoration-underline">See Doc</a>
                                                @endif
                                                <p>Upload only PDF up to 1MB</p>
                                            </div>
                                        </div> -->

                                </div>

                                <!--address sec end-->
                                {{-- <div class="col-xxl-3 col-md-7 gy-4 form-check">
                                    <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                    <label style="color: blue; width: 1170px ">I acknowledge that the usage of  Aadhaar ,PAN for relevant purpose is in accordance with the applicable laws and regulations, and I hereby consent to such usage.</label>
                                </div> --}}

                                <div class="row">
                                    <div class="col-lg-12 gy-4">
                                        <div class="hstack gap-2">
                                            <a href="{{ route('superadmin.processorUseredit.step2', $userdetails->id) }}" class="btn btn-soft-success">
                                                Back
                                            </a>
                                            <button type="submit" class="btn btn-primary">
                                                Submit
                                            </button>

                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>



@endsection
@push('script')
<script>
    $(document).ready(function() {
        $("body").on("click", ".add-more", function() {
            var html = $(".after-add-more").first().clone();
            $(html).find(".change").html(
                "<label for=''>&nbsp;</label><br/><a class='btn btn-danger remove'><i class='ri-close-line'></i></a>"
            );
            $(".after-add-more").last().after(html);
        });

        $("body").on("click", ".remove", function() {
            $(this).parents(".after-add-more").remove();
        });
    });


    $('.upload_document').on('change', function() {
            var $this = $(this);
            var file = $this[0].files[0];
            var fileType = file.type;
            var fileSize = file.size;
            var allowedTypes = ['application/pdf'];

            // Check for file type
            if (!allowedTypes.includes(fileType)) {
                Swal.fire({
                    icon: 'error',
                    title: 'Invalid File Extension',
                    text: 'Please upload PDF only.',
                });
                $this.val("");
                return false;
            }

            // Check for file size
            if (fileSize > 1000000) { // 2 MB in bytes
                Swal.fire({
                    icon: 'error',
                    title: 'File Size Too Large',
                    text: 'Please upload files of size 1 MB or less only.',
                });
                $this.val("");
                return false;
            }
        });
</script>
@endpush
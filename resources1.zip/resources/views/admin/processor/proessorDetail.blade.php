@extends('admin.layouts.app')
@section('content')



    <style>
        .overlay {
            background: rgb(0 0 0 / 50%);
            position: fixed;
            top: 0;
            z-index: 11111;
            left: 0;
            right: 0;
            bottom: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            display: none;
        }

        .loader {
            position: fixed !important;
            left: 50% !important;
            margin-left: -4em !important;
            top: 20em !important;
        }

        .wrapper {
            max-width: 1240px;
            margin: 0 auto;
        }

        .white-bg {
            background-color: white;
            /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
            border-bottom: 5px solid #ff9800;
            margin-bottom: 15px;
        }

        .auth-one-bg .slide .carousel-indicators {
            bottom: 25px;
        }

        .auth-page-wrapper .auth-page-content {
            padding-bottom: 0px !important;
        }

        .auth-page-content .card {
            margin-bottom: 0rem;
        }

        .data-tabs .wrapper .nav-tabs button {
            font-size: 17px;
            color: black;
        }

        .data-tabs .wrapper .nav-tabs .active {
            background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
            */ color: white;
            background: orange;
            border-radius: 0px;
        }

        .carousel-caption.d-none.d-md-block {
            background-color: #000000bf;
            left: 0;
            width: 100%;
            bottom: 0;
        }

        .carousel-indicators {
            display: none;
        }

        .custom-banner-caption {
            color: white !important;
        }

        .announcement-heading {
            font-size: 1.2em;
            font-weight: 600;
        }

        .data-tabs .tab-pane ul li {
            font-size: 1em;
            padding: 5px 0;

        }

        .main-logo {
            padding: 10px;
        }

        .data-tabs .nav-item .nav-link {
            background-image: none;
        }

        /* .right-sec{
                box-shadow: 5px 10px 18px #888888;
            } */
        .navbar-brand-box {
            background: #fff;
        }

        [data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
            color: white !important;
        }

        .header-buttons .btn-primary {
            margin-right: 10px;
            padding: 6px 15px;
            font-weight: 600;
            background-color: #207005;
            border: none;
            box-shadow: 0px 2px 7px #888888;
        }

        .header-buttons .btn-secondary {
            margin-right: 10px;
            padding: 6px 15px;
            font-weight: 600;
            background-color: #72a055;
            border: none;
            box-shadow: 0px 2px 7px #888888;
        }


        .right-sec {
            border-left: 5px solid #ede7e7;
        }

        .tabdiv {
            background: white;
            padding: 20px;
            margin-top: 10px;
            border: 10px solid #dfdbd5;
        }

        .nav-tabs {
            border-bottom: 0px;
        }

        div#myTabContent {
            border: 1px solid #cccccc;
        }

        .frontfooter footer {
            padding: 20px calc(1.5rem / 2);
            position: static;
            color: #000;
            height: 60px;
            background-color: #f9f9f9;
            margin-top: 30px;
            border-top: 1px solid #e1dfdf;
        }

        span.logo-sm img {
            width: 69px;
        }

        .seperatesec {
            margin-top: 20px;
        }

        .simplebar-content li.nav-item:hover {
            background: #4caf50;
        }

        .sectitle {
            font-size: 14px;
        }

        .required {
            color: red;
        }

        .customtextarea {
            height: 120px;
        }

        ul.boxsection {
            margin: 0;
            padding: 0;
        }

        ul.boxsection li {
            list-style-type: none;
            padding: 7px 0;
            border-bottom: 1px solid #efeded;
        }

        .boxcard .col:nth-child(1) {
            background: #effcfb;
        }

        .boxcard .col:nth-child(2) {
            background: #fdfdfd;
        }

        .boxcard .col:nth-child(3) {
            background: #effcfb;
        }

        .boxcard .col:nth-child(4) {
            background: #fdfdfd;
        }

        .boxcard .col:nth-child(5) {
            background: #effcfb;
        }

        /* --registration-form css  */
        .custom-tab-content {
            padding-top: 0 !important;
            padding-bottom: 0px !important;
        }

        .custom-tab-nav {
            background: white;

        }

        .custom-tab-nav .nav-link {
            border-radius: 0 !important;
            border-bottom: 1px solid #e9ebec;
            border-right: 1px solid #e9ebec;
            font-size: 14px;
            padding: 10px;
        }

        .custom-tab-nav .nav-link.active,
        .custom-tab-nav .show>.nav-link {
            color: rgb(255, 255, 255) !important;
            background-color: #2c8c6d;
            border-bottom: #2c8c6d !important;
            /* border-bottom: #207005 !important; */
            position: relative;
        }

        .custom-tab-nav .nav-link:hover,
        .custom-tab-nav .nav-link:focus {
            border-bottom: 1px solid #207005;
            border-radius: 0;
            font-size: 14px;
            transition: background-color 0.20s linear;
        }

        .custom-tab-nav .nav-link.active:after {
            content: "";
            position: absolute;
            bottom: -16px;
            left: 50%;
            border: 8px solid transparent;
            border-top-color: #2c8c6d;
            z-index: 999;
        }

        .reg-form-btns {
            margin-bottom: 15px;
        }

        .reg-form-btns .btn-secondary {
            color: #fff;
            background-color: #405189;
            border-color: #405189;
        }

        .btn-soft-success:active,
        .btn-soft-success:focus,
        .btn-soft-success:hover {
            border: none;
        }

        .custom-tab-nav ul {
            padding: 0px;
            margin: 0px;
        }

        .custom-tab-nav ul li {
            padding: 0px;
            margin: 0px;
            display: inline-block;
            list-style: none;
        }

        /* -------  */
        .btn-email {
            font-size: 13px;
            padding: 1px 7px;
            line-height: 17px;

        }

        .btn-mailsend {
            font-size: 13px;
            padding: 1px 7px;
            line-height: 17px;
        }

        .btn-verify {
            font-size: 13px;
            padding: 1px 7px;
            line-height: 34px;
        }

        .inputEmail .input-group-append {
            display: flex;
            align-items: end;
        }

        .inputEmail .validateEmailId {
            border-radius: 4px 0 0 4px;
        }

        .input-group-append .verifiEmail_otp,
        .input-group-append .resendEmail_otp {
            margin-left: 10px;
        }

        .login-pass.otp-email {
            margin-top: 5px
        }

        .login-pass.otp-email .inp-b {
            border-radius: 0 4px 4px 0
        }
    </style>
    <!-- start page title -->
    <div class="overlay">
        <div class="loader"></div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">प्रोसेसर प्रोफ़ाइल/Processor Profile</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Processor Profile</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">
            <form method="post" enctype="multipart/form-data" id="registration"
                action="{{ route('superadmin.processorUseredit.stepsave', $userdetails->id) }}">
                @csrf
                <nav>
                    <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                        <a class="nav-link active" id="step1-tab" data-bs-toggle="tab_"
                            href="{{ route('superadmin.processorUseredit', $userdetails->id) }}">General Information</a>

                        <a class="nav-link" id="step3-tab" data-bs-toggle="tab_"
                            href="{{ route('superadmin.processorUseredit.step1', $userdetails->id) }}">Geo Tagging of
                            Processing Unit</a>
                        <a class="nav-link" id="step4-tab" data-bs-toggle="tab_"
                            href="{{ route('superadmin.processorUseredit.step2', $userdetails->id) }}">Products Details</a>
                        <a class="nav-link" id="step4-tab" data-bs-toggle="tab_"
                            href="{{ route('superadmin.processorUseredit.step3', $userdetails->id) }}">List of Documents</a>
                    </div>
                </nav>
                <div class="tab-content py-4 custom-tab-content">
                    <div class="tab-pane fade show active" id="step1">
                        <div class="card">
                            <div class="card-header align-items-center d-flex">
                                <h4 class="card-title mb-0 flex-grow-1">
                                    प्रोसेसर की जानकारी/Processor Information
                                </h4>
                                <div class="flex-shrink-0">
                                    @if (session('error'))
                                        <div class="alert alert-danger">
                                            {{ session('error') }}
                                        </div>
                                    @endif
                                    @if (session('success'))
                                        <div class="alert alert-success">
                                            {{ session('success') }}
                                        </div>
                                    @endif
                                    @if ($errors)
                                        @foreach ($errors->all() as $error)
                                            <div class="alert alert-danger">{{ $error }}</div>
                                        @endforeach
                                    @endif
                                </div>

                            </div>
                            <!-- end card header -->
                            <div class="card-body">
                                <div class="live-preview">

                                    <div class="row seperatesec_  white-inner">
                                        {{-- <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Date of Registration by CB/पंजीकरण की तारीख<span class="required">
                                                        *</span></label>
                                                <input type="text" class="form-control" id="date_of_registration"
                                                    value="{{ date('d-m-Y', strtotime($userdetails->created_at)) ?? '' }}"
                                                    placeholder="" name="date_of_registration" required readonly>
                                            </div>
                                        </div> --}}
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">पैन /PAN <span class="required">
                                                        *</span></label>
                                                <input type="text" class="form-control" id="user_name"
                                                    value="{{ $userdetails->user_name ?? '' }}"
                                                    placeholder="processor first name" name="user_name" required readonly>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">प्रोसेसर का नाम/Name of Processor<span class="required">
                                                        *</span></label>
                                                <input type="text" class="form-control" id="processor_first_name"
                                                    value="{{ $userdetails->first_name ?? '' }}"
                                                    placeholder="processor first name" name="processor_first_name" required readonly>
                                            </div>
                                        </div>

                                        

                                        {{-- <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label for="labelInput" class="form-label">Photo of the Processing Unit/प्रोसेसिंग यूनिट का फोटो<span
                                                        class="required">
                                                    </span></label>
                                                <input type="file" class="form-control upload_document" name="processor_photo"
                                                    id="processor_photo">
                                                @if (isset($userdetails->processor_photo) && !empty($userdetails->processor_photo))
                                                    <a href="{{ asset('public/processor_photo/' . $userdetails->processor_photo) }}"
                                                        target="_BLANK" class="text-decoration-underline">See Doc</a>
                                                    <input type="hidden" name="processor_photo_edit"
                                                        value="{{ $userdetails->processor_photo }}">
                                                @endif
                                                    <p>Upload only PDF up to 1MB</p>
                                            </div>
                                        </diV> --}}
                                    </diV>

                                    <div class="row white-inner">
                                        <div class="sectitle">
                                            <label for="labelInput" class="form-label blue-ht">प्रसंस्करण इकाई का पता/Address of Processing Unit</label>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div class="row">
                                                <div class="col-xx-12 col-md-12">
                                                    <label for="labelInput" class="form-label"> पता/Address
                                                        <span class="required">*</span></label>
                                                    <textarea placeholder="Address" class="form-control customtextarea" name="address" readonly>{{ $userdetails->address ?? '' }}</textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xxl-9 col-md-9  ">
                                            <div class="row  ">

                                                <div class="col-xxl-4 col-md-4 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">राज्य/State <span
                                                                class="required">*</span></label>
                                                                <input type="hidden" value="{{ $userdetails->ref_state_id }}" name="ref_state_id" >
                                                         <select class="form-select state" name=""
                                                            id="state" disabled >
                                                            <option value="">-Select State-</option>
                                                            @forelse(getAllState() as $state)
                                                                <option value="{{ $state->id }}"
                                                                    {{ $userdetails->ref_state_id == $state->id ? 'selected' : '' }}>
                                                                    {{ $state->state_name }}</option>
                                                            @empty
                                                            @endforelse
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-4 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">ज़िला/District <span
                                                                class="required">*</span></label>
                                                                <input type="hidden" value="{{ $userdetails->ref_district_id }}" name="ref_district_id" >
                                                        <select class="form-select district" name=""
                                                            id="district" disabled>
                                                            <option value="">Select District</option>
                                                            @forelse(getDistrictByStateID($userdetails->ref_state_id) as $district)
                                                                <option value="{{ $district->id }}"
                                                                    {{ $userdetails->ref_district_id == $district->id ? 'selected' : '' }}>
                                                                    {{ $district->district_name }}</option>
                                                            @empty
                                                            @endforelse
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-4 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">तालुका/मंडल/Taluka/Mandal
                                                            <span class="required">*</span></label>
                                                            <input type="hidden" value="{{ $userdetails->ref_block_tehsil_id }}" name="ref_block_tehsil_id" >
                                                        <select class="form-select block_tehsil"
                                                            name="" id="block_tehsil" disabled>
                                                            <option value="">Select Taluka/Mandal</option>
                                                            @forelse(getBlockTehsilByDistrictID($userdetails->ref_district_id) as $block)
                                                                <option value="{{ $block->id }}"
                                                                    {{ $userdetails->ref_block_tehsil_id == $block->id ? 'selected' : '' }}>
                                                                    {{ $block->block_tehsil_name }}</option>
                                                            @empty
                                                            @endforelse
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-6 gy-3">
                                                    <div>
                                                        <label class="form-label">गाँव/Village </label>
                                                        <input type="hidden" value="{{ $userdetails->ref_village_id }}" name="ref_village_id" >
                                                        <select class="form-select village" name=""
                                                            id="village" disabled >
                                                            <option value="">Select Village</option>
                                                            @forelse(getVillageByBlock($userdetails->ref_block_tehsil_id) as $village)
                                                                <option value="{{ $village->id }}"
                                                                    {{ $userdetails->ref_village_id == $village->id ? 'selected' : '' }}>
                                                                    {{ $village->village_name }}</option>
                                                            @empty
                                                            @endforelse
                                                        </select>
                                                    </div>
                                                </div>



                                                <div class="col-xxl-4 col-md-6 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">पिन कोड/Pin Code<span
                                                                class="required">*</span></label>
                                                        <input type="text" class="form-control numbersonly"
                                                            id="placeholderInput" placeholder="Pin Code" name="pin"
                                                            value="{{ $userdetails->pin ?? '' }}" readonly
                                                            maxlength="6" />
                                                    </div>
                                                </div>

                                            </div>
                                        </div>

                                    </div>

                                    <div class="row seperatesec white-inner">

                                        <div class="sectitle">
                                            <label for="labelInput" class="form-label blue-ht">प्रोसेसर मैनेजर का विवरण/Details of Processor Manager</label>
                                        </div>
                                        <div class="col-xxl-3 col-md-4 gy-3">
                                            <div>
                                                <label for="labelInput" class="form-label">संपर्क व्यक्ति का पहला नाम/Contact Person first name<span
                                                        class="required"> *</span></label>
                                                <input type="text" class="form-control"
                                                    value="{{ $userdetails->contact_person_first_name ?? '' }}"
                                                    id="contact_person_first_name" name="contact_person_first_name"
                                                    placeholder="Contact Person first name" readonly>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-4 gy-3">
                                            <div>
                                                <label for="labelInput" class="form-label">संपर्क व्यक्ति मध्य नाम/Contact Person middle name<span
                                                        class="required"></span></label>
                                                <input type="text" class="form-control"
                                                    value="{{ $userdetails->contact_person_middle_name ?? '' }}"
                                                    id="contact_person_middle_name" name="contact_person_middle_name"
                                                    placeholder="Contact Person middle name" readonly>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-4 gy-3">
                                            <div>
                                                <label for="labelInput" class="form-label">संपर्क व्यक्ति का अंतिम नाम/Contact Person last name<span
                                                        class="required"> *</span></label>
                                                <input type="text" class="form-control"
                                                    value="{{ $userdetails->contact_person_last_name ?? '' }}"
                                                    id="contact_person_last_name" name="contact_person_last_name"
                                                    placeholder="Contact Person last name" readonly>
                                            </div>
                                        </div>
                                        
                                        <div class="col-xxl-3 col-md-4 gy-3">
                                            <div>
                                                <label class="form-label">लिंग/Gender<span class="required"> *</span></label>
                                                <input type="hidden" value="{{ $userdetails->contact_person_gender }}" name="contact_person_gender" >
                                                <select class="form-select" name="contact_person_gender"
                                                    id="contact_person_gender" disabled>
                                                    <option value="">--Select--</option>
                                                    <option
                                                        {{ !empty($userdetails) && $userdetails->contact_person_gender == 1 ? 'selected' : '' }}
                                                        value="1">Male</option>
                                                    <option
                                                        {{ !empty($userdetails) && $userdetails->contact_person_gender == 2 ? 'selected' : '' }}
                                                        value="2">Female</option>
                                                    <option
                                                        {{ !empty($userdetails) && $userdetails->contact_person_gender == 3 ? 'selected' : '' }}
                                                        value="3">Other</option>

                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-4 gy-3">
                                            <div>
                                                <label class="form-label">संपर्क व्यक्ति का मोबाइल नंबर/Contact Person Mobile Number<span
                                                        class="required">
                                                    </span></label>
                                                <input type="text" class="form-control numbersonly"
                                                    value="{{ $userdetails->contact_person_mobile_number ?? '' }}"
                                                    id="contact_person_mobile" name="contact_person_mobile"
                                                    placeholder="Mobile Number" maxlength="10" readonly>
                                            </div>
                                        </div>
                                        <!-- <div class="col-xxl-3 col-md-4 gy-3">
                                            <div>
                                                <label class="form-label">Company PAN Number<span class="required">
                                                    </span></label>
                                                <input type="text" class="form-control pan" name="pan_number"
                                                    id="pan_number"
                                                    value="{{ $userdetails->contact_person_pan_number ?? '' }}"
                                                    placeholder="PAN Number">
                                            </div>
                                        </div> -->

                                        <div class="col-xxl-3 col-md-4 gy-3">
                                            <div>
                                                <label class="form-label">संपर्क व्यक्ति आधार नंबर/Contact Person Aadhaar No.<span
                                                        class="required">
                                                    </span></label>

                                                     @php
                                                         $maskedAadhar = '';
                                                        try {
                                                            if ($userdetails->contact_person_aadhar_number) {
                                                                $decryptedAadhar = Crypt::decrypt(
                                                                    $userdetails->contact_person_aadhar_number,
                                                                );
                                                                $maskedAadhar = maskAadhaarNumber($decryptedAadhar);
                                                            }
                                                        } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
                                                            $maskedAadhar = 'Invalid Aadhaar Number';
                                                        }
                                                     @endphp
                                                <input type="text" class="form-control"
                                                    name="contact_person_aadhar_number" id="aadhar_number"     
                                                    value="{{$maskedAadhar}}"
                                                    placeholder="Aadhar Number" readonly>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-4 gy-3">



                                            <div class="inputEmail  col-12 col-sm-12 col-md-12 col-lg-12">
                                                <div class="form-group d-flex justify-content-center ge-otp-form">
                                                    <div class="col-12 col-sm-12 col-md-10 col-lg-12">
                                                        <label>ईमेल आईडी/Email ID<span class="text-danger">*</span></label>
                                                        <input
                                                            class="form-control validateEmailId col-12 col-sm-12 col-md-12 col-lg-12"
                                                            type="text"
                                                            value="{{ $userdetails->contact_person_email }}"
                                                            placeholder="Email Id" id="email_id1"
                                                            name="contact_person_email"  readonly/>
                                                    </div>
                                                    {{-- <div class="input-group-append col-12 col-sm-12 col-md-2 col-lg-2">
                                                        <button type="button"
                                                            class="btn-email btn btn-outline-success waves-effect waves-light visitorCat2">Get
                                                            OTP</button>
                                                        <button type="button"
                                                            class="btn btn-ghost-success waves-effect waves-light btn-mailsend"
                                                            style="display:none">Mail Send</button>
                                                        <button type="button"
                                                            class="btn btn-ghost-success waves-effect waves-light btn-verify"
                                                            style="display:none">Verified</button>
                                                    </div> --}}
                                                </div>
                                                {{-- <div class="verify-email justify-content-center">
                                                    <div class="login-pass mb-4 otp-email col-12 col-sm-12 col-md-5 col-lg-12 pl-2"
                                                        style="display:none">
                                                        <div class="input-group">
                                                            <span class="input-group-text mdi mdi-key"
                                                                id="inputGroup-sizing-default"></span>
                                                            <input type="text" class="form-control inp-b"
                                                                aria-label="Sizing example input"
                                                                aria-describedby="inputGroup-sizing-default"
                                                                id="email_otp1">
                                                            <div class="input-group-append">
                                                                <a href="javascript:void(0)"
                                                                    class="verifiEmail_otp btn btn-outline-success waves-effect waves-light">Verify</a>
                                                                <a
                                                                    href="javascript:void(0)"class="resendEmail_otp btn btn-outline-danger waves-effect waves-light">Resend</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div> --}}
                                            </div>
                                        </div>

                                        {{-- <div class="col-xxl-3 col-md-4 gy-3">
                                            <div>
                                                <label class="form-label">Contact Person Photo<span class="required">
                                                    </span></label>
                                                <input type="file" class="form-control" name="contact_person_photo"
                                                    id="contact_person_photo">
                                                @if (isset($userdetails->contact_person_photo) && !empty($userdetails->contact_person_photo))
                                                    <a href="{{ asset('public/contact_person_photo/' . $userdetails->contact_person_photo) }}"
                                                        target="_BLANK" class="text-decoration-underline">See Doc</a>
                                                    <input type="hidden" name="contact_person_photo_edit"
                                                        value="{{ $userdetails->contact_person_photo }}">
                                                @endif
                                            </div>
                                        </div> --}}

                                        <div class="sectitle gy-3">
                                            <label for="labelInput" class="form-label blue-ht">
                                                प्रोसेसर मैनेजर का पता/Address of Processor Manager</label>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div class="row">
                                                <div class="col-xx-12 col-md-12">
                                                    <label for="labelInput" class="form-label">संपर्क व्यक्ति का पता/Address of Contact Person
                                                         <span class="required">*</span></label>
                                                    <textarea placeholder="Address" class="form-control customtextarea" name="processor_address"  required>{{ $userdetails->processor_address ?? '' }}</textarea>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xxl-9 col-md-9  ">
                                            <div class="row  ">
                                                <div class="col-xxl-4 col-md-4 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">राज्य/State <span
                                                                class="required">*</span></label>
                                                        <select class="form-select state" name="processor_state_id"
                                                            required >
                                                            <option value="">Select State</option>
                                                            @forelse(getAllState() as $state)
                                                                <option value="{{ $state->id }}"
                                                                    {{ $userdetails->processor_state_id == $state->id ? 'selected' : '' }}>
                                                                    {{ $state->state_name }}</option>
                                                            @empty
                                                            @endforelse

                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-xxl-4 col-md-4 gy-3">
                                                    <div>

                                                        <label for="labelInput" class="form-label">ज़िला/District <span
                                                                class="required">*</span></label>
                                                        <select class="form-select district" name="processor_district_id"
                                                            id="district" required >
                                                            <option value="">-Select District-</option>
                                                            @forelse(getDistrictByStateID($userdetails->processor_state_id) as $district)
                                                                <option value="{{ $district->id }}"
                                                                    {{ $userdetails->processor_district_id == $district->id ? 'selected' : '' }}>
                                                                    {{ $district->district_name }}</option>
                                                            @empty
                                                            @endforelse
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-4 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">तालुका/मंडल/Taluka/Mandal
                                                            <span class="required">*</span></label>
                                                        <select class="form-select block_tehsil"
                                                            name="processor_block_tehsil_id" id="block_tehsil" required >
                                                            <option value="">-Select Taluka/Mandal-</option>
                                                            @forelse(getBlockTehsilByDistrictID($userdetails->processor_district_id) as $block)
                                                                <option value="{{ $block->id }}"
                                                                    {{ $userdetails->processor_block_tehsil_id == $block->id ? 'selected' : '' }}>
                                                                    {{ $block->block_tehsil_name }}</option>
                                                            @empty
                                                            @endforelse
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-4 gy-3">
                                                    <div>

                                                        <label class="form-label">गाँव/Village </label>
                                                        <select class="form-select village" name="processor_village_id"
                                                            id="village" required >
                                                            <option value="">-Select Village-</option>
                                                            @forelse(getVillageByBlock($userdetails->processor_block_tehsil_id) as $village)
                                                                <option value="{{ $village->id }}"
                                                                    {{ $userdetails->processor_village_id == $village->id ? 'selected' : '' }}>
                                                                    {{ $village->village_name }}</option>
                                                            @empty
                                                            @endforelse
                                                        </select>
                                                    </div>
                                                </div>



                                                <div class="col-xxl-4 col-md-4 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">पिन कोड/Pin Code<span
                                                                class="required">*</span></label>
                                                        <input type="text" class="form-control numbersonly"
                                                            id="placeholderInput" placeholder="Pin Code" 
                                                            name="processor_pin"
                                                            value="{{ $userdetails->processor_pin ?? '' }}"
                                                            maxlength="6" required />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div> 
                                      
                                        <div class="row seperatesec white-inner">
                                            <div class="sectitle gy-3">
                                                <label for="labelInput" class="form-label blue-ht">प्रोसेसर का बैंक विवरण/Bank Details of the
                                                    Processor</label>
                                            </div>


                                            <div class="col-xxl-3 col-md-4 gy-3">
                                                <div>
                                                    <label class="form-label">बैंक का नाम/Bank Name<span class="required">
                                                        </span></label>
                                                    <select class="form-select" name="ref_bank_id">
                                                        <option value="">Select Bank</option>
                                                        @forelse(getRefBank() as $bank)
                                                            <option value="{{ $bank->id }}"
                                                                {{ isset($userdetails->bankDetails->ref_bank_id) && $userdetails->bankDetails->ref_bank_id == $bank->id ? 'selected' : '' }}>
                                                                {{ $bank->bank_name }}</option>
                                                        @empty
                                                            <option value="">No data found.</option>
                                                        @endforelse
                                                    </select>

                                                </div>
                                            </div>

                                            <div class="col-xxl-3 col-md-4 gy-3">
                                                <div>
                                                    <label class="form-label">खाता संख्या/Account Number<span class="required">
                                                        </span></label>
                                                    <input type="text" class="form-control" name="account_number"
                                                        value="{{ $userdetails->bankDetails->account_number ?? '' }}"
                                                        id="account_number" placeholder="Account Number">
                                                </div>
                                            </div>

                                            <div class="col-xxl-3 col-md-4 gy-3">
                                                <div>
                                                    <label class="form-label">आईएफएससी कोड/IFSC Code<span class="required">
                                                        </span></label>
                                                    <input type="text" class="form-control"
                                                        value="{{ $userdetails->bankDetails->ifsc_code ?? '' }}"
                                                        name="ifsc_code" id="ifsc_code" placeholder="IFSC Code">
                                                </div>
                                            </div>

                                            <div class="col-xxl-3 col-md-4 gy-3">
                                                <div>
                                                    <label class="form-label">शाखा का नाम/Branch Name<span class="required">
                                                        </span></label>
                                                    <input type="text" class="form-control"
                                                        value="{{ $userdetails->bankDetails->branch_name ?? '' }}"
                                                        name="branch_name" id="branch_name" placeholder="Branch Name">
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-4 gy-3">
                                                <div>
                                                    <label class="form-label">पिन कोड/Pin Code<span class="required">
                                                        </span></label>
                                                    <input type="text"
                                                        value="{{ $userdetails->bankDetails->pincode ?? '' }}"
                                                        class="form-control numbersonly" name="pincode" id="pincode"
                                                        placeholder="Pin Code" maxlength="6">
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-4 gy-3">
                                                <div>
                                                    <label class="form-label">पता/Address<span class="required">
                                                        </span></label>
                                                    <textarea name="bank_address" id="address" class="form-control">{{ $userdetails->bankDetails->bank_address ?? '' }}</textarea>
                                                </div>
                                            </div>

                                        </div>

                                        <!--address sec end-->

                                        <div class="row">
                                            <div class="col-lg-12 gy-4">
                                                <div class="hstack gap-2">
                                                    <button type="submit" class="btn btn-primary">
                                                        Save
                                                    </button>
                                                    <a href="{{ route('superadmin.processorUseredit.step1', $userdetails->id) }}"
                                                        class="btn btn-soft-success">
                                                        Next
                                                    </a>

                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
            </form>
        </div>
    </div>



@endsection
@push('script')
    <script>

$('.upload_document').on('change', function() {
            var $this = $(this);
            var file = $this[0].files[0];
            var fileType = file.type;
            var fileSize = file.size;
            var allowedTypes = ['application/pdf'];

            // Check for file type
            if (!allowedTypes.includes(fileType)) {
                Swal.fire({
                    icon: 'error',
                    title: 'Invalid File Extension',
                    text: 'Please upload PDF only.',
                });
                $this.val("");
                return false;
            }

            // Check for file size
            if (fileSize > 1000000) { // 2 MB in bytes
                Swal.fire({
                    icon: 'error',
                    title: 'File Size Too Large',
                    text: 'Please upload files of size 1 MB or less only.',
                });
                $this.val("");
                return false;
            }
        });



        $(".btn-email").click(function(e) {
            e.preventDefault();
            var user_email = $('#email_id1').val();


            if (user_email != "") {
                $(".overlay").show();
                $.ajax({
                    type: 'POST',
                    url: "{{ route('superadmin.usermanagement.email_mobile_OTP') }}",
                    data: {
                        'user_email': user_email
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(resp) {
                        if (resp == 1) {

                            Swal.fire({
                                text: "Please verify OTP send on Email id",
                                icon: 'success',
                                confirmButtonText: 'OK'
                            }).then((result) => {
                                $('.otp-email').show(500);
                                $('#email_id1').val(user_email);
                                $('#email_id1').prop('readonly', true);
                                $('.btn-email').hide(500);
                                $('.btn-mailsend').show(100);
                            });

                        }
                        $(".overlay").hide();
                    }
                });
            } else {
                Swal.fire("", "Please enter Email ID", "error");
            }
        });
        /// check pan number
        $(document).on('change', '.pan', function() {

            var inputvalues = $(this).val();
            var regex = /[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
            if (!regex.test(inputvalues)) {
                console.log(inputvalues);
                $(".pan").val("");
                alert("invalid PAN no");
                return regex.test(inputvalues);
            }
        });

        $(".verifiEmail_otp").click(function(e) {
            e.preventDefault();
            var email_otp = $('#email_otp1').val();
            $(".overlay").show();
            if (email_otp != "") {

                $.ajax({
                    type: 'POST',
                    url: "{{ route('superadmin.usermanagement.email_mobile_OTP_check') }}",
                    data: {
                        'email_otp': email_otp
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(html) {
                        if (html == 0) {
                            Swal.fire("", "Please enter Valid OTP", "error");
                        } else {
                            $('#email_otp').prop('readonly', true);
                            $('.otp-email1').hide(500);
                            $('.btn-email').hide(500);
                            $('.btn-verify').show(500);
                            $('.visitorCat').hide(500);
                            $('.visitorCat1').hide(500);
                            $('.user_detail_page').show(500);
                            $('#email_id').prop('readonly', true);
                            $('.btn-mailsend').hide();
                            $('.login-pass').hide();
                        }
                        $(".overlay").hide();
                    }
                });
            } else {
                Swal.fire("", "Please enter OTP", "error");
            }
        });

        $(".resendEmail_otp").click(function(e) {
            e.preventDefault();
            var user_email = $('#email_id1').val();

            $.ajax({
                type: 'POST',
                url: "{{ route('superadmin.usermanagement.email_mobile_OTP') }}",
                data: {
                    'user_email': user_email
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(html) {
                    Swal.fire("", "Re OTP Send!!", "success");
                }
            });
        });
    </script>
@endpush

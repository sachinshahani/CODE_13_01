@extends('admin.layouts.app') @section('content')

<style>
        .wrapper{
        max-width: 1240px; margin:0 auto;
    }
    .white-bg{
        background-color: white;
        /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
        border-bottom:5px solid #ff9800;
        margin-bottom:15px;
    }
    .auth-one-bg .slide .carousel-indicators {
        bottom: 25px;
    }
    .auth-page-wrapper .auth-page-content{
        padding-bottom: 0px !important;
    }
    .auth-page-content  .card {
         margin-bottom: 0rem;
    }
    .data-tabs .wrapper .nav-tabs button {
        font-size: 17px;
        color: black;
    }
    .data-tabs .wrapper .nav-tabs .active{
        background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f); */
        color: white;
        background: orange;
        border-radius: 0px;
    }
    .carousel-caption.d-none.d-md-block {
        background-color: #000000bf;
        left: 0;
        width: 100%;
        bottom: 0;
    }
    .carousel-indicators {
        display: none;
    }
    .custom-banner-caption {
        color: white !important;
    }
    .announcement-heading{
        font-size: 1.2em;
        font-weight: 600;
    }
    .data-tabs .tab-pane ul li{
    font-size: 1em;
    padding: 5px 0;

    }
    .main-logo{
        padding: 10px;
    }
    .data-tabs .nav-item .nav-link {
        background-image:none ;
    }
    /* .right-sec{
        box-shadow: 5px 10px 18px #888888;
    } */
    .navbar-brand-box {
        background: #fff;
    }

    [data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
        color: white !important;
    }
    .header-buttons .btn-primary {
        margin-right: 10px;
        padding: 6px 15px;
        font-weight: 600;
        background-color: #207005;
        border: none;
        box-shadow: 0px 2px 7px #888888;
    }
    .header-buttons .btn-secondary {
        margin-right: 10px;
        padding: 6px 15px;
        font-weight: 600;
        background-color: #72a055;
        border: none;
        box-shadow: 0px 2px 7px #888888;
    }


    .right-sec { border-left: 5px solid #ede7e7; }
    .tabdiv { background: white;  padding: 20px;  margin-top: 10px;  border: 10px solid #dfdbd5; }

    .nav-tabs {border-bottom:0px; }
    div#myTabContent { border: 1px solid #cccccc;}
    .frontfooter footer { padding: 20px calc(1.5rem / 2); position: static; color: #000; height: 60px; background-color: #f9f9f9;
        margin-top: 30px; border-top: 1px solid #e1dfdf; }
    span.logo-sm img { width: 69px;}

    .seperatesec{margin-top:20px;}
    .simplebar-content li.nav-item:hover {  background: #4caf50;}
    .sectitle{font-size: 14px;}
    .required { color: red; }
    .customtextarea{height: 120px;}

    ul.boxsection { margin: 0; padding: 0;}
    ul.boxsection li { list-style-type: none; padding: 7px 0; border-bottom: 1px solid #efeded;}
    .boxcard .col:nth-child(1) { background: #effcfb;}
    .boxcard .col:nth-child(2) { background: #fdfdfd;}
    .boxcard .col:nth-child(3) { background: #effcfb;}
    .boxcard .col:nth-child(4) { background: #fdfdfd;}
    .boxcard .col:nth-child(5) { background: #effcfb;}

    /* --registration-form css  */
    .custom-tab-content {
        padding-top: 0 !important;
        padding-bottom: 0px !important;
    }
    .custom-tab-nav {
        background: white;

    }
    .custom-tab-nav .nav-link {
        border-radius: 0 !important;
        border-bottom: 1px solid #e9ebec;
        border-right: 1px solid #e9ebec;
        font-size: 14px;
        padding: 10px;
    }
    .custom-tab-nav .nav-link.active, .custom-tab-nav .show>.nav-link{
        color: rgb(255, 255, 255) !important;
        background-color: #2c8c6d;
        border-bottom: #2c8c6d !important;
        /* border-bottom: #207005 !important; */
        position:relative;
    }
    .custom-tab-nav .nav-link:hover, .custom-tab-nav .nav-link:focus {
        border-bottom: 1px solid #207005;
        border-radius: 0;
        font-size: 14px;
        transition: background-color 0.20s linear;
    }
    .custom-tab-nav .nav-link.active:after {
        content: "";
        position: absolute;
        bottom: -16px;
        left: 50%;
        border: 8px solid transparent;
        border-top-color: #2c8c6d;
        z-index: 999;
    }
    .reg-form-btns {
        margin-bottom: 15px;
    }
    .reg-form-btns .btn-secondary {
        color: #fff;
        background-color: #405189;
        border-color: #405189;
    }
    .btn-soft-success:active, .btn-soft-success:focus, .btn-soft-success:hover{
        border: none;
    }
    .custom-tab-nav ul{padding:0px; margin:0px;}
    .custom-tab-nav ul li{padding:0px; margin:0px; display: inline-block; list-style: none;}
</style>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">processor Profile / प्रोसेसर प्रोफ़ाइल</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">processor Profile</li>
                </ol>
            </div>
        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <form method="post" enctype="multipart/form-data" id="registration" action="{{route('superadmin.processorUseredit.step2save',$userdetails->id)}}">
            @csrf
            <nav>
                        <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                            <a class="nav-link" id="step1-tab" data-bs-toggle="tab_"
                                href="{{route('superadmin.processorUseredit',$userdetails->id)}}">General Information</a>

                            <a class="nav-link" id="step3-tab" data-bs-toggle="tab_"
                                href="{{route('superadmin.processorUseredit.step1',$userdetails->id)}}">Geo Tagging of Processing  house Details</a>
                            <a class="nav-link active" id="step4-tab" data-bs-toggle="tab_"
                                href="{{route('superadmin.processorUseredit.step2',$userdetails->id)}}">Products Details</a>
							<a class="nav-link" id="step4-tab" data-bs-toggle="tab_"
                                href="{{route('superadmin.processorUseredit.step3',$userdetails->id)}}">List of Documents</a>
                        </div>
                    </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1">
                                उत्पाद का विवरण/Details of Products
                            </h4>
							<div class="flex-shrink-0">
                                @if (session('error'))
                                <div class="alert alert-danger">
                                    {{ session('error') }}
                                </div>
                                @endif
                                @if (session('success'))
                                <div class="alert alert-success">
                                    {{ session('success') }}
                                </div>
                                @endif
                                @if($errors)
                                @foreach ($errors->all() as $error)
                                <div class="alert alert-danger">{{ $error }}</div>
                                @endforeach
                                @endif
                            </div>
                        </div>
                        <!-- end card header -->
                        <div class="card-body">
                            <div class="live-preview">
								@forelse($processor_product_details as $processor_product_detail)
								<div class="row seperatesec white-inner after-add-more" id="row{{ $processor_product_detail->id }}">
									<input type="hidden" class="form-control" value="{{ $processor_product_detail->id }}" name="row_id[]"/>
                                    <div class="col-xxl-3 col-md-3 gy-3">
										<div>
											<label class="form-label">प्रोसेसिंग यूनिट आईडी/Processing Unit ID<span class="required"> *</span></label>
											<input type="text" class="form-control" value="{{ ($processor_product_detail->processing_unit_id) ?? ''}}" id="processing_unit_id" name="processing_unit_id[]" placeholder="Warehouse Unit ID" >
										</div>
									</div>
                                    @php
                                        $productID = getProductBYCBName($cbID->id);
                                        $refProductIDs = $productID->pluck('ref_product_id')->toArray();
                                    @endphp

                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">उत्पाद का एचएस कोड/HS Code of the Product<span class="required"> *</span></label>
                                            <select class="form-select hscode js-example-basic-single" name="ref_hscode_id[]" onchange="getHscodeProduct(this)">
                                                <option value="">--Select--</option>
                                                @forelse(getRefProduct() as $hscode)
                                                    @if(in_array($hscode->id, $refProductIDs)) 
                                                        @continue
                                                    @endif
                                                    <option value="{{ $hscode->id }}" data-name="{{ $hscode->product_name }}" data-des="{{ $hscode->hscode_description }}"  {{ $processor_product_detail->ref_hscode_id == $hscode->id ? 'selected' : '' }}>
                                                        {{ $hscode->hs_code }} - {{$hscode->product_name}}
                                                    </option>
                                                @empty
                                                    <option value="">No products available</option>
                                                @endforelse
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-xxl-3 col-md-3 gy-3">
										<div>
											<label class="form-label">प्रोसेसर उत्पाद का नाम/Processor Name of the Product<span class="required"> *</span></label>
                                            {{-- <select class="form-select product_type" name="ref_product_id[]">
                                                <option value="">Select Product</option>
                                                @forelse(getRefProduct() as $product)
                                                <option value="{{ $product->id }}"  {{ $processor_product_detail->ref_product_id == $product->id ? 'selected' : '' }}>{{ $product->product_name }}</option>
                                                @empty
                                                @endforelse

                                            </select> --}}
                                            <input type="hidden" name="ref_product_id[]" value="{{ $processor_product_detail->ref_product_id??'' }}">
                                            <input type="text" class="form-control" id="" placeholder="Product Name"
                                            name="product_processor_name[]" value="{{ getRefProductById($processor_product_detail->ref_product_id)->product_name ??''}}">

										</div>
									</div>
									<div class="col-xxl-3 col-md-3 gy-3">
										<div>
											<label class="form-label">उत्पाद विवरण/Product Description<span class="required"> *</span></label>
											<input type="text" class="form-control" value="{{ ($processor_product_detail->product_description) ?? ''}}" id="product_description" placeholder="Product Description" name="product_description[]">
										</div>
									</div>
									<div class="col-xxl-3 col-md-3 gy-3">
										<div>
											<label class="form-label">प्रोसेसर का नाम/Name of Product<span class="required"> *</span></label>
											<input type="text" class="form-control" value="{{ ($processor_product_detail->product_processor_name) ?? ''}}" id="product_processor_name_" placeholder="Name of Processor" name="product_processor_name_[]">
										</div>
									</div>

									<div class="col-xxl-3 col-md-3 gy-3">
										<div>
											<label class="form-label">जैविक स्थिति/Organic Status <span class="required"> *</span></label>

                                            <select class="form-select" name="organic_status[]">
                                                <option value="">Select Product</option>
                                                @forelse(getRefOrganicStatusMaster() as $val)
                                                <option value="{{ $val->id }}"  {{ $processor_product_detail->organic_status == $val->id ? 'selected' : '' }}>{{ $val->organic_status}}</option>
                                                @empty
                                                @endforelse
                                            </select>
										</div>
									</div>
									<!-- <div class="col-xxl-3 col-md-3 gy-3">
										<div>
											<label class="form-label">उत्पाद का फोटो/Photo of the Product<span class="required"> </span></label>
											<input type="file" class="form-control upload_document1" id="product_image" name="product_image[]">
											@if(!empty($processor_product_detail->product_image))
												<input type="hidden" name="product_image_edit[]" value="{{ ($processor_product_detail->product_image) ?? ''}}">
												<a target="_BLANK" href="{{asset('public/processor/product_photo/'.$processor_product_detail->product_image)}}" class="text-decoration-underline">See Doc</a>
											@endif

                                            <p>Supported formats:jpg, jpeg. Upto 1MB</p>
										</div>
									</div> -->

									<div class="mt-2 text-sm-end">
										<div class="form-group change">
										<label for="">&nbsp;</label><br />
										<a class="mdi mdi-delete btn btn-soft-danger "  href="javascript:void(0);" onclick="confirmDelete('{{$processor_product_detail->id}}')" alt="Remove"></a>
									</div>
									</div>
                                </div>

								@empty

                                <div class="after-add-more seperatesec">

								 <div class="row white-inner">
								 <input type="hidden" class="form-control" value="" name="row_id[]"/>
                                    <div class="col-xxl-3 col-md-3 gy-3">
										<div>
											<label class="form-label">प्रोसेसिंग यूनिट आईडी/Processing  Unit ID<span class="required"> *</span></label>
											<input type="text" class="form-control" id="processing_unit_id" name="processing_unit_id[]" placeholder="Warehouse Unit ID" >
										</div>
									</div>

                                    @php
                                        $productID = getProductBYCBName($cbID->id);
                                        $refProductIDs = $productID->pluck('ref_product_id')->toArray();
                                    @endphp

                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">उत्पाद का एचएस कोड/HS Code of the Product<span class="required"> *</span></label>
                                            <select class="form-select hscode js-example-basic-single" name="ref_hscode_id[]" onchange="getHscodeProduct(this)">
                                                <option value="">--Select--</option>
                                                @forelse(getRefProduct() as $hscode)
                                                    @if(in_array($hscode->id, $refProductIDs)) 
                                                        @continue
                                                    @endif
                                                    <option value="{{ $hscode->id }}">
                                                        {{ $hscode->hs_code }} - {{$hscode->product_name}}
                                                    </option>
                                                @empty
                                                    <option value="">No products available</option>
                                                @endforelse
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-xxl-3 col-md-3 gy-3">
										<div>
											<label class="form-label">प्रोसेसर उत्पाद का नाम/Processor Name of the Product<span class="required"> *</span></label>
                                            <input type="hidden" name="ref_product_id[]" value="">
                                            <input type="text" class="form-control" id="product_description" placeholder="Product Description" name="product_processor_name[]">

                                            {{-- <select class="form-select product_type" name="ref_product_id[]">
                                                <option value="">Select Product</option>
                                                @forelse(getRefProduct() as $hscode)
                                                <option value="{{ $hscode->id }}">{{ $hscode->product_name}}</option>
                                                @empty
                                                @endforelse
                                            </select> --}}
										</div>
									</div>
                                    <div class="col-xxl-3 col-md-3 gy-3">
										<div>
											<label class="form-label">उत्पाद विवरण/Product Description<span class="required"> *</span></label>
											<input type="text" class="form-control" id="product_description" placeholder="Product Description" name="product_description[]">
										</div>
									</div>
                                    <div class="col-xxl-3 col-md-3 gy-3">
										<div>
											<label class="form-label">प्रोसेसर का नाम/Name of Processor<span class="required"> *</span></label>
											<input type="text" class="form-control" id="product_processor_name_" placeholder="Name of Processor" name="product_processor_name_[]">
										</div>
									</div>

									<div class="col-xxl-3 col-md-3 gy-3">
										<div>
											<label class="form-label">जैविक स्थिति/Organic Status <span class="required"> *</span></label>

                                            <select class="form-select" name="organic_status[]" required>
                                                <option value="">Select Product</option>
                                                @forelse(getRefOrganicStatusMaster() as $val)
                                                <option value="{{ $val->id }}">{{ $val->organic_status}}</option>
                                                @empty
                                                @endforelse
                                            </select>
										</div>
									</div>
									<!-- <div class="col-xxl-3 col-md-3 gy-3">
										<div>
											<label class="form-label">उत्पाद का फोटो/Photo of the Product<span class="required"> </span></label>
											<input type="file" class="form-control upload_document1" id="product_image" name="product_image[]">
                                            <p>Supported formats:jpg, jpeg. Upto 1MB</p>
										</div>
									</div> -->

									<div class="mt-2 text-sm-end">
										<div class="form-group change">

										</div>
									</div>

                                </div>
							 </div>
                            @endforelse
                             <div class="mt-2 text-sm-end">
										<div class="form-group change">
											<label for="">&nbsp;</label><br />
                                            <i data-type="wm" class="mdi mdi-plus btn btn-soft-success add-more" data-toggle="tooltip" title="Add More"></i>
											<!-- <a class="btn btn-success add-more"><i class="ri-add-line"></i></a> -->
										</div>
									</div>


                                <!--address sec end-->

                                <div class="row">
                                    <div class="col-lg-12 gy-4">
                                        <div class="hstack gap-2">
                                            <a href="{{route('superadmin.processorUseredit.step1',$userdetails->id)}}" class="btn btn-soft-success">
                                                Back
                                            </a>
                                            <button type="submit" class="btn btn-primary">
                                                Save
                                            </button>
											 <a href="{{route('superadmin.processorUseredit.step3',$userdetails->id)}}" class="btn btn-soft-success">
                                                Next
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

@endsection

@push('script')

<script>


//    function getHscodeProduct(hscode) {
//         var th = $(this);
//        alert($('option:selected',this).data("name"));
//         // $.ajax({
//         //     url:"{{route('superadmin.getHscodeProduct')}}",
//         //     type: "POST",
//         //     data: {
//         //         hscode: hscode,
//         //         _token: '{{csrf_token()}}'
//         //         },
//         //     dataType : 'json',
//         //      success: function(result){
//         //         if(result){
//         //             th.closest('.row').find('.product_type').html(result);
//         //         }
//         //     }
//         // });

//     }

    function getHscodeProduct(th) {
        //alert(th.value);
        //var ref_id = $(this).val();
        var name = $('option:selected',th).data("name");
        var des = $('option:selected',th).data("des");
        $(th).parent().parent().parent().find('input[name="ref_product_id[]"]').val(th.value);
        $(th).parent().parent().parent().find('input[name="product_processor_name[]"]').val(name);
        $(th).parent().parent().parent().find('input[name="product_description[]"]').val(des);


    }
    function confirmDelete(id) {

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.value) {
                $.ajax({
                    url: "{{ route('superadmin.processorUseredit.deleteProductProcessor') }}",
                    method: "POST",
                    dataType: 'json',
                    data: {
                        'id': id,
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(result) {
                        $('#row'+id).remove();
                        Swal.fire(
                            'Deleted!',
                            'Record Deleted Successfully..',
                            'success'
                        );

                    }
                });

            }
        })
    }

    $(document).ready(function () {
        $("body").on("click", ".add-more", function () {
            var html = $(".after-add-more").first().clone().find("input").val("").end().find("a").remove().end();
            $(html).find(".change").html("<label for=''>&nbsp;</label><br/><a class='mdi mdi-delete btn btn-soft-danger remove'></a>");
            $(".after-add-more").last().after(html);


        });

        $("body").on("click", ".remove", function () {
            $(this).parents(".after-add-more").remove();
        });
    });
    $('.upload_document').on('change', function() {
            var $this = $(this);
            var file = $this[0].files[0];
            var fileType = file.type;
            var fileSize = file.size;
            var allowedTypes = ['application/pdf'];

            // Check for file type
            if (!allowedTypes.includes(fileType)) {
                Swal.fire({
                    icon: 'error',
                    title: 'Invalid File Extension',
                    text: 'Please upload PDF only.',
                });
                $this.val("");
                return false;
            }

            // Check for file size
            if (fileSize > 1000000) { // 2 MB in bytes
                Swal.fire({
                    icon: 'error',
                    title: 'File Size Too Large',
                    text: 'Please upload files of size 1 MB or less only.',
                });
                $this.val("");
                return false;
            }
        });



       




$('.upload_document1').on('change', function() {
    var $this = $(this);
    var file = $this[0].files[0];
    var fileType = file.type;
    var fileSize = file.size;
    var allowedTypes = ['image/jpeg', 'image/jpg'];

    // Check for file type
    if (!allowedTypes.includes(fileType)) {
        Swal.fire({
            icon: 'error',
            title: 'Invalid File Extension',
            text: 'Please upload JPEG, JPG only.',
        });
        $this.val("");
        return false;
    }

    // Check for file size (1 MB = 1,048,576 bytes)
    if (fileSize > 1048576) {
        Swal.fire({
            icon: 'error',
            title: 'File Size Too Large',
            text: 'Please upload files of size 1 MB or less only.',
        });
        $this.val("");
        return false;
    }
});


$(document).ready(function() {
    $('.js-example-basic-single').select2();
});

</script>

@endpush

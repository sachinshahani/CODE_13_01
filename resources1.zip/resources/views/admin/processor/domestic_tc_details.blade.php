@extends('admin.layouts.app')
@section('content')
<style>
    .pdf_maindiv {
        border: 1px solid #cccccc;
        width: 100%;
        float: left;
        padding: 3%;
    }

    th {
        border: 1px solid black;
        background-color: 1px solid #3941ab;
    }

</style>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Application for Transaction Certificate</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Application for Transaction Certificate</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">

            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                    <a class="nav-link" id="step1-tab" href="{{ route('superadmin.domestictc') }}">Add Product</a>
                    <a class="nav-link" id="step2-tab" href="javascript:void(0);">Packing Details</a>
                    <a class="nav-link active" id="step3-tab" href="javascript:void(0);">TC Details</a>

                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                            <div class="live-preview">
                                <div class="flex-shrink-0">
                                    @if (session('error'))
                                    <div class="alert alert-danger">
                                        {{ session('error') }}
                                    </div>
                                    @endif
                                    @if (session('success'))
                                    <div class="alert alert-success">
                                        {{ session('success') }}
                                    </div>
                                    @endif
                                    @if($errors)
                                    @foreach ($errors->all() as $error)
                                    <div class="alert alert-danger">{{ $error }}</div>
                                    @endforeach
                                    @endif
                                </div>
                                <div class="row white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label  blue-ht">Application for Transaction Certificate</label>
                                    </div><br>
                                    <form method="post" action="{{ route('superadmin.domesticTcSaveData')}}" >
                                        @csrf

                                        <div class="col-xxl-12 col-md-12 ">
                                            <label for="labelInput" class="form-label blue-ht">Producer/Manufacturer</label>
                                        </div>
                                        <div class="col-xxl-12 col-md-9 ms-3">
                                            <div class="row  ">
                                               <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                    <tr>
                                                        <td class="pdf_txt1">Name :</td>
                                                        <td class="pdf_box"><input type="text"></td>

                                                        <td class="pdf_txt1">Address :</td>
                                                        <td class="pdf_box"><input type="text"></td>

                                                        <td class="pdf_txt1"></td>
                                                        <td class="pdf_box"></td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div><br>
                                        
                                        <div class="col-xxl-12 col-md-12 ">
                                            <label for="labelInput" class="form-label blue-ht">Seller Information</label>
                                        </div>
                                        <div class="col-xxl-12 col-md-9 ms-3">
                                            <div class="row  ">
                                               <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                    <tr>
                                                        <td class="pdf_txt1">Scope Certificate Number :</td>
                                                        <td class="pdf_box"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="pdf_txt1">Seller Name :</td>
                                                        <td class="pdf_box"></td>
                                                        <td class="pdf_txt1">Seller ID Proof :</td>
                                                        <td class="pdf_box"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="pdf_txt1">Address :</td>
                                                        <td class="pdf_box"></td>
                                                        <td class="pdf_txt1">Email :</td>
                                                        <td class="pdf_box"></td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div><br>

                                        <div class="col-xxl-12 col-md-12 ">
                                            <label for="labelInput" class="form-label blue-ht">Buyer Detail(s)</label>
                                        </div>
                                        <div class="col-xxl-12 col-md-9 ms-3">
                                            <div class="row  ">
                                               <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                <tr>
                                                    <td class="pdf_txt1">Buyer Scope Cert No. :</td>
                                                    <td class="pdf_box"><input type="text" value="ORG/SC?65214/1655"></td>
                                                    <td class="pdf_txt1">Buyer ID Proof :</td>
                                                    <td class="pdf_box"><input type="text" value="CUGPK4092Q">&nbsp;PAN</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Buyer Name :</td>
                                                    <td class="pdf_box"><input type="text" value="Trader demo"></td>
                                                    <td class="pdf_txt1">Address :</td>
                                                    <td class="pdf_box"><input type="text" value="Demo Demo"></td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">State :</td>
                                                    <td class="pdf_box">New Delhi</td>
                                                    <td class="pdf_txt1">Email :</td>
                                                    <td class="pdf_box"><input type="email" value="demo@demi.com"></td>
                                                </tr>
                                                </table>
                                            </div>
                                        </div><br>

                                        <div class="col-xxl-12 col-md-12 ">
                                            <label for="labelInput" class="form-label blue-ht">Invoice Detail(s)</label>
                                        </div>

                                        <div class="col-xxl-12 col-md-9 ms-3 ">
                                            <div class="row  ">
                                               <table style="padding: 10px; border: 1px;" class="table_pdf">
                                                <tr class="inner-table th">
                                                    <th>Invoice No.</th>
                                                    <th>Date of Invoice</th>
                                                    <th>Action</th>
                                                </tr>
                                                <tr>
                                                    <td><input type="text"></td>
                                                    <td><input type="text"></td>
                                                    <td class="btn btn-md btn-soft-primary"> Add </td>
                                                </tr>
                                                </table>
                                            </div>
                                        </div><br>
                                        
                                        <div class="col-xxl-12 col-md-9 ms-3">
                                            <div class="row  ">
                                               <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                <tr>
                                                    <td class="pdf_txt1">Invoice Value (in Rs) :</td>
                                                    <td class="pdf_box"><input type="text" value="10000"></td>
                                                    <td class="pdf_txt1">Place of Dispatch/origin :</td>
                                                    <td class="pdf_box"><input type="text" value="New Delhi"></td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Lot No. :</td>
                                                    <td class="pdf_box"><input type="text" value="2323332"></td>
                                                    <td class="pdf_txt1">Place of Destination :</td>
                                                    <td class="pdf_box"><input type="text" value="Kolkata"></td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Marks & No. :</td>
                                                    <td class="pdf_box"><input type="text" value="12121"></td>
                                                    <td class="pdf_txt1">Reference no. :</td>
                                                    <td class="pdf_box"><input type="text" value="656575"></td>
                                                </tr>
                                                </table>
                                            </div>
                                        </div><br>

                                        <div class="col-xxl-12 col-md-12 ">
                                            <label for="labelInput" class="form-label blue-ht">Transport Detail(s)</label>
                                        </div>
                                        <div class="col-xxl-12 col-md-9 ms-3">
                                            <div class="row  ">
                                               <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                  <tr>
                                                     <td class="pdf_txt1">Mod of Transport :</td>
                                                        <td>
                                                            <label>
                                                                <input type="radio" name="Road" value="Road">
                                                                Road
                                                            </label>
                                                        </td>
                                                        <td>
                                                            <label>
                                                                <input type="radio" name="Train" value="Train">
                                                                Train
                                                            </label>
                                                        </td>
                                                        <td>
                                                            <label>
                                                                <input type="radio" name="Air" value="Air">
                                                                    Air
                                                            </label>
                                                        </td>
                                                        <td>
                                                            <label>
                                                                <input type="radio" name="Ship" value="Ship">
                                                                    Ship
                                                            </label>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div><br>

                                        
                                        <div class="col-xxl-12 col-md-12 ">
                                            <label for="labelInput" class="form-label blue-ht">Train Detail(s)</label>
                                        </div>
                                        <div class="col-xxl-12 col-md-9 ms-3">
                                            <div class="row  ">
                                               <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                <tr>
                                                    <td class="pdf_txt1">Train No. :</td>
                                                    <td class="pdf_box"><input type="text" value="16234"></td>
                                                    <td class="pdf_txt1">Bagon No. :</td>
                                                    <td class="pdf_box"><input type="text" value="30/06/2019"></td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1"></td>
                                                    <td class="pdf_box"></td>
                                                    <td class="pdf_txt1">Date of Transport :</td>
                                                    <td class="pdf_box"><input type="text" value="1623465"></td>
                                                </tr>
                                                </table>
                                            </div>
                                        </div><br>
                                        <div class="col-xxl-12 col-md-12 add-edit-div">
                                            <label for="Gross Weight (in MT)">Gross Weight (in MT)</label>
                                           <input type="text" name="grossWeight" value="20">
                                        </div>
                                    <div style="text-align: center;">
                                        <span id="successmsg" class="badge badge-soft-success"></span><br>
                                      <button type="submit" class="btn btn-primary mt-2"> Save & Preview</button>
                                        <a href="{{ route('superadmin.domestictc') }}" class="btn btn-primary mt-2">Back to Packing Details</a>
                                        <a href="{{ route('superadmin.domestictc') }}" class="btn btn-primary mt-2">Delete</a>
                                       
                                        {{-- <a href="{{ route('superadmin.TcDetail') }}" class="btn btn-primary mt-2 ">Proceed</a> --}}
                                            {{-- <button type="submit" class="btn btn-primary mt-2 proceed" {{ (isset($packDet->id) && $packDet!='')?'':'disabled' }} >Delete</button> --}} 
                                        {{-- {{-- @else
                                            <a href="javascript:void(0);" class="btn btn-primary mt-2 proceed" onclick="chkAddEditPacking();">Proceed</a>
                                        @endif --}}
                                        {{-- <a href="javascript:void(0);" class="btn btn-danger mt-2">Delete</a> --}}
                                    </div>
                                    </form>
                                </div>

                            </div>
                        {{-- </div>
                    </div> --}}
                </div>
            </div>
        </div>
    @endsection
    @push('script')
        <div class="modal fade" id="addBatchModalgrid" tabindex="-1" aria-labelledby="addBatchModalgridLabel"
            aria-modal="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addBatchModalgridLabel">Edit Product</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body" id="batch_popup">

                    </div>
                </div>
            </div>
        </div>
    @endpush
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Get all elements with the class 'toggle-row'
        const toggleRows = document.querySelectorAll('.toggle-row');

        // Add click event listener to each row
        toggleRows.forEach(row => {
            row.addEventListener('click', () => {
                // Toggle the 'hidden' class on the clicked row
                row.classList.toggle('hidden');
            });
        });
    });
</script>
@extends('admin.layouts.app')
@section('content')

<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Batch Creation</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Batch Creation</li>
                </ol>
            </div>

        </div>
    </div>
</div>

<div class="col-lg-12">

    <nav>
        <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

            <a class="nav-link " id="step0-tab" href="javascript:void(0);">Product Details</a>
            <a class="nav-link" id="step2-tab" href="javascript:void(0);">Processed Details</a>
            <a class="nav-link" id="step3-tab" href="javascript:void(0);">Source Details</a>
            <a class="nav-link active" id="step4-tab" href="javascript:void(0);">Preview</a>
            <a class="nav-link" id="step5-tab" href="javascript:void(0);">Batch Details</a>
            <!-- <a class="nav-link" id="step4-tab"
                        href="javascript:void(0);">Product Details</a> -->
        </div>
    </nav>
</div>

<br>

<form action="{{route('superadmin.batchCreationPreviewDetailssave')}}" class="commonform1 " method="POST" enctype="multipart/form-data" id="commonform1" autocomplete="off">
    @csrf



   <b> <p class="mb-sm-0">Product Details</p></b>
    <br>

    <div class="row">
        <div class="col-xxl-3 col-md-6">
            <div>
                <label class="form-label" for="scopeCertificateNo">Product Name:</label>
                <span class="form-text">
                    <input type="text" class="form-control" id="product_name" name="product_name" value="{{$data->product}}" readonly>
                </span>
            </div>
        </div>

        <div class="col-xxl-3 col-md-6">
            <div>
                <label class="form-label" for="email">HS Code:</label>
                <input type="text" class="form-control" id="hs_code" name="hs_code" value="{{$data->hs_code}}" readonly>

            </div>
        </div>

    </div>


    <div>
        <br>
        <div class="row white-inner">
          <b><p class="mb-sm-0">Processed Product</p></b>
            <br><br>

            <div class="row">
                <div class="col-xxl-3 col-md-6">
                    <div>
                        <label class="form-label" for="scopeCertificateNo">Processed Unit Name</label>
                        <span class="form-text">
                            <input type="text" class="form-control" id="unit_name" name="unit_name" value="{{$data->unit_name}}" readonly>
                        </span>
                    </div>
                </div>

                <div class="col-xxl-3 col-md-6">
                    <div>
                        <label class="form-label" for="email">Organic Status:</label>
                        <input type="text" class="form-control" id="organic_status" name="organic_status" value="{{$data->organic_status}}" readonly>

                    </div>
                </div>
                <div class="col-xxl-3 col-md-6">
                    <div>
                        <label class="form-label" for="code">Processed Date:</label>
                        <span class="form-text">
                            <input type="text" class="form-control" id="processed_date" name="processed_date" value="{{$data->processing_date}}" readonly>
                        </span>
                    </div>
                </div>

                <div class="col-xxl-3 col-md-6">
                    <div>
                        <label class="form-label" for="product">Batch Quantity</label>
                        <span class="form-text">
                            <input type="text" class="form-control" id="batch_quantity" name="total_quantity" value="{{$data->quantity}}" readonly>
                        </span>
                    </div>
                </div>

            </div>


            <div class="row">
                <div class="col-xxl-3 col-md-6">
                    <div>
                        <label class="form-label" for="scopeCertificateNo">Conversion Percentage</label>
                        <span class="form-text">
                            <input type="text" class="form-control" id="percentage" name="percentage"  value="{{$data->percentage}}" readonly>
                        </span>
                    </div>
                </div>

                <div class="col-xxl-3 col-md-6">
                    <div>
                        <label class="form-label" for="email">Expiry Date:</label>

                        <input type="text" class="form-control" id="expiry_date" name="expiry_date"  value="{{$data->expiry_date}}" readonly>
                    </div>
                </div>
                <div class="col-xxl-3 col-md-6">
                    <div>
                        <label class="form-label" for="code">By-Product along with this batch:</label>
                        <span class="form-text">
                            <input type="text" class="form-control" id="byProduct" placeholder="" name="byProduct" value="{{$data->by_product}}" readonly>
                        </span>
                    </div>
                </div>



            </div>


        </div>


    </div>

    <div class="row">

        <div class="col-lg-12">
            <div class="card">

                <div class="card-body table-responsive">
                 <b><p>Source Deatils From TC:</p></b>
                    <table id="searchResultsTable" class="table table-bordered table-striped align-middle" style="width:100%">
                        <thead>
                            <tr>
                                <th>TC No.</th>
                                <th>Product Name</th>
                                <th>Available Quantity (in MT)</th>
                                <th>Quantity Source (in MT)</th>



                            </tr>
                        </thead>
                        @forelse ($Sourcedata as $data)


                        <tbody>

                            <tr>
                                <td>{{$data->tc_no ?? ''}}</td>
                                <td>
                                    @if (!empty($data->product_code))
                                        {{ getHscodeProductName($data->product_code) }}
                                    @else
                                        N/A <!-- or some default value -->
                                    @endif
                                </td>
                                
                                <td>{{$data->available_quantity ?? ''}}</td>
                                <td>{{$data->quantity_source ?? ''}}</td>
                            </tr>


                        </tbody>
                        @empty

                        @endforelse
                    </table>
                </div>
            </div>
        </div>
        <!--end col-->
    </div>

    <div class="row ">
        <div class="col-lg-12 gy-4">
            <div class="hstack gap-2 ">
                <button type="submit" class="btn btn-primary">Generate Batch & forward to CB</button>
            </div>
        </div>
    </div>

</form>

@endsection

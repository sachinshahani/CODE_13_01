<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table border="0" cellspacing="0" cellpadding="0"
        style="width:100%;max-width: 800px;margin: 0 auto;border-collapse: collapse;">
        <tbody>
            <tr>
                <td colspan="2" style="text-align:right;margin: 0;padding-bottom:0px;">
                    <img src="{{ asset('public/backend/images/india-org.jpg') }}" alt="" style="max-width: 100px;">
                </td>
            </tr>
            <tr>
                <td colspan="2" style="text-align: center;">
                    <p style="font-family:'Arial';padding: 3px 0;margin: 0;font-weight: bold;font-size:18px">
                        TRANSACTION CERTIFICATE FOR ORGANIC PRODUCTS TRADED WITHIN INDIA
                        FOR EXPORT PURPOSES
                    </p>
                    <pre>
            </td>
            </tr>
            <tr>
                <td style="padding-left:15px;text-align: center;">
                    <img src="{{ asset('public/backend/images/bar.png') }}" alt="">
                </td>
            </tr>
        </tbody>
    </table>
    <table border="1" cellspacing="0" cellpadding="0"
        style="width:100%;max-width: 800px;margin: 0 auto;margin-top:10px;border-collapse: collapse;">
        <tbody>
            <tr>
                <td style="text-align:left;padding-top:10px;">
                    <p style="margin-bottom:5px;margin-top: 0;font-family:'Arial';font-weight:400;font-size: 12px;">1.
                        Certification Body (Name & Address)</p>
                    <p style="margin-bottom:5px;margin-top: 0;font-family:'Arial';font-weight:400;font-size: 12px;">  </p>
                    <p style="margin: 0;font-family:'Arial';font-weight:400;font-size: 12px;"> </p>
                    <p
                    style="font-family:'Arial';padding: 3px 0;margin: 0;font-weight: bold;font-size: 12px;padding-right: 25px;">
                    {{$user->first_name}}</p>
                    &
                    <p
                    style="font-family:'Arial';padding: 3px 0;margin: 0;font-weight: bold;font-size: 12px;padding-right: 25px;">
                    {{$user->address}}</p>
                </td>
                <td style="text-align:left;padding-top:10px;">
                    <p style="font-family:'Arial';padding: 3px 0;margin: 0;font-weight:400;font-size: 12px;">
                        2. Transaction Certificate No.</p>
                    <p
                        style="font-family:'Arial';padding: 3px 0;margin: 0;font-weight: bold;font-size: 12px;padding-right: 25px;">
                        {{$tcIssueList[0]->transaction_certificate_no}}</p>
                </td>
            </tr>
            <tr>
                <td colspan="2" style="padding-top:5px;">
                    <p style="margin-bottom:5px;margin-top: 0;font-family:'Arial';font-weight:400;font-size: 12px;">3.
                        Seller (Name and Address of Individual/ICS)
                        
                    </p>
                    <p style="margin-bottom:5px;margin-top: 0;font-family:'Arial';font-weight:400;font-size: 12px;">
                      Name:  {{$user->first_name}}</p>
                    <p style="margin-bottom:5px;margin-top: 0;font-family:'Arial';font-weight:400;font-size: 12px;">
                     Address: {{$user->address}}  </p>
                    <p style="margin: 0;font-family:'Arial';font-weight:400;font-size: 12px;"><span
                            style="font-weight:600">PAN :</span></p>
                </td>
            </tr>
            <tr>
                <td colspan="2" style="padding-top:5px;">
                    <p style="margin-bottom:5px;margin-top: 0;font-family:'Arial';font-weight:400;font-size: 12px;">4.
                        Buyer (Name and Address)</p>
                    <p style="margin-bottom:5px;margin-top: 0;font-family:'Arial';font-weight:400;font-size: 12px;">
                        </p>
                    <p style="margin-bottom:5px;margin-top: 0;font-family:'Arial';font-weight:400;font-size: 12px;">
                       </p>
                    <p style="margin: 0;font-family:'Arial';font-weight:600;font-size: 12px;">PAN : {{$userData[0]->pan ?? '' }}</p>
                </td>
            </tr>
            <tr>
                <td style="text-align:left;padding-top:5px;">
                    <p style="margin-bottom:5px;margin-top: 0;font-family:'Arial';font-weight:400;font-size: 12px;">5.
                        Place of Dispatch</p>
                    <p style="margin-bottom:5px;margin-top: 0;font-family:'Arial';font-weight:400;font-size: 12px;">
                        </p>
                </td>
                <td style="text-align:left;padding-top:5px;">
                    <p style="font-family:'Arial';padding: 3px 0;margin: 0;font-weight:400;font-size: 12px;">
                        6. Place of Destination</p>
                    <p
                        style="font-family:'Arial';padding: 3px 0;margin: 0;font-weight:400;font-size: 12px;padding-right: 25px;">
                        </p>
                </td>
            </tr>
            <tr>
                <td colspan="2" style="padding-top:5px;">
                 <!--   <p
                        style="font-family:'Arial';padding: 3px 0;margin: 0;font-weight:400;font-size: 12px;margin-bottom: 0;">
                        7.</p>-->
                    <table border="1" cellspacing="0" cellpadding="0"
                        style="width:100%;margin: 0 auto;margin-top:0px;border-collapse: collapse;">
                        <thead>
                            <tr>
                                <th
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:600;font-size: 12px;padding:3px;line-height:18px">
                                    Product(s)
                                </th>
                               <!-- <th
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:600;font-size: 12px;padding:3px;line-height:18px">
                                    HS Code
                                </th>-->
                                <th
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:600;font-size: 12px;padding:3px;line-height:18px">
                                    HS CodeNPOP Organic
                                    Compliance
                                    (C1/C2/C3/Organic)
                                </th>
                             <!--   <th
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:600;font-size: 12px;padding:3px;line-height:18px">
                                    NOP Organic Compliance
                                    (C1/C2/C3/Organic)
                                </th>-->
                                <th
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:600;font-size: 12px;padding:3px;line-height:18px">
                                    Lot No.&
                                    Quantity(in MT)
                                </th>
                                <th
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:600;font-size: 12px;padding:3px;line-height:18px">
                                    Trade
                                    Name
                                </th>
                                <th
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:600;font-size: 12px;padding:3px;line-height:18px">
                                    Packing Details
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:400;font-size: 12px;padding:3px;line-height:18px">
                                    <p
                                    style="font-family:'Arial';padding: 3px 0;margin: 0;font-weight: bold;font-size: 12px;padding-right: 25px;">
                                    {{$tcIssueList[0]->trade_name_of_product}}</p>
                                </td>
                                <!--<td
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:400;font-size: 12px;padding:3px;line-height:18px">
                                   
                                </td>-->
                                <td
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:400;font-size: 12px;padding:3px;line-height:18px">
                                    <p
                                    style="font-family:'Arial';padding: 3px 0;margin: 0;font-weight: bold;font-size: 12px;padding-right: 25px;">
                                    {{$tcIssueList[0]->organic_status}}</p>
                                </td>
                               <!--  <td
                                   style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:400;font-size: 12px;padding:3px;line-height:18px">
                                    
                                </td>-->
                                <td
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:400;font-size: 12px;padding:3px;line-height:18px">
                                    <p
                                    style="font-family:'Arial';padding: 3px 0;margin: 0;font-weight: bold;font-size: 12px;padding-right: 25px;">
                                    {{$data->lot_number ?? ''}}</p>
                                    &
                                    <p
                                    style="font-family:'Arial';padding: 3px 0;margin: 0;font-weight: bold;font-size: 12px;padding-right: 25px;">
                                    {{$tcIssueList[0]->total_qty ?? ''}}</p>
                                   
                                <td
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:400;font-size: 12px;padding:3px;line-height:18px">
                                    <p
                                    style="font-family:'Arial';padding: 3px 0;margin: 0;font-weight: bold;font-size: 12px;padding-right: 25px;">
                                    {{$tcIssueList[0]->trade_name_of_product}}</p>
                                </td>
                                <td
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:400;font-size: 12px;padding:3px;line-height:18px;width:30%;">
                                    <p style="font-family: 'Arial'; padding: 3px 0; margin: 0; font-weight: bold; font-size: 12px; padding-right: 25px;">
                                        @php
                                            echo $tcIssueList[0]->total_qty * 100 . " Kg";
                                        @endphp
                                    </p>
                                    {{-- <p style="margin: 0;padding-bottom: 5px;">100.000000Kg X 500 Nos. =
                                        50000.000000 Kg</p>
                                    <p style="margin: 0;padding-bottom: 5px;">200.000000Kg X 150 Nos. =
                                        30000.000000 Kg</p> --}}
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr>
                <td colspan="2" style="padding-top:5px;">
                    <p
                        style="font-family:'Arial';padding: 3px 0;margin: 0;font-weight:400;font-size: 12px;margin-bottom: 0;">
                        8. Transaction Details</p>
                    <table border="1" cellspacing="0" cellpadding="0"
                        style="width:80%;margin: 0 auto;margin-top:15px;border-collapse: collapse;">
                        <tbody>
                            <tr>
                                <td
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:400;font-size: 12px;padding:3px;line-height:18px">
                                    <p style="margin:0;font-size:12px">a) Order/Contract No.</p>
                                    <p style="margin:0;font-size:12px;margin-top: 5px;">{{ $data->container_no ?? '' }}</p>
                                </td>
                            </tr>
                            <tr>
                                <td
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:400;font-size: 12px;padding:3px;line-height:18px">
                                    <p style="margin:0;font-size:12px">b) Invoice No.& Date</p>
                                    <table border="1" cellspacing="0" cellpadding="0"
                                        style="width:80%;margin-top:15px;border-collapse: collapse;">
                                        <thead>
                                            <tr>
                                                <th
                                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-size: 12px;padding:3px;">
                                                    S. No.</th>
                                                <th
                                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-size: 12px;padding:3px;">
                                                    Invoice No.</th>
                                                <th
                                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-size: 12px;padding:3px;">
                                                    Invoice Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td
                                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-size: 12px;padding:3px;">
                                                    1</td>
                                                <td
                                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-size: 12px;padding:3px;">
                                                    <p
                                                    style="font-family:'Arial';padding: 3px 0;margin: 0;font-weight: bold;font-size: 12px;padding-right: 25px;">
                                                    {{$data->invoice_no ?? ''}}</p>
                                                <td
                                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-size: 12px;padding:3px;">
                                                    <p
                                                    style="font-family:'Arial';padding: 3px 0;margin: 0;font-weight: bold;font-size: 12px;padding-right: 25px;">
                                                    {{$data->invoice_date ?? ''}}</p>
                                                   </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table border="1" cellspacing="0" cellpadding="0"
                        style="width:80%;margin: 0 auto;margin-top:15px;border-collapse: collapse;margin-bottom:5px;">
                        <thead>
                            <tr>
                                <th
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-size: 12px;padding:3px;">
                                    c) Mode of Transport</th>
                                <th
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-size: 12px;padding:3px;">
                                    e) Transport Document No.</th>
                                <th
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-size: 12px;padding:3px;">
                                    e)Vehicle No./Bull Cart/Air/others</th>
                                <th
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-size: 12px;padding:3px;">
                                    f) Date of Transport</th>
                            </tr>
                        </thead>
                        @php
                        $road_transport_date = '';
                    @endphp
                    @if (isset($data->transport_mode) && $data->transport_mode == 'road')
                        @php
                            $road_transport_date = $data->transport_date;
                        @endphp
                    @endif
                        <tbody>
                            <tr>
                                <td
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-size: 12px;padding:3px;">
                                    <p
                                    style="font-family:'Arial';padding: 3px 0;margin: 0;font-weight: bold;font-size: 12px;padding-right: 25px;">
                                    {{$data->transport_mode ?? ''}}</p>
                                   </td>
                                <td
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-size: 12px;padding:3px;">
                                    <p
                                    style="font-family:'Arial';padding: 3px 0;margin: 0;font-weight: bold;font-size: 12px;padding-right: 25px;">
                                    {{$data->transport_doc_no ?? ''}}</p>
                                    </td>
                                <td
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-size: 12px;padding:3px;">
                                    <p
                                    style="font-family:'Arial';padding: 3px 0;margin: 0;font-weight: bold;font-size: 12px;padding-right: 25px;">
                                    {{$data->container_no_road ?? ''}}</p>
                                   </td>
                                <td
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-size: 12px;padding:3px;">
                                    <p
                                    style="font-family:'Arial';padding: 3px 0;margin: 0;font-weight: bold;font-size: 12px;padding-right: 25px;">
                                    {{ !empty($road_transport_date) ? date('d-m-Y', strtotime($road_transport_date)) : '' }}</p>
                                   </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr>
                <td colspan="2" style="padding-top:5px;font-family:'Arial'">
                    <p style="padding: 3px 0;margin: 0;font-size:12px;">9. Additional Declaration by the Certification
                        Body</p>
                    <p style="padding: 3px 0;margin: 0;font-size:12px;">This is to certify that :</p>
                    <ol style="list-style: lower-alpha;font-family:'Arial';margin:5px;font-size: 12px;">
                        <li style="padding: 3px 0;">This Transaction Certificate is issued after satisfying ourselves
                            with the required inspection under the checked programmes at S.No.7 above;</li>
                        <li style="padding: 3px 0;">On the date of issue of this Transaction Certificate, the
                            Accreditation of this Certification Body under NPOP is valid.</li>
                        <li style="padding: 3px 0;">The above information is correct to the best of our knowledge and
                            belief.</li>
                    </ol>
                    <p style="padding: 3px 0;margin: 0;font-size:12px;">Issued Date: </p>
                    <p
                    style="font-family:'Arial';padding: 3px 0;margin: 0;font-weight: bold;font-size: 12px;padding-right: 25px;">
                    {{ $data->created_at ? $data->created_at->format('d-m-Y') : '' }}
                </p>
                    <table cellspacing="0" cellpadding="0"
                        style="width:100%;margin: 0 auto;margin-top:0px;border-collapse: collapse;">
                        <tbody>
                            <tr>
                                <td style="font-family:'Arial';font-size: 12px;padding-top: 40px;">
                                    <p style="margin: 0;padding-bottom: 5px;">Name and Signature of the authorised person</p>
                                    <p style="margin: 0;padding-bottom: 5px;">Satish Agrawal</p>
                                </td>
                                <td style="padding-top:40px;">
                                    <img src="{{ asset('public/backend/images/qr.png') }}" alt="" style="width:70px;">
                                </td>
                                <td style="padding-top: 40px;">
                                    <img src="{{ asset('public/backend/images/apeda-vec.svg') }}" alt="" style="width:70px;">
                                </td>
                                <td style="font-family:'Arial';font-size: 12px;padding-top: 40px;">
                                    Stamp of Certification Body
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
        </tbody>
    </table>
</body>

</html>
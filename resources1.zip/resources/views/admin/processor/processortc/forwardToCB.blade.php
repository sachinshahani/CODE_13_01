@extends('admin.layouts.app')
@section('content')
    <style>
        .pdf_maindiv {
            border: 1px solid #cccccc;
            width: 100%;
            float: left;
            padding: 2%;
        }

        .pdf_heading {
            font-size: 15px;
            color: #000;
            padding: 26px 0 12px 0px;
            position: relative;
            width: 100%;
            float: left;
        }
    </style>

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Application for Transaction Certificate</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Application for Transaction Certificate</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">

            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">
                    <a class="nav-link" id="step1-tab" href="javascript:void(0);">Add Product</a>
                    <a class="nav-link" id="step2-tab" href="javascript:void(0);">Packing Details</a>
                    <a class="nav-link active" id="step3-tab" href="">TC Details</a>
                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">

                    <div class="live-preview">
                       
                        <div class="row white-inner">
                            <form method="post" action="{{ route('superadmin.P-postForwardToCB') }}">
                                @csrf
                                <input type="hidden" value="{{ $id }}" name="row_id">
                               
                                <div style="text-align: center;">
                                    <a href="{{ route('superadmin.P-viewTCApplication', $id) }}"
                                    class="">Click here to preview the Domestic Transaction Certificate Application</a>
                                    <span id="successmsg" class="badge badge-soft-success"></span><br>
                                    <a href="{{ route('superadmin.P-trader.TcDetail', $id) }}"
                                        class="btn btn-primary mt-2">Edit</a>
                                    <button type="submit" class="btn btn-primary mt-2">Forward To CB</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
@endsection
@push('script')
    <div class="modal fade" id="addBatchModalgrid" tabindex="-1" aria-labelledby="addBatchModalgridLabel"
        aria-modal="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addBatchModalgridLabel">Edit Product</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="batch_popup">

                </div>
            </div>
        </div>
    </div>
    <script>
        
    </script>
@endpush

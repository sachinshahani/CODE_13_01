@extends('admin.layouts.app')
@section('content')
<style>
    .pdf_maindiv {
        border: 1px solid #cccccc;
        width: 100%;
        float: left;
        padding: 3%;
    }
    .pdf_heading {
        font-size: 15px;
        color: #000;
        padding: 26px 0 12px 0px;
        position: relative;
        width: 100%;
        float: left;
    }
</style>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Application for Transaction Certificate</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Application for Transaction Certificate</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">

            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                    <a class="nav-link " id="step1-tab" href="javascript:void(0);">Add Product</a>
                    <a class="nav-link active" id="step2-tab" href="javascript:void(0);">Packing Details</a>
                    <a class="nav-link " id="step3-tab" href="javascript:void(0);">TC Details</a>

                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    {{-- <div class="card">

                        <div class="card-body"> --}}
                            {{-- <label for="labelInput" class="form-label blue-ht">Packing Detail(s) Entry</label> --}}
                            <div class="live-preview">
                                <div class="flex-shrink-0">
                                    @if (session('error'))
                                    <div class="alert alert-danger">
                                        {{ session('error') }}
                                    </div>
                                    @endif
                                    @if (session('success'))
                                    <div class="alert alert-success">
                                        {{ session('success') }}
                                    </div>
                                    @endif
                                    @if($errors)
                                    @foreach ($errors->all() as $error)
                                    <div class="alert alert-danger">{{ $error }}</div>
                                    @endforeach
                                    @endif
                                </div>
                                <div class="row white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label  blue-ht">Packing Detail(s) Entry</label>
                                    </div>
                                    <form method="post" action="{{ route('superadmin.P-trader.storePackingDetailTC')}}" >
                                        @csrf
                                       
                                        <div class="col-xxl-12 col-md-12 ">
                                            <label for="labelInput" class="form-label blue-ht">Operators details</label>
                                        </div>

                                        <div class="col-xxl-12 col-md-9 ms-3">
                                            <div class="row  ">
                                               <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                    <tr>
                                                        <td class="pdf_txt1">Operator Name :</td>
                                                        <td class="pdf_box">{{Auth::user()->first_name}} {{Auth::user()->last_name}}</td>

                                                        <td class="pdf_txt1">Operator Scope certificate Number :</td>
                                                        <td class="pdf_box">{{getScopeCerNoById(Auth::user()->id)}}</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="pdf_txt1">Operator Type  :</td>
                                                        <td class="pdf_box">{{getOperatorTypeById(Auth::user()->ref_operator_type_id)}}</td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div>
                                        <div class="table-responsive">
                                            <table class="table table-bordered table-striped align-middle dataTable no-footer"
                                                width="100%" id="datatable_">
                                                <thead>
                                                    <tr>
                                                        <th>S.No.</th>
                                                        <th>Product /TC</th>
                                                        <th>Status</th>
                                                        <th>Total Quantity (in MT)</th>
                                                        <th>Remaning Sourced (in MT)</th>
                                                        <th>Sourced Quantity (in MT)</th>
                                                        <th>Packing Entered</th>
                                                        <th>Action</th>
                                                    </tr>

                                                </thead>
                                                <tbody>
                                                    

                                                    @php
                                                        $tran_id = '';
                                                        @endphp
                                                        @forelse($trans as $tr)
                                                        @php
                                                
                                                        $sourceData_avilable = App\Models\SourceDetails::where('at_user_id',$tr->created_by)->first();
                                                        

                                                        //$getSource = getSourceQty($tr->created_by,$tr->product_code);
                                                        $pro_souciedc_if  = App\Models\AtOpTransactionProductSourced::where('created_by',Auth::id())->latest()->first();
                                                        $tran_id = $pro_souciedc_if->id ?? '';
                                                        @endphp

                                                    <tr>
                                                        <td>{{1}}</td>
                                                        {{-- <td>{{getHscodeProductName($tr->product_code??'')}}</td> --}}
                                                            
                                                        <td>{{getHscodeProductName($tr->product_code??'')}}</td>

                                                        <td>{{ getSingleTableRecordById('ref_organic_status_master', 'id', $tr->organic_status)->organic_status??'' }}</td>
                                                        <td>{{$tr->total_qty ?? ''}}    </td>
                                                        <td>{{$tr->rem_qty ?? ''}}</td>

                                                        {{-- <td>{{$tr->quantity_for_tc ?? ''}}</td> --}}

                                                        @php
                                                               $getSource = getSourceQty($tr->created_by,$tr->product_code);                                                               
                                                        @endphp

                                                        <td>{{$getSource ?? ''}}</td>
                                                        
                                                        <td>No</td>
                                                        <td><a href="javascript:void(0);" onclick="getLots();">Add/Edit Packing</a></td>
                                                    </tr>
                                                    @empty
                                                    @endforelse
                                                </tbody>

                                            </table>
                                        </div>

                                        <div class="col-xxl-12 col-md-12 ">
                                            <label for="labelInput" class="form-label blue-ht">Add product value details</label>
                                        </div>
                                        <div class="col-xxl-12 col-md-12">
                                            <div class="row  ">
                                                <div class="col-xxl-4 col-md-3 mt-4">
                                                    <div>
                                                        <input type="hidden" name="at_op_transaction_product_sourced_id" value="{{$tran_id}}">
                                                        
                                                        <label for="labelInput" class="form-label">Product Name :</label>
                                                        <input type="hidden" name="ref_product_id" value="{{ $trans[0]->product_code ?? '' }}">
                                                       {{getHscodeProductName($trans[0]->product_code)}}
                                                    </div>
                                                </div>

                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">Value INR: <span
                                                                class="required">*</span></label>
                                                            <input type="text" name="value_inr" class="form-control" value="{{$trans[0]->value_inr ?? ''}}" required>
                                                    </div>
                                                </div>

                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">Trade Name:
                                                            <span class="required">*</span></label>
                                                            <input type="text" name="trade_name_of_product" class="form-control" value="{{$trans[0]->trade_name_of_product ?? ''}}" required>

                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                        <div class="col-xxl-12 col-md-12 add-edit-div {{$trans[0]->value_inr ?? 'd-none'}} ">
                                            <label for="labelInput" class="form-label blue-ht">Add/Edit Packing details</label>
                                        </div>
                                        <div class="col-xxl-12 col-md-12 add-edit-div {{$trans[0]->value_inr ?? 'd-none'}} ">
                                            <div class="row  ">
                                                <input type="hidden" name="trans_id" value="{{$trans[0]->id ?? ''}}">

                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">Total Qty. Sourced(in Kg) :<span
                                                                class="required">*</span></label>
                                                                @php
                                                               $getSource = getSourceQty($tr->created_by,$tr->product_code);                                                               
                                                        @endphp
                                                        {{$getSource}}
                                                       {{-- {{$trans[0]->quantity_for_tc}} --}}
                                                    </div>
                                                </div>

                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">Reaming Qty.(in Kg): <span
                                                                class="required">*</span></label>
                                                                <input type="text" name="remain_qty" class="form-control" value="{{$trans[0]->rem_qty}}">

                                                    </div>
                                                </div>
                                                <div class="table-responsive">
                                                    <table class="table table-bordered table-striped align-middle dataTable no-footer"
                                                        width="100%" id="datatable_">
                                                        <thead>
                                                            <tr>
                                                                <th>S.No.</th>
                                                                <th>Packing Type </th>
                                                                <th>No. of units</th>
                                                                <th>Qty. (Pack size in Kg).</th>
                                                                <th>Total Qty. (in Kg)</th>

                                                            </tr>

                                                        </thead>
                                                        <tbody>
                                                           
                                                            @php
                                                               //$packDet = App\Models\AtOpTransactionPackingDetails::where(['at_op_transaction_product_sourced_id'=>$source->id])->first();

                                                            @endphp

                                                                        <tr>
                                                                            <input type="hidden" name="row_id" value="{{ $packDet->id ?? '' }}">
                                                                            {{-- <input type="hidden" name="at_op_transaction_product_sourced_id" value="{{ $source->id??'' }}"> --}}
                                                                            <td><input name="packing" type="checkbox" {{ (isset($packDet->id) && $packDet->id!='')? 'checked' : '' }} ></td>
                                                                            <td>
                                                                                <select class="form-select" name="ref_packing_master_id">
                                                                                <option value="">Select Packing Type</option>
                                                                                @forelse($packs as $pc)
                                                                                    <option value="{{$pc->id}}" {{ (isset($packDet->ref_packing_master_id) && $packDet->ref_packing_master_id==$pc->id) ? 'selected' : '' }}>{{$pc->packing_type}}</option>
                                                                                @empty
                                                                                @endforelse
                                                                                </select>
                                                                            </td>
                                                                            <td><input type="text" class="form-control" name="no_of_box" value="{{ $packDet->no_of_box ?? '' }}"></td>
                                                                            <td><input type="text" class="form-control" name="pack_size" value="{{ $packDet->pack_size ?? '' }}"></td>
                                                                            <td><input type="text" class="form-control" name="total_qty_in_kg" value="{{ $packDet->total_qty_in_kg ?? '' }}"></td>

                                                                        </tr>
                                                                    

                                                         
                                                        </tbody>

                                                    </table>
                                                </div>
                                               {{-- {{ $trans[0]->trade_name_of_product ??'aa'  }} --}}
                                                <div style="text-align: center;">
                                                    <span id="successmsg" class="badge badge-soft-success"></span><br>
                                                    @if(isset($trans[0]->trade_name_of_product) && $trans[0]->trade_name_of_product=='')
                                                        <button type="submit" class="btn btn-primary mt-2">Save</button>

                                                    @endif

                                                </div>

                                            </div>
                                        </div>

                                    <div style="text-align: center;">
                                        <span id="successmsg" class="badge badge-soft-success"></span><br>
                                        <a href="{{ route('superadmin.P-trader.applyForDomesticTCT') }}" class="btn btn-primary mt-2">Back to Add Product</a>

                                        {{-- <a href="{{ route('superadmin.TcDetail') }}" class="btn btn-primary mt-2 ">Proceed</a> --}}
                                            <button type="submit" class="btn btn-primary mt-2 proceed" {{ (isset($packDet->id) && $packDet!='')?'':'disabled' }} >Proceed</button>
                                        {{-- @else
                                            <a href="javascript:void(0);" class="btn btn-primary mt-2 proceed" onclick="chkAddEditPacking();">Proceed</a>
                                        @endif --}}
                                        {{-- <a href="javascript:void(0);" class="btn btn-danger mt-2">Delete</a> --}}
                                    </div>
                                    </form>


                                </div>

                            </div>
                        {{-- </div>
                    </div> --}}
                </div>
            </div>
        </div>
    @endsection
    @push('script')
        <div class="modal fade" id="addBatchModalgrid" tabindex="-1" aria-labelledby="addBatchModalgridLabel"
            aria-modal="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addBatchModalgridLabel">Edit Product</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body" id="batch_popup">

                    </div>
                </div>
            </div>
        </div>
        <script>
            // $(document).ready(function() {
            //     $(document).on('blur', '.tc_qty',function () {
            //         var id = $(this).data('id');
            //         if($('#tcqty'+id).val()> 0){

            //             if(Number($(this).data('avail')) >= Number($('#tcqty'+id).val())){
            //                 $('#purch'+id).attr("checked",true);
            //             }else{
            //                 $('#tcqty'+id).val('');
            //                 Swal.fire('', 'Quantity for TC is less then available quantity', 'warning');
            //             }

            //         }else{
            //             $('#purch'+id).attr("checked",false);
            //         }
            //     });
            // });
            // $.ajaxSetup({
            //     headers: {
            //         'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            //     }
            // });


            function getLots() {

                $('.add-edit-div').removeClass("d-none");
                $('select[name="ref_packing_master_id[]"]').prop('required',true);
                $('input[name="no_of_box[]"]').prop('required',true);
                $('input[name="pack_size[]"]').prop('required',true);
                $('input[name="total_qty_in_kg[]"]').prop('required',true);
                $('.proceed').prop('disabled', false);

            }

            function chkAddEditPacking(){
                var packingId = $('input[name="ref_packing_master_id[]"]').val();
                //console.log(packingId);
                if(packingId == undefined){
                    Swal.fire('', 'Please click on Add/Edit Packing and Add Details. ', '');
                }else{
                    return true;
                }
            }
        </script>
    @endpush

@extends('admin.layouts.app')
@section('content')
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Application for Transaction Certificate</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Application for Transaction Certificate</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">

            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                    <a class="nav-link active" id="step1-tab" href="javascript:void(0);">Add Product</a>
                    <a class="nav-link " id="step2-tab" href="javascript:void(0);">Packing Details</a>
                    <a class="nav-link " id="step3-tab" href="javascript:void(0);">TC Details</a>
                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    {{-- <div class="card">

                        <div class="card-body"> --}}
                    <div class="card-header align-items-center d-flex">

                        <div class="flex-shrink-0">
                            @if (session('error'))
                                <div class="alert alert-danger">
                                    {{ session('error') }}
                                </div>
                            @endif
                            @if (session('success'))
                                <div class="alert alert-success">
                                    {{ session('success') }}
                                </div>
                            @endif
                            @if ($errors)
                                @foreach ($errors->all() as $error)
                                    <div class="alert alert-danger">{{ $error }}</div>
                                @endforeach
                            @endif
                        </div>
                    </div>
                    <div class="live-preview">
                        <div class="row white-inner">
                            <div class="sectitle">
                                <label for="labelInput" class="form-label  blue-ht">Product Details</label>
                            </div>
                            <form method="post" action="{{ route('superadmin.P-trader.storeApplyForDomesticTCT') }}">
                                @csrf
                                <div class="table-responsive">
                                    @if (count($data) > 0)

                                        <table class="table table-bordered table-striped align-middle dataTable no-footer"
                                            width="100%" id="datatable_">
                                            <thead>
                                                <tr>
                                                    <th>Select</th>
                                                    <th>Products</th>
                                                    <th>Status</th>
                                                    <th>Total Quantity (in MT)</th>
                                                    {{-- <th>Quantity Sourced (in MT)</th> --}}
                                                    <th>Available Quantity (in MT)</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @forelse($data as $key => $vals)
                                                @php

                                                    $source_avible = App\Models\SourceDetails::where('batch_id', $vals->id)->first();                                                    

                                                    $pro_code = '';
                                                    foreach($vals->batchDetails as $batchdetail){
                                                    $pro_code = $batchdetail->product_code;
                                                    }
                                                   
                                                    $ref_product = App\Models\RefProduct::where('hs_code',$pro_code)->first();
                                               
                                                @endphp
                                                
                                                    <tr>
                                                        <input type="hidden" name="row_id[{{ $key }}]"
                                                            value="{{ $vals->id ?? '' }}">
                                                        <input type="hidden" name="farm_no[{{ $key }}]"
                                                            value="{{ $vals->farm_no ?? '' }}">
                                                        <td><input name="lots[{{ $key }}]" type="checkbox"
                                                                onclick="getLots('{{ $vals->id }}','{{ $vals->id }}',{{ $key }});"
                                                                required>
                                                        </td>
                                                        <td>{{ $vals->product }}</td>
                                                        <td>
                                                            <input type="hidden" name="product_code[{{ $key }}]"
                                                                value="{{ $ref_product->id ?? ''}}">
                                                            <input type="hidden"
                                                                name="organic_status[{{ $key }}]"
                                                                value="{{ $vals->organic_status }}">
                                                            {{ getSingleTableRecordById('ref_organic_status_master', 'id', $vals->organic_status)->organic_status }}
                                                        </td>
                                                        <td> <input type="hidden" name="total_qty[{{ $key }}]"
                                                                value="{{ $vals->quantity ?? '' }}">
                                                            {{ $vals->quantity }}
                                                        </td>
                                                        {{-- <td>{{ $vals->quantity_for_tc }}
                                                            <input type="hidden" name="req_qty[{{ $key }}]"
                                                                value="{{ $vals->quantity_for_tc ?? '' }}">
                                                        </td> --}}

                                                        {{-- <td> <input type="hidden" name="rem_qty[{{ $key }}]"
                                                                value="{{ $vals->rem_qty ?? '0' }}">
                                                            {{ $vals->rem_qty }}
                                                        </td> --}}
                                                        
                                                        <td> <input type="hidden" name="rem_qty[{{ $key }}]"
                                                            value="{{ $source_avible-> available_quantity ?? '0' }}">
                                                        {{ $source_avible-> available_quantity ?? '0'}}
                                                    </td>

                                                    </tr>

                                                    <tr id="tbl{{ $vals->id }}" class="d-none">
                                                        <td></td>
                                                        <td colspan="5">
                                                            {{-- ******************* --}}


                                                            <table
                                                                class="table table-bordered table-striped align-middle dataTable"
                                                                width="100%" id="datatable2">
                                                                <thead class="table-success">
                                                                    <tr>
                                                                        <th>Select Purchases</th>
                                                                        <th>Products</th>
                                                                        <th>Organic Status</th>
                                                                        <th>Total Quantity (in MT)</th>
                                                                        <th>Quantity Sourced (in MT)</th>
                                                                        <th>Available Quantity (in MT)</th>
                                                                        <th>Quantity for this TC (in MT)</th>
                                                                        <th>Action</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    @forelse($vals->batchDetails as $k =>$val)
                                                                    @php

                                                                    $source_avible1 = App\Models\SourceDetails::where('batch_id', $val->batch_id)->first();
                                                                   
                
                                                                @endphp
                                                                        <tr>
                                                                            <input type="hidden"
                                                                                name="rows_id[{{ $key }}][{{ $k }}]"
                                                                                value="{{ $val->id ?? '' }}">
                                                                            <input
                                                                                name="ref_product_id[{{ $key }}][{{ $k }}]"
                                                                                type="hidden"
                                                                                value="{{ $val->ref_product_id ?? '' }}">
                                                                            <input
                                                                                name="at_closing_stock_id[{{ $key }}][{{ $k }}]"
                                                                                type="hidden"
                                                                                value="{{ $val->at_closing_stock_id ?? '' }}">
                                                                            <input
                                                                                name="at_purchase_details_id[{{ $key }}][{{ $k }}]"
                                                                                type="hidden"
                                                                                value="{{ $val->at_purchase_details_id ?? '' }}">
                                                                                <input
                                                                                name="op_organic_status[{{ $key }}][{{ $k }}]"
                                                                                type="hidden"
                                                                                value="{{ getSingleTableRecordById('ref_organic_status_master', 'id', $vals->organic_status)->id }}">
                                                                            
                                                                            <td><input
                                                                                    name="pur_lots[{{ $key }}][{{ $k }}]"
                                                                                    type="checkbox"
                                                                                    id="purch{{ $val->id }}"
                                                                                    onclick="getPurch('{{ $val->id }}');"
                                                                                    required></td>

                                                                            <td>{{ $val->product_name }}
                                                                            </td>
                                                                            <td>{{ getSingleTableRecordById('ref_organic_status_master', 'id', $vals->organic_status)->organic_status }}
                                                                            </td>
                                                                            {{-- <td>{{ $val->total_quantity ?? 0 }}</td>
                                                                            <td>{{ $val->quantity_source ?? 0 }}</td>
                                                                            <td>{{ $val->available_quantity ?? 0 }}</td> --}}
                                                                            <td>{{ $vals->quantity ?? 0 }}</td>
                                                                            <td>{{ $source_avible1->quantity_source ?? 0 }}</td>
                                                                            <td>{{ $source_avible1->available_quantity ?? 0 }}</td>


                                                                            <td><input type="text" name="used_quantity[{{ $key }}][{{ $k }}]"
                                                                                    id="tcqty{{ $val->id }}" class="tc_qty" data-id="{{ $val->id??'' }}"
                                                                                    data-avail="{{ $source_avible1->available_quantity ?? 0 }}"
                                                                                    value="{{ $val->used_quantity ?? '' }}"
                                                                                    required></td>
                                                                            <td>
                                                                                <div class="btn btn-success btn-sm"
                                                                                    onclick="addSourceQTY('{{ $val->id }}');">
                                                                                    <i class="ri-add-box-fill"></i></div>
                                                                            </td>

                                                                        </tr>
                                                                    @empty
                                                                        <tr>
                                                                            <td colspan="8">No records found..</td>
                                                                        </tr>
                                                                    @endforelse
                                                                </tbody>

                                                            </table>
                                                            {{-- ******************** --}}
                                                        </td>
                                                    </tr>


                                                @empty
                                                    <tr>
                                                        <td colspan="6">No records found..</td>
                                                    </tr>
                                                @endforelse
                                            </tbody>

                                        </table>
                                    @else
                                        <table class="table table-bordered table-striped align-middle dataTable no-footer"
                                            width="100%" id="datatable_">
                                            <thead>
                                                <tr>
                                                    <th>Select</th>
                                                    <th>Products</th>
                                                    <th>Status</th>
                                                    <th>Total Quantity (in MT)</th>
                                                    <th>Quantity Sourced (in MT)</th>
                                                    <th>Available Quantity (in MT)</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @if (isset($order['purchase_list']) && !empty($order['purchase_list']))
                                                    @forelse($order['purchase_list'] as $key => $vals)
                                                        <tr>
                                                            <input type="hidden" name="row_id[{{ $key }}]" value="">
                                                            <input type="hidden" name="farm_no[{{ $key }}]" value="{{ $vals->id ?? '' }}">
                                                            <td><input name="lots[{{ $key }}]" type="checkbox"
                                                                    onclick="getLots('{{ $vals->id }}','{{ $vals->clsid }}',{{ $key }});"
                                                                    required>
                                                            </td>
                                                            <td>{{ getHscodeProductName($vals->commodity) }}</td>
                                                            <td>
                                                                <input type="hidden"
                                                                    name="product_code[{{ $key }}]"
                                                                    value="{{ $vals->commodity }}">
                                                                <input type="hidden"
                                                                    name="organic_status[{{ $key }}]"
                                                                    value="{{ $vals->organic_status }}">
                                                                {{ getSingleTableRecordById('ref_organic_status_master', 'id', $vals->organic_status)->organic_status }}
                                                            </td>
                                                            <td> <input type="hidden"
                                                                    name="total_qty[{{ $key }}]"
                                                                    value="{{ $vals->closing_stock ?? '0' }}">
                                                                {{ $vals->quantity }}</td>
                                                                
                                                            <td>{{ $vals->closing_stock}}
                                                                <input type="hidden" name="req_qty[{{ $key }}]"
                                                                    value="{{ $vals->quantity ?? '' }}">
                                                            </td>
                                                            <input type="hidden" name="rem_qty[{{ $key }}]"
                                                                value="{{ $vals->closing_stock - ($vals->quantity ? $vals->quantity : 0) }}">

                                                            <td id="#rem_qty_td_{{ $key }}">
                                                                {{ $vals->quantity - $vals->closing_stock }}</td>
                                                        </tr>

                                                        <tr id="tbl{{ $vals->clsid }}" class="d-none">
                                                            <td></td>
                                                            <td colspan="5">
                                                                {{-- ******************* --}}


                                                                <table
                                                                    class="table table-bordered table-striped align-middle dataTable"
                                                                    width="100%" id="datatable2">
                                                                    <thead class="table-success">
                                                                        <tr>
                                                                            <th>Select Purchases</th>
                                                                            <th>Products</th>
                                                                            <th>Organic Status</th>
                                                                            <th>Total Quantity (in MT)</th>
                                                                            <th>Quantity Sourced (in MT)</th>
                                                                            <th>Available Quantity (in MT)</th>
                                                                            <th>Quantity for this TC (in MT)</th>
                                                                            <th>Action</th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        @forelse($vals->mypurchase as $k =>$val)
                                                                            <tr>
                                                                                <input type="hidden"
                                                                                    name="rows_id[{{ $key }}][{{ $k }}]"
                                                                                    value="">
                                                                                <input
                                                                                    name="ref_product_id[{{ $key }}][{{ $k }}]"
                                                                                    type="hidden"
                                                                                    value="{{ $val->commodity ?? '' }}">
                                                                                <input
                                                                                    name="at_closing_stock_id[{{ $key }}][{{ $k }}]"
                                                                                    type="hidden"
                                                                                    value="{{ $val->at_closing_stock_id ?? '' }}">
                                                                                <input
                                                                                    name="at_purchase_details_id[{{ $key }}][{{ $k }}]"
                                                                                    type="hidden"
                                                                                    value="{{ $val->id ?? '' }}">
                                                                                <input
                                                                                    name="op_organic_status[{{ $key }}][{{ $k }}]"
                                                                                    type="hidden"
                                                                                    value="{{ $vals->organic_status ?? '' }}">

                                                                                <td><input
                                                                                        name="pur_lots[{{ $key }}][{{ $k }}]"
                                                                                        type="checkbox"
                                                                                        id="purch{{ $val->id }}"
                                                                                        onclick="getPurch('{{ $val->id }}');"
                                                                                        required></td>

                                                                                <td>{{ getHscodeProductName($vals->commodity) }}
                                                                                </td>
                                                                                <td>{{ getSingleTableRecordById('ref_organic_status_master', 'id', $vals->organic_status)->organic_status }}
                                                                                </td>
                                                                                <td>{{ $val->purchase_qty ?? 0 }}</td>
                                                                                <td>{{ 0 }}</td>
                                                                                <td>{{ $val->purchase_qty }}</td>
                                                                                <td><input type="text"
                                                                                        name="qty_in_mt[{{ $key }}][{{ $k }}]"
                                                                                        id="tcqty{{ $val->id }}"
                                                                                        class="tc_qty"
                                                                                        data-id="{{ $val->id }}"
                                                                                        data-avail="{{ $val->purchase_qty }}"
                                                                                        value=""
                                                                                        onchange="remainingQty({{ $key }},{{ $k }});"
                                                                                        required></td>
                                                                                <td>
                                                                                    <div class="btn btn-success btn-sm"
                                                                                        onclick="addSourceQTY('{{ $val->id }}');">
                                                                                        <i class="ri-add-box-fill"></i>
                                                                                    </div>
                                                                                </td>

                                                                            </tr>
                                                                        @empty
                                                                            <tr>
                                                                                <td colspan="8">No records found..</td>
                                                                            </tr>
                                                                        @endforelse
                                                                    </tbody>

                                                                </table>
                                                                {{-- ******************** --}}
                                                            </td>
                                                        </tr>


                                                    @empty
                                                        <tr>
                                                            <td colspan="6">No records found..</td>
                                                        </tr>
                                                    @endforelse
                                                @endif
                                            </tbody>

                                        </table>
                                    @endif
                                </div>
                                <div style="text-align: center;">
                                    <span id="successmsg" class="badge badge-soft-success"></span><br>
                                    <button type="submit" class="btn btn-primary mt-2">Proceed</button>
                                    {{-- <a href="javascript:void(0);" class="btn btn-danger mt-2">Delete</a> --}}
                                </div>
                            </form>


                        </div>

                    </div>
                    {{-- </div>
                    </div> --}}
                </div>
            </div>
        </div>
    @endsection
    @push('script')
        <div class="modal fade" id="addBatchModalgrid" tabindex="-1" aria-labelledby="addBatchModalgridLabel"
            aria-modal="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addBatchModalgridLabel">Edit Product</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body" id="batch_popup">

                    </div>
                </div>
            </div>
        </div>
        <script>
            $(document).ready(function() {
                $(document).on('blur', '.tc_qty', function() {
                    var id = $(this).data('id');
                    if ($('#tcqty' + id).val() > 0) {

                        if (Number($(this).data('avail')) >= Number($('#tcqty' + id).val())) {
                            $('#purch' + id).attr("checked", true);
                        } else {
                            $('#tcqty' + id).val('');
                            Swal.fire('', 'Quantity for TC is less then available quantity', 'warning');
                        }

                    } else {
                        $('#purch' + id).attr("checked", false);
                    }
                });
            });
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });


            function getLots(id, ordid, ke) {

                if ($('input[name="lots[' + ke + ']"]').is(':checked')) {
                    $('#tbl' + ordid).removeClass("d-none");
                }
                if ($('input[name="lots[' + ke + ']"]').is(':unchecked')) {
                    $('#tbl' + ordid).addClass("d-none");
                }
            }

            function addSourceQTY(id) {
                
                if ($('#tcqty' + id).val() > 0) {
                    
                    $("#successmsg").html('Sourced Quantity Added Successfully.');
                }
            }

            function remainingQty(a, b) {
                //alert('#rem_qty_td_'+ a);
                $('#rem_qty_td_' + a).html('');
                var availQty = $('input[name="rem_qty[' + a + ']"]').val();
                var inputQty = $('input[name="qty_in_mt[' + a + '][' + b + ']"]').val();
                var remainQty = parseFloat(availQty).toFixed(2) - parseFloat(inputQty).toFixed(2);
                $('input[name="rem_qty[' + a + ']"]').val(parseFloat(remainQty).toFixed(2));

            }

            function getPurch(id) {
                if ($('#purch' + id).is(':checked')) {

                } else {
                    $('#tcqty' + id).val('');
                }
            }

            // function editProduct(product_id = '') {
            //     $('#whole_page_loader').show();
            //     $.ajax({
            //         url: "{{ route('superadmin.harvestUpdate.editIcsHarvestProduct') }}",
            //         method: "POST",
            //         cache: false,
            //         data: {
            //             'product_id': product_id,
            //         },
            //         headers: {
            //             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            //         },
            //         success: function(result) {
            //             console.log(result);
            //             $('#batch_popup').html(result);
            //             $('#addBatchModalgrid').modal('show');
            //             $('#whole_page_loader').hide();
            //         }
            //     });
            // }

            $(document).on('click', '#formSubmit', function(e) {
                e.preventDefault();
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                    }
                });
                $('#whole_page_loader').show();
                $.ajax({
                    url: "{{ route('superadmin.ProcessorUpdate.storeIcsHarvestProduct') }}",
                    method: 'post',
                    data: {
                        actual_yield: $('#actual_yield').val(),
                        harvest_date: $('#harvest_date').val(),
                        sowing_date: $('#sowing_date').val(),
                        product_id: $('#product_id').val(),
                    },
                    success: function(result) {
                        if (result.errors) {
                            $('.alert-danger').html('');

                            $.each(result.errors, function(key, value) {
                                $('.alert-danger').show();
                                $('.alert-danger').append('<li>' + value + '</li>');
                            });
                            $('#whole_page_loader').hide();
                        } else {
                            $('#edit_actual_yield').html(result.data['actual_yield']);
                            $('#edit_harvest_date').html(result.data['harvest_date']);
                            $('#edit_sowing_date').html(result.data['sowing_date']);
                            $('.alert-danger').hide();
                            $('#addBatchModalgrid').modal('hide');
                            $('#batch_popup').html('');
                            $('#whole_page_loader').hide();
                        }
                    }
                });
            });

            $('#datatable').DataTable();
        </script>
    @endpush

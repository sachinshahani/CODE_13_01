@extends('admin.layouts.app')
@section('content')
    <style>
        .pdf_maindiv {
            border: 1px solid #cccccc;
            width: 100%;
            float: left;
            padding: 2%;
        }

        .pdf_heading {
            font-size: 15px;
            color: #000;
            padding: 26px 0 12px 0px;
            position: relative;
            width: 100%;
            float: left;
        }
    </style>

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Application for Transaction Certificate</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Application for Transaction Certificate</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">

            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">
                    <a class="nav-link" id="step1-tab" href="javascript:void(0);">Add Product</a>
                    <a class="nav-link" id="step2-tab" href="javascript:void(0);">Packing Details</a>
                    <a class="nav-link active" id="step3-tab" href="">TC Details</a>
                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">

                    <div class="live-preview">

                        <div class="row white-inner">

                            <form method="post" action="{{ route('superadmin.storeTcDetail') }}">
                                @csrf
                                <input type="hidden" name="at_op_transaction_vs_transaction_product_id"
                                    value="{{ $id }}">

                                <div class="col-xxl-12 col-md-12 ">
                                    <label for="labelInput" class="pdf_heading">Producer/Manufacture details</label>
                                </div>

                                <div class="row pdf_maindiv">

                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">Name </label>
                                            <input type="text" class="form-control"
                                                value="{{ Auth::guard('misadmin')->user()->first_name }}" id=""
                                                readonly>
                                        </div>
                                    </div>
                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">Address</label>
                                            <input type="text" class="form-control"
                                                value="{{ Auth::guard('misadmin')->user()->address }}" id=""
                                                readonly>
                                        </div>
                                    </div>

                                </div>



                                <div class="col-xxl-12 col-md-12 ">
                                    <label for="labelInput" class="pdf_heading">Seller Information</label>
                                </div>
                                <div class="col-xxl-12 col-md-12">
                                    <div class="row  pdf_maindiv">
                                        <div class="col-xxl-4 col-md-6">
                                            <div>
                                                <label for="labelInput" class="form-label">Scope certificate number
                                                    :</label>
                                                {{ getScopeCerNoById(Auth::user()->id) }}
                                                <input type="hidden" value="{{ getScopeCerNoById(Auth::user()->id) }}"
                                                    name="seller_at_op_certificate_standard_details_id">
                                            </div>
                                        </div>

                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label for="labelInput" class="form-label">Seller ID proof : </label>
                                                N/A
                                            </div>
                                        </div>

                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label for="labelInput" class="form-label">Seller name :</label>
                                                <input type="hidden" name="exporter_seller_name"
                                                    value="{{ Auth::guard('misadmin')->user()->first_name ?? '' }}">
                                                {{ Auth::guard('misadmin')->user()->first_name ?? '' }}

                                            </div>
                                        </div>
                                        <div class="col-xxl-4 col-md-6 gy-3">
                                            <div>
                                                <label for="labelInput" class="form-label">E- mail :</label>
                                                <input type="hidden" name="seller_email"
                                                    value="{{ Auth::guard('misadmin')->user()->email ?? '' }}">
                                                {{ Auth::guard('misadmin')->user()->email ?? '' }}

                                            </div>
                                        </div>
                                        <div class="col-xxl-4 col-md-4 gy-3">
                                            <div>
                                                <label for="labelInput" class="form-label">Address : </label>
                                                <input type="hidden" name="exporter_seller_address"
                                                    value="{{ Auth::guard('misadmin')->user()->address ?? '' }}">
                                                {{ Auth::guard('misadmin')->user()->address ?? '' }}

                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="col-xxl-12 col-md-12">
                                    <label for="labelInput" class="pdf_heading">Buyer’s Details</label>
                                </div>
                                @php
                                    $buyerDet = App\Models\AtPurchaseRequest::where('at_user_id', Auth::guard('misadmin')->user()->id)->first();
                                    
                                @endphp

                                <div class="col-xxl-12 col-md-12">
                                    <div class="row  pdf_maindiv">
                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label class="form-label">Enter buyer scope certificate Number <span
                                                        class="required"> *</span></label>
                                                <input type="text" class="form-control"
                                                    value="{{ getScopeCerNoById(Auth::user()->id) }}" id=""
                                                    name="" readonly>
                                                <input type="hidden" value="{{ getScopeCerNoById(Auth::user()->id) }}"
                                                    name="buyer_at_op_certificate_standard_details_id">
                                            </div>
                                        </div>

                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label class="form-label">Buyer ID Proof <span class="required">
                                                        *</span></label>
                                                <input type="text" class="form-control" value="N/A" id=""
                                                    name="buyer_id_proof" readonly>
                                            </div>
                                        </div>

                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label class="form-label">Buyer name<span class="required">
                                                        *</span></label>
                                                <input type="text" class="form-control"
                                                    value="{{ getUserById($buyerDet->created_by)->first_name ?? '' }}"
                                                    id="" name="buyer_name" readonly>
                                            </div>
                                        </div>

                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label class="form-label">Address <span class="required"> *</span></label>
                                                <input type="text" class="form-control"
                                                    value="{{ getUserById($buyerDet->created_by)->address ?? '' }}"
                                                    id="" name="buyer_address" readonly>
                                            </div>
                                        </div>

                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label class="form-label">State<span class="required"> *</span></label>
                                                {{-- <input type="hidden"value="{{ getUserById($buyerDet->created_by)->ref_state_id?? '' }}"  name="buyer_ref_state_id" > --}}
                                                <input type="text" class="form-control"
                                                    value="{{ get_state_name(getUserById($buyerDet->created_by)->ref_state_id) ?? '' }}"
                                                    id="" name="" readonly>
                                            </div>
                                        </div>
                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label class="form-label">E-mail<span class="required"> *</span></label>
                                                <input type="text" class="form-control"
                                                    value="{{ getUserById($buyerDet->created_by)->email ?? '' }}"
                                                    id="" name="buyer_email" readonly>
                                            </div>
                                        </div>



                                    </div>
                                </div>
                                <div class="col-xxl-12 col-md-12">
                                    <label for="labelInput" class="pdf_heading">Invoice details</label>
                                </div>
                                <div class="col-xxl-12 col-md-12">
                                    <div class="row pdf_maindiv ">

                                        <table class="table table-bordered table-striped align-middle dataTable"
                                            width="100%" id="invoice_tbl">
                                            <thead class="table-success">
                                                <tr>
                                                    <th>Invoice number </th>
                                                    <th>Date of invoice</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td> <input type="text" class="form-control" value="{{ $data->invoice_no ?? '' }}"
                                                            id="" name="invoice_no[]" required></td>
                                                    <td> <input type="Date" class="form-control" value="{{ !empty($data->invoice_date) ? date('Y-m-d', strtotime($data->invoice_date)) :'' }}"
                                                            id="" name="invoice_date[]" required></td>
                                                    <td>
                                                        <div class="btn btn-success btn-sm  add_invoice"><i
                                                                class="ri-add-box-fill"></i></div>
                                                    </td>
                                                </tr>
                                            </tbody>

                                        </table>

                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label class="form-label">Invoice value (in Rs)<span class="required">
                                                        *</span></label>
                                                <input type="text" class="form-control" value="{{ $data->invoice_value ?? '' }}" id=""
                                                    name="invoice_value" required>
                                            </div>
                                        </div>

                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label class="form-label">Place of Dispatch/origin <span class="required">
                                                        *</span></label>
                                                <input type="text" class="form-control" value="{{ $data->place_of_dispatch ?? '' }}" id=""
                                                    name="place_of_dispatch">
                                            </div>
                                        </div>

                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label class="form-label">Lot number<span class="required">
                                                        *</span></label>
                                                <input type="text" class="form-control" value="{{ $data->lot_number ?? '' }}" id=""
                                                    name="lot_number" required>
                                            </div>
                                        </div>
                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label class="form-label">Place of destination<span class="required">
                                                        *</span></label>
                                                <input type="text" class="form-control" value="{{ $data->place_of_destination ?? '' }}" id=""
                                                    name="place_of_destination" required>
                                            </div>
                                        </div>
                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label class="form-label">Marks & No.<span class="required">
                                                        *</span></label>
                                                <input type="text" class="form-control" value="{{ $data->marks_no ?? '' }}" id=""
                                                    name="marks_no" required>
                                            </div>
                                        </div>
                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label class="form-label">Reference Number<span class="required">
                                                        *</span></label>
                                                <input type="text" class="form-control" value="{{ $data->reference_no ?? '' }}" id=""
                                                    name="reference_no" required>
                                            </div>
                                        </div>



                                    </div>
                                </div>

                                <div class="col-xxl-12 col-md-12">
                                    <label for="labelInput" class="pdf_heading">Transport Details</label>
                                </div>
                                <div class="col-xxl-12 col-md-12">
                                    <div class="row  pdf_maindiv">
                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label class="form-label">Mode of Transport<span class="required">
                                                        *</span></label>
                                                <br>
                                                <input type="radio" id="html" name="transport_mode"
                                                    value="road" {{!empty($data->transport_mode) && $data->transport_mode=='road'?'checked' : ''}}>
                                                <label for="road">Road</label>
                                                <input type="radio" id="css" name="transport_mode"
                                                    value="train" {{ !empty($data->transport_mode) && $data->transport_mode=='train'?'checked' : ''}}>
                                                <label for="train">Train</label>
                                                <input type="radio" id="html" name="transport_mode"
                                                    value="air" {{ !empty($data->transport_mode) && $data->transport_mode=='air'?'checked' : ''}}>
                                                <label for="air">Air</label>
                                                <input type="radio" id="css" name="transport_mode"
                                                    value="ship" {{!empty($data->transport_mode) &&  $data->transport_mode=='ship'?'checked' : ''}}>
                                                <label for="ship">Ship</label><br>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                @php
                                    $road_transport_date = '';
                                @endphp
                                @if (isset($data->transport_mode) && $data->transport_mode=='road')
                                    @php
                                        $road_transport_date = $data->transport_date;
                                    @endphp
                                @endif
                                <div class="col-xxl-12 col-md-12 road_div {{ isset($data->transport_mode) && $data->transport_mode=='road' ? '' : 'd-none'  }}">
                                    <label for="labelInput" class="pdf_heading">Road details</label>
                                </div>
                                <div class="col-xxl-12 col-md-12 road_div {{ isset($data->transport_mode) &&  $data->transport_mode=='road' ? '' : 'd-none'  }}">
                                    <div class="row pdf_maindiv ">
                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label class="form-label">Vehicle No./Container No.<span
                                                        class="required"> *</span></label>
                                                <input type="text" class="form-control road_field" value="{{ $data->container_no_road ?? '' }}"
                                                    id="" name="container_no_road" >
                                            </div>
                                        </div>
                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label class="form-label">Transport Document No.<span class="required">
                                                        *</span></label>
                                                <input type="text" class="form-control road_field" value="{{ $data->transport_doc_no ?? '' }}"
                                                    id="" name="transport_doc_no" >
                                            </div>
                                        </div>
                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label class="form-label">Date Of Transport<span class="required">
                                                        *</span></label>
                                                <input type="date" class="form-control road_field" value="{{ !empty($road_transport_date) ? date('Y-m-d', strtotime($road_transport_date)) : '' }}"
                                                    id="" name="road_transport_date" >
                                            </div>
                                        </div>


                                    </div>
                                </div>
                                @php
                                    $train_transport_date = '';
                                @endphp
                                @if (isset($data->transport_mode) && $data->transport_mode=='train')
                                    @php
                                        $train_transport_date = $data->transport_date;
                                    @endphp
                                @endif
                                <div class="col-xxl-12 col-md-12 train_div {{ isset($data->transport_mode) &&  $data->transport_mode=='train' ? '' : 'd-none'  }}">
                                    <label for="labelInput" class="pdf_heading">Train details</label>
                                </div>
                                <div class="col-xxl-12 col-md-12 train_div {{ isset($data->transport_mode) && $data->transport_mode=='train' ? '' : 'd-none'  }}">
                                    <div class="row pdf_maindiv ">
                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label class="form-label">Train No.<span class="required">
                                                        *</span></label>
                                                <input type="text" class="form-control train_field" value="{{ $data->train_no ?? '' }}"
                                                    id="" name="train_no">
                                            </div>
                                        </div>
                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label class="form-label">Wagon No.<span class="required">
                                                        *</span></label>
                                                <input type="text" class="form-control train_field" value="{{ $data->wagon_no ?? '' }}"
                                                    id="" name="wagon_no">
                                            </div>
                                        </div>

                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label class="form-label">Date of Transport<span class="required">
                                                        *</span></label>
                                                <input type="date" class="form-control train_field" value="{{  !empty($train_transport_date) ? date('Y-m-d', strtotime($train_transport_date)) : '' }}"
                                                    id="" name="train_transport_date">
                                            </div>
                                        </div>


                                    </div>
                                </div>
                               
                                <div class="col-xxl-12 col-md-12 air_div {{ isset($data->transport_mode) && $data->transport_mode=='air' ? '' : 'd-none'  }}">
                                    <label for="labelInput" class="pdf_heading">Air details</label>
                                </div>
                                <div class="col-xxl-12 col-md-12 air_div {{ isset($data->transport_mode) && $data->transport_mode=='air' ? '' : 'd-none'  }}">
                                    <div class="row pdf_maindiv ">
                                       
                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label class="form-label">Flight No.<span class="required">
                                                        *</span></label>
                                                <input type="text" class="form-control air_field" value="{{ $data->flight_no ?? '' }}"
                                                    id="" name="flight_no">
                                            </div>
                                        </div>
                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label class="form-label">Flight Date<span class="required">
                                                        *</span></label>
                                                <input type="date" class="form-control air_field" value="{{ !empty($data->flight_date) ? date('Y-m-d', strtotime($data->flight_date)) : '' }}"
                                                    id="" name="flight_date">
                                            </div>
                                        </div>
                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label class="form-label">Airway Bill No.<span class="required">
                                                        *</span></label>
                                                <input type="text" class="form-control air_field" value="{{ $data->airway_bill_no ?? '' }}"
                                                    id="" name="airway_bill_no">
                                            </div>
                                        </div>
                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label class="form-label">Airway Bill Date<span class="required">
                                                        *</span></label>
                                                <input type="date" class="form-control air_field" value="{{ !empty($data->airway_bill_date) ? date('Y-m-d', strtotime($data->airway_bill_date)) : '' }}"
                                                    id="" name="airway_bill_date">
                                            </div>
                                        </div>
                                        
                                        <div class="col-xxl-4 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Airway Container No.<span class="required">
                                                        *</span></label>
                                                <input type="text" class="form-control air_field" value="{{ $data->container_no_air ?? '' }}"
                                                    id="" name="container_no_air">
                                            </div>
                                        </div>


                                    </div>
                                </div>
                            
                                <div class="col-xxl-12 col-md-12 ship_div {{ isset($data->transport_mode) && $data->transport_mode=='ship' ? '' : 'd-none'  }}">
                                    <label for="labelInput" class="pdf_heading">Ship details</label>
                                </div>
                                <div class="col-xxl-12 col-md-12 ship_div {{ isset($data->transport_mode) && $data->transport_mode=='ship' ? '' : 'd-none'  }}">
                                    <div class="row pdf_maindiv ">
                                      
                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label class="form-label">Vessel No.<span class="required">
                                                        *</span></label>
                                                <input type="text" class="form-control ship_field" value="{{ $data->ship_no ?? '' }}"
                                                    id="" name="ship_no">
                                            </div>
                                        </div>
                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label class="form-label">Vessel Name<span class="required">
                                                        *</span></label>
                                                <input type="text" class="form-control ship_field" value="{{  $data->ship_name ?? '' }}"
                                                    id="" name="ship_name">
                                            </div>
                                        </div>
                                        <div class="col-xxl-4 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Vessel Date<span class="required">
                                                        *</span></label>
                                                <input type="date" class="form-control ship_field" value="{{ !empty($data->vessel_date) ? date('Y-m-d', strtotime($data->vessel_date )) : '' }}"
                                                    id="" name="vessel_date">
                                            </div>
                                        </div>
                                      
                                        <div class="col-xxl-4 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Bill of Lading No. <span class="required">
                                                        *</span></label>
                                                <input type="text" class="form-control ship_field" value="{{ $data->bill_of_lading ?? '' }}"
                                                    id="" name="bill_of_lading">
                                            </div>
                                        </div>
                                        <div class="col-xxl-4 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Bill of Lading Date<span class="required">
                                                        *</span></label>
                                                <input type="date" class="form-control ship_field" value="{{ !empty($data->date_of_lading) ? date('Y-m-d', strtotime($data->date_of_lading )) : '' }}"
                                                    id="" name="date_of_lading">
                                            </div>
                                        </div>
                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label class="form-label">Vessel Container number<span class="required">
                                                        *</span></label>
                                                <input type="text" class="form-control ship_field" value="{{ $data->container_no_ship ?? '' }}"
                                                    id="" name="container_no_ship">
                                            </div>
                                        </div>
                                        


                                    </div>
                                </div>
                                <div class="col-xxl-4 col-md-3 gy-3">
                                    <div>
                                        <label class="form-label">Gross weight (in MT)<span class="required">
                                                *</span></label>
                                        <input type="text" class="form-control" value="{{ $data->gross_weight ?? '' }}" id=""
                                            name="gross_weight" required>
                                    </div>
                                </div>
                                <div style="text-align: center;">
                                    <span id="successmsg" class="badge badge-soft-success"></span><br>
                                    <a href="{{ route('superadmin.packingDetailTC', $id) }}"
                                        class="btn btn-primary mt-2">Back to Add Product</a>
                                    <button type="submit" class="btn btn-primary mt-2">Save & Preview</button>
                                    

                                    {{-- <a href="javascript:void(0);" class="btn btn-danger mt-2">Delete</a> --}}
                                </div>
                            </form>


                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
@endsection
@push('script')
    <div class="modal fade" id="addBatchModalgrid" tabindex="-1" aria-labelledby="addBatchModalgridLabel"
        aria-modal="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addBatchModalgridLabel">Edit Product</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="batch_popup">

                </div>
            </div>
        </div>
    </div>
    <script>
        $("input[type=radio]").change(function() {
            var transport_mode = $('input[name="transport_mode"]:checked').val();
            if (transport_mode == 'road') {
                $('.road_div').removeClass("d-none");
                $('.road_field').prop('required', true);

            } else {
                $('.road_div').addClass("d-none");
                $('.road_field').prop('required', false);
            }
            if (transport_mode == 'train') {
                $('.train_div').removeClass("d-none");
                $('.train_field').prop('required', true);
            } else {
                $('.train_div').addClass("d-none");
                $('.train_field').prop('required', false);
            }
            if (transport_mode == 'air') {
                $('.air_div').removeClass("d-none");
                $('.air_field').prop('required', true);
            } else {
                $('.air_div').addClass("d-none");
                $('.air_field').prop('required', false);
            }
            if (transport_mode == 'ship') {
                $('.ship_div').removeClass("d-none");
                $('.ship_field').prop('required', true);
            } else {
                $('.ship_div').addClass("d-none");
                $('.ship_field').prop('required', false);
            }

        });


        $('.add_invoice').on('click', function () {

        $("#invoice_tbl tbody").append('<tr> <td> <input type="text" class="form-control" value="" id="" name="invoice_no[]" required></td> <td> <input type="Date" class="form-control" value="" id="" name="invoice_date[]" required></td> <td> <div class="btn btn-danger btn-sm remove"><i class="ri-checkbox-indeterminate-fill remove"></i></div> </td> </tr>'); 

        });
        $("body").on("click", ".remove", function() {
        //alert('ss');
        $(this).parents("tr").remove();
        });
    </script>
@endpush

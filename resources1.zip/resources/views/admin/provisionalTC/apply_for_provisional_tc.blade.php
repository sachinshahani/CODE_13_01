@extends('admin.layouts.app')
@section('content')
<style>
    .pdf_maindiv {
        border: 1px solid #cccccc;
        width: 100%;
        float: left;
        padding: 3%;
    }
    .pdf_heading {
        font-size: 15px;
        color: #000;
        padding: 26px 0 12px 0px;
        position: relative;
        width: 100%;
        float: left;
    }
    .errormsg {
        color: red;
        font-size: 14px !important;
    }
</style>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Application for Transaction Certificate</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Application for Transaction Certificate</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">

            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                    <a class="nav-link active" id="step1-tab" data-bs-toggle="tab"
                    href="{{ route('superadmin.applyForProvisionalTC') }}">Apply For Provision TC</a>
                    <a class="nav-link" href="">Add Product</a>
                    <a class="nav-link" href="">Packing Details</a>
                    <a class="nav-link" href="">TC Details</a>

                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    {{-- <div class="card">

                        <div class="card-body"> --}}
                            {{-- <label for="labelInput" class="form-label blue-ht">Packing Detail(s) Entry</label> --}}
                            <div class="live-preview">
                               
                                <div class="row white-inner">
                                    <div class="col-xxl-12 col-md-4 ">
                                        <div class="flex-shrink-0">
                                            @if (session('error'))
                                            <div class="alert alert-danger">
                                                {{ session('error') }}
                                            </div>
                                            @endif
                                            @if (session('success'))
                                            <div class="alert alert-success">
                                                {{ session('success') }}
                                            </div>
                                            @endif
                                            @if($errors)
                                            @foreach ($errors->all() as $error)
                                            <div class="alert alert-danger">{{ $error }}</div>
                                            @endforeach
                                            @endif
                                        </div>
                                    </div>
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label  blue-ht">Apply for Provisional Transaction Certificate</label>
                                    </div>
                                    <form method="post" action="{{ route('superadmin.applyForProvisionalTCStore')}}" id="ptcform">
                                        @csrf
                                        <div class="col-xxl-12 col-md-12 ">
                                            <label for="labelInput" class="form-label blue-ht">Operators details</label>
                                        </div>
                                      
                                        <div class="col-xxl-12 col-md-9 ms-3">
                                            <div class="row  ">
                                               <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                    <tr>
                                                        <td class="pdf_txt1">Seller Scope Certificate No :</td>
                                                        <td class="pdf_box">{{ $scope->scope_certificate_no ?? '' }}</td>
                                                        <input type="hidden" name="seller_at_op_certificate_standard_details_id" value="{{ $scope->id ?? '' }}">
                                                        <td class="pdf_txt1">Operator Name :</td>
                                                        <td class="pdf_box">{{Auth::user()->first_name}} {{Auth::user()->last_name}}</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="pdf_txt1">Operator Type  :</td>
                                                        <td class="pdf_box">{{getOperatorTypeById(Auth::user()->ref_operator_type_id)}}</td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div>
                                        <div class="col-xxl-12 col-md-12">
                                            <div class="row">
                                                <div class="col-xxl-4 col-md-3 mt-4">
                                                    <div>
                                                        <label for="labelInput" class="form-label">Operator IECode  :</label>
                                                        <input type="text" class="form-control" id="" placeholder="Enter IECode"
                                                        name="ie_code" value="{{ $tcEntry->ie_code ?? '' }}" required>
                                                    </div>
                                                </div> 
                                                <div class="col-xxl-3 col-md-4 mt-4">
                                                    <div>
                                                        <label class="form-label">Choose Country for Transaction Certificate</label>
                        
                                                        <select class="form-select" name="country_origin" id="" required style=" width: 285px;">
                                                            <option value="">-Select-</option>
                                                            <option value="5" {{ (isset($tcEntry->country_origin) && $tcEntry->country_origin==5 )?'selected':'' }}>European Union</option>
                                                            <option value="6" {{ (isset($tcEntry->country_origin) && $tcEntry->country_origin==6 )?'selected':'' }}>Switzerland</option>
                                                            <option value="187" {{ (isset($tcEntry->country_origin) && $tcEntry->country_origin==187 )?'selected':'' }}>Taiwan</option>
                                                            <option value="211" {{ (isset($tcEntry->country_origin) && $tcEntry->country_origin==211 )?'selected':'' }}>Great Britain</option>
                                                            <option value="other" {{ (isset($tcEntry->country_origin) && $tcEntry->country_origin=='other' )?'selected':'' }}>Other</option>
                                                        </select>
                        
                                                    </div>
                                                </div>
                                              
                                            </div>
                                            <div class="row mt-4">
                                                <div style="text-align: center;">
                                                  
                                                    <button type="submit" class="btn btn-primary " id="submitbtn">Process </button>
                                                   
                                                </div>
                                            </div>
                                        </div>
                                    
                                    </form>

                                </div>

                            </div>
                        {{-- </div>
                    </div> --}}
                </div>
            </div>
        </div>
    @endsection
@push('script')
<script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
    <script>
        $(document).on('click', '#submitbtn', function() {
            if (checkValidation("ptcform")) {
                $('#ptcform').submit();
                return true;
            } else {
                return false;
            }
        });
    </script>
@endpush

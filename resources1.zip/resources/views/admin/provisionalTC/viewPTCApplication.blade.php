@extends('admin.layouts.app')
@section('content')
    <style>
        .pdf_maindiv {
            border: 1px solid #cccccc;
            width: 100%;
            float: left;
            padding: 2%;
        }

        .form-label blue-ht {
            font-size: 15px;
            color: #000;
            padding: 26px 0 12px 0px;
            position: relative;
            width: 100%;
            float: left;
        }
    </style>

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Application for Transaction Certificate</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Application for Transaction Certificate</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">


            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">

                    <div class="live-preview">

                        <div class="row white-inner">
                            <div class="sectitle">
                                <label for="labelInput" class="form-label  blue-ht">Packing Detail(s) Entry</label>
                            </div>
                            <form method="post" action="{{ route('superadmin.storePackingDetailTC') }}">
                                @csrf
                                <div class="col-xxl-12 col-md-12 ">
                                    <label for="labelInput" class="form-label blue-ht">Operators details:</label>
                                </div>

                                <div class="col-xxl-12 col-md-9 ms-3">
                                    <div class="row  ">
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                            <tr>
                                                <td class="pdf_txt1">Operator Name :</td>
                                                <td class="pdf_box">{{ Auth::user()->first_name }}
                                                    {{ Auth::user()->last_name }}</td>

                                                <td class="pdf_txt1">Operator Scope certificate Number :</td>
                                                <td class="pdf_box">{{ getScopeCerNoById(Auth::user()->id) }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Operator Type :</td>
                                                <td class="pdf_box">
                                                    {{ getOperatorTypeById(Auth::user()->ref_operator_type_id) }}</td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped align-middle dataTable no-footer"
                                        width="100%" id="datatable_">
                                        <thead>
                                            <tr>
                                                <th>S.No.</th>
                                                <th>Product /TC</th>
                                                <th>Status</th>
                                                <th>Total Quantity (in MT)</th>
                                                <th>Remaning Sourced (in MT)</th>
                                                <th>Sourced Quantity (in MT)</th>
                                                <th>Packing Entered</th>
                                                {{-- <th>Action</th> --}}
                                            </tr>

                                        </thead>
                                        <tbody>
                                            @forelse($trans as $tr)
                                                <tr>
                                                    <td>{{ 1. }}</td>
                                                    <td>{{ ($tr->product_code) }}</td>
                                                    <td>{{ getSingleTableRecordById('ref_organic_status_master', 'id', $tr->organic_status)->organic_status }}
                                                    </td>
                                                    <td>{{ $tr->total_qty }}</td>
                                                    <td>{{ $tr->rem_qty }}</td>
                                                    <td>{{ $tr->quantity_for_tc }}</td>
                                                    <td>No</td>
                                                    {{-- <td><a href="javascript:void(0);" onclick="getLots();">Add/Edit Packing</a></td> --}}
                                                </tr>
                                            @empty
                                            @endforelse
                                        </tbody>

                                    </table>
                                </div>

                                <div class="col-xxl-12 col-md-12 ">
                                    <label for="labelInput" class="form-label blue-ht">Product value details:</label>
                                </div>
                                <div class="col-xxl-12 col-md-12">
                                    <div class="row  ">
                                        <div class="col-xxl-4 col-md-3 ">
                                            <div>
                                                <label for="labelInput" class="form-label">Product Name :</label>

                                                {{ ($trans[0]->product_code)??'' }}
                                            </div>
                                        </div>

                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label for="labelInput" class="form-label">Value INR : </label>
                                                {{ $trans[0]->value_inr ?? '' }}

                                            </div>
                                        </div>

                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label for="labelInput" class="form-label">Trade Name :
                                                </label> {{ $trans[0]->trade_name_of_product ?? '' }}

                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="col-xxl-12 col-md-12 add-edit-div ">
                                    <label for="labelInput" class="form-label blue-ht">Packing details:</label>
                                </div>
                                <div class="col-xxl-12 col-md-12 add-edit-div">
                                    <div class="row ">
                                        <input type="hidden" name="trans_id" value="{{ $trans[0]->id ?? '' }}">

                                        <div class="col-xxl-4 col-md-6">
                                            <div>
                                                <label for="labelInput" class="form-label">Total Qty. Sourced(in Kg)
                                                    :</label>
                                                {{ $trans[0]->quantity_for_tc }}
                                            </div>
                                        </div>

                                        <div class="col-xxl-4 col-md-6">
                                            <div>
                                                <label for="labelInput" class="form-label">Reaming Qty.(in Kg) : </label>
                                                {{ $trans[0]->rem_qty }}

                                            </div>
                                        </div>
                                        <div class="table-responsive">
                                            <table
                                                class="table table-bordered table-striped align-middle dataTable no-footer"
                                                width="100%" id="datatable_">
                                                <thead>
                                                    <tr>
                                                        <th>S.No.</th>
                                                        <th>Packing Type </th>
                                                        <th>No. of units</th>
                                                        <th>Qty. (Pack size in Kg).</th>
                                                        <th>Total Qty. (in Kg)</th>

                                                    </tr>

                                                </thead>
                                                <tbody>
                                                    @forelse($trans[0]->getTransProductSource as $key => $source)

                                                        @php
                                                            $packDet = App\Models\AtOpTransactionPackingDetails::where(['at_op_transaction_product_sourced_id' => $source->id])->first();

                                                        @endphp

                                                        <tr>

                                                            <td>{{ $key + 1 }}.</td>
                                                            <td>
                                                                <select class="form-select" disabled>
                                                                    <option selected>
                                                                        {{ getPackingMasterById($packDet->ref_packing_master_id??'')->packing_type??'' }}
                                                                    </option>

                                                                </select>
                                                            </td>
                                                            <td>{{ $packDet->no_of_box ?? '' }}</td>
                                                            <td>{{ $packDet->pack_size ?? '' }}</td>
                                                            <td>{{ $packDet->total_qty_in_kg ?? '' }}</td>

                                                        </tr>
                                                    @empty
                                                    @endforelse
                                                </tbody>

                                            </table>
                                        </div>
                                        <hr>
                                        <div class="col-xxl-12 col-md-12 ">
                                            <label for="labelInput" class="form-label blue-ht">Producer/Manufacture
                                                details</label>
                                        </div>

                                        <div class="row ">

                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">Name </label>
                                                    <input type="text" class="form-control"
                                                        value="{{ Auth::guard('misadmin')->user()->first_name }}"
                                                        id="" readonly>
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">Address</label>
                                                    <input type="text" class="form-control"
                                                        value="{{ Auth::guard('misadmin')->user()->address }}"
                                                        id="" readonly>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xxl-12 col-md-12 ">
                                            <label for="labelInput" class="form-label blue-ht">Seller Information</label>
                                        </div>
                                        <div class="col-xxl-12 col-md-12">
                                            <div class="row  pdf_maindiv">
                                                <div class="col-xxl-4 col-md-6">
                                                    <div>
                                                        <label for="labelInput" class="form-label">Scope certificate number
                                                            :</label>
                                                        {{ getScopeCerNoById(Auth::user()->id) }}
                                                        <input type="hidden"
                                                            value="{{ getScopeCerNoById(Auth::user()->id) }}"
                                                            name="seller_at_op_certificate_standard_details_id">
                                                    </div>
                                                </div>

                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">Seller ID proof :
                                                        </label>
                                                        N/A
                                                    </div>
                                                </div>

                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">Seller name :</label>
                                                        <input type="hidden" name="exporter_seller_name"
                                                            value="{{ Auth::guard('misadmin')->user()->first_name ?? '' }}">
                                                        {{ Auth::guard('misadmin')->user()->first_name ?? '' }}

                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-6 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">E- mail :</label>
                                                        <input type="hidden" name="seller_email"
                                                            value="{{ Auth::guard('misadmin')->user()->email ?? '' }}">
                                                        {{ Auth::guard('misadmin')->user()->email ?? '' }}

                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-4 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">Address : </label>
                                                        <input type="hidden" name="exporter_seller_address"
                                                            value="{{ Auth::guard('misadmin')->user()->address ?? '' }}">
                                                        {{ Auth::guard('misadmin')->user()->address ?? '' }}

                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                        <div class="col-xxl-12 col-md-12">
                                            <label for="labelInput" class="form-label blue-ht">Buyer’s Details</label>
                                        </div>
                                        @php
                                            $buyerDet = App\Models\AtPurchaseRequest::where('at_user_id', Auth::guard('misadmin')->user()->id)->first();

                                        @endphp

                                        <div class="col-xxl-12 col-md-12">
                                            <div class="row  pdf_maindiv">
                                                <div class="col-xxl-4 col-md-4">
                                                    <div>
                                                        <label class="form-label">Enter buyer scope certificate Number :
                                                        </label>
                                                        {{ getScopeCerNoById(213) }}

                                                    </div>
                                                </div>

                                                <div class="col-xxl-4 col-md-4">
                                                    <div>
                                                        <label class="form-label">Buyer ID Proof : </label> N/A
                                                    </div>
                                                </div>

                                                <div class="col-xxl-4 col-md-4">
                                                    <div>
                                                        <label class="form-label">Buyer name : </label>
                                                        {{ Auth::user()->first_name ?? ''}}
                                                    </div>
                                                </div>

                                                <div class="col-xxl-4 col-md-4">
                                                    <div>
                                                        <label class="form-label">Address : </label>
                                                        {{ getUserById(Auth::user()->id)->address ?? '' }}
                                                    </div>
                                                </div>

                                                <div class="col-xxl-4 col-md-4">
                                                    <div>
                                                        <label class="form-label">State : </label>
                                                        {{ get_state_name(getUserById(Auth::user()->id)->ref_state_id) ?? '' }}
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-4">
                                                    <div>
                                                        <label class="form-label">E-mail : </label>
                                                        {{ getUserById(Auth::user()->id)->email ?? '' }}
                                                    </div>
                                                </div>



                                            </div>
                                        </div>
                                        <div class="col-xxl-12 col-md-12">
                                            <label for="labelInput" class="form-label blue-ht">Invoice details</label>
                                        </div>
                                        <div class="col-xxl-12 col-md-12">
                                            <div class="row pdf_maindiv ">

                                                <table class="table table-bordered table-striped align-middle dataTable"
                                                    width="100%" id="datatable2">
                                                    <thead class="table-success">
                                                        <tr>
                                                            <th>Invoice number </th>
                                                            <th>Date of invoice</th>

                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td> {{ $data->invoice_no ?? '' }}</td>
                                                            <td> {{ !empty($data->invoice_date) ? date('d-m-Y', strtotime($data->invoice_date)) : '' }}
                                                            </td>

                                                        </tr>
                                                    </tbody>

                                                </table>

                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label class="form-label">Invoice value (in Rs) :</label>
                                                        {{ $data->invoice_value ?? '' }}
                                                    </div>
                                                </div>

                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label class="form-label">Place of Dispatch/origin :</label>
                                                        {{ $data->place_of_dispatch ?? 'N/A' }}
                                                    </div>
                                                </div>

                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label class="form-label">Lot number :</label>
                                                        {{ $data->lot_number ?? '' }}
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label class="form-label">Place of destination :</label>
                                                        {{ $data->place_of_destination ?? '' }}
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label class="form-label">Marks & No. :</label>
                                                        {{ $data->marks_no ?? '' }}
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label class="form-label">Reference Number : </label>
                                                        {{ $data->reference_no ?? '' }}
                                                    </div>
                                                </div>



                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xxl-12 col-md-12">
                                        <label for="labelInput" class="form-label blue-ht">Transport Details</label>
                                    </div>
                                    <div class="col-xxl-12 col-md-12">
                                        <div class="row  pdf_maindiv">
                                            <div class="col-xxl-4 col-md-3">
                                                <div>
                                                    <label class="form-label">Mode of Transport :
                                                    </label> {{ $data->transport_mode ?? '' }}
                                                    <br>
                                                    {{-- <input type="radio" id="html" name="transport_mode"
                                                        value="road" {{!empty($data->transport_mode) && $data->transport_mode=='road'?'checked' : ''}}>
                                                    <label for="road">Road</label>
                                                    <input type="radio" id="css" name="transport_mode"
                                                        value="train" {{ !empty($data->transport_mode) && $data->transport_mode=='train'?'checked' : ''}}>
                                                    <label for="train">Train</label>
                                                    <input type="radio" id="html" name="transport_mode"
                                                        value="air" {{ !empty($data->transport_mode) && $data->transport_mode=='air'?'checked' : ''}}>
                                                    <label for="air">Air</label>
                                                    <input type="radio" id="css" name="transport_mode"
                                                        value="ship" {{!empty($data->transport_mode) &&  $data->transport_mode=='ship'?'checked' : ''}}>
                                                    <label for="ship">Ship</label><br>
                                                </div> --}}
                                                </div>

                                            </div>
                                        </div>
                                        @php
                                            $road_transport_date = '';
                                        @endphp
                                        @if (isset($data->transport_mode) && $data->transport_mode == 'road')
                                            @php
                                                $road_transport_date = $data->transport_date;
                                            @endphp
                                        @endif
                                        <div
                                            class="col-xxl-12 col-md-12 road_div {{ isset($data->transport_mode) && $data->transport_mode == 'road' ? '' : 'd-none' }}">
                                            <label for="labelInput" class="form-label blue-ht">Road details</label>
                                        </div>
                                        <div
                                            class="col-xxl-12 col-md-12 road_div {{ isset($data->transport_mode) && $data->transport_mode == 'road' ? '' : 'd-none' }}">
                                            <div class="row pdf_maindiv ">
                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label class="form-label">Vehicle No./Container No. : </label>
                                                        {{ $data->container_no_road ?? '' }}
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label class="form-label">Transport Document No. : </label>
                                                        {{ $data->transport_doc_no ?? '' }}
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label class="form-label">Date Of Transport :</label>
                                                        {{ !empty($road_transport_date) ? date('d-m-Y', strtotime($road_transport_date)) : '' }}
                                                    </div>
                                                </div>


                                            </div>
                                        </div>
                                        @php
                                            $train_transport_date = '';
                                        @endphp
                                        @if (isset($data->transport_mode) && $data->transport_mode == 'train')
                                            @php
                                                $train_transport_date = $data->transport_date;
                                            @endphp
                                        @endif
                                        <div
                                            class="col-xxl-12 col-md-12 train_div {{ isset($data->transport_mode) && $data->transport_mode == 'train' ? '' : 'd-none' }}">
                                            <label for="labelInput" class="form-label blue-ht">Train details</label>
                                        </div>
                                        <div
                                            class="col-xxl-12 col-md-12 train_div {{ isset($data->transport_mode) && $data->transport_mode == 'train' ? '' : 'd-none' }}">
                                            <div class="row pdf_maindiv ">
                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label class="form-label">Train No. :</label>
                                                        {{ $data->train_no ?? '' }}
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label class="form-label">Wagon No. :</label>
                                                        {{ $data->wagon_no ?? '' }}
                                                    </div>
                                                </div>

                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label class="form-label">Date of Transport :</label>
                                                        {{ !empty($train_transport_date) ? date('d-m-Y', strtotime($train_transport_date)) : '' }}
                                                    </div>
                                                </div>


                                            </div>
                                        </div>

                                        <div
                                            class="col-xxl-12 col-md-12 air_div {{ isset($data->transport_mode) && $data->transport_mode == 'air' ? '' : 'd-none' }}">
                                            <label for="labelInput" class="form-label blue-ht">Air details</label>
                                        </div>
                                        <div
                                            class="col-xxl-12 col-md-12 air_div {{ isset($data->transport_mode) && $data->transport_mode == 'air' ? '' : 'd-none' }}">
                                            <div class="row pdf_maindiv ">

                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label class="form-label">Flight No. :</label>
                                                        {{ $data->flight_no ?? '' }}
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label class="form-label">Flight Date :</label>
                                                        {{ !empty($data->flight_date) ? date('d-m-Y', strtotime($data->flight_date)) : '' }}
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label class="form-label">Airway Bill No. :</label>
                                                        {{ $data->airway_bill_no ?? '' }}
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label class="form-label">Airway Bill Date :</label>
                                                        {{ !empty($data->airway_bill_date) ? date('d-m-Y', strtotime($data->airway_bill_date)) : '' }}
                                                    </div>
                                                </div>

                                                <div class="col-xxl-4 col-md-3 gy-3">
                                                    <div>
                                                        <label class="form-label">Airway Container No. :</label>
                                                        {{ $data->container_no_air ?? '' }}
                                                    </div>
                                                </div>


                                            </div>
                                        </div>

                                        <div
                                            class="col-xxl-12 col-md-12 ship_div {{ isset($data->transport_mode) && $data->transport_mode == 'ship' ? '' : 'd-none' }}">
                                            <label for="labelInput" class="form-label blue-ht">Ship details</label>
                                        </div>
                                        <div
                                            class="col-xxl-12 col-md-12 ship_div {{ isset($data->transport_mode) && $data->transport_mode == 'ship' ? '' : 'd-none' }}">
                                            <div class="row pdf_maindiv ">

                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label class="form-label">Vessel No. :</label>
                                                        {{ $data->ship_no ?? '' }}
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label class="form-label">Vessel Name :</label>
                                                        {{ $data->ship_name ?? '' }}
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-3 gy-3">
                                                    <div>
                                                        <label class="form-label">Vessel Date :</label>
                                                        {{ !empty($data->vessel_date) ? date('d-m-Y', strtotime($data->vessel_date)) : '' }}
                                                    </div>
                                                </div>

                                                <div class="col-xxl-4 col-md-3 gy-3">
                                                    <div>
                                                        <label class="form-label">Bill of Lading No. :</label>
                                                        {{ $data->bill_of_lading ?? '' }}
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-3 gy-3">
                                                    <div>
                                                        <label class="form-label">Bill of Lading Date :</label>
                                                        {{ !empty($data->date_of_lading) ? date('d-m-Y', strtotime($data->date_of_lading)) : '' }}
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label class="form-label">Vessel Container number :</label>
                                                        {{ $data->container_no_ship ?? '' }}
                                                    </div>
                                                </div>



                                            </div>
                                        </div>
                                        <br>
                                        <div class="col-xxl-4 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Gross weight (in MT) : </label>
                                                {{ $data->gross_weight ?? '' }}
                                            </div>
                                        </div>
                            </form>

                            <a href="{{ route('superadmin.forwardToCB', $id) }}"
                            class="btn btn-primary mt-2">Back </a>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
@endsection
@push('script')
    <div class="modal fade" id="addBatchModalgrid" tabindex="-1" aria-labelledby="addBatchModalgridLabel"
        aria-modal="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addBatchModalgridLabel">Edit Product</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="batch_popup">

                </div>
            </div>
        </div>
    </div>
    <script></script>
@endpush

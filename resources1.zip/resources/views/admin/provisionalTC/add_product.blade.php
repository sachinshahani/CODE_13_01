@extends('admin.layouts.app')
@section('content')
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Application for Provision Transaction Certificate</h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Application for Provision Transaction Certificate</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <form method="post" enctype="multipart/form-data" id="registration" action="{{ route('superadmin.addProductStore') }}">
                @csrf
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                    <a class="nav-link " id="step2-tab" data-bs-toggle=""
                        href="{{ route('superadmin.applyForProvisionalTC') }}">Apply
                        For Provision TC</a>
                    <a class="nav-link active" id="step2-tab" href="">Add Product</a>
                    <a class="nav-link" href="">Packing Details</a>
                    <a class="nav-link" href="">PTC Details</a>

                </div>
                </nav>
                <div class="tab-content py-4 custom-tab-content">
                    <div class="tab-pane fade show active" id="step2">
                        <div class="flex-shrink-0">
                            @if (session('error'))
                                <div class="alert alert-danger">
                                    {{ session('error') }}
                                </div>
                            @endif
                            @if (session('success'))
                                <div class="alert alert-success">
                                    {{ session('success') }}
                                </div>
                            @endif
                            @if ($errors)
                                @foreach ($errors->all() as $error)
                                    <div class="alert alert-danger">{{ $error }}</div>
                                @endforeach
                            @endif
                        </div>
                        <div class="row white-inner">
                            <div class="col-xxl-12 col-md-12 ">
                                <label for="labelInput" class="form-label blue-ht">Batch Details</label>
                            </div>
                            @if (count($data) > 0)

                                <table class="table table-bordered table-striped align-middle dataTable no-footer"
                                    width="100%" id="datatable_">
                                    <thead>
                                        <tr>
                                            <th>Select</th>
                                            <th>Products</th>
                                            <th>Status</th>
                                            <th>Total Quantity (in MT)</th>
                                            <th>Quantity Sourced (in MT)</th>
                                            <th>Available Quantity (in MT)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse($data as $key => $vals)
                                            <tr>
                                                <input type="hidden" name="row_id[{{ $key }}]"
                                                    value="{{ $vals->id ?? '' }}">
                                                <input type="hidden" name="farm_no[{{ $key }}]"
                                                    value="{{ $vals->farm_no ?? '' }}">
                                                <td><input name="lots[{{ $key }}]" type="checkbox"
                                                        onclick="getLots('{{ $vals->id }}','{{ $vals->id }}',{{ $key }});"
                                                        required>
                                                </td>
                                                <td>{{ $vals->product_code }}</td>
                                                <td>
                                                    <input type="hidden" name="product_code[{{ $key }}]"
                                                        value="{{ $vals->product_code }}">
                                                    <input type="hidden" name="organic_status[{{ $key }}]"
                                                        value="{{ $vals->organic_status }}">
                                                    {{ 'ref_organic_status_master', 'id', $vals->organic_status }}
                                                </td>
                                                <td> <input type="hidden" name="total_qty[{{ $key }}]"
                                                        value="{{ $vals->total_qty ?? '' }}">
                                                    {{ $vals->total_qty }}</td>
                                                <td>{{ $vals->quantity_for_tc }}
                                                    <input type="hidden" name="req_qty[{{ $key }}]"
                                                        value="{{ $vals->quantity_for_tc ?? '' }}">
                                                </td>

                                                <td> <input type="hidden" name="rem_qty[{{ $key }}]"
                                                        value="{{ $vals->rem_qty ?? '0' }}">
                                                    {{ $vals->rem_qty }}
                                                </td>
                                            </tr>

                                            <tr id="tbl{{ $vals->id }}" class="d-none">
                                                <td></td>
                                                <td colspan="5">
                                                    {{-- ******************* --}}


                                                    <table class="table table-bordered table-striped align-middle dataTable"
                                                        width="100%" id="datatable2">
                                                        <thead class="table-success">
                                                            <tr>
                                                                <th>Select Batch</th>
                                                                <th>Products</th>
                                                                <th>Organic Status</th>
                                                                <th>Total Quantity (in MT)</th>
                                                                <th>Used Quantity (in MT)</th>
                                                                <th>Available Quantity (in MT)</th>
                                                                <th>Quantity for this TC (in MT)</th>
                                                                <th>Action</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>

                                                            @forelse($vals->getTransProductSource as $k =>$val)
                                                                <tr>
                                                                    <input type="hidden"
                                                                        name="rows_id[{{ $key }}][{{ $k }}]"
                                                                        value="{{ $val->id ?? '' }}">
                                                                    <input
                                                                        name="ref_product_id[{{ $key }}][{{ $k }}]"
                                                                        type="hidden"
                                                                        value="{{ $val->ref_product_id ?? '' }}">
                                                                    <input
                                                                        name="at_closing_stock_id[{{ $key }}][{{ $k }}]"
                                                                        type="hidden"
                                                                        value="{{ $val->at_closing_stock_id ?? '' }}">
                                                                    <input
                                                                        name="at_purchase_details_id[{{ $key }}][{{ $k }}]"
                                                                        type="hidden"
                                                                        value="{{ $val->at_purchase_details_id ?? '' }}">
                                                                    <input
                                                                        name="op_organic_status[{{ $key }}][{{ $k }}]"
                                                                        type="hidden"
                                                                        value="{{ getSingleTableRecordById('ref_organic_status_master', 'id', $val->organic_status)->id }}">


                                                                    <td><input
                                                                            name="pur_lots[{{ $key }}][{{ $k }}]"
                                                                            type="checkbox" id="purch{{ $val->id }}"
                                                                            onclick="getPurch('{{ $val->id }}');"
                                                                            required>
                                                                    </td>

                                                                    <td>{{ getHscodeProductName($val->ref_product_id) }}
                                                                    </td>
                                                                    <td>{{ getSingleTableRecordById('ref_organic_status_master', 'id', $vals->organic_status)->organic_status }}
                                                                    </td>
                                                                    <td>{{ $vals->total_qty ?? 0 }}</td>
                                                                    <td>{{ $vals->quantity_for_tc ?? 0 }}</td>
                                                                    <td>{{ $vals->rem_qty ?? 0 }}</td>
                                                                    <td><input type="text"
                                                                            name="qty_in_mt[{{ $key }}][{{ $k }}]"
                                                                            id="tcqty{{ $val->id }}" class="tc_qty"
                                                                            data-id="{{ $val->id ?? '' }}"
                                                                            data-avail="{{ $vals->rem_qty ?? '' }}"
                                                                            value="{{ $val->qty_in_mt ?? '' }}" required>
                                                                    </td>
                                                                    <td>
                                                                        <div class="btn btn-success btn-sm"
                                                                            onclick="addSourceQTY('{{ $val->id }}');">
                                                                            <i class="ri-add-box-fill"></i>
                                                                        </div>
                                                                    </td>

                                                                </tr>
                                                            @empty
                                                                <tr>
                                                                    <td colspan="8">No records found..</td>
                                                                </tr>
                                                            @endforelse

                                                        </tbody>

                                                    </table>
                                                    {{-- ******************** --}}
                                                </td>
                                            </tr>

                                        @empty
                                            <tr>
                                                <td colspan="6">No records found..</td>
                                            </tr>
                                        @endforelse

                                    </tbody>

                                </table>
                            @else
                                <table class="table table-bordered table-striped align-middle dataTable no-footer"
                                    width="100%" id="datatable_">
                                    <thead>
                                        <tr>
                                            <th>Select</th>
                                            <th>Products</th>
                                            <th>Status</th>
                                            <th>Total Quantity (in MT)</th>
                                            <th>Quantity Sourced (in MT)</th>
                                            <th>Available Quantity (in MT)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @if (isset($order['purchase_list']) && !empty($order['purchase_list']))
                                            @forelse($order['purchase_list'] as $key => $vals)
                                                <tr>
                                                    <input type="hidden" name="row_id[{{ $key }}]"
                                                        value="">
                                                    <input type="hidden" name="farm_no[{{ $key }}]"
                                                        value="{{ $vals->id ?? '' }}">
                                                    <td><input name="lots[{{ $key }}]" type="checkbox"
                                                            onclick="getLots('{{ $vals->id }}','{{ $vals->id }}',{{ $key }});"
                                                            required>
                                                    </td>
                                                    <td>{{ getHscodeProductName($vals->commodity) }}</td>
                                                    <td>
                                                        <input type="hidden" name="product_code[{{ $key }}]"
                                                            value="{{ $vals->commodity }}">
                                                        <input type="hidden" name="organic_status[{{ $key }}]"
                                                            value="{{ $vals->organic_status }}">
                                                        {{ getSingleTableRecordById('ref_organic_status_master', 'id', $vals->organic_status)->organic_status }}
                                                    </td>
                                                    <td> <input type="hidden" name="total_qty[{{ $key }}]"
                                                            value="{{ $vals->closing_stock ?? '' }}">
                                                        {{ $vals->closing_stock }}</td>
                                                    <td>{{ $vals->quantity }}
                                                        <input type="hidden" name="req_qty[{{ $key }}]"
                                                            value="{{ $vals->quantity ?? '' }}">
                                                    </td>
                                                    <input type="hidden" name="rem_qty[{{ $key }}]"
                                                        value="{{ $vals->closing_stock - ($vals->quantity ? $vals->quantity : 0) }}">

                                                    <td id="#rem_qty_td_{{ $key }}">
                                                        {{ $vals->closing_stock - $vals->quantity }}</td>
                                                </tr>

                                                <tr id="tbl{{ $vals->id }}" class="d-none">
                                                    <td></td>
                                                    <td colspan="5">
                                                        {{-- ******************* --}}


                                                        <table
                                                            class="table table-bordered table-striped align-middle dataTable"
                                                            width="100%" id="datatable2">
                                                            <thead class="table-success">
                                                                <tr>
                                                                    <th>Select Purchase</th>
                                                                    <th>Products</th>
                                                                    <th>Organic Status</th>
                                                                    <th>Total Quantity (in MT)</th>
                                                                    <th>Quantity Sourced (in MT)</th>
                                                                    <th>Available Quantity (in MT)</th>
                                                                    <th>Quantity for this TC (in MT)</th>
                                                                    <th>Action</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                @forelse($vals->mypurchase as $k =>$val)
                                                                    <tr>
                                                                        <input type="hidden"
                                                                            name="rows_id[{{ $key }}][{{ $k }}]"
                                                                            value="">
                                                                        <input
                                                                            name="ref_product_id[{{ $key }}][{{ $k }}]"
                                                                            type="hidden"
                                                                            value="{{ $val->commodity ?? '' }}">
                                                                        <input
                                                                            name="at_closing_stock_id[{{ $key }}][{{ $k }}]"
                                                                            type="hidden"
                                                                            value="{{ $val->at_closing_stock_id ?? '' }}">
                                                                        <input
                                                                            name="at_purchase_details_id[{{ $key }}][{{ $k }}]"
                                                                            type="hidden" value="{{ $val->id ?? '' }}">
                                                                        <input
                                                                            name="op_organic_status[{{ $key }}][{{ $k }}]"
                                                                            type="hidden"
                                                                            value="{{ $vals->organic_status ?? '' }}">

                                                                        <td><input
                                                                                name="pur_lots[{{ $key }}][{{ $k }}]"
                                                                                type="checkbox"
                                                                                id="purch{{ $val->id }}"
                                                                                onclick="getPurch('{{ $val->id }}');"
                                                                                required></td>

                                                                        <td>{{ getHscodeProductName($vals->commodity) }}
                                                                        </td>
                                                                        <td>{{ getSingleTableRecordById('ref_organic_status_master', 'id', $vals->organic_status)->organic_status }}
                                                                        </td>
                                                                        <td>{{ $val->purchase_qty ?? 0 }}</td>
                                                                        <td>{{ 0 }}</td>
                                                                        <td>{{ $val->purchase_qty }}</td>
                                                                        <td><input type="text"
                                                                                name="qty_in_mt[{{ $key }}][{{ $k }}]"
                                                                                id="tcqty{{ $val->id }}"
                                                                                class="tc_qty"
                                                                                data-id="{{ $val->id }}"
                                                                                data-avail="{{ $val->purchase_qty }}"
                                                                                value=""
                                                                                onchange="remainingQty({{ $key }},{{ $k }});"
                                                                                required></td>
                                                                        <td>
                                                                            <div class="btn btn-success btn-sm"
                                                                                onclick="addSourceQTY('{{ $val->id }}');">
                                                                                <i class="ri-add-box-fill"></i>
                                                                            </div>
                                                                        </td>

                                                                    </tr>
                                                                @empty
                                                                    <tr>
                                                                        <td colspan="8">No records found..</td>
                                                                    </tr>
                                                                @endforelse
                                                            </tbody>

                                                        </table>
                                                        {{-- ******************** --}}
                                                    </td>
                                                </tr>


                                            @empty
                                                <tr>
                                                    <td colspan="6">No records found..</td>
                                                </tr>
                                            @endforelse
                                        @endif
                                    </tbody>

                                </table>
                            @endif
                        </div>

                        <div class="btn-container white-inner" style="text-align: center;">
                            <span id="successmsg" class="badge badge-soft-success"></span><br>
                            <button type="submit" class="btn btn-primary mt-2">Proceed</button>
                            {{-- <button type="button" class="btn btn-primary" id="deleteApplicationBtn">Delete
                                Application</button> --}}
                        </div>

                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

@endsection

@push('script')
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        function getLots(id, ordid, ke) {
            if ($('input[name="lots[' + ke + ']"]').is(':checked')) {
                $('#tbl' + ordid).removeClass("d-none");
            }
        }

        function addSourceQTY(id) {
            if ($('#tcqty' + id).val() > 0) {
                $("#successmsg").html('Sourced Quantity Added Successfully.');
            }
        }

        // function getLots() {
        //     if ($('input[name="lots"]').is(':checked')) {
        //         $('#tbl_1').removeClass("d-none");
        //     }
        // }

        // function addSourceQTY() {
        //     //if ($('#tcqty' + id).val() > 0) {
        //     $("#successmsg").html('Sourced Quantity Added Successfully.');
        //     // }
        // }
    </script>
@endpush

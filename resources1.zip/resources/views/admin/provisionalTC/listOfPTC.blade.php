@extends('admin.layouts.app')
@section('content')
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Application for Transaction Certificate</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Application for Transaction Certificate</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">

           
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    {{-- <div class="card">

                        <div class="card-body"> --}}
                            <div class="card-header align-items-center d-flex">
                               
                                <div class="flex-shrink-0">
                                    
                                </div>
                            </div>
                            <div class="live-preview">

                                <div class="row white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label  blue-ht">LIST OF TRANSACTION CERTIFICATE</label>
                                    </div>
                                   
                                    <div class="table-responsive">
                                       
                                            <table class="table table-bordered table-striped align-middle dataTable no-footer"
                                            width="100%" id="datatable_">
                                            <thead>
                                                <tr>
                                                    <th>S.No.</th>
                                                    <th>TC Application No.</th>
                                                    <th>Date of Applicationn</th>
                                                    <th>Seller</th>
                                                    <th>Buyer</th>
                                                    <th>Country</th>
                                                    <th>Status</th>
                                                    <th>TC Type</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @forelse ($result as $key =>$val)
                                                @php
                                                    $buyerDet = App\Models\AtPurchaseRequest::where('at_user_id', Auth::guard('misadmin')->user()->id)->first();
                                                    
                                                @endphp
                                                <tr>
                                                    <td>{{ $key+1 }}.</td>
                                                    <td>{{ $val->tc_application_no ?? '' }}</td>
                                                    <td>{{ date('d-m-Y', strtotime($val->tc_date)) ??'' }}</td>
                                                    <td>{{ Auth::guard('misadmin')->user()->first_name ?? '' }}</td>
                                                    <td>{{ Auth::guard('misadmin')->user()->first_name ?? '' }}</td>
                                                    <td> INDIA </td>
                                                    <td>{{ $val->nop_status ?? '' }}</td>
                                                    <td> Provisional TC</td>
                                                    <td><a href="{{ route('superadmin.viewPTCApplication', $val->id) }}"> View Application </a></td>  
                                                </tr>
                                                @empty
                                                <tr>
                                                    <td colspan="9">No records found..</td>
                                                </tr>
                                                @endforelse
                                               
                                            </tbody>

                                        </table>
                                       
                                    </div>
                                    
                                   
                                </div>

                            </div>
                        {{-- </div>
                    </div> --}}
                </div>
            </div>
        </div>
    @endsection
    @push('script')
        <div class="modal fade" id="addBatchModalgrid" tabindex="-1" aria-labelledby="addBatchModalgridLabel"
            aria-modal="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addBatchModalgridLabel">Edit Product</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body" id="batch_popup">

                    </div>
                </div>
            </div>
        </div>
        <script>
         

            

            $('#datatable').DataTable();
        </script>
    @endpush

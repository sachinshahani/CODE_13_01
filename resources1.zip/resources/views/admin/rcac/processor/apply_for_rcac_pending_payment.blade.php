@extends('admin.layouts.app')
@section('content')
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">

            <h4 class="mb-sm-0">

               List pending application for payment

            </h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);"> User Management</a></li>
                    <li class="breadcrumb-item active">
                        List pending application for payment
                    </li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div>
    <div class="row">

        <div class="col-lg-12">
            <div class="card">

                <div class="card-body table-responsive">
                    {{-- <p>List Issued TCs</p> --}}
                    <table id="searchResultsTable" class="table table-bordered table-striped align-middle"
                        style="width:100%">
                        <thead>
                            <tr>
                                <th>SNo.</th>
                                <th>Registration No.</th>
                                <th>Operator Name</th>
                                <th>Application No.</th>
                                <th>Applied On(DD/MM/YYYY)</th>
                                <th>PTC No.</th>
                                <th>PTC Date</th>
                                <th>Category</th>
                                <th>Product</th>
                                <th>Quantity(in MT)</th>
                                <th>Transaction Amount(INR)</th>
                                <th>Transaction Status</th>
                                <th>Action</th>

                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td colspan="12">No Record found.</td>

                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!--end col-->
    </div>
@endsection
@push('script')
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    var table = $('#searchResultsTable').DataTable({
        dom: 'Bfrtip',
        lengthMenu: [
            [10, 25, 50, -1],
            [10, 25, 50, "All"]
        ],
        processing: true,
        serverSide: true,
        ajax: {
            url: '{{ route('PendingPaymentProcessorSearch') }}',
            type: 'GET',
            data: function(d) {
                d.financial = $('#financial').val();

            },
            error: function(xhr, error, code) {
                console.log(xhr.responseText); // This will print the error response
            }
        },
        columns: [{
                data: 'DT_RowIndex',
                name: 'DT_RowIndex',
                orderable: true
            },
            {
                data: 'reg_no',
                name: 'reg_no',
                orderable: true
            },

            {
                data: 'operator_name',
                name: 'operator_name',
                orderable: true
            },
            {
                data: 'application_no',
                name: 'application_no',
                orderable: true
            },

            {
                data: 'applied_on',
                name: 'applied_on',
                orderable: true
            },
            {
                data: 'ptc_no',
                name: 'ptc_no',
                orderable: true
            },
            {
                data: 'ptc_date',
                name: 'ptc_date',
                orderable: true
            },
            {
                data: 'category',
                name: 'category',
                orderable: true
            },
            {
                data: 'product',
                name: 'product',
                orderable: true
            },
            {
                data: 'qty',
                name: 'qty',
                orderable: true
            },
            {
                data: 'amount',
                name: 'amount',
                orderable: true
            },
            {
                data: 'status',
                name: 'status',
                orderable: true
            },
            {
                data: 'action', // New action column
                name: 'action',
                orderable: false,
                searchable: false
            }


        ],
        paging: false,
        buttons: [
            'excelHtml5',
            {
                extend: 'csvHtml5',
                title: function() {
                    return "REPORTS";
                },
                titleAttr: 'CSV REPORTS'
            },
            {
                extend: 'pdfHtml5',
                title: function() {
                    return "PDF REPORTS";
                },
                orientation: 'landscape',
                pageSize: 'A4',
                titleAttr: 'PDF REPORTS'
            }
        ],
        language: {
            emptyTable: "No Record found."
        }
    });

</script>
@endpush

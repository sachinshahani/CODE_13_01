@extends('admin.layouts.app')

@section('content')
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">
                    Add LC/Contract
                </h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);"> User Management</a></li>
                        <li class="breadcrumb-item active">
                            Add LC/Contract
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div class="live-preview">
        <form action="{{ route('Update') }}" class="commonform1" method="POST" enctype="multipart/form-data"
            id="commonform1" autocomplete="off">
            @csrf
            <input type="hidden" name="id" id="" value="{{$data->id}}">
            <div class="row gy-4">
                <div class="row seperatesec white-inner">

                    <div class="col-xxl-3 col-md-6 mt-4">
                        <div>
                            <label class="form-label">Type<span class="required">*</span></label>
                            <select class="form-select state" name="lc_type" id="lc_type" required>
                                <option value="" {{ old('lc_type', $data->lc_type) == '' ? 'selected' : '' }}>Select Type</option>
                                <option value="LC" {{ old('lc_type', $data->lc_type) == 'LC' ? 'selected' : '' }}>LC</option>
                                <option value="Contract" {{ old('lc_type', $data->lc_type) == 'Contract' ? 'selected' : '' }}>Contract</option>
                            </select>
                        </div>
                    </div>

                    <div class="col-xxl-3 col-md-6 mt-4">
                        <div>
                            <label class="form-label">LC No.<span class="required">*</span></label>
                            <input type="text" class="form-control numbersonly" id="lc_no" name="lc_no"
                                placeholder="Enter Letter of Credit Number" value="{{ $data->lc_no }}" required>
                        </div>
                    </div>

                    <div class="col-xxl-3 col-md-6 mt-4">
                        <div>

                            <label class="form-label">Upload LC Scanned Copy></label>
                            <input type="file" class="form-control textonly" id="lc_file" name="lc_file"
                                value="{{ old('lc_file') }}">

                                <a target="_BLANK"
                                    href="{{ asset('public/LC/' . $data->lc_file) }}"
                                    class="text-decoration-underline doctext">See Doc</a>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-6 mt-4">
                        <div>
                            <label class="form-label">LC Date<span class="required">*</span></label>
                            <input type="date" class="form-control " id="lc_date" name="lc_date" required
                                value="{{ $data->lc_date }}">
                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-6 mt-4">
                        <div>
                            <label class="form-label">LC Validity Date<span class="required">*</span></label>
                            <input type="date" class="form-control " id="lc_validity_date" name="lc_validity_date"
                                required value="{{ $data->lc_validity_date }}">
                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-6 mt-4">
                        <div>
                            <label class="form-label">LC QTY(in MT)<span class="required">*</span></label>
                            <input type="text" class="form-control numbersonly" id="lc_qty" name="lc_qty"
                                placeholder="Enter Quantity" required value="{{ $data->lc_qty }}">
                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-6 mt-4">
                        <div>
                            <label class="form-label">Importer Name<span class="required">*</span></label>
                            <input type="text" class="form-control textonly" id="importer_name" name="importer_name"
                                placeholder="Enter Name" required value="{{ $data->importer_name }}">
                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-6 mt-4">
                        <div>
                            <label class="form-label">Importer Address<span class="required">*</span></label>
                            <input type="text" class="form-control textonly" id="importer_address"
                                value="{{ $data->importer_address }}" name="importer_address" placeholder="Enter Address"
                                required value="{{ old('importer_address') }}">
                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-6 mt-4">
                        <div>
                            <label class="form-label">Importer Country<span class="required">*</span></label>
                            <select class="form-select state" name="importer_country" id="importer_country" required>
                                <option value="">Select Country</option>
                                @forelse(getRefCountryMaster() as $country)
                                    <option value="{{ $country->id }}" {{ old('importer_country', $data->importer_country) == $country->id ? 'selected' : '' }}>
                                        {{ $country->country_name }}
                                    </option>
                                @empty
                                    <option value="" disabled>No countries available</option>
                                @endforelse
                            </select>
                        </div>
{{--
                        <div class="display-selection">
                            Selected Importer Country:
                            @if($data->importer_country)
                                {{ getRefCountryMaster()->where('id', $data->importer_country)->first()->country_name }}
                            @else
                                None
                            @endif
                        </div> --}}

                    </div>
                    <div class="col-xxl-12 col-md-12 mt-4">
                        <div style="border: 1px solid #888; padding: 15px; border-radius: 5px;">
                            <label class="form-label">Declaration:</label>

                            <label style="color: rgb(136, 129, 139); display: block;">
                                <input type="checkbox" class="form-check-input" id="declaration" name="declaration">

                                I/we
                                hereby declare that the information and document submitted by me/us are correct and true to
                                the best of my/our knowledge and belief. Incase, it is found to be false I/We would be held
                                responsible and I/We hereby indemnify APEDA from the implications, if any, arising from
                                submission of wrong information in the application.
                            </label>

                        </div>
                    </div>
                    <div class="col-xxl-12 col-md-12 mt-4 text-center">
                        <button type="submit" class="btn btn-primary" id="registerBtn">Update</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
@endsection

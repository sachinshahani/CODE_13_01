@extends('admin.layouts.app')

@section('content')
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">

                <h4 class="mb-sm-0">

                  Application For RCAC

                </h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);"> User Management</a></li>
                        <li class="breadcrumb-item active">
                            Application For RCAC
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div class="live-preview">
        <form action="{{ route('ApllyForRCACProcessorSave' , $id) }}" class="commonform1" method="POST" enctype="multipart/form-data"
            id="commonform1" autocomplete="off">
            @csrf

            <div class="row gy-4">
                <div class="row seperatesec white-inner">

                    <div class="col-xxl-4 col-md-6 mt-4">
                        <div>
                            <label class="form-label">Select LC<span class="required">*</span></label>
                            <select class="form-select state" name="lc_type" id="lc_type" required>
                                <option value="">Select Type</option>
                                <option value="LC">LC</option>
                                <option value="Contract">Contract</option>

                            </select>
                        </div>
                    </div>

                    <div class="col-xxl-4 col-md-6 mt-4">
                        <div>
                            <label class="form-label">Select LC No.<span class="required">*</span></label>
                            <select class="form-select state" name="lc_no" id="lc_no" required>
                                <option value="">Select LC No</option>
                                @forelse ( $data as $val )
                                <option value="{{$val->lc_no}}">{{$val->lc_no}}</option>

                                @empty

                                @endforelse

                                {{-- <option value="Contract">Contract</option> --}}

                            </select>
                        </div>
                    </div>
                    <div class="col-xxl-4 col-md-6 mt-4">
                        <div>
                            <label class="form-label">Enter Provisional Transaction Certificate(PTC) No. <span class="required">*</span></label>
                            <input type="text" class="form-control" id="ptc_no"
                               name="ptc_no" placeholder="Enter PTC No"
                                required value="{{ old('ptc_no') }}">
                        </div>
                    </div>

                    <div class="col-xxl-12 col-md-12 mt-5 text-center">
                        <button type="submit" class="btn btn-primary" id="registerBtn">Proceed</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
@endsection

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payment Process</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }
        .container {
            width: 100%;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #ffffff;
            border: 1px solid #dddddd;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .header {
            background-color: #1a4876;
            color: white;
            padding: 10px 0;
            text-align: center;
        }
        .content {
            padding: 20px;
        }
        .transaction-details {
            width: 100%;
            border-collapse: collapse;
        }
        .transaction-details th, .transaction-details td {
            padding: 10px;
            border: 1px solid #dddddd;
            text-align: left;
        }
        .transaction-details th {
            background-color: #f9f9f9;
        }
        .submit-button {
            text-align: center;
            margin-top: 20px;
        }
        .submit-button button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #1a4876;
            color: white;
            border: none;
            cursor: pointer;
        }
        .submit-button button:hover {
            background-color: #163b61;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>Payment Process</h2>
        </div>
        <div class="content">
            <form action="{{ route('payment.create') }}" method="POST">
                @csrf
                <input type="hidden" name="user_id" value="{{auth()->user()->id}}" readonly>
                <input type="hidden" name="rc_id" value="{{$rc_id}}" readonly>
                <table class="transaction-details">
                    <tr>
                        <th>Transaction Details</th>
                        <th></th>
                    </tr>
                    <tr>
                        <td>Order No.</td>
                        <td><input type="text" name="orderId" value="{{ $orderNo }}" readonly></td>
                    </tr>
                    <tr>
                        <td>service ID.</td>
                        <td><input type="text" name="serviceId" value="{{ $orderNo. time() }}" readonly></td>
                    </tr>
                    <tr>
                        <td>Amount Payable</td>
                        <td><input type="text" name="amount" value="2.00" readonly></td>
                    </tr>
                    <tr>
                        <td>Currency Type</td>
                        <td><input type="text" name="currency" value="INR" readonly></td>
                    </tr>
                </table>
                <div class="submit-button">
                    <button type="submit">Submit</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>

@extends('admin.layouts.app')

@section('content')
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">

                <h4 class="mb-sm-0">

                    LC/Contract Details

                </h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);"> User Management</a></li>
                        <li class="breadcrumb-item active">

                            LC/Contract Details

                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-12 mt-2">
        @if (session('success'))
            <div class="alert alert-success" id="validate">
                {{ session('success') }}
            </div>
        @endif

        @if (session('importErrors'))
            <div class="alert alert-danger">
                <p>Following Errors Occured While Uploading the list, Please fix and upload again</p>
                <ul>
                    @foreach (session('importErrors') as $failure)
                        @foreach ($failure->errors() as $f)
                            <li>{{ $f . ' at row ' . $failure->row() }}</li>
                        @endforeach
                    @endforeach
                </ul>
            </div>
        @endif
    </div>

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <div class="row justify-content-end mb-2">
                        <div class="col-2">
                            <a href="{{ route('LcEntryAdd') }}" class="btn btn-primary" style="float: right">Add </a>
                        </div>
                    </div>
                </div>
                <div class="card-body table-responsive white-inner">
                    <table id="datatable" class="table table-bordered table-striped align-middle" style="width:100%">
                        <thead>
                            <tr>
                                <th>S.No.</th>
                                <th>LC No.</th>
                                <th>Type</th>
                                <th>LC Qty(in MT)</th>
                                <th>LC Date</th>
                                <th>LC Validity Date</th>
                                <th>Importer Name</th>
                                <th>Importer Address</th>
                                <th>Importer Country</th>
                                <th>Certificate</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        @foreach ($data as $key => $row)
                            <tbody>

                                <td>{{ $key + 1 }}</td>
                                <td>{{ $row->lc_no ?? '' }}</td>
                                <td>{{ $row->lc_type ?? '' }}</td>
                                <td>{{ $row->lc_qty ?? '' }}</td>
                                <td>{{ $row->lc_date ?? '' }}</td>
                                <td>{{ $row->lc_validity_date ?? '' }}</td>
                                <td>{{ $row->importer_name ?? '' }}</td>
                                <td>{{ $row->importer_address ?? '' }}</td>
                                <td>{{ getCountryName($row->importer_country ?? '') }}</td>

                                <td>
                                    <a target="_BLANK"
                                    href="{{ asset('public/LC/' . $row->lc_file) }}"
                                    class="text-decoration-underline doctext">View</a>
                                </td>

                                <td>
                                    <a href="{{ route('Edit', ['id' => $row->id]) }}" class="btn btn-primary">Edit</a>
                                    <a href="{{ route('Delete', ['id' => $row->id]) }}" class="btn btn-danger">Delete</a>
                                </td>

                            </tbody>
                        @endforeach
                    </table>
                </div>
            </div>
        </div>
        <!--end col-->
    </div>
    <!--end row-->

@endsection



@push('script')
    <script>
        // $.ajaxSetup({
        //     headers: {
        //         'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        //     }
        // });

        // var table = $('#datatable').DataTable({
        //             //dom: 'l<"clear">Bfrtip',
        //             dom: 'Bfrtip',

        //             //dom:'Blfrtip',
        //             lengthMenu: [
        //                 [10, 25, 50, -1],
        //                 [10, 25, 50, "All"]
        //             ],
        //             processing: true,
        //             serverSide: true,
        //             ajax: {
        //                 url: '',
        //                 type: 'GET',
        //                 data: function(d) {
        //                     d._token = "{{ csrf_token() }}";
        //                     d.status = $("#search").val();
        //                 }

        //             },
        //             columns: [{
        //                     data: 'DT_RowIndex',
        //                     name: 'DT_RowIndex',
        //                     orderable: true
        //                 },
        //                 {
        //                     data: 'lc_no',
        //                     name: 'lc_no',
        //                     orderable: true
        //                 },
        //                 {
        //                     data: 'type',
        //                     name: 'type',
        //                     orderable: true
        //                 },
        //                 {
        //                     data: 'lc_qty',
        //                     name: 'lc_qty',
        //                     orderable: true
        //                 },
        //                 {
        //                     data: 'lc_date',
        //                     name: 'lc_date',
        //                     orderable: true
        //                 },
        //                 {
        //                     data: 'lc_validity',
        //                     name: 'lc_validity',
        //                     orderable: true
        //                 },
        //                 {
        //                     data: 'importer_name',
        //                     name: 'importer_name',
        //                     orderable: true
        //                 },

        //                 {
        //                     data: 'importer_address',
        //                     name: 'importer_address',
        //                     orderable: true
        //                 },
        //                 {
        //                     data: 'importer_country',
        //                     name: 'importer_country',
        //                     orderable: true
        //                 },
        //                 {
        //                     data: 'certificate',
        //                     name: 'certificate',
        //                     orderable: true
        //                 },
        //                 {
        //                     data: 'action',
        //                     name: 'name',
        //                     orderable: false
        //                 },
        //             ],
        //             paging: false,
        //                     dom: 'Bfrtip',
        //                     buttons: [
        //                         'excelHtml5',
        //                         {
        //                             extend : 'csvHtml5',
        //                             title : function() {
        //                                 return "REPORTS";
        //                             },


        //                             titleAttr : 'CSV REPORTS'
        //                         },
        //                         {
        //                             extend : 'pdfHtml5',
        //                             title : function() {
        //                                 return "PDF REPORTS";
        //                             },
        //                             orientation : 'landscape',
        //                             pageSize : 'A4',

        //                             titleAttr : 'PDF REPORTS'
        //                         },

        //                     ]

        //     });
    </script>
@endpush

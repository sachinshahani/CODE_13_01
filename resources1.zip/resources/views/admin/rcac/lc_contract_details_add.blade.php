@extends('admin.layouts.app')

@section('content')
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">
                    Add LC/Contract
                </h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);"> User Management</a></li>
                        <li class="breadcrumb-item active">
                            Add LC/Contract
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div class="live-preview">
        <form action="{{ route('LcEntrySave') }}" class="commonform1" method="POST" enctype="multipart/form-data"
            id="commonform1" autocomplete="off">
            @csrf

            <div class="row gy-4">
                <div class="row seperatesec white-inner">

                    <div class="col-xxl-3 col-md-6 mt-4">
                        <div>
                            <label class="form-label">Type<span class="required">*</span></label>
                            <select class="form-select state" name="lc_type" id="lc_type" required>
                                <option value="">Select Type</option>
                                <option value="LC">LC</option>
                                <option value="Contract">Contract</option>

                            </select>
                        </div>
                    </div>

                    <div class="col-xxl-3 col-md-6 mt-4">
                        <div>
                            <label class="form-label">LC No.<span class="required">*</span></label>
                            <input type="text" class="form-control numbersonly" id="lc_no" name="lc_no"
                                placeholder="Enter Letter of Credit Number"  required>
                        </div>
                    </div>

                    <div class="col-xxl-3 col-md-6 mt-4">
                        <div>
                            <label class="form-label">Upload LC Scanned Copy></label>
                            <input type="file" class="form-control textonly" id="lc_file" name="lc_file"
                                value="{{ old('lc_file') }}">
                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-6 mt-4">
                        <div>
                            <label class="form-label">LC Date<span class="required">*</span></label>
                            <input type="date" class="form-control " id="lc_date" name="lc_date" required
                                >
                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-6 mt-4">
                        <div>
                            <label class="form-label">LC Validity Date<span class="required">*</span></label>
                            <input type="date" class="form-control " id="lc_validity_date" name="lc_validity_date"
                                required >
                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-6 mt-4">
                        <div>
                            <label class="form-label">LC QTY(in MT)<span class="required">*</span></label>
                            <input type="text" class="form-control numbersonly" id="lc_qty" name="lc_qty"
                                placeholder="Enter Quantity" required >
                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-6 mt-4">
                        <div>
                            <label class="form-label">Importer Name<span class="required">*</span></label>
                            <input type="text" class="form-control textonly" id="importer_name" name="importer_name"
                                placeholder="Enter Name"  required >
                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-6 mt-4">
                        <div>
                            <label class="form-label">Importer Address<span class="required">*</span></label>
                            <input type="text" class="form-control textonly" id="importer_address"
                               name="importer_address" placeholder="Enter Address"
                                required >
                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-6 mt-4">
                        <div>
                            <label class="form-label">Importer Country<span class="required">*</span></label>
                            <select class="form-select state" name="importer_country" id="importer_country" required>
                                <option value="">Select Country</option>
                                @forelse(getRefCountryMaster() as $country)
                                    <option value="{{ $country->id }}" @selected(old('country') == $country->id)>
                                        {{ $country->country_name }}
                                    </option>
                                @empty
                                @endforelse
                            </select>
                        </div>
                    </div>
                    <div class="col-xxl-12 col-md-12 mt-4">
                        <div style="border: 1px solid #888; padding: 15px; border-radius: 5px;">
                            <label class="form-label">Declaration:</label>

                            <label style="color: rgb(136, 129, 139); display: block;">
                                <input type="checkbox" class="form-check-input" id="declaration" name="declaration">

                                I/we
                                hereby declare that the information and document submitted by me/us are correct and true to
                                the best of my/our knowledge and belief. Incase, it is found to be false I/We would be held
                                responsible and I/We hereby indemnify APEDA from the implications, if any, arising from
                                submission of wrong information in the application.
                            </label>

                        </div>
                    </div>
                    <div class="col-xxl-12 col-md-12 mt-4 text-center">
                        <button type="submit" class="btn btn-primary" id="registerBtn">Save</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
@endsection

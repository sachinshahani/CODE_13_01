@extends('admin.layouts.app')
<style>
    table {
        width: 100%;
        border-collapse: collapse;
    }

    th,
    td {
        border: 1px solid black;
        padding: 8px;
        text-align: left;
    }

    th {
        background-color: rgba(204, 214, 218, 0.986);
    }

    .checkbox-cell {
        text-align: center;
    }

    .form-box {
        border: 1px solid #ccc;
        /* Light gray border */
        padding: 20px;
        /* Padding inside the box */
        border-radius: 5px;
        /* Rounded corners */
        background-color: #f9f9f9;
        /* Light background color */
    }

    .scrollable-table {
        max-height: 150px;
        /* Adjust the height as needed */
        overflow-y: auto;
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    th,
    td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
    }

    th {
        background-color: #f2f2f2;
    }
</style>
@section('content')
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">

                <h4 class="mb-sm-0">

                    Application For RCAC

                </h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);"> User Management</a></li>
                        <li class="breadcrumb-item active">
                            Application For RCAC
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div class="live-preview">
        <form action="{{ route('ApplicationForRCACSave') }}" class="commonform1" method="POST"
            enctype="multipart/form-data" id="commonform1" autocomplete="off">
            @csrf
            <input type="hidden" name="id" id="" value="{{ $data->id ?? '' }}">
            <div class="row gy-4">
                <div class="row seperatesec white-inner">

                    <label class="form-label">Exporter Information:</label>
                    <div style="border: 1px solid #108d16; padding: 15px; border-radius: 5px;">

                        <div class="row">
                            <div class="col-12 col-sm-12 col-md-6 col-lg-4 mt-2">
                                <div>
                                    <label class="form-label">Registration No.</label>
                                    <input type="text" class="form-control numbersonly" readonly id="registration_no"
                                        name="registration_no" value="{{ $user->registration_no }}">
                                </div>
                            </div>
                            <div class="col-12 col-sm-12 col-md-6 col-lg-4 mt-2">
                                <div>
                                    <label class="form-label">Exporter Name</label>
                                    <input type="text" class="form-control" id="exporter_name" readonly
                                        name="exporter_name" value="{{ $user->first_name }} ">
                                </div>
                            </div>
                            <div class="col-12 col-sm-12 col-md-6 col-lg-4 mt-2">
                                <div>
                                    <label class="form-label">PTC No.</label>
                                    <input type="text" class="form-control" id="exporter_name" readonly
                                        name="exporter_name" value="PTC-2405140058">
                                </div>
                            </div>
                        </div>
                    </div>

                    <label class="form-label">Application Details:</label>
                    <div class="col-xxl-2 col-md-4 mt-4">

                        <div>
                            <label class="form-label">Application Date</label>
                            <input type="date" class="form-control numbersonly" id="application_date"
                                name="application_date">
                        </div>

                    </div>

                    <div class="col-xxl-2 col-md-6 mt-4">
                        <div>
                            <label class="form-label">Select Quota/Non Quota</label>
                            <select class="form-select state" name="quota" id="quota">
                                <option value="">Select</option>
                                <option value="quota">Quota</option>
                                <option value="non-quota">Non Quota</option>

                            </select>
                        </div>

                    </div>
                    <div class="col-xxl-2 col-md-6 mt-4">
                        <div>
                            <label class="form-label">APEDA Office</label>
                            <select class="form-select state" name="office" id="office">
                                <option value="">Select</option>
                                <option value="delhi">APEDA Delhi</option>


                            </select>
                        </div>
                    </div>
                    <div class="col-xxl-2 col-md-6 mt-4">
                        <div>
                            <label class="form-label">Trade Notice No.</label>
                            <select class="form-select state" name="trade_notice_no" id="trade_notice_no">
                                <option value="">Select</option>
                                <option value="123456">123456</option>
                                <option value="654321">654321</option>

                            </select>
                        </div>
                    </div>
                    <div class="col-xxl-2 col-md-6 mt-4">
                        <div>
                            <label class="form-label">Product Category</label>
                            <select class="form-select state" name="product_category" id="product_category">
                                <option value="">Select</option>
                                @forelse(getAllCategory() as $category)
                                    <option value="{{ $category->id }}"
                                        {{ old('category_name') == $category->id ? 'selected' : '' }}>
                                        {{ $category->category_name }}
                                    </option>
                                @empty
                                    <option value="" disabled>No countries available</option>
                                @endforelse


                            </select>
                        </div>
                    </div>

                    <div class="scrollable-table mt-4">
                        <table>
                            <tr>
                                <th>Select</th>
                                <th>HSCODE</th>
                                <th>Product Name</th>
                                <th>Organic Status</th>
                                <th>Quantity (in MT)</th>
                            </tr>
                            <tr>
                                <td class="checkbox-cell"><input type="checkbox" name="product[0][select]" value="1">
                                </td>
                                <td><input type="hidden" name="hscode" value="08061000">08061000</td>
                                <td><input type="hidden" name="product_name" value="Lentils">Lentils</td>
                                <td><input type="hidden" name="product_status" value="MVOI">MVOI</td>
                                <td><input type="hidden" name="quantity" value="0.001">0.001</td>
                            </tr>
                            <tr>
                                <td class="checkbox-cell"><input type="checkbox" name="product[0][select]"
                                        value="1"></td>
                                <td><input type="hidden" name="hscode" value="08061000">08061000</td>
                                <td><input type="hidden" name="product_name" value="Lentils">Lentils</td>
                                <td><input type="hidden" name="product_status" value="MVOI">MVOI</td>
                                <td><input type="hidden" name="quantity" value="0.001">0.001</td>
                            </tr>
                            <tr>
                                <td class="checkbox-cell"><input type="checkbox" name="product[0][select]"
                                        value="1"></td>
                                <td><input type="hidden" name="hscode" value="08061000">08061000</td>
                                <td><input type="hidden" name="product_name" value="Lentils">Lentils</td>
                                <td><input type="hidden" name="product_status" value="MVOI">MVOI</td>
                                <td><input type="hidden" name="quantity" value="0.001">0.001</td>
                            </tr>
                            <tr>
                                <td class="checkbox-cell"><input type="checkbox" name="product[0][select]"
                                        value="1"></td>
                                <td><input type="hidden" name="hscode" value="08061000">08061000</td>
                                <td><input type="hidden" name="product_name" value="Lentils">Lentils</td>
                                <td><input type="hidden" name="product_status" value="MVOI">MVOI</td>
                                <td><input type="hidden" name="quantity" value="0.001">0.001</td>
                            </tr>
                            <tr>
                                <td class="checkbox-cell"><input type="checkbox" name="product[0][select]"
                                        value="1"></td>
                                <td><input type="hidden" name="hscode" value="08061000">08061000</td>
                                <td><input type="hidden" name="product_name" value="Lentils">Lentils</td>
                                <td><input type="hidden" name="product_status" value="MVOI">MVOI</td>
                                <td><input type="hidden" name="quantity" value="0.001">0.001</td>
                            </tr>
                            <!-- Add more rows as needed -->
                        </table>
                    </div>


                    <div class="col-xxl-3 col-md-6 mt-4">
                        <div>
                            <label class="form-label">LC No.</label>
                            <input type="text" class="form-control numbersonly" id="lc_no" name="lc_no"
                                value="{{ $importer->lc_no ?? '' }}" readonly>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-6 mt-4">
                        <div>
                            <label class="form-label">Validity Date</label>
                            <input type="date" class="form-control " id="validity_date" name="validity_date"
                                value="{{ $importer->lc_validity_date ?? '' }}" readonly>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-6 mt-4">
                        <div>
                            <label class="form-label">Remaining Qty(in MT)</label>
                            <input type="text" class="form-control numbersonly" id="remaining_qty"
                                name="remaining_qty" value="{{ $importer->lc_qty ?? '' }}" readonly>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-6 mt-4">
                        <div>
                            <label class="form-label">Applying Qty(in MT)</label>
                            <input type="text" class="form-control numbersonly" id="applying_qty" name="applying_qty"
                                value="0.001" readonly>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-6 mt-4">
                        <div>
                            <label class="form-label">F.O.B per MT</label>
                            <input type="text" class="form-control numbersonly" id="fob" name="fob">
                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-6 mt-4">
                        <div>
                            <label class="form-label">Port Of Origin</label>
                            <select class="form-select state" name="port_of_origin" id="port_of_origin">
                                <option value="">Select</option>
                                <option value="Hong Kong">Hong Kong</option>
                                <option value="Yantian">Yantian</option>



                            </select>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-6 mt-4">
                        <div>
                            <label class="form-label">CIF / C&F Value :</label>
                            <select class="form-select state" name="value" id="value" required>
                                <option value="">Select</option>
                                <option value="cif value">CIF Value</option>
                                <option value="c$f value">C&F Value</option>


                            </select>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-6 mt-4">
                        <div>
                            <label class="form-label">CIF Amount</label>
                            <input type="text" class="form-control numbersonly" id="cif_amount" name="cif_amount"
                                required>
                        </div>
                    </div>


                    <div class="col-xxl-12 col-md-12 mt-4 form-box">
                        <label class="form-label">IMPORTER INFORMATION</label>
                        <div class="row">
                            <div class="col-xxl-3 col-md-6 mt-4">
                                <div>
                                    <label class="form-label">Importer Name</label>
                                    <input type="text" class="form-control" id="importer_name" name="importer_name"
                                        value="{{ $importer->importer_name ?? '' }}">
                                </div>
                            </div>
                            <div class="col-xxl-3 col-md-6 mt-4">
                                <div>
                                    <label class="form-label">Importer Address</label>
                                    <input type="text" class="form-control" id="importer_address"
                                        name="importer_address" value="{{ $importer->importer_address ?? '' }}">
                                </div>
                            </div>
                            <div class="col-xxl-3 col-md-6 mt-4">
                                <div>
                                    <label class="form-label">Certificate Dispatch By</label>
                                    <select class="form-select state" name="certificate_dispatch_by"
                                        id="certificate_dispatch_by">
                                        <option value="">Select</option>
                                        <option value="Online">Online</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-xxl-3 col-md-6 mt-4">
                                <div>
                                    <label class="form-label">Importer Country</label>
                                    <select class="form-select state" name="importer_country" id="importer_country"
                                        required>
                                        <option value="">Select Country</option>
                                        @forelse(getRefCountryMaster() as $country)
                                            <option value="{{ $country->id }}"
                                                {{ old('importer_country', $importer->importer_country ?? '') == $country->id ? 'selected' : '' }}>
                                                {{ $country->country_name }}
                                            </option>
                                        @empty
                                            <option value="" disabled>No countries available</option>
                                        @endforelse
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <label class="form-label">Mode Of Payment</label>

                    <div class="col-xxl-2 col-md-6 mt-2">

                        <div>

                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="mode_of_payment"
                                    id="mode_of_payment">
                                <label class="form-check-label" for="flexRadioDefault1">
                                    Online
                                </label>
                            </div>


                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-6 mt-2">
                        <div>

                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="mode_of_payment"
                                    id="mode_of_payment">
                                <label class="form-check-label" for="flexRadioDefault1">
                                    Offline
                                </label>
                            </div>


                        </div>
                    </div>



                    <div class="col-xxl-12 col-md-12 mt-4">
                        <div style="border: 1px solid #888; padding: 15px; border-radius: 5px;">
                            <label class="form-label">Declaration:<span class="required">*</span></label>

                            <label style="color: rgb(136, 129, 139); display: block;">
                                <input type="checkbox" class="form-check-input" id="declaration" name="declaration">

                                I/we
                                hereby declare that the information and document submitted by me/us are correct and true to
                                the best of my/our knowledge and belief. Incase, it is found to be false I/We would be held
                                responsible and I/We hereby indemnify APEDA from the implications, if any, arising from
                                submission of wrong information in the application.
                            </label>

                        </div>
                    </div>
                    <div class="col-xxl-12 col-md-12 mt-4 text-center">
                        <button type="submit" class="btn btn-primary" id="registerBtn">Proceed</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
@endsection

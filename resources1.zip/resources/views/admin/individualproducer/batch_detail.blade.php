@extends('admin.layouts.app')
@section('content')

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Batch Creation</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Batch Creation</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">

        <nav>
            <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                <a class="nav-link " id="step0-tab" href="{{route('superadmin.batchCreation', auth()->user()->id)}}">Product Details</a>
                <a class="nav-link" id="step2-tab" href="">Processed Details</a>
                <a class="nav-link" id="step3-tab" href="javascript:void(0);">Source Details</a>
                <a class="nav-link " id="step4-tab" href="javascript:void(0);">Preview</a>
                <a class="nav-link active" id="step4-tab" href="javascript:void(0);">Batch Details</a>
                <!-- <a class="nav-link" id="step4-tab"
                        href="javascript:void(0);">Product Details</a> -->
            </div>
        </nav>
    </div>
</div>



<div class="row  white-inner">

    <div class="col-lg-12">
        <div class="card">

            <div class="card-body table-responsive white-inner">
               <b><p>Batch Details:</p></b>
                <table id="searchResultsTable" class="table table-bordered table-striped align-middle" style="width:100%">
                    <thead>
                        <tr>
                            <th>Batch ID</th>
                            <th>Product Name</th>
                            <th>Total Quantity (in MT)</th>
                            <th>Batch Created Date</th>
                            <th>Source From </th>
                            {{-- <th>Expiry Date</th> --}}
                            <th>Action</th>

                        </tr>
                    </thead>
                    @forelse($data as $product)
                    <tbody>

                        <tr class="pro-tr">


                            <td>{{$product->product_code ?? ''}}</td>
                            <td>{{$product->product_name ?? ''}}</td>
                            <td>{{$product->total_quantity ?? ''}}</td>
                            <td>{{ $product->created_at ? $product->created_at->format('Y-m-d') : '' }}</td>
                            <td>{{$product->source_from ?? ''}}</td>
                            {{-- <td>{{$product->expiry_date ?? ''}}</td> --}}
                            <td>
                            <a href="JavaScript:void(0);" class="deletedata" data-value="{{$product->id }}"><span><i class="mdi mdi-delete-circle text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Delete User"></i></span></a>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="8">No records found..</td>
                        </tr>

                    </tbody>
                    @endforelse
                </table>
            </div>

        </div>
        <p style="color: red;">Note: Delete is allowed till 7 days from Date of Creation of Batch(s)</p>

    </div>
    <!--end col-->
</div>
@endsection
@push('script')
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

        $(document).on('click', '.deletedata', function() {
            var id = $(this).attr('data-value');

            Swal.fire({
                title: 'Are you sure?',
                // html: '<input type="text" id="deletionReason" class="swal2-input" placeholder="Enter reason for deletion...">',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.value) {
                    var deletionReason = $('#deletionReason').val();
                    $.ajax({
                        url: "{{ route('superadmin.usermanagement.batchDelete') }}",
                        method: "POST",
                        dataType: 'json',
                        data: {
                            'id': id,
                            'deletionReason': deletionReason,
                            '_token': '{{ csrf_token() }}',
                        },
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function(result) {
                            Swal.fire('Deleted!', 'Record Deleted Successfully..', 'success')
                                .then((result) => {
                                    window.location.href =
                                        '';
                                });
                        }

                    });
                }
            });
        });


</script>
@endpush

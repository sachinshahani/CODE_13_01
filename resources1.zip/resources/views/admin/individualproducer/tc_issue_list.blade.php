@extends('admin.layouts.app')

@section('content')
    <div class="clearfix"></div>

    <div class="col-md-12 mt-2">
        @if (session('success'))
            <div class="alert alert-success" id="validate">
                {{ session('success') }}
            </div>
        @endif

        @if (session('importErrors'))
            <div class="alert alert-danger">
                <p>Following Errors Occured While Uploading the list, Please fix and upload again</p>
                <ul>
                    @foreach (session('importErrors') as $failure)
                        @foreach ($failure->errors() as $f)
                            <li>{{ $f . ' at row ' . $failure->row() }}</li>
                        @endforeach
                    @endforeach
                </ul>
            </div>
        @endif
    </div>

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0" style="float: left">
                        List of Transaction Certificate issued
                    </h5>

                </div>
                <div class="card-body table-responsive">
                    <table id="tcIssueList" class="table datatable table-bordered table-striped align-middle" style="width:100%">
                        <thead>
                            <tr>
                                <th>S.No.</th>
                                <th>TC Application No</th>
                                <th>Operator Type</th>
                                <th>Transaction Certificate Number</th>
                                <th>TC Date</th> 
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($tcIssueList as $tcIssueListData)
                            <tr>
                                <td>{{$loop->iteration}}</td>
                                <td>{{$tcIssueListData->tc_application_no}}</td>
                                <td>{{getOperatorTypeById($tcIssueListData->operator_type)}}</td>
                                <td>{{$tcIssueListData->transaction_certificate_no}}</td>
                                <td>{{$tcIssueListData->tc_date}}</td>
                                <td><a href="{{route('superadmin.IP.cb.TcViewApplication', ['id'=>$tcIssueListData->id])}}">View Application</a></td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!--end col-->
    </div>
    <!--end row-->

@endsection
@push('script')
    <script>
        // Initialize DataTables on the table with the 'datatable' class
        $(document).ready(function () {
            $('.datatable').DataTable();
        });
    </script>
@endpush
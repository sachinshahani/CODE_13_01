@extends('admin.layouts.app')
@section('content')

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Batch Creation</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Batch Creation</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <nav>
            <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">
                <a class="nav-link active" id="step0-tab" href="{{ route('whbatchCreationindex', auth()->user()->id ) }}">Product Details</a>
                <a class="nav-link " id="step2-tab" href="">Processed Details</a>
                <a class="nav-link" id="step3-tab" href="javascript:void(0);">Source Details</a>
            <a class="nav-link " id="step4-tab" href="javascript:void(0);">Preview</a>
                <a class="nav-link" id="step3-tab" href="javascript:void(0);">Batch Details</a>
            </div>
        </nav>
        <div class="tab-content py-4 custom-tab-content">
            <div class="tab-pane fade show active" id="step0">
                <div class="card">
                    <div class="card-body">
                        <div class="live-preview">
                            <div class="row seperatesec white-inner">
                                <div class="sectitle">
                                    <label for="labelInput" class="form-label blue-ht">PRODUCT DETAIL</label>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped align-middle dataTable no-footer" width="100%" id="datatable">
                                            <thead>
                                                <tr>
                                                    <th>S.No.</th>
                                                    <th>Product Name</th>
                                                    <th>Organic Status</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @forelse($product_details as $product)
                                                <tr class="pro-tr">
                                                    <td>1</td>
                                                    <td>{{$product->details_name_of_corp ?? ''}}</td>

                                                 <td>{{getRefOrganicStatuscodeByname($product->organic_status ?? '')}}</td>
                                                    <td>
                                                        <a href="{{route('superadmin.ipbatchCreation',[$product->at_user_id])}}" class="create-batch">Create Batch</a>
                                                    </td>
                                                </tr>
                                                @empty
                                                <tr>
                                                    <td colspan="8">No records found..</td>
                                                </tr>
                                                @endforelse
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>




@endsection

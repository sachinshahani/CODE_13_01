@extends('admin.layouts.app')

@section('content')
<style>
    .wrapper{
    max-width: 1240px; margin:0 auto;
}
.white-bg{
    background-color: white;
    /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
    border-bottom:5px solid #ff9800;
    margin-bottom:15px;
}
.auth-one-bg .slide .carousel-indicators {
    bottom: 25px;
}
.auth-page-wrapper .auth-page-content{
    padding-bottom: 0px !important;
}
.auth-page-content  .card {
     margin-bottom: 0rem;
}
.data-tabs .wrapper .nav-tabs button {
    font-size: 17px;
    color: black;
}
.data-tabs .wrapper .nav-tabs .active{
    background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f); */
    color: white;
    background: orange;
    border-radius: 0px;
}
.carousel-caption.d-none.d-md-block {
    background-color: #000000bf;
    left: 0;
    width: 100%;
    bottom: 0;
}
.carousel-indicators {
    display: none;
}
.custom-banner-caption {
    color: white !important;
} 
.announcement-heading{
    font-size: 1.2em;
    font-weight: 600;
}
.data-tabs .tab-pane ul li{
font-size: 1em;
padding: 5px 0;

}
.main-logo{
    padding: 10px;
}
.data-tabs .nav-item .nav-link {
    background-image:none ;
}
/* .right-sec{
    box-shadow: 5px 10px 18px #888888;
} */
.navbar-brand-box {
    background: #fff;
}
.btn-danger {
    background-color: #40895a;
    border: 1px solid #40895a;
}
[data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
    color: white !important;
}
.header-buttons .btn-primary {
    margin-right: 10px;
    padding: 6px 15px;
    font-weight: 600;
    background-color: #207005;
    border: none;
    box-shadow: 0px 2px 7px #888888;
}
.header-buttons .btn-secondary {
    margin-right: 10px;
    padding: 6px 15px;
    font-weight: 600;
    background-color: #72a055;
    border: none;
    box-shadow: 0px 2px 7px #888888;
}


.right-sec { border-left: 5px solid #ede7e7; }
.tabdiv { background: white;  padding: 20px;  margin-top: 10px;  border: 10px solid #dfdbd5; }

.nav-tabs {border-bottom:0px; }
div#myTabContent { border: 1px solid #cccccc;}
.frontfooter footer { padding: 20px calc(1.5rem / 2); position: static; color: #000; height: 60px; background-color: #f9f9f9;
    margin-top: 30px; border-top: 1px solid #e1dfdf; }
span.logo-sm img { width: 69px;}

.seperatesec{margin-top:20px;}
.simplebar-content li.nav-item:hover {  background: #4caf50;}
.sectitle{font-size: 14px;}
.required { color: red; }
.customtextarea{height: 120px;}

ul.boxsection { margin: 0; padding: 0;}
ul.boxsection li { list-style-type: none; padding: 7px 0; border-bottom: 1px solid #efeded;}
.boxcard .col:nth-child(1) { background: #effcfb;}
.boxcard .col:nth-child(2) { background: #fdfdfd;}
.boxcard .col:nth-child(3) { background: #effcfb;}
.boxcard .col:nth-child(4) { background: #fdfdfd;}
.boxcard .col:nth-child(5) { background: #effcfb;}

/* --registration-form css  */
.custom-tab-content {
    padding-top: 0 !important;
    padding-bottom: 0px !important;
}
.custom-tab-nav {
    background: white;
    
}
.custom-tab-nav .nav-link {
    border-radius: 0 !important;
    border-bottom: 1px solid #e9ebec;
    border-right: 1px solid #e9ebec;
    font-size: 14px;
    padding: 10px;
}
.custom-tab-nav .nav-link.active, .custom-tab-nav .show>.nav-link{
    color: rgb(255, 255, 255) !important;
    background-color: #2c8c6d;
    border-bottom: #2c8c6d !important;
    /* border-bottom: #207005 !important; */
    position:relative;
}
.custom-tab-nav .nav-link:hover, .custom-tab-nav .nav-link:focus {
    border-bottom: 1px solid #207005;
    border-radius: 0;
    font-size: 14px;
    transition: background-color 0.20s linear;
}
.custom-tab-nav .nav-link.active:after {
    content: "";
    position: absolute;
    bottom: -16px;
    left: 50%;
    border: 8px solid transparent;
    border-top-color: #2c8c6d;
    z-index: 999;
}
.reg-form-btns {
    margin-bottom: 15px;
}
.reg-form-btns .btn-secondary {
    color: #fff;
    background-color: #405189;
    border-color: #405189;
}
.btn-soft-success:active, .btn-soft-success:focus, .btn-soft-success:hover{
    border: none;
}
.custom-tab-nav ul{padding:0px; margin:0px;}
.custom-tab-nav ul li{padding:0px; margin:0px; display: inline-block; list-style: none;}
</style> 
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0">ICS Profile</h4>

                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                            <li class="breadcrumb-item active">ICS Profile</li>
                        </ol>
                    </div>

                </div>
            </div>
        </div>
        <!-- end page title -->

        <div class="row">
            <div class="col-lg-12">
                <form method="post" id="registration"  action="{{route('superadmin.icsuser.step4post',$userdetails->id)}}">
                @csrf 
                <input type="hidden" name="roleid" value="{{$userdetails->roles[0]->id}}">

                    <nav>
                        <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                            <a class="nav-link" id="step1-tab" data-bs-toggle="tab"
                                href="#step1">General Information</a>
                            <a class="nav-link" id="step2-tab" data-bs-toggle="tab"
                                href="#step2">Self/Mandator Details</a>
                            <a class="nav-link" id="step3-tab" data-bs-toggle="tab"
                                href="#step3">Inspector Details</a>
                            <a class="nav-link active" id="step4-tab" data-bs-toggle="tab"
                                href="#step4">Warehouse Details</a>   
                        </div>
                    </nav>
                    <div class="tab-content py-4 custom-tab-content">
                        <div class="tab-pane fade show active" id="step4">
                            <div class="card">
                                <div class="card-header align-items-center d-flex">
                                        <h4 class="card-title mb-0 flex-grow-1"> Warehouse Details
                                        </h4>
                                        <div class="flex-shrink-0">
                                            @if (session('error'))
                                            <div class="alert alert-danger">
                                                {{ session('error') }}
                                            </div>
                                            @endif
                                            @if (session('success'))
                                                <div class="alert alert-success">
                                                    {{ session('success') }}
                                                </div>
                                            @endif
                                            @if($errors)
                                                @foreach ($errors->all() as $error)
                                                    <div class="alert alert-danger">{{ $error }}</div>
                                                @endforeach
                                            @endif 
                                        </div> 
                                </div>    
                                <div class="card-body">
                                    <div class="live-preview">
                                        
                                
                                        <div class="row seperatesec">
                                            <div class="col-xxl-6 col-md-4 gy-3 ">
                                            <label for="basiInput" class="form-label">Number of Warehouse1 <span
                                                    class="required">*</span></label>
                                                    <input type="number" class="form-control" id="placeholderInput"
                                                    placeholder="Number Warehouse" required name="no_warehouse" value="{{ (isset($warehs)) ? $warehs[0]->no_warehouse : ''}}"/>
                                            </div>
                                        
                                        <div class="col-xxl-6 col-md-4  gy-3">
                                            <div>
                                                <label for="labelInput" class="form-label">Warehouse Licence Number <span
                                                        class="required">*</span></label>
                                                <input type="text" class="form-control" id="placeholderInput"
                                                    placeholder="Licence Number" required name="warehouse_lic_no" value="{{ (isset($warehs)) ? $warehs[0]->license_number : ''}}"/>
                                            </div>
                                        </div>
                                        <div class="col-xxl-6 col-md-4  gy-3">
                                            <div>
                                                <label for="labelInput" class="form-label">Area Of Warehouse <span
                                                        class="required">*</span></label>
                                                <input type="text" class="form-control" id="placeholderInput"
                                                    placeholder="Area" required name="area_warehouse" value="{{ (isset($warehs)) ? $warehs[0]->area_of_warehouse : ''}}"/>
                                            </div>
                                        </div>
                                    
                                    </div>
                                    
                                    <div class="row seperatesec">
                                        <div class="col-xxl-6 col-md-6  gy-3">
                                            <div>
                                                <label for="labelInput" class="form-label">Capacity <span
                                                        class="required">*</span></label>
                                                <input type="text" class="form-control" id="placeholderInput"
                                                    placeholder="Capacity" required name="capacity" value="{{ (isset($warehs)) ? $warehs[0]->capacity : ''}}"/>
                                            </div>
                                        </div>
                                        
                                        <div class="col-xxl-6 col-md-6  gy-3">
                                        
                                            <label for="labelInput" class="form-label">Office Address <span
                                                class="required">*</span></label>
                                    <input type="address" placeholder="Address"
                                    class="form-control customtextarea" required name="address" value="{{ (isset($warehs)) ? $warehs[0]->address : ''}}">
                                        
                                    </div>
                                    </div>
                                        


                                    <div class="row seperatesec">
                                        <div class="col-xxl-6 col-md-6  gy-3">
                                            <div class="card">
                                                <div class="card-header">
                                                    <h4 class="card-title mb-0">Photo of Office building:</h4>
                                                </div>
                                                <div class="dropzone">
                                                    <div class="fallback">
                                                        <input name="file" type="file" multiple="multiple">
                                                    </div>
                                                    <div class="dz-message needsclick">
                                                        <div class="mb-3">
                                                            <i
                                                                class="display-4 text-muted ri-upload-cloud-2-fill"></i>
                                                        </div>

                                                        <h4>Drop files here or click to upload.</h4>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                        

                                    </div>
                                   
                                    <div class="row seperatesec">
                                            <div class="col-xxl-6 col-md-4 gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">State <span
                                                            class="required">*</span></label>
                                                        <select class="form-select" name="state" required>
                                                        <option value="">Select State</option>
                                                        @forelse($states as $state)
                                                            <option value="{{$state->id}}" @if(isset($warehs) && $warehs[0]->state==$state->id) selected @endif>{{$state->state_name}}</option>
                                                            @empty
                                                        @endforelse
                                                        </select>
                                                </div>
                                            </div>
                                            <div class="col-xxl-6 col-md-4 gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">District <span
                                                            class="required">*</span></label>
                                                            <select class="form-select" name="district" required>
                                                                <option value="">Select District</option> 
                                                                @forelse($districts as $district)
                                                                    <option value="{{$district->id}}" @if(isset($warehs) && $warehs[0]->district==$district->id) selected @endif>{{$district->district_name}}</option>
                                                                @empty
                                                                @endforelse                              
                                                            </select>
                                                </div>
                                            </div>
                                            <div class="col-xxl-6 col-md-4 gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">Taluka/Mandal
                                                        <span class="required">*</span></label>
                                                        <select class="form-select" name="taluka" required>
                                                            <option value="">Select Taluka/Mandal</option>
                                                            @forelse($regions as $region)
                                                            <option value="{{$region->id}}" @if(isset($warehs) && $warehs[0]->taluka==$region->id) selected @endif>{{$region->region_name}}</option>
                                                            @empty
                                                        @endforelse                                                                
                                                        </select>
                                                </div>
                                            </div>
                                          
                                        </div>
                                        <div class="row seperatesec">
                                            <div class="col-xxl-6 col-md-4 gy-3">
                                                <div>
                                                    <label class="form-label">Village </label>
                                                    <select class="form-select" name="village" required>
                                                        <option value="">Select Village</option> 
                                                        @forelse($villages as $village)
                                                            <option value="{{$village->id}}" @if(isset($warehs) && $warehs[0]->village==$village->id) selected @endif>{{$village->village_name}}</option>
                                                        @empty
                                                        @endforelse                              
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-xxl-6 col-md-4 gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">Pin Code<span
                                                            class="required">*</span></label>
                                                    <input type="number" class="form-control" id="placeholderInput"
                                                        placeholder="Pin Code" name="pincode" required value="{{ (isset($warehs)) ? $warehs[0]->pin_code : ''}}"/>
                                                </div>
                                            </div>
                                             
                                            <div class="col-xxl-6 col-md-4 gy-3 ">
                                                <div>
                                                    <label for="basiInput" class="form-label">Address Proof Of Office
                                                    </label>
                                                    <div class="input-group">
                                                        <select class="form-select" name="address_proof_of_office">
                                                            <option value="electricity_bill"  @if(isset($warehs) && $warehs[0]->address_proof_of_office=="electricity_bill") selected @endif>Electricity Bill</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                        </div>
                                        <br>
                                        <h2 class="card-title mb-0 flex-grow-1">
                                            Details Of Warehouse Manager
                                        </h2>
                                        @forelse($wmanager as $wm)
                                        <div class="row seperatesec">
                                            <div class="col-xxl-4 col-md-4  gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">Name </label>
                                                    <input type="text" class="form-control" id="placeholderInput"
                                                        placeholder="name" name="wm_name[]" value="{{ $wm->name}}" />
                                                </div>
                                            </div>
                                            <div class="col-xxl-4 col-md-4  gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">Aadhar Card </label>
                                                    <input type="number" class="form-control" id="placeholderInput"
                                                        placeholder="Aadhar" name="wm_aadhar[]" value="{{ $wm->aadhar}}"/>
                                                </div>
                                            </div>
                                            <div class="col-xxl-4 col-md-4  gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">Contact Number </label>
                                                    <input type="number" class="form-control" id="placeholderInput"
                                                        placeholder="Mobile Number" name="wm_mobile_no[]" value="{{ $wm->mobile_no}}"/>
                                                </div>
                                            </div>
                                        </div>
                                        @empty
                                        <div class="row seperatesec">
                                            <div class="col-xxl-4 col-md-4  gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">Name </label>
                                                    <input type="text" class="form-control" id="placeholderInput"
                                                        placeholder="name" name="wm_name[]" />
                                                </div>
                                            </div>
                                            <div class="col-xxl-4 col-md-4  gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">Aadhar Card </label>
                                                    <input type="number" class="form-control" id="placeholderInput"
                                                        placeholder="Aadhar" name="wm_aadhar[]"/>
                                                </div>
                                            </div>
                                            <div class="col-xxl-4 col-md-4  gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">Contact Number </label>
                                                    <input type="number" class="form-control" id="placeholderInput"
                                                        placeholder="Mobile Number" name="wm_mobile_no[]"/>
                                                </div>
                                            </div>
                                        </div>
                                        @endforelse
                                        

                                        <br>
                                        <h2 class="card-title mb-0 flex-grow-1">
                                            Details Of Purchase Manager
                                        </h2>
                                        @forelse($pmanager as $pm)
                                        <div class="row seperatesec">
                                            <div class="col-xxl-4 col-md-4  gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">Name </label>
                                                    <input type="text" class="form-control" id="placeholderInput"
                                                        placeholder="name" name="pm_name[]" value="{{$pm->name}}"/>
                                                </div>
                                            </div>
                                            <div class="col-xxl-4 col-md-4  gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">Aadhar Card </label>
                                                    <input type="number" class="form-control" id="placeholderInput"
                                                        placeholder="Aadhar" name="pm_aadhar[]" value="{{$pm->aadhar}}"/>
                                                </div>
                                            </div>
                                            <div class="col-xxl-4 col-md-4  gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">Contact Number </label>
                                                    <input type="text" class="form-control" id="placeholderInput"
                                                        placeholder="Contact Number" name="pm_mobile_no[]" value="{{$pm->mobile_no}}"/>
                                                </div>
                                            </div>
                                        </div>
                                        @empty
                                        <div class="row seperatesec">
                                            <div class="col-xxl-4 col-md-4  gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">Name </label>
                                                    <input type="text" class="form-control" id="placeholderInput"
                                                        placeholder="name" name="pm_name[]"/>
                                                </div>
                                            </div>
                                            <div class="col-xxl-4 col-md-4  gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">Aadhar Card </label>
                                                    <input type="number" class="form-control" id="placeholderInput"
                                                        placeholder="Aadhar" name="pm_aadhar[]"/>
                                                </div>
                                            </div>
                                            <div class="col-xxl-4 col-md-4  gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">Contact Number </label>
                                                    <input type="text" class="form-control" id="placeholderInput"
                                                        placeholder="Contact Number" name="pm_mobile_no[]" />
                                                </div>
                                            </div>
                                        </div>
                                        @endforelse


                                        <br>
                                         

                                <div class="row seperatesec">
                                    <div class="col-xxl-4 col-md-6  gy-3">
                                        <div>
                                            <label for="labelInput" class="form-label">No. of Field Officers </label>
                                            <input type="number" class="form-control" id="placeholderInput"
                                                placeholder="No. of Field Officers" name="no_field_officers" value="{{ (isset($warehs)) ? $warehs[0]->no_field_officer : ''}}"/>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                        
                                <div class="row seperatesec">
                                <h2 class="card-title mb-0 flex-grow-1">
                                Details. of Field Officers
                                </h2>
                                @forelse($foanager as $fo)
                                <div class="row seperatesec">
                                    <div class="col-xxl-4 col-md-4  gy-3">
                                        <div>
                                        <label for="labelInput" class="form-label">Name </label>
                                        <input type="text" class="form-control" id="placeholderInput"
                                        placeholder="name" name="fo_name[]" value="{{$fo->name}}"/>
                                        </div>
                                    </div>
                                    <div class="col-xxl-4 col-md-4  gy-3">
                                        <div>
                                        <label for="labelInput" class="form-label">Aadhar Card </label>
                                        <input type="number" class="form-control" id="placeholderInput"
                                        placeholder="Aadhar"  name="fo_aadhar[]" value="{{$fo->aadhar}}"/>
                                        </div>
                                    </div>
                                    <div class="col-xxl-4 col-md-4  gy-3">
                                        <div>
                                        <label for="labelInput" class="form-label">Contact Details </label>
                                        <input type="text" class="form-control" id="placeholderInput"
                                        placeholder="Contact Number"  name="fo_mobile_no[]" value="{{$fo->mobile_no}}"/>
                                        </div>
                                    </div>
                                </div>    
                                @empty
                                <div class="row seperatesec">
                                    <div class="col-xxl-4 col-md-4  gy-3">
                                        <div>
                                        <label for="labelInput" class="form-label">Name </label>
                                        <input type="text" class="form-control" id="placeholderInput"
                                        placeholder="name" name="fo_name[]"/>
                                        </div>
                                    </div>
                                    <div class="col-xxl-4 col-md-4  gy-3">
                                        <div>
                                        <label for="labelInput" class="form-label">Aadhar Card </label>
                                        <input type="number" class="form-control" id="placeholderInput"
                                        placeholder="Aadhar"  name="fo_aadhar[]"/>
                                        </div>
                                    </div>
                                    <div class="col-xxl-4 col-md-4  gy-3">
                                        <div>
                                        <label for="labelInput" class="form-label">Contact Details </label>
                                        <input type="text" class="form-control" id="placeholderInput"
                                        placeholder="Contact Number"  name="fo_mobile_no[]"/>
                                        </div>
                                    </div>
                                </div>
                                @endforelse
                                </div>


                                        <br>
                                        <h2 class="card-title mb-0 flex-grow-1">
                                            Details Of Approval Manager\Committee
                                        </h2>
                                        @forelse($amanager as $am)
                                        <div class="row seperatesec">
                                            <div class="col-xxl-4 col-md-4 gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">Name </label>
                                                    <input type="text" class="form-control" id="placeholderInput"
                                                        placeholder="name"  name="am_name[]" value="{{$am->name}}"/>
                                                </div>
                                            </div>
                                            <div class="col-xxl-4 col-md-4 gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">Aadhar Card </label>
                                                    <input type="number" class="form-control" id="placeholderInput"
                                                        placeholder="Aadhar" name="am_aadhar[]" value="{{$am->aadhar}}"/>
                                                </div>
                                            </div>
                                            <div class="col-xxl-4 col-md-4 gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">Contact Details </label>
                                                    <input type="text" class="form-control" id="placeholderInput"
                                                        placeholder="Contact number" name="am_mobile_no[]" value="{{$am->mobile_no}}"/>
                                                </div>
                                            </div>
                                        </div>
                                        @empty
                                        <div class="row seperatesec">
                                            <div class="col-xxl-4 col-md-4 gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">Name </label>
                                                    <input type="text" class="form-control" id="placeholderInput"
                                                        placeholder="name"  name="am_name[]"/>
                                                </div>
                                            </div>
                                            <div class="col-xxl-4 col-md-4 gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">Aadhar Card </label>
                                                    <input type="number" class="form-control" id="placeholderInput"
                                                        placeholder="Aadhar" name="am_aadhar[]"/>
                                                </div>
                                            </div>
                                            <div class="col-xxl-4 col-md-4 gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">Contact Details </label>
                                                    <input type="text" class="form-control" id="placeholderInput"
                                                        placeholder="Contact number" name="am_mobile_no[]"/>
                                                </div>
                                            </div>
                                        </div>
                                        @endforelse


                                        <!--address sec end-->

                                        <div class="row">
                                            <div class="col-lg-12 gy-4">
                                                <div class="hstack gap-2">
                                                <a href="{{route('superadmin.icsuser.step3',$userdetails->id)}}" class="btn btn-soft-success">
                                                        Back
                                                    </a>    
                                                <button type="submit" class="btn btn-primary">Submit</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>    
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
@endsection
@push('script')


@endpush


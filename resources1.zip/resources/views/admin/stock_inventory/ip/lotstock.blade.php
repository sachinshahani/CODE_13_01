@extends('admin.layouts.app')
@section('content')
    <style>
        .customtextarea {
            height: 80px;
        }
    </style>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Batch Stock
                </h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Batch Stock</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body table-responsive">
                        <table id="searchResultsTable" class="table table-bordered table-striped align-middle"
                            style="width:100%">
                            <thead>
                                <tr>
                                    <th>SNo.</th>
                                    <th>Lot Id</th>
                                    <th>Product Code</th>
                                    <th>Lot Quantity</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('script')
        <script>
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var table = $('#searchResultsTable').DataTable({
                dom: 'Bfrtip',
                lengthMenu: [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
                processing: true,
                serverSide: true,
                ajax: {
                    url: '{{ route('superadmin.IPLotStockSearch') }}',
                    type: 'GET',
                    data: function(d) {
                        d.state = $('#state').val();
                        d.from_date = $('#from_date').val();
                        d.to_date = $('#to_date').val();
                        d.operator = $('#operator').val();
                    },
                    error: function(xhr, error, code) {
                        console.log(xhr.responseText); // This will print the error response
                    }
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: true
                    },

                    {
                        data: 'lot_id',
                        name: 'lot_id',
                        orderable: true
                    },
                    {
                        data: 'product_code',
                        name: 'product_code',
                        orderable: true
                    },

                    {
                        data: 'quantity',
                        name: 'quantity',
                        orderable: true
                    },

                ],
                paging: false,
                buttons: [
                    'excelHtml5',
                    {
                        extend: 'csvHtml5',
                        title: function() {
                            return "REPORTS";
                        },
                        titleAttr: 'CSV REPORTS'
                    },
                    {
                        extend: 'pdfHtml5',
                        title: function() {
                            return "PDF REPORTS";
                        },
                        orientation: 'landscape',
                        pageSize: 'A4',
                        titleAttr: 'PDF REPORTS'
                    }
                ],
                language: {
                    emptyTable: "No Record found."
                }
            });

            $('#state, #from_date, #to_date, #operator').change(function() {
                table.draw();
            });
        </script>
    @endpush

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>APEDA</title>

<style>
    .customdiv{max-width:800px;   margin: 0 auto; border:1px solid #cccccc; padding:20px;}
    label{font-weight: 600;}
    .customdiv table tr td{padding:10px;}
</style>
</head>

<body>
    <div class="customdiv">
    <table cellspacing="0" cellpadding="0" style="width:100%;max-width: 800px; margin: 0 auto; ">
        <tbody>
            <tr>
                <td style="text-align: center;margin: 0;">
                    <h1>
                        CERTIFICATE OF REGISTRATION - NPOP</h1>
                </td>
            </tr>
            <tr>
                <td style="text-align: center;margin: 0;padding-top: 20px;">
                    <p
                        style="font-family:'Arial'; margin-top: 0;padding: 3px 0;margin: 0;font-weight:400;font-size: 14px;">
                        With reference to your application, we have registered you as {{$opr_type}} and your</p>
                    <p
                        style="font-family:'Arial'; margin-top: 0;padding: 3px 0;margin: 0;font-weight:400;font-size: 14px;">
                        Registration No. is<input type="text" placeholder="ORG-2305-001208" size="7" style="margin-left:15px;text-transform: capitalize;border: none;border-bottom: 1px solid #000;font-size: 14px;" value="{{$reg_no}}"></p>
                </td>
            </tr>
        </tbody>
    </table>

    <table cellspacing="0" cellpadding="0" >
        <tbody>
            <tr>
                <td colspan="2" >
                    Please
                    note your registration number and use the same in all the future correspondence. Your basic
                    information is given below :</td>
            </tr>
            <tr>
                <td colspan="2">
                    <table cellspacing="0" cellpadding="0"
                        style="border-collapse: collapse;width: 100%;  margin: 0px 15px 0 80px">
                        <tbody>
                            <tr>
                                <td>
                                   <label for="">Name :</label> </td>
                                <td>
                                    <label for="">{{ucwords($name)}}</label>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label for=""> Address :</label></td>
                                <td>
                                    <label for="">{{ucwords($address)}}</label>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                  <label for=""> Operation Type :</label></td>
                                <td>
                                    <label for="">{{$opr_type}}</label>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                  <label for=""> Status :</label> </td>
                                <td   >
                                    <label for="">{{($status==1?"Registered":"")}}</label>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                 <label for=""> Date of Registration :</label>  </td>
                                <td>
                                    <label for="">{{date('d/m/Y',strtotime($date_of_reg))}}</label>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label for=""> Contact No. :</label></td>
                                <td>
                                    <label for="">{{$contact}}</label>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                   <label for=""> E-mail ID :</label></td>
                                <td>
                                    <label for="">{{$email}}</label>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                   <label for=""> PAN :</label></td>
                                <td>
                                    <label for="">{{$pan}}</label>
                                </td>
                            </tr>
                        </tbody>
                    </table>
               </td>
            </tr>
            <tr>
                <td colspan="2"
                    style="font-family:'Arial'; text-align: left;font-size: 14px;font-weight: 400;padding: 15px 0px;">
                    <p style="font-family:'Arial';padding:2px 0;margin: 0;font-weight:400;">From the date of
                        Registration, this project is under supervision of {{$cb_name}}, till formally</p>
                    <p style="font-family:'Arial';padding:2px 0;margin: 0;font-weight:400;">withdrawn by you. In case
                        of any query, please do not hesitate to contact undersigned.</p>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <table cellspacing="0" cellpadding="0"
                        style="border-collapse: collapse;width: 100%;max-width: 800px;margin: 10px auto;">
                        <tbody>
                            <tr>
                                <td
                                    style="font-family:'Arial'; text-align: left;font-size: 14px;font-weight: 400;padding: 2px 2px;">
                                    <img src="data:image/png;base64, {!! $qr_code !!}" alt="" style="height: 50px">
                                </td>
                                <td
                                    style="font-family:'Arial'; text-align: right;font-size: 14px;font-weight: 400;padding: 2px 0px;">

                                    <p style="font-family:'Arial';padding: 3px 2px;margin: 0;font-weight:400;"> </p>
                                    <p style="font-family:'Arial';padding: 3px 0;margin: 0;font-weight:400;">Authorised
                                        Signatory</p>
                                    <p style="font-family:'Arial';padding: 3px 0;margin: 0;font-weight:400;">{{$cb_name}}</p>
                                    <p style="font-family:'Arial';padding: 3px 0;margin: 0;font-weight:400;">{{$cb_address}}</p>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr>
                <td colspan="2"
                    style="font-family:'Arial'; text-align: left;font-size: 16px;font-weight: 400;padding: 15px 0px 2px;">
                    <p style="font-family:'Arial';padding: 3px 0;margin: 0;"> Issued On : <input type="text" placeholder="31/05/2023" size="7" style="border: none;border-bottom: 1px solid #000;font-size: 14px;text-align: center;" value="{{$issued_on}}"></p>
                    <p style="font-family:'Arial';padding: 3px 0;margin: 0;">Note: This is only a Certificate of
                        Registration; the subsequent process leading to issue the Scope Certificate will depend upon
                        the physical evaluation in compliance with the NPOP standards.</p>
                </td>
            </tr>
        </tbody>
    </table>
</div>


</body>

</html>

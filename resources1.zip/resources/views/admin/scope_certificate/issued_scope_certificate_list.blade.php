@extends('admin.layouts.app')

@section('content')
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">

                <h4 class="mb-sm-0">

                    List of scope certificate issued

                </h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                          <li class="breadcrumb-item"><a href="{{route('superadmin.dashboard')}}">Dashboard</a></li>
                        <li class="breadcrumb-item active">

                           Scope Certification

                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>

    <div class="col-md-12 mt-2">
        @if (session('success'))
            <div class="alert alert-success" id="validate">
                {{ session('success') }}
            </div>
        @endif

        @if (session('importErrors'))
            <div class="alert alert-danger">
                <p>Following Errors Occured While Uploading the list, Please fix and upload again</p>
                <ul>
                    @foreach (session('importErrors') as $failure)
                        @foreach ($failure->errors() as $f)
                            <li>{{ $f . ' at row ' . $failure->row() }}</li>
                        @endforeach
                    @endforeach
                </ul>
            </div>
        @endif
    </div>

    <div class="row">
        <div class="col-lg-12">
            {{-- <div class="card">
                <div class="card-header">
                    <button type="button" class="btn btn-primary" id="generateDigitalSign" data-fileName="835_1732608410.pdf"
                        data-path="public/scope_certificate" data-fileStored="public" data-certificate="SCC">
                        Digital Sign
                    </button>
                </div>
            </div> --}}
            <div class="card">

                <div class="card-body">
                    <div class="table-responsive">
                        <table id="deptUser" class="table table-bordered table-striped align-middle" style="width:100%">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Scope Certificate No.</th>
                                    <th>Operator Name</th>
                                    <!-- <th>Certification Type</th> -->
                                    <th>Operator Type </th>
                                    <th>Apply Date </th>
                                    <th>Validity</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                    {{-- <th>Digital Signature</th> --}}
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!--end col-->
    </div>
    <!--end row-->

@endsection



@push('script')
    <script src="{{ asset('public/assets/js/digitalSign.js') }}"></script>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        var table = $('#deptUser').DataTable({
            //dom: 'l<"clear">Bfrtip',
            //dom:'Bfrtip',
            //dom:'Blfrtip',
            lengthMenu: [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
            ],
            processing: true,
            serverSide: true,
            ajax: {
                url: '#',
                type: 'GET',
                data: function(d) {
                    d._token = "{{ csrf_token() }}";
                    d.status = $("#search").val();
                }

            },
            columns: [{
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex',
                    orderable: true
                },
                {
                    data: 'registration_no',
                    name: 'registration_no',
                    orderable: false
                },
                {
                    data: 'name',
                    name: 'name',
                    orderable: false
                },
                // {
                //     data: 'programme',
                //     name: 'programme',
                //     orderable: false
                // },

                {
                    data: 'opr_type',
                    name: 'opr_type',
                    orderable: false
                },
                {
                    data: 'created_at',
                    name: 'created_at',
                    orderable: false
                },
                {
                    data: 'validity',
                    name: 'validity',
                    orderable: false
                },
                {
                    data: 'status',
                    name: 'status',    
                    orderable: false
                },
                {
                    data: 'action',
                    name: 'action',
                    orderable: false
                },
               
            ],
            // initComplete: function () {
            //     var btns = $('.dt-button');
            //     //btns.addClass('btn btn-success btn-success');
            //     btns.removeClass('dt-button');

            // },

        });

        $("#search").on('change', function(e) {
            table.draw();
            e.preventDefault();
        });
    </script>
    {{-- <script>
        $(document).ready(function() {
            $(document).on("click", "#generateDigitalSign", function(event) {
                event.preventDefault();
    
                const $this = $(this);
                const fileName = $this.data("filename");
                const path = $this.data("path");
                const storageType = $this.data("filestored");
                const docName = $this.data("certificate");
    
                $this.prop("disabled", true);
                $this.html('<span class="loader"></span> Processing...'); // Assuming you have a loader CSS
    
                // Call the function
                initiateDigitalSign(fileName, path, storageType, docName).finally(() => {
                    $this.prop("disabled", false);
                    $this.html("Generate Digital Sign"); // Reset to original button text
                });
            });
    
            function initiateDigitalSign(fileName, path, storageType, docName) {
                return $.ajax({
                    url: '{{ route('generate.digital.sign') }}',
                    type: 'POST',
                    data: {
                        file_name: fileName,
                        path: path,
                        storage_type: storageType,
                        docName: docName,
                        _token: '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        if (response.status === "success") {
                            Swal.fire({
                                title: "eSign User Authentication",
                                text: "You are redirected here to authenticate for eSign.",
                                icon: 'success',
                                confirmButtonText: '<a href="https://authenticate.sandbox.emudhra.com/index.jsp?txnref=' 
                                                    + response.gatewayParameter + '&maxAuthAttempt=2" target="_blank" style="text-decoration: none; color: white;">Proceed to Authenticate</a>',
                                showCancelButton: false,
                                allowOutsideClick: false
                            });
                        } else {
                            Swal.fire({
                                title: "Failed",
                                text: "Failed to eSign User Authentication.",
                                icon: 'error',
                                confirmButtonText: 'Close'
                            });
                        }
                    },
                    error: function() {
                        Swal.fire({
                            title: "Error",
                            text: "An error occurred while generating the digital sign request.",
                            icon: 'error',
                            confirmButtonText: 'Close'
                        });
                    }
                });
            }
        });
    </script> --}}
    
@endpush

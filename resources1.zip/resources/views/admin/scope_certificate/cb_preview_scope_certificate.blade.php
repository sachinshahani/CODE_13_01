@extends('admin.layouts.app')
@section('content')
     
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Apply For Scope Certificate</h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Apply For Scope Certificate</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">

            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1">
                                Forward Application to CB for Scope Certificate
                            </h4>
                           
                        </div>

                        <!-- end card header -->
                        <div class="card-body">
                             
                            <div class="pdf_maindiv">
                                <!--form1 section starts here-->
                                <div class="container-fluid">        
                                    <div class="row">
                                        <div class="col-xxl-12 col-md-12 ">
                                            <div class="text-center">
                                                
												<a target="_BLANK" href="{{ route('superadmin.CBpreviewScopeCertificate',$appliedscop->id)}}">View PDF in new window</a>
												<br><br>
												 <form method="post" action="{{ route('superadmin.scopeCertificateGenerateSave') }}">
													@csrf
													<input type="hidden" name="hid" value="{{ $appliedscop->id }}">
													<input type="hidden" class="form-control" name="certification_date" value="{{ date('Y-m-d')}}" readonly>
													<button class="btn btn-primary"  type="submit" >Submit Application</button>
													</form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                              
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    </div>
@endsection

@push('script')
    <script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
    <script>
        $(document).on('click', '#submitbtn', function() {

            if (checkValidation("registration")) {
                $('#registration').submit();
                return true;
            } else {
                return false;
            }
        });
    </script>
@endpush

@extends('admin.layouts.app')
@section('content')
    <style>
       body {
            margin: 0px;
            padding: 0px;
            font-family: "Segoe UI";
        }
        .card-body {
    background: #fff !important;
}
        .maindiv {
            width: 80%;
            margin: 0 auto;
        }

        .pdf_maindiv {
            border: 1px solid #cccccc;
            width: 100%;
            float: left;
            padding:2% 1%;
        }

        .pdf_heading {
            font-size: 20px;
            color: #000;
            padding: 26px 0 20px 0px;
            position: relative;
            width: 100%;
            float: left;
        }

        .brd_heading {
            border-bottom: 2px solid #ee5e24;
            padding-bottom: 8px;
            padding-right: 8px;
            width: 60px;
        }

        .pdf_input1 {
            background: #eeeeee;
        }

        .pdf_txt1 {
            color: #000;
            font-size: 14px;
            width: 45%;
            float: left;
            padding-bottom: 10px;
            font-weight: bold;
        }

        .pdf_box {
            color: #000;
            font-size: 14px;
            width: 55%;
            float: left;
            padding-bottom: 10px;
        }

        .table_pdf {
            width: 100%;
        }
        .pdf_heading:after{content: ""; position: absolute; width:70px; height:2px; background-color:#ee5e24; bottom:10px; display: block; }
.pdf_heading:before{content: ""; position: absolute; width:22px; height: 6px; background-color:#ee5e24; bottom:8px; display: block; }
#step1 .card-body{background:#fff}
.pdf_inner_heading:after{display:none;}
.pdf_inner_heading:before {display:none;}
.pdf_inner_heading {padding:20px 0 12px;text-decoration:underline;font-size: 16px;}
.pdf_maindiv hr:last-child {display: none;}
.pdf-img-icon {
    height: 17px;
    width: 15px;
    margin-right: 5px;
}
@media print {

           .pdf_heading {
            font-size: 20px;
            color: #000;
            padding: 26px 0 20px 0px;
            position: relative;
            width: 100%;
            float: left;
            -webkit-print-color-adjust: exact !important;
            Chrome,
            Safari color-adjust: exact !important;
           }

    .pdf_heading:before{content: ""; position: absolute; width:20px; height: 4px; background-color:#ee5e24; bottom:10px; display: block;-webkit-print-color-adjust: exact !important;    Chrome, Safari
            color-adjust: exact !important;  }


}
    </style>
    </style>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Generate Scope Certificate</h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Generate Scope Certificate</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">

            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1">
                                Generate Scope Certificate
                            </h4>

                        </div>

                        <!-- end card header -->
                        <div class="card-body">

                            @if($user->status== 0 ?? '')
                            <div class="pdf_heading">Operator Details</div>
                            <div class="pdf_maindiv">
                                <!--form1 section starts here-->
                                <div class="container-fluid">

                                    <form method="post" action="{{ route('superadmin.saveViewCertificatePreview') }}" id="myForm">
                                    @csrf
                                    <div class="row">
                                        <div class="col-md-12">
                                            <table class="table table-borderless" style="padding: 10px; border: 0px;" class="table_pdf">
                                                <tr>
                                                    <th>Registration Number:</th>
                                                    <td> {{ $user->getuser->registration_no ?? 'Not Alloted' }}</td>

                                                    <th>Operator Name:</th>
                                                    <td> {{ user_name($user->getuser->id) ?? '' }}</td>
                                                </tr>
												 <tr>
                                                    <th>Address:</th>
                                                    <td> {{ ucfirst($user->getuser->address).' '. get_district_name($user->getuser->ref_district_id).' '. get_state_name($user->getuser->ref_state_id).' '.$user->getuser->pin }}</td>

                                                    <th>Certification Program:</th>
                                                    <td>NPOP</td>
                                                </tr>
												<tr>
                                                    <th>Certificate Date:</th>
                                                    <td>
													{{ date('d-m-Y')}}
                                                        <input type="hidden" class="form-control" name="certification_date" value="{{ date('Y-m-d')}}" readonly>
                                                        <input type="hidden" name="hid" value="{{ $user->id }}">
                                                    </td>

                                                    <th>Scope Certification for:</th>
                                                    <td>
                                                        {{ $user->scope_for ?? '' }}
                                                    </td>
                                                </tr>
												<tr>

                                                    <th>Authorized Signatory:</th>
                                                    <td>
                                                        <select name="auth_sign" id="auth_sign" class="form-select" required>
                                                            <option value="">Choose Authorized Signatory...</option>
                                                            @forelse($authsign as $vals)
                                                            <option value="{{$vals->id}}">{{$vals->first_name}}</option>
                                                            @empty

                                                            @endforelse

                                                        </select>
                                                    </td>
													 <th>&nbsp;</th>
                                                    <td>&nbsp;</td>

                                                </tr>
                                            </table>
                                        </div>

                                    </div>
                                    <div class="row">
                                        <div class="col-xxl-12 col-md-12 gy-4 ">
                                            <div class="hstack gap-2" style="float: right">
                                                <button type="submit" id="submitbtn" class="btn btn-primary submit-button">Preview of Application</button>
                                            </div>
                                        </div>
                                    </div>
                                    </form>
                                </div>
                            </div>
                            @else
                            <div class="pdf_maindiv">
                                <!--form1 section starts here-->
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-xxl-12 col-md-12 ">
                                            <div class="hstack">
                                                <div class="btn btn-soft-success" style="width: 100%">Your Scope Certificate Already Generated.</div>
                                            </div>
                                        </div>
                                    </div>
                                    </div>
                            </div>
                                    @endif




                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    </div>
@endsection
@push('script')
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.min.js"></script>

    <script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
    <script>
        $(document).on('click', '#submitbtn', function() {

            if (checkValidation("registration")) {
                $('#registration').submit();
                return true;
            } else {
                return false;
            }
        });


        $(document).ready(function() {
            $("#myForm").validate({
                rules: {
                    auth_sign: {
                        required: true
                    }
                },
                messages: {
                    auth_sign: {
                        required: "Please choose an authorized signatory."
                    }
                },
                submitHandler: function(form) {
                    var userConfirmed = window.confirm('Are you sure you want to submit the form?');
                    if (userConfirmed) {
                        form.submit();  
                    } else {
                        alert('Form submission cancelled.');
                    }
                }
            });
        });
    </script>
@endpush

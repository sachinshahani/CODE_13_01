@extends('admin.layouts.app')
@section('content')
    <style>
        body {
            margin: 0px;
            padding: 0px;
            font-family: "Segoe UI";
        }
        .card-body {
    background: #fff !important;
}
        .maindiv {
            width: 80%;
            margin: 0 auto;
        }

        .pdf_maindiv {
            border: 1px solid #cccccc;
            width: 100%;
            float: left;
            padding:2% 1%;
        }

        .pdf_heading {
            font-size: 20px;
            color: #000;
            padding: 26px 0 20px 0px;
            position: relative;
            width: 100%;
            float: left;
        }

        .brd_heading {
            border-bottom: 2px solid #ee5e24;
            padding-bottom: 8px;
            padding-right: 8px;
            width: 60px;
        }

        .pdf_input1 {
            background: #eeeeee;
        }

        .pdf_txt1 {
            color: #000;
            font-size: 14px;
            width: 45%;
            float: left;
            padding-bottom: 10px;
            font-weight: bold;
        }

        .pdf_box {
            color: #000;
            font-size: 14px;
            width: 55%;
            float: left;
            padding-bottom: 10px;
        }

        .table_pdf {
            width: 100%;
        }
        .pdf_heading:after{content: ""; position: absolute; width:70px; height:2px; background-color:#ee5e24; bottom:10px; display: block; }
.pdf_heading:before{content: ""; position: absolute; width:22px; height: 6px; background-color:#ee5e24; bottom:8px; display: block; }
#step1 .card-body{background:#fff}
.pdf_inner_heading:after{display:none;}
.pdf_inner_heading:before {display:none;}
.pdf_inner_heading {padding:20px 0 12px;text-decoration:underline;font-size: 16px;}
.pdf_maindiv hr:last-child {display: none;}
.pdf-img-icon {
    height: 17px;
    width: 15px;
    margin-right: 5px;
}
        @media print {

                   .pdf_heading {
                    font-size: 20px;
                    color: #000;
                    padding: 26px 0 20px 0px;
                    position: relative;
                    width: 100%;
                    float: left;
                    -webkit-print-color-adjust: exact !important;
                    Chrome,
                    Safari color-adjust: exact !important;
                   }

            .pdf_heading:before{content: ""; position: absolute; width:20px; height: 4px; background-color:#ee5e24; bottom:10px; display: block;-webkit-print-color-adjust: exact !important;    Chrome, Safari
                    color-adjust: exact !important;  }


        }
    </style>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Apply For Scope Certificate</h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Apply For Scope Certificate</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">

            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1">
                                Forward Application to CB for Scope Certificate
                            </h4>
                           
                        </div>

                        <!-- end card header -->
                        <div class="card-body">
						@if(auth()->guard('misadmin')->user()->status == 1)
							 <div class="pdf_maindiv">
                                <!--form1 section starts here-->
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-xxl-12 col-md-12 ">
                                            <div class="hstack">
                                                <div class="btn btn-danger" style="width: 100%">Your Profile is not completed! Please contact to Administrator!!.</div>
                                            </div>
                                        </div>
                                    </div>
                                    </div>
                            </div>
						@else
							
                            @if($elegible=='')
									<div class="pdf_heading">Application Details</div>
									<div class="pdf_maindiv">
										<!--form1 section starts here-->
										<div class="container-fluid">
											
											<form method="post" action="{{ route('superadmin.previewOfApplication') }}">
											@csrf
											<div class="row">
												<div class="col-6">
													<table style="padding: 10px; border: 0px;" class="table_pdf">
														<tr>
															<td class="pdf_txt1">Registration Number:</td>
															<td class="pdf_box"> {{ $user->registration_no ?? 'Not Alloted' }}</td>
														</tr>
														<tr>
															<td class="pdf_txt1">Operator Name:</td>
															<td class="pdf_box"> {{ $user->first_name ?? '' }}</td>
														</tr>
													</table>
												</div>
												<div class="col-6">
													<table style="padding: 10px; border: 0px;" class="table_pdf">
														<tr>
															<td class="pdf_txt1">Operator Type:</td>
															<td class="pdf_box">{{ getOperatorTypeById($user->ref_operator_type_id)}}</td>
														</tr>
														<tr>
															<td class="pdf_txt1">Date Of Registration:</td>
															<td class="pdf_box">{{ date('d-m-Y',strtotime($user->created_at)) }}</td>
														</tr>
														{{--   <tr>
															<td class="pdf_txt1">View Profile:</td>
															<td class="pdf_box">
															@if($user->ref_operator_type_id==2)
															<!-- ICS  -->
															<a href="{{route('superadmin.icsuser.preview',$user->id)}}" target="_blank">Click Here</a>
															@elseif($user->ref_operator_type_id==3)
															<!-- Individual Producer  -->
															<a href="{{route('superadmin.icsuser.preview',$user->id)}}" target="_blank">Click Here</a>
															@elseif($user->ref_operator_type_id==4)
															<!-- Wild Harvester  -->
															<a href="{{route('superadmin.icsuser.preview',$user->id)}}" target="_blank">Click Here</a>
															@elseif($user->ref_operator_type_id==5)
															<!-- Trader  -->
															<a href="{{route('superadmin.icsuser.preview',$user->id)}}" target="_blank">Click Here</a>
															@else
															<!-- Processor  -->
															<a href="{{route('superadmin.usermanagement.deptUser.proview',$user->id)}}" target="_blank">Click Here</a>
															@endif

															
															</td>
														</tr> --}}

														

													</table>
												</div>
											</div>
											<div class="row">
												<div class="col-xxl-11 col-md-11 gy-4 ">
													<div class="hstack gap-2" style="float: right">
														<button type="submit" id="submitbtn" class="btn btn-primary submit-button">Preview of application</button>
													</div>
												</div>
											</div>
											</form>
										</div>
									</div>
                                    @elseif($elegible==0)
									<div class="pdf_maindiv">
										<!--form1 section starts here-->
										<div class="container-fluid">        
											<div class="row">
												<div class="col-xxl-12 col-md-12 ">
													<div class="hstack">
														<div class="btn btn-soft-danger" style="width: 100%">Your application has been already forwarded to CB</div>
													</div>
												</div>
											</div>
										</div>
									</div>
                                    @else
									<div class="pdf_maindiv">
										<!--form1 section starts here-->
										<div class="container-fluid">
											<div class="row">
												<div class="col-xxl-12 col-md-12 ">
													<div class="hstack">
														<div class="btn btn-soft-success" style="width: 100%">Your Scope Certificate Already Generated.</div>
													</div>
												</div>
											</div>
											</div>
									</div>
                                    @endif
                                
                        @endif     
                             
                            
                             
                             
                       
                           
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    </div>
@endsection

@push('script')
    <script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
    <script>
        $(document).on('click', '#submitbtn', function() {

            if (checkValidation("registration")) {
                $('#registration').submit();
                return true;
            } else {
                return false;
            }
        });
    </script>
@endpush

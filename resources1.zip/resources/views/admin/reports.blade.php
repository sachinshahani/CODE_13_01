@extends('admin.layouts.app')
@section('content')
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">All Registered CB
            </h4>
            <input type="hidden" id="state_id" name="state_id" value="{{$id}}">
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">All Registered CB</li>
                </ol>
            </div>
        </div>
    </div>
</div>
<div class="row">

    <div class="col-lg-12">
        <div class="card">

            <div class="card-body table-responsive">
                <p>List of CB(s)</p>
                <table id="searchResultsTable" class="table table-bordered table-striped align-middle"
                    style="width:100%">
                    <thead>
                        <tr>
                            <th>S No.</th>
                            <th>CB Name</th>
                            <th>Address</th>
                            <th>State</th>
                            <th>District</th>
                            <th>Registration Date</th>

                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td colspan="6">No Record found.</td>

                        </tr>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection
@push('script')
        <script>
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var table = $('#searchResultsTable').DataTable({
                dom: 'Bfrtip',
                lengthMenu: [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
                processing: true,
                serverSide: true,
                ajax: {
                    url: '{{ route('superadmin.ReportsSearch') }}',
                    type: 'GET',
                    data: function(d) {
                         d.uid = $('#state_id').val();

                    },
                    error: function(xhr, error, code) {
                        console.log(xhr.responseText); // This will print the error response
                    }
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: true
                    },
                    {
                        data: 'cb_name',
                        name: 'cb_name',
                        orderable: true
                    },

                    {
                        data: 'address',
                        name: 'address',
                        orderable: true
                    },
                    {
                        data: 'state',
                        name: 'state',
                        orderable: true
                    },

                    {
                        data: 'district',
                        name: 'district',
                        orderable: true
                    },
                    {
                        data: 'reg_date',
                        name: 'reg_date',
                        orderable: true
                    },


                ],
                paging: false,
                buttons: [
                    'excelHtml5',
                    {
                        extend: 'csvHtml5',
                        title: function() {
                            return "REPORTS";
                        },
                        titleAttr: 'CSV REPORTS'
                    },
                    {
                        extend: 'pdfHtml5',
                        title: function() {
                            return "PDF REPORTS";
                        },
                        orientation: 'landscape',
                        pageSize: 'A4',
                        titleAttr: 'PDF REPORTS'
                    }
                ],
                language: {
                    emptyTable: "No Record found."
                }
            });

            $('#financial').change(function() {
                table.draw();
            });
        </script>
    @endpush

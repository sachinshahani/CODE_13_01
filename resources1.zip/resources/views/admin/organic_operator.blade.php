<?php //dd($userdetails); die; 
?>
<!doctype html>
<html lang="en" data-layout="vertical" data-topbar="light" data-sidebar="dark" data-sidebar-size="lg"
    data-sidebar-image="none">

<head>
    <meta charset="utf-8" />
    <title> APEDA </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="{{ asset('public/assets/images/favicon.png') }}">
    <!-- Layout config Js -->
    <script src="{{ asset('public/assets/js/layout.js') }}"></script>
    <!-- Bootstrap Css -->
    <link href="{{ asset('public/assets/css/bootstrap.min.css') }}" rel="stylesheet" />
    <!-- Icons Css -->
    <link href="{{ asset('public/assets/css/icons.min.css') }}" rel="stylesheet" />
    <!-- App Css-->
    <link href="{{ asset('public/assets/css/app.min.css') }}" rel="stylesheet" />
    <!-- custom Css-->
    <link href="{{ asset('public/assets/css/custom.min.css') }}" rel="stylesheet" />
    <link href="{{ asset('public/assets/css/font-awesome.min.css') }}" rel="stylesheet" />
    <link href="{{asset('public/assets/libs/select2/select2.min.css') }}" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans&display=swap" rel="stylesheet">
    <style>
        /* and end with */
        .customtextarea {
            height: 120px;
        }

        .right-sec .reload i.ri-refresh-line {
            font-size: 18px;
        }

        .right-sec .captchareload.btn-refresh {
            margin-top: 30px;
        }


        .main-logo {
            display: flex;
        }

        .logo-des {
            margin: auto;
            padding: 0 0 0 5px;
            text-transform: capitalize;
        }

        .logo-des h1 {
            display: flex;
            flex-direction: column;
            font-size: 20px;
            margin: 0;
            border-left: 1px solid #7272727a;
            padding-left: 15px;
            color: #02600c;
        }

        .header-buttons img {
            max-width: 52%;
            float: left;
        }

        .header-buttons {
            display: flex;
            justify-content: end;
        }

        .auth-one-bg .carousel-item img {
            max-height: 522px;
            min-height: 522px;
        }

        div#carouselExampleCaptions,
        .carousel-inner,
        .carousel-item {
            height: 100% !important;
        }

        .captchareload.btn-refresh {
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .captcha.nopd {
            width: 90%;
        }

        #error {
            color: red;
        }



        .overlay {
            background: rgb(0 0 0 / 50%);
            position: fixed;
            top: 0;
            z-index: 11111;
            left: 0;
            right: 0;
            bottom: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            display: none;
        }

        .loader {
            position: fixed !important;
            left: 50% !important;
            margin-left: -4em !important;
            top: 20em !important;
        }

        .wrapper {
            max-width: 1240px;
            margin: 0 auto;
        }

        /* Whole-page overlay with dark background */
        #overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            /* Dark overlay with 60% opacity */
            z-index: 9999;
            /* Ensure it's on top of everything */
            display: none;
            /* Initially hidden */
        }

        /* Centered loader (spinner) */
        #loader {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 10000;
            /* Ensure it is above the overlay */
            display: none;
            /* Initially hidden */
        }

        .center-loader {
            color: white;
            /* Color for the loader */
        }

        .select2-container--default .select2-selection--single {
            padding: 4px 3px;
            font-size: .8125rem;
            font-weight: 400;
            line-height: 11.5;
            color: var(--vz-body-color);
            background-color: var(--vz-input-bg);
            background-clip: padding-box;
            border: 1px solid var(--vz-input-border);
            border-radius: .25rem;
            height: 37.5px;
        }

        .select2-container--default .select2-selection--single .select2-selection__arrow {
            top: 6px;
        }
    </style>
</head>

<body>
    <!-- auth-page wrapper -->
    <div id="overlay" class="d-none position-fixed top-0 start-0 end-0 bottom-0 bg-dark opacity-50"></div>
    <div id="loader"
        class="d-none position-fixed top-0 start-0 end-0 bottom-0 d-flex justify-content-center align-items-center">
        <div class="spinner-border" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>
    <div class="auth-page-wrapper auth-bg-cover d-flex justify-content-center align-items-center">
        <div class="bg-overlay"></div>
        <!-- auth-page content -->
        <div class="auth-page-content overflow-hidden">
            <div class="container-fluid">
                {{-- <div class="wrapper"> --}}
                {{-- <div class="row">
                    <div class="col-lg-12">
                        <div class="white-bg d-flex justify-content-between align-items-center pe-lg-5">
                            <div class="main-logo">
                                <a href="{{ route('superadmin.dashboard') }}" class="d-block">
                <img class="img-fluid"
                    src="{{ asset('public/assets/images/tracenet_final_logo.png') }}" alt=""
                    style="width: 195px;">
                </a>
                <div class="logo-des">
                    <h1>A Traceability system <span> for organic products</span></h1>
                </div>
            </div>

            <div class="header-buttons">
                <!-- <button type="button" class="btn btn-primary btn-sm">Log In</button> -->
                <img src="{{ asset('public/assets/images/new_NPOP_logo.png') }}" alt="">
            </div>
        </div>
    </div>
    </div> --}}
    <div class="row t-header">
        <div class="col-lg-12">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="white-bg d-flex justify-content-between align-items-center">
                            <div class="main-logo">

                                <a href="#" class="d-block">
                                    <img class="img-fluid emblem-logo" src="{{ asset('public/assets/images/emblem.png') }}"
                                        alt="">
                                </a>
                                <a href="#" class="d-block">
                                    <img class="img-fluid apeda-logo" src="{{ asset('public/assets/images/APEDA_logo.png') }}"
                                        alt="">
                                </a>
                                <div class="logo-des">
                                    <h3>Agricultural & Processed Food Products <div class="export-txt">Export Development Authority(APEDA)</div><span> Ministry of Commerce and Industry<spna class="gov-india">Government of India</span></h3>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-lg-2">
                        <img class="trace-logo" src="{{ asset('public/assets/images/tracenet_logo_with_tagline.png') }}" alt="">
                    </div>
                    <div class="col-lg-4 d-flex justify-content-end">
                        <div class="cust_bg_flex_login_but">
                            <div class="header-buttons">
                                <img src="{{ asset('public/assets/images/new_NPOP_logo.png') }}" alt="" width="25%">
                            </div>
                            {{-- <div class="cust_log_cust_nn">
                                  <a href="{{ route('lab_login') }}" class="btn btn-success"> Lab Login</a>
                        </div> --}}
                        {{-- <div class="cust_log_cust_nn">
                                  <a href="" class="btn btn-success">Login</a>
                              </div> --}}
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <div class="row">

        <!-- end col -->
    </div>
    <!-- end row -->
    </div>
    <!-- end container -->
    </div>
    <!-- end auth page content -->
    </div>
    <!-- end auth-page-wrapper -->
    <!----------------------------------------------------- DATA TABS- -->
    <div class="breadcrum-area  ">
        <div class="breadcrumb-title-sec">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-sm-12 col-md-12 col-lg-12">
                        <h1 class="page-title">Request For Registration</h1>
                        <nav class="breadcrumb wow fadeInDown" role="navigation" aria-labelledby="system-breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="{{ route('apeda') }}">Home</a>
                                </li>

                                <li class="breadcrumb-item">
                                    <span>Request For Registration</span>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="data-tabs">
        <div class="container-fluid">
            <div class="wrapper tabdiv">
                {{-- <div class="row"> --}}
                {{-- <form action="{{ route('OrganicOperatorPost') }}" class="commonform1" id="commonform1" method="POST"
                enctype="multipart/form-data">
                @csrf
                <div class="row">
                    <div class="col-12 mb-3">
                        <h2 style="display: flex; justify-content: center;">Request For Registration</h2>
                    </div>
                </div>
                <div class="row">

                    <div class="flex-shrink-0">
                        @if (session('error'))
                        <div id="flash-message" class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                        @endif
                        @if (session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                        @endif
                        @if ($errors)
                        @foreach ($errors->all() as $error)
                        <div class="alert alert-danger">{{ $error }}</div>
                        @endforeach
                        @endif
                    </div>


                    <div class="col-xxl-3 col-md-6 mb-4">

                        <label for="basiInput" class="form-label">Certification Body<span class="required">*</span>
                        </label>

                        <select class="form-select select-2-down" name="cb_type" id="cb_type" onchange="getCBID(this.value)"
                            required>
                            <option value="">select</option>
                            @forelse(getCBNamesById() as $cb)
                            <option value="{{ $cb->id }}">
                                {{ $cb->first_name }}
                            </option>
                            @empty
                            @endforelse
                        </select>
                        @if ($errors->has('created_by'))
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $errors->first('created_by') }}</strong>
                        </span>
                        @endif


                    </div>


                    <div class="col-xxl-3 col-md-6 mb-4">
                        <div>
                            <label for="basiInput" class="form-label"> Legal Document1<span
                                    class="required">*</span>
                            </label>

                            <select class="form-select" name="document_type" id="document_type" required>
                                <option value="">-Select-</option>
                                <!-- <option value="PAN"
                                        {{ isset($userdetails->document_type) && $userdetails->document_type == 'PAN' ? 'selected' : '' }}>
                                        PAN</option> -->
                                <option value="PAN"
                                    {{ old('document_type', isset($userdetails->document_type) && $userdetails->document_type == 'PAN' ? 'PAN' : '') == 'PAN' ? 'selected' : '' }}>
                                    PAN
                                </option>

                            </select>

                            @if ($errors->has('document_type'))
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $errors->first('document_type') }}</strong>
                            </span>
                            @endif

                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-6 mb-4">
                        <div>
                            <label for="basiInput" class="form-label">Operator Type<span
                                    class="required">*</span>
                            </label>

                            <!-- <select class="form-select" name="operator_type_id" id="operator_type_id" required>
                                    <option value="">select</option>
                                    @forelse(getAllOperatorType() as $optyp)
                                        <option value="{{ $optyp->id }}">
                                            {{ $optyp->operator_type }}</option>
                                    @empty
                                    @endforelse

                                </select> -->
                            <select class="form-select" name="operator_type_id" id="operator_type_id" required>
                                <option value="">select</option>
                                @forelse(getAllOperatorType() as $optyp)
                                <!-- <option value="{{ $optyp->id }}"
                                            {{ old('operator_type_id', isset($optyp->id) && $userdetails->operator_type_id == $optyp->id ? $optyp->id : '') == $optyp->id ? 'selected' : '' }}>
                                            {{ $optyp->operator_type }}
                                        </option> -->
                                <option value="{{ $optyp->id }}" @selected(old('optyp')==$optyp->id)>
                                    {{ $optyp->operator_type }}
                                </option>
                                @empty
                                @endforelse
                            </select>
                            @if ($errors->has('ref_operator_type_id'))
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $errors->first('ref_operator_type_id') }}</strong>
                            </span>
                            @endif
                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-6 mb-4">
                        <label for="labelInput" class="form-label">Legal Entity Type / कानूनी प्रतिष्ठान प्रकार</label>
                        <select name="entity_firm" id="entity_firm" class="form-select">
                            <option value="">--Select Entity--</option>
                        </select>
                    </div>

                    <div class="col-xxl-3 col-md-6 mb-4">
                        <div>
                            <label class="form-label"><span id="operator_name_label">Operator Name</span><span
                                    class="required">*</span></label>
                            <input type="text" class="form-control keyValueChecker " id="first_name"
                                name="first_name" required value="{{ old('first_name') }}">
                            @if ($errors->has('first_name'))
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $errors->first('first_name') }}</strong>
                            </span>
                            @endif
                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-6 mb-4">
                        <div>
                            <label class="form-label">
                                <span id="dob_doi_label">Date of Birth/जन्म तिथि</span>
                                <span class="form-text">(As per Pan)</span>
                                <span class="required">*</span>
                            </label>
                            <input type="date" class="form-control" id="dob_doi_date" name="dob_doi_date"
                                required
                                value="{{ old('dob_doi_date', isset($yourModel) ? $yourModel->dob_doi_date->format('Y-m-d') : '') }}"
                                max="{{ now()->format('Y-m-d') }}">
                        </div>
                        <div class="mt-1" id="panDob_response"></div>
                    </div>
                    <div class="col-xxl-3 col-md-6 mb-4 d-none" id="fatherName_add">
                        <div class="mb-2">
                            <label class="form-label">/Fathers Name<span class="form-text">(As per PAN)</span>
                                <span class="required">*</span></label>
                            <input type="text" class="form-control" id="father_name"
                                placeholder="Father Name" name="father_name" value="{{ old('father_name') }}" required>
                        </div>
                        <div class="mt-1" id="fatherName_response"></div>
                    </div>
                    <div class="col-xxl-3 col-md-6 mb-4">

                        <label class="form-label">PAN Number/पैन संख्या<span class="required">*</span></label>
                        <input type="text" class="form-control" id="user_name" name="user_name" required
                            value="{{ old('user_name') }}" maxlength="10" onblur="getDetailsPanOP(this.value)">
                        <span id="error"></span>
                        @if ($errors->has('user_name'))
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $errors->first('user_name') }}</strong>
                        </span>
                        @endif

                    </div>

                    <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">


                        <label for="labelInput" class="form-label">Address <span
                                class="required">*</span></label>
                        <textarea class="form-control customtextarea keyValueChecker" name="address" required maxlength="200"
                            style="height: 50px;">{{ old('address') }}</textarea>

                        @if ($errors->has('address'))
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $errors->first('address') }}</strong>
                        </span>
                        @endif


                    </div>
                    <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">

                        <label for="labelInput" class="form-label">Pin Code <span
                                class="required">*</span></label>
                        <input type="text" class="form-control numbersonly" id="pin" required
                            name="pin" placeholder="Pin Code" maxlength="6" value="{{ old('pin') }}">

                        @if ($errors->has('pin'))
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $errors->first('pin') }}</strong>
                        </span>
                        @endif
                    </div>

                    <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">
                        <label for="labelInput" class="form-label">State <span class="required">*</span></label>
                        <select class="form-select state" name="state" id="stateID" required required>
                            <option value="">Select State</option>
                            @forelse(getAllState() as $state)
                            <option value="{{ $state->id }}" @selected(old('state')==$state->id)>
                                {{ $state->state_name }}
                            </option>
                            @empty
                            @endforelse
                        </select>
                    </div>
                    <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">
                        <label for="labelInput" class="form-label">District <span
                                class="required">*</span></label>
                        <select class="form-select district" name="district" id="district" required required>
                            @forelse(getDistrictByStateID(old('state')) as $district)
                            <option value="{{ $district->id }}" @selected(old('district')==$district->id)>
                                {{ $district->district_name }}
                            </option>
                            @empty
                            <option value="">-Select District-</option>
                            @endforelse


                        </select>
                    </div>
                    <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">
                        <label for="labelInput" class="form-label">Taluka/Mandal
                            <span class="required">*</span></label>
                        <select class="form-select block_tehsil" name="taluka" required id="block_tehsil"
                            required>

                            @forelse(getBlockTehsilByDistrictID(old('district')) as $block)
                            <option value="{{ $block->id }}" @selected(old('taluka')==$block->id)>
                                {{ $block->block_tehsil_name }}
                            </option>
                            @empty
                            <option value="">-Select Taluka/Mandal-</option>
                            @endforelse


                        </select>
                    </div>

                    <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">
                        <label for="labelInput" class="form-label">Village <span
                                class="required">*</span></label>

                        <select class="form-select village" name="village" id="village" required>
                            @forelse(getVillageByBlock(old('taluka')) as $village)
                            <option value="{{ $village->id }}" @selected(old('village')==$village->id)>
                                {{ $village->village_name }}
                            </option>
                            @empty
                            <option value="">-Select Village-</option>
                            @endforelse
                        </select>

                    </div>


                </div>

                <div class="row">


                    <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">

                        <label class="form-label">Contact Person First Name<span class="required">*</span></label>
                        <input type="text" class="form-control keyValueChecker"
                            id="contact_person_first_name" required placeholder="First Name"
                            name="contact_person_first_name" value="{{ old('contact_person_first_name') }}">
                        @if ($errors->has('contact_person_first_name'))
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $errors->first('contact_person_first_name') }}</strong>
                        </span>
                        @endif

                    </div>

                    <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">

                        <label class="form-label">Contact Person Middle Name
                        </label>
                        <input type="text" class="form-control keyValueChecker"
                            id="contact_person_middle_name" name="contact_person_middle_name"
                            placeholder="Middle Name" value="{{ old('contact_person_middle_name') }}">



                    </div>

                    <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">

                        <label class="form-label">Contact Person Last Name<span class="required">*</span></label>
                        <input type="text" class="form-control keyValueChecker"
                            id="contact_person_last_name" required name="contact_person_last_name"
                            placeholder="Last Name" value="{{ old('contact_person_last_name') }}">
                        @if ($errors->has('contact_person_last_name'))
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $errors->first('contact_person_last_name') }}</strong>
                        </span>
                        @endif

                    </div>
                    <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">

                        <label for="labelInput" class="form-label">Gender</label>
                        <select name="contact_person_gender" class="form-select" required>
                            <option value="">Select Gender</option>
                            @foreach (getGenderName() as $key => $value)
                            <option value="{{ $key }}"
                                {{ old('contact_person_gender') == 1 ? 'selected' : '' }}>
                                {{ $value }}
                            </option>
                            @endforeach

                        </select>

                    </div>

                    <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">

                        <label for="labelInput" class="form-label">Contact Person
                            Email Id<span class="required">*</span></label>
                        <input type="contact_person_email" class="form-control " id="contact_person_email"
                            required name="contact_person_email" placeholder="Contact Person Email"
                            value="{{ old('contact_person_email') }}">
                        @if ($errors->has('contact_person_email'))
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $errors->first('contact_person_email') }}</strong>
                        </span>
                        @endif

                        <button type="button"
                            class="btn-email btn btn-outline-success waves-effect waves-light visitorCat2 mt-2">Get
                            OTP</button>
                        <button type="button" class="btn btn-ghost-success waves-effect waves-light btn-mailsend"
                            style="display:none">Mail Send</button>
                        <button type="button" class="btn btn-ghost-success waves-effect waves-light btn-verify"  style="display:none">Verified</button>

                    </div>
                    <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">

                        <label for="labelInput" class="form-label">Contact Person Mobile
                            Number<span class="required">*</span></label>
                        <input type="text" class="form-control numbersonly phone" id="mobile_number" required
                            name="contact_person_mobile_number" placeholder="Mobile Number"
                            onblur="phonenumber(this)" maxlength="10"
                            value="{{ old('contact_person_mobile_number') }}">


                        <button type="button" class="btn btn-primary mt-2" id="getOtpBtn"
                            onclick="sendOtp()">Get OTP</button>


                        <button type="button" class="btn btn-warning mt-2" id="resendOtpBtn"
                            onclick="sendOtp()" style="display: none;">Resend OTP</button>


                        <button type="button" class="btn btn-success mt-2" id="verifiedBtn"
                            style="display: none;" disabled>Verified</button>


                        <div id="otp_section" style="display: none;">
                            <input type="text" id="otp_input" class="form-control mt-2"
                                placeholder="Enter OTP" maxlength="6">
                            <button type="button" class="btn btn-primary mt-2" onclick="verifyOtp()">Verify
                                OTP</button>
                        </div>


                        @if ($errors->has('mobile'))
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $errors->first('mobile') }}</strong>
                        </span>
                        @endif
                    </div>
                    <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">

                        <label for="labelInput" class="form-label">Contact
                            Person Aadhar Number</label>
                        <input type="text" class="form-control numbersonly"
                            name="contact_person_aadhar_number" id="contact_person_aadhar_number"
                            placeholder="Aadhar Number*" value="" maxlength="12">


                    </div>


                    <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">

                        <label for="labelInput" class="form-label">Designation of Contact Person</label>

                        <select name="contact_designation" class="form-select">
                            <option value="">Select Designation</option>

                            <option value="Manager">Manager
                            </option> -


                        </select>


                    </div>



                </div>

                <div class="row">
                    <div class="col-12 col-sm-12 col-md-12 col-lg-12 mb-3">
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" id="declaration" name="declaration"
                                required>
                            <label style="color: rgb(221, 83, 48); width: 1200px ">I/we hereby declare that all the
                                information provided is true and accurate,
                                I/we acknowledge and agree to use my PAN/Aadhar and
                                other licenses for verification purposes and consent to the sharing of this
                                information with regulatory bodies as required.
                            </label>
                            @if ($errors->has('declaration'))
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $errors->first('declaration') }}</strong>
                            </span>
                            @endif
                        </div>
                    </div>

                </div>
                <div class="row">

                    <div class="col-12 col-sm-12 col-md-3 col-lg-2">
                        <div class="form-group">
                            <label>Captcha</label>
                            <div class="captcha nopd">
                                <span><?php echo captcha_img(); ?> </span>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-12 col-md-1 col-lg-1">
                        <div class="form-group captchareload btn-refresh">
                            <a href="javascript:void(0);" class="reload fa-lg"><i
                                    class="ri-refresh-line align-middle"></i></a>
                        </div>
                    </div>
                    <div class="col-12 col-sm-12 col-md-3 col-lg-3">
                        <div class="form-group captchinputcstm">
                            <label>Put Text Here</label>
                            <input type="text" name="captcha" name="captcha"
                                class="form-control {{ $errors->has('captcha') ? ' is-invalid' : '' }}"
                                placeholder="Enter captcha">
                            @if ($errors->has('captcha'))
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $errors->first('captcha') }}</strong>
                            </span>
                            @endif
                        </div>
                    </div>

                    <div class="col-lg-12 gy-4 mt-5">
                        <div class="gap-2" style="display: flex; justify-content: center;">
                            <button type="submit" class="btn btn-primary" id="submitBtn"
                                style="display: none;">Submit Application to CB</button>
                        </div>
                    </div>
                </div>
                </form> --}}

                <form action="{{ route('OrganicOperatorPost') }}" class="commonform1" id="commonform1" method="POST"
                    enctype="multipart/form-data">
                    @csrf
                    <div class="row">
                        <div class="col-12 mb-3">
                            <h2 style="display: flex; justify-content: center;">पंजीकरण के लिए अनुरोध / Request For Registration</h2>
                        </div>
                    </div>
                    <div class="row">

                        <div class="flex-shrink-0">
                            @if (session('error'))
                            <div id="flash-message" class="alert alert-danger">
                                {{ session('error') }}
                            </div>
                            @endif
                            @if (session('success'))
                            <div class="alert alert-success">
                                {{ session('success') }}
                            </div>
                            @endif
                            @if ($errors)
                            @foreach ($errors->all() as $error)
                            <div class="alert alert-danger">{{ $error }}</div>
                            @endforeach
                            @endif
                        </div>


                        <div class="col-xxl-4 col-md-6 mb-6">
                            {{-- <div> --}}
                            <label for="basiInput" class="form-label">प्रमाणीकरण निकाय / Certification Body<span class="required">*</span>
                            </label>
                            <!-- <select class="form-select select-2-down" name="cb_type" id="cb_type" onchange="getCBID(this.value)"
                                required>
                                <option value="">select</option>
                                @forelse(getCBNamesById() as $cb)
                                    <option value="{{ $cb->id }}">
                                        {{ $cb->first_name }}</option>
                                @empty
                                @endforelse
                            </select> -->
                            <select class="form-select select-2-down" name="cb_type" id="cb_type" onchange="getCBID(this.value)" required>
                                <option value="">select</option>
                                @forelse(getCBNamesById() as $cb)
                                <option value="{{ $cb->id }}"
                                    @selected(old('cb_type')==$cb->id)>
                                    {{ $cb->first_name }}
                                </option>
                                @empty
                                <option value="">No options available</option>
                                @endforelse
                            </select>

                            @if ($errors->has('created_by'))
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $errors->first('created_by') }}</strong>
                            </span>
                            @endif

                            {{-- </div> --}}
                        </div>

                        {{-- <div class="row"> --}}
                        {{-- <div class="col-xxl-4 col-md-6 mb-4">
                            <div>
                                <label for="basiInput" class="form-label">कानूनी दस्तावेज़ / Legal Document<span
                                        class="required">*</span>
                                </label>

                                <select class="form-select" name="document_type" id="document_type" required>
                                    <!-- <option value="">-Select-</option>
                                    <option value="PAN"
                                        {{ isset($userdetails->document_type) && $userdetails->document_type == 'PAN' ? 'selected' : '' }}>
                        PAN</option> -->
                        <option value="PAN" {{ old('document_type', isset($userdetails->document_type) && $userdetails->document_type == 'PAN' ? 'selected' : '') }}> PAN</option>

                        </select>

                        @if ($errors->has('document_type'))
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $errors->first('document_type') }}</strong>
                        </span>
                        @endif

                    </div>
            </div>--}}
            <div class="col-xxl-4 col-md-6 mb-6">
                <div>
                    <label for="basiInput" class="form-label">संचालक प्रकार / Operator Type <span
                            class="required">*</span>
                    </label>

                    <select class="form-select" name="operator_type_id" id="operator_type_id" required>
                        <option value="">select</option>
                        @forelse(getAllOperatorType() as $optyp)
                        <option value="{{ $optyp->id }}" @selected(old('operator_type_id')==$optyp->id)>
                            {{ $optyp->operator_type }}
                        </option>
                        @empty
                        <option value="">No operators available</option>
                        @endforelse
                    </select>

                    @if ($errors->has('ref_operator_type_id'))
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $errors->first('ref_operator_type_id') }}</strong>
                    </span>
                    @endif
                </div>
            </div>
            <!-- <div class="col-xxl-3 col-md-6 mb-4">
                            <label for="labelInput" class="form-label">कानूनी प्रतिष्ठान प्रकार / Legal Entity Type</label>
                            <select name="entity_firm" id="entity_firm" class="form-select">
                                <option value="">--Select Entity--</option>
                            </select>
                        </div> -->
            <div class="col-xxl-4 col-md-6 mb-4">
                <label for="labelInput" class="form-label">कानूनी प्रतिष्ठान प्रकार / Legal Entity Type</label>
                <select name="entity_firm" id="entity_firm" class="form-select">
                    <option value="">--Select Entity--</option>
                    @if (old('operator_type_id') == 2)
                    <option value="Registered Society" @selected(old('entity_firm')=='Registered Society' )>Registered Society</option>
                    <option value="FPO/FPC" @selected(old('entity_firm')=='FPO/FPC' )>FPO/FPC</option>
                    <option value="Co-operative society/PACs" @selected(old('entity_firm')=='Co-operative society/PACs' )>Co-operative society/PACs</option>
                    @elseif (old('operator_type_id') == 3)
                    <option value="Individual" @selected(old('entity_firm')=='Individual' )>Individual</option>
                    <option value="Business Entity" @selected(old('entity_firm')=='Business Entity' )>Business Entity</option>
                    @elseif (old('operator_type_id') == 4)
                    <option value="Business Entity" @selected(old('entity_firm')=='Business Entity' )>Business Entity</option>
                    @elseif (old('operator_type_id') == 5)
                    <option value="Business Entity" @selected(old('entity_firm')=='Business Entity' )>Business Entity</option>
                    @elseif (old('operator_type_id') == 6)
                    <option value="Business Entity" @selected(old('entity_firm')=='Business Entity' )>Business Entity</option>
                    @endif
                </select>
            </div>
            <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">
                <div>
                    <label class="form-label"><span id="operator_name_label">संचालक का नाम / Operator Name (As per PAN)</span><span
                            class="required">*</span></label>
                    <input type="text" class="form-control keyValueChecker " id="first_name"
                        name="first_name" required value="{{ old('first_name') }}">
                    @if ($errors->has('first_name'))
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $errors->first('first_name') }}</strong>
                    </span>
                    @endif
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">
                <div>
                    <label class="form-label">
                        <span id="dob_doi_label">जन्म तिथि (पैन के अनुसार)/Date of Birth (As per PAN)</span>
                        <span class="required">*</span>
                    </label>
                    <input type="date" class="form-control" id="dob_doi_date" name="dob_doi_date"
                        required
                        value="{{ old('dob_doi_date', isset($yourModel) ? $yourModel->dob_doi_date->format('Y-m-d') : '') }}"
                        max="{{ now()->format('Y-m-d') }}">
                </div>
                <div class="mt-1" id="panDob_response"></div>
            </div>
            <div class="col-xxl-3 col-md-6 mb-4 d-none" id="fatherName_add">
                <div class="mb-2">
                    <label class="form-label">पिता का नाम /Father's Name<span class="form-text">(As per PAN)</span>
                        <span class="required">*</span></label>
                    <input type="text" class="form-control" id="father_name"
                        placeholder="Father Name" name="father_name" value="{{ old('father_name') }}" required>
                </div>
                <div class="mt-1" id="fatherName_response"></div>
            </div>
            <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">
                {{-- <div> --}}
                <label class="form-label">पैन संख्या / PAN No<span class="required">*</span></label>
                <input type="text" class="form-control" id="user_name" name="user_name" required
                    value="{{ old('user_name') }}" maxlength="10" onblur="getDetailsPanOP(this.value)">
                <span id="error"></span>
                @if ($errors->has('user_name'))
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first('user_name') }}</strong>
                </span>
                @endif
                {{-- </div> --}}
            </div>
            <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">
                {{-- <div class="col-xx-3 col-md-12"> --}}
                <label for="labelInput" class="form-label">पता / Address <span class="required">*</span></label>
                <textarea placeholder="Address" class="form-control customtextarea" maxlength="200" name="address" required>{{ old('address') }}</textarea>
                {{-- </div> --}}
                @if ($errors->has('address'))
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first('address') }}</strong>
                </span>
                @endif
            </div>
            <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">
                {{-- <div> --}}
                <label for="labelInput" class="form-label">पिन कोड/ Pin code<span class="required">*</span></label>
                <input type="text" class="form-control numbersonly" id="pin" required name="pin" placeholder="Pin Code" maxlength="6" value="{{ old('pin') }}">
                {{-- </div> --}}
                @if ($errors->has('pin'))
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first('pin') }}</strong>
                </span>
                @endif
            </div>
            {{-- <div class="col-xxl-9 col-md-9 mt-4"> --}}
            {{-- <div class="row"> --}}
            <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">
                <label for="labelInput" class="form-label">राज्य/State/UT <span class="required">*</span></label>
                <select class="form-select state" name="state" id="stateID" required>
                    <option value="">Select State</option>
                    @forelse(getAllState() as $state)
                    <option value="{{ $state->id }}" @selected(old('state')==$state->id)> {{ $state->state_name }} </option>
                    @empty
                    <option value="">No states available</option>
                    @endforelse
                </select>
            </div>
            <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">
                <label for="labelInput" class="form-label">जिला/District <span class="required">*</span></label>
                <select class="form-select district" name="district" id="district" required required>
                    @forelse(getDistrictByStateID(old('state')) as $district)
                    <option value="{{ $district->id }}" @selected(old('district')==$district->id)>
                        {{ $district->district_name }}
                    </option>
                    @empty
                    <option value="">-Select District-</option>
                    @endforelse
                </select>
            </div>
            <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">
                <label for="labelInput" class="form-label">तालुका/मंडल /Taluka/Mandal
                    <span class="required">*</span></label>
                <select class="form-select block_tehsil" name="taluka" required id="block_tehsil"
                    required>

                    @forelse(getBlockTehsilByDistrictID(old('district')) as $block)
                    <option value="{{ $block->id }}" @selected(old('taluka')==$block->id)>
                        {{ $block->block_tehsil_name }}
                    </option>
                    @empty
                    <option value="">-Select Taluka/Mandal-</option>
                    @endforelse
                </select>
            </div>
            <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">
                <label for="labelInput" class="form-label">गांव/Village <span class="required">*</span></label>
                <select class="form-select village" name="village" id="village" required>
                    @forelse(getVillageByBlock(old('taluka')) as $village)
                    <option value="{{ $village->id }}" @selected(old('village')==$village->id)>
                        {{ $village->village_name }}
                    </option>
                    @empty
                    <option value="">-Select Village-</option>
                    @endforelse
                </select>
            </div>

            {{-- </div> --}}
            {{-- </div> --}}

            {{-- </div> --}}
        </div>

        <div class="row white-inner">
            <div class="sectitle">
                <label for="labelInput" class="form-label blue-ht">संपर्क व्यक्ति का विवरण /Contact Person Details</label>
            </div>
            <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">
                <label class="form-label">
                    प्रथम नाम / First Name<span class="required">*</span>
                </label>
                <input type="text" class="form-control keyValueChecker" id="contact_person_first_name" required placeholder="First Name" name="contact_person_first_name" value="{{ old('contact_person_first_name') }}">
                @if ($errors->has('contact_person_first_name'))
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first('contact_person_first_name') }}</strong>
                </span>
                @endif
            </div>
            <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">
                <label class="form-label">मध्य नाम / Middle Name</label>
                <input type="text" class="form-control keyValueChecker" id="contact_person_middle_name" name="contact_person_middle_name" placeholder="Middle Name" value="{{ old('contact_person_middle_name') }}">
            </div>
            <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">
                <label class="form-label">अंतिम नाम / Last Name <span class="required">*</span></label>
                <input type="text" class="form-control keyValueChecker" id="contact_person_last_name" required name="contact_person_last_name" placeholder="Last Name" value="{{ old('contact_person_last_name') }}">
                @if ($errors->has('contact_person_last_name'))
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first('contact_person_last_name') }}</strong>
                </span>
                @endif

            </div>
            <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">
                <label for="labelInput" class="form-label">लिंग/Gender<span class="required">*</span></label>
                <select name="contact_person_gender" class="form-select" required>
                    <option value="">Select Gender</option>
                    @foreach (getGenderName() as $key => $value)
                    <option value="{{ $key }}"
                        {{ old('contact_person_gender') == $key ? 'selected' : '' }}>
                        {{ $value }}
                    </option>
                    @endforeach
                </select>
            </div>
            <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">
                <label for="labelInput" class="form-label">ई-मेल आईडी/ Email Id<span class="required">*</span></label>
                <input type="contact_person_email" class="form-control " id="contact_person_email"
                    required name="contact_person_email" placeholder="Person Email"
                    value="{{ old('contact_person_email') }}">
                @if ($errors->has('contact_person_email'))
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first('contact_person_email') }}</strong>
                </span>
                @endif
                <button type="button" class="btn-email btn btn-outline-success waves-effect waves-light visitorCat2 mt-2">ओटीपी प्राप्त करें/ Get OTP</button>
                <button type="button" class="btn btn-ghost-success waves-effect waves-light btn-mailsend" style="display:none">Mail Send</button>  
                <button type="button" class="btn btn-ghost-success waves-effect waves-light btn-verify" style="display:none">Verified</button>
            </div>
            <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">
                <label for="labelInput" class="form-label">मोबाइल नंबर/ Mobile Number<span class="required">*</span></label>
                <input type="text" class="form-control numbersonly phone" id="mobile_number" required
                    name="contact_person_mobile_number" placeholder="Mobile Number"
                    onblur="phonenumber(this)" maxlength="10"
                    value="{{ old('contact_person_mobile_number') }}">
                <!-- Get OTP Button -->
                <button type="button" class="btn btn-primary mt-2" id="getOtpBtn"
                    onclick="sendOtp()">ओटीपी प्राप्त करें/ Get OTP</button>

                <!-- Resend OTP Button (Initially Hidden) -->
                <button type="button" class="btn btn-warning mt-2" id="resendOtpBtn"
                    onclick="sendOtp()" style="display: none;">Resend OTP</button>

                <!-- Verified Button (Initially Hidden) -->
                <button type="button" class="btn btn-success mt-2" id="verifiedBtn"
                    style="display: none;" disabled>Verified</button>

                <!-- OTP Input Section (Initially Hidden) -->
                <div id="otp_section" style="display: none;">
                    <input type="text" id="otp_input" class="form-control mt-2"
                        placeholder="Enter OTP" maxlength="6">
                    <button type="button" class="btn btn-primary mt-2" onclick="verifyOtp()">Verify
                        OTP</button>
                </div>

                @if ($errors->has('mobile'))
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first('mobile') }}</strong>
                </span>
                @endif
            </div>

            <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">
                <label for="contact_person_aadhar_number" class="form-label">
                    आधार संख्या/ Aadhaar No.
                    <span class="required">*</span>
                </label>
                <input type="text" class="form-control numbersonly"
                    name="contact_person_aadhar_number" id="contact_person_aadhar_number"
                    placeholder="Aadhaar No." value="{{  base64_decode(old('contact_person_aadhar_number')) }}" maxlength="12">
            </div>

            <div class="col-12 col-sm-12 col-md-4 col-lg-4 mb-3">
                <label for="labelInput" class="form-label">पदनाम / Designation<span class="required">*</span></label>

                <select name="contact_designation" id="contact_designation" class="form-select">
                    <option value="">Select Designation</option>
                    <option value="ICS Manager" @selected(old('contact_designation')=='ICS Manager' )>ICS Manager</option>
                    <option value="Business Entity" @selected(old('contact_designation')=='Business Entity' )>Business Entity</option>
                    <option value="Individual" @selected(old('contact_designation')=='Individual' )>Individual</option>
                    <!-- Additional options will be added dynamically via JavaScript -->
                </select>
            </div>
        </div>

        <div class="row">
            <div class="col-12 col-sm-12 col-md-12 col-lg-12 mb-3">
                <div class="form-check">
                    <input type="checkbox" class="form-check-input" id="declaration" name="declaration"
                        required>
                    <label style="color: rgb(221, 83, 48); width: 1185px ">मैं/हम घोषणा करते हैं कि प्रदान की गई सभी जानकारी सत्य और सटीक है, मैं/हम सत्यापन प्रयोजनों के लिए अपने पैन/आधार और अन्य लाइसेंस का उपयोग करने और आवश्यकतानुसार विनियामक निकायों के साथ इस जानकारी को साझा करने की सहमति देते हैं। <br>I/we hereby declare that all the information provided is true and accurate, I/we acknowledge and agree to use my PAN/Aadhaar and other licenses for verification purposes and consent to the sharing of this information with regulatory bodies as required.
                    </label>
                    @if ($errors->has('declaration'))
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $errors->first('declaration') }}</strong>
                    </span>
                    @endif
                </div>
            </div>

        </div>
        <div class="row">
            {{-- <div class="mb-3 d-flex align-items-center captcharow"> --}}
            {{-- <div class="row "> --}}
            <div class="col-12 col-sm-12 col-md-3 col-lg-2">
                <div class="form-group">
                    <label>कैप्चा/Captcha</label>
                    <div class="captcha nopd">
                        <span><?php echo captcha_img(); ?> </span>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-1 col-lg-1">
                <div class="form-group captchareload btn-refresh">
                    <a href="javascript:void(0);" class="reload fa-lg"><i
                            class="ri-refresh-line align-middle"></i></a>
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-3 col-lg-3">
                <div class="form-group captchinputcstm">
                    <label>टेक्स्ट यहाँ डालें/ Put Text Here</label>
                    <input type="text" name="captcha" name="captcha"
                        class="form-control {{ $errors->has('captcha') ? ' is-invalid' : '' }}"
                        placeholder="Enter captcha">
                    @if ($errors->has('captcha'))
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $errors->first('captcha') }}</strong>
                    </span>
                    @endif
                </div>
            </div>
            {{-- </div> --}}
            {{-- </div> --}}
            <div class="col-lg-12 gy-4 mt-5">
                <div class="gap-2" style="display: flex; justify-content: center;">
                    <button type="submit" class="btn btn-primary" id="submitBtn"
                        style="display: none;">Submit Application to CB</button>
                </div>
            </div>
        </div>
        </form>


        {{-- </div> --}}
    </div>
    </div>
    </div>
    <!-- footer -->
    <div class="frontfooter">
        <footer class="footer ">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="text-center">
                            <p class="mb-0">
                                &copy;
                                Agricultural and Processed Food Products Export Development Authority (APEDA)
                                <script>
                                    document.write(new Date().getFullYear())
                                </script>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>
    <!-- end Footer -->
    <!------------------------------------------------- DATA TABS ENDS  -->
    <!-- JAVASCRIPT -->
    <script src="{{ asset('public/js/jquery-3.3.1.min.js') }}"></script>
    <script src="{{ asset('public/js/bootstrap-4.2.1.js') }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.3/jquery.validate.min.js"></script>
    <script type="text/javascript" src="{{ asset('public/backend/js/sha.js') }}"></script>
    <script src="{{ asset('public/assets/libs/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
    <script src="{{ asset('public/assets/libs/simplebar/simplebar.min.js') }}"></script>
    <script src="{{ asset('public/assets/libs/node-waves/waves.min.js') }}"></script>
    <script src="{{ asset('public/assets/libs/feather-icons/feather.min.js') }}"></script>
    <script src="{{ asset('public/assets/js/pages/plugins/lord-icon-2.1.0.js') }}"></script>
    <script src="{{ asset('public/assets/js/plugins.js') }}"></script>
    <script src="{{ asset('public/assets/js/pages/password-addon.init.js') }}"></script>
    <script src="{{ asset('public/backend/js/sweetalert.js') }}"></script>
    <script src="{{asset('public/assets/libs/select2/select2.min.js')}}"></script>



    @include('sweetalert::alert')

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Get references to the dropdowns
            var entityFirmSelect = document.getElementById('entity_firm');
            var contactDesignationSelect = document.getElementById('contact_designation');

            // Function to update contact designation options based on selected entity firm
            function updateDesignationOptions() {
                var selectedEntity = entityFirmSelect.value;

                // Clear previous options
                contactDesignationSelect.innerHTML = '<option value="">Select Designation</option>';

                // Update contact designation options based on entity firm selection
                if (selectedEntity === 'Business Entity') {
                    var option = document.createElement('option');
                    option.value = 'Director';
                    option.textContent = 'Director';
                    contactDesignationSelect.appendChild(option);
                } else {
                    var option = document.createElement('option');
                    option.value = 'ICS Manager';
                    option.textContent = 'ICS Manager';
                    contactDesignationSelect.appendChild(option);
                }

                // Optionally, add "Manager" as a default option
                var managerOption = document.createElement('option');
                managerOption.value = 'Business Entity';
                managerOption.textContent = 'Business Entity';
                contactDesignationSelect.appendChild(managerOption);
                var managerOption = document.createElement('option');
                managerOption.value = 'Individual';
                managerOption.textContent = 'Individual';
                contactDesignationSelect.appendChild(managerOption);
            }

            // Listen for changes in the entity firm dropdown
            entityFirmSelect.addEventListener('change', updateDesignationOptions);

            // Initialize the designation options on page load (in case there is an existing value)
            updateDesignationOptions();
        });


        document.getElementById('operator_type_id').addEventListener('change', function() {
            const dobLabel = document.getElementById('dob_doi_label');
            const operatorNameLabel = document.getElementById('operator_name_label');
            $('#entity_firm').empty();
            $('#entity_firm').append('<option value="">--Select Entity--</option>');
            const oldValue = '{{ old('
            entity_firm ') }}';

            switch (this.value) {
                case '2': // Grower Group
                    $('#entity_firm').append(
                        `<option value="Registered Society" data-docType="NA" title="Society registered under the Societies Registration Act, 1860 or relevant State Societies Act/Rules">Registered Society</option>
                        <option value="FPO/FPC" data-docType="NA" title="Farmers Producer Organization (FPO)/Farmers Producer Company (FPC) incorporated under the Companies Act, 2013, as amended from time to time">FPO/FPC</option><option value="Co-operative society/PACs/FPO" data-docType="NA" title="Co-operative society, including Primary Agricultural Co-operative Societies (PACs) and Farmers Producer Organization (FPO), registered under the relevant state Co-operative Societies Act/Rules"> Co-operative society/PACs</option>`
                    );
                    dobLabel.innerHTML = 'संस्थापन की तारीख/Date of Incorporation';
                    operatorNameLabel.innerHTML = 'उत्पादक समूह का नाम/Name of Grower Group (As per PAN)';
                    break;
                case '3': // Individual Producer
                    $('#entity_firm').append(
                        `<option value="Indian Companies Act" data-docType="NA">Business Entity</option>
                        <option value="Propietor" data-docType="Y">Individual</option>`

                    );
                    dobLabel.innerHTML = 'संस्थापन की तारीख/Date of Incorporation';
                    operatorNameLabel.innerHTML = 'व्यक्तिगत उत्पादक का नाम/Name of Individual Producer (As per PAN)';
                    break;
                case '4': // Wild Harvester
                    $('#entity_firm').append(
                        `<option value="Indian Companies Act" data-docType="NA">Business Entity</option>`
                    );
                    dobLabel.innerHTML = 'संस्थापन की तारीख/Date of Incorporation';
                    operatorNameLabel.innerHTML =
                        'वन कटाईकर्ता का नाम/Name of Wild Harvester (As per PAN Document)';
                    break;
                case '5': // Trader
                    $('#entity_firm').append(
                        `<option value="Indian Companies Act" data-docType="NA">Business Entity</option>`
                    );
                    dobLabel.innerHTML = 'संस्थापन की तारीख/Date of Incorporation';
                    operatorNameLabel.innerHTML = 'व्यापारी का नाम/Name of Trader (As per PAN)';
                    break;
                case '6': // Processor
                    $('#entity_firm').append(
                        `<option value="Indian Companies Act" data-docType="NA">Business Entity</option>`
                    );
                    dobLabel.innerHTML = 'संस्थापन की तारीख/Date of Incorporation';
                    operatorNameLabel.innerHTML = 'प्रोसेसर का नाम/Name of Processor(As per PAN)';
                    break;
                case '7': // Processor
                    $('#entity_firm').append(
                        ` <option value="Propietor" data-doctype="Y">Propietor</option>`
                    );
                    dobLabel.innerHTML = 'जन्मतिथि/Date of Birth';
                    operatorNameLabel.innerHTML = 'व्यक्तिगत उत्पादक का नाम/Name of Individual Producer (As per PAN Document)';
                    break;
                default: // Reset to default
                    dobLabel.innerHTML = 'संस्थापन की तारीख/Date of Incorporation';
                    operatorNameLabel.innerHTML = 'Name (As per Legal Document)';
                    break;
            }

            if (oldValue && $('#entity_firm option[value="' + oldValue + '"]').length) {
                $('#entity_firm').val(oldValue); // Set the old value in the dropdown
            }
        });


        function showLoader() {
            document.getElementById('overlay').classList.remove('d-none');
            document.getElementById('loader').classList.remove('d-none');
        }

        function hideLoader() {
            document.getElementById('overlay').classList.add('d-none');
            document.getElementById('loader').classList.add('d-none');
        }

        // jQuery script to allow only numbers in inputs with the 'numbersonly' class
        $(document).ready(function() {
            $('.numbersonly').on('input', function() {
                this.value = this.value.replace(/[^0-9]/g, ''); // Removes any non-numeric characters
            });
            $('#entity_firm').on('change', function() {
                const doctype = $(this).find('option:selected').data('doctype');
                if (doctype === 'Y') {
                    $('#fatherName_add').removeClass('d-none');
                } else {
                    $('#fatherName_add').addClass('d-none');
                }
                if (doctype === 'NA') {
                    $('#dob_doi_label').text("संस्थापन की तारीख/Date of Incorporation."); // Change label text
                } else {
                    $('#dob_doi_label').text("जन्म तिथि (पैन के अनुसार)/Date of Birth (As per PAN)"); // Default label
                }
            });
        });


        $(".btn-refresh").click(function() {

            $.ajax({
                type: 'GET',
                url: '{{ route('refresh_captcha') }}',
                success: function(data) {
                    $(".captcha span").html(data);

                }
            });
        });

        $("#commonform1").validate({
            rules: {
                // user_password: {
                // 	required: true,
                // 	minlength: 8,
                // 	maxlength: 10,
                // } ,
                mobile: {
                    required: true,
                }
            },
            messages: {
                // user_password: {
                // 	required:"This field is required and should be 8 digits, contains upper,lowerCase,and a special Character"
                // },
                mobile: {
                    required: "This field is required",
                }
            }

        });

        let isOtpVerified = false;
        let isMobileVerified = false;
        let isEmailVerified = false;

        function sendOtp() {
            var mobile = document.getElementById('mobile_number').value;

            if (mobile.length === 10) {
                showLoader();
                fetch('{{ route('sendOtpReg') }}', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': '{{ csrf_token() }}'
                            },
                            body: JSON.stringify({
                                mobile_number: mobile
                            })
                        })
                    .then(response => response.json())
                    .then(data => {
                        hideLoader();
                        if (data.status === 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: 'Valid Mobile Number',
                                text: 'OTP sent successfully!',
                            });
                            document.getElementById('otp_section').style.display = 'block'; // Display OTP section
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed to send OTP',
                                text: 'Please try again.',
                            });
                        }
                    })
                    .catch(error => {
                        hideLoader();
                        console.error('Error:', error);
                        Swal.fire({
                            icon: 'error',
                            title: 'An error occurred',
                            text: 'Please try again.',
                        });
                    });
            } else {
                hideLoader();
                Swal.fire({
                    icon: 'error',
                    title: 'Invalid Mobile Number',
                    text: 'Please Enter a Valid 10-digit Mobile Number.',
                });
            }
        }

        function verifyOtp() {
            var mobile = document.getElementById('mobile_number').value;
            var otp = document.getElementById('otp_input').value; // Updated to use the correct OTP input field
            if (otp.length === 4) {
                showLoader();
                fetch('{{ route('verifyOtpReg') }}', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': '{{ csrf_token() }}'
                            },
                            body: JSON.stringify({
                                mobile_number: mobile,
                                otp: otp
                            })
                        })
                    .then(response => {
                        const contentType = response.headers.get("content-type");
                        if (contentType && contentType.includes("application/json")) {
                            return response.json();
                        } else {
                            throw new Error('Received non-JSON response');
                        }
                    })
                    .then(data => {
                        hideLoader();
                        if (data.status === 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: 'OTP Verified',
                                text: 'Your OTP has been verified successfully!',
                            });

                            // Hide Get OTP button and Resend OTP button, show Verified button
                            document.getElementById('mobile_number').readOnly = true;
                            document.getElementById('getOtpBtn').style.display = 'none';
                            document.getElementById('resendOtpBtn').style.display = 'none'; // Hide Resend OTP button
                            document.getElementById('verifiedBtn').style.display =
                                'inline-block'; // Show Verified button

                            // Hide the OTP input section after successful verification
                            document.getElementById('otp_section').style.display = 'none';
                            isOtpVerified = true;
                            checkFormSubmission();
                        } else {
                            hideLoader();
                            Swal.fire({
                                icon: 'error',
                                title: 'Invalid OTP',
                                text: 'The OTP you entered is incorrect. Please try again.',
                            });
                        }
                    })
                    .catch(error => {
                        hideLoader();
                        console.error('Error:', error);
                        Swal.fire({
                            icon: 'error',
                            title: 'An error occurred',
                            text: 'Unable to verify the OTP. Please try again.',
                        });
                    });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Invalid OTP',
                    text: 'Please enter a valid 4-digit OTP.',
                });
            }
        }


        $(".btn-email").click(function(e) {
            e.preventDefault();
            var user_email = $('#contact_person_email').val();

            if (IsEmail(user_email) == false) {
                $(".overlay").hide();
                Swal.fire({
                    text: "Invalid email",
                    icon: 'error',
                    confirmButtonText: 'OK'
                });
                return false;
            }
            if (user_email != "") {
                $(".overlay").show();
                showLoader();
                $.ajax({
                    type: 'POST',
                    url: "{{ route('email_mobile_OTP_reg') }}",
                    data: {
                        'user_email': user_email
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    beforeSend: function() {
                        $(".overlay").css({
                            display: 'flex',
                            justifyContent: 'center',
                            alignItems: 'center',
                            position: 'fixed',
                            top: 0,
                            left: 0,
                            right: 0,
                            bottom: 0,
                            backgroundColor: 'rgba(0, 0, 0, 0.5)',
                            zIndex: 1000
                        }).html(`
                            <div style="text-align: center;">
                                <div class="spinner-border" role="status" style="width: 3rem; height: 3rem;">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                                <div style="color: white; margin-top: 10px;">Please wait...</div>
                            </div>
                        `);
                    },
                    success: function(resp) {
                        hideLoader();
                        if (resp == 1) {
                            Swal.fire({
                                text: "Please verify the OTP sent to your Email ID",
                                icon: 'success',
                                confirmButtonText: 'OK'
                            }).then((result) => {
                                $('.otp-email').show(500);
                                $('#email_id1').val(user_email).prop('readonly', true);
                                $('.btn-email').hide(500);
                                $('.btn-mailsend').show(100);
                            });
                        } else {
                            Swal.fire({
                                title: "Error",
                                text: resp.message,
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        }
                        $(".overlay").hide();
                    },
                    error: function(xhr) {
                        hideLoader();
                        // Handle error response
                        if (xhr.responseJSON && xhr.responseJSON.message) {
                            Swal.fire({
                                title: "Error",
                                text: xhr.responseJSON.message,
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        } else {
                            Swal.fire({
                                title: "Error",
                                text: "An unexpected error occurred.",
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        }
                        $(".overlay").hide();
                    }
                });
            } else {
                Swal.fire("", "Please enter Email ID", "error");
            }
        });

        function IsEmail(email) {
            var regex =
                /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            if (!regex.test(email)) {
                return false;
            } else {
                return true;
            }
        }



        $(".verifiEmail_otp").click(function(e) {
            e.preventDefault();
            var email_otp = $('#contact_person_email').val();
            $(".overlay").show();
            if (email_otp != "") {
                showLoader();
                $.ajax({
                    type: 'POST',
                    url: "{{ route('email_mobile_OTP_check_reg') }}",
                    data: {
                        'email_otp': email_otp
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    beforeSend: function() {
                        $(".overlay").css({
                            display: 'flex',
                            justifyContent: 'center',
                            alignItems: 'center',
                            position: 'fixed',
                            top: 0,
                            left: 0,
                            right: 0,
                            bottom: 0,
                            backgroundColor: 'rgba(0, 0, 0, 0.5)',
                            zIndex: 1000
                        }).html(
                            ` <div style="text-align: center;"> <div class="spinner-border" role="status" style="width: 3rem; height: 3rem;"> <span class="visually-hidden">Loading...</span> </div> <div style="color: white; margin-top: 10px;">Please wait...</div> </div> `
                        );
                    },
                    success: function(html) {
                        hideLoader();
                        if (html == 0) {
                            Swal.fire("", "Please enter Valid OTP", "error");
                        } else {
                            $('#email_otp').prop('readonly', true);
                            $('.otp-email1').hide(500);
                            $('.btn-email').hide(500);
                            $('.btn-verify').show(500);
                            $('.visitorCat').hide(500);
                            $('.visitorCat1').hide(500);
                            $('.user_detail_page').show(500);
                            $('#email_id').prop('readonly', true);
                            $('.btn-mailsend').hide();
                            $('.login-pass').hide();
                        }
                        $(".overlay").hide();
                    },
                    error: function(html) {
                        hideLoader();
                        $(".overlay").hide();

                    }
                });
            } else {
                Swal.fire("", "Please enter OTP", "error");
            }
        });

        $(".resendEmail_otp").click(function(e) {
            e.preventDefault();
            var user_email = $('#email_id1').val();
            showLoader();
            $.ajax({
                type: 'POST',
                url: "{{ route('email_mobile_OTP_reg') }}",
                data: {
                    'user_email': user_email
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                beforeSend: function() {
                    $(".overlay").css({
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        position: 'fixed',
                        top: 0,
                        left: 0,
                        right: 0,
                        bottom: 0,
                        backgroundColor: 'rgba(0, 0, 0, 0.5)',
                        zIndex: 1000
                    }).html(
                        ` <div style="text-align: center;"> <div class="spinner-border" role="status" style="width: 3rem; height: 3rem;"> <span class="visually-hidden">Loading...</span> </div> <div style="color: white; margin-top: 10px;">Please wait...</div> </div> `
                    );
                },
                success: function(html) {
                    hideLoader();
                    Swal.fire("", "Re OTP Send!!", "success");
                }
            });
        });

        // end-----


        $(document).ready(function() {

            $('#stateID').on('change', function() {
                var state_id = $(this).val();

                $.ajax({
                    url: "{{ route('getStateIDDistrict') }}",
                    type: 'POST',
                    data: {
                        _token: $('meta[name="csrf-token"]').attr('content'),
                        state_id: state_id
                    },
                    success: function(response) {

                        $('#district').html(response);
                    },
                    error: function(xhr) {
                        $('#district').text('An error occurred: ' + xhr.status);
                    }
                });
            });
        });


        $(document).ready(function() {

            $('#district').on('change', function() {
                var district_id = $(this).val();

                $.ajax({
                    url: "{{ route('getDistBlockTehsil') }}",
                    type: 'POST',
                    data: {
                        _token: $('meta[name="csrf-token"]').attr('content'),
                        district_id: district_id
                    },
                    success: function(response) {

                        $('#block_tehsil').html(response);
                    },
                    error: function(xhr) {
                        $('#block_tehsil').text('An error occurred: ' + xhr.status);
                    }
                });
            });
        });




        $(document).ready(function() {

            $('#block_tehsil').on('change', function() {
                var block_tehsil_id = $(this).val();

                $.ajax({
                    url: "{{ route('getBlockTehsilVillage') }}",
                    type: 'POST',
                    data: {
                        _token: $('meta[name="csrf-token"]').attr('content'),
                        block_tehsil_id: block_tehsil_id
                    },
                    success: function(response) {

                        $('#village').html(response);
                    },
                    error: function(xhr) {
                        $('#village').text('An error occurred: ' + xhr.status);
                    }
                });
            });
        });




        // document.getElementById('commonform1').addEventListener('submit', function(event) {

        //     var aadhar_number = $('#contact_person_aadhar_number').val();
        //     if (aadhar_number == null || aadhar_number == '') {
        //         var encoded_aadhar = '';
        //         $('#contact_person_aadhar_number').val(encoded_aadhar);
        //     } else {
        //         var encoded_aadhar = encodeURIComponent(window.btoa(aadhar_number));
        //         $('#contact_person_aadhar_number').val(encoded_aadhar);
        //     }

        // });


        document.getElementById('commonform1').addEventListener('submit', function(event) {
            var aadhar_number = $('#contact_person_aadhar_number').val();

            if (aadhar_number == null || aadhar_number.trim() === '') {
                event.preventDefault();
                $('#contact_person_aadhar_number').val('');
                Swal.fire({
                    title: "Error",
                    text: "Aadhar Number is required.",
                    icon: "warning",
                    confirmButtonText: "OK"
                });
            } else if (!/^\d{12}$/.test(aadhar_number)) {
                event.preventDefault();
                $('#contact_person_aadhar_number').val('');
                Swal.fire({
                    title: "Invalid Aadhaar Number",
                    text: "Please enter a valid Aadhar Number (12 digits only).",
                    icon: "error",
                    confirmButtonText: "OK"
                });
            } else {
                // Encode Aadhaar and allow submission
                var encoded_aadhar = encodeURIComponent(window.btoa(aadhar_number));
                $('#contact_person_aadhar_number').val(encoded_aadhar);
            }
        });


        setTimeout(function() {
            var flashMessage = document.getElementById('flash-message');
            flashMessage.style.display = 'none';
            flashMessage.remove();
        }, 45000);


        function getCBID(cb_id) {
            $('#whole_page_loader').show();
            $.ajax({
                url:"{{route('getCBIDOperator')}}",
                type: 'POST',
                data: {
                    _token: $('meta[name="csrf-token"]').attr('content'),
                    cb_id: cb_id
                },
                success: function(res) {
                    // $('#operator_type_id').hide();
                    $('#operator_type_id').html(res);

            $.ajax({
                url: "{{ route('getCBID') }}",
                type: 'POST',
                data: {
                    _token: $('meta[name="csrf-token"]').attr('content'),
                    cb_id: cb_id
                },
                success: function(response) {
                    $('#whole_page_loader').hide();
                    $('#stateID').html(response);
                },
                error: function(xhr) {
                    $('#village').text('An error occurred: ' + xhr.status);
                }
            });
        },
        error: function(xhr) {
                    $('#village').text('An error occurred: ' + xhr.status);
                }
    });

        }

        function getDetailsPanOP(Pan_id) {

            $.ajax({
                type: 'POST',
                url: "{{ route('OrganicOperatorgetDetailsPan') }}",
                data: {
                    'PanID': Pan_id
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                beforeSend: function() {
                    $(".overlay").css({
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        position: 'fixed',
                        top: 0,
                        left: 0,
                        right: 0,
                        bottom: 0,
                        backgroundColor: 'rgba(0, 0, 0, 0.5)',
                        zIndex: 1000
                    }).html(`
                <div style="text-align: center;">
                    <div class="spinner-border" role="status" style="width: 3rem; height: 3rem;">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <div style="color: white; margin-top: 10px;">Please wait...</div>
                </div>
            `);
                },
                success: function(resp) {
                    if (resp.status == true) {
                        $('#error').html(resp.message);
                    } else {
                        $('#error').html('');
                    }
                    $(".overlay").hide();
                },
                error: function(xhr) {
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        $('#error').html('');
                        Swal.fire({
                            title: "Error",
                            text: xhr.responseJSON.message,
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    } else {
                        $('#error').html('');
                        Swal.fire({
                            title: "Error",
                            text: "An unexpected error occurred.",
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    }
                    $(".overlay").hide();
                    $('#error').html('');
                }
            });
        }

        $(document).ready(function() {
            $('#user_name').keyup(function() {
                var currentValue = $(this).val();
                $(this).val(currentValue.toUpperCase());
            });
            $('.keyValueChecker').on('input', function() {
                let value = $(this).val();
                value = value.replace(/[^a-zA-Z\s]/g, '');
                value = value.replace(/\s+$/, ' ');
                $(this).val(value);
            });
            $('.select-2-down').select2({
                selectOnClose: true
            });
        });


        function checkFormSubmission() {
            var isEmailVerified = document.getElementById('contact_person_email').style.display === 'inline-block';

            if (isOtpVerified && isEmailVerified) {
                document.getElementById('submitBtn').style.display = 'inline-block';
            }
        }


        document.getElementById('declaration').addEventListener('change', function() {
            var submitBtn = document.getElementById('submitBtn');

            if (!isOtpVerified) {
                Swal.fire({
                    icon: 'warning',
                    title: 'OTP Not Verified',
                    text: 'Please verify your OTP first before submitting.',
                });
                this.checked = false;
                submitBtn.style.display = 'none';
            } else if (this.checked && isOtpVerified) {
                submitBtn.style.display =
                    'inline-block';
            } else {
                submitBtn.style.display = 'none';
            }
        });
    </script>

</body>

</html>
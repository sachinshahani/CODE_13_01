@extends('admin.layouts.app') @section('content')

<style>
        .wrapper{
        max-width: 1240px; margin:0 auto;
    }
    .white-bg{
        background-color: white;
        /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
        border-bottom:5px solid #ff9800;
        margin-bottom:15px;
    }
    .auth-one-bg .slide .carousel-indicators {
        bottom: 25px;
    }
    .auth-page-wrapper .auth-page-content{
        padding-bottom: 0px !important;
    }
    .auth-page-content  .card {
         margin-bottom: 0rem;
    }
    .data-tabs .wrapper .nav-tabs button {
        font-size: 17px;
        color: black;
    }
    .data-tabs .wrapper .nav-tabs .active{
        background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f); */
        color: white;
        background: orange;
        border-radius: 0px;
    }
    .carousel-caption.d-none.d-md-block {
        background-color: #000000bf;
        left: 0;
        width: 100%;
        bottom: 0;
    }
    .carousel-indicators {
        display: none;
    }
    .custom-banner-caption {
        color: white !important;
    }
    .announcement-heading{
        font-size: 1.2em;
        font-weight: 600;
    }
    .data-tabs .tab-pane ul li{
    font-size: 1em;
    padding: 5px 0;

    }
    .main-logo{
        padding: 10px;
    }
    .data-tabs .nav-item .nav-link {
        background-image:none ;
    }
    /* .right-sec{
        box-shadow: 5px 10px 18px #888888;
    } */
    .navbar-brand-box {
        background: #fff;
    }

    [data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
        color: white !important;
    }
    .header-buttons .btn-primary {
        margin-right: 10px;
        padding: 6px 15px;
        font-weight: 600;
        background-color: #207005;
        border: none;
        box-shadow: 0px 2px 7px #888888;
    }
    .header-buttons .btn-secondary {
        margin-right: 10px;
        padding: 6px 15px;
        font-weight: 600;
        background-color: #72a055;
        border: none;
        box-shadow: 0px 2px 7px #888888;
    }


    .right-sec { border-left: 5px solid #ede7e7; }
    .tabdiv { background: white;  padding: 20px;  margin-top: 10px;  border: 10px solid #dfdbd5; }

    .nav-tabs {border-bottom:0px; }
    div#myTabContent { border: 1px solid #cccccc;}
    .frontfooter footer { padding: 20px calc(1.5rem / 2); position: static; color: #000; height: 60px; background-color: #f9f9f9;
        margin-top: 30px; border-top: 1px solid #e1dfdf; }
    span.logo-sm img { width: 69px;}

    .seperatesec{margin-top:20px;}
    .simplebar-content li.nav-item:hover {  background: #4caf50;}
    .sectitle{font-size: 14px;}
    .required { color: red; }
    .customtextarea{height: 120px;}

    ul.boxsection { margin: 0; padding: 0;}
    ul.boxsection li { list-style-type: none; padding: 7px 0; border-bottom: 1px solid #efeded;}
    .boxcard .col:nth-child(1) { background: #effcfb;}
    .boxcard .col:nth-child(2) { background: #fdfdfd;}
    .boxcard .col:nth-child(3) { background: #effcfb;}
    .boxcard .col:nth-child(4) { background: #fdfdfd;}
    .boxcard .col:nth-child(5) { background: #effcfb;}

    /* --registration-form css  */
    .custom-tab-content {
        padding-top: 0 !important;
        padding-bottom: 0px !important;
    }
    .custom-tab-nav {
        background: white;

    }
    .custom-tab-nav .nav-link {
        border-radius: 0 !important;
        border-bottom: 1px solid #e9ebec;
        border-right: 1px solid #e9ebec;
        font-size: 14px;
        padding: 10px;
    }
    .custom-tab-nav .nav-link.active, .custom-tab-nav .show>.nav-link{
        color: rgb(255, 255, 255) !important;
        background-color: #2c8c6d;
        border-bottom: #2c8c6d !important;
        /* border-bottom: #207005 !important; */
        position:relative;
    }
    .custom-tab-nav .nav-link:hover, .custom-tab-nav .nav-link:focus {
        border-bottom: 1px solid #207005;
        border-radius: 0;
        font-size: 14px;
        transition: background-color 0.20s linear;
    }
    .custom-tab-nav .nav-link.active:after {
        content: "";
        position: absolute;
        bottom: -16px;
        left: 50%;
        border: 8px solid transparent;
        border-top-color: #2c8c6d;
        z-index: 999;
    }
    .reg-form-btns {
        margin-bottom: 15px;
    }
    .reg-form-btns .btn-secondary {
        color: #fff;
        background-color: #405189;
        border-color: #405189;
    }
    .btn-soft-success:active, .btn-soft-success:focus, .btn-soft-success:hover{
        border: none;
    }
    .custom-tab-nav ul{padding:0px; margin:0px;}
    .custom-tab-nav ul li{padding:0px; margin:0px; display: inline-block; list-style: none;}
</style>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Traders Profile</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Traders Profile</li>
                </ol>
            </div>
        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <form method="post" enctype="multipart/form-data" id="registration" action="{{route('superadmin.tradersUseredit.step2save',$userdetails->id)}}">
            @csrf
            <nav>
                        <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                            <a class="nav-link" id="step1-tab" data-bs-toggle="tab_"
                                href="{{route('superadmin.tradersUseredit',$userdetails->id)}}">General Information</a>

                            <a class="nav-link" id="step3-tab" data-bs-toggle="tab_"
                                href="{{route('superadmin.tradersUseredit.step1',$userdetails->id)}}">Geo Tagging of Warehouse / FSSAI Details </a>
                            <a class="nav-link active" id="step4-tab" data-bs-toggle="tab_"
                                href="{{route('superadmin.tradersUseredit.step2',$userdetails->id)}}">Products Details</a>
							<a class="nav-link" id="step4-tab" data-bs-toggle="tab_"
                                href="{{route('superadmin.tradersUseredit.step3',$userdetails->id)}}">List of Documents</a>
                        </div>
                    </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1">
                            उत्पादों का विवरण/Details of Products
                            </h4>
							<div class="flex-shrink-0">
                                @if (session('error'))
                                <div class="alert alert-danger">
                                    {{ session('error') }}
                                </div>
                                @endif
                                @if (session('success'))
                                <div class="alert alert-success">
                                    {{ session('success') }}
                                </div>
                                @endif
                                @if($errors)
                                @foreach ($errors->all() as $error)
                                <div class="alert alert-danger">{{ $error }}</div>
                                @endforeach
                                @endif
                            </div>
                        </div>
                        <!-- end card header -->
                        <div class="card-body">
                            <div class="live-preview ">
                                @php $i=0; @endphp
								@forelse($traders_product_details as $traders_product_detail)
									<div class="row after-add-more p-3 mb-1 {{(($i+1)%2 ==0 ? 'bg-soft-secondary':'bg-soft-success' )}}" id="row{{ $traders_product_detail->id }}">
									<input type="hidden" class="form-control" value="{{ $traders_product_detail->id }}" name="row_id[]"/>
                                    <div class="col-xxl-3 col-md-3 gy-3">
										<div>
											<label class="form-label">गोदाम इकाई आईडी/Warehouse Unit ID<span class="required"> *</span></label>
											<input type="text" class="form-control" value="{{ ($traders_product_detail->warehouse_unit_id) ?? ''}}" id="warehouse_unit_id" name="warehouse_unit_id[]" placeholder="Warehouse Unit ID" required>
										</div>
									</div>

                                    @php
                                        $productID = getProductBYCBName($cbID->id);
                                        $refProductIDs = $productID->pluck('ref_product_id')->toArray();
                                    @endphp

                                    <div class="col-xxl-3 col-md-3 gy-3">
										<div>
											<label class="form-label">उत्पाद का एचएस कोड/HS Code of the Product<span class="required"> *</span></label>
                                            <select class="form-select hscode js-example-basic-single" name="ref_hscode_id[]" onchange="getHscodeProduct(this)" required>
                                                <option value="">--Select--</option>
                                                @forelse(getRefProduct() as $hscode)
                                                @if(in_array($hscode->id, $refProductIDs)) 
                                                @continue
                                                @endif
                                                <option value="{{ $hscode->id }}" data-name="{{ $hscode->product_name }}" data-des="{{ $hscode->hscode_description }}"
                                                    {{ $traders_product_detail->ref_hscode_id == $hscode->id ? 'selected' : '' }}>
                                                    {{ $hscode->hs_code }} - {{ $hscode->product_name }}</option>
                                                @empty
                                                @endforelse
                                            </select>
										</div>
									</div>
                                    <div class="col-xxl-3 col-md-3 gy-3">
										<div>
											<label class="form-label">उत्पाद का व्यापार नाम/Trade Name of the Product <span class="required"> *</span></label>
                                            {{-- <select class="form-select product_type" name="ref_product_id[]" required>
                                                <option value="">Select Product</option>
                                                @forelse(getRefProduct() as $product)
                                                <option value="{{ $product->id }}"  {{ $traders_product_detail->ref_product_id == $product->id ? 'selected' : '' }}>{{ $product->product_name }}</option>
                                                @empty
                                                @endforelse

                                            </select> --}}
                                            <input type="hidden" name="ref_product_id[]" value="{{ $traders_product_detail->ref_product_id??'' }}">
                                            <input type="text" class="form-control" id="" placeholder="Product Name"
                                            name="product_trader_name[]" value="{{ getRefProductById($traders_product_detail->ref_product_id)->product_name ??''}}">
										</div>
									</div>
									<div class="col-xxl-3 col-md-3 gy-3">
										<div>
											<label class="form-label">उत्पाद विवरण/Product Description<span class="required"> *</span></label>
											<input type="text" class="form-control" value="{{ ($traders_product_detail->product_description) ?? ''}}" id="product_description" placeholder="Product Description" name="product_description[]" required>
										</div>
									</div>
									{{-- <div class="col-xxl-3 col-md-3 gy-3">
										<div>
											<label class="form-label">Name of Trader<span class="required"> </span></label>
											<input type="text" class="form-control" value="" id="product_trader_name_" placeholder="Name of Trader" name="product_trader_name_[]" >
										</div>
									</div> --}}

									<div class="col-xxl-3 col-md-3 gy-3">
										<div>
											<label class="form-label">जैविक स्थिति/Organic Status <span class="required"> *</span></label>
											{{-- <input type="text" class="form-control" value="{{ ($traders_product_detail->organic_status) ?? ''}}" id="organic_status" placeholder="Organic Status" name="organic_status[]" required> --}}
                                            <select class="form-select" name="organic_status[]" required>
                                                <option value="">Select Product</option>
                                                @forelse(getRefOrganicStatusMaster() as $val)
                                                <option value="{{ $val->id }}"  {{ $traders_product_detail->organic_status == $val->id ? 'selected' : '' }}>{{ $val->organic_status}}</option>
                                                @empty
                                                @endforelse
                                            </select>
										</div>
									</div>
									{{-- <div class="col-xxl-3 col-md-3 gy-3">
										<div>
											<label class="form-label">Photo of the Product<span class="required"> </span></label>
											<input type="file" class="form-control" id="product_image" name="product_image[]">
											@if(!empty($traders_product_detail->product_image))
												<input type="hidden" name="product_image_edit[]" value="{{ ($traders_product_detail->product_image) ?? ''}}">
												<a target="_BLANK" href="{{asset('public/traders/product_photo/'.$traders_product_detail->product_image)}}" class="text-decoration-underline">See Doc</a>
											@endif
										</div>
									</div> --}}

									<div class="mt-2 text-sm-end">
										<div class="form-group change">
										<label for="">&nbsp;</label><br />
										<a class="btn btn-danger"  href="javascript:void(0);" onclick="confirmDelete('')" alt="Remove"><i class="ri-delete-bin-line"></i></a>
									</div>
									</div>
                                </div>
							    <hr>
                                @php $i++; @endphp
								@empty
								<div class="after-add-more seperatesec white-inner">

                                 <div class="row">
                                 <input type="hidden" class="form-control" value="" name="row_id[]"/>
                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">गोदाम इकाई आईडी/Warehouse Unit ID<span class="required"> *</span></label>
                                            <input type="text" class="form-control" id="warehouse_unit_id" name="warehouse_unit_id[]" placeholder="Warehouse Unit ID" required>
                                        </div>
                                    </div>

                                    @php
                                        $productID = getProductBYCBName($cbID->id);
                                        $refProductIDs = $productID->pluck('ref_product_id')->toArray();
                                    @endphp

                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">उत्पाद का एचएस कोड/HS Code of the Product<span class="required"> *</span></label>

                                            <select class="form-select hscode js-example-basic-single" name="ref_hscode_id[]" onchange="getHscodeProduct(this)" required>
                                                <option value="">--Select--</option>
                                                @forelse(getRefProduct() as $hscode)
                                                @if(in_array($hscode->id, $refProductIDs)) 
                                                @continue
                                                @endif
                                                <option value="{{ $hscode->id }}">
                                                {{ $hscode->hs_code }} - {{ $hscode->product_name }}</option>
                                                @empty
                                                @endforelse
                                            </select>
                                        </div>
                                    </div>






                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">उत्पाद का व्यापार नाम/Trade Name of the Product <span class="required"> *</span></label>

                                            {{-- <select class="form-select product_type" name="ref_product_id[]" required>
                                                <option value="">Select Product</option>
                                                @forelse(getRefProduct() as $product)
                                                <option value="{{ $product->id }}">{{ $product->product_name ?? '' }}</option>
                                                @empty
                                                @endforelse

                                            </select> --}}
                                            <input type="hidden" name="ref_product_id[]" value="">
                                            <input type="text" class="form-control" id="product_description" placeholder="Product Description" name="product_trader_name[]">

                                        </div>
                                    </div>
                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">उत्पाद विवरण/Product Description<span class="required"> *</span></label>
                                            <input type="text" class="form-control" id="product_description" placeholder="Product Description" name="product_description[]" required>
                                        </div>
                                    </div>
                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">व्यापारी का नाम/Name of Trader<span class="required"></span></label>
                                            <input type="text" class="form-control" id="product_trader_name" placeholder="Name of Trader" name="product_trader_name_[]">
                                        </div>
                                    </div>

                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">जैविक स्थिति/Organic Status <span class="required"> *</span></label>

                                            <select class="form-select" name="organic_status[]" required>
                                                <option value="">Select Product</option>
                                                @forelse(getRefOrganicStatusMaster() as $val)
                                                <option value="{{ $val->id }}">{{ $val->organic_status}}</option>
                                                @empty
                                                @endforelse
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">उत्पाद का फोटो/Photo of the Product<span class="required"> </span></label>
                                            <input type="file" class="form-control upload_document1" id="product_image" name="product_image[]">
                                            <p>Supported formats:jpg, jpeg. Upto 1MB</p>
                                        </div>
                                    </div>

                                    <div class="mt-2 text-sm-end">
                                        <div class="form-group change">

                                        </div>
                                    </div>



                                </div>
                             </div>

								@endforelse

                                <div class="mt-2 text-sm-end">
                                        <div class="form-group change">
                                            <label for="">&nbsp;</label><br />
                                            <a class="btn btn-success add-more"><i class="ri-add-line"></i></a>
                                        </div>
                                    </div>



                                <!--address sec end-->

                                <div class="row">
                                    <div class="col-lg-12 gy-4">
                                        <div class="hstack gap-2">
                                            <a href="{{route('superadmin.tradersUseredit.step1',$userdetails->id)}}" class="btn btn-soft-success">
                                                Back
                                            </a>
                                            <button type="submit" class="btn btn-primary">
                                                Save
                                            </button>
											 <a href="{{route('superadmin.tradersUseredit.step3',$userdetails->id)}}" class="btn btn-soft-success">
                                                Next
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

@endsection

@push('script')

<script>
   
    $(document).ready(function () {
        $("body").on("click", ".add-more", function () {
            var html = $(".live-preview > .after-add-more").first().clone().find("input").val("").end();

            $(html).find(".change").html("<label for=''>&nbsp;</label><br/><a class='btn btn-danger remove'><i class='ri-delete-bin-line'></i></a>");
            $(".live-preview > .after-add-more").last().after(html);
        });

        $("body").on("click", ".remove", function () {
            $(this).parents(".after-add-more").remove();
        });
    });

    function getHscodeProduct(th) {
       // alert(th.value);
        //var ref_id = $(this).val();
        var name = $('option:selected',th).data("name");
        var des = $('option:selected',th).data("des");
        $(th).parent().parent().parent().find('input[name="ref_product_id[]"]').val(th.value);
        $(th).parent().parent().parent().find('input[name="product_trader_name[]"]').val(name);
        $(th).parent().parent().parent().find('input[name="product_description[]"]').val(des);


    }


    $('.upload_document1').on('change', function() {
    var $this = $(this);
    var file = $this[0].files[0];
    var fileType = file.type;
    var fileSize = file.size;
    var allowedTypes = ['image/jpeg', 'image/jpg'];

    // Check for file type
    if (!allowedTypes.includes(fileType)) {
        Swal.fire({
            icon: 'error',
            title: 'Invalid File Extension',
            text: 'Please upload JPEG, JPG only.',
        });
        $this.val("");
        return false;
    }

    // Check for file size (1 MB = 1,048,576 bytes)
    if (fileSize > 1048576) {
        Swal.fire({
            icon: 'error',
            title: 'File Size Too Large',
            text: 'Please upload files of size 1 MB or less only.',
        });
        $this.val("");
        return false;
    }
});


$(document).ready(function() {
    $('.js-example-basic-single').select2();
});

</script>

@endpush

@extends('admin.layouts.app')
@section('content')



<style>
.wrapper {
    max-width: 1240px;
    margin: 0 auto;
}

.white-bg {
    background-color: white;
    /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
    border-bottom: 5px solid #ff9800;
    margin-bottom: 15px;
}

.auth-one-bg .slide .carousel-indicators {
    bottom: 25px;
}

.auth-page-wrapper .auth-page-content {
    padding-bottom: 0px !important;
}

.auth-page-content .card {
    margin-bottom: 0rem;
}

.data-tabs .wrapper .nav-tabs button {
    font-size: 17px;
    color: black;
}

.data-tabs .wrapper .nav-tabs .active {
    background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
    */ color: white;
    background: orange;
    border-radius: 0px;
}

.carousel-caption.d-none.d-md-block {
    background-color: #000000bf;
    left: 0;
    width: 100%;
    bottom: 0;
}

.carousel-indicators {
    display: none;
}

.custom-banner-caption {
    color: white !important;
}

.announcement-heading {
    font-size: 1.2em;
    font-weight: 600;
}

.data-tabs .tab-pane ul li {
    font-size: 1em;
    padding: 5px 0;

}

.main-logo {
    padding: 10px;
}

.data-tabs .nav-item .nav-link {
    background-image: none;
}

/* .right-sec{
    box-shadow: 5px 10px 18px #888888;
} */
.navbar-brand-box {
    background: #fff;
}

[data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
    color: white !important;
}

.header-buttons .btn-primary {
    margin-right: 10px;
    padding: 6px 15px;
    font-weight: 600;
    background-color: #207005;
    border: none;
    box-shadow: 0px 2px 7px #888888;
}

.header-buttons .btn-secondary {
    margin-right: 10px;
    padding: 6px 15px;
    font-weight: 600;
    background-color: #72a055;
    border: none;
    box-shadow: 0px 2px 7px #888888;
}


.right-sec {
    border-left: 5px solid #ede7e7;
}

.tabdiv {
    background: white;
    padding: 20px;
    margin-top: 10px;
    border: 10px solid #dfdbd5;
}

.nav-tabs {
    border-bottom: 0px;
}

div#myTabContent {
    border: 1px solid #cccccc;
}

.frontfooter footer {
    padding: 20px calc(1.5rem / 2);
    position: static;
    color: #000;
    height: 60px;
    background-color: #f9f9f9;
    margin-top: 30px;
    border-top: 1px solid #e1dfdf;
}

span.logo-sm img {
    width: 69px;
}

.seperatesec {
    margin-top: 20px;
}

.simplebar-content li.nav-item:hover {
    background: #4caf50;
}

.sectitle {
    font-size: 14px;
}

.required {
    color: red;
}

.customtextarea {
    height: 120px;
}

ul.boxsection {
    margin: 0;
    padding: 0;
}

ul.boxsection li {
    list-style-type: none;
    padding: 7px 0;
    border-bottom: 1px solid #efeded;
}

.boxcard .col:nth-child(1) {
    background: #effcfb;
}

.boxcard .col:nth-child(2) {
    background: #fdfdfd;
}

.boxcard .col:nth-child(3) {
    background: #effcfb;
}

.boxcard .col:nth-child(4) {
    background: #fdfdfd;
}

.boxcard .col:nth-child(5) {
    background: #effcfb;
}

/* --registration-form css  */
.custom-tab-content {
    padding-top: 0 !important;
    padding-bottom: 0px !important;
}

.custom-tab-nav {
    background: white;

}

.custom-tab-nav .nav-link {
    border-radius: 0 !important;
    border-bottom: 1px solid #e9ebec;
    border-right: 1px solid #e9ebec;
    font-size: 14px;
    padding: 10px;
}

.custom-tab-nav .nav-link.active,
.custom-tab-nav .show>.nav-link {
    color: rgb(255, 255, 255) !important;
    background-color: #2c8c6d;
    border-bottom: #2c8c6d !important;
    /* border-bottom: #207005 !important; */
    position: relative;
}

.custom-tab-nav .nav-link:hover,
.custom-tab-nav .nav-link:focus {
    border-bottom: 1px solid #207005;
    border-radius: 0;
    font-size: 14px;
    transition: background-color 0.20s linear;
}

.custom-tab-nav .nav-link.active:after {
    content: "";
    position: absolute;
    bottom: -16px;
    left: 50%;
    border: 8px solid transparent;
    border-top-color: #2c8c6d;
    z-index: 999;
}

.reg-form-btns {
    margin-bottom: 15px;
}

.reg-form-btns .btn-secondary {
    color: #fff;
    background-color: #405189;
    border-color: #405189;
}

.btn-soft-success:active,
.btn-soft-success:focus,
.btn-soft-success:hover {
    border: none;
}

.custom-tab-nav ul {
    padding: 0px;
    margin: 0px;
}

.custom-tab-nav ul li {
    padding: 0px;
    margin: 0px;
    display: inline-block;
    list-style: none;
}
</style>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Traders Profile</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Traders Profile</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <form method="post" enctype="multipart/form-data" id="registration"
            action="{{route('superadmin.tradersUseredit.finalSave',$userdetails->id)}}">
            @csrf
            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                    <a class="nav-link" id="step1-tab" data-bs-toggle="tab_"
                        href="{{route('superadmin.tradersUseredit',$userdetails->id)}}">General Information</a>

                    <a class="nav-link" id="step3-tab" data-bs-toggle="tab_"
                        href="{{route('superadmin.tradersUseredit.step1',$userdetails->id)}}">Geo Tagging of Warehouse / FSSAI
                        Details</a>
                    <a class="nav-link" id="step4-tab" data-bs-toggle="tab_"
                        href="{{route('superadmin.tradersUseredit.step2',$userdetails->id)}}">Products Details</a>
                    <a class="nav-link active" id="step4-tab" data-bs-toggle="tab_"
                        href="{{route('superadmin.tradersUseredit.step3',$userdetails->id)}}">List of Documents</a>
                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1">
                                दस्तावेज़ों की सूची/List of Documents
                            </h4>

                        </div>
                        <div class="flex-shrink-0">
                            @if (session('error'))
                            <div class="alert alert-danger">
                                {{ session('error') }}
                            </div>
                            @endif
                            @if (session('success'))
                            <div class="alert alert-success">
                                {{ session('success') }}
                            </div>
                            @endif
                            @if($errors)
                            @foreach ($errors->all() as $error)
                            <div class="alert alert-danger">{{ $error }}</div>
                            @endforeach
                            @endif
                        </div>
                        <!-- end card header -->
                        <div class="card-body">
                            <div class="live-preview">

                                <div class="row white-inner">
                                    @if(!empty($traders_document))
                                    <input type="hidden" class="form-control" value="{{ $traders_document->id }}"
                                        name="row_id" />
                                    @endif
                                     <div class="col-xxl-3 col-md-6 gy-3">
                                        <div>
                                            <label class="form-label">अतिरिक्त दस्तावेज़ अपलोड करें/Upload Additional Document</label>
                                            <input type="file" class="form-control upload_document" id="aadhar_card_image_path"
                                                name="aadhar_card_image_path"
                                                {{ $traders_document->aadhar_card_image_path  ?? '' }}>
                                               
                                            @if(!empty($traders_document->aadhar_card_image_path))
                                            <input type="hidden" name="aadhar_card_image_path_edit"
                                                value="{{ ($traders_document->aadhar_card_image_path) ?? ''}}">
                                            <a target="_BLANK"
                                                href="{{asset('public/traders/documents/aadhar_card/'.$traders_document->aadhar_card_image_path)}}"
                                                class="text-decoration-underline">See Doc</a>
                                            @endif
                                            <p>Supported formats: PDF Upto 1MB</p>       
                                        </div>
                                    </div>
                                    {{-- <div class="col-xxl-3 col-md-6 gy-3">
                                        <div>
                                            <label class="form-label">PAN Card<span class="required">* </span></label>
                                            <input type="file" class="form-control" name="pan_card_image_path"
                                                id="pan_card_image_path"
                                                {{ $traders_document->pan_card_image_path??'required' }}>
                                            @if(!empty($traders_document->pan_card_image_path))
                                            <input type="hidden" name="pan_card_image_path_edit"
                                                value="{{ ($traders_document->pan_card_image_path) ?? ''}}">
                                            <a target="_BLANK"
                                                href="{{asset('public/traders/documents/pan_card/'.$traders_document->pan_card_image_path)}}"
                                                class="text-decoration-underline">See Doc</a>
                                            @endif
                                        </div>
                                    </div> --}}
                                    <!-- <div class="col-xxl-3 col-md-6 gy-3">
												<div>
													<label class="form-label">Bank Copy/Passbook<span class="required">* </span></label>
													<input type="file" class="form-control" name="passbook_image_path" id="passbook_image_path" {{ $traders_document->passbook_image_path??'required' }}>
													@if(!empty($traders_document->passbook_image_path))
														<input type="hidden" name="passbook_image_path_edit" value="{{ ($traders_document->passbook_image_path) ?? ''}}">
														<a target="_BLANK" href="{{asset('public/traders/documents/bank_copy_passbook/'.$traders_document->passbook_image_path)}}" class="text-decoration-underline">See Doc</a>
													@endif
												</div>
											</div> -->
                                    <!-- <div class="col-xxl-3 col-md-6 gy-3">
												<div>
													<label class="form-label">Contact Person Sign/Thumb Impression<span class="required">* </span></label>
													<input type="file" class="form-control" name="contact_person_sign_image_path" id="contact_person_sign_image_path" {{ $traders_document->contact_person_sign_image_path??'required' }}>
													@if(!empty($traders_document->contact_person_sign_image_path))
														<input type="hidden" name="contact_person_sign_image_path_edit" value="{{ ($traders_document->contact_person_sign_image_path) ?? ''}}">
														<a target="_BLANK" href="{{asset('public/traders/documents/contact_person_sign_thumb_Impression/'.$traders_document->contact_person_sign_image_path)}}" class="text-decoration-underline">See Doc</a>
													@endif
												</div>
											</div> -->
                                    <!-- <div class="col-xxl-3 col-md-6 gy-3">
												<div>
													<label class="form-label">Live Signature/Thumb Impression<span class="required"> *</span></label>
													<input type="file" class="form-control" name="live_signature_image_path" id="live_signature_image_path" {{ $traders_document->live_signature_image_path??'required' }}>
													@if(!empty($traders_document->live_signature_image_path))
														<input type="hidden" name="live_signature_image_path_edit" value="{{ ($traders_document->live_signature_image_path) ?? ''}}">
														<a target="_BLANK" href="{{asset('public/traders/documents/live_signature_thumb_impression/'.$traders_document->live_signature_image_path)}}" class="text-decoration-underline">See Doc</a>
													@endif
												</div>
											</div> -->
                                    
                                </div>

                                <!--address sec end-->

                                <div class="row">
                                    <div class="col-lg-12 gy-4">
                                        <div class="hstack gap-2">
                                            <a href="{{route('superadmin.tradersUseredit.step2',$userdetails->id)}}"
                                                class="btn btn-soft-success">
                                                Back
                                            </a>
                                            <button type="submit" class="btn btn-primary">
                                                Submit
                                            </button>

                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>



@endsection
@push('script')

<script>

$(document).on('change', '.upload_document', function () {
    var $this = $(this);
    var file = $this[0].files[0];

    // Ensure a file is selected
    if (!file) {
        Swal.fire({
            icon: 'error',
            title: 'No File Selected',
            text: 'Please select a file to upload.',
        });
        return false;
    }

    var fileType = file.type;
    var fileSize = file.size;
    var allowedTypes = ['application/pdf'];

    // Check for file type
    if (!allowedTypes.includes(fileType)) {
        Swal.fire({
            icon: 'error',
            title: 'Invalid File Extension',
            text: 'Please upload a PDF file only.',
        });
        $this.val(""); // Clear the input
        return false;
    }

    // Check for file size (1 MB = 1048576 bytes)
    if (fileSize > 1048576) { // 1 MB limit
        Swal.fire({
            icon: 'error',
            title: 'File Size Too Large',
            text: 'Please upload a file of size 1 MB or less.',
        });
        $this.val(""); // Clear the input
        return false;
    }

    // If validation passes
    Swal.fire({
        icon: 'success',
        title: 'Valid File',
        text: 'File is ready for upload.',
    });
});

</script>

@endpush
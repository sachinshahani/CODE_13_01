@extends('admin.layouts.app')
@section('content')
<style>
    body {
        margin: 0px;
        padding: 0px;
        font-family: "Segoe UI";
    }

    .maindiv {
        width: 80%;
        margin: 0 auto;
    }

    .pdf_maindiv {
        border: 1px solid #cccccc;
        width: 100%;
        float: left;
        padding: 3%;
    }

    .pdf_heading {
        font-size: 20px;
        color: #000;
        padding: 26px 0 12px 0px;
        position: relative;
        width: 100%;
        float: left;
    }

    .brd_heading {
        border-bottom: 2px solid #ee5e24;
        padding-bottom: 8px;
        padding-right: 8px;
        width: 60px;
    }

    .pdf_input1 {
        background: #eeeeee;
    }

    .pdf_txt1 {
        color: #000;
        font-size: 14px;
        width: 45%;
        float: left;
        padding-bottom: 10px;
        font-weight: bold;
    }

    .pdf_box {
        color: #000;
        font-size: 14px;
        width: 55%;
        float: left;
        padding-bottom: 10px;
    }

    .table_pdf {
        width: 100%;
    }


    @media print {
        /*
                           .pdf_heading {
                            font-size: 20px;
                            color: #000;
                            padding: 26px 0 12px 0px;
                            position: relative;
                            width: 100%;
                            float: left;
                            -webkit-print-color-adjust: exact !important;
                            Chrome,
                            Safari color-adjust: exact !important;
                           } */

        /* .pdf_heading:before{content: ""; position: absolute; width:20px; height: 4px; background-color:#ee5e24; bottom:10px; display: block;-webkit-print-color-adjust: exact !important;    Chrome, Safari
                            color-adjust: exact !important;  } */


    }
</style>
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Traders Profile</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Traders Profile</li>
                </ol>
            </div>

        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">

        <div class="tab-content py-4 custom-tab-content">
            <div class="tab-pane fade show active" id="step1">
                <div class="card">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1">
                            {{ user_name($user->id) ?? '' }}
                        </h4>

                        <div class="flex-shrink-0  {{ $user->status == 2 || $user->status == 4 ? 'flex-grow-1' : '' }}">
                            <label for="basiInput"
                                class="form-label">{{ $user->status == 2 ? 'Registration Number : ' . $user->registration_no : 'Application Number : #00' . $user->id }}</label>
                        </div>
                        @if ($user->status == 2)
                        <div class="flex-shrink-0 flex-grow-1">
                            <label for="basiInput" class="form-label">Registration Certificate : <a target="_BLANK"
                                    href="{{ asset('public/' . $user->registration_certificate) }}"
                                    class="text-decoration-underline"><img
                                        src="{{ asset('public/assets/images/pdf-icon.png') }}" alt=""
                                        class="pdf-img-icon" height="17px">See Doc</a></label>
                        </div>
                        @if ($eMSignedModuleAlow['status'] == 'success')
                        <div class="flex-shrink-0">
                            @if ($eMSignedModuleResult['status'] == 'success')
                            @php
                            $publicPath = str_replace('var/www/html/apeda/', '', $eMSignedModuleResult['signedPath']);
                            @endphp
                            <a class="btn btn-success btn-sm" download href="{{ $hostName . $publicPath }}">Download Signed PDF</a>
                            @else
                            <button type="button" class="btn btn-primary btn-sm" id="generateDigitalSign"
                                data-filename="{{ basename($user->registration_certificate) }}"
                                data-path="/{{ basename(dirname($user->registration_certificate)) }}/"
                                data-filestored="public"
                                data-certificate="RC">
                                Digital Sign
                            </button>
                            @endif
                        </div>
                        @endif
                        @endif

                        @if ($user->status == 0 || $user->status == 3)
                        <div class="flex-shrink-0">
                            <a href="{{ route('superadmin.tradersUseredit', $user->id) }}"
                                class="btn btn-soft-success">Back</a>

                        </div>
                        @endif
                    </div>

                    <!-- end card header -->
                    <div class="card-body white-inner">

                        <div class="pdf_heading">Company/Trader Details</div>
                        <div class="pdf_maindiv">
                            <!--form1 section starts here-->
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                            <tr>
                                                <td class="pdf_txt1">Name of Trader :</td>
                                                <td class="pdf_box">{{ user_name($user->id) ?? '' }}</td>
                                            </tr>


                                            {{-- <tr>
                                                        <td class="pdf_txt1">Standerd Type</td>
                                                        <td class="pdf_box">{{ $user->standerd_type ??''}}</td>
                                            </tr>
                                            --}}

                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">

                                            <tr>
                                                <td class="pdf_txt1">Legal Document Number</td>
                                                <td class="pdf_box">{{ $user->legal_document_number ?? '' }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Photo of Trader building</td>
                                                <td class="pdf_box">
                                                    @if (!empty($user->office_building_photo))
                                                    <a target="_BLANK"
                                                        href="{{ asset('public/ics/office_building_photo/' . $user->office_building_photo) }}"
                                                        class="text-decoration-underline">See Doc</a>
                                                    @else
                                                    NOt Available
                                                    @endif
                                                </td>
                                            </tr>

                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="pdf_heading">Trader Address</div>
                        <div class="pdf_maindiv">
                            <!--form1 section starts here-->
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                            <tr>
                                                <td class="pdf_txt1">State</td>
                                                <td class="pdf_box">{{ getStateName($user->ref_state_id) }}</td>
                                            </tr>

                                            <tr>
                                                <td class="pdf_txt1">Taluka/Mandal</td>
                                                <td class="pdf_box">{{ getTalukName($user->ref_block_tehsil_id) }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Address</td>
                                                <td class="pdf_box">{{ $user->address ?? '' }}</td>
                                            </tr>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>

                                    <div class="col-6">

                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                            <tr>
                                                <td class="pdf_txt1">District</td>
                                                <td class="pdf_box">{{ getDisName($user->ref_district_id) }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Village</td>
                                                <td class="pdf_box">{{ getVillName($user->ref_village_id) }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Pin Code</td>
                                                <td class="pdf_box">{{ $user->pin ?? '' }}</td>
                                            </tr>

                                        </table>
                                        <!--form1 tab end here-->
                                    </div>


                                </div>
                            </div>
                        </div>
                        <div class="pdf_heading">Contact Person Details</div>
                        <div class="pdf_maindiv">
                            <!--form1 section starts here-->
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                            <tr>
                                                <td class="pdf_txt1">Full Name</td>
                                                <td class="pdf_box"> {{ $user->contact_person_first_name ?? '' }} {{ $user->contact_person_middle_name ?? '' }} {{ $user->contact_person_last_name ?? '' }} </td>
                                            </tr>
                                            {{-- <tr>
                                                    <td class="pdf_txt1">Last Name</td>
                                                    <td class="pdf_box"> {{ $user->contact_person_last_name ?? '' }}</td>
                                            </tr> --}}
                                            <tr>
                                                <td class="pdf_txt1">Email Id</td>
                                                <td class="pdf_box" colspan=2>{{ $user->contact_person_email ?? '' }}
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Gender</td>
                                                <td class="pdf_box">
                                                    @if ($user->contact_gender == 1)
                                                    Male
                                                    @elseif($user->contact_gender == 2)
                                                    Female
                                                    @else
                                                    other
                                                    @endif
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Address proof of Individual Producer Manager</td>
                                                <td class="pdf_box">
                                                    @if ($user->address_proof_of_office == 'electricity_bill')
                                                    Electricity Bill
                                                    @elseif($user->address_proof_of_office == 'water_bill')
                                                    Water Bill
                                                    @elseif($user->address_proof_of_office == 'rent_agreement')
                                                    Rent Agreement
                                                    @else
                                                    N/A
                                                    @endif
                                                </td>
                                            </tr>
                                            {{-- <tr>
                                                    <td class="pdf_txt1">Number of Farmers</td>
                                                    <td class="pdf_box">{{ $user->no_of_farmers ?? '' }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Managed by</td>
                                                <td class="pdf_box">{{ $user->managed_by ?? '' }}</td>
                                            </tr> --}}
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>

                                    <div class="col-6">

                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                            {{-- <tr>
                                                    <td class="pdf_txt1">Middle Name</td>
                                                    <td class="pdf_box"> {{ $user->contact_person_middle_name ?? '' }}
                                            </td>
                                            </tr> --}}
                                            <tr>
                                                <td class="pdf_txt1">Contact No.</td>
                                                <td class="pdf_box">{{ $user->contact_person_mobile_number ?? '' }}
                                                </td>
                                            </tr>
                                            <tr>
                                                @php
                                                $maskedAadhar = '';
                                                try {
                                                if ($user->contact_person_aadhar_number) {
                                                $decryptedAadhar = Crypt::decrypt(
                                                $user->contact_person_aadhar_number,
                                                );
                                                $maskedAadhar = maskAadhaarNumber($decryptedAadhar);
                                                }
                                                } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
                                                $maskedAadhar = 'Invalid Aadhaar Number';
                                                }
                                                @endphp


                                                <td class="pdf_txt1">Aadhaar No.</td>
                                                <td class="pdf_box">{{ $maskedAadhar }}
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Designation of Contact Person</td>
                                                <td class="pdf_box">{{ $user->contact_designation ?? '' }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Address Proof Doc</td>
                                                <td class="pdf_box">
                                                    @if (!empty($user->address_proof_of_office_doc))
                                                    <a target="_BLANK"
                                                        href="{{ asset('public/ics/address_proof_of_office_doc/' . $user->address_proof_of_office_doc) }}"
                                                        class="text-decoration-underline">See Doc</a>
                                                    @else
                                                    NOt Available
                                                    @endif
                                                </td>
                                            </tr>
                                            {{-- <tr>
                                                    <td class="pdf_txt1">Number of Inspector</td>
                                                    <td class="pdf_box">{{ $user->no_of_inspector ?? '' }}</td>
                                            </tr> --}}
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>


                                </div>
                            </div>
                        </div>

                        <!-- Start Form Details -->
                        <div class="pdf_heading">Trader Warehouse</div>
                        <div class="pdf_maindiv">
                            <!-- farmer-1 container start  -->
                            @forelse($traders_warehouse_details as $key => $val)
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-12">
                                        {{-- <h6 style="padding:0;padding-bottom:15px;width: 100%;text-decoration: underline;">Farmer {{ $key+1 }} --}}
                                        </caption>
                                    </div>
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;"
                                            class="table_pdf table_contact_person">

                                            <tbody>
                                                <tr>
                                                    <td class="pdf_txt1">Warehouse Unit No.</td>
                                                    <td class="pdf_box">{{ $val->warehouse_unit_id ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Warehouse Name</td>
                                                    <td class="pdf_box">{{ $val->warehouse_name ?? '' }} </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Fssai License No.</td>
                                                    <td class="pdf_box"> {{ $val->fssai_license_number }}</td>
                                                </tr>

                                                <tr>
                                                    <td class="pdf_txt1">License Document</td>
                                                    <td class="pdf_box">
                                                        @if (!empty($val->license_document))
                                                        <a target="_BLANK"
                                                            href="{{ asset('public/traders/license_document/' . $val->license_document) }}">View</a>
                                                        @endif
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">License Validity</td>
                                                    <td class="pdf_box">{{ date('d-m-Y', strtotime($val->license_validity)) ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Number of Products</td>
                                                    <td class="pdf_box"> {{ $val->number_of_products ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Additional Certificate</td>
                                                    <td class="pdf_box">
                                                        @if (!empty($val->additional_certificate))
                                                        <a target="_BLANK"
                                                            href="{{ asset('public/traders/additional_certificate/' . $val->additional_certificate) }}">View</a>
                                                        @endif
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Geo Tagging Warehouse Unit</td>
                                                    <td class="pdf_box">
                                                        {{ $val->geo_tagging_warehouse_unit ?? '' }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Image After Tagging</td>
                                                    <td class="pdf_box">
                                                        @if (!empty($val->image_after_tagging))
                                                        <a target="_BLANK"
                                                            href="{{ asset('public/traders/reflect_farm_image_after_tagging/' . $val->image_after_tagging) }}">View</a>
                                                        @endif
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Total Capacity</td>
                                                    <td class="pdf_box"> {{ $val->total_capacity ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Organic Installed Capacity</td>
                                                    <td class="pdf_box">
                                                        {{ $val->organic_installed_capacity ?? '' }}
                                                    </td>
                                                </tr>
                                                <br>
                                            </tbody>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;"
                                            class="table_pdf table_contact_person">
                                            <tbody>
                                                <br>
                                                <tr>
                                                    <td class="pdf_txt1">State</td>
                                                    <td class="pdf_box">{{ getStateName($val->ref_state_id) }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">District</td>
                                                    <td class="pdf_box"> {{ getDisName($val->ref_district_id) }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Village</td>
                                                    <td class="pdf_box">{{ getVillName($val->ref_village_id) }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Taluka/Mandal</td>
                                                    <td class="pdf_box" colspan=2>
                                                        {{ getTalukName($val->ref_block_tehsil_id) }}
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td class="pdf_txt1">Pin Code</td>
                                                    <td class="pdf_box">{{ $val->pin_code ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Address</td>
                                                    <td class="pdf_box"> {{ $val->address ?? '' }}</td>
                                                </tr>

                                                <tr>
                                                    <td class="pdf_txt1">Agreement Status</td>
                                                    <td class="pdf_box">{{ $val->agreement_status ?? '' }}</td>
                                                </tr>


                                            </tbody>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                </div>
                            </div>
                            <!-- Farmer - 1 container ended  -->

                            @empty
                            No Record found..
                            @endforelse

                        </div>
                        <!-- END PRoducer Form Details -->
                        <div class="pdf_heading">Product Details</div>
                        <div class="pdf_maindiv">

                            <!-- farmer-1 container start  -->
                            @forelse($traders_product_details as $key => $val)
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-12">
                                        {{-- <h6 style="padding:0;padding-bottom:15px;width: 100%;text-decoration: underline;">Farmer {{ $key+1 }} --}}
                                        </caption>
                                    </div>
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;"
                                            class="table_pdf table_contact_person">

                                            <tbody>
                                                <tr>
                                                    <td class="pdf_txt1">Warehouse Unit ID</td>
                                                    <td class="pdf_box">{{ $val->warehouse_unit_id ?? '' }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">HS Code of the Product </td>
                                                    <td class="pdf_box">
                                                        {{ getHscodeById($val->ref_hscode_id) ?? '' }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Name of Product</td>
                                                    <td class="pdf_box">
                                                        {{ getHscodeProductName($val->ref_product_id) ?? '' }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Product Description</td>
                                                    <td class="pdf_box"> {{ $val->product_description ?? '' }}
                                                    </td>
                                                </tr>



                                            </tbody>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;"
                                            class="table_pdf table_contact_person">
                                            <tbody>
                                                <tr>
                                                    <td class="pdf_txt1">Name of Trader</td>
                                                    <td class="pdf_box">{{ $val->product_trader_name ?? '' }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Organic Status</td>
                                                    <td class="pdf_box">
                                                        {{ getRefOrganicStatusMasterByID($val->organic_status) ?? '' }}

                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Photo of the Product</td>
                                                    <td class="pdf_box">
                                                        @if (!empty($val->product_image))
                                                        <a target="_BLANK"
                                                            href="{{ asset('public/traders/product_photo/' . $val->product_image) }}">View</a>
                                                        @endif
                                                    </td>
                                                </tr>

                                            </tbody>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <!-- Farmer - 1 container ended  -->
                            @empty
                            No Record found..
                            @endforelse
                            <!-- Docs - 2 container start  -->

                            <!-- Docs -2 container end  -->
                        </div>
                        <!-- END Product Details -->

                        <!-- <div class="pdf_heading">Document Details</div>
                        <div class="pdf_maindiv"> -->
                            <!-- farmer-1 container start  -->
                            <!-- @forelse($traders_document as $key => $val)
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-12">
                                        {{-- <h6 style="padding:0;padding-bottom:15px;width: 100%;text-decoration: underline;">Farmer {{ $key+1 }} --}}
                                        </caption>
                                    </div>
                                    <div class="col-6"> -->
                                        <!--form1 tab starts here-->
                                        <!-- <table style="padding: 10px; border: 0px;"
                                            class="table_pdf table_contact_person">

                                            <tbody>
                                                <tr>
                                                    <td class="pdf_txt1">Aadhaar</td>
                                                    <td class="pdf_box">{{ $val->aadhar_card ?? '' }} @if (!empty($val->aadhar_card_image_path))
                                                        <a target="_BLANK"
                                                            href="{{ asset('public/traders/documents/aadhar_card/' . $val->aadhar_card_image_path) }}">View</a>
                                                        @endif
                                                    </td>
                                                </tr>

                                                {{-- <tr>
                                                            <td class="pdf_txt1">Land Doc</td>
                                                            <td class="pdf_box"> {{ $val->land_documets }} @if (!empty($val->land_documents_image_path))
                                                <a target="_BLANK"
                                                    href="{{ asset('public/traders/documents/bank_copy_passbook/' . $val->passbook_image_path) }}">View</a>
                                                @endif
                                                </td>
                                                </tr> --}}



                                            </tbody>
                                        </table> -->
                                        <!--form1 tab end here-->
                                    <!-- </div> -->
                                    <!-- <div class="col-6"> -->
                                        <!--form1 tab starts here-->
                                        <!-- <table style="padding: 10px; border: 0px;"
                                            class="table_pdf table_contact_person">
                                            <tbody>

                                                <tr>
                                                    <td class="pdf_txt1">PAN </td>
                                                    <td class="pdf_box">{{ $val->pan_card ?? '' }} @if (!empty($val->pan_card_image_path))
                                                        <a target="_BLANK"
                                                            href="{{ asset('public/traders/documents/pan_card/' . $val->pan_card_image_path) }}">View</a>
                                                        @endif
                                                    </td>
                                                </tr> -->
                                                <!-- <tr>
                                                            <td class="pdf_txt1">Passbook</td>
                                                            <td class="pdf_box">{{ $val->passbook }} @if (!empty($val->passbook_image_path))
                                                                    <a target="_BLANK"
                                                                        href="{{ asset('public/traders/documents/bank_copy_passbook/' . $val->passbook_image_path) }}">View</a>
                                                                @endif
                                                            </td>
                                                        </tr> -->
                                                <!-- <tr>
                                                            <td class="pdf_txt1">Contact person sign</td>
                                                            <td class="pdf_box">{{ $val->contact_person_sign ?? '' }}
                                                                @if (!empty($val->contact_person_sign_image_path))
                                                                    <a target="_BLANK"
                                                                        href="{{ asset('public/traders/documents/contact_person_sign_thumb_Impression/' . $val->contact_person_sign_image_path) }}">View</a>
                                                                @endif
                                                            </td>
                                                        </tr> -->
                                                <!-- <tr>
                                                            <td class="pdf_txt1">Live Signature</td>
                                                            <td class="pdf_box">{{ $val->live_signature ?? '' }}
                                                                @if (!empty($val->live_signature_image_path))
                                                                    <a target="_BLANK"
                                                                        href="{{ asset('public/traders/documents/live_signature_thumb_impression/' . $val->live_signature_image_path) }}">View</a>
                                                                @endif
                                                            </td>
                                                        </tr> -->

                                            <!-- </tbody>
                                        </table> -->
                                        <!--form1 tab end here-->
                                    <!-- </div> -->
                                </div>
                            </div>
                            <!-- Farmer - 1 container ended  -->
                            @empty
                            No Record found..
                            @endforelse
                            <!-- Docs - 2 container start  -->

                            <!-- Docs -2 container end  -->
                        </div>
                        <!-- END PRoducer Documents-->
                    
                        @if (!empty(Auth::guard('misadmin')->user()->role) && Auth::guard('misadmin')->user()->role->role_id == 1)
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="tab-content py-4 custom-tab-content">
                                    <div class="tab-pane fade show active" id="step1">
                                        
                                        <div class="card">
                                            <div class="card-header align-items-center d-flex">
                                                <h4 class="card-title mb-0 flex-grow-1">
                                                    Remarks:

                                                </h4>
                                            </div>
                                            <!-- end card header -->
                                            <div class="card-body">
                                                <div class="live-preview">

                                                    {{-- <div class="col-xxl-4 col-md-4 gy-4 ">
                                                                    <div>
                                                                        <label for="basiInput"
                                                                            class="form-label">Remarks :
                                                                        </label>
                                                                        <label for="basiInput">{{ $user->cb_reg_remarks ?? '' }}
                                                    </label>

                                                </div>
                                            </div> --}}

                                            <form method="post" id="" action="{{ route('superadmin.usermanagement.deptUser.previewpost') }}">
                                                @csrf
                                                <input type="hidden" name="at_user_id" value="{{ $user->id }}">
                                                <input type="hidden" name="id" value="{{ $user->ref_operator_type_id }}">
                                                <div class="col-xxl-4 col-md-4 gy-4 ">
                                                    <div>
                                                        <label for="basiInput" class="form-label">Status<span class="required">*</span>
                                                        </label>

                                                        <select class="form-select" name="status" required>
                                                            <option value="">-Select-
                                                            </option>
                                                            <option value="2" {{  $user->status==2 ?'selected':'' }}>Approved
                                                            </option>
                                                            <option value="4" {{  $user->status==4 ?'selected':'' }}>Review</option>
                                                            <option value="3" {{  $user->status==3 ?'selected':'' }}>Rejected

                                                            </option>
                                                        </select>

                                                    </div>
                                                </div>

                                                <div class="col-xxl-6 col-md-6 gy-6 mt-3">
                                                    <div>
                                                        <label class="form-label">Submit Your
                                                            Remarks:<span class="required">
                                                                *</span></label>
                                                        <textarea placeholder="" class="form-control customtextarea" name="cb_remarks" required>{{ $user->cb_reg_remarks ?? '' }}</textarea>
                                                    </div>
                                                </div>
                                                {{-- @if ($regDetail->cb_remarks == '' && $regDetail->cb_status == '') --}}
                                                <div class="row">
                                                    <div class="col-xxl-4 col-md-4 gy-4 ">
                                                        <div class="hstack gap-2">

                                                            <button type="submit" id="submitbtn" class="btn btn-primary submit-button">Submit</button>

                                                        </div>
                                                    </div>
                                                </div>
                                                {{-- @endif --}}
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @else
                <div class="row">
                    <div class="col-lg-12 gy-4">
                        <div class="hstack gap-2">
                            <br>
                            @if ($user->status == 0 || $user->status == 3)
                            <form method="post" id=""
                                action="{{ route('superadmin.icsuser.previewpost') }}">
                                @csrf
                                <input type="hidden" name="at_user_id"
                                    value="{{ $user->id }}">
                                <button type="submit" class="btn btn-primary" id="submitbtn">
                                    Final Submit
                                </button>
                            </form>

                            @endif
                            @if ($user->status == 3)

                            <div class="col-xxl-4 col-md-4 gy-4 ">
                                <a href="{{ route('superadmin.icsuser.step1', $user->id) }}"
                                    class="btn btn-soft-success">
                                    Edit
                                </a>

                                @endif
                            </div>
                    </div>
                    @endif
                </div>
            </div>
          
            @if ($user->status == 2 || $user->status == 3)
                            <div class="col-xxl-4 col-md-4 gy-4 ">
                                <div>
                                    <label for="basiInput"
                                        class="form-label">{{ $user->status == 2 ? 'Status :' : '' }}
                                    </label>
                                    <label
                                        for="basiInput">
                                        @php
                                        if($user->status==2){
                                        echo 'Application Approved By CB';
                                        }else if($user->status==3){
                                        echo 'Application Rejected By CB';
                                        }else if($user->status==4){
                                        echo 'Review';
                                        }else{
                                        echo 'Pending';
                                        }
                                        @endphp

                                    </label>

                                </div>
                            </div>

                            <div class="col-xxl-4 col-md-4 gy-4 ">
                                <div>
                                    <label for="basiInput" class="form-label">Remarks :
                                    </label>
                                    <label for="basiInput">{{ $user->cb_reg_remarks ?? '' }}
                                    </label>

                                </div>
                            </div>
                        </div>
                        @else

                        @endif
                </div>
        </div>
    </div>
    @endsection

    @push('script')
    <script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
    <script>
        $(document).on('click', '#submitbtn', function() {

            if (checkValidation("registration")) {
                $('#registration').submit();
                return true;
            } else {
                return false;
            }
        });
    </script>
    @endpush
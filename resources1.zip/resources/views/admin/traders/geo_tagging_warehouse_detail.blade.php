@extends('admin.layouts.app')
@section('content')

<style>
    .wrapper {
        max-width: 1240px;
        margin: 0 auto;
    }

    .white-bg {
        background-color: white;
        /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
        border-bottom: 5px solid #ff9800;
        margin-bottom: 15px;
    }

    .auth-one-bg .slide .carousel-indicators {
        bottom: 25px;
    }

    .auth-page-wrapper .auth-page-content {
        padding-bottom: 0px !important;
    }

    .auth-page-content .card {
        margin-bottom: 0rem;
    }

    .data-tabs .wrapper .nav-tabs button {
        font-size: 17px;
        color: black;
    }

    .data-tabs .wrapper .nav-tabs .active {
        background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
        */ color: white;
        background: orange;
        border-radius: 0px;
    }

    .carousel-caption.d-none.d-md-block {
        background-color: #000000bf;
        left: 0;
        width: 100%;
        bottom: 0;
    }

    .carousel-indicators {
        display: none;
    }

    .custom-banner-caption {
        color: white !important;
    }

    .announcement-heading {
        font-size: 1.2em;
        font-weight: 600;
    }

    .data-tabs .tab-pane ul li {
        font-size: 1em;
        padding: 5px 0;

    }

    .main-logo {
        padding: 10px;
    }

    .data-tabs .nav-item .nav-link {
        background-image: none;
    }

    /* .right-sec{
            box-shadow: 5px 10px 18px #888888;
        } */
    .navbar-brand-box {
        background: #fff;
    }

    [data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
        color: white !important;
    }

    .header-buttons .btn-primary {
        margin-right: 10px;
        padding: 6px 15px;
        font-weight: 600;
        background-color: #207005;
        border: none;
        box-shadow: 0px 2px 7px #888888;
    }

    .header-buttons .btn-secondary {
        margin-right: 10px;
        padding: 6px 15px;
        font-weight: 600;
        background-color: #72a055;
        border: none;
        box-shadow: 0px 2px 7px #888888;
    }


    .right-sec {
        border-left: 5px solid #ede7e7;
    }

    .tabdiv {
        background: white;
        padding: 20px;
        margin-top: 10px;
        border: 10px solid #dfdbd5;
    }

    .nav-tabs {
        border-bottom: 0px;
    }

    div#myTabContent {
        border: 1px solid #cccccc;
    }

    .frontfooter footer {
        padding: 20px calc(1.5rem / 2);
        position: static;
        color: #000;
        height: 60px;
        background-color: #f9f9f9;
        margin-top: 30px;
        border-top: 1px solid #e1dfdf;
    }

    span.logo-sm img {
        width: 69px;
    }

    .seperatesec {
        margin-top: 20px;
    }

    .simplebar-content li.nav-item:hover {
        background: #4caf50;
    }

    .sectitle {
        font-size: 14px;
    }

    .required {
        color: red;
    }

    .customtextarea {
        height: 120px;
    }

    ul.boxsection {
        margin: 0;
        padding: 0;
    }

    ul.boxsection li {
        list-style-type: none;
        padding: 7px 0;
        border-bottom: 1px solid #efeded;
    }

    .boxcard .col:nth-child(1) {
        background: #effcfb;
    }

    .boxcard .col:nth-child(2) {
        background: #fdfdfd;
    }

    .boxcard .col:nth-child(3) {
        background: #effcfb;
    }

    .boxcard .col:nth-child(4) {
        background: #fdfdfd;
    }

    .boxcard .col:nth-child(5) {
        background: #effcfb;
    }

    /* --registration-form css  */
    .custom-tab-content {
        padding-top: 0 !important;
        padding-bottom: 0px !important;
    }

    .custom-tab-nav {
        background: white;

    }

    .custom-tab-nav .nav-link {
        border-radius: 0 !important;
        border-bottom: 1px solid #e9ebec;
        border-right: 1px solid #e9ebec;
        font-size: 14px;
        padding: 10px;
    }

    .custom-tab-nav .nav-link.active,
    .custom-tab-nav .show>.nav-link {
        color: rgb(255, 255, 255) !important;
        background-color: #2c8c6d;
        border-bottom: #2c8c6d !important;
        /* border-bottom: #207005 !important; */
        position: relative;
    }

    .custom-tab-nav .nav-link:hover,
    .custom-tab-nav .nav-link:focus {
        border-bottom: 1px solid #207005;
        border-radius: 0;
        font-size: 14px;
        transition: background-color 0.20s linear;
    }

    .custom-tab-nav .nav-link.active:after {
        content: "";
        position: absolute;
        bottom: -16px;
        left: 50%;
        border: 8px solid transparent;
        border-top-color: #2c8c6d;
        z-index: 999;
    }

    .reg-form-btns {
        margin-bottom: 15px;
    }

    .reg-form-btns .btn-secondary {
        color: #fff;
        background-color: #405189;
        border-color: #405189;
    }

    .btn-soft-success:active,
    .btn-soft-success:focus,
    .btn-soft-success:hover {
        border: none;
    }

    .custom-tab-nav ul {
        padding: 0px;
        margin: 0px;
    }

    .custom-tab-nav ul li {
        padding: 0px;
        margin: 0px;
        display: inline-block;
        list-style: none;
    }

    .pdf_heading {
        font-size: 20px;
        color: #000;
        padding: 26px 0 12px 0px;
        position: relative;
        width: 100%;
        float: left;
    }
</style>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">व्यापारी प्रोफ़ाइल/Traders Profile</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Traders Profile</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <form method="post" enctype="multipart/form-data" id="registration" action="{{ route('superadmin.tradersUseredit.step1save', $userdetails->id) }}">
            @csrf
            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                    <a class="nav-link" id="step1-tab" data-bs-toggle="tab_" href="{{ route('superadmin.tradersUseredit', $userdetails->id) }}">General Information</a>

                    <a class="nav-link active" id="step3-tab" data-bs-toggle="tab_" href="{{ route('superadmin.tradersUseredit.step1', $userdetails->id) }}">Geo Tagging of
                        Warehouse / FSSAI
                        Details</a>
                    <a class="nav-link" id="step4-tab" data-bs-toggle="tab_" href="{{ route('superadmin.tradersUseredit.step2', $userdetails->id) }}">Products Details</a>
                    <a class="nav-link" id="step4-tab" data-bs-toggle="tab_" href="{{ route('superadmin.tradersUseredit.step3', $userdetails->id) }}">List of Documents</a>
                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <!-- <div class="card">
                                        <div class="card-header align-items-center d-flex">
                                            <h4 class="card-title mb-0 flex-grow-1">
                                            Warehouse Unit Details
                                            </h4>
                                            
                                        </div>
                                        
                                        <div class="card-body">
                                            <div class="live-preview">
                                                <div class="row seperatesec_">
                                                     <div class="col-xxl-4 col-md-4">
                    <div>
                     <label class="form-label">Number of Warehouse Unit<span class="required"> *</span></label>
                     <input type="text" class="form-control" id="name" placeholder="Enter the Number of Warehouse Unit" name="name">
                    </div>
                   </div>
                  </diV>
                 </diV>
                </diV>
               </diV> -->

                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1">
                                वेयरहाउस इकाई की जियोटैगिंग/Geo Tagging of Warehouse Unit
                            </h4>
                            <div class="flex-shrink-0">
                                @if (session('error'))
                                <div class="alert alert-danger">
                                    {{ session('error') }}
                                </div>
                                @endif
                                @if (session('success'))
                                <div class="alert alert-success">
                                    {{ session('success') }}
                                </div>
                                @endif
                                @if ($errors)
                                @foreach ($errors->all() as $error)
                                <div class="alert alert-danger">{{ $error }}</div>
                                @endforeach
                                @endif
                            </div>
                        </div>
                        <!-- end card header -->
                        <div class="card-body">
                            <div class="live-preview">
                                @php $i=1; @endphp
                                @forelse($GeoTaggingWarehouseDetails as $GeoTagging)
                                <div class="row after-add-more p-3 mb-1 white-inner" id="row{{ $GeoTagging->id }}">
                                    <input type="hidden" class="form-control" value="{{ $GeoTagging->id }}" name="row_id[]" />

                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">वेयरहाउस इकाई आईडी/Warehouse Unit ID<span class="required">
                                                    *</span></label>
                                            <input type="text" class="form-control" value="{{ $GeoTagging->warehouse_unit_id ?? '' }}" placeholder="Warehouse Unit ID" name="warehouse_unit_id[]" required>
                                        </div>
                                    </div>

                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">गोदाम इकाइयों का नाम/Name of the Warehouse Units<span class="required"> *</span></label>
                                            <input type="text" class="form-control" value="{{ $GeoTagging->warehouse_name ?? '' }}" id="warehouse_name" placeholder="Enter the Name of the Warehouse Units " name="warehouse_name[]">
                                        </div>
                                    </div>
                                    <input type="hidden" class="form-control" value="{{ $GeoTagging->fssai_license_record ?? '' }}" name="fssai_license_record[]" />

                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">एफएसएसएआई लाइसेंस नंबर/FSSAI License Number<span class="required">
                                                    *</span></label>
                                            <input type="text" class="form-control fssai_license_number" value="{{ $GeoTagging->fssai_license_number ?? '' }}" id="fssai_license_number" placeholder="FSSAI License Number" name="fssai_license_number[]" required>
                                            <label for="agreement_status" class="success fssi_success d-none" style="color:green">License Verified.</label>
                                            @if (!empty($GeoTagging->fssai_license_record))
                                            <a href="javascript:void(0);" onclick='viewLicense({{ $GeoTagging->id }})' class="text-decoration-underline">View License Detail</a>
                                            @endif
                                        </div>
                                    </div>
                                   <!-- <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">लाइसेंस दस्तावेज़/License Document<span class="required">
                                                </span></label>
                                            <input type="file" class="form-control upload_document" name="license_document[]">
											<span class="form-text">Supported formats: PDF. Upto 1MB</span>
                                            @if (!empty($GeoTagging->license_document))
                                            <input type="hidden" name="license_document_edit[]" value="{{ $GeoTagging->license_document ?? '' }}">
                                            <a target="_BLANK" href="{{ asset('public/traders/license_document/' . $GeoTagging->license_document) }}" class="text-decoration-underline">See Doc</a>
                                            @endif
                                        </div>
                                    </div> -->

                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">एफएसएसएआई समाप्ति तिथि/FSSAI End Date<span class="required"> *</span></label>
                                            <input type="date" class="form-control license_validity" value="{{ date('Y-m-d', strtotime($GeoTagging->license_validity)) ?? '' }}" id="license_validity" placeholder="FSSAI License Validity" name="license_validity[]" readonly>
                                        </div>
                                    </div>
                                    <div class="col-xxl-4 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">उत्पाद/Products<span class="required">
                                                        *</span></label>


                                                <textarea name="products[]" id="products" class="form-control fss_pro" readonly required>{{ $GeoTagging->address ?? '' }}</textarea>
                                            </div>
                                    </div>
                                    {{-- <div class="col-xxl-4 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">CompanyName<span class="required">
                                                        *</span></label>
                                                <textarea name="company[]" id="company" class="form-control fss_add" readonly required>{{ $GeoTagging->address ?? '' }}</textarea>
                                            </div>
                                    </div> --}}
                                    
                                    <div class="col-xxl-4  col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">परिसर का पता/Premise Address<span class="required">
                                                    *</span></label>
                                            <textarea name="address[]" id="address" class="form-control fss_add" required readonly>{{ $GeoTagging->address ?? '' }}</textarea>
                                        </div>
                                    </div>
                                    {{-- <div class="col-xxl-4 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">License Active Flag<span class="required">
                                                        *</span></label>


                                                <textarea name="licenseActiveFlag[]" id="licenseActiveFlag" class="form-control fss_add" readonly required>{{ $GeoTagging->address ?? '' }}</textarea>
                                            </div>
                                        </div> --}}
                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">समझौते की स्थिति/Status of Agreement<span class="required">
                                                    *</span></label>
                                            <input type="text" class="form-control" value="{{ $GeoTagging->agreement_status ?? '' }}" id="agreement_status" placeholder="Status of Agreement" name="agreement_status[]" required>
                                        </div>
                                    </div>
                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label for="labelInput" class="form-label">उत्पादों की संख्या/Number of Products<span class="required"> *</span></label>
                                            <input type="number" class="form-control" value="{{ $GeoTagging->number_of_products ?? '' }}" id="number_of_products" placeholder="Number of Products" name="number_of_products[]">
                                        </div>
                                    </div>
                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">अतिरिक्त प्रमाणपत्र/Additional Certificate<span class="required"> *</span></label>
                                            <input type="file" class="form-control upload_document" name="additional_certificate[]" id="additional_certificate">
											<span class="form-text">Supported formats: PDF. Upto 1MB</span>
                                            @if (!empty($GeoTagging->additional_certificate))
                                            <input type="hidden" name="additional_certificate_edit[]" value="{{ $GeoTagging->additional_certificate ?? '' }}">
                                            <a target="_BLANK" href="{{ asset('public/traders/additional_certificate/' . $GeoTagging->additional_certificate) }}" class="text-decoration-underline">See Doc</a>
                                            @endif
                                        </div>
                                    </div>
                                   <!-- <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label for="labelInput" class="form-label">गोदाम की जियो टैगिंग इकाई/Geo Tagging of Warehouse Unit<span class="required"> *</span></label>
                                            <input type="text" class="form-control" value="{{ $GeoTagging->geo_tagging_warehouse_unit ?? '' }}" name="geo_tagging_warehouse_unit[]" id="geo_tagging_warehouse_unit" placeholder="Geo Tagging of Processing Unit">
                                        </div>
                                    </div> -->

                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">टैगिंग के बाद फार्म छवि प्रतिबिंबित करें/Reflect Farm Image after Tagging<span class="required"> </span></label>
                                            <input type="file" class="form-control upload_document1" name="image_after_tagging[]" id="image_after_tagging">
                                            @if (!empty($GeoTagging->image_after_tagging))
                                            <input type="hidden" name="image_after_tagging_edit[]" value="{{ $GeoTagging->image_after_tagging ?? '' }}">
                                            <a target="_BLANK" href="{{ asset('public/traders/reflect_farm_image_after_tagging/' . $GeoTagging->image_after_tagging) }}" class="text-decoration-underline">See Doc</a>
                                            @endif
                                        </div>
                                          <span class="form-text">Supported formats:jpg, jpeg. Upto 1MB</span>
                                    </div>
                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label for="labelInput" class="form-label">गोदाम की कुल क्षमता इकाई/Total Capacity of Warehouse Unit<span class="required"> *</span></label>
                                            <input type="number" class="form-control" value="{{ $GeoTagging->total_capacity ?? '' }}" name="total_capacity[]" id="total_capacity" placeholder="Total Capacity of Warehouse Unit">
                                        </div>
                                    </div>
                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label for="labelInput" class="form-label">जैविक प्रसंस्करण के तहत स्थापित क्षमता/Installed Capacity Under Organic Processing<span class="required"> *</span></label>
                                            <input type="number" class="form-control" value="{{ $GeoTagging->organic_installed_capacity ?? '' }}" name="organic_installed_capacity[]" id="organic_installed_capacity" placeholder="Total Installed Capacity Under Organic Processing">
                                        </div>
                                    </div>

                                    <div class="mt-2 text-sm-end">
                                        @php
                                        $token = $GeoTagging->id . '#rgvv';

                                        $token = Crypt::encryptString($token);
                                        @endphp
                                        <div class="form-group change">
                                            <label for="">&nbsp;</label><br />
                                            <a class="btn btn-danger" href="javascript:void(0);" onclick="confirmDelete('{{ $token }}')" alt="Remove"><i class="ri-delete-bin-line"></i></a>
                                        </div>
                                    </div>
                                </div>

                                {{-- Model Start --}}

                                @php
                                $licRec = json_decode($GeoTagging->fssai_license_record ?? '');
                                @endphp
                                <div class="modal fade zoomIn" id="myModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered modal-lg">
                                        <div class="modal-content border-0">
                                            <div class="modal-header p-3 bg-soft-info">
                                                <h5 class="modal-title" id="exampleModalLabel">Licence Details</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" id="close-modal"></button>
                                            </div>

                                            <div class="modal-body">
                                                {{-- <div class="pdf_heading">Licence Details</div> --}}
                                                <div class="row g-3">

                                                    <div class="col-lg-6">
                                                        <div>
                                                            <label for="client_nameName-field" class="form-label">Expiry Date : </label>
                                                            {{ $licRec->expiryDate ?? '' }}

                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div>
                                                            <label for="assignedtoName-field" class="form-label">LicenseNo : </label>
                                                            {{ $licRec->licenseNo ?? '' }}
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div>
                                                            <label for="assignedtoName-field" class="form-label">License Category Name : </label>
                                                            {{ $licRec->licenseCategoryName ?? '' }}
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label for="date-field" class="form-label">Company Name :
                                                        </label>
                                                        {{ $licRec->companyName ?? '' }}
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label for="duedate-field" class="form-label">Address :
                                                        </label>
                                                        {{ $licRec->premiseAddress ?? '' }}
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label for="duedate-field" class="form-label">License
                                                            Status : </label>
                                                        {{ $licRec->licenseActiveFlag ?? '' }}
                                                    </div>
                                                    <div class="col-12">
                                                        <h6 style="padding:0;padding-bottom:15px;width: 100%;text-decoration: underline;">
                                                            Product Details
                                                            </caption>
                                                    </div>
                                                    @if(!empty($licRec->productDetails))
                                                    @foreach ($licRec->productDetails as $row)
                                                    <div class="col-lg-6">
                                                        <label for="duedate-field" class="form-label">Group Name : </label>
                                                        {{ $row->groupName ?? '' }}
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label for="duedate-field" class="form-label">Kob Name : </label>
                                                        {{ $row->kobName ?? '' }}
                                                    </div>
                                                    <div class="card-body table-responsive">
                                                        <table id="dtBasicExamplesss" class="table table-bordered table-striped align-middle" style="width:100%">

                                                            <thead>
                                                                <tr>
                                                                    <th>S.No.</th>
                                                                    <th>Product Name</th>
                                                                    <th>Product Status</th>

                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                @forelse( $row->productList as $k=>$val)
                                                                <tr>
                                                                    <td>{{ $k+1 }}</td>
                                                                    <td>{{ $val->productName??'' }}</td>

                                                                    <td>{{ $val->documentId==''?'Non-Organic' : 'Organic' }}</td>

                                                                </tr>
                                                                @empty
                                                                <tr>
                                                                    <td colspan="3">No Data Found.</td>
                                                                </tr>
                                                                @endforelse

                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    @endforeach
                                                    @endif
                                                </div>

                                            </div>

                                            <div class="modal-footer">
                                                <div class="hstack gap-2 justify-content-end">
                                                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>

                                                    {{-- <button type="submit" class="btn btn-success" id="edit-btn">Save</button> --}}
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                {{-- Model End --}}




                                @php $i++; @endphp
                                @empty
                                <div class="after-add-more seperatesec white-inner">
                                    <input type="hidden" class="form-control" value="" name="row_id[]" />
                                    <div class="row">
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">वेयरहाउस इकाई आईडी/Warehouse Unit ID<span class="required">
                                                        *</span></label>
                                                <input type="text" class="form-control" id="warehouse_unit_id" placeholder="Warehouse Unit ID" name="warehouse_unit_id[]" required>
                                            </div>
                                        </div>

                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">वेयरहाउस इकाइयों के नाम/Name of the Warehouse Units<span class="required"> *</span></label>
                                                <input type="text" class="form-control" id="warehouse_name" placeholder="Enter the Name of the Warehouse Units " name="warehouse_name[]" required>
                                            </div>
                                        </div>
                                        <input type="hidden" class="form-control" value="" name="fssai_license_record[]" />
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">एफएसएसएआई लाइसेंस नंबर/FSSAI License Number<span class="required">
                                                        *</span></label>
                                                <input type="text" class="form-control  fssai_license_number" id="fssai_license_number" placeholder="FSSAI License Number" name="fssai_license_number[]" required>
                                                <label for="agreement_status" class="success fssi_success d-none" style="color:green">License Verified.</label>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">लाइसेंस दस्तावेज़/License Document<span class="required">
                                                    </span></label>
                                                <input type="file" class="form-control upload_document" name="license_document[]">
												<span class="form-text">Supported formats:PDF Upto 1MB</span>
                                            </div>
                                        </div>

                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">एफएसएसएआई लाइसेंस की वैधता/FSSAI License Validity<span class="required"> *</span></label>
                                                <input type="date" class="form-control license_validity" id="license_validity" placeholder="FSSAI License Validity" name="license_validity[]" readonly required>
                                            </div>
                                        </div>
                                        <div class="col-xxl-5 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">उत्पाद/Products<span class="required">
                                                        *</span></label>


                                                <textarea name="products[]" id="products" class="form-control fss_pro" readonly required></textarea>
                                            </div>
                                        </div>
                                        <div class="col-xxl-4 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">परिसर का पता/Premise Address<span class="required">
                                                        *</span></label>
                                                <textarea name="address[]" id="address" class="form-control fss_add" readonly required></textarea>
                                            </div>
                                        </div>
                                        <div class="col-xxl-4 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">कंपनी का नाम/CompanyName<span class="required">
                                                        *</span></label>
                                                <textarea name="company[]" id="company" class="form-control fss_add" readonly required></textarea>
                                            </div>
                                        </div>
                                       <!-- <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">लाइसेंस सक्रिय स्थिति फ्लैग/License Active Flag<span class="required">
                                                        *</span></label>


                                                <textarea name="licenseActiveFlag[]" id="licenseActiveFlag" class="form-control fss_add" readonly required></textarea>
                                            </div>
                                        </div> -->
                                        

                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">सहमति की स्थिति/Status of Agreement<span class="required">
                                                        *</span></label>
                                                <input type="text" class="form-control" id="agreement_status" placeholder="Status of Agreement" name="agreement_status[]" required>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label for="labelInput" class="form-label">उत्पादों की संख्या/Number of Products<span class="required"> *</span></label>
                                                <input type="number" class="form-control" placeholder="Number of Products" name="number_of_products[]" required>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">अतिरिक्त प्रमाणपत्र/Additional Certificate<span class="required"> *</span></label>
                                                <input type="file" class="form-control upload_document" name="additional_certificate[]" id="additional_certificate" required>
												<span class="form-text">Supported formats:JPG, PNG, PDF. Upto 1MB</span>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label for="labelInput" class="form-label">वेयरहाउस इकाई का जियो टैगिंग/Geo Tagging of
                                                    Warehouse
                                                    Unit<span class="required"> *</span></label>
                                                <input type="text" class="form-control" name="geo_tagging_warehouse_unit[]" id="geo_tagging_warehouse_unit" placeholder="Geo Tagging of Processing Unit" required>
                                            </div>
                                        </div>

                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">टैगिंग के बाद फार्म छवि दिखाएँ/Reflect Farm Image after Tagging<span class="required"> </span></label>
                                                <input type="file" class="form-control upload_document1" name="image_after_tagging[]" id="image_after_tagging">
                                            </div>
                                              <span class="form-text">Supported formats:jpg, jpeg. Upto 1MB</span>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label for="labelInput" class="form-label">वेयरहाउस इकाई की कुल क्षमता/Total Capacity of
                                                    Warehouse
                                                    Unit<span class="required"> *</span></label>
                                                <input type="number" class="form-control" name="total_capacity[]" id="total_capacity" placeholder="Total Capacity of Warehouse Unit" required>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label for="labelInput" class="form-label">जैविक प्रसंस्करण के तहत स्थापित क्षमता/Installed Capacity
                                                    Under
                                                    Organic Processing<span class="required"> *</span></label>
                                                <input type="number" class="form-control" name="organic_installed_capacity[]" id="organic_installed_capacity" placeholder="Total Installed Capacity Under Organic Processing" required>
                                            </div>
                                        </div>

                                        <div class="mt-2 text-sm-end">
                                            <div class="form-group change">


                                            </div>
                                        </div>


                                    </div>

                                </div>
                                @endforelse

                                <div class="mt-2 text-sm-end">
                                    <div class="form-group change">
                                        <label for="">&nbsp;</label><br />
                                        <a class="btn btn-success add-more"><i class="ri-add-line"></i></a>
                                    </div>
                                </div>

                                <hr>

                                <!--address sec end-->

                                <div class="row">
                                    <div class="col-lg-12 gy-4">
                                        <div class="hstack gap-2">
                                            <a href="{{ route('superadmin.tradersUseredit', $userdetails->id) }}" class="btn btn-soft-success">
                                                Back
                                            </a>
                                            <button type="submit" class="btn btn-primary">
                                                Save & Next
                                            </button>
                                            <a href="{{ route('superadmin.tradersUseredit.step2', $userdetails->id) }}" class="btn btn-soft-success">
                                                Next
                                            </a>

                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>


@endsection
@push('script')
<script>
    // $("#registration").validate({
    //     rules: {

    //     },
    //     messages: {

    //     }

    // });


    $(document).on('change', '.upload_document', function () {
    var $this = $(this);
    var file = $this[0].files[0];

    // Ensure a file is selected
    if (!file) {
        Swal.fire({
            icon: 'error',
            title: 'No File Selected',
            text: 'Please select a file to upload.',
        });
        return false;
    }

    var fileType = file.type;
    var fileSize = file.size;
    var allowedTypes = ['application/pdf'];

    // Check for file type
    if (!allowedTypes.includes(fileType)) {
        Swal.fire({
            icon: 'error',
            title: 'Invalid File Extension',
            text: 'Please upload a PDF file only.',
        });
        $this.val(""); // Clear the input
        return false;
    }

    // Check for file size (1 MB = 1048576 bytes)
    if (fileSize > 1048576) { // 1 MB limit
        Swal.fire({
            icon: 'error',
            title: 'File Size Too Large',
            text: 'Please upload a file of size 1 MB or less.',
        });
        $this.val(""); // Clear the input
        return false;
    }

    // If validation passes
    Swal.fire({
        icon: 'success',
        title: 'Valid File',
        text: 'File is ready for upload.',
    });
});

    function confirmDelete_(id) {
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.value) {
                $.ajax({
                    url: "{{ route('superadmin.usermanagement.deptUser.individualUserDeleteGeoTagging') }}",
                    method: "POST",
                    dataType: 'json',
                    data: {
                        'id': id,
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(result) {
                        $('#row' + id).remove();
                        Swal.fire(
                            'Deleted!',
                            'Record Deleted Successfully..',
                            'success'
                        );

                    }
                });

            }
        })
    }


    $(document).ready(function() {
        $("body").on("click", ".add-more", function() {
            var html = $(".live-preview > .after-add-more").first().clone().find("input").val("").end()
                .find("textarea").val("").end();
            $(html).find(".change").html(
                "<label for=''>&nbsp;</label><br/><a class='btn btn-danger remove'><i class='ri-delete-bin-line'></i></a>"
            );
            $(".live-preview > .after-add-more").last().after(html);
        });

        $("body").on("click", ".remove", function() {
            $(this).parents(".after-add-more").remove();
        });
    });


    //$('.fssai_license_number').blur(function() {
    $(document).on('blur', '.fssai_license_number', function() {
        var th = $(this);
        var license_number = this.value;

        $.ajax({
            type: 'POST',
            url: "{{ route('superadmin.trader.getFSSAIDetails') }}",
            data: {
                'license_number': license_number
            },
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(response) {
                if (response) {
                    var res = JSON.parse(response);

                    if (res.productDetails) {
                        var productList = res.productDetails.find(productDetail => productDetail.groupName === "Food Services" && productDetail.kobName === "Hawker (Itinerant / Mobile food vendor)");
                        if (productList) {
                            var products = "";

                            productList.productList.forEach(function(product) {

                                products += "Product Name: " + product.productName + "\n";
                                products += "-----------------------------------------\n";
                            });


                            $('.fss_pro').val(products);
                        }
                    }

                    if (res.expiryDate !== undefined) {
                        var dateAr = res.expiryDate.split('-');
                        var newDate = dateAr[2] + '-' + dateAr[1] + '-' + dateAr[0].slice(-2);
                        $(th).parent().parent().parent().find('input[name="license_validity[]"]').val(newDate);
                        $(th).parent().parent().parent().find('textarea[name="address[]"]').val(res.premiseAddress);
                        $(th).parent().parent().parent().find('textarea[name="company[]"]').val(res.companyName);
                        $(th).parent().parent().parent().find('textarea[name="licenseActiveFlag[]"]').val(res.licenseActiveFlag);
                        $(th).parent().parent().parent().find('input[name="fssai_license_record[]"]').val(response);
                        $(".fssi_success").removeClass("d-none");
                    } else {
                        $(".fssi_success").addClass("d-none");
                        Swal.fire(
                            'Warning!',
                            'Invalid FSSAI License Number .',
                            'warning'
                        );
                    }
                }
            }
        });
    });

    function viewLicense(id) {
        //alert(id);
        $("#myModal").modal('show');

    }

    $('.upload_document1').on('change', function() {
    var $this = $(this);
    var file = $this[0].files[0];
    var fileType = file.type;
    var fileSize = file.size;
    var allowedTypes = ['image/jpeg', 'image/jpg'];

    // Check for file type
    if (!allowedTypes.includes(fileType)) {
        Swal.fire({
            icon: 'error',
            title: 'Invalid File Extension',
            text: 'Please upload JPEG, JPG only.',
        });
        $this.val("");
        return false;
    }

    // Check for file size (1 MB = 1,048,576 bytes)
    if (fileSize > 1048576) {
        Swal.fire({
            icon: 'error',
            title: 'File Size Too Large',
            text: 'Please upload files of size 1 MB or less only.',
        });
        $this.val("");
        return false;
    }
});
</script>
@endpush
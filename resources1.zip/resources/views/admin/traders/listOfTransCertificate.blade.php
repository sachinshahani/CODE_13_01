@extends('admin.layouts.app')
@section('content')
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Application for Transaction Certificate</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Application for Transaction Certificate dgf</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">


            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    {{-- <div class="card">

                        <div class="card-body"> --}}
                            <div class="card-header align-items-center d-flex">

                                <div class="flex-shrink-0">

                                </div>
                            </div>
                            <div class="live-preview">

                                <div class="row white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label  blue-ht">LIST OF TRANSACTION CERTIFICATE</label>
                                    </div>

                                    <div class="table-responsive">

                                            <table class="table table-bordered table-striped align-middle dataTable no-footer"
                                            width="100%" id="example">
                                            <thead>
                                                <tr>
                                                    <th>S.No.</th>
                                                    <th>TC Application No.</th>
                                                    <th>Date of Applicationn</th>
                                                    <th>Seller</th>
                                                    <th>Buyer</th>
                                                    <th>Country</th>
                                                    <th>Status</th>
                                                    <th>TC Type</th>
                                                    <th>Action</th>

                                                </tr>
                                            </thead>
                                            <tbody>

                                            </tbody>

                                        </table>

                                    </div>


                                </div>

                            </div>
                        {{-- </div>
                    </div> --}}
                </div>
            </div>
        </div>
    @endsection
    @push('script')
<script>
    $(document).ready(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $('#example').DataTable({
            dom: 'l<"clear">Bfrtip',
            //dom:'Bfrtip',
            //dom:'Blfrtip',
            lengthMenu: [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
            ],
            processing: true,
            serverSide: true,
            ajax: {
                url: '{{ route('superadmin.listOfTransCertificate') }}',
                type: 'GET',
                data: function(d) {
                }
            },
            columns: [
                {data: 'DT_RowIndex', name: 'DT_RowIndex',orderable: false  },
                { data: 'tc_application_no', name: 'tc_application_no' },
                { data: 'tc_date', name: 'tc_date' },
                { data: 'seller', name: 'seller' },
                { data: 'buyer', name: 'buyer' },
                { data: 'country', name: 'country' },
                { data: 'status', name: 'status' },
                { data: 'tc_type', name: 'tc_type' },
                { data: 'action', name: 'action', orderable: false, searchable: false }
            ]
        });
    });
</script>
@endpush

<div class="alert alert-danger" style="display:none"></div>
<form action="{{route('superadmin.closingstocks.storeIcsclosingstockProduct')}}" method="post">
 @csrf

<input type="hidden" name="product_id" id="product_id" value="{{ $product_id }}" />
<input type="hidden" name="stcrop_id" id="stcrop_id" value="{{ $stcropData->id }}" />
<input type="hidden" name="farm_id" id="farm_id" value="{{ $farm_id }}">
<input type="hidden" name="harvest_date" id="harvest_date" value="{{ $harvest_date }}">
<input type="hidden" name="actual_yield" id="actual_yield" value="{{ $stcropData->actual_yield }}">
 
	<div class="row g-3">
		<div class="col-xxl-6">
			<div>
				<label for="actual_yield" class="form-label">Closing Stock(in MT)</label>
				<input type="text" class="form-control" value="{{ $product_detail->closing_stock ?? ''}}" name="closing_stock" id="closing_stock" required>
			</div>
		</div><!--end col-->


		 <div class="col-xxl-6">
			<div>
				<label for="sowing_date" class="form-label">Closing Stock Date</label>
				<input type="date" class="form-control" data-provider="flatpickr" data-date-format="d M, Y" value="{{ $product_detail->closing_stock_date ?? ''}}" name="closing_stock_date" id="closing_stock_date" required>
			</div>
		</div><!--end col-->


		<div class="col-lg-12">
			<div class="hstack gap-2 justify-content-end">
				<button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
				<button type="button" id="formSubmit" class="btn btn-primary">Update</button>
			</div>
		</div><!--end col-->
	</div><!--end row-->
</form>

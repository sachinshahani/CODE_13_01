@extends('admin.layouts.app')
@section('content')

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Update Actual Yield</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Update Actual Yield</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">

            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                    <a class="nav-link" id="step1-tab"
                        href="javascript:void(0);">Farmer Details</a>
                        <a class="nav-link" id="step3-tab"
                        href="{{ route('superadmin.harvestUpdate.updateIcsActualYieldFarmsdetails',$id)}}">Farms Details</a>
                    <a class="nav-link active" id="step2-tab"
                        href="javascript:void(0);">Product Details</a>

                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">

                        <div class="card-body">
                            <div class="live-preview">

							<div class="row seperatesec white-inner">
								<div class="sectitle">
									<label for="labelInput" class="form-label blue-ht">Operator Details</label>
								</div>

								<div class="table-responsive">
									<table class="table table-bordered table-striped align-middle " width="50%" id="datatable_">
										<thead>
											<tr>
												<th>Registration No:</th><td>{{$harvester->registration_no ?? 'Not Alloted'}}</td>

												<th>Operator name</th><td>{{$harvester->first_name.' '.$harvester->middle_name.' '.$harvester->last_name}}</td>

												<th>Operator Type</th><td>{{getOperatorTypeById($harvester->ref_operator_type_id)}}</td>
											</tr>
                                            <tr>
												<th>Servics Provider</th><td>{{getOperatorTypeById($harvester->ref_operator_type_id)}}</td>
											</tr>
										</thead>

									</table>
								</div>
							</div>

							<div class="row seperatesec white-inner">
								<div class="sectitle">
									<label for="labelInput" class="form-label blue-ht">Farmer Detail(s)</label>
								</div>

								<div class="table-responsive">
									<table class="table table-bordered table-striped align-middle " width="50%" id="datatable_">
										<thead>
											<tr>
												<th>Farmer Name</th><td>{{$FarmerRegDetail->farmer_first_name}}</td>

												<th>Farmer ID</th><td>{{$FarmerRegDetail->owner_farmerid}}</td>
											</tr>
                                            <tr>
												<th>Address</th><td>{{$FarmerRegDetail->farmer_address}}</td>

												<th>State</th><td>{{getStateName($FarmerRegDetail->ref_state_id)}}</td>
											</tr>

										</thead>

									</table>
								</div>
							</div>
                            <div class="row seperatesec white-inner">
								<div class="sectitle">
									<label for="labelInput" class="form-label blue-ht">Farm Detail(s)</label>
								</div>

								<div class="table-responsive">
									<table class="table table-bordered table-striped align-middle " width="50%" id="datatable_">
										<thead>
											<tr>
												<th>Farm Name</th><td>{{$farm_details->farm_name}}</td>

												<th>Farm No</th><td>{{$farm_details->farm_no}}</td>
											</tr>
                                            <tr>
												<th>Organic Status</th><td>{{getRefOrganicStatusMasterByID($farm_details->ref_organic_status_master_id)}}</td>

												<th>Area Under Organic Cultivation(in Ha.)</th><td>{{$farm_details->area_organic_cultivation}}</td>
											</tr>
                                            <tr>
												<th>No of Products</th><td>{{countTableRecordById('at_farmer_standing_crop_details','at_farm_details_id',$farm_details->id)}}</td>
											</tr>

										</thead>

									</table>
								</div>
							</div>



                                <div class="row seperatesec  white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label  blue-ht">Product List</label>
                                    </div>
                                    <div class="table-responsive">
								<table class="table table-bordered table-striped align-middle dataTable no-footer" width="100%" id="datatable">
									<thead>
											<tr>
												<th>S.No.</th>
												<th>Product Name</th>
												<th>Season</th>
												<th>Crop Type</th>
												<th>Harvest Technique</th>
												<th>Organic Status</th>
												<th>Crop Area (in MT)</th>
												<th>Estimated Yield (in MT)</th>
												<th>Actual Yield (in MT)</th>
												<th>Harvest Date</th>
												<th>Sowing Date</th>
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
											  @forelse($product_details as $value)
											<tr>
												<td>{{$loop->iteration}}</td>
												<td></td>
												<td>{{$value->season_name}}</td>
												<td>Main</td>
												<td>{{$value->circle}}</td>
												<td>{{getSingleTableRecordById('ref_organic_status_master','standard_type_id',$value->organic_status)->organic_status ?? ''}}</td>
												<td>{{$value->crop_area}}</td>
												<td>{{$value->estimated_yield}}</td>
												<td><span id="edit_actual_yield">{{$value->actual_yield}}</span></td>
												<td><span id="edit_harvest_date">{{$value->harvest_date}}</span></td>
												<td><span id="edit_sowing_date">{{$value->sowing_date}}</span></td>
												<td>
													@if(countTableRecordById('at_closing_stock','at_farmer_standing_crop_details_id',$value->id) == 0)
													<a href="javascript:void(0)" onclick="editProduct('{{$value->id}}')">Edit</a>
													@else
													<a href="javascript:void(0)" >Updated</a>
												@endif
												</td>
											</tr>
											@empty
											<tr>
												<td colspan="8">No records found..</td>
											</tr>
											@endforelse
										</tbody>

								</table>
							</div>


                                </div>

                            </div>
                        </div>
                    </div>
                </div>
    </div>
</div>



@endsection
@push('script')
<div class="modal fade" id="addBatchModalgrid" tabindex="-1" aria-labelledby="addBatchModalgridLabel" aria-modal="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addBatchModalgridLabel">Edit Product</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="batch_popup">

            </div>
        </div>
    </div>
</div>
<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
function editProduct(product_id='')
{
$('#whole_page_loader').show();
	$.ajax({
		  url: "{{ route('superadmin.harvestUpdate.editIcsHarvestProduct') }}",
		  method: "POST",
		  cache: false,
		  data: {
			  'product_id': product_id,
		  },
		  headers: {
			  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
		  },
		  success: function (result) {
			  console.log(result);
			  $('#batch_popup').html(result);
			  $('#addBatchModalgrid').modal('show');
			  $('#whole_page_loader').hide();
		  }
	  });
}

$(document).on('click','#formSubmit',function(e){
		e.preventDefault();
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
			}
		});
		$('#whole_page_loader').show();
		$.ajax({
			url: "{{route('superadmin.harvestUpdate.storeIcsHarvestProduct')}}",
			method: 'post',
			data: {
				actual_yield: $('#actual_yield').val(),
				harvest_date: $('#harvest_date').val(),
				sowing_date: $('#sowing_date').val(),
				product_id: $('#product_id').val(),
			},
			success: function(result){
				if(result.errors)
				{
					$('.alert-danger').html('');

					$.each(result.errors, function(key, value){
						$('.alert-danger').show();
						$('.alert-danger').append('<li>'+value+'</li>');
					});
					$('#whole_page_loader').hide();
				}
				else
				{
					$('#edit_actual_yield').html(result.data['actual_yield']);
					$('#edit_harvest_date').html(result.data['harvest_date']);
					$('#edit_sowing_date').html(result.data['sowing_date']);
					$('.alert-danger').hide();
					$('#addBatchModalgrid').modal('hide');
					$('#batch_popup').html('');
					$('#whole_page_loader').hide();
				}
			}
		});
	});

$('#datatable').DataTable();
</script>

@endpush

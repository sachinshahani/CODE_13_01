@extends('admin.layouts.app')
@section('content')

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Update Actual Yield</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Update Actual Yield</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">

            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                    <a class="nav-link" id="step1-tab"
                        href="javascript:void(0);">Farmer Details</a>
                    <a class="nav-link active" id="step2-tab"
                        href="javascript:void(0);">Farms Details</a>
                    <a class="nav-link" id="step3-tab"
                        href="javascript:void(0);">Product Details</a>
                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">

                        <div class="card-body">
                            <div class="live-preview">

							<div class="row seperatesec white-inner">
								<div class="sectitle">
									<label for="labelInput" class="form-label blue-ht">Operator Details</label>
								</div>

								<div class="table-responsive">
									<table class="table table-bordered table-striped align-middle " width="50%" id="datatable_">
										<thead>
											<tr>
												<th>Registration No:</th><td>{{$harvester->registration_no ?? 'Not Alloted'}}</td>

												<th>Operator name</th><td>{{$harvester->first_name.' '.$harvester->middle_name.' '.$harvester->last_name}}</td>

												<th>Operator Type</th><td>{{getOperatorTypeById($harvester->ref_operator_type_id)}}</td>
											</tr>
										</thead>

									</table>
								</div>
							</div>

							<div class="row seperatesec white-inner">
								<div class="sectitle">
									<label for="labelInput" class="form-label blue-ht">Farmer Details</label>
								</div>

								<div class="table-responsive">
									<table class="table table-bordered table-striped align-middle " width="50%" id="datatable_">
										<thead>
											<tr>
												<th>Farmer Name</th><td>{{$FarmerRegDetail->farmer_first_name}}</td>

												<th>Farmer ID</th><td>{{$FarmerRegDetail->owner_farmerid}}</td>
											</tr>
                                            <tr>
												<th>Address</th><td>{{$FarmerRegDetail->farmer_address}}</td>

												<th>State</th><td>{{getStateName($FarmerRegDetail->ref_state_id)}}</td>
											</tr>

										</thead>

									</table>
								</div>
							</div>



                                <div class="row seperatesec  white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label  blue-ht">Farm(s) List</label>
                                    </div>
                                    <div class="table-responsive">
								<table class="table table-bordered table-striped align-middle dataTable no-footer" width="100%" id="datatable">
									<thead>
											<tr>
												<th>S.No.</th>
												<th>Farm No</th>
												<th>Farm Name</th>
												<th>Organic Status</th>
												<th>State</th>
												<th>Area Under Organic Cultivation(in Ha.)</th>
												<th>No of Products</th>
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
											@forelse($farm_details as $value)
											<tr {{$value->id}}>
												<td>{{$loop->iteration}}</td>
												<td>{{$value->farm_no}}</td>
												<td>{{$value->farm_name}}</td>
                                                <td>{{getRefOrganicStatusMasterByID($value->ref_organic_status_master_id)}}</td>
                                                <td>{{getStateName($value->ref_state_id)}}</td>
												<td>{{$value->area_organic_cultivation}}</td>
												<td>{{countTableRecordById('at_farmer_standing_crop_details','at_farm_details_id',$value->id)}}</td>
												<td><a href="{{ route('superadmin.harvestUpdate.updateIcsActualYieldProducts',[$value->at_farmer_reg_details_id,$value->id])}}">Proced</a></td>
											</tr>
											@empty
											<tr>
												<td colspan="8">No records found..</td>
											</tr>
											@endforelse
										</tbody>

								</table>
							</div>

	
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
    </div>
</div>



@endsection
@push('script')

<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
$('#datatable').DataTable();
</script>

@endpush

@extends('admin.layouts.app')
@section('content')

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Update Closing Stock</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Update Closing Stock</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">

            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">
                    <a class="nav-link inactive" id="step0-tab"
                    href="javascript:void(0);">Operator Details</a>
                    <a class="nav-link" id="step1-tab"
                        href="javascript:void(0);">Farmer Details</a>
                        <a class="nav-link" id="step3-tab"
                        href="#">Farms Details</a>
                    <a class="nav-link active" id="step2-tab"
                        href="javascript:void(0);">Product Details</a>

                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">

                        <div class="card-body">
                            <div class="live-preview">

							<div class="row seperatesec white-inner">
								<div class="sectitle">
									<label for="labelInput" class="form-label blue-ht">Operator Details</label>
								</div>

								<div class="table-responsive">
									<table class="table table-bordered table-striped align-middle " width="50%" id="datatable_">
										<thead>
											<tr>
                                                <th>Operator name</th><td>{{user_name($operator_list->at_user_id)}}</td>
                                                <th>Registration No:</th><td>{{getbyOperatornameRegNo($operator_list->at_user_id)}}</td>
                                                <th>Operator Type</th><td>{{getOperatorTypeById($operator_list->ref_operator_type_id)}}</td>
											</tr>
                                            <tr>
												<th>Servics Provider</th><td> </td>
											</tr>
										</thead>

									</table>
								</div>
							</div>

							<div class="row seperatesec white-inner">
								<div class="sectitle">
									<label for="labelInput" class="form-label blue-ht">Farmer Detail(s)</label>
								</div>

								<div class="table-responsive">
									<table class="table table-bordered table-striped align-middle " width="50%" id="datatable_">
										<thead>
											<tr>
												<th>Farmer Name</th><td>{{$FarmerRegDetail->farmer_first_name}}</td>

												<th>Farmer ID</th><td>{{$FarmerRegDetail->owner_farmerid}}</td>
											</tr>
                                            <tr>
												<th>Address</th><td>{{$FarmerRegDetail->farmer_address}}</td>

												<th>State</th><td>{{getStateName($FarmerRegDetail->ref_state_id)}}</td>
											</tr>

										</thead>

									</table>
								</div>
							</div>
                            <div class="row seperatesec white-inner">
								<div class="sectitle">
									<label for="labelInput" class="form-label blue-ht">Farm Detail(s)</label>
								</div>

								<div class="table-responsive">
									<table class="table table-bordered table-striped align-middle " width="50%" id="datatable_">
										<thead>
											<tr>
												<th>Farm Name</th><td>{{$farm_details->farm_name}}</td>

												<th>Farm No</th><td>{{$farm_details->farm_no}}</td>
											</tr>
                                            <tr>
												<th>Organic Status</th><td>{{getRefOrganicStatusMasterByID($farm_details->ref_organic_status_master_id)}}</td>

												<th>Area Under Organic Cultivation(in Ha.)</th><td>{{$farm_details->area_organic_cultivation}}</td>
											</tr>
                                            <tr>
												<th>No of Products</th><td>{{countTableRecordById('at_farmer_standing_crop_details','at_farm_details_id',$farm_details->id)}}</td>
											</tr>

										</thead>

									</table>
								</div>
							</div>



                                <div class="row seperatesec  white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label  blue-ht">Product List</label>
                                    </div>
                                    <div class="table-responsive">
								<table class="table table-bordered table-striped align-middle dataTable no-footer" width="100%" id="datatable">
									<thead>
											<tr>
												<th>S.No.</th>
												<th>Product Name</th>
												<th>On-Farm Processor Product</th>
												<th>Season</th>
												<th>Crop Type</th>
												<th>Harvest Technique</th>
												<th>Organic Status</th>
												<th>Crop Area (in MT)</th>
												<th>Estimated Yield (in MT)</th>
												<th>Actual Yield (in MT)</th>
												<th>Harvest Date</th>
												<th>Sowing Date</th>
												<th>Quantity Sourced(in MT)</th>
												<th>Closing Stock(in MT)</th>
												<th>Closing Stock Date</th>
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
										 
											  @forelse($product_details as $value)
											 
											<tr class="pro-tr">
												<td>{{$loop->iteration}}</td>
												<td>{{getHscodeProductName($value->ref_product_id)}}</td>
												<td>{{$farm_details->farm_processing}}</td>
												<td>{{$value->season_name}}</td>
												<td>{{$value->crop_name}}</td>
												<td>{{$value->ref_harvesting_technique_id}}</td>
                                                <td>{{getRefOrganicStatusMasterByID(($value->organic_status))}}</td>
												<!-- <td>{{$value->organic_status}}</td> -->
												<td>{{$value->crop_area}}</td>
												<td>{{$value->estimated_yield}}</td>
												<td class="pro-td">{{$value->actual_yield}}</span></td>
												<td>{{$value->harvest_date}}</span></td>
												<td>{{$value->sowing_date}}</span></td>
												<td></td>

												<td><span id="edit_closing_stock_{{ $value->id }}">{{getClosingStockByCropId($value->id)->closing_stock ?? ''}}</td>
												<td><span id="edit_closing_stock_date_{{ $value->id }}">{{getClosingStockByCropId($value->id)->closing_stock_date ?? ''}}</td>
												<td>
													<a href="javascript:void(0)" onclick="editProduct('{{$value->id}}','{{$farm_id}}','{{$value->harvest_date}}')">Edit</a>
												</td>
											</tr>
											 
											@empty
											<tr>
												<td colspan="8">No records found..</td>
											</tr>
											@endforelse
										</tbody>

								</table>
							</div>


                                </div>

                            </div>
                        </div>
                    </div>
                </div>
    </div>
</div>



@endsection
@push('script')
<div class="modal fade" id="addBatchModalgrid" tabindex="-1" aria-labelledby="addBatchModalgridLabel" aria-modal="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addBatchModalgridLabel">Closing Stock Update</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="batch_popup">

            </div>
        </div>
    </div>
</div>
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    function editProduct(product_id,farm_id,harvest_date)
    {
        if(product_id!= '' && farm_id!='' && harvest_date!=''){
            $('#whole_page_loader').show();
            $.ajax({
                url: "{{ route('superadmin.closingstocks.editIcsClosingstockProduct') }}",
                method: "POST",
                cache: false,
                data: {
                    'product_id': product_id,'farm_id': farm_id,'harvest_date':harvest_date
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function (result) {


                    $('#batch_popup').html(result);
                    $('#addBatchModalgrid').modal('show');
                    $('#whole_page_loader').hide();
                }
            });
        } else {
            alert('product id should not blank');

        }
    }

    $(document).on('click','#formSubmit',function(){
        var actual_yield = $('#actual_yield').val();
        var closing_stock = $('#closing_stock').val();
        if(closing_stock > actual_yield){
            Swal.fire({
                        text: "Closing Stock should not be greater than Actual Yield (in MT).",
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
        } else{
            //$('#whole_page_loader').show();

            $.ajax({
                type:"post",
                data: {
                    "_token": "{{csrf_token()}}",
                    closing_stock: $('#closing_stock').val(),
                    closing_stock_date: $('#closing_stock_date').val(),
                    product_id: $('#product_id').val(),
                    harvest_date: $('#harvest_date').val(),
                    farm_id: $('#farm_id').val(),
                    stcrop_id: $('#stcrop_id').val(),
                },
                url: "{{route('superadmin.closingstocks.storeIcsclosingstockProduct')}}",
                success: function(result){

                    console.log(result);
                    if(result.errors)
                    {
                        $('.alert-danger').html('');

                        $.each(result.errors, function(key, value){
                            $('.alert-danger').show();
                            $('.alert-danger').append('<li>'+value+'</li>');
                        });
                        //$('#whole_page_loader').hide();
                    }
                    else
                    {
                        Swal.fire({
                                text: "Closing Stock has been updated successfully",
                                icon: 'success',
                                confirmButtonText: 'OK'
                            });

                        $('#edit_closing_stock_'+result.data['at_farmer_standing_crop_details_id']).html(result.data['closing_stock']);
                        $('#edit_closing_stock_date_'+result.data['at_farmer_standing_crop_details_id']).html(result.data['closing_stock_date']);
                        $('.alert-danger').hide();
                        $('#addBatchModalgrid').modal('hide');
                        $('#batch_popup').html('');
                        //$('#whole_page_loader').hide();
                    }
                }
            });
        }   
        
    });

    $(document).on("change", "#closing_stock", function(evt) {
              
               evt.preventDefault();
            
            //    var total = 0;
            //    $( ".area" ).each( function(){
            //      total += parseFloat( $( this ).val() ) || 0;
                
            //    });
            //    if(tot_area < total){
            //        Swal.fire('', 'Farm area can not be exceed from the total farm area.', '');
            //        $('.submit-button').attr('disabled',true);
            //        return false;
            //    }else{
            //        $('.submit-button').attr('disabled',false);
            //        return true;
            //    }
              
    });

    $('#datatable').DataTable();
    </script>

@endpush

@extends('admin.layouts.app')
@section('content')

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Update Closing Stock</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Update Closing Stock</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">

            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                    <a class="nav-link active" id="step1-tab"
                    href="javascript:void(0);">Operator Details</a>
                    <a class="nav-link" id="step2-tab"
                        href="javascript:void(0);">Farmer Details</a>
                        <a class="nav-link" id="step3-tab"
                        href="javascript:void(0);">Farms Details</a>
                    <a class="nav-link" id="step4-tab"
                        href="javascript:void(0);">Product Details</a>
                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">

                        <div class="card-body">
                            <div class="live-preview">


                                <div class="row">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label  blue-ht">Operator List</label>
                                    </div>
                                    <div class="card-body">
                                        <div class="table-responsive">
                                            <table class="table table-bordered table-striped align-middle dataTable no-footer" width="100%" id="datatable">
									<thead>
											<tr>
												<th>S.No.</th>
												<th>Registration No</th>
												<th>Operator Name</th>
												<th>Operator Type</th>
												<th>Registration Date</th>
												<th>Action</th>
											</tr>
										</thead>


								</table>
							</div>
                        </div>


                                </div>

                            </div>
                        </div>
                    </div>
                </div>
    </div>
</div>



@endsection
@push('script')

<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

</script>
<script type="text/javascript">
    // DataTables Core and Extensions
     var table_schedule =  $('#datatable').DataTable({
            processing: true,
            serverSide: true,
           // autoWidth: true,
           // responsive: true,
            "order": [
                    [1, "asc"]
                ],
            ajax: '#',
            columns: [
                {data: 'DT_RowIndex', name: 'DT_RowIndex'},
                {data: 'registration_no', name: 'registration_no'},
                {data: 'operator_name', name: 'operator_name'},
                {data: 'ref_operator_type_id', name: 'ref_operator_type_id'},
                {data: 'created_at', name: 'created_at'},
                {data: 'action', name: 'action', orderable: true, searchable: true}
            ]
        });
    </script>
@endpush

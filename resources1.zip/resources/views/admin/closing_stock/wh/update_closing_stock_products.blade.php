@extends('admin.layouts.app')
@section('content')

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Update Actual Yield</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Update Actual Yield</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">

            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                    <a class="nav-link" id="step1-tab"
                        href="javascript:void(0);">Opeartor Details</a>

                    <a class="nav-link active" id="step2-tab"
                        href="javascript:void(0);">Product Details</a>
                        <a class="nav-link" id="step3-tab"
                        href="#"></a>

                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">

                        <div class="card-body">
                            <div class="live-preview">

							<div class="row seperatesec white-inner">
								<div class="sectitle">
									<label for="labelInput" class="form-label blue-ht">Operator Details</label>
								</div>

								<div class="table-responsive">
									<table class="table table-bordered table-striped align-middle " width="50%" id="datatable_">
										<thead>
											<tr>
												<th>Operator name</th><td>{{$operator_list->operator_name}}</td>
                                                <th>Registration No:</th><td>{{$operator_list->registration_no ?? 'Not Alloted'}}</td>
												<th>Operator Type</th><td>{{getOperatorTypeById($operator_list->ref_operator_type_id)}}</td>
											</tr>

										</thead>

									</table>
								</div>
							</div>
                                <div class="row seperatesec  white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label  blue-ht">Wild Area Product Details</label>
                                    </div>
                                    <div class="table-responsive">
								<table class="table table-bordered table-striped align-middle dataTable no-footer" width="100%" id="datatable">
									<thead>
											<tr>
												<th>S.No.</th>
												<th>Product Name</th>
												<th>HS code</th>
												<th>Organic Status</th>
												<th>Economic Part</th>
                                                <th>Total Estimated Quantity (in MT)</th>
												<th>Harvest Date</th>
												<th>Actual Yield (in MT)</th>
												<th>Quantity Sourced (in MT)</th>
												<th>Closing Stock (in MT)</th>
												<th>Closing Stock Date</th>
												<th>Action</th>
											</tr>
										</thead>
										<tbody>

											<tr>
												<td> </td>
												<td></td>
												<td> </td>
												<td> </td>
												<td> </td>
												<td> </td>
												<td> </td>
												<td> </td>
												<td> </td>
												<td> </td>
												<td> </td>
												{{-- <td><span id="edit_actual_yield">{{$value->actual_yield}}</span></td>
												<td><span id="edit_harvest_date">{{$value->harvest_date}}</span></td>
												<td><span id="edit_sowing_date">{{$value->sowing_date}}</span></td>
												<td><a href="javascript:void(0)" onclick="editProduct('{{$value->id}}')">Edit</a></td> --}}
											</tr>

											<tr>
												<td colspan="8">No records found..</td>
											</tr>

										</tbody>

								</table>
							</div>


                                </div>

                            </div>
                        </div>
                    </div>
                </div>
    </div>
</div>



@endsection
@push('script')
<div class="modal fade" id="addBatchModalgrid" tabindex="-1" aria-labelledby="addBatchModalgridLabel" aria-modal="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addBatchModalgridLabel">Edit Product</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="batch_popup">

            </div>
        </div>
    </div>
</div>
<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
function editProduct(product_id='')
{
$('#whole_page_loader').show();
	$.ajax({
		  url: "{{ route('superadmin.harvestUpdate.editIPHarvestProduct') }}",
		  method: "POST",
		  cache: false,
		  data: {
			  'product_id': product_id,
		  },
		  headers: {
			  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
		  },
		  success: function (result) {
			  console.log(result);

			  $('#batch_popup').html(result);
			  $('#addBatchModalgrid').modal('show');
			  $('#whole_page_loader').hide();
		  }
	  });
}

$(document).on('click','#formSubmit',function(e){
		e.preventDefault();

        //alert('hello');
		$('#whole_page_loader').show();
		$.ajax({
			url: "{{route('superadmin.harvestUpdate.storeIPHarvestProduct')}}",
			type: 'post',
            data: {
				actual_yield: $('#actual').val(),
				harvest_date: $('#harvest_date').val(),
				sowing_date: $('#sowing_date').val(),
				product_id: $('#product_id').val(),
			},
			success: function(result){

				if(result.errors)
				{
                    alert('hello');
					$('.alert-danger').html('');

					$.each(result.errors, function(key, value){
						$('.alert-danger').show();
						$('.alert-danger').append('<li>'+value+'</li>');
					});
					$('#whole_page_loader').hide();
				}
				else
				{
                    alert("Update Successfully ");
					/*$('#edit_actual_yield').html(result.data['actual_yield']);
					$('#edit_harvest_date').html(result.data['harvest_date']);
					$('#edit_sowing_date').html(result.data['sowing_date']);
					$('.alert-danger').hide();
					$('#addBatchModalgrid').modal('hide');
					$('#batch_popup').html('');*/
					$('#whole_page_loader').hide();
				}
			}
		});
	});

$('#datatable').DataTable();
</script>

@endpush

@extends('admin.layouts.app')
@section('content')

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Update Actual Yield</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Update Actual Yield</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">

            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                    <a class="nav-link" id="step1-tab"
                        href="{{route('superadmin.harvestUpdate.updateActualYieldScope')}}">Wild Area Details</a>
                    <a class="nav-link" id="step2-tab"
                        href="javascript:void(0);">Product Details</a>
                    <a class="nav-link active" id="step3-tab"
                        href="{{route('superadmin.harvestUpdate.updateActualYieldHarvestHistory')}}">Harvest History</a>
                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">

                        <div class="card-body">
                            <div class="live-preview">


                                <div class="row seperatesec  white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label  blue-ht">Product List</label>
                                    </div>
                                    <div class="table-responsive">
								<table class="table table-bordered table-striped align-middle dataTable no-footer" width="100%" id="datatable">
									<thead>
											<tr>
												<th>S.No.</th>
												<th>Wild ID</th>
												<th>State Name</th>
												<th>Circle</th>
												<th>Division</th>
												<th>Range</th>
												<th>Product Name</th>
												<th>Harvest Technique</th>
												<th>Organic Status</th>
												<th>Actual Yield(in MT)</th>
												<th>Harvest Year</th>
											</tr>
										</thead>
										<tbody>
											@forelse($harvester_history as $value)
											<tr>
												<td>{{$loop->iteration}}</td>
												<td>{{$value->wild_id}}</td>
												<td>{{getStateName($value->ref_state_id)}}</td>
												<td>{{$value->circle}}</td>
												<td>{{$value->division}}</td>
												<td>{{$value->range}}</td>
												<td>{{$value->name_of_the_forest_product}}</td>
												<td></td>
												<td>{{$value->organic_status}}</td>
												<td>{{$value->actual_harvest_yield}}</td>
												<td>{{date('Y',strtotime($value->created_at))}}</td>
											</tr>
											@empty
											<tr>
												<td colspan="11">No records found..</td>
											</tr>
											@endforelse
										</tbody>

								</table>
							</div>


                                </div>

                            </div>
                        </div>
                    </div>
                </div>
    </div>
</div>



@endsection
@push('script')

<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

</script>

@endpush

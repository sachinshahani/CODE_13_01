@extends('admin.layouts.app_acc')

@section('content')
    <style>
        .customtextarea {
            height: 80px;
        }
    </style>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Amendment</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Amendment</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->
    <form method="post" enctype="multipart/form-data" id="registration" action="{{route('superadmin.accrAmendmentSave')}}">
        @csrf

        <div class="tab-content py-4 custom-tab-content">
            <div class="tab-pane fade show active" id="step1">
                <div class="card">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1">

                        </h4>

                    </div>
                    @if (session('success'))
                                <div class="alert alert-success">
                                    {{ session('success') }}
                                </div>
                            @endif
                    <!-- end card header -->
                    <div class="card-body">
                        <div class="live-preview">
                            <div class="row seperatesec  white-inner">
                                <div class="col-12">
                                    <h6 style="padding:0;padding-bottom:15px;width: 100%;text-decoration: underline;">Basic
                                        Details of CB :
                                        </caption>
                                </div>
                                <div class="col-12">
                                    <!--form1 tab starts here-->
                                    <table style="padding: 10px; border: 0px;" class="table_pdf table_contact_person">

                                        <tbody>
                                            <tr>
                                                <th class="pdf_txt1">Name of Certification Body : </th>
                                                <td class="pdf_box">{{ old('at_user_id', $userid->first_name) }}</td>
                                            </tr>
                                            <tr>
                                                <th class="pdf_txt1">Accreditation NO.: </th>
                                                <td class="pdf_box">NPOP/NAB/420</td>
                                            </tr>
                                            <tr>
                                                <th class="pdf_txt1">Accreditation Validity End Date : </th>
                                                <td class="pdf_box">{{ old('at_user_id', $userid->date_of_registration) }}</td>
                                            </tr>
                                            <tr>
                                                <th class="pdf_txt1">Registered Address : </th>
                                                <td class="pdf_box">{{ old('at_user_id', $userid->address) }}</td>
                                            </tr>
                                            <tr>
                                                <th class="pdf_txt1">Legal Status : </th>
                                                <td class="pdf_box">NOt Avialable</td>
                                            </tr>

                                        </tbody>
                                    </table>
                                    <!--form1 tab end here-->
                                </div>

                            </div>
                            <div class="row seperatesec white-inner" >
                                <div class="sectitle">
                                    <label for="labelInput" class="form-label  blue-ht">Apply for Amendment</label>
                                </div>
                                <div class="col-xxl-3 col-md-4">
                                    <div>
                                        <label class="form-label">Change Name: <span class="required">*</span></label>
                                        <select class="form-select" name="country" id="change_dive" required>
                                            <option value="">-Select-</option>
                                            <option value="name">Name Change</option>
                                            <option value="address">Address Change</option>
                                            <option value="logo">Logo Change</option>
                                            <option value="legal_status">Change request for legal status</option>
                                            <option value="processing">Addition of Processing and Handling</option>
                                            <option value="accreditation">Extension of Accreditation Validity</option>

                                        </select>
                                    </div>
                                </div>


                            </div>
                            <div class="row white-inner name-change">
                                <div class="col-xxl-3 col-md-4 ">
                                    <div>
                                        <label for="labelInput" class="form-label">Existing Name: <span
                                                class="required">*</span></label>
                                                <input type="hidden" class="form-control" name="at_user_id" value=""
                                            required />
                                        <input type="text" class="form-control" name="existing_name" value="{{ old('at_user_id', $userid->first_name) }}"
                                            required />
                                    </div>
                                </div>
                                <div class="col-xxl-3 col-md-4">
                                    <div>
                                        <label for="labelInput" class="form-label">New Name: <span
                                                class="required">*</span></label>
                                        <input type="text" class="form-control" name="amendment_name" value=""
                                            required />
                                    </div>
                                </div>

                                <div>
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped align-middle dataTable no-footer"
                                        width="100%" id="datatable">
                                        <thead>
                                            <tr>
                                                <th>S.No.</th>
                                                <th>Required Document</th>
                                                <th>Upload Documents</th>
                                                <!-- <th>Action</th> -->

                                            </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                                <td>1</td>
                                                <td>Document For Name Change</td>
                                                <td>
                                                    <input type="file" class="form-control" name="name_document_upload" accept="image/png, application/pdf, image/jpeg">
                                                </td>
                                                <!-- <td>
                                                    <a href="" id="uploadButton">Upload</a>
                                                </td> -->
                                            </tr>


                                        </tbody>

                                    </table>
                                </div>


                                </div>
                                <div class="col-xxl-6 col-md-4  gy-3">
                                    <div>
                                        <label for="labelInput" class="form-label">Remarks : <span
                                                class="required">*</span></label>

                                        <textarea placeholder="Remark Here" class="form-control customtextarea" name="remarks" maxlength="100"></textarea>

                                    </div>
                                </div>
                            </div>
                            <div class="row white-inner address-change">
                                <div class="col-xxl-6 col-md-4 gy-3">
                                    <div>
                                        <label class="form-label">Which address do you want to change ? : <span
                                                class="required">*</span></label>
                                        <br>
                                        <input type="radio" id="html" name="operational_address" value="Registered Address" checked>
                                        <label for="new">Registered Address</label>

                                        <input type="radio" id="html" name="operational_address" value="Operational Address">
                                        <label for="new">Operational Address</label>

                                        <input type="radio" id="html" name="operational_address" value="Both Address">
                                        <label for="new">Both Address</label>

                                    </div>
                                </div>
                                <div class="col-xxl-6 col-md-4 gy-3">
                                    <div>
                                        <label class="form-label">Address Type: <span class="required">*</span></label>
                                        <br>
                                        <input type="radio" id="html" name="add_type" value="Owned" checked>
                                        <label for="new">Owned</label>
                                        <input type="radio" id="html" name="add_type" value="Lease/Rent">
                                        <label for="new">Lease/Rent</label>

                                    </div>
                                </div>
                                <div class="col-xxl-6 col-md-6 gy-3">
                                    <div>
                                        <div class="col-xxl-9 col-md-6 gy-3">
                                            <label for="labelInput" class="form-label">Existing Registered Address <span
                                                    class="required">*</span></label>
                                        <input type="text" class="form-control numbersonly"  name="no_of_farmers" value="{{ old('at_user_id', $userid->address) }}"

                                         required />


                                        </div>
                                        <div class="col-xxl-9 col-md-6 gy-3">
                                            <label for="labelInput" class="form-label">State Name<span
                                                    class="required">*</span></label>

                                        <input type="text" class="form-control numbersonly"  name="no_of_farmers" value="{{ getStateName($userid->ref_state_id)??'' }}"

                                         required />





                                         <div>
                                    </div>

                                        </div>
                                        <div class="col-xxl-9 col-md-6 gy-3">
                                            <label for="labelInput" class="form-label">District Name <span
                                                    class="required">*</span></label>

                                        <input type="text" class="form-control numbersonly"  name="no_of_farmers" value="{{ getDisName($userid->ref_district_id)??'' }}"

                                         required />


                                        </div>
                                        <div class="col-xxl-9 col-md-6 gy-3">
                                            <label for="labelInput" class="form-label">Village Name <span
                                                    class="required">*</span></label>

                                        <input type="text" class="form-control numbersonly"  name="no_of_farmers" value="{{ getVillName($userid->ref_district_id)??'' }}"

                                         required />


                                        </div>
                                        <div class="col-xxl-9 col-md-6 gy-3">
                                            <label for="labelInput" class="form-label">Pin <span
                                                    class="required">*</span></label>

                                            <input type="text" class="form-control numbersonly"  name="no_of_farmers" value="{{ old('at_user_id', $userid->pin) }}"

                                            required />
                                        </div>

                                    </div>
                                </div>
                                <div class="col-xxl-6 col-md-6 gy-3">
                                    <div>
                                        <div class="col-xxl-9 col-md-6 gy-3">
                                            <label for="labelInput" class="form-label">New Registered Address <span
                                                    class="required">*</span></label>
                                        <input type="text" class="form-control"  name="address" value="" required />


                                        </div>
                                        <div class="col-xxl-9 col-md-6 gy-3">
                                            <label for="labelInput" class="form-label">State Name<span
                                                    class="required">*</span></label>

                                                    <select class="form-select state" name="ref_state_id" id="ref_state_id" required>
                                            <option value="">Select State</option>
                                            @forelse(getAllState() as $state)
                                                <option value="{{ $state->id }}">
                                                    {{ $state->state_name }}</option>
                                            @empty
                                            @endforelse
                                        </select>
                                        </div>
                                        <div class="col-xxl-9 col-md-6 gy-3">
                                            <label for="labelInput" class="form-label">District Name <span
                                                    class="required">*</span></label>

                                                    <select class="form-select district" name="ref_district_id" id="ref_district_id"
                                                    required>
                                                    @forelse(getDistrictByStateID(old('state')) as $district)
                                                    <option value="{{ $district->id }}"
                                                        @selected(old('district')==$district->id)>
                                                        {{ $district->district_name }}</option>
                                                    @empty
                                                    <option value="">-Select District-</option>
                                                    @endforelse


                                                </select>
                                        </div>
                                        <div class="col-xxl-9 col-md-6 gy-3">
                                            <label for="labelInput" class="form-label">Village Name <span
                                                    class="required">*</span></label>

                                            <input type="text" class="form-control" id="" placeholder=""
                                            name="city_name" value="" />
                                        </div>
                                        <div class="col-xxl-9 col-md-6 gy-3">
                                            <label for="labelInput" class="form-label">Pin <span
                                                    class="required">*</span></label>

                                            <input type="text" class="form-control numbersonly" maxlength="6"  name="pin" value=""
                                            required />
                                        </div>




                                    </div>
                                </div>

                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped align-middle dataTable no-footer"
                                        width="100%" id="datatable">
                                        <thead>
                                            <tr>
                                                <th>S.No.</th>
                                                <th>Required Document</th>
                                                <th>Upload Documents</th>
                                                <!-- <th>Action</th> -->

                                            </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                                <td>1</td>
                                                <td>Document For Address Change</td>
                                                <td>
                                                    <input type="file" class="form-control" name="address_document_upload" accept="image/png, application/pdf, image/jpeg">
                                                </td>
                                                <!-- <td>
                                                    <a href="" id="uploadButton">Upload</a>
                                                </td> -->
                                            </tr>


                                        </tbody>

                                    </table>
                                </div>
                                <div class="col-xxl-6 col-md-4  gy-3">
                                    <div>
                                        <label for="labelInput" class="form-label">Remarks : <span
                                                class="required">*</span></label>

                                        <textarea placeholder="Remark Here" class="form-control customtextarea" name="remarks" maxlength="100"></textarea>

                                    </div>
                                </div>


                            </div>
                            <div class="row white-inner logo-change">
                                <div class="col-xxl-3 col-md-4 ">
                                    <div>
                                        <label for="labelInput" class="form-label">Logo Change : <span
                                                class="required">*</span></label>

                                    </div>
                                </div>


                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped align-middle dataTable no-footer"
                                        width="100%" id="datatable">
                                        <thead>
                                            <tr>
                                                <th>S.No.</th>
                                                <th>Required Document</th>
                                                <th>Upload Documents</th>
                                                <!-- <th>Action</th> -->

                                            </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                                <td>1</td>
                                                <td>Organization Logo</td>
                                                <td>
                                                    <input type="file" class="form-control" name="logo_change_document_upload" accept="image/png, application/pdf, image/jpeg">
                                                </td>
                                                <!-- <td>
                                                    <a href="" id="uploadButton">Upload</a>
                                                </td> -->
                                            </tr>

                                        </tbody>

                                    </table>
                                </div>

                                <div class="col-xxl-6 col-md-4  gy-3">
                                    <div>
                                        <label for="labelInput" class="form-label">Remarks : <span
                                                class="required">*</span></label>

                                        <textarea placeholder="Address" class="form-control customtextarea" name="remarks" maxlength="100"></textarea>

                                    </div>
                                </div>


                            </div>
                            <div class="row white-inner legal-status">
                                <div class="col-xxl-3 col-md-4 ">
                                    <div>
                                        <label for="labelInput" class="form-label">Legal Status : <span
                                                class="required">*</span></label>
                                        <select class="form-select" name="legal_status" id="legal_status" required>
                                            <option value="">-Select-</option>
                                            <option value="Legal Status 1">Legal Status 1</option>
                                            <option value="Legal Status 2">Legal Status 2</option>
                                            <option value="Legal Status 3">Legal Status 3</option>

                                        </select>

                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped align-middle dataTable no-footer"
                                        width="100%" id="datatable">
                                        <thead>
                                            <tr>
                                                <th>S.No.</th>
                                                <th>Required Document</th>
                                                <th>Upload Documents</th>
                                                <!-- <th>Action</th> -->

                                            </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                                <td>1</td>
                                                <td>Registration certificate including its legal status</td>
                                                <td>
                                                    <input type="file" class="form-control" name="legal_status_document_upload" accept="image/png, application/pdf, image/jpeg">
                                                </td>
                                                <!-- <td>
                                                    <a href="" id="uploadButton">Upload</a>
                                                </td> -->
                                            </tr>


                                        </tbody>

                                    </table>
                                </div>
                                <div class="col-xxl-6 col-md-4  gy-3">
                                    <div>
                                        <label for="labelInput" class="form-label">Remarks : <span
                                                class="required">*</span></label>

                                        <textarea placeholder="Address" class="form-control customtextarea" name="remarks" maxlength="100"></textarea>

                                    </div>
                                </div>


                            </div>
                            <!-- <div class="row white-inner addition-processing">
                                <div class="col-xxl-3 col-md-4 ">
                                    <div>
                                        <label for="labelInput" class="form-label">Addition of Processing and Handling : <span
                                                class="required">*</span></label>

                                    </div>
                                </div>

                            </div> -->

                            <div class="row white-inner processing-addition">

                                <div class="table-responsive">
                                      <table class="table table-bordered table-striped align-middle dataTable no-footer"
                                          width="100%" id="datatable">
                                          <thead>
                                              <tr>
                                                  <th>S.No.</th>
                                                  <th>Required Document</th>
                                                  <th>Upload Documents</th>
                                                  <!-- <th>Action</th> -->

                                              </tr>
                                          </thead>
                                          <tbody>
                                          <tr>
                                                  <td>1</td>
                                                  <td>Any other Supportive Document for Processing and Handling </td>
                                                  <td>
                                                      <input type="file" class="form-control" name="supporting_document_upload" accept="image/png, application/pdf, image/jpeg">
                                                  </td>
                                                  <!-- <td>
                                                      <a href="" id="uploadButton">Upload</a>
                                                  </td> -->
                                              </tr>


                                          </tbody>

                                      </table>
                                  </div>
                                  <div class="col-xxl-6 col-md-4  gy-3">
                                      <div>
                                          <label for="labelInput" class="form-label">Remarks : <span
                                                  class="required">*</span></label>

                                          <textarea placeholder="remark here" class="form-control customtextarea" name="remarks" maxlength="100"></textarea>

                                      </div>
                                  </div>
                              </div>




                            <div class="row white-inner accreditation-extension">
                                <div class="col-xxl-3 col-md-4 ">
                                    <div>
                                        <label for="labelInput" class="form-label">Accreditation Existing Validity : <span
                                                class="required">*</span></label>
                                                <input type="text" class="form-control " name="accreditation_existing_validity"
                                                value="{{ old('at_user_id', $userid->date_of_registration) }}" maxlength="" />

                                    </div>
                                </div>
                                <div class="col-xxl-3 col-md-4 ">
                                    <div>
                                        <label for="labelInput" class="form-label">Accreditation Extended Validity Upto : <span
                                                class="required">*</span></label>
                                         <input type="date" class="form-control " name="extended_accreditation_validity"
                                                value="" maxlength="" />

                                    </div>
                                </div>

                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped align-middle dataTable no-footer"
                                        width="100%" id="datatable">
                                        <thead>
                                            <tr>
                                                <th>S.No.</th>
                                                <th>Required Document</th>
                                                <th>Upload Documents</th>
                                                <!-- <th>Action</th> -->

                                            </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                                <td>1</td>
                                                <td>Other Document For Extended Validity Upto:</td>
                                                <td>
                                                    <input type="file" class="form-control" name="extended_accreditation_validity_document_upload" accept="image/png, application/pdf, image/jpeg">
                                                </td>
                                                <!-- <td>
                                                    <a href="" id="uploadButton">Upload</a>
                                                </td> -->
                                            </tr>


                                        </tbody>

                                    </table>
                                </div>
                                <div class="col-xxl-6 col-md-4  gy-3">
                                    <div>
                                        <label for="labelInput" class="form-label">Remarks : <span
                                                class="required">*</span></label>

                                        <textarea placeholder="Address" class="form-control customtextarea" name="remarks" maxlength="100"></textarea>

                                    </div>
                                </div>

                            </div>




                            <!-- <div class="row white-inner">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped align-middle dataTable no-footer"
                                        width="100%" id="datatable">
                                        <thead>
                                            <tr>
                                                <th>S.No.</th>
                                                <th>Required Document</th>
                                                <th>Upload Documents</th>
                                                <th>Action</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                                <td>1</td>
                                                <td>Policies for the scope applied under NPOP</td>
                                                <td>
                                                    <input type="file" class="form-control" name="name_document_upload" accept="image/png, application/pdf, image/jpeg">
                                                </td>
                                                <td>
                                                    <a href="" id="uploadButton">Upload</a>
                                                </td>
                                            </tr>


                                        </tbody>

                                    </table>
                                </div>

                            </div> -->
                            <div class="row">
                                <div class="col-lg-12 gy-4">
                                    <div class="hstack gap-2">
                                        <button type="submit" class="btn btn-primary" id="submitbtn">
                                            Save & Continue
                                        </button>
                                        <!-- <button type="" class="btn btn-primary" id="submitbtn">
                                            Final Submit
                                        </button> -->
                                        {{-- <a href="{{ route('superadmin.icsuser.step2', $userdetails->id) }}"
                                                    class="btn btn-soft-success">
                                                    Next
                                                </a> --}}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
@endsection
@push('script')
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $("#registration").validate({
            rules: {

            },
            messages: {

            }

        });


        $(document).ready(function() {

        $(".name-change, .address-change, .logo-change, .legal-status, .processing-addition, .accreditation-extension").hide();


        $("#change_dive").change(function() {
            var selectedOption = $(this).val();
            // alert(selectedOption);

            $(".name-change, .address-change, .logo-change, .legal-status, .processing-addition, .accreditation-extension").hide();

            if (selectedOption === "name") {
                $(".name-change").show();
            } else {
                $(".name-change").hide();
            }

            if (selectedOption === "address") {
                $(".address-change").show();
            } else {
                $(".address-change").hide();
            }
            if (selectedOption === "logo") {
                $(".logo-change").show();
            } else{
                $(".logo-change").hide();
            }
            if (selectedOption === "legal_status") {
                $(".legal-status").show();
            } else {
                $(".legal-status").hide();
            }
            if (selectedOption === "processing") {
                $(".processing-addition").show();
            } else{
                $(".processing-addition").hide();
            }
             if (selectedOption === "accreditation") {
                $(".accreditation-extension").show();
            }else{
                $(".accreditation-extension").hide();
            }
        });
});

</script>

<script>

    // $(document).ready(function() {
    //     $('#uploadButton').on('click', function(e) {
    //         e.preventDefault();

    //         var fileInput = $('input[name="name_document_upload"]')[0];
    //         var file = fileInput.files[0];
    //         var formData = new FormData();
    //         formData.append('name_document_upload', file);

    //         $.ajax({
    //             type: 'POST',
    //             url: '{{ route('superadmin.accrAmendmentSave') }}',
    //             data: formData,
    //             processData: false,
    //             contentType: false,
    //             success: function(response) {
    //                 alert(response.success);
    //             },

    //             error: function(xhr, status, error) {
    //                 alert('Choose File');
    //             }
    //         });
    //     });
    // });


</script>




@endpush

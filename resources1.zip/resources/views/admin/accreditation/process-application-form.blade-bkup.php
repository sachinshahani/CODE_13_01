@extends(?admin.layouts.app?)

@section('content')
<style? .customtextarea { height: 80px; } ?/style? ?!-- start page title --? <div class="row">
    ?div class=?col-12??
    ?div class=?page-title-box d-sm-flex align-items-center justify-content-between??
    <h4 class="mb-sm-0">Update Actual Yield
        ?/h4?

        <div class="page-title-right">
            ?ol class=?breadcrumb m-0??
            ?li class=?breadcrumb-item???a href=?javascript: void(0);??Dashboard?/a??/li?
            <li class="breadcrumb-item active">Update Actual Yield</li>
            ?/ol?
            ?/div?
        </div>
        ?/div?
        ?/div? ?!-- end page title --?
        <form method="post" enctype="multipart/form-data" id="registration" action=?{{
            route(?superadmin.processApplicationFormSubmit?) }}?? @csrf ?div class=?tab-content py-4
            custom-tab-content">
            ?div class=?tab-pane fade show active? id=?step1??
            ?div class=?card??
            <div class="card-header align-items-center d-flex">
                ?h4 class=?card-title mb-0 flex-grow-1??
                Name of the Operator
    </h4>
    ?div class=?flex-shrink-0??
    @if (session(?error?))
    <div class="alert alert-danger">
        {{ session(?error?) }}
        ?/div?
        @endif
        @if (session(?success?))
        ?div class=?alert alert-success??
        {{ session('success') }}
        ?/div?
        @endif
        @if ($errors)
        @foreach ($errors-?all() as $error)
        ?div class=?alert alert-danger??{{ $error }}?/div?
        @endforeach
        @endif
        ?/div?
    </div>

    ?!-- end card header --?
    <div class="card-body">
        ?div class=?live-preview??
        ?div class=?row white-inner??
        <div class="col-xxl-3 col-md-4">
            ?div?
            ?label class=?form-label??Application Type : ?span class=?required??*?/span??/label?
            <br>
            ?input type=?radio? id=?html? name=?application_type? value=?new? checked?
            ?label for=?new??New?/label>

            ?/div?
            ?/div>

            ?div class=?col-xxl-3 col-md-4??
            ?div?
            <label for="labelInput" class="form-label">Scope of Accreditation : <span class=?required??*?/span??/label?
                    ?br? <a target="_BLANK" href="" class="text-decoration-underline">See Doc</a>
                    ?/div?
                    ?/div>

                    ?div class=?col-xxl-3 col-md-4??
                    ?div?
                    <label for="basiInput" class="form-label"> Category of Accreditation : <span
                            class=?required??*?/span? ?/label>

                            ?select class=?form-select? name=?document_type? id=?document_type? required?
                            ?option value=???-Select-?/option?
                            <option value="Aquaculture Production">Aquaculture Production : </option>

                            ?/select>

                            ?/div?
                            ?/div>

                            ?div class=?col-xxl-3 col-md-4??
                            ?div?
                            <label for="labelInput" class="form-label">CB Name/Organization Name : <span
                                    class=?required??*?/span??/label? ?input type=?text? class=?form-control?
                                    name=?first_name? value=?? required />
                                ?/div?
                                ?/div>

                                ?div class=?col-xxl-3 col-md-4 gy-3??
                                ?div?
                                <label for="labelInput" class="form-label">CB /Organization Head Name : <span
                                        class=?required??*?/span??/label? ?input type=?text? class=?form-control?
                                        name=?last_name? value=?? required />
        </div>
    </div>

    <div class="col-xxl-3 col-md-4 gy-3">
        <div>
            <label for="labelInput" class="form-label">CB /Organization Head Designation : <span
                    class="required">*</span></label>
            <input type="text" class="form-control" name="designation" value="" required />
        </div>
    </div>
    <div class="col-xxl-3 col-md-4 gy-3">
        <div>
            <label for="labelInput" class="form-label">Contact Person Name : <span class="required">*</span></label>
            <input type="text" class="form-control" name="contact_person_first_name" value="" required />
        </div>
    </div>
    <div class="col-xxl-3 col-md-4 gy-3">
        <div>
            <label for="labelInput" class="form-label">Contact Person Mobile No. : <span
                    class="required">*</span></label>
            <input type="text" class="form-control" name="contact_person_mobile_number" value="" required />
        </div>
    </div>
    <div class="col-xxl-3 col-md-4 gy-3">
        <div>
            <label for="labelInput" class="form-label">Contact Person Email ID : <span class="required">*</span></label>
            <input type="email" class="form-control" name="contact_person_email" value="" required />
        </div>
    </div>
    <div class="col-xxl-3 col-md-4 gy-3">
        <div>
            <label class="form-label">Is your registered or Operational Address same ? : <span
                    class="required">*</span></label>
            <br>
            <input type="radio" id="html" name="add" value="yes" checked>
            <label for="new">Yes</label>

            <input type="radio" id="html" name="add1" value="no">
            <label for="new">No</label>

        </div>
    </div>
    <div class="col-xxl-3 col-md-4 gy-3">
        <div>
            <label class="form-label">CB /Organization Address Type: <span class="required">*</span></label>
            <br>
            <input type="radio" id="html1" name="addressowned" value="Owned" checked>
            <label for="new">Owned</label>

            <input type="radio" id="html1" name="addressrent" value="Lease/Rent">
            <label for="new">Lease/Rent</label>

        </div>
    </div>

    <div class="col-xxl-3 col-md-4 gy-3">
        <div>
            <label class="form-label">CB /Organization registered office address: <span
                    class="required">*</span></label>
            <br>
            <textarea placeholder="Address" class="form-control customtextarea" name="address" required></textarea>


        </div>
    </div>
    <div class="col-xxl-3 col-md-4">
        <div>
            <label for="labelInput" class="form-label">Country <span class="required">*</span></label>

            <select class="form-select" name="country" id="country" required>
                <option value="">-Select-</option>
                <option value="india">India</option>

            </select>

        </div>
    </div>
    <div class="col-xxl-3 col-md-4">
        <div>
            <label for="labelInput" class="form-label">State <span class="required">*</span></label>



            <select class="form-select state" name="ref_state_id" id="ref_state_id" required>
                <option value="">Select State</option>
                @forelse(getAllState() as $state)
                <option value="{{ $state->id }}" @selected(old('state')==$state->id)>
                    {{ $state->state_name }}</option>
                @empty
                @endforelse
            </select>






        </div>
    </div>

    <div class="col-xxl-3 col-md-4">
        <div>
            <label for="labelInput" class="form-label">District <span class="required">*</span></label>
            <input type="hidden" name="ref_district_id" value="">


            <select class="form-select district" name="ref_district_id" id="ref_district_id" required>
                @forelse(getDistrictByStateID(old('state')) as $district)
                <option value="{{ $district->id }}" @selected(old('district')==$district->id)>
                    {{ $district->district_name }}</option>
                @empty
                <option value="">-Select District-</option>
                @endforelse


            </select>

        </div>
    </div>
    <div class="col-xxl-3 col-md-4">
        <div>
            <label for="labelInput" class="form-label">Taluka/Mandal
                <span class="required">*</span></label>
            <input type="hidden" name="ref_block_tehsil_id" value="">


            <select class="form-select block_tehsil" name="ref_block_tehsil_id" id="ref_block_tehsil_id" required>

                @forelse(getBlockTehsilByDistrictID(old('district')) as $block)
                <option value="{{ $block->id }}" @selected(old('taluka')==$block->id)>
                    {{ $block->block_tehsil_name }}</option>
                @empty
                <option value="">-Select Taluka/Mandal-</option>
                @endforelse


            </select>


        </div>
    </div>
    <div class="col-xxl-3 col-md-4 gy-3">
        <div>
            <label class="form-label">Village </label>
            {{-- <input type="hidden" name="ref_village_id" value=""> --}}
            {{-- <input type="text" class="form-control" id="" placeholder="" name="ref_village_id" value="" /> --}}

            <select class="form-select village" name="ref_village_id" required>
                <option value="">Select Village</option>
                @forelse(getVillageByBlock(old('ref_village_id')) as $village)
                <option value="{{ $village->id }}" @if (isset($value) && $value->ref_village_id == $village->id)
                    selected @endif>
                    {{ $village->village_name }}</option>
                @empty
                <option value="">-Select Village-</option>
                @endforelse
            </select>

        </div>
    </div>

    <div class="col-xxl-3 col-md-4 gy-3">
        <div>
            <label for="labelInput" class="form-label">Pin Code<span class="required">*</span></label>
            <input type="text" class="form-control numbersonly" name="pin" value="" maxlength="6" required />
        </div>
    </div>
    <div class="col-xxl-3 col-md-4 gy-3">
        <div>
            <label for="labelInput" class="form-label">Office Phone Number (landline) with Std
                Code : <span class="required">*</span></label>
            <input type="text" class="form-control numbersonly" name="office_phone_number" value="" maxlength="6"
                required />
        </div>
    </div>
    <div class="col-xxl-3 col-md-4 gy-3">
        <div>
            <label for="labelInput" class="form-label">Fax No : <span class="required">*</span></label>
            <input type="text" class="form-control numbersonly" name="fax" value="" maxlength="6" required />
        </div>
    </div>
    <div class="col-xxl-3 col-md-4 gy-3">
        <div>
            <label for="labelInput" class="form-label">CB/Organization Email ID : <span
                    class="required">*</span></label>
            <input type="email" class="form-control numbersonly" name="email" value="" maxlength="" required />
        </div>
    </div>
    <div class="col-xxl-3 col-md-4 gy-3">
        <div>
            <label for="labelInput" class="form-label">Website Address: <span class="required">*</span></label>
            <input type="text" class="form-control numbersonly" name="website_address" value="" maxlength="" required />
        </div>
    </div>

    <div class="col-xxl-3 col-md-4  gy-3">
        <div>
            <label for="labelInput" class="form-label">Legal Status: <span class="required">*</span></label>

            <select class="form-select" name="legal_status" id="legal_status" required>
                <option value="">-Select-</option>
                <option value="india">Registered Company</option>

            </select>

        </div>
    </div>
    <div class="col-xxl-3 col-md-4  gy-3">
        <div>
            <label for="labelInput" class="form-label">Year of Establishment <span class="required">*</span></label>

            <select class="form-select" name="year_of_establishment" id="year_of_establishment" required>
                <option value="">-Select-</option>
                <option value="2021">2021</option>
                <option value="2022">2023</option>

            </select>

        </div>
    </div>
    <div class="col-xxl-3 col-md-4  gy-3">
        <div>
            <label for="labelInput" class="form-label">Date of Establishment the certification
                Programme : <span class="required">*</span></label>

            <input type="date" class="form-control numbersonly" name="date_of_establishment" value="" maxlength=""
                required />

        </div>
    </div>
    <div class="col-xxl-3 col-md-4  gy-3">
        <div>
            <label for="labelInput" class="form-label">GST No : <span class="required">*</span></label>

            <input type="text" class="form-control numbersonly" name="gst_no" value="" maxlength="" required />

        </div>
    </div>


    </div>
    <div class="row white-inner">
        <div class="col-xxl-6 col-md-4  gy-3">
            <div>
                <label for="labelInput" class="form-label">Any Other additional information you
                    wish to specify.(Max 100) : <span class="required">*</span></label>

                <textarea placeholder="Address" class="form-control customtextarea" name="descriptions"
                    maxlength="100"></textarea>

            </div>
        </div>
    </div>
    <div class="row seperatesec  white-inner">
        <div class="sectitle">
            <label for="labelInput" class="form-label ">Details of Top Management
                Officials(MD/CEO/Director/President/Chairman/CMD) and
                Operating officials Involved in the inspection and certification of scope applied
                for (Eg: Quality Manager, Evaluator, Reviewer, Inspectors)
            </label>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered table-striped align-middle dataTable no-footer " width="100%"
                id="certificationbody_tbl">
                <thead>
                    <tr>
                        <th>Employee Type</th>
                        <th>Name</th>
                        <th>Designation</th>
                        <th>Qualification
                            (Graduate
                            /PG/PHD)</th>
                        <th>Total Experience
                            (in years)</th>
                        <th>Date of Joining</th>
                        <th>Trainings</th>
                        <th>Bio Data</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <select class="form-select required-entry" name="employee_type" id="employee_type">
                                <option value="">-Select-</option>
                                <option value="Top Management">Top Management</option>
                            </select>
                        </td>
                        <td><input type="text" class="form-control required-entry" value="" name="name[]" id="name" />
                        </td>
                        <td><select class="form-select required-entry" name="desination[]" id="desination">
                                <option value="">-Select-</option>
                                <option value="Chairman">Chairman</option>
                            </select></td>
                        <td><input type="text" class="form-control required-entry" value="" name="qualification[]"
                                id="qualification" /> </td>
                        <td><input type="text" class="form-control required-entry numbersonly" value=""
                                name="total_experiance[]" id="total_experiance" />
                        </td>
                        <td><input type="date" class="form-control required-entry" value="" name="date_of_joining[]"
                                id="date_of_joining" />
                        </td>
                        <td><input type="text" class="form-control" value="" name="training[]" id="training" />
                        </td>
                        <td> <input type="file" class="form-control" name="upload_biodata[]" id="upload_biodata"
                                accept="image/png, application/pdf, image/jpeg">
                        </td>
                        <td>

                            <a class="btn btn-primary add_certificationbody">Add</a>
                        </td>
                    </tr>
                </tbody>

            </table>
        </div>


    </div>
    <!-- <div class="row seperatesec  white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label ">List of Supporting Document Required to upload
                                        </label>
                                    </div>
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped align-middle dataTable no-footer"
                                            width="100%" id="datatable">
                                            <thead>
                                                <tr>
                                                    <th>S.No.</th>
                                                    <th>Required Document</th>
                                                    
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>
                                                       1
                                                    </td>
                                                    <td>Policies for thescope applied under NPOP</td>
                                                   
                                                </tr>
                                            </tbody>

                                        </table>
                                    </div>


                                </div> -->
    <div class="row seperatesec  white-inner">
        <div class="sectitle">
            <label for="labelInput" class="form-label ">List of Scan document to be uploaded
            </label>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered table-striped align-middle dataTable no-footer" width="100%"
                id="datatable">
                <thead>
                    <tr>
                        <th>S.No.</th>
                        <th>Required Document</th>
                        <th>Upload Documents</th>
                        <th>Action</th>
                    </tr>
                </thead>
                @foreach ($data as $res)
                <tbody>
                    <tr>
                        <td> {{ $res->id }} </td>
                        <td>{{ $res->document_name }}</td>
                        <td class="file_upload"> <input type="file" class="form-control " name="document_upload"
                                accept="image/png, application/pdf, image/jpeg">

                        </td>
                        <td class="upload_btn">
                            <button type="button" class="upload-button btn btn-primary"
                                data-id="{{ $res->id }}">Upload</button>

                        </td>
                    </tr>
                </tbody>
                @endforeach
            </table>
        </div>



    </div>

    <div class="row seperatesec  white-inner">
        <div class="sectitle">
            <label for="labelInput" class="form-label ">Declaration
            </label>
        </div>

        <div class="col-xxl-3 col-md-4  gy-3">
            <div>
                <label for="labelInput" class="form-label">Name: <span class="required">*</span></label>

                <input type="text" class="form-control " name="first_name" value="" maxlength="" required />

            </div>
        </div>
        <div class="col-xxl-3 col-md-4  gy-3">
            <div>
                <label for="labelInput" class="form-label">Designation: <span class="required">*</span></label>

                <input type="text" class="form-control " name="designation" value="" maxlength="" required />

            </div>
        </div>

        <div class="col-xxl-3 col-md-4  gy-3">
            <div>
                <label for="labelInput" class="form-label">Date: <span class="required">*</span></label>

                <input type="date" class="form-control " name="date_of_registration" value="" maxlength="" required />

            </div>
        </div>
        <div class="col-xxl-3 col-md-4  gy-3">
            <div>
                <label for="labelInput" class="form-label">Signature: <span class="required">*</span></label>

                <input type="file" class="form-control" name="signature" id=""
                    accept="image/png, application/pdf, image/jpeg">

            </div>
        </div>
        <div class="col-xxl-3 col-md-4 gy-3">
            <div>
                <label class="form-label">Payment Mode : <span class="required">*</span></label>
                <br>
                <input type="radio" id="html" name="app_type" value="Online" checked>
                <label for="new">Online</label>

            </div>
        </div>

    </div>




    <div class="row">
        <div class="col-lg-12 gy-4">
            <div class="hstack gap-2">
                <button type="submit" class="btn btn-primary" id="submitbtn">
                    Save & Next
                </button>
                {{-- <a href="{{ route('superadmin.icsuser.step2', $userdetails->id) }}" class="btn btn-soft-success">
                    Next
                </a> --}}
            </div>
        </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </form>

    @endsection
    @push('script')
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $("#registration").validate({
            rules: {

            },
            messages: {

            }

        });
        // Dropzone has been added as a global variable.

        $('.add_certificationbody').on('click', function () {
            
                
            $("#certificationbody_tbl tbody").append('<tr class="cer_tr"> <td> <select class="form-select required-entry" name="employee_type" id="employee_type" > <option value="">-Select-</option> <option value="Top Management">Top Management</option> </select> </td> <td><input type="text" class="form-control required-entry" value="" name="name[]" id="name" /> </td> <td><select class="form-select required-entry" name="desination[]" id="desination"> <option value="">-Select-</option> <option value="Chairman">Chairman</option> </select></td> <td><input type="text" class="form-control required-entry" value="" name="qualification[]" id="qualification" /> </td> <td><input type="text" class="form-control required-entry numbersonly" value="" name="total_experiance[]" id="total_experiance" /> </td> <td><input type="date" class="form-control required-entry" value="" name="date_of_joining[]" id="date_of_joining"/> </td> <td><input type="text" class="form-control" value="" name="training[]" id="training" /> </td> <td> <input type="file" class="form-control" name="upload_biodata[]"  id="upload_biodata" accept="image/png, application/pdf, image/jpeg"> </td> <td> <a class="btn btn-danger remove" >Remove</a> </td> </tr>'); 

      
   });
   $("body").on("click", ".remove", function() {
       //alert('ss');
           $(this).parents(".cer_tr").remove();
   });
   $(document).ready(function() {

$('.upload-button').click(function() {
    // var href='{{ asset('/') }}';
    //              alert(href);
    //              return false;
    var th = $(this);
    var fileInput = $(this).closest('tr').find('input[type="file"]')[0].files[0];
    var documentId = $(this).data('id');

    if (fileInput) {
        var formData = new FormData();
        formData.append('document_upload', fileInput);
        formData.append('document_id', documentId);

        $.ajax({
            url: '{{ route('file.upload') }}',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function(response) {

                console.log(response);
                console.log(response.success);
                
               if(response.success=='done'){
                 
                th.closest('tr').find('.file_upload').html('<input type="hidden" name="document_upload_edit" value="' + response.file + '"> <a target="_BLANK" href="' + response.path + '" class="text-decoration-underline">See Doc</a>');
                th.closest('tr').find('.upload_btn').html('<a class="mdi mdi-delete btn btn-soft-danger deletedata" data-id="'+ response.id+'" data-value="'+ documentId +'"></a>');
                
               }else{
                th.closest('tr').find('.file_upload').html('<input type="file" class="form-control " name="document_upload" accept="image/png, application/pdf, image/jpeg">');
                th.closest('tr').find('.upload_btn').html('<button type="button" class="upload-button btn btn-primary" data-id="{{ $res->id }}">Upload</button>');
               }
               
            }
        });
    } else {
        alert('Please select a file to upload.');
    }
});
});
$(document).on('click', '.deletedata', function() {
            var ths = $(this);
            var id = $(this).attr('data-id');
            var cba_id = $(this).attr('data-value');

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.value) {
                    $.ajax({
                        url: "{{ route('superadmin.deleteFile') }}",
                        method: "POST",
                        dataType: 'json',
                        data: {
                            'id': id,
                        },
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function(result) {
                            console.log(result);
                           // Swal.fire('Deleted!', 'Record Deleted Successfully..', 'success');
                           if(result.message=='done'){
                             
                                ths.closest('tr').find('.file_upload').html('<input type="file" class="form-control " name="document_upload" accept="image/png, application/pdf, image/jpeg">');
                                ths.closest('tr').find('.upload_btn').html('<button type="button" class="upload-button btn btn-primary" data-id="'+cba_id+'">Upload</button>'); 
                             
                            }
                        }

                    });
                }
            });
        });
    </script>

    @endpush
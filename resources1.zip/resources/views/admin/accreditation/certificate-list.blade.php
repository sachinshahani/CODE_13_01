@extends('admin.layouts.app_acc')
@section('content')

    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0"></h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);"></a></li>
                        <li class="breadcrumb-item active"></li>
                    </ol>
                </div>

            </div>
        </div>
    </div>

    <div class="row seperatesec  white-inner">
        <div class="sectitle">
            <label for="labelInput" class="form-label  blue-ht">List of Issued Certificate(s)</label>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered table-striped align-middle dataTable no-footer"
                width="100%" id="datatable">
                <thead>
                    <tr>
                        <th>S.No.</th>
                        <th>Reference No.</th>
                        <th>MD/CEO/Director Name</th>
                        <th>CB/Organization Name</th>
                        <th>CB/Organization Registered Address</th>
                        <th>Application Type</th>
                        <th>Scope of Accreditation</th>
                        <th>Application Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td colspan="9">No Application available for process.</td>
                    </tr>
                </tbody>

            </table>
        </div>


    </div>
@endsection

@push('script')

@endpush

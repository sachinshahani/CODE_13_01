@extends('admin.layouts.app_acc')

@section('content')
    <style>
        .customtextarea {
            height: 80px;
        }
    </style> <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">New Registration
                </h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">New Registration</li>
                    </ol>
                </div>
            </div>
        </div>
    </div> <!-- end page title -->
    <form method="post" enctype="multipart/form-data" id="registration"
        action="{{ route('superadmin.processApplicationFormSubmit') }}"> @csrf <div
            class="tab-content
        py-4 custom-tab-content">
            <div class="tab-pane fade show active" id="step1">
                <div class="card">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1">
                            APPLICATION FORM FOR EXTENSION OF SCOPE OF ACCREDITATION UNDER NPOP
                        </h4>
                        {{-- <div class="flex-shrink-0">
                            @if (session('error'))
                                <div class="alert alert-danger">
                                    {{ session('error') }}
                                </div>
                            @endif
                            @if (session('success'))
                                <div class="alert alert-success">
                                    {{ session('success') }}
                                </div>
                            @endif
                            @if ($errors)
                                @foreach ($errors->all() as $error)
                                    <div class="alert alert-danger">{{ $error }}</div>
                                @endforeach
                            @endif
                        </div> --}}
                    </div>
                    <input type="hidden" name="application_id" value="{{ $userid }}">
                    <!-- end card header -->
                    <div class="card-body">
                        <div class="live-preview">
                            <div class="row white-inner">
                                <div class="col-xxl-3 col-md-4">
                                    <div>
                                        <label class="form-label">Application Type : <span class="">*</span></label>
                                        <br>
                                        <input type="radio" id="new" name="application_type"
                                            value="new"{{ old('application_type', $app->application_type ?? '') == 'new' ? ' checked' : '' }}>
                                        <label for="new">New</label>

                                        <input type="radio" id="exiting" name="application_type"
                                            value="Exiting"{{ old('application_type', $app->application_type ?? '') == 'Exiting' ? ' checked' : '' }}>
                                        <label for="exiting">Exiting</label>
                                    </div>

                                </div>

                                {{-- <div class="col-xxl-3 col-md-4">
                                    <div>
                                        <label for="labelInput" class="form-label">Scope of Accreditation : </label>
                                        <br>
                                       <a target="_BLANK" href="" class="text-decoration-underline">See Doc</a>
                                    </div>
                                </div> --}}

                                <div class="col-xxl-3 col-md-4">
                                    <div>
                                        <label for="basiInput" class="form-label"> Category of Accreditation : <span
                                                class="">*</span></label>
                                        <select class="form-select" name="category_type" id="category_type">


                                            <option
                                                value="Aquaculture Production"{{ old('category_type', $app->category_type ?? '') === 'Aquaculture Production' ? 'selected' : '' }}>
                                                Aquaculture Production</option>
                                            <option
                                                value="Livestock, Poultry Products including Apiculture"{{ old('category_type', $app->category_type ?? '') === 'Livestock,Poultry Products including Apiculture' ? 'selected' : '' }}>
                                                Livestock,
                                                Poultry Products including Apiculture
                                            </option>
                                            <option
                                                value="Animal Feed Processing Handling"{{ old('category_type', $app->category_type ?? '') === 'Animal Feed Processing Handling' ? 'selected' : '' }}>
                                                Animal Feed Processing Handling
                                            </option>
                                            <option
                                                value="Mushroom Production"{{ old('category_type', $app->category_type ?? '') === 'Mushroom Production' ? 'selected' : '' }}>
                                                Mushroom Production</option>
                                            <option
                                                value="Seaweed,Aquatic Plants and GreenHouse Crop Production"{{ old('category_type', $app->category_type ?? '') === 'Seaweed,Aquatic Plants and GreenHouse Crop Production' ? 'selected' : '' }}>
                                                Seaweed,Aquatic Plants and GreenHouse Crop Production
                                            </option>
                                            <option
                                                value="Apiculture"{{ old('category_type', $app->category_type ?? '') === 'Apiculture' ? 'selected' : '' }}>
                                                Apiculture</option>

                                        </select>
                                    </div>
                                </div>

                                <div class="col-xxl-3 col-md-4">
                                    <div>
                                        <label for="labelInput" class="form-label">CB Name/Organization Name : <span
                                                class="">*</span></label>
                                        <input type="text" class="form-control" name="name"
                                            value="{{ old('first_name', Auth::guard('misadmin')->user()->first_name) }}"
                                            readonly />
                                    </div>
                                </div>

                                <div class="col-xxl-3 col-md-4 gy-3">
                                    <div>
                                        <label for="labelInput" class="form-label">CB/Organization Head Name : <span
                                                class="">*</span></label>
                                        <input type="text" class="form-control" name="cb_head_name"
                                            value="{{ old('cb_head_name', $app->cb_head_name ?? '') }}"
                                            placeholder="Enter Head Name" />
                                    </div>
                                </div>

                                <div class="col-xxl-3 col-md-4 gy-3">
                                    <div>
                                        <label for="labelInput" class="form-label">CB /Organization Head Designation : <span
                                                class="">*</span></label>


                                        {{-- @dd($app->ref_designation_master_id) --}}
                                        <select class="form-select state" name="ref_designation_master_id"
                                            id="ref_designation_master_id">
                                            <option value="">Select Designation</option>
                                            @forelse(getAllDesignation() as $designation)
                                                <option
                                                    value="{{ $designation->id }}"{{ old('ref_designation_master_id') == $designation->ref_designation_master_id ?  'selected' : '' }}>
                                                    {{ $designation->designation_name }}</option>
                                            @empty
                                            @endforelse
                                        </select>


                                    </div>
                                </div>
                                <div class="col-xxl-3 col-md-4 gy-3">
                                    <div>
                                        <label for="labelInput" class="form-label">Contact Person Name : <span
                                                class="required">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Contact Person Name"
                                            required name="contact_person_first_name"
                                            value="{{ old('contact_person_first_name', $app->contact_person_first_name ?? '') }}" />
                                    </div>
                                </div>
                                <div class="col-xxl-3 col-md-4 gy-3">
                                    <div>
                                        <label for="labelInput" class="form-label">Contact Person Mobile No. : <span
                                                class="">*</span></label>
                                        <input type="text" class="form-control numbersonly"
                                            name="contact_person_mobile_number"
                                            value="{{ old('contact_person_mobile_number', $app->contact_person_mobile_number ?? '') }}"
                                            maxlength="10" placeholder="Enter Contact Person Mobile No" />
                                    </div>
                                </div>
                                <div class="col-xxl-3 col-md-4 gy-3">
                                    <div>
                                        <label for="labelInput" class="form-label">Contact Person Email: <span
                                                class="">*</span></label>
                                        <input type="email" class="form-control"
                                            placeholder="Enter Contact Person Email" name="contact_person_email"
                                            value="{{ old('contact_person_email', $app->contact_person_email ?? '') }}" />
                                    </div>
                                </div>
                                <div class="col-xxl-3 col-md-4 gy-3">
                                    <div>
                                        <label class="form-label">Is your registered or Operational Address same ? : <span
                                                class="">*</span></label>
                                        <br>
                                        <input type="radio" id="html" name="is_your_registered"
                                            value="yes"{{ old('is_your_registered', $app->is_your_registered ?? '') == 'yes' ? ' checked' : '' }}>
                                        <label for="new">Yes</label>

                                        <input type="radio" id="html" name="is_your_registered"
                                            value="no"{{ old('is_your_registered', $app->is_your_registered ?? '') == 'no' ? ' checked' : '' }}>
                                        <label for="new">No</label>

                                    </div>
                                </div>
                                <div class="col-xxl-3 col-md-4 gy-3">
                                    <div>
                                        <label class="form-label">CB /Organization Address Type: <span
                                                class="">*</span></label>
                                        <br>
                                        <input type="radio" id="html" name="cb_address_type"
                                            value="Owned"{{ old('is_your_registered', $app->cb_address_type ?? '') == 'Owned' ? ' checked' : '' }}>
                                        <label for="new">Owned</label>

                                        <input type="radio" id="html" name="cb_address_type"
                                            value="Lease/Rent"{{ old('is_your_registered', $app->cb_address_type ?? '') == 'Lease/Rent' ? ' checked' : '' }}>
                                        <label for="new">Lease/Rent</label>

                                    </div>
                                </div>

                                <div class="col-xxl-3 col-md-4 gy-3">
                                    <div>
                                        <label class="form-label">CB /Organization registered office address: <span
                                                class="">*</span></label>
                                        <br>
                                        <textarea placeholder="Address" class="form-control customtextarea" name="cb_registered_office_address">{{ old('cb_registered_office_address', $app->cb_registered_office_address ?? '') }}</textarea>


                                    </div>
                                </div>
                                <div class="col-xxl-3 col-md-4">
                                    <div>
                                        <label for="labelInput" class="form-label">Country <span
                                                class="">*</span></label>

                                        <select class="form-select" name="country" id="country">
                                            <option value="">-Select-</option>
                                            @forelse(getRefCountryMaster() as $country)
                                                <option value="{{ $country->country_name }}"
                                                    {{ old('country') == $country->country_name ? 'selected' : '' }}>
                                                    {{ $country->country_name }}
                                                </option>
                                            @empty
                                                <option value="">No countries available</option>
                                            @endforelse


                                        </select>

                                    </div>
                                </div>
                                <div class="col-xxl-3 col-md-4">
                                    <div>
                                        <label for="labelInput" class="form-label">State <span
                                                class="">*</span></label>
                                        <select class="form-select state" name="ref_state_id" id="ref_state_id">
                                            <option value="">Select State</option>
                                            @forelse(getAllState() as $state)
                                                <option
                                                    value="{{ $state->id }}"{{ old('ref_state_id') == $state->ref_state_id ? 'selected' : '' }}>
                                                    {{ $state->state_name }}</option>
                                            @empty
                                            @endforelse
                                        </select>
                                    </div>
                                </div>

                                <div class="col-xxl-3 col-md-4">
                                    <div>
                                        <label for="labelInput" class="form-label">District <span
                                                class="">*</span></label>
                                        <input type="hidden" name="ref_district_id" value="">


                                        <select class="form-select district" name="ref_district_id" id="ref_district_id">
                                            @forelse(getDistrictByStateID(old('state')) as $district)
                                                <option
                                                    value="{{ $district->id }}"{{ old('ref_district_id') == $district->ref_district_id ? 'selected' : '' }}>
                                                    {{ $district->district_name }}</option>
                                            @empty
                                                <option value="">-Select District-</option>
                                            @endforelse


                                        </select>

                                    </div>
                                </div>
                                <div class="col-xxl-3 col-md-4">
                                    <div>
                                        <label for="labelInput" class="form-label">Taluka/Mandal
                                            <span class="">*</span></label>
                                        <input type="hidden" name="ref_block_tehsil_id" value="">


                                        <select class="form-select block_tehsil" name="ref_block_tehsil_id"
                                            id="ref_block_tehsil_id">

                                            @forelse(getBlockTehsilByDistrictID(old('district')) as $block)
                                                <option value="{{ $block->id }}"
                                                    {{ old('ref_block_tehsil_id') == $block->ref_block_tehsil_id ? 'selected' : '' }}>
                                                    {{ $block->block_tehsil_name }}</option>
                                            @empty
                                                <option value="">-Select Taluka/Mandal-</option>
                                            @endforelse


                                        </select>


                                    </div>
                                </div>
                                <div class="col-xxl-3 col-md-4 gy-3">
                                    <div>
                                        <label class="form-label">Village </label>
                                        {{-- <input type="hidden" name="ref_village_id" value=""> --}}
                                        {{-- <input type="text" class="form-control" id="" placeholder=""
                                            name="ref_village_id" value="" /> --}}

                                        <select class="form-select village" name="ref_village_id">
                                            <option value="">Select Village</option>
                                            @forelse(getVillageByBlock(old('ref_village_id')) as $village)
                                                <option value="{{ $village->id }}"
                                                    {{ old('ref_village_id') == $village->ref_village_id ? 'selected' : '' }}>
                                                    {{ $village->village_name }}</option>
                                            @empty
                                                <option value="">-Select Village-</option>
                                            @endforelse
                                        </select>

                                    </div>
                                </div>

                                <div class="col-xxl-3 col-md-4 gy-3">
                                    <div>
                                        <label for="labelInput" class="form-label">Pin Code<span
                                                class="">*</span></label>
                                        <input type="text" class="form-control numbersonly" name="pin"
                                            value="{{ old('pin', $app->pin ?? '') }}" maxlength="6"
                                            placeholder="Enter Pin" />
                                    </div>
                                </div>
                                <div class="col-xxl-3 col-md-4 gy-3">
                                    <div>
                                        <label for="labelInput" class="form-label">Office Phone Number (landline) with Std
                                            Code : <span class="">*</span></label>
                                        <input type="text" class="form-control numbersonly"
                                            placeholder="Enter Office Phone Number" name="office_phone_number"
                                            value="{{ old('office_phone_number', $app->office_phone_number ?? '') }}"
                                            maxlength="10" />
                                    </div>
                                </div>
                                <div class="col-xxl-3 col-md-4 gy-3">
                                    <div>
                                        <label for="labelInput" class="form-label">Fax No : <span
                                                class="">*</span></label>
                                        <input type="text" class="form-control numbersonly" placeholder="Enter Fax No"
                                            name="fax" value="{{ old('fax', $app->fax ?? '') }}" maxlength="12" />
                                    </div>
                                </div>
                                <div class="col-xxl-3 col-md-4 gy-3">
                                    <div>
                                        <label for="labelInput" class="form-label">CB/Organization Email ID : <span
                                                class="">*</span></label>
                                        <input type="email" class="form-control numbersonly" placeholder=""
                                            name="cb_email_id" value="{{ old('cb_email_id', $app->cb_email_id ?? '') }}"
                                            maxlength="" />
                                    </div>
                                </div>
                                <div class="col-xxl-3 col-md-4 gy-3">
                                    <div>
                                        <label for="labelInput" class="form-label">Website Address: <span
                                                class="">*</span></label>
                                        <input type="text" class="form-control " placeholder=""
                                            name="website_address"
                                            value="{{ old('website_address', $app->website_address ?? '') }}" maxlength="" />
                                    </div>
                                </div>

                                <div class="col-xxl-3 col-md-4  gy-3">
                                    <div>
                                        <label for="labelInput" class="form-label">Legal Status: <span
                                                class="">*</span></label>

                                        <select class="form-select" name="legal_status" id="legal_status">
                                            <option value="">-Select-</option>
                                            {{-- <option value="Registered Company"
                                                {{ old('legal_status', $userData->legal_status) === 'Registered Company' ? 'selected' : '' }}>
                                                Registered Company</option> --}}
                                            <option
                                                value="Registered Company"{{ old('legal_status', $app->legal_status ?? '') === 'Registered Company' ? 'selected' : '' }}>
                                                Registered Company</option>
                                            <option
                                                value="Registered Society"{{ old('legal_status', $app->legal_status ?? '') === 'Registered Society' ? 'selected' : '' }}>
                                                Registered Society</option>
                                            <option
                                                value="Trust"{{ old('legal_status', $app->legal_status ?? '') === 'Trust' ? 'selected' : '' }}>
                                                Trust</option>
                                            <option
                                                value="Co-operative"{{ old('legal_status', $app->legal_status ?? '') === 'Co-operative' ? 'selected' : '' }}>
                                                Co-operative</option>
                                            <option
                                                value="State Govt. Organization"{{ old('legal_status', $app->legal_status ?? '') === 'State Govt. Organization' ? 'selected' : '' }}>
                                                State Govt. Organization</option>

                                        </select>

                                    </div>
                                </div>
                                <div class="col-xxl-3 col-md-4  gy-3">
                                    <div>
                                        <label for="labelInput" class="form-label">Year of Establishment <span
                                                class="">*</span></label>

                                        <select class="form-select" name="year_of_establishment"
                                            id="year_of_establishment">
                                            <option value="">-Select-</option>
                                            <option value="2021"
                                                {{ old('year_of_establishment', $app->year_of_establishment ?? '') === '2021' ? 'selected' : '' }}>
                                                2021</option>
                                            <option value="2022"
                                                {{ old('year_of_establishment', $app->year_of_establishment ?? '') === '2022' ? 'selected' : '' }}>
                                                2022</option>

                                        </select>

                                    </div>
                                </div>
                                <div class="col-xxl-3 col-md-4  gy-3">
                                    <div>
                                        <label for="labelInput" class="form-label">Date of Establishment the certification
                                            Programme : <span class="">*</span></label>

                                        <input type="date" class="form-control numbersonly"
                                            name="date_of_establishment"
                                            value="{{ old('date_of_establishment', $app->date_of_establishment ?? '') }}"
                                            maxlength="" />

                                    </div>
                                </div>
                                <div class="col-xxl-3 col-md-3  gy-3">
                                    <div>
                                        <label for="labelInput" class="form-label">GST No : <span
                                                class="">*</span></label>

                                        <input type="text" class="form-control " placeholder="" name="gst_no"
                                            value="{{ old('gst_no', $app->date_of_establishment ?? '') }}" maxlength="15" />

                                    </div>
                                </div>

                                <div class="col-xxl-3 col-md-3  gy-3">
                                    <div>
                                        <label for="labelInput" class="form-label">Additional information<span
                                                class="">*</span></label>

                                        <textarea placeholder="Additional information" class="form-control customtextarea" name="descriptions"
                                            maxlength="100">{{ old('descriptions', $app->descriptions ?? '') }}</textarea>

                                    </div>
                                </div>
                            </div>

                            <div class="row seperatesec  white-inner">
                                <div class="sectitle">
                                    <label for="labelInput" class="form-label ">Details of Top Management
                                        Officials(MD/CEO/Director/President/Chairman/CMD) and
                                        Operating officials Involved in the inspection and certification of scope applied
                                        for (Eg: Quality Manager, Evaluator, Reviewer, Inspectors)
                                    </label>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped align-middle dataTable no-footer "
                                        width="100%" id="certificationbody_tbl">
                                        <thead>
                                            <tr>
                                                <th>Employee Type<span class="required">*</span></th>
                                                <th>Name<span class="required">*</span></th>
                                                <th>Designation<span class="required">*</span></th>
                                                <th>Qualification
                                                    (Graduate
                                                    /PG/PHD)<span class="required">*</span></th>
                                                <th>Total Experience
                                                    (in years)<span class="required">*</span></th>
                                                <th>Date of Joining<span class="required">*</span></th>
                                                <th>Trainings<span class="required">*</span></th>
                                                <th>Bio Data<span class="required">*</span></th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <select class="form-select -entry" required name="employee_type[]"
                                                        id="employee_type">
                                                        <option value="">-Select-</option>
                                                        <option value="Top Management" {{ old('employee_type') }}>Top
                                                            Management</option>
                                                        <option value="Operating Official"
                                                            {{ old('Operating Official') }}>Operating Official</option>
                                                    </select>
                                                </td>
                                                <td><input type="text" class="form-control -entry"
                                                        value="{{ old('name') }}" name="name[]" required
                                                        id="name" />
                                                </td>
                                                <td><select class="form-select -entry" name="ref_designation_master_id[]"
                                                        required id="ref_designation_master_id">
                                                        <option value="">-Select-</option>
                                                        @forelse(getAllDesignation() as $designation)
                                                            <option
                                                                value="{{ $designation->id }}"{{ old('ref_designation_master_id') == $designation->id ? 'selected' : '' }}>
                                                                {{ $designation->designation_name }}</option>
                                                        @empty
                                                        @endforelse
                                                    </select></td>
                                                <td><input type="text" required class="form-control -entry "
                                                        value="{{ old('qualification') }}" name="qualification[]"
                                                        id="qualification" /> </td>
                                                <td><input type="text" required class="form-control -entry numbersonly"
                                                        value="{{ old('total_experience') }}" name="total_experience[]"
                                                        id="total_experience" maxlength="2" />
                                                </td>
                                                <td><input type="date" required class="form-control -entry"
                                                        value="{{ old('date_of_joining') }}" name="date_of_joining[]"
                                                        id="date_of_joining" />
                                                </td>
                                                <td><input type="text" required class="form-control"
                                                        value="{{ old('training') }}" name="training[]"
                                                        id="training" />
                                                </td>
                                                <td> <input type="file" required class="form-control"
                                                        name="upload_biodata[]" id="upload_biodata"
                                                        accept="image/png, application/pdf, image/jpeg">

                                                </td>
                                                <td>

                                                    <a class="btn btn-primary add_certificationbody">Add</a>
                                                </td>
                                            </tr>
                                            @foreach ($cbodyData as $cbodyData)
                                                <tr>
                                                    {{-- <input type="text" name="id" class="form-control"
                                                        value="{{ $cbodyData->id }}" /> --}}
                                                    <td>
                                                        <select class="form-select -entry" name="employee_type[]"
                                                            id="employee_type">
                                                            <option value="">-Select-</option>
                                                            <option value="Top Management"
                                                                {{ old('employee_type', $cbodyData->employee_type ?? '') === 'Top Management' ? 'selected' : '' }}>
                                                                Top Management</option>
                                                            <option value="Operating Official"
                                                                {{ old('employee_type', $cbodyData->employee_type ?? '') === 'Operating Official' ? 'selected' : '' }}>
                                                                Operating Official</option>
                                                        </select>
                                                    </td>
                                                    <td><input type="text" class="form-control -entry"
                                                            value="{{ old('name', $cbodyData->name ?? '') }}" name="name[]"
                                                            id="name" />
                                                    </td>
                                                    <td><select class="form-select -entry" name="desination[]"
                                                            id="desination">
                                                            <option value="">-Select-</option>
                                                            <option
                                                                value="MD"{{ old('desination', $cbodyData->desination ?? '') === 'MD' ? 'selected' : '' }}>
                                                                MD</option>
                                                            <option
                                                                value="CEO"{{ old('desination', $cbodyData->desination ?? '') === 'CEO' ? 'selected' : '' }}>
                                                                CEO</option>
                                                            <option
                                                                value="Director"{{ old('desination', $cbodyData->desination ?? '') === 'Director' ? 'selected' : '' }}>
                                                                Director</option>
                                                            <option
                                                                value="President"{{ old('desination', $cbodyData->desination ?? '') === 'President' ? 'selected' : '' }}>
                                                                President</option>
                                                            <option
                                                                value="Chairman"{{ old('desination', $cbodyData->desination ?? '') === 'Chairman' ? 'selected' : '' }}>
                                                                Chairman</option>
                                                            <option
                                                                value="CMD"{{ old('desination', $cbodyData->desination ?? '') === 'CMD' ? 'selected' : '' }}>
                                                                CMD</option>
                                                        </select></td>
                                                    <td><input type="text" class="form-control -entry "
                                                            value="{{ old('qualification', $cbodyData->qualification ?? '') }}"
                                                            name="qualification[]" id="qualification" /> </td>
                                                    <td><input type="text" class="form-control -entry numbersonly"
                                                            value="{{ old('total_experience', $cbodyData->total_experience ?? '') }}"
                                                            name="total_experience[]" id="total_experience"
                                                            maxlength="2" />
                                                    </td>
                                                    <td><input type="date" class="form-control -entry"
                                                            value="{{ old('date_of_joining', $cbodyData->date_of_joining ?? '') }}"
                                                            name="date_of_joining[]" id="date_of_joining" />
                                                    </td>
                                                    <td><input type="text" class="form-control"
                                                            value="{{ old('training', $cbodyData->training ?? '') }}"
                                                            name="training[]" id="training" />
                                                    </td>
                                                    <td> <input type="file" class="form-control"
                                                            name="upload_biodata[]" id="upload_biodata"
                                                            accept="image/png, application/pdf, image/jpeg">


                                                        <a target="_BLANK"
                                                            href="{{ asset('public/accredtiation/upload_biodata/' . $cbodyData->upload_biodata ?? '') }}"
                                                            class="text-decoration-underline">See Doc</a>
                                                    </td>
                                                    <td>

                                                        <a class="btn btn-danger biodelete"
                                                            data-id="{{ $cbodyData->id }}">Delete</a>
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>


                                    </table>
                                </div>


                            </div>

                            <div class="row seperatesec  white-inner">
                                <div class="sectitle">
                                    <label for="labelInput" class="form-label ">List of Scan document to be uploaded
                                    </label>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped align-middle dataTable no-footer"
                                        width="100%" id="datatable">
                                        <thead>
                                            <tr>
                                                <th>S.No.</th>
                                                <th>Document</th>
                                                <th>Upload Documents</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <input type="hidden" name="application_id" value="{{ $app->id ?? '' }}">

                                        {{-- @dd($app->id ); --}}
                                        @foreach ($data as $res)
                                            <tbody>
                                                <tr>

                                                    <td> {{ $res->id }} </td>
                                                    <td>{{ $res->document_name }}</td>
                                                    <td class="file_upload"> <input type="file" placeholder=""
                                                            class="form-control " name="document_upload"
                                                            accept="image/png, application/pdf, image/jpeg">

                                                        @php
                                                            $image = getAccrediationDocumentByID($res->id, $userid);
                                                        @endphp

                                                        @if (isset($image->document_upload) && $image->document_upload != '')
                                                            <a target="_BLANK"
                                                                href="{{ asset('public/accredtiation/accrediation_document/' . $image->document_upload) }}"
                                                                class="text-decoration-underline">See Doc</a>
                                                        @endif

                                                    </td>
                                                    <td class="upload_btn">
                                                        <button type="button" class="upload-button btn btn-primary"
                                                            data-id="{{ $res->id }}">Upload</button>

                                                    </td>
                                                </tr>
                                            </tbody>
                                        @endforeach
                                    </table>
                                </div>
                            </div>

                            <div class="row seperatesec  white-inner">
                                <div class="sectitle">
                                    <label for="labelInput" class="form-label ">Declaration
                                    </label>
                                </div>

                                <div class="col-xxl-3 col-md-4  gy-3">
                                    <div>
                                        <label for="labelInput" class="form-label">Name: <span
                                                class="">*</span></label>

                                        <input type="text" class="form-control " readonly name="declaration_name"
                                            value="{{ old('declaration_name', Auth::guard('misadmin')->user()->first_name) }}"
                                            maxlength="" />

                                    </div>
                                </div>
                                <div class="col-xxl-3 col-md-4  gy-3">
                                    <div>
                                        <label for="labelInput" class="form-label">Designation: <span
                                                class="">*</span></label>


                                        <select class="form-select state" name="ref_designation_master_id"
                                            id="ref_designation_master_id">
                                            <option value="">Select Designation</option>
                                            @forelse(getAllDesignation() as $designation)
                                                <option
                                                    value="{{ $designation->id }}"{{ old('ref_designation_master_id') == $designation->id ? ' selected' : '' }}>
                                                    {{ $designation->designation_name }}
                                                </option>
                                            @empty
                                                <option value="">No designations available</option>
                                            @endforelse

                                        </select>

                                    </div>
                                </div>

                                <div class="col-xxl-3 col-md-4  gy-3">
                                    <div>
                                        <label for="labelInput" class="form-label">Date: <span
                                                class="">*</span></label>

                                        <input type="date" class="form-control " name="declaration_date"
                                            value="{{ old('declaration_date', $app->declaration_date ?? '') }}"
                                            maxlength="" />

                                    </div>
                                </div>
                                <div class="col-xxl-3 col-md-4  gy-3">
                                    <div>
                                        <label for="labelInput" class="form-label">Signature: <span
                                                class="">*</span></label>
                                        <a target="_BLANK"
                                            href="{{ asset('public/accredtiation/signature/' ) }}"
                                            class="text-decoration-underline">See Doc</a>
                                        <input type="file" class="form-control" name="signature" id=""
                                            accept="image/png, application/pdf, image/jpeg">
                                    </div>
                                </div>
                                <div class="col-xxl-3 col-md-4 gy-3">
                                    <div>
                                        <label class="form-label">Payment Mode : <span class="">*</span></label>
                                        <br>
                                        <input type="radio" id="html" name="declaration_payment_mode"
                                            value="Online" checked>
                                        <label for="new">Online</label>

                                    </div>
                                </div>

                            </div>




                            <div class="row">
                                <div class="col-lg-12 gy-4">
                                    <div class="hstack gap-2">
                                        <button type="submit" class="btn btn-primary" id="submitbtn">
                                            Save
                                        </button>
                                        {{-- <a href="{{ route('superadmin.icsuser.step2', $userdetails->id) }}" class="btn btn-soft-success">Next</a> --}}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
@endsection
@push('script')
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        // $("#registration").validate({
        //     rules: {

        //     },
        //     messages: {

        //     }

        // });
        $('.add_certificationbody').on('click', function() {

            $("#certificationbody_tbl tbody").append(
                '<tr class="cer_tr"> <td> <select class="form-select -entry" name="employee_type[]" id="employee_type" > <option value="">-Select-</option> <option value="Top Management">Top Management</option> <option value="Operating Official">Operating Official</option> </select> </td> <td><input type="text" class="form-control -entry" value="" name="name[]" id="name" /> </td> <td><select class="form-select -entry" name="desination[]" id="desination"> <option value="">-Select-</option> <option value="MD">MD</option>  <option value="CEO">CEO</option>  <option value="Chairman">Chairman</option>  <option value="Director">Director</option>  <option value="President">President</option>  <option value="CMD">CMD</option> </select></td> <td><input type="text" class="form-control -entry" value="" name="qualification[]" id="qualification" /> </td> <td><input type="text" class="form-control -entry numbersonly" value="" name="total_experience[]" id="total_experience" /> </td> <td><input type="date" class="form-control -entry" value="" name="date_of_joining[]" id="date_of_joining"/> </td> <td><input type="text" class="form-control" value="" name="training[]" id="training" /> </td> <td> <input type="file" class="form-control" name="upload_biodata[]"  id="upload_biodata" accept="image/png, application/pdf, image/jpeg"> </td> <td> <a class="btn btn-danger remove" >Remove</a> </td> </tr>'
            );



        });

        $(document).ready(function() {

            // $(".remove").on("click", function() {

            //     var row = $(this).closest("tr");


            //     row.remove();
            // });
            $(document).on('click', '.biodelete', function() {
                var ths = $(this);
                var id = $(this).attr('data-id');
                //alert(id);
                //     var id = $(this).data('data-id');
                // var cba_id = $(this).attr('data-value');

                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.value) {
                        $.ajax({
                            url: "{{ route('superadmin.bioDataDelete') }}",
                            method: "POST",
                            dataType: 'json',
                            data: {
                                'id': id,
                            },
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            },
                            success: function(result) {
                                console.log(result);

                                if (result.message == 'done') {

                                    ths.closest("tr").remove();
                                    Swal.fire('Deleted!',
                                        'Record Deleted Successfully..', 'success');
                                }
                            }

                        });
                    }
                });
            });
        });

        $("body").on("click", ".remove", function() {
            //alert('ss');
            $(this).parents(".cer_tr").remove();
        });



        //    $("body").on("click", ".remove", function() {
        //        //alert('ss');
        //            $(this).parents(".cer_tr").remove();
        //    });
        $(document).ready(function() {

            $('.upload-button').click(function() {
                // var href='{{ asset('/') }}';

                //              return false;
                var th = $(this);
                var fileInput = $(this).closest('tr').find('input[type="file"]')[0].files[0];
                var documentId = $(this).data('id');
                var applicationId = $('input[name="application_id"]').val();


                if (fileInput) {
                    var formData = new FormData();
                    formData.append('document_upload', fileInput);
                    formData.append('document_id', documentId);
                    formData.append('application_id', applicationId);


                    $.ajax({
                        url: '{{ route('file.upload') }}',
                        type: 'POST',
                        data: formData,
                        contentType: false,
                        processData: false,
                        success: function(response) {

                            console.log(response);
                            console.log(response.success);

                            if (response.success == 'done') {

                                th.closest('tr').find('.file_upload').html(
                                    '<input type="hidden" name="document_upload_edit" value="' +
                                    response.file + '"> <a target="_BLANK" href="' +
                                    response.path +
                                    '" class="text-decoration-underline">See Doc</a>');
                                th.closest('tr').find('.upload_btn').html(
                                    '<a class="mdi mdi-delete btn btn-soft-danger deletedata" data-id="' +
                                    response.id + '" data-value="' + documentId + '"></a>');

                            } else {
                                th.closest('tr').find('.file_upload').html(
                                    '<input type="file" class="form-control " name="document_upload" accept="image/png, application/pdf, image/jpeg">'
                                );
                                th.closest('tr').find('.upload_btn').html(
                                    '<button type="button" class="upload-button btn btn-primary" data-id="' +
                                    documentId + '">Upload</button>');
                            }

                        }
                    });
                } else {
                    alert('Please select a file to upload.');
                }
            });
        });
        $(document).on('click', '.deletedata', function() {
            var ths = $(this);
            var id = $(this).attr('data-id');
            var cba_id = $(this).attr('data-value');

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.value) {
                    $.ajax({
                        url: "{{ route('superadmin.deleteFile') }}",
                        method: "POST",
                        dataType: 'json',
                        data: {
                            'id': id,
                        },
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function(result) {
                            console.log(result);
                            // Swal.fire('Deleted!', 'Record Deleted Successfully..', 'success');
                            if (result.message == 'done') {

                                ths.closest('tr').find('.file_upload').html(
                                    '<input type="file" class="form-control " name="document_upload" accept="image/png, application/pdf, image/jpeg">'
                                );
                                ths.closest('tr').find('.upload_btn').html(
                                    '<button type="button" class="upload-button btn btn-primary" data-id="' +
                                    cba_id + '">Upload</button>');

                            }
                        }

                    });
                }
            });
        });
    </script>
@endpush

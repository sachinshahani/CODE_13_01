@extends('admin.layouts.app_acc')
@section('content')

    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Process Application</h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Process Application</a></li>
                        <li class="breadcrumb-item active">Process Application</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>

    <div class="row seperatesec  white-inner">
        <div class="sectitle">
            <label for="labelInput" class="form-label  blue-ht">List of in Progress Application(s) for new Registration</label>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered table-striped align-middle dataTable no-footer"
                width="100%" id="searchResultsTable">
                <thead>
                    <tr>
                        <th>S.No.</th>
                        {{-- <th>Reference No.</th> --}}
                        <th>MD/CEO/Director Name</th>
                        <th>CB/Organization Name</th>
                        <th>CB/Organization Registered Address</th>
                        <th>Application Type</th>
                        <th>Scope of Accreditation</th>
                        <th>Application Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td colspan="9">No Record found.</td>

                    </tr>
                </tbody>

            </table>
        </div>


    </div>
@endsection

@push('script')
        <script>
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var table = $('#searchResultsTable').DataTable({
                dom: 'Bfrtip',
                lengthMenu: [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
                processing: true,
                serverSide: true,
                ajax: {
                    url: '{{ route('superadmin.processApplication') }}',
                    type: 'GET',
                    // data: function(d) {
                    //     d.state = $('#state').val();
                    //     d.from_date = $('#from_date').val();
                    //     d.to_date = $('#to_date').val();
                    //     d.operator = $('#operator').val();
                    // },
                    error: function(xhr, error, code) {
                        console.log(xhr.responseText); // This will print the error response
                    }
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: true
                    },
                    {
                        data: 'name',
                        name: 'name',
                        orderable: true
                    },
                    {
                        data: 'org_name',
                        name: 'org_name',
                        orderable: true
                    },
                    {
                        data: 'org_address',
                        name: 'org_address',
                        orderable: true
                    },
                    {
                        data: 'application_type',
                        name: 'application_type',
                        orderable: true
                    },
                    {
                        data: 'scope',
                        name: 'scope',
                        orderable: true
                    },
                    {
                        data: 'application_date',
                        name: 'application_date',
                        orderable: true
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: true
                    },
                ],
                paging: false,
                buttons: [
                    'excelHtml5',
                    {
                        extend: 'csvHtml5',
                        title: function() {
                            return "REPORTS";
                        },
                        titleAttr: 'CSV REPORTS'
                    },
                    {
                        extend: 'pdfHtml5',
                        title: function() {
                            return "REPORTS";
                        },
                        orientation: 'landscape',
                        pageSize: 'A4',
                        titleAttr: 'PDF REPORTS'
                    }
                ],
                language: {
                    emptyTable: "No Record found."
                }
            });

            // $('#state, #from_date, #to_date, #operator').change(function() {
            //     table.draw();
            // });
        </script>
    @endpush

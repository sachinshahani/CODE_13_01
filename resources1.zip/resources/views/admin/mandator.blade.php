<div class="card">
        <div class="card-header align-items-center d-flex">
            <h4 class="card-title mb-0 flex-grow-1">
                Mandator Details
            </h4>
            <div class="flex-shrink-0">
                                         @if (session('error'))
											<div class="alert alert-danger">
												{{ session('error') }}
											</div>
										@endif
										@if (session('success'))
											<div class="alert alert-success">
												{{ session('success') }}
											</div>
										@endif
										@if($errors)
											@foreach ($errors->all() as $error)
												<div class="alert alert-danger">{{ $error }}</div>
											@endforeach
										@endif 
                                    </div>
            
        </div>
        <!-- end card header -->
        <div class="card-body">
            <div class="live-preview">
                
 
                <div class="row seperatesec">
                    <div class="col-xxl-4 col-md-6">
                        <div>
                            <label class="form-label">First Name</label>
                            <input type="password" class="form-control" id="placeholderInput"
                                placeholder="First Name" />
                        </div>
                    </div>

                    <div class="col-xxl-4 col-md-6">
                        <div>
                            <label class="form-label">Middle Name</label>
                            <input type="password" class="form-control" id="placeholderInput"
                                placeholder="Middle Name" />
                        </div>
                    </div>

                    <div class="col-xxl-4 col-md-6">
                        <div>
                            <label class="form-label">Last Name</label>
                            <input type="password" class="form-control" id="placeholderInput"
                                placeholder="Last Name" />
                        </div>
                    </div>

                    <div class="gy-3">
                        <label for="labelInput" class="form-label">Office Address <span
                                class="required">*</span></label>
                        <textarea placeholder="Address"
                            class="form-control customtextarea"></textarea>
                    </div>
                </div>
                    

                <div class="row seperatesec">
                    <div class="col-xxl-6 col-md-6 gy-3">
                        <div>
                            <label class="form-label">Village </label>

                            <input type="text" class="form-control" id="placeholderInput"
                                placeholder="village_name*" />
                        </div>
                    </div>
                    <div class="col-xxl-6 col-md-6 gy-3">
                        <div>
                            <label for="labelInput" class="form-label">Taluka/Mandal
                                <span class="required">*</span></label>
                            <input type="text" class="form-control" id="placeholderInput"
                                placeholder="taluka_name*" />
                        </div>
                    </div>
                </div>


                <div class="row seperatesec">
                    <div class="col-xxl-4 col-md-6  gy-3">
                        <div>
                            <label for="labelInput" class="form-label">City <span
                                    class="required">*</span></label>
                            <input type="text" class="form-control" id="placeholderInput"
                                placeholder="city_name*" />
                        </div>
                    </div>
                    <div class="col-xxl-4 col-md-6  gy-3">
                        <div>
                            <label for="labelInput" class="form-label">District <span
                                    class="required">*</span></label>
                            <input type="text" class="form-control" id="placeholderInput"
                                placeholder="state_district*" />
                        </div>
                    </div>
                    <div class="col-xxl-4 col-md-6  gy-3">
                        <div>
                            <label for="labelInput" class="form-label">State <span
                                    class="required">*</span></label>
                            <input type="text" class="form-control" id="placeholderInput"
                                placeholder="state_name*" />
                        </div>
                    </div>
                </div>



                <div class="row seperatesec">
                    <div class="col-xxl-4 col-md-6  gy-3">
                        <div>
                            <label for="labelInput" class="form-label">Pin Code<span
                                    class="required">*</span></label>
                            <input type="number" class="form-control" id="placeholderInput"
                                placeholder="Pin Code" />
                        </div>
                    </div>
                    <div class="col-xxl-4 col-md-6  gy-3">
                        <div>
                            <label for="labelInput" class="form-label">Contact Deatils<span
                                    class="required">*</span></label>
                            <input type="password" class="form-control" id="placeholderInput"
                                placeholder="contatct_details*" />
                        </div>
                    </div>
                    <div class="col-xxl-4 col-md-6  gy-3">
                        <div>
                            <label for="labelInput" class="form-label">Email Id<span
                                    class="required">*</span></label>
                            <input type="password" class="form-control" id="placeholderInput"
                                placeholder="Email Id*" />
                        </div>
                    </div>
                </div>




                <div class="row seperatesec ">

                    <div class="col-xxl-6 col-md-6 gy-3 ">
                        <div>
                            <label for="basiInput" class="form-label">Id Proof
                            </label>
                            <div class="input-group">
                                <select class="form-select">
                                    <option>PAN</option>
                                    <option>Aadhar</option>
                                    <option>TAN</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-4 col-md-6  gy-3">
                        <div>
                            <label for="basiInput" class="form-label">Address Proof of Office
                            </label>
                            <div class="input-group">
                                <select class="form-select">
                                    <option>Electricity Bill</option>
                                    <option>Rent Agreement</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="row seperatesec">

                    
        <div class="col-xxl-4 col-md-6  gy-3 ">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title mb-0">Photo Individual</h4>
                </div><!-- end card header -->

                <div class="dropzone">
                                <div class="fallback">
                                    <input name="file2" type="file" >
                                </div>
                                <div class="dz-message needsclick">
                                    <div class="mb-3">
                                        <i class="display-4 text-muted ri-upload-cloud-2-fill"></i>
                                    </div>

                                    <h4>Drop files here or click to upload.</h4>
                                </div>
                            </div>
                <!-- end card body -->
            </div>
            <!-- end card -->
        </div>
                    <div class="col-xxl-4 col-md-6  gy-3">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title mb-0">Photo of Office building:</h4>
                            </div>
                            <div class="card-body">
                                <div class="avatar-xl mx-auto">
                                    <input type="file" class="filepond filepond-input-circle"
                                        name="Photo_of_building"
                                        accept="image/png, image/jpeg, image/gif" />
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xxl-4 col-md-6  gy-3">
                        <div class="card-header">
                            <h4 class="card-title mb-0">Contract Letter</h4>
                        </div>
                        <div class="dropzone">
                            <div class="fallback">
                                <input name="file" type="file" multiple="multiple">
                            </div>
                            <div class="dz-message needsclick">
                                <div class="mb-3">
                                    <i class="display-4 text-muted ri-upload-cloud-2-fill"></i>
                                </div>

                                <h4>Drop files here or click to upload.</h4>
                            </div>
                        </div>

                    </div>

                </div>




                <!--address sec end-->

                <div class="row">
                    <div class="col-lg-12 gy-4">
                        <div class="hstack gap-2">
                        <a href="{{route('superadmin.userprofile')}}" class="btn btn-soft-success">
                                                        Back
                                                    </a>    
                        <button type="submit" class="btn btn-primary">
                                Submit
                            </button>
                            <a href="{{route('superadmin.icsuser.step3',$userdetails->id)}}" class="btn btn-soft-success">
                                                        Next
                                                    </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@push('script')

<script>
                    $.ajaxSetup({
                    headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                    });

                    // Dropzone has been added as a global variable.
                    const dropzone = new Dropzone("div.dropzone", {
                    url: "{{ route('projects.storeMedia') }}",
                    paramName: "file",
                    maxFilesize: 2,
                    maxFiles: 1,
                    acceptedFiles: ".jpeg,.jpg,.png,.mp4,.webm,.html5",
                    headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    init: function() {
                    var drop = this; // Closure
                    this.on('error', function(file, errorMessage) {
                    if (errorMessage.indexOf('Error 404') !== -1) {
                    var errorDisplay = document.querySelectorAll('[data-dz-errormessage]');
                    errorDisplay[errorDisplay.length - 1].innerHTML =
                    'Error 404: The upload page was not found on the server';
                    }
                    if (errorMessage.indexOf('File is too big') !== -1) {
                    alert('Unable to upload image size is greated than 2 MB');
                    // i remove current file
                    drop.removeFile(file);
                    }
                    });
                    this.on("maxfilesexceeded", function(file) {
                    this.removeAllFiles();
                    this.addFile(file);
                    }),
                    this.on("success", function(file, response) {
                    console.log(response);
                    var hiddenImage = $('<input type="hidden" name="_hidden_images[]" value="' +
                    response.name + '"/>');
                    $('.hidden_images_area').html(hiddenImage);
                    })
                    }
                    });
                    </script>

@endpush
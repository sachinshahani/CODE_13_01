<!doctype html>
<html lang="en" data-layout="vertical" data-topbar="light" data-sidebar="dark" data-sidebar-size="lg"
    data-sidebar-image="none">

<head>
    <meta charset="utf-8" />
    <title> APEDA </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="{{ asset('public/assets/images/favicon.png') }}">
    <!-- Layout config Js -->
    <script src="{{ asset('public/assets/js/layout.js') }}"></script>
    <!-- Bootstrap Css -->
    <link href="{{ asset('public/assets/css/bootstrap.min.css') }}" rel="stylesheet" />
    <!-- Icons Css -->
    <link href="{{ asset('public/assets/css/icons.min.css') }}" rel="stylesheet" />
    <!-- App Css-->
    <link href="{{ asset('public/assets/css/app.min.css') }}" rel="stylesheet" />
    <!-- custom Css-->
    <link href="{{ asset('public/assets/css/custom.min.css') }}" rel="stylesheet" />
    <link href="{{ asset('public/assets/css/font-awesome.min.css') }}" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans&display=swap" rel="stylesheet">
    <style>
        .right-sec .reload i.ri-refresh-line {
            font-size: 18px;
        }

        .right-sec .captchareload.btn-refresh {
            margin-top: 30px;
        }


        .main-logo {
            display: flex;
        }

        .logo-des {
            margin: auto;
            padding: 0 0 0 5px;
            text-transform: capitalize;
        }

        .logo-des h1 {
            display: flex;
            flex-direction: column;
            font-size: 20px;
            margin: 0;
            border-left: 1px solid #7272727a;
            padding-left: 15px;
            color: #02600c;
        }

        .header-buttons img {
            max-width: 52%;
            float: left;
        }

        .header-buttons {
            display: flex;
            justify-content: end;
        }

        .auth-one-bg .carousel-item img {
            max-height: 522px;
            min-height: 522px;
        }

        div#carouselExampleCaptions,
        .carousel-inner,
        .carousel-item {
            height: 100% !important;
        }

        .container {
            margin: 50px;
        }

        h1 {
            color: #009900;
        }

        .btn-container {
            display: flex;
            justify-content: center;
            margin-top: 30px;
        }

        .btn {
            background-color: #00b300;
            color: white;
            padding: 15px 30px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 10px;
            border-radius: 10px;
            border: none;
            cursor: pointer;
        }

        .btn:hover {
            background-color: #009900;
        }

        .back-btn {
            background-color: #a6a6a6;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            margin-top: 20px;
            border-radius: 10px;
            border: none;
            cursor: pointer;
        }

        .back-btn:hover {
            background-color: #808080;
        }

        .new-label {
            color: #ff0000;
            font-size: 12px;
            margin-left: 5px;
            font-weight: bold;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #ffffff;
            text-align: center;
            margin: 0;
            padding: 0;
        }
    </style>
</head>

<body>
    <!-- auth-page wrapper -->
    <div class="auth-page-wrapper auth-bg-cover d-flex justify-content-center align-items-center">
        <div class="bg-overlay"></div>
        <!-- auth-page content -->
        <div class="auth-page-content overflow-hidden">
            <div class="wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="white-bg d-flex justify-content-between align-items-center pe-lg-5">
                            <div class="main-logo">
                                <a href="index-2.html" class="d-block">
                                    <img class="img-fluid" src="{{ asset('public/assets/images/APEDA-Logo.png') }}"
                                        alt="">
                                </a>
                                <div class="logo-des">
                                    <h1>A Traceability system <span> for organic products</span></h1>
                                </div>
                            </div>

                            <div class="header-buttons">
                                <!-- <button type="button" class="btn btn-primary btn-sm">Log In</button> -->
                                <img src="{{ asset('public/assets/images/india-org.jpg') }}" alt="">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">

                    <!-- end col -->
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </div>
        <!-- end auth page content -->
    </div>
    <!-- end auth-page-wrapper -->
    <!----------------------------------------------------- DATA TABS- -->
    <div class="data-tabs">
        <div class="container-fluid">
            <div class="wrapper tabdiv">
                <div class="row">

                    <div class="container">
                        <h1>NATIONAL PROGRAMME FOR ORGANIC PRODUCTION (NPOP)</h1>
                        <p>Apply here for Accreditation/Surveillance/Renewal/Scope Extension of Certification
                            Bodies<span class="new-label">New</span></p>
                        <div class="btn-container">
                            <a href="{{route('cb_login')}}" class="btn">NEW APPLICANT BODY FOR ACCREDITATION UNDER
                                NPOP</a>
                            <a href="{{route('cb_login')}}" class="btn">SURVEILLANCE/RENEWAL/SCOPE EXTENSION OF
                                ACCREDITED CERTIFICATION BODY</a>
                        </div>
                        {{-- <a href="back-url" class="back-btn">&lt; BACK</a> --}}
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- footer -->
    {{-- <div class="frontfooter">
        <footer class="footer ">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="text-center">
                            <p class="mb-0">
                                &copy;
                                <script>
                                    document.write(new Date().getFullYear())
                                </script> APEDA
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div> --}}
    <!-- end Footer -->
    <!------------------------------------------------- DATA TABS ENDS  -->
    <!-- JAVASCRIPT -->
    <script src="{{ asset('public/js/jquery-3.3.1.min.js') }}"></script>
    <script src="{{ asset('public/js/bootstrap-4.2.1.js') }}"></script>
    <script type="text/javascript" src="{{ asset('public/backend/js/sha.js') }}"></script>
    <script src="{{ asset('public/assets/libs/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
    <script src="{{ asset('public/assets/libs/simplebar/simplebar.min.js') }}"></script>
    <script src="{{ asset('public/assets/libs/node-waves/waves.min.js') }}"></script>
    <script src="{{ asset('public/assets/libs/feather-icons/feather.min.js') }}"></script>
    <script src="{{ asset('public/assets/js/pages/plugins/lord-icon-2.1.0.js') }}"></script>
    <script src="{{ asset('public/assets/js/plugins.js') }}"></script>
    <script src="{{ asset('public/assets/js/pages/password-addon.init.js') }}"></script>
    @include('sweetalert::alert')

</body>

</html>
@extends('layouts.app')

@section('content')
    <!-- Your Login Form -->
    <form method="POST" action="{{ route('login') }}">
        @csrf
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Login</button>
    </form>
@endsection

<!-- Check if 'shouldShowModal' is true to show modal dynamically using JavaScript -->
@if(isset($shouldShowModal) && $shouldShowModal)
    <!-- Modal HTML -->
    <div id="user-modal" class="modal">
        <div class="modal-content">
            <h3>Select Your Role</h3>
            <ul>
                @foreach($users as $user)
                    <li onclick="selectUserRole('{{ $user->id }}')">
                        {{ $user->user_name }} (Role: {{ $user->roles->pluck('name')->join(', ') }})
                    </li>
                @endforeach
            </ul>
        </div>
    </div>
@endif

@section('scripts')
<script>
    // Check if the modal should be displayed based on the 'shouldShowModal' variable
    document.addEventListener('DOMContentLoaded', function() {
        @if(isset($shouldShowModal) && $shouldShowModal)
            var modal = document.getElementById("user-modal");
            modal.style.display = "block";  // Show modal when condition is true
        @endif
    });

    // Function to handle role selection from modal
    function selectUserRole(userId) {
        // You can redirect or trigger other actions based on selected user
        window.location.href = '/dashboard/role/' + userId; // Example redirect
    }
</script>
{{--@endsection

@section('styles')
<!-- <style>
    /* Modal Styling */
    .modal {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        display: none; /* Hidden by default */
        z-index: 9999;
        padding-top: 60px;
    }

    .modal-content {
        background-color: #fff;
        margin: 5% auto;
        padding: 20px;
        border: 1px solid #888;
        width: 60%;
    }

    ul {
        list-style-type: none;
        padding: 0;
    }

    li {
        padding: 10px;
        cursor: pointer;
    }

    li:hover {
        background-color: #ddd;
    }
</style> -->
@endsection --}}

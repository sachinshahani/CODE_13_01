@extends('admin.layouts.app')
@section('content')
    <div class="container">
        @if (session('status') == 'success')
            <div class="alert alert-success">
                Payment Successful! Your transaction has been completed.
            </div>
        @elseif (session('status') == 'failure')
            <div class="alert alert-danger">
                Payment Failed! Please try again or contact support.
            </div>
        @endif
    </div>
    @if (session('payment_status') == 'success')
        <script>
            swal({
                title: "Payment Successful",
                text: "Your payment was processed successfully!",
                icon: "success",
                button: "OK",
            }).then(function() {
                window.location.href = "{{ route('payment.status') }}";
            });
        </script>
    @elseif (session('payment_status') == 'failure')
        <script>
            swal({
                title: "Payment Failed",
                text: "There was an issue processing your payment. Please try again.",
                icon: "error",
                button: "OK",
            }).then(function() {
                window.location.href = "{{ route('payment.status') }}";
            });
        </script>
    @endif
@endsection

@extends('admin.layouts.app')

@section('content')
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Approved Purchase List</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Approved Purchase List</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">

            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">
                        <div class="row seperatesec  white-inner">
                            <div class="card-header align-items-center d-flex">
                                <h4 class="card-title mb-0 flex-grow-1">
                                    Approved Purchase List

                                </h4>
                                @if (
                                    !empty(Auth::user()->roles) &&
                                        !empty(Auth::user()->roles[0]->title) &&
                                        (Auth::user()->roles[0]->title == 'Processor' || Auth::user()->roles[0]->title == 'Trader'))
                                    <a href="{{ route('superadmin.purchaseRequestPage') }}" class="btn btn-primary"
                                        style="float: right">New Purchase Request</a>
                                @endif
                            </div>
                            <!-- end card header -->
                            <div class="table-responsive">
                                <table id="inspSchedule" class="table table-bordered nowrap table-striped align-middle"
                                    style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>S.No.</th>
                                            <th>User Name</th>
                                            <th>Product</th>
                                            <th>Packages</th>
                                            <th>Quantity</th>
                                            <th>Status</th>
                                            <th>Order Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
@endsection
@push('script')
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        var table = $('#inspSchedule').DataTable({
            lengthMenu: [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
            ],
            processing: true,
            serverSide: true,
            ajax: {
                url: '{{ route('superadmin.approvedPurchaseList') }}',
                type: 'GET',
                data: function(d) {}
            },
            columns: [{
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex',
                    orderable: true
                },
                {
                    data: 'user_name',
                    name: 'user_name',
                    orderable: true
                },
                {
                    data: 'Commodity',
                    name: 'Commodity',
                    orderable: true
                },
                {
                    data: 'no_of_packages',
                    name: 'no_of_packages',
                    orderable: true
                },
                {
                    data: 'quantity',
                    name: 'quantity',
                    orderable: true
                },
                {
                    data: 'status',
                    name: 'status',
                    orderable: true
                },
                {
                    data: 'order_status',
                    name: 'order_status',
                    orderable: true
                },
                {
                    data: 'action',
                    name: 'action',
                    orderable: false
                },
            ],
        });



        function confirmDelete_(id) {

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.value) {
                    $.ajax({
                        url: "{{ route('superadmin.icsuser.deleteInspSchedule') }}",
                        method: "POST",
                        dataType: 'json',
                        data: {
                            'id': id,
                        },
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function(result) {

                            Swal.fire(
                                'Deleted!',
                                'Record Deleted Successfully..',
                                'success'
                            );
                            location.reload();

                        }
                    });

                }
            })
        }
    </script>
@endpush

@extends('admin.layouts.app')
@section('content')
    <style>
        .page-content {
            background: #F2FBF9;
        }
    </style>
    <!-- start page title -->
    {{-- <div class="row">
                        <div class="col-12">
                            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                <h4 class="mb-sm-0">Home</h4>

                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">Home</a></li>

                                    </ol>
                                </div>

                            </div>
                        </div>
                    </div> --}}
    <!-- end page title -->

      <!-- end page title -->
      <div class="row">
              {{--  <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                    <div class="card dashb-box gradient-colr">
                        <div class="card-body p-0">
                            <div class="img-part">
                                <img src="{{ asset('public/assets/images/micon-1.png') }}" alt="">
                            </div>
                            <div class="txt-part">
                                <p>Total Registered Users</p>
                                <h3 id="user_id"></h3>
                                <p id="user_date"></p>
                                <div class="digital-clock">00:00:00</div>

                            </div>
                        </div><!-- end card body -->
                    </div><!-- end card -->
                </div><!-- end col -->
                --}}
                <div class="col-12 col-sm-12 col-md-9 col-lg-9 col-xl-9 ps-2">
                    <div class="more-cards-inner">
                        <div class="card dashb-box blue-bx">
                            <div class="card-body p-0">
                                <div class="img-part">
                                    <img src="{{ asset('public/assets/images/micon-2.png') }}" alt="">
                                </div>
                                <div class="txt-part">
                                    <p>Total Sampling</p>
                                    <p class="colr-txt" id="ics_id">{{$lab}}</p>
                                </div>
                            </div><!-- end card body -->
                        </div><!-- end card -->
                        <div class="card dashb-box purple-bx">
                            <div class="card-body p-0">
                                
                                <div class="txt-part">
                                    <p>Genrated Report</p>
                                    <p class="colr-txt" id="individual_id">{{$genrate_report_lab}}</p>
                                </div>
                            </div><!-- end card body -->
                        </div><!-- end card -->
                       {{-- <div class="card dashb-box drk-brown-bx">
                            <div class="card-body p-0">
                                <div class="img-part">
                                    <img src="{{ asset('public/assets/images/micon-4.png') }}" alt="">
                                </div>
                                <div class="txt-part">
                                    <p>Processors</p>
                                    <p class="colr-txt" id="processor_id"></p>
                                </div>
                            </div><!-- end card body -->
                        </div><!-- end card -->
                        --}}
                        {{--
                        <div class="card dashb-box drk-blue-bx">
                            <div class="card-body p-0">
                                <div class="img-part">
                                    <img src="{{ asset('public/assets/images/micon-6.png') }}" alt="">
                                </div>
                                <div class="txt-part">
                                    <p>Wild Harvester</p>
                                    <p class="colr-txt" id="harvester_id"></p>
                                </div>
                            </div><!-- end card body -->
                        </div><!-- end card -->
                        --}}
                    {{--    <div class="card dashb-box yellow-bx">
                            <div class="card-body p-0">
                                <div class="img-part">
                                    <img src="{{ asset('public/assets/images/micon-7.png') }}" alt="">
                                </div>
                                <div class="txt-part">
                                    <p>Traders</p>
                                    <p class="colr-txt" id="trader_id"></p>
                                </div>
                            </div><!-- end card body -->
                        </div><!-- end card -->
                        <div class="card dashb-box green-bx">
                            <div class="card-body p-0">
                                <div class="img-part">
                                    <img src="{{ asset('public/assets/images/micon-5.png') }}" alt="">
                                </div>
                                <div class="txt-part">
                                    <p>Farmers</p>
                                    <p class="colr-txt" id="farmer_id"></p>
                                </div>
                            </div><!-- end card body -->
                        </div><!-- end card -->
                        <div class="card dashb-box pink-bx">
                            <div class="card-body p-0">
                                <div class="img-part">
                                    <img src="{{ asset('public/assets/images/micon-9.png') }}" alt="">
                                </div>
                                <div class="txt-part">
                                    <p>Farms</p>
                                    <p class="colr-txt" id="farm_id"></p>
                                </div>
                                <div class="txt-part total-txt">
                                    <p class="colr-txt" id=""></p>
                                </div>
                            </div><!-- end card body -->
                        </div><!-- end card -->
                        <div class="card dashb-box orng-bx">
                            <div class="card-body p-0">
                                <div class="img-part">
                                    <img src="{{ asset('public/assets/images/micon-8.png') }}" alt="">
                                </div>
                                <div class="txt-part">
                                    <p>Products</p>
                                    <p class="colr-txt" id="product_id"></p>
                                </div>
                            </div><!-- end card body -->
                        </div><!-- end card -->
                        --}}
                    </div>
                </div><!-- end col -->
            </div><!-- end row -->
        </div>
        {{-- <div class="row">
                        <div class="col-xl-12">
                            <div class="card crm-widget">
                                <div class="card-body p-0">
                                    <div class="row row-cols-xxl-5 row-cols-md-4 row-cols-1 g-0 white-inner">
                                        <div class="col-xxl-2 col-md-2">
                                            <div class="mt-2 mt-md-0 py-3 px-3">
                                                <h5 class="text-muted text-uppercase fs-13">ICS <i class="ri-arrow-up-circle-line text-success fs-18 float-end align-middle"></i></h5>
                                                <div class="d-flex align-items-center">
                                                    <div class="flex-shrink-0">
                                                        <i class="ri-user-line display-6 text-muted"></i>
                                                    </div>
                                                    <div class="flex-grow-1 ms-3">
                                                        <h2 class="mb-0"><span class="counter-value" data-target="{{$ics ?? '0'}}">0</span></h2>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!-- end col -->
                                        <div class="col-xxl-2 col-md-2">
                                            <div class="mt-2 mt-md-0 py-3 px-3">
                                                <h5 class="text-muted text-uppercase fs-13"> Individual Producer <i class="ri-arrow-up-circle-line text-success fs-18 float-end align-middle"></i></h5>
                                                <div class="d-flex align-items-center">
                                                    <div class="flex-shrink-0">
                                                        <i class="ri-user-line display-6 text-muted"></i>
                                                    </div>
                                                    <div class="flex-grow-1 ms-3">
                                                        <h2 class="mb-0"> <span class="counter-value" data-target="{{$individual ?? '0'}}">0</span></h2>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!-- end col -->
                                        <div class="col-xxl-2 col-md-2">
                                            <div class="mt-2 mt-md-0 py-3 px-3">
                                                <h5 class="text-muted text-uppercase fs-13">Wild Harvester <i class="ri-arrow-up-circle-line text-success fs-18 float-end align-middle"></i></h5>
                                                <div class="d-flex align-items-center">
                                                    <div class="flex-shrink-0">
                                                        <i class="ri-user-line display-6 text-muted"></i>
                                                    </div>
                                                    <div class="flex-grow-1 ms-3">
                                                        <h2 class="mb-0"><span class="counter-value" data-target="{{$harvester ?? '0'}}">0</span></h2>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!-- end col -->
                                        <div class="col-xxl-2 col-md-2">
                                            <div class="mt-2 mt-lg-0 py-3 px-3">
                                                <h5 class="text-muted text-uppercase fs-13">Trader <i class="ri-arrow-up-circle-line text-success fs-18 float-end align-middle"></i></h5>
                                                <div class="d-flex align-items-center">
                                                    <div class="flex-shrink-0">
                                                        <i class="ri-user-line display-6 text-muted"></i>
                                                    </div>
                                                    <div class="flex-grow-1 ms-3">
                                                        <h2 class="mb-0"><span class="counter-value" data-target="{{$trader ?? '0'}}">0</span></h2>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!-- end col -->
                                        <div class="col-xxl-2 col-md-2">
                                            <div class="mt-3 mt-lg-0 py-3 px-3">
                                                <h5 class="text-muted text-uppercase fs-13">Processor <i class="ri-arrow-up-circle-line text-success fs-18 float-end align-middle"></i></h5>
                                                <div class="d-flex align-items-center">
                                                    <div class="flex-shrink-0">
                                                        <i class="ri-user-line display-6 text-muted"></i>
                                                    </div>
                                                    <div class="flex-grow-1 ms-3">
                                                        <h2 class="mb-0"><span class="counter-value" data-target="{{$processor ?? '0'}}">0</span></h2>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!-- end col -->
                                        <div class="col-xxl-2 col-md-2">
                                            <div class="mt-3 mt-lg-0 py-3 px-3">
                                                <h5 class="text-muted text-uppercase fs-13">Mandator <i class="ri-arrow-up-circle-line text-success fs-18 float-end align-middle"></i></h5>
                                                <div class="d-flex align-items-center">
                                                    <div class="flex-shrink-0">
                                                        <i class="ri-user-line display-6 text-muted"></i>
                                                    </div>
                                                    <div class="flex-grow-1 ms-3">
                                                        <h2 class="mb-0"><span class="counter-value" data-target="{{$mandators ?? '0'}}">0</span></h2>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                         <!-- end col -->
                                    </div><!-- end row -->
                                </div><!-- end card body -->
                            </div><!-- end card -->
                        </div><!-- end col -->
                    </div><!-- end row --> --}}

        {{-- <div class="row">
                        <div class="col-xl-12">
                            <div class="card crm-widget ">
                                <div class="card-body p-0 white-inner">
                                    <div class="row row-cols-xxl-5 row-cols-md-4 row-cols-1 g-0">

                                        <div class="col-xxl-12 col-md-12">
                                            <div class="mt-2 mt-md-0 py-3 px-3">

                                                <div class="d-flex align-items-center">

                                                     text here
                                                </div>
                                            </div>
                                        </div><!-- end col -->


                                         <!-- end col -->
                                    </div><!-- end row -->
                                </div><!-- end card body -->
                            </div><!-- end card -->
                        </div><!-- end col -->
                    </div><!-- end row --> --}}

      

   
  
        <style>
            .form-check-inline {
                display: inline-block;
                margin-right: 0%;
            }
        </style>
   

@endsection
@push('script')
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>


    <script>

    $('#sc_certificate').on('change', function(e){
        //alert('aaa');
        $('#sc_form').submit();
    });
        $(document).ready(function() {
            $('#dtBasicExample').DataTable();
            $('.dataTables_length').addClass('bs-select');
        });
        $(document).ready(function() {
            $('#dtBasicExamplesss').DataTable();
            $('.dataTables_length').addClass('bs-select');
        });

        google.charts.load("current", {
            packages: ['corechart', 'bar']
        });
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {
            var data = google.visualization.arrayToDataTable([
                ['Task', 'Hours per Day'],
                ['Total Units', 30],
                ['Dropped Units', 70],
            ]);
            var options = {
                pieHole: 0.5,
            };
            var chart = new google.visualization.PieChart(document.getElementById('donutchart1'));
            chart.draw(data, options);
        }


        google.charts.setOnLoadCallback(drawBasic);

        function drawBasic() {


            // var data = new google.visualization.DataTable();
            // data.addColumn('string', 'State');
            // data.addColumn('number', 'Registered');
            // data.addColumn('role', 'style');

            // data.addRows([
            //     @foreach ($icsWithFarmerCount as $val)
            //     ['{{ $val->first_name }}', {{ $val->users }}, 'gold'],
            //     @endforeach


            // ]);

            var data = google.visualization.arrayToDataTable([
                ['State', 'Registered', {
                    role: 'style'
                }],
                // ['Copper', 8.94, '#b87333'],            // RGB value
                // ['Silver', 10.49, 'silver'],            // English color name
                // ['Gold', 19.30, 'gold'],
                // ['Platinum', 21.45, 'color: #e5e4e2' ], // CSS-style declaration

                @foreach ($icsWithFarmerCount as $val)
                    ['{{ $val->first_name }}', {{ $val->users }}, '#359f68'],
                @endforeach
            ]);



            var options = {
                title: 'No. of Operators Registered',
                hAxis: {
                    title: '',
                },
                vAxis: {
                    title: ''
                }
            };

            var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));
            chart.draw(data, options);
        }



        //   google.charts.load('current', {'packages':['bar']});
        google.charts.setOnLoadCallback(drawChart2);

        function drawChart2() {
            var t1 = 0;
            @foreach ($llast_month_users as $val)
                t1 = t1 + {{ $val->users }}
            @endforeach

            var apr = "{{ getDashboardmandator(4) }}";
            var may = "{{ getDashboardmandator(5) }}";
            var jun = "{{ getDashboardmandator(6) }}";

            var t2 = 0;
            @foreach ($last_month_users as $val)
                t2 = t2 + {{ $val->users }}
            @endforeach

            var t3 = 0;
            @foreach ($cur_month_users as $val)
                t3 = t3 + {{ $val->users }}
            @endforeach
            var data = google.visualization.arrayToDataTable([
                ['Month', 'ICS', 'Individual Producer', 'Wild Harvestor', 'Trader', 'Processor', 'Mandator',
                    'Total Operator'
                ],
                ['April',
                    {{ getDashboardGraph(4, 2) }},
                    {{ getDashboardGraph(4, 3) }},
                    {{ getDashboardGraph(4, 4) }},
                    {{ getDashboardGraph(4, 5) }},
                    {{ getDashboardGraph(4, 6) }},
                    {{ getDashboardmandator(4) }}, t1 + {{ getDashboardmandator(4) }}
                ],
                ['May',
                    {{ getDashboardGraph(5, 2) }},
                    {{ getDashboardGraph(5, 3) }},
                    {{ getDashboardGraph(5, 4) }},
                    {{ getDashboardGraph(5, 5) }},
                    {{ getDashboardGraph(5, 6) }},
                    {{ getDashboardmandator(5) }}, t2 + {{ getDashboardmandator(5) }}
                ],
                ['June',
                    {{ getDashboardGraph(6, 2) }},
                    {{ getDashboardGraph(6, 3) }},
                    {{ getDashboardGraph(6, 4) }},
                    {{ getDashboardGraph(6, 5) }},
                    {{ getDashboardGraph(6, 6) }},
                    {{ getDashboardmandator(6) }}, t3 + {{ getDashboardmandator(6) }}
                ],

            ]);

            var options = {
                chart: {
                    subtitle: 'Month Wise',
                },
                bars: 'vertical'
            };

            var chart = new google.charts.Bar(document.getElementById('barchart_material'));

            chart.draw(data, google.charts.Bar.convertOptions(options));
        }

        google.charts.setOnLoadCallback(pieChart);

        function pieChart() {

            var data = google.visualization.arrayToDataTable([
                ['Task', 'Hours per Day'],

                @foreach ($operatorCountByState as $val)
                    @if (isset($val['ref_state_id']) && $val['ref_state_id'] != '')
                        ['{!! get_state_name($val['ref_state_id']) !!}', {{ $val['users'] }}],
                    @endif
                @endforeach
                ///['Work',     11],
                //['Eat',      2],
                //   ['Commute',  3],
                //   ['Watch TV', 5],
                //   ['Sleep',    7]
            ]);

            var options = {
                title: 'No. of Operators Registered',
                is3D: true,
            };

            var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
            chart.draw(data, options);
        }

        google.charts.setOnLoadCallback(drawChart4);

        function drawChart4() {
            var data = google.visualization.arrayToDataTable([
                ['Year', 'TC'],
                ['2013', 100],
                ['2014', 30],
                ['2015', 60],
                ['2016', 10],
                ['2017', 80],
                ['2018', 60],
                ['2019', 10],
                ['2020', 20],
                ['2021', 40],
                ['2022', 30],
                ['2023', 90]
            ]);

            var options = {
                title: 'Total TC Issued',
                hAxis: {
                    title: 'Year',
                    titleTextStyle: {
                        color: '#333'
                    }
                },
                vAxis: {
                    minValue: 0
                }
            };

            var chart = new google.visualization.AreaChart(document.getElementById('chart-area'));
            chart.draw(data, options);
        }


        $(document).ready(function() {
            $('#loading').html('Page is loaded!');

        });
    </script>
    <script>
      


       
    </script>
@endpush

@extends('admin.layouts.app')
@section('content')
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Registered Lab</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Registered Lab</li>
                </ol>
            </div>

        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1">Lab List</h4>


            <a href="{{route('superadmin.addLab')}}" class="btn btn-primary" style="float: right">Add LAB</a>
            </div>

        </div>

        <div class="card-body table-responsive">
            <table id="farmerTable" class="table table-bordered table-striped align-middle" style="width:100%">
                <thead>
                    <tr>
                        <th>S.No.</th>
                        <th>Name</th>
                        <th>Email Id</th>
                        <th>Mobile No</th>
                        {{-- <th>Status:</th> --}}
                        <th>Action</th>
                    </tr>
                </thead>

            </table>
        </div>
    </div>
</div>






@endsection
@push('script')
<script>

var table =$('#farmerTable').DataTable({
        //dom: 'l<"clear">Bfrtip',
        //dom:'Bfrtip',
       //dom:'Blfrtip',
        lengthMenu : [[10, 25, 50, -1], [10, 25, 50, "All"]],
        processing: true,
        serverSide: true,
        ajax: {
            url: '{{ route("superadmin.registeredLab") }}',
            type: 'GET',
            data: function (d) {
                d.operator = $('#operator').val();
            }
          },
        columns: [
            {data: 'DT_RowIndex', name: 'DT_RowIndex',orderable: false  },
            { data: 'lab_name', name: 'lab_name',orderable: true  },
            { data: 'lab_email',name:'lab_email',orderable: true },
            { data: 'lab_tel',name:'lab_tel',orderable: true },
            { data: 'action', name: 'name',orderable: false },
        ],


    });

    </script>
@endpush

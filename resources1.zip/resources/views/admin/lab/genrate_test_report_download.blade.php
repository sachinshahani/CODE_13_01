<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Organic Test Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            background-color: #f9f9f9;
        }
        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
            background: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            /* border-bottom: 2px solid #4CAF50; */
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 10px;
        }
        header h1 {
            margin: 70;
            text-align: left;
            width: 100%;
            color: #0f110f;
        }
        .logo {
            height: 50px;
            width: auto;
            position: absolute;
            right: 10px;
            top: 10px;
        }
        .center-logo {
            display: flex;
            justify-content: center;
            align-items: center;
            position: absolute;
            left: 0;
            right: 0;
            top: 10%;
            transform: translateY(-50%);
        }
        .center-logo img {
            height: 50px; /* Adjust as needed */
            width: auto;
        }
        .report-info, .details, .results {
            margin-bottom: 20px;
        }
        .report-info table, .results table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .report-info table th, .results table th,
        .report-info table td, .results table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        /* .report-info table th, .results table th {
            background-color: #0c0c0c;
            color: white;
        } */
        .details h2, .results h2 {
            text-align: center;
            /* color: #4CAF50;
            border-bottom: 2px solid #4CAF50; */
            display: inline-block;
            padding-bottom: 5px;
            margin-bottom: 20px;
        }
        .details .detail-row {
            display: flex;
            justify-content: space-between;
            padding: 10px;
            /* border: 2px solid #4CAF50; */
            border-radius: 5px;
            margin-bottom: 10px;
            background-color: #f1f1f1;
        }
        .details .detail-row div {
            flex: 1;
            padding: 0 10px;
            word-wrap: break-word;
        }
        .details .detail-row div:nth-child(odd) {
            /* background-color: #e9f7ef; */
        }
        .signature {
            text-align: right;
            margin-top: 50px;
            /* color: #4CAF50; */
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>Test Report</h1>
            <div class="center-logo">
                <img src="{{ asset('public/assetss/images/nabl.png') }}" alt="Certificate Logo">
            </div>
            <img src="{{ asset($lab->lab_logo ?? '') }}" class="logo">
        </header>

        <div class="report-info">
            <table>
                <tr>
                    <th>Report No:</th>
                    <td>{{($sample_data->lab_code)}}</td>
                    <th>ULR:</th>
                    <td>{{$inspIds->tc_no ?? ''}}</td>
                </tr>
                <tr>
                    <th>Date of Issue:</th>
                    <td>{{dateFormat($LabTestReport->created_at ?? '--')}}</td>
                    <th>Issue to:</th>
                    <td>{{$tranEntry->buyer_name ?? '--'}}</td>
                </tr>
                <tr>
                    <th>Job Ref No:</th>
                    <td>TR/2424/20-21</td>
                    <th>Place of receipt/ Lab:</th>
                    <td>{{$sample_data->place_sampling ?? '' }}</td>
                </tr>
                <tr>
                    <th>Group:</th>
                    <td>Food and Agriculture Products</td>
                    <th>SubGroup:</th>
                    <td>Cereal Pulses and Cereal Products</td>
                </tr>
                <tr>
                    <th>Discipline:</th>
                    <td>Chemical</td>
                    <th>Sample receipt date:</th>
                    <td>{{dateFormat($sample_data->drawn_sample_date ?? '') }}</td>
                </tr>
                <tr>
                    <th>City:</th>
                    <td>{{$lab->lab_city ?? '' }}</td>
                    <th>Analysis Start date:</th>
                    <td>{{dateFormat($sample_data->drawn_sample_date ?? '') }}</td>
                </tr>
                <tr>
                    <th>PIN/ZIP:</th>
                    <td>{{$lab->lab_pin ?? '' }}</td>
                    <th>Analysis Completion Date:</th>
                    <td>{{dateFormat($sample_data->drawn_sample_date ?? '') }}</td>
                </tr>
                <tr>
                    <th>State:</th>
                    <td>{{getStateNameById($lab->ref_state_id ?? '') }}</td>
                    <th>Quantity of sample received:</th>
                    <td>{{($sample_data->sample_retains_qty ?? '')  }} Kg</td>
                </tr>
                <tr>
                    <th>Country:</th>
                    <td>India</td>
                    <th>Condition of sample on receipt:</th>
                    <td>Intact</td>
                </tr>
                <tr>
                    <th>Address:</th>
                    <td colspan="3">{{$lab->lab_address ?? '' }}</td>
                </tr>
            </table>
        </div>

        <div class="details">
            <h2 >Details of Sample (Customer Provided Information)</h2>
            <div class="detail-row">
                <div>Name and address of Exporter</div>
                <div> {{$tranEntry->buyer_name ?? '--'}}, {{$tranEntry->buyer_address ?? '--'}}</div>
            </div>
            <div class="detail-row">
                <div>Lot No./ Batch No</div>
                <div> {{$tranEntry->lot_number ?? '--'}}</div>
            </div>
            <div class="detail-row">
                <div>Quantity of Lot/ batch</div>
                <div>{{$tranEntry->total_qty ?? '--'}}MT</div>
            </div>
            <div class="detail-row">
                <div>Packing details</div>
                <div>1 kg x 20</div>
            </div>
            <div class="detail-row">
                <div>Commodity Name</div>
                <div>Rice</div>
            </div>
            <div class="detail-row">
                <div>Commodity Grade</div>
                <div>Pusa Creamy sella Basmati Rice (Grade B)</div>
            </div>
            <div class="detail-row">
                <div>Brand Name</div>
                <div>Maharani(Yellow)</div>
            </div>
            <div class="detail-row">
                <div>Sample Description</div>
                <div>Pusa Creamy sella Basmati Rice (Grade B)</div>
            </div>
            <div class="detail-row">
                <div>Buyer Name</div>
                <div>Fadie Food</div>
            </div>
            <div class="detail-row">
                <div>Importing country/ Port of Discharge</div>
                <div>Rotterdam (Netherlands)</div>
            </div>
            <div class="detail-row">
                <div>Invoice Number & date</div>
                <div> {{$tranEntry->invoice_no ?? '--'}} &  {{dateFormat($tranEntry->invoice_date ?? '--')}}</div>
            </div>
            <div class="detail-row">
                <div>Contract Number</div>
                <div>{{$tranEntry->invoice_no ?? '--'}}</div>
            </div>
            <div class="detail-row">
                <div>Manufactured/ Processed By</div>
                <div>{{$tranEntry->buyer_name ?? '--'}}</div>
            </div>
            <div class="detail-row">
                <div>Supplied by</div>
                <div>{{$tranEntry->buyer_name ?? '--'}}</div>
            </div>
            <div class="detail-row">
                <div>Manufacturing Date</div>
                <div>{{dateFormat($LabTestReport->test_start_date ?? '--')}}</div>
            </div>
            <div class="detail-row">
                <div>Expiry Date</div>
                <div>{{dateFormat($LabTestReport->test_end_date ?? '--')}}</div>
            </div>
            <div class="detail-row">
                <div>Location</div>
                <div>{{$lab->lab_city ?? '' }}</div>
            </div>
            <div class="detail-row">
                <div>Sampling details</div>
                <div>The customer has provided the declaration stating that the sample submitted for analysis for above stated lot number has been drawn in accordance with Codex document containing recommended method of sampling for determination of pesticide residue for compliance with MRLs CAC/GL-33-1999.</div>
            </div>
            <div class="detail-row">
                <div>Number of packs sampled</div>
                <div>---</div>
            </div>
            <div class="detail-row">
                <div>Submitted By</div>
                <div>{{$tranEntry->buyer_name ?? '--'}}</div>
            </div>
            <div class="detail-row">
                <div>Other info, if any</div>
                <div>--</div>
            </div>
        </div>

        <div class="results">
            <h2>Test Results</h2>
            <table>
                <thead>
                    <tr>
                        <th>SNo. </th>
                        <th>Parameter tested for</th>
                        <th>Unit of Measurement</th>
                        <th>Results with corrected recovery along with
                            level of recovery</th>
                        <th>Limit of determination/ quantification:
                            LOQ/CCα/ CCβ, as applicable(e.g. LOQ in case
                            of pesticide, CCβ for screening test, CCα for
                            drug and contaminates, etc.)</th>
                            <th>LOD (as applicable)</th>
                            <th>Level of action (i.e. Conc. Above which
                                results are deemed non compliant) e.g.
                                MRL/ MRPL/ML</th>
                        <th>Analytical method (e.g. ELISA, Delvo test,
                            Pour plate, TLC, HPLC, LCMS etc.)</th>
                        <th>Specification/ Standard/ test method against
                            which product is tested like AOAC, BIS, in
                            house method, etc</th>
                        <th>Validation protocol (e.g. specify 2002/ 657/
                            EC, IUPAC, CODEX etc.</th>
                            <th>Remark (Conformity with the level of
                                action)</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>

                        @forelse($LabTestReports as $LabTestReport)
                        <tr>
                            <td>{{ $loop->iteration }}</td>
                            <td>{{ $LabTestReport->test_parameter_id }}</td>
                            <td>mg/kg</td>
                            <td>BLQ</td>
                            <td>0.005</td>
                            <td>0.005</td>
                            <td>{{$LabTestReport->blq}}</td>
                            <td>LCMS-MS</td>
                            <td>CommGrade/L3-GGN-FOO-009</td>
                            <td>SANTE/11813/2017</td>
                            <td>{{ $LabTestReport->result }}</td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="10">No Lab Test Reports available.</td>
                        </tr>
                        @endforelse



                    </tr>

                    <!-- Additional rows as needed -->
                </tbody>
            </table>
        </div>

        <div class="signature">
            <p>For National Collateral Management Services Limited</p>
            <p>Gulveer Chaudhary</p>
            <p>Technical Manager</p>
            <p>(Authorized Signatory)</p>
        </div>
    </div>
</body>
</html>




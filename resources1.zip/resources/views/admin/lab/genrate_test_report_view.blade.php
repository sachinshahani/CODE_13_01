@extends('admin.layouts.app')
@section('content')
<style>
    body {
        margin: 0px;
        padding: 0px;
        font-family: "Segoe UI";
    }

    .maindiv {
        width: 80%;
        margin: 0 auto;
    }

    .pdf_maindiv {
        border: 1px solid #cccccc;
        width: 100%;
        float: left;
        padding: 2% 1%;
    }

    .pdf_heading {
        font-size: 20px;
        color: #000;
        padding: 26px 0 20px 0px;
        position: relative;
        width: 100%;
        float: left;
    }

    .brd_heading {
        border-bottom: 2px solid #ee5e24;
        padding-bottom: 8px;
        padding-right: 8px;
        width: 60px;
    }

    .pdf_input1 {
        background: #eeeeee;
    }

    .pdf_txt1 {
        color: #000;
        font-size: 14px;
        width: 45%;
        float: left;
        padding-bottom: 10px;
        font-weight: bold;
    }

    .pdf_box {
        color: #000;
        font-size: 14px;
        width: 55%;
        float: left;
        padding-bottom: 10px;
    }

    .table_pdf {
        width: 100%;
    }

    .pdf_heading:after {
        content: "";
        position: absolute;
        width: 70px;
        height: 2px;
        background-color: #ee5e24;
        bottom: 10px;
        display: block;
    }

    .pdf_heading:before {
        content: "";
        position: absolute;
        width: 22px;
        height: 6px;
        background-color: #ee5e24;
        bottom: 8px;
        display: block;
    }

    #step1 .card-body {
        background: #fff
    }

    .pdf_inner_heading:after {
        display: none;
    }

    .pdf_inner_heading:before {
        display: none;
    }

    .pdf_inner_heading {
        padding: 20px 0 12px;
        text-decoration: underline;
        font-size: 16px;
    }

    .pdf_maindiv hr:last-child {
        display: none;
    }

    .pdf-img-icon {
        height: 17px;
        width: 15px;
        margin-right: 5px;
    }

    @media print {

        .pdf_heading {
            font-size: 20px;
            color: #000;
            padding: 26px 0 20px 0px;
            position: relative;
            width: 100%;
            float: left;
            -webkit-print-color-adjust: exact !important;
            Chrome,
            Safari color-adjust: exact !important;
        }

        .pdf_heading:before {
            content: "";
            position: absolute;
            width: 20px;
            height: 4px;
            background-color: #ee5e24;
            bottom: 10px;
            display: block;
            -webkit-print-color-adjust: exact !important;
            Chrome,
            Safari color-adjust: exact !important;
        }


    }
</style>
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Test Report Details</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Test Report Details</li>
                </ol>
            </div>

        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">

        <div class="tab-content py-4 custom-tab-content">
            <div class="tab-pane fade show active" id="step1">
                <div class="card">
                    <div class="card-body">

                        <div class="pdf_heading">Enter Test Report Details</div>
                        <div style="display: flex; justify-content: flex-end;">
                            <button class="btn btn-primary btn-sm">View Application</button>
                        </div>
                        <div class="pdf_maindiv">
                            <!--form1 section starts here-->
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                            <tr>
                                                <td class="pdf_txt1">Test Start Date  :</td>
                                                <td class="pdf_box"><input type="text" name="sample_code" value="{{now()}}"  class="form-control" readonly/></td>
                                            </tr>
                                            <tr>
                                                        <td class="pdf_txt1">Test Report No. :</td>
                                                        <td class="pdf_box">{{$inspIds->transaction_certificate_no ?? ''}}</td>
                                            </tr>
                                            

                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                    <div class="col-6">
                                       
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">

                                        <tr>
                                            <td class="pdf_txt1">Test Ending Date :</td>
                                            <td class="pdf_box">
                                            <input type="text" name="sample_code" value="{{now()}}"  class="form-control" readonly/>
                                            </td>
                                        </tr>

                                            <tr>
                                            <td class="pdf_txt1">Product Name :</td>
                                                <td class="pdf_box"> {{$inspIds->operator_type ?? ''}}</td>
                                                
                                            </tr>

                                        </table>
                                      
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="pdf_maindiv">
                            <!--form1 section starts here-->
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-6">
                                        <form method="post" action="{{route('superadmin.lab.forward_sample_details')}}">
                                            @csrf

                                            <input type="hidden" name="at_org_sample_rtn_dtl_id" value="{{$id}}"  class="form-control" />
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                            <tr>
                                                <td class="pdf_txt1">Test Parameter :</td>
                                                <td class="pdf_box"> <input type="text" name="sample_code" value="{{$sample_data->sample_code}}"  class="form-control" readonly/></td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">BLQ :</td>
                                                <td class="pdf_box"> <input type="date" name="drawn_sample_date" value="{{$sample_data->drawn_sample_date}}" class="form-control" readonly/></td>
                                            </tr>
                                           
                                           
                                        </table>

                                       
                                    </div>

                                    <div class="col-6">

                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                            <tr>
                                                <td class="pdf_txt1">Equipment/Method of Analysis :</td>
                                                <td class="pdf_box"> <input type="text" name="sample_weight" value="{{$sample_data->sample_weight}}" class="form-control" readonly/></td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Result :</td>
                                                <td class="pdf_box"> <input type="text" name="person_name"  class="form-control"  value="{{$sample_data->person_name}}" readonly/></td>
                                            </tr>
                                           
                                           
                                        </table>
                                        <div style="margin-top: 10px;">
                                            <button type="submit" id="submitbtn" class="btn btn-primary submit-button">Save Test Report</button>
                                            
                                        </div>
                                    </div>
                                    <form>

                                </div>
                            </div>
                        </div>
               
                       

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

</div>
</div>
@endsection

@push('script')
<script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
<script>
    $(document).on('click', '#submitbtn', function() {

        if (checkValidation("registration")) {
            $('#registration').submit();
            return true;
        } else {
            return false;
        }
    });
</script>
@endpush
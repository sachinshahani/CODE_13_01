@extends('admin.layouts.app')
@section('content')
<style>
    body {
        margin: 0px;
        padding: 0px;
        font-family: "Segoe UI";
    }

    .maindiv {
        width: 80%;
        margin: 0 auto;
    }

    .pdf_maindiv {
        border: 1px solid #cccccc;
        width: 100%;
        float: left;
        padding: 2% 1%;
    }

    .pdf_heading {
        font-size: 20px;
        color: #000;
        padding: 26px 0 20px 0px;
        position: relative;
        width: 100%;
        float: left;
    }

    .brd_heading {
        border-bottom: 2px solid #ee5e24;
        padding-bottom: 8px;
        padding-right: 8px;
        width: 60px;
    }

    .pdf_input1 {
        background: #eeeeee;
    }

    .pdf_txt1 {
        color: #000;
        font-size: 14px;
        width: 45%;
        float: left;
        padding-bottom: 10px;
        font-weight: bold;
    }

    .pdf_box {
        color: #000;
        font-size: 14px;
        width: 55%;
        float: left;
        padding-bottom: 10px;
    }

    .table_pdf {
        width: 100%;
    }

    .pdf_heading:after {
        content: "";
        position: absolute;
        width: 70px;
        height: 2px;
        background-color: #ee5e24;
        bottom: 10px;
        display: block;
    }

    .pdf_heading:before {
        content: "";
        position: absolute;
        width: 22px;
        height: 6px;
        background-color: #ee5e24;
        bottom: 8px;
        display: block;
    }

    #step1 .card-body {
        background: #fff
    }

    .pdf_inner_heading:after {
        display: none;
    }

    .pdf_inner_heading:before {
        display: none;
    }

    .pdf_inner_heading {
        padding: 20px 0 12px;
        text-decoration: underline;
        font-size: 16px;
    }

    .pdf_maindiv hr:last-child {
        display: none;
    }

    .pdf-img-icon {
        height: 17px;
        width: 15px;
        margin-right: 5px;
    }

    @media print {

        .pdf_heading {
            font-size: 20px;
            color: #000;
            padding: 26px 0 20px 0px;
            position: relative;
            width: 100%;
            float: left;
            -webkit-print-color-adjust: exact !important;
            Chrome,
            Safari color-adjust: exact !important;
        }

        .pdf_heading:before {
            content: "";
            position: absolute;
            width: 20px;
            height: 4px;
            background-color: #ee5e24;
            bottom: 10px;
            display: block;
            -webkit-print-color-adjust: exact !important;
            Chrome,
            Safari color-adjust: exact !important;
        }


    }
</style>
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Manage Test Parameter</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Manage Test Parameter</li>
                </ol>
            </div>

        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">

        <div class="tab-content py-4 custom-tab-content">
            <div class="tab-pane fade show active" id="step1">
                <div class="card">
                    <div class="card-body">

                
                     
                        <div class="pdf_heading">Manage Test Parameter</div>
                        <div class="pdf_maindiv">
                            <!--form1 section starts here-->
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-6">
                                        <form method="post" action="{{route('superadmin.lab.forward_sample_details')}}">
                                            @csrf
                                            <div class="row">
                                            <div class="col-lg-6">
                                                    <label>Select Test Name :</label>
                                                   
                                                    <select class="form-select" name="status" id="search" data-label-msg="Status" required>
                                                        <option value="">Select </option>
                                                        <option value="all">Chemist</option>
                                                        <option value="0">Payment Collector</option>
                                                        <option value="1">Sample Collector</option>
                                                        <option value="2">Sample Receiver</option>
                                                    </select>
                                                  
                                            </div>
                                            <div class="col-md-6" style="margin-top:25px;">
                                                <button type="button" onclick="correspondence_modal()" class="btn btn-primary" data-toggle="modal" >Add new Category</button>
                                        
                                                <button type="button" onclick="add_new_unit()" class="btn btn-primary submit-button"  data-toggle="modal">Add new Unit</button>
                                            </div>
                                           

                                       
                                    </div>
                                    
                                    
                                    <form>

                                </div>
                            </div>
                        </div>
               
                       

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

</div>
</div>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">Add category</h4>
                <button type="button" class="close" onclick="close_popup()" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">

            <label>Test Category :</label>
             <select class="form-select" name="status" id="search" data-label-msg="Status" required>
                            <option value="">Select</option>
                            <option value="all">All</option>
                            <option value="0">Pending</option>
                          
            </select>
            
            <label>Test Name :</label>
            <input type="text" name="sample_retaining_date"  class="form-control" />
            </div>
            <div class="modal-footer">
                <!-- Modal Footer Content -->
                <!-- Add your modal footer content here -->
                <button type="button" class="btn btn-primary" data-dismiss="modal">Save</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel1">Add MRL Unit</h4>
                <button type="button" class="close" onclick="close_popup1()" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">

           
            
            <label>MRL Unit :</label>
            <input type="text" name="sample_retaining_date"  class="form-control" />
            </div>
            <div class="modal-footer">
                <!-- Modal Footer Content -->
                <!-- Add your modal footer content here -->
                <button type="button" class="btn btn-primary" data-dismiss="modal">Save</button>
            </div>
        </div>
    </div>
</div>
@endsection

@push('script')

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


    <script>
      function correspondence_modal() {
        $('#myModal').modal('show'); // Show the modal
    }
    function close_popup()
                {
                    $('#myModal').modal('hide');
                    
                    
                }

                function add_new_unit() {
        $('#myModal1').modal('show'); // Show the modal
    }
    function close_popup1()
                {
                    $('#myModal1').modal('hide');
                    
                    
                }
</script>

@endpush
@extends('admin.layouts.app')

@section('content')

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Sampling Receipt List</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Sampling Receipt List</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
       
    <div class="tab-content py-4 custom-tab-content">
        <div class="tab-pane fade show active" id="step1">
            <div class="card">
                <div class="card-header align-items-center d-flex">
                    <h4 class="card-title mb-0 flex-grow-1">
                    Sampling Receipt List
                    </h4>
                  </div>
                <!-- end card header -->
                <div class="card-body">

                    
                    <table id="farmerTable" class="table table-bordered dt-responsive nowrap table-striped align-middle" style="width:100%">
                        <thead>
                            <tr>
                                <th>Lot/Tc No.</th>
                                <th>Operator Name</th>
                                <th>Sample Code No.</th>
                                <th>Date of Sampling</th>
                                <th>Action</th> 

                              
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div>
</div>



@endsection
@push('script')
<script>

$.ajaxSetup({
      headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      }
});

var table =$('#farmerTable').DataTable({
        //dom: 'l<"clear">Bfrtip',
        //dom:'Bfrtip',
       //dom:'Blfrtip',
        lengthMenu : [[10, 25, 50, -1], [10, 25, 50, "All"]],
        processing: true,
        serverSide: true,
        ajax: {
            url: '{{ route("superadmin.lab.sampling_receiplat_list") }}',
            type: 'GET',
            data: function (d) {
                d.operator = $('#operator').val();
            }
          },
        columns: [
            { data: 'tc_no', name: 'tc_no',orderable: true  },
            { data: 'company_name',name:'company_name',orderable: true },
            { data: 'sample_code',sample_code:'name',orderable: true },
            
           
            { data: 'drawn_sample_date',name:'drawn_sample_date',orderable: true },
            { data: 'action', name: 'name',orderable: false },
        ],
        // initComplete: function () {
        //     var btns = $('.dt-button');
        //     //btns.addClass('btn btn-success btn-success');
        //     btns.removeClass('dt-button');

        // },

    });

    $("#filterButton").click(function(){
            table.draw();
    });

    function confirmDelete_(id) {

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.value) {
                $.ajax({
                    url: "{{ route('superadmin.icsuser.deleteinspector') }}",
                    method: "POST",
                    dataType: 'json',
                    data: {
                        'id': id,
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(result) {
                     
                        Swal.fire(
                            'Deleted!',
                            'Record Deleted Successfully..',
                            'success'
                        );
                        location.reload();

                    }
                });

            }
        })
    }
</script>
@endpush

@extends('admin.layouts.app')
@section('content')

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0" style="float: left">
                   
                   LAB Details
                  
                </h5>

                <div class="row justify-content-end mb-2">
                    <!-- <div class="col-md-3 text-right">
                        <select class="form-select" name="status" id="search" data-label-msg="Status" required>
                            <option value="">Select status</option>
                            <option value="all">All</option>
                            <option value="0">Pending</option>
                            <option value="1">Profile Completed</option>
                            <option value="2">Approve</option>
                            <option value="3">Reject</option>
                        </select>
                    </div> -->
                  
                    <div class="col-2">
                       
                        <a href="{{route('superadmin.lab_register')}}" class="btn btn-primary" style="float: right">Add LAB</a>
                       

                        

                    </div>
                </div>

            </div>
            <div class="card-body table-responsive">
                <table id="deptUser" class="table table-bordered table-striped align-middle" style="width:100%">
                    <thead>
                        <tr>
                            <th>S.No.</th>
                            <th>LAB Name</th>
                            <th>LAB User ID</th>
                            <th>LAB Number</th>
                            <th>Created On</th>
                            <!-- <th>Action</th> -->
                        </tr>
                    </thead>
                    <tbody>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!--end col-->
</div>
<!--end row-->

@endsection



@push('script')
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    var table = $('#deptUser').DataTable({
                //dom: 'l<"clear">Bfrtip',
                dom: 'Bfrtip',

                //dom:'Blfrtip',
                lengthMenu: [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
                processing: true,
                serverSide: true,
                ajax: {
                    url: '{{ route('superadmin.lab_register_list') }}',
                    type: 'GET',
                    data: function(d) {
                        d._token = "{{ csrf_token() }}";
                        d.status = $("#search").val();
                    }

                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: true
                    },
                    {
                        data: 'lab_id',
                        name: 'lab_id',
                        orderable: true
                    },
                    {
                        data: 'user_name',
                        name: 'user_name',
                        orderable: true
                    },
                    {
                        data: 'mobile',
                        name: 'mobile',
                        orderable: true
                    },
                    {
                        data: 'created_on',
                        name: 'created_on',
                        orderable: true
                    },
                    // {
                    //     data: 'action',
                    //     name: 'name',
                    //     orderable: true
                    // },
                ],
                // initComplete: function () {
                //     var btns = $('.dt-button');
                //     //btns.addClass('btn btn-success btn-success');
                //     btns.removeClass('dt-button');

                // },

                paging: false,
                        dom: 'Bfrtip',
                        buttons: [                             
                            'excelHtml5',                             
                            {
                                extend : 'csvHtml5',
                                title : function() {
                                    return "REPORTS";
                                },
                                
                                
                                titleAttr : 'CSV REPORTS'
                            },
                            {
                                extend : 'pdfHtml5',
                                title : function() {
                                    return "PDF REPORTS";
                                },
                                orientation : 'landscape',
                                pageSize : 'A4',
                               
                                titleAttr : 'PDF REPORTS'
                            },
                            
                            
                        ]

                        

        });

        $("#search").on('change', function(e) {
            table.draw();
            e.preventDefault();
        });


        $(document).on('click', '.deletedata', function() {
            var id = $(this).attr('data-value');

            Swal.fire({
                title: 'Are you sure?',
                html: '<input type="text" id="deletionReason" class="swal2-input" placeholder="Enter reason for deletion...">',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.value) {
                    var deletionReason = $('#deletionReason').val();
                    $.ajax({
                        url: "{{ route('superadmin.usermanagement.deptUser.delete') }}",
                        method: "POST",
                        dataType: 'json',
                        data: {
                            'id': id,
                            'deletionReason': deletionReason,
                            '_token': '{{ csrf_token() }}',
                        },
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function(result) {
                            Swal.fire('Deleted!', 'Record Deleted Successfully..', 'success')
                                .then((result) => {
                                    window.location.href =
                                        '';
                                });
                        }

                    });
                }
            });
        });

        $(document).on('click', '.viewdata', function() {
            var id = $(this).attr('data-id');

            $.ajax({
                url: "{{ route('superadmin.usermanagement.deptUser.view') }}",
                method: "POST",
                dataType: 'json',
                data: {
                    'id': id,
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(result) {
                    if (result.status == "success") {
                        $('#viewDataModal').modal('show');
                        $('#viewDataModal #htmlData').html(result.html);
                        return true;
                    } else {
                        Swal.fire('', result.msg, 'warning');
                    }
                },
                error: function(result) {

                }
            });
        });
</script>
@endpush





@extends('admin.layouts.app')
@section('content')
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Add Lab</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item active">Add Lab</li>
                </ol>
            </div>

        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1">Add Lab Details </h4>
                <div class="flex-shrink-0">
                    @if (session('error'))
                    <div class="alert alert-danger">
                        {{ session('error') }}
                    </div>
                    @endif
                    @if (session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                    @endif
                    @if($errors)
                    @foreach ($errors->all() as $error)
                    <div class="alert alert-danger">{{ $error }}</div>
                    @endforeach
                    @endif
                </div>
            </div>

            <div class="card-body">
                <div class="live-preview">


                    <form method="post" action="{{route('superadmin.lab_save')}}" enctype="multipart/form-data" >
                        @csrf
                        <div class="row gy-4">
                            <div class="row seperatesec">
                                <div class="col-xxl-3 col-md-3">
                                </div>

                            </div>
                            <div class="row seperatesec white-inner">

                                <div class="col-xxl-6 col-md-6">
                                    <div>
                                        <label class="form-label">Name<span class="required">*</span></label>
                                        <input type="text" class="form-control" id="lab_name" name="lab_name" placeholder=" Enter Lab Name" value="{{ old('name') }}">
                                    </div>
                                </div>
                                <div class="col-xxl-6 col-md-1">
                                    <div>
                                        <label for="labelInput" class="form-label">Address</label>
                                        <textarea class="form-control " name="lab_address" required>{{ old('remark') }}</textarea>
                                    </div>
                                </div>

                                <div class="col-xxl-6 col-md-6 gy-4">

                                    <label for="labelInput" class="form-label">State<span class="required">*</span></label>
                                    <select class="form-select state" name="ref_state_id" id="ref_state_id" required>
                                        <option value="">Select State</option>
                                        @forelse(getAllState() as $state)
                                        <option value="{{ $state->id }}" @selected(old('state')==$state->id)>{{ $state->state_name }}
                                        </option>
                                        @empty
                                        @endforelse
                                    </select>

                                </div>

                                <div class="col-xxl-6 col-md-3 gy-4 name-change ">


                                    <label for="labelInput" class="form-label">District<span class="required">*</span></label>
                                    <select class="form-select district" name="district" id="district" required>
                                        @forelse(getDistrictByStateID(old('state')) as $district)
                                        <option value="{{ $district->id }}" @selected(old('district')==$district->id)>
                                            {{ $district->district_name }}
                                        </option>
                                        @empty
                                        <option value="">-Select District-</option>
                                        @endforelse


                                    </select>


                                </div>

                                <div class="col-xxl-6 col-md-3 gy-4 name-change">

                                    <label for="labelInput" class="form-label">NABL Certification No</label>
                                    <input type="text" class="form-control" name="certificate_no" required  >
                                </div>

                                <div class="col-xxl-6 col-md-6 gy-4">
                                    <div>
                                        <label for="labelInput" class="form-label">Printer Header</label>
                                        <select class="form-select" name="print_header" id="" required>
                                            <option value="">--Select--</option>
                                            <option value="yes">Yes</option>
                                            <option value="no">No</option>
                                        </select>
                                    </div>
                                </div>


                                <div class="col-xxl-6 col-md-3 gy-4 external_resourse">
                                    <label for="labelInput" class="form-label">NABL Start Date</label>
                                    <input type="date" class="form-control" name="start_date" required >
                                </div>
                                <div class="col-xxl-6 col-md-6 gy-4">
                                    <div>
                                        <label for="labelInput" class="form-label">NABL End Date<span class="required">*</span></label>
                                        <input type="date" class="form-control" name="end_date"  required>
                                    </div>
                                </div>

                                <div class="col-xxl-6 col-md-6 gy-4">
                                    <div>
                                        <label for="labelInput" class="form-label">City<span class="required">*</span></label>
                                        <input type="text" class="form-control" name="lab_city"  required>

                                    </div>
                                </div>
                                <div class="col-xxl-6 col-md-6 gy-4">
                                    <div>
                                        <label for="labelInput" class="form-label">PIN<span class="required">*</span></label>
                                        <input type="text" class="form-control numbersonly" name="lab_pin" required maxlength="6">
                                    </div>
                                </div>
                                <div class="col-xxl-6 col-md-6 gy-4">
                                    <div>
                                        <label for="labelInput" class="form-label">Mobile Number<span class="required">*</span></label>
                                        <input type="text" class="form-control numbersonly phone" id="lab_tel" required name="lab_tel" placeholder="Mobile Number" onblur="phonenumber(this)" maxlength="10" value="{{ old('mobile') }}">

                                    </div>
                                </div>
                                <div class="col-xxl-6 col-md-6 gy-4">
                                    <div>
                                        <label for="labelInput" class="form-label">Alternate Mobile Number</label>
                                        <input type="text" class="form-control numbersonly phone" id="mobile"  name="alternate_mobile" placeholder="Mobile Number" onblur="phonenumber(this)" maxlength="10" value="{{ old('mobile') }}">
                                    </div>
                                </div>
                                <div class="col-xxl-6 col-md-6 gy-4">
                                    <div>
                                        <label for="labelInput" class="form-label">Email Id<span class="required">*</span></label>
                                        <input type="text" class="form-control" name="lab_email" placeholder=""  required>

                                    </div>
                                </div>
                                <div class="col-xxl-6 col-md-6 gy-4">
                                    <div>
                                        <label for="labelInput" class="form-label">Alternate Email Id</label>
                                        <input type="text" class="form-control numbersonly" name="alternate_email">
                                    </div>
                                </div>

                                <div class="col-xxl-6 col-md-6 gy-4">
                                    <div>
                                        <label for="labelInput" class="form-label">Fax</label>
                                        <input type="text" class="form-control " name="lab_fax" placeholder=""   >
                                    </div>
                                </div>

                                <div class="col-xxl-6 col-md-6 gy-4">
                                    <div>
                                        <label for="labelInput" class="form-label">Scope for Sampling and analysis of products group<span class="required">*</span></label>
                                        {{-- <input class="form-control " name="scope_for_sampling" value="Organic" placeholder="Organic" readonly required>{{ old('remark') }}</input> --}}

                                        <select name="scope_for_sampling" id="scope_for_sampling" class="form-control ">
                                            <option value="">Select</option>
                                            <option value="General">General</option>
                                            <option value="ETO">ETO</option>
                                            <option value="GMO">GMO</option>

                                        </select>
                                    </div>
                                </div>

                                <div class="col-xxl-6 col-md-6 gy-4">
                                    <div>
                                        <label for="labelInput" class="form-label">Enter remarks<span class="required">*</span></label>
                                        <textarea class="form-control " name="remarks" required>{{ old('remark') }}</textarea>
                                    </div>
                                </div>
                                <div class="row">

                                <div class="col-xxl-6 col-md-6 gy-4">
                                    <div>
                                        <label for="labelInput" class="form-label">Upload Lab Logo<span class="required">*</span></label>
                                        <input type="file" class="form-control " name="lab_logo" placeholder="" required >
                                        <p style="color: red;">Only image file(jpeg/png) of less than 200 kb of size is allowed</p>
                                    </div>
                                </div>

                                <div class="col-xxl-6 col-md-6 gy-4">
                                    <div>
                                        <label for="labelInput" class="form-label">Upload NABL Logo<span class="required">*</span></label>
                                        <input type="file" class="form-control " name="nabl_logo" placeholder=""  required >
                                        <p style="color: red;">Only image file(jpeg/png) of less then 200 kb of size is allowed</p>
                                    </div>
                                </div>
</div>
                                <div class="col-xxl-6 col-md-6 gy-4">
                                    <div>
                                        <label for="labelInput" class="form-label">Upload NABL Certificate<span class="required">*</span></label>
                                        <input type="file" class="form-control " name="nabl_certificate" placeholder="" required maxlength="">
                                        <p style="color: red;">Only PDF file(jpeg/png) of less then 1 MB of size is allowed</p>
                                    </div>
                                </div>

                                <div class="form-check gy-4">
                                    <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" >
                                    <label class="form-check-label" for="flexCheckChecked">
                                        I have checked all the entered details the same will be published on the APEDA website.
                                    </label>
                                </div>

                                <div class="row">
                                    <div class="col-lg-12 gy-4">
                                        <div class="hstack gap-2">
                                            <button type="submit" class="btn btn-primary">Add Lab</button>

                                        </div>
                                    </div>
                                </div>

                            </div>
                                <div class="form-check gy-4">

                                    <label class="form-check-label" for="flexCheckChecked">
                                    <p style="color: red;">Note:- The lab details will be published only after the product(s) will be Added.</p>
                                    </label>
                                </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@extends('admin.layouts.app')
@section('content')
<!-- start page title -->
<style>
    /* Custom CSS */

/* Page Title */
.page-title-box {
    padding: 10px;
    background-color: #f8f9fa;
    border-bottom: 1px solid #dee2e6;
    margin-bottom: 20px;
}

.page-title-box h4 {
    margin-bottom: 0;
}

/* Breadcrumbs */
.breadcrumb {
    background-color: transparent;
    margin-bottom: 0;
}

/* Cards */
.card {
    margin-bottom: 20px;
    border: none;
    border-radius: 8px;
    box-shadow: 0 0 20px 0 rgba(69, 90, 100, 0.08);
}

.card-header {
    background-color: #f8f9fa;
    border-bottom: 1px solid #dee2e6;
}

.card-title {
    color: #343a40;
}

.card-body {
    padding: 20px;
}

/* Tables */
.table_pdf {
    width: 100%;
    margin-bottom: 1rem;
    color: #212529;
    border-collapse: collapse;
}

.pdf_txt1 {
    font-weight: bold;
}

.pdf_box {
    padding: 8px;
    border-bottom: 1px solid #dee2e6;
}

.pdf_heading {
    font-size: 20px;
    margin-top: 30px;
    margin-bottom: 10px;
}

.pdf_maindiv {
    border: 1px solid #dee2e6;
    padding: 15px;
    border-radius: 8px;
    background-color: #f8f9fa;
    margin-bottom: 20px;
}

.pdf-img-icon {
    width: 20px;
    margin-right: 5px;
}

/* Media Queries */
@media (max-width: 768px) {
    .col-6 {
        flex: 0 0 100%;
        max-width: 100%;
    }
}

</style>
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">View Lab</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">View Lab</li>
                </ol>
            </div>

        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">

        <div class="tab-content py-4 custom-tab-content">
            <div class="tab-pane fade show active" id="step1">
                <div class="card">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1">
                           Lab Details
                        </h4>

                        <div class="flex-shrink-0  ">
                            <label for="basiInput" class="form-label"></label>
                        </div>


                    </div>

                    <!-- end card header -->
                    <div class="card-body">

                        <div class="pdf_heading">Personal Details:</div>
                        <div class="pdf_maindiv">
                            <!--form1 section starts here-->
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                            <tr>
                                                <td class="pdf_txt1">Name :</td>
                                                <td class="pdf_box">{{$data->lab_name ?? '--'}}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Mobile Number:</td>
                                                <td class="pdf_box">{{$data->lab_tel ?? '--'}}</td>
                                            </tr>



                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">




                                            <tr>
                                                <td class="pdf_txt1">Email Id:</td>
                                                <td class="pdf_box">{{$data->lab_email ?? '--'}}</td>
                                            </tr>


                                            <tr>
                                                <td class="pdf_txt1">Fax:</td>
                                                <td class="pdf_box">{{$data->lab_fax ?? '--'}}</td>
                                            </tr>


                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="pdf_heading">Address:</div>
                        <div class="pdf_maindiv">
                            <!--form1 section starts here-->
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                            <tr>
                                                <td class="pdf_txt1">State:</td>
                                                <td class="pdf_box">{{get_state_name($data->ref_state_id ?? '--' )}}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">District:</td>
                                                <td class="pdf_box">{{get_district_name_by_id($data->ref_district_id ?? '--' )}}</td>
                                            </tr>

                                        </table>
                                        <!--form1 tab end here-->
                                    </div>

                                    <div class="col-6">

                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">

                                            <tr>
                                                <td class="pdf_txt1">Pin Code:</td>
                                                <td class="pdf_box">{{$data->lab_pin ?? '--'}}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Address:</td>
                                                <td class="pdf_box">{{$data->lab_address ?? '--'}}</td>
                                            </tr>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>


                                </div>
                            </div>
                        </div>




                        <div class="pdf_heading">Uploaded Document:</div>
                        <div class="pdf_maindiv">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf table_contact_person">
                                            <tbody>


                                                <tr>
                                                    <td class="pdf_txt1">Lab Logo:</td>
                                                    <td class="pdf_box">

                                                      <img src="{{asset($data->lab_logo) }}"  style="width: 80px;height: 80px;border-radius: 100%;">

                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">NABL Logo:</td>
                                                    <td class="pdf_box">

                                                    <img src="{{asset($data->nabl_logo)}}"  style="width: 80px;height: 80px;border-radius: 100%;">

                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf table_contact_person">
                                            <tbody>



                                                <tr>
                                                    <td class="pdf_txt1">NABL Certificate:</td>
                                                    <td class="pdf_box">

                                                    <img src="{{asset($data->nabl_certificate) }}" style="width: 80px;height: 80px;border-radius: 100%;">

                                                    </td>

                                                </tr>


                                            </tbody>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="pdf_heading">NABL Details:</div>
                        <div class="pdf_maindiv">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf table_contact_person">
                                            <tr>
                                                <td class="pdf_txt1">NABL Start Date:</td>
                                                <td class="pdf_box">{{$data->start_date ?? '--'}}</td>
                                            </tr>

                                            <tr>
                                                <td class="pdf_txt1">Remarks</td>
                                                <td class="pdf_box">
                                                    <p>
                                                    {{$data->remarks ?? '--'}}
                                                    </p>
                                                </td>
                                            </tr>


                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf table_contact_person">
                                            <tr>
                                                <td class="pdf_txt1">NABL End Date:</td>
                                                <td class="pdf_box"> {{$data->end_date ?? '--'}}</td>
                                            </tr>

                                            <tr>
                                                <td class="pdf_txt1">Scope for Sampling and analysis of products group:</td>
                                                <td class="pdf_box">
                                                    <p>
                                                    {{$data->scope_for_sampling ?? '--'}}
                                                    </p>
                                                </td>
                                            </tr>

                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

@extends('admin.layouts.app')

@section('content')

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Test Rest Entry</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">

                    <li class="breadcrumb-item active">Test Rest Entry</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">

    <div class="tab-content py-4 custom-tab-content">
        <div class="tab-pane fade show active" id="step1">
            <div class="card">
                <div class="card-header align-items-center d-flex">
                    <h4 class="card-title mb-0 flex-grow-1">
                    Test Rest Entry
                    </h4>
                  </div>
                <!-- end card header -->
                <div class="card-body">


                    <table id="farmerTable" class="table table-bordered dt-responsive nowrap table-striped align-middle" style="width:100%">
                        <thead>
                            <tr>
                            <th>Sample Code No.</th>
                                <th>Tc Application No.</th>
                                <th>Lab Code No.</th>
                                <th>Sampler Name</th>
                                <th>Sample Date</th>
                                <th>Action</th>


                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div>
</div>



@endsection
@push('script')
<script>

$.ajaxSetup({
      headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      }
});

var table =$('#farmerTable').DataTable({
        //dom: 'l<"clear">Bfrtip',
        //dom:'Bfrtip',
       //dom:'Blfrtip',
        lengthMenu : [[10, 25, 50, -1], [10, 25, 50, "All"]],
        processing: true,
        serverSide: true,
        ajax: {
            url: '{{ route("superadmin.lab.test_rest_entry") }}',
            type: 'GET',
            data: function (d) {
                d.operator = $('#operator').val();
            }
          },
        columns: [
            { data: 'sample_code',sample_code:'name',orderable: true },
            { data: 'tc_no', name: 'tc_no',orderable: true  },
            { data: 'lab_code',name:'lab_code',orderable: true },
            { data: 'person_name',name:'person_name',orderable: true },
            { data: 'drawn_sample_date',name:'drawn_sample_date',orderable: true },
            { data: 'action', name: 'name',orderable: false },
        ],

    });

    $("#filterButton").click(function(){
            table.draw();
    });

</script>
@endpush

@extends('admin.layouts.app')
@section('content')
    <style>
        body {
            margin: 0px;
            padding: 0px;
            font-family: "Segoe UI";
        }

        .maindiv {
            width: 80%;
            margin: 0 auto;
        }

        .pdf_maindiv {
            border: 1px solid #cccccc;
            width: 100%;
            float: left;
            padding: 2% 1%;
        }

        .pdf_heading {
            font-size: 20px;
            color: #000;
            padding: 26px 0 20px 0px;
            position: relative;
            width: 100%;
            float: left;
        }

        .brd_heading {
            border-bottom: 2px solid #ee5e24;
            padding-bottom: 8px;
            padding-right: 8px;
            width: 60px;
        }

        .pdf_input1 {
            background: #eeeeee;
        }

        .pdf_txt1 {
            color: #000;
            font-size: 14px;
            width: 45%;
            float: left;
            padding-bottom: 10px;
            font-weight: bold;
        }

        .pdf_box {
            color: #000;
            font-size: 14px;
            width: 55%;
            float: left;
            padding-bottom: 10px;
        }

        .table_pdf {
            width: 100%;
        }

        .pdf_heading:after {
            content: "";
            position: absolute;
            width: 70px;
            height: 2px;
            background-color: #ee5e24;
            bottom: 10px;
            display: block;
        }

        .pdf_heading:before {
            content: "";
            position: absolute;
            width: 22px;
            height: 6px;
            background-color: #ee5e24;
            bottom: 8px;
            display: block;
        }

        #step1 .card-body {
            background: #fff
        }

        .pdf_inner_heading:after {
            display: none;
        }

        .pdf_inner_heading:before {
            display: none;
        }

        .pdf_inner_heading {
            padding: 20px 0 12px;
            text-decoration: underline;
            font-size: 16px;
        }

        .pdf_maindiv hr:last-child {
            display: none;
        }

        .pdf-img-icon {
            height: 17px;
            width: 15px;
            margin-right: 5px;
        }

        @media print {

            .pdf_heading {
                font-size: 20px;
                color: #000;
                padding: 26px 0 20px 0px;
                position: relative;
                width: 100%;
                float: left;
                -webkit-print-color-adjust: exact !important;
                Chrome,
                Safari color-adjust: exact !important;
            }

            .pdf_heading:before {
                content: "";
                position: absolute;
                width: 20px;
                height: 4px;
                background-color: #ee5e24;
                bottom: 10px;
                display: block;
                -webkit-print-color-adjust: exact !important;
                Chrome,
                Safari color-adjust: exact !important;
            }


        }
    </style>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Test Report Details</h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Test Report Details</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">

            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">
                        <div class="card-body">

                            <div class="pdf_heading">Enter Test Report Details</div>
                            <div style="display: flex; justify-content: flex-end;">


                                <a href="{{ route('superadmin.lab.test_rest_entry_genrate', ['id' => $inspIds->id]) }}"
                                    class="btn btn-primary">View Application</a>

                            </div>
                            <div class="pdf_maindiv">
                                <!--form1 section starts here-->
                                <div class="container-fluid">
                                    <form method="post" action="{{ route('superadmin.lab.lab_test_save') }}">
                                        @csrf
                                        <div class="row">
                                            <div class="col-6">
                                                <!--form1 tab starts here-->
                                                <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                    <tr>
                                                        <td class="pdf_txt1">Test Start Date :</td>
                                                        <td class="pdf_box"><input type="date" name="test_start_date"
                                                                class="form-control" required /></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="pdf_txt1">Test Report No. :</td>
                                                        <td class="pdf_box">{{ $sample_data->lab_code ?? '0' }}</td>
                                                    </tr>


                                                </table>
                                                <!--form1 tab end here-->
                                            </div>
                                            <div class="col-6">

                                                <table style="padding: 10px; border: 0px;" class="table_pdf">

                                                    <tr>
                                                        <td class="pdf_txt1">Test Ending Date :</td>
                                                        <td class="pdf_box"><input type="date" name="test_end_date"
                                                                class="form-control" required />
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td class="pdf_txt1">Product Name :</td>
                                                        <td class="pdf_box">
                                                            @if ($inspIds->ref_product_id === null)
                                                                --
                                                            @else
                                                                {{ getProductNameById1($inspIds->ref_product_id) ?? '' }}
                                                            @endif
                                                        </td>


                                                    </tr>

                                                </table>

                                            </div>
                                        </div>
                                </div>
                            </div>

                            <div class="pdf_maindiv">
                                <!--form1 section starts here-->
                                <div class="container-fluid">




                                    <table class="table table-striped">
                                        <thead>
                                            <tr>

                                                <th>Test Parameter</th>
                                                <th>BLQ</th>
                                                <th>Equipment/Method of Analysis</th>
                                                <th>Result</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($samples as $index => $sample)
                                                <!-- Loop through samples -->
                                                <tr>
                                                    
                                                    <input type="hidden" name="id[]" value="{{ $id }}"
                                                        class="form-control" readonly />
                                                    <td><input type="text" name="test_parameter_name[]"
                                                            value="{{ getParameterNameById($sample->ref_cb_test_parameter_master_id) }}"
                                                            class="form-control" readonly /></td>
                                                    <td><input type="text" name="mrl_value[]"
                                                            value="{{ getParameterMtrById($sample->ref_cb_test_parameter_master_id) }}"
                                                            class="form-control" readonly /></td>
                                                    <td><input type="text" name="equipment[]" class="form-control" />
                                                    </td>
                                                    <td><input type="text" name="result[]" class="form-control" /></td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>

                                    <div style="margin-top: 10px; text-align: center;">
                                        <button type="submit" class="btn btn-primary submit-button">Save Test
                                            Report</button>
                                    </div>
                                    </form>
                                </div>



                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    </div>
    </div>
@endsection

@push('script')
    <script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
    <script>
        $(document).on('click', '#submitbtn', function() {

            if (checkValidation("registration")) {
                $('#registration').submit();
                return true;
            } else {
                return false;
            }
        });
    </script>
@endpush

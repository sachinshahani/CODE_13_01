@extends('admin.layouts.app')
@section('content')
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            border: 1px solid black;
            padding: 8px;
            text-align: center;
        }

        .file-upload {
            margin-top: 10px;
        }
    </style>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Assign Product</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item active">Assign Product</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>

    <div class="row white-inner">
        <div class="col-lg-12">
            <div class="card">
                {{-- <div class="card-header align-items-center d-flex">
                    <h4 class="card-title mb-0 flex-grow-1">Add Lab Details </h4>

                </div> --}}

                <div class="card-body  white-inner">
                    <div class="live-preview">


                        <form method="post" action="{{ route('superadmin.submitForm') }}" enctype="multipart/form-data">
                            @csrf
                            <input type="hidden" name="lab_id" id="" value="{{ $data->id }}">
                            <div class="row gy-4">
                                <div class="row seperatesec">
                                    <div class="col-xxl-3 col-md-3">
                                    </div>

                                </div>
                                <div class="row seperatesec white-inner">

                                    <div class="col-xxl-6 col-md-4 gy-4">
                                        <div>
                                            <label for="labelInput" class="form-label">Module</label>
                                            <select class="form-select" name="module" id="" >
                                                <option value="">--Select--</option>
                                                <option value="TRACENET">TRACENET</option>

                                            </select>
                                        </div>
                                    </div>


                                    <div class="col-xxl-6 col-md-4 gy-4">
                                        <div>
                                            <label for="labelInput" class="form-label">Product</label>
                                            <select class="form-select" name="product_name" id="" >
                                                <option value="">--Select--</option>
                                                <option value="Organic">Organic</option>

                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-xxl-6 col-md-4 gy-4">
                                        <div>
                                            <label for="labelInput" class="form-label">ETO</label>
                                            <select class="form-select" name="eto_status" id="" >
                                                <option value="">--Select--</option>
                                                <option value="Yes">Yes</option>
                                                <option value="No">No</option>

                                            </select>
                                        </div>
                                    </div>


                                    <div class="col-xxl-6 col-md-4 gy-4">
                                        <div>
                                            <label for="labelInput" class="form-label">GMO</label>
                                            <select class="form-select" name="gmo_status" id="" >
                                                <option value="">--Select--</option>
                                                <option value="Yes">Yes</option>
                                                <option value="No">No</option>

                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-xxl-6 col-md-6 gy-4">
                                        <div>
                                            <label for="blocked_by" class="form-label">Blocked By<span
                                                    class="required">*</span></label>
                                            <input class="form-check-input" type="checkbox" name="blocked_by[]"
                                                value="APEDA" id="blockedByApeda">
                                            <label for="blockedByApeda" class="form-label">APEDA</label>
                                            <input class="form-check-input" type="checkbox" name="blocked_by[]"
                                                value="Agmark" id="blockedByAgmark">
                                            <label for="blockedByAgmark" class="form-label">Agmark</label>
                                            <input class="form-check-input" type="checkbox" name="blocked_by[]"
                                                value="NRL" id="blockedByNrl">
                                            <label for="blockedByNrl" class="form-label">NRL</label>
                                            <input class="form-check-input" type="checkbox" name="blocked_by[]"
                                                value="NABL" id="blockedByNabl">
                                            <label for="blockedByNabl" class="form-label">NABL</label>
                                            @if (session('error'))
                                                <div class="alert alert-danger">
                                                    {{ session('error') }}
                                                </div>
                                            @endif
                                        </div>
                                    </div>

                                    <div class="md-6 gy-4">
                                        <table>
                                            <thead>
                                                <tr>
                                                    <th>Row Number</th>
                                                    <th>Session of PT Month</th>
                                                    <th>Session of PT Year</th>
                                                    <th>Recommendation of NRL</th>
                                                    <th>File</th>

                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>1</td>
                                                    <td>
                                                        <select name="ptmonth" id="">
                                                            <option>January</option>
                                                            <option>February</option>
                                                            <option>March</option>
                                                            <option>April</option>
                                                            <option>May</option>
                                                            <option>June</option>
                                                            <option>July</option>
                                                            <option>August</option>
                                                            <option>September</option>
                                                            <option>October</option>
                                                            <option>November</option>
                                                            <option>December</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <select name="ptyear">
                                                            <option>2024</option>
                                                            <option>2025</option>
                                                            <option>2026</option>
                                                            <option>2027</option>
                                                            <option>2028</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <input type="date" name="nrldate" placeholder="mm/dd/yyyy">
                                                    </td>
                                                    <td>
                                                        <input type="file" name="file" accept=".pdf"
                                                            id="fileInput">
                                                        <div class="file-upload">
                                                            <span style="color: red;">[Only PDF file of less than 1MB of
                                                                size is allowed]</span>
                                                        </div>
                                                        @if (session('error'))
                                                            <div class="alert alert-danger">
                                                                {{ session('error') }}
                                                            </div>
                                                        @endif
                                                    </td>

                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="md-6 gy-5">
                                        <div>
                                            <label for="recommended_by" class="form-label">Recommended By<span
                                                    class="required">*</span></label>
                                            <input class="form-check-input" type="checkbox" name="recommended_by[]"
                                                value="Agmark" id="recommendedByAgmark">
                                            <label for="recommendedByAgmark" class="form-label">Agmark</label>
                                            <input class="form-check-input" type="checkbox" name="recommended_by[]"
                                                value="NRL" id="recommendedByNrl">
                                            <label for="recommendedByNrl" class="form-label">NRL</label>
                                            <input class="form-check-input" type="checkbox" name="recommended_by[]"
                                                value="NABL" id="recommendedByNabl">
                                            <label for="recommendedByNabl" class="form-label">NABL</label>
                                            @if (session('error'))
                                                <div class="alert alert-danger">
                                                    {{ session('error') }}
                                                </div>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="row ">
                                        <div class="col-lg-12 gy-4">
                                            <div class="hstack gap-2 ">
                                                <button type="submit" class="btn btn-primary"
                                                    style="margin: auto;">Submit</button>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
{{-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    $(document).ready(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $('#uploadButton').click(function() {
            var formData = new FormData($('#uploadForm')[0]);

            $.ajax({
                url: "{{ route('superadmin.upload') }}",
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                success: function(response) {
                    if (response.success) {
                        alert(response.success);
                    } else {
                        alert(response.error);
                    }
                },
                error: function(response) {
                    alert('File upload failed.');
                }
            });
        });
    });
</script> --}}

@extends('admin.layouts.app')
@section('content')
<style>
    body {
        margin: 0px;
        padding: 0px;
        font-family: "Segoe UI";
    }

    .maindiv {
        width: 80%;
        margin: 0 auto;
    }

    .pdf_maindiv {
        border: 1px solid #cccccc;
        width: 100%;
        float: left;
        padding: 2% 1%;
    }

    .pdf_heading {
        font-size: 20px;
        color: #000;
        padding: 26px 0 20px 0px;
        position: relative;
        width: 100%;
        float: left;
    }

    .brd_heading {
        border-bottom: 2px solid #ee5e24;
        padding-bottom: 8px;
        padding-right: 8px;
        width: 60px;
    }

    .pdf_input1 {
        background: #eeeeee;
    }

    .pdf_txt1 {
        color: #000;
        font-size: 14px;
        width: 45%;
        float: left;
        padding-bottom: 10px;
        font-weight: bold;
    }

    .pdf_box {
        color: #000;
        font-size: 14px;
        width: 55%;
        float: left;
        padding-bottom: 10px;
    }

    .table_pdf {
        width: 100%;
    }

    .pdf_heading:after {
        content: "";
        position: absolute;
        width: 70px;
        height: 2px;
        background-color: #ee5e24;
        bottom: 10px;
        display: block;
    }

    .pdf_heading:before {
        content: "";
        position: absolute;
        width: 22px;
        height: 6px;
        background-color: #ee5e24;
        bottom: 8px;
        display: block;
    }

    #step1 .card-body {
        background: #fff
    }

    .pdf_inner_heading:after {
        display: none;
    }

    .pdf_inner_heading:before {
        display: none;
    }

    .pdf_inner_heading {
        padding: 20px 0 12px;
        text-decoration: underline;
        font-size: 16px;
    }

    .pdf_maindiv hr:last-child {
        display: none;
    }

    .pdf-img-icon {
        height: 17px;
        width: 15px;
        margin-right: 5px;
    }

    @media print {

        .pdf_heading {
            font-size: 20px;
            color: #000;
            padding: 26px 0 20px 0px;
            position: relative;
            width: 100%;
            float: left;
            -webkit-print-color-adjust: exact !important;
            Chrome,
            Safari color-adjust: exact !important;
        }

        .pdf_heading:before {
            content: "";
            position: absolute;
            width: 20px;
            height: 4px;
            background-color: #ee5e24;
            bottom: 10px;
            display: block;
            -webkit-print-color-adjust: exact !important;
            Chrome,
            Safari color-adjust: exact !important;
        }


    }
</style>
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Search MIS Report</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Search MIS Report</li>
                </ol>
            </div>

        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">

        <div class="tab-content py-4 custom-tab-content">
            <div class="tab-pane fade show active" id="step1">
                <div class="card">
                    <div class="card-body">

                
                     
                        <div class="pdf_heading">Search MIS Report</div>
                        <div class="pdf_maindiv">
                            <!--form1 section starts here-->
                            <div class="container-fluid">
                                <div class="row">
                                   
                                        <form method="post" action="{{route('superadmin.lab.forward_sample_details')}}">
                                            @csrf

                                            
                                            
                                            <div class="row">
                                                <div class="col-lg-6">

                                               
                                                    <label>Period From :</label>
                                                   
                                                        <input type="date" name="drawn_sample_date" class="form-control" />
                                                </div>
                                                <div class="col-lg-6">
                                                    
                                                    <label>Period To:</label>
                                                    
                                                        <input type="date" name="drawn_sample_date" class="form-control" />
                                                        </div>
                                                
                                            </div>

                                            <div class="row">
                                            <div class="col-lg-6">
                                                    <label>Operator Name :</label>
                                                   
                                                        <input type="text" name="company_name" class="form-control" />
                                                    
                                            </div>
                                            <div class="col-lg-6">
                                                    <label>Lot/TC No. :</label>
                                                   
                                                        <input type="text" name="lot_tc_no" class="form-control" />
                                                  
                                            </div>


                                            </div>
                                           

                                       
                                    </div>
                                    <br>
                                    <div style="text-align: center;">
                                    <button type="submit" id="submitbtn" class="btn btn-primary submit-button">Submit</button>
                                            <button type="button" id="submitbtn" class="btn btn-primary submit-button">View All</button>
                                            
                                        </div>
                                    
                                    <form>

                                </div>
                            </div>
                        </div>
               
                       

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

</div>
</div>
@endsection

@push('script')
<script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>

@endpush
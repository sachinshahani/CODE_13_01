@extends('admin.layouts.app')

@section('content')
    <div class="clearfix"></div>

    <div class="col-md-12 mt-2">
        @if (session('success'))
            <div class="alert alert-success" id="validate">
                {{ session('success') }}
            </div>
        @endif

        @if (session('importErrors'))
            <div class="alert alert-danger">
                <p>Following Errors Occured While Uploading the list, Please fix and upload again</p>
                <ul>
                    @foreach (session('importErrors') as $failure)
                        @foreach ($failure->errors() as $f)
                            <li>{{ $f . ' at row ' . $failure->row() }}</li>
                        @endforeach
                    @endforeach
                </ul>
            </div>
        @endif
    </div>

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0" style="float: left">
                        List of Internal Stock Transfer Certificate issued
                    </h5>

                </div>
                <div class="card-body table-responsive">
                    <table id="tcIssueList" class="table datatable table-bordered table-striped align-middle" style="width:100%">
                        <thead>
                            <tr>
                                <th>S.No.</th>
                                <th>ST Certificate Number</th>
                                <th>ST Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($tcIssueList as $tcIssueListData)
                            <tr>
                                <td>{{$loop->iteration}}</td>
                                <td>{{$tcIssueListData->transferee_scope_certification_no}}</td>
                                <td>{{date('Y-m-d', strtotime($tcIssueListData->date_of_internal_transfer))}}</td>
                                <td><a href="{{ route('superadmin.StViewApplication', ['id' => $tcIssueListData->id]) }}" target="_blank">View Certificate</a></td>

                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!--end col-->
    </div>
    <!--end row-->

@endsection
@push('script')
    <script>
        // Initialize DataTables on the table with the 'datatable' class
        $(document).ready(function () {
            $('.datatable').DataTable();
        });
    </script>
@endpush

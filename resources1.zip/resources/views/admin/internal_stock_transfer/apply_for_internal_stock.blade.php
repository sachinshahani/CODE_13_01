@extends('admin.layouts.app')

@section('content')
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Apply for internal stock transfer</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Apply for internal stock transfer</li>
                </ol>
            </div>

        </div>
    </div>
</div>


<div class="row">
    <div class="col-lg-12">

        <div class="tab-content py-4 custom-tab-content">

            <div class="tab-pane fade show active" id="step1">
                <div class="card">
                    <h5 class="mb-sm-1">Scope Certificate</h5>
                    <div class="row seperatesec  white-inner">

                        <!-- end card header -->
                        <div class="table-responsive">
                            <table id="inspSchedule" class="table table-bordered nowrap table-striped align-middle" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>S.No.</th>
                                        <th>Scope Certificate No</th>
                                        <th>Date of Registration</th>
                                        <th>Operator Name</th>
                                        <th>Operator Address</th>
                                        <th>Validity Start Date</th>
                                        <th>Validity End Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($list as $listData)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $listData->scope_certificate_no ?? '' }}</td>
                                        @if( $listData->at_user_id == $user[0]->id)
                                        <td>{{dateformat( $user[0]->date_of_registration ?? '')  }}</td>
                                        <td>{{ $user[0]->first_name ?? ''  }}</td>
                                        <td>{{ $user[0]->address ?? ''  }}</td>
                                        @endif
                                        <td>{{ dateformat($listData->validity_start_date ?? '')  }}</td>
                                        <td>{{ dateformat($listData->validity_end_date ?? '')  }}</td>
                                        <td>
                                            <a href="{{route('superadmin.InternalStockAddProduct', $listData->at_user_id)}}" class="btn btn-soft-primary">Proceed</a>
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
@endsection
@push('script')
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        // var table = $('#inspSchedule').DataTable({
        //     lengthMenu: [
        //         [10, 25, 50, -1],
        //         [10, 25, 50, "All"]
        //     ],
        //     processing: true,
        //     serverSide: true,
        //     ajax: {
        //         url: '{{ route('superadmin.purchaseRequestList') }}',
        //         type: 'GET',
        //         data: function(d) {
        //         }
        //     },
        //     columns: [{
        //             data: 'DT_RowIndex',
        //             name: 'DT_RowIndex',
        //             orderable: true
        //         },
        //         {
        //             data: 'user_name',
        //             name: 'user_name',
        //             orderable: true
        //         },
        //         {
        //             data: 'Commodity',
        //             name: 'Commodity',
        //             orderable: true
        //         },
        //         {
        //             data: 'no_of_packages',
        //             name: 'no_of_packages',
        //             orderable: true
        //         },
        //         {
        //             data: 'created_at',
        //             name: 'created_at',
        //             orderable: true
        //         },
        //         {
        //             data: 'created_at',
        //             name: 'created_at',
        //             orderable: true
        //         },
        //         {
        //             data: 'created_at',
        //             name: 'created_at',
        //             orderable: true
        //         },
        //         {
        //             data: 'action',
        //             name: 'action',
        //             orderable: false
        //         },
        //     ],
        // });


    </script>
@endpush

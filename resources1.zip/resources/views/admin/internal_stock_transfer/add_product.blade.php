@extends('admin.layouts.app')
@section('content')
    <!-- start page title -->
    <style>
        /* Add your styling here */
        .inner-table {
            display: none;
            margin-top: -5px;
            margin-left: 40px;

        }

        .inner-table th,
        .inner-table td {
            padding: 10px;
            text-align: center;
            border: 1px solid #ddd;
        }

        .inner-table th {
            background-color: #7fa9f5;
            color: black;
        }

        .right-align {
        text-align: right;
    }
    </style>

    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Apply for internal stock transfer</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Apply for internal stock transfer</li>

                    </ol>
                </div>

            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">
                    <a class="nav-link active" id="step0-tab"
                        href="{{ route('superadmin.InternalStockAddProduct', $id) }}">Add Product</a>
                    <a class="nav-link" id="step2-tab"
                        href="{{ route('superadmin.InternalStockPackingDetail', $id) }}">Packing Details</a>
                    <a class="nav-link " id="step3-tab" href="javascript:void(0);">Internal stock Details</a>
                </div>
            </nav>

            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step0">
                    <div class="card">
                        <div class="card-body">
                            <div class="live-preview">
                                <div class="row white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label blue-ht">Batch Details</label>
                                    </div>
                                    <form method="post" action="{{ route('superadmin.InternalStockPackingDetail', $id) }}">
                                        @csrf
                                        <div class="card-body" id="inetStockProductForm">
                                            <div class="table-responsive">
                                                <table
                                                    class="table table-bordered table-striped align-middle dataTable no-footer"
                                                    width="100%" id="datatable_  ">
                                                    <thead>
                                                        <tr>
                                                            <th>Select</th>
                                                            <th>Product(s)</th>
                                                            <th>Status(s)</th>
                                                            <th>Total Quantity (In MT)</th>
                                                            <th>Quantity Sourced (In MT)</th>
                                                            <th>Available Quantity (In MT)</th>
                                                        </tr>
                                                    </thead>
                                                    {{-- <tbody>
                                                        @foreach ($batch_details as $key => $productData)
                                                            <input type="hidden" name="at_user_id"
                                                                id="{{ $productData->at_user_id }}"
                                                                value="{{ $productData->at_user_id }}">
                                                            <input type="hidden" name="batch_id"
                                                                id="{{ $productData->batch_id }}"
                                                                value="{{ $productData->batch_id }}">
                                                            <input type="hidden" name="product_code"
                                                                id="{{ $batch_details[0]->product_code ?? '' }}"
                                                                value="{{ $batch_details[0]->product_code ?? '' }}">
                                                            <input type="hidden" name="organic_status"
                                                                id="{{ $productData->organic_status }}"
                                                                value="{{ $productData->organic_status }}">

                                                            <tr class="pro-tr">
                                                                <td><input name="lots[{{ $key }}]" type="checkbox"
                                                                        onclick="getLots('{{ $productData->id }}','{{ $productData->id }}',{{ $key }});"
                                                                        required>

                                                                </td>
                                                                <td>{{ $productData->product_code ?? '' }}</td>
                                                                <td>{{ $productData->organic_status ?? '' }}</td>
                                                                <td>{{ $productData->total_quantity ?? '' }}</td>
                                                                <td>{{ $productData->quantity_source ?? '' }}</td>
                                                                <td>{{ $productData->available_quantity ?? '' }}</td>
                                                            </tr>

                                                            <tr id="tbl{{ $productData->id }}" class="d-none">
                                                                <td></td>
                                                                <td colspan="5">


                                                                    <table
                                                                        class="table table-bordered table-striped align-middle dataTable"
                                                                        width="100%" id="datatable2 ">
                                                                        <thead class="table-success">
                                                                            <tr>
                                                                                <th>Select Batch ID</th>
                                                                                <th>Product</th>
                                                                                <th>Organic Status</th>
                                                                                <th>Total Quantity (In MT)</th>
                                                                                <th>Used Quantity (Including this
                                                                                    application in MT)</th>
                                                                                <th>Available Quantity (In MT)</th>
                                                                                <th>Quantity (in MT)</th>
                                                                                <th>Add</th>
                                                                            </tr>
                                                                        </thead>
                                                                        <tbody>
                                                                            @forelse($batch_details as $productData)
                                                                                <tr>
                                                                                    <td>
                                                                                        <input type="checkbox"
                                                                                            name="selectBatchID">
                                                                                        <span>&nbsp;&nbsp;&nbsp;&nbsp;{{ $productData->batch_id ?? '' }}</span>
                                                                                    </td>
                                                                                    <td>{{ $productData->product_code ?? '' }}
                                                                                    </td>
                                                                                    <td>{{ $productData->organic_status ?? '' }}
                                                                                    </td>
                                                                                    <td>{{ $productData->total_quantity ?? '' }}
                                                                                    </td>
                                                                                    <td>{{ $productData->used_quantity ?? '' }}
                                                                                    </td>
                                                                                    <td>{{ $productData->available_quantity ?? '' }}
                                                                                    </td>
                                                                                    <td><input type="text"
                                                                                            name="quantity"
                                                                                            id="tcqty{{ $productData->id }}"
                                                                                            class="tc_qty"
                                                                                            data-id="{{ $productData->id ?? '' }}"
                                                                                            data-avail="{{ $productData->available_quantity ?? '' }}"
                                                                                            value="{{ $productData->used_quantity ?? '' }}"
                                                                                            required></td>
                                                                                    <td>
                                                                                        <a href="javascript:void(0);"
                                                                                            class="btn btn-soft-primary "
                                                                                            onclick="saveProduct()">
                                                                                            <b>Add</b>
                                                                                        </a>
                                                                                    </td>
                                                                                </tr>
                                                                            @empty
                                                                            @endforelse
                                                                        </tbody>

                                                                    </table>

                                                                </td>
                                                            </tr>
                                                        @endforeach
                                                    </tbody> --}}

                                                    @forelse($data  as $key => $vals)
                                                    {{-- @dd($vals) --}}
                                                         <tr>
                                                             <input type="hidden" name="row_id[{{ $key }}]"
                                                                 value="{{ $vals->id ?? '' }}">
                                                             <input type="hidden" name="farm_no[{{ $key }}]"
                                                                 value="{{ $vals->farm_no ?? '' }}">
                                                             <td><input name="lots[{{ $key }}]" type="checkbox"
                                                                     onclick="getLots('{{ $vals->id }}','{{ $vals->id }}',{{ $key }});"
                                                                     required>
                                                             </td>
                                                             <td>{{ $vals->product }}</td>
                                                             <td>
                                                                 <input type="hidden" name="product_code[{{ $key }}]"
                                                                     value="{{ $vals->product_code }}">
                                                                 <input type="hidden"
                                                                     name="organic_status[{{ $key }}]"
                                                                     value="{{ $vals->organic_status }}">
                                                                 {{ getSingleTableRecordById('ref_organic_status_master', 'id', $vals->organic_status )->organic_status ?? '' }}
                                                             </td>
                                                             <td class="right-align"> <input type="hidden" name="total_qty[{{ $key }}]"
                                                                     value="{{ $vals->batch_details_sum_total_quantity ?? '' }}">
                                                                 {{ $vals->batch_details_sum_total_quantity }}</td>
                                                             <td class="right-align">{{ $vals->batch_details_sum_quantity_source }}
                                                                 <input type="hidden" name="req_qty[{{ $key }}]"
                                                                     value="{{ $vals->batch_details_sum_quantity_source ?? '' }}">
                                                             </td>

                                                             <td class="right-align"> <input type="hidden" name="rem_qty[{{ $key }}]"
                                                                     value="{{ $vals->batch_details_sum_available_quantity ?? '0' }}">
                                                                 {{ $vals->batch_details_sum_available_quantity }}
                                                             </td>

                                                         </tr>

                                                         <tr id="tbl{{ $vals->id }}" class="d-none">
                                                             <td></td>
                                                             <td colspan="5">
                                                                 {{-- ******************* --}}
                                                                 <table
                                                                     class="table table-bordered table-striped align-middle dataTable"
                                                                     width="100%" id="datatable2">
                                                                     <thead class="table-success">
                                                                         <tr>
                                                                             <th>Select</th>
                                                                             <th>Products</th>
                                                                             <th>Organic Status</th>
                                                                             <th>Total Quantity (in MT)</th>
                                                                             <th>Quantity Sourced (in MT)</th>
                                                                             <th>Available Quantity (in MT)</th>
                                                                             <th>Quantity for this TC (in MT)</th>
                                                                             <th>Action</th>
                                                                         </tr>
                                                                     </thead>
                                                                     <tbody>
                                                                         @forelse($vals->batchDetails as $k =>$val)
                                                                             <tr>
                                                                                 <input type="hidden"
                                                                                     name="rows_id[{{ $key }}][{{ $k }}]"
                                                                                     value="{{ $val->id ?? '' }}">
                                                                                 <input
                                                                                     name="ref_product_id[{{ $key }}][{{ $k }}]"
                                                                                     type="hidden"
                                                                                     value="{{ $val->ref_product_id ?? '' }}">
                                                                                 <input
                                                                                     name="at_closing_stock_id[{{ $key }}][{{ $k }}]"
                                                                                     type="hidden"
                                                                                     value="{{ $val->at_closing_stock_id ?? '' }}">
                                                                                 <input
                                                                                     name="at_purchase_details_id[{{ $key }}][{{ $k }}]"
                                                                                     type="hidden"
                                                                                     value="{{ $val->at_purchase_details_id ?? '' }}">
                                                                                 <input
                                                                                     name="op_organic_status[{{ $key }}][{{ $k }}]"
                                                                                     type="hidden"
                                                                                     value="{{ getSingleTableRecordById('ref_organic_status_master', 'id', $vals->organic_status ?? '')->id }}">
                                                                                 <td><input
                                                                                         name="pur_lots[{{ $key }}][{{ $k }}]"
                                                                                         type="checkbox"
                                                                                         id="purch{{ $val->id }}"
                                                                                         onclick="getPurch('{{ $val->id }}');"
                                                                                         required></td>

                                                                                 <td>{{ $val->product_code }}
                                                                                 </td>
                                                                                 <td>{{ getSingleTableRecordById('ref_organic_status_master', 'id', $vals->organic_status ?? '')->organic_status }}
                                                                                 </td>
                                                                                 <td class="right-align">{{ $val->total_quantity ?? 0 }}</td>
                                                                                 <td class="right-align">{{ $val->quantity_source ?? 0 }}</td>
                                                                                 <td class="right-align">{{ $val->available_quantity ?? 0 }}</td>
                                                                                 <td><input type="text"
                                                                                         name="used_quantity[{{ $key }}][{{ $k }}]"
                                                                                         id="tcqty{{ $val->id }}"
                                                                                         class="tc_qty"
                                                                                         data-id="{{ $val->id ?? '' }}"
                                                                                         data-avail="{{ $val->available_quantity ?? '' }}"
                                                                                         value=""
                                                                                         required></td>
                                                                                 <td>
                                                                                    <a href="javascript:void(0);"
                                                                                    class="btn btn-soft-primary "
                                                                                    onclick="saveProduct()">
                                                                                    <b>Add</b>
                                                                                </a>
                                                                                 </td>

                                                                             </tr>
                                                                         @empty
                                                                             <tr>
                                                                                 <td colspan="8">No records found..</td>
                                                                             </tr>
                                                                         @endforelse
                                                                     </tbody>

                                                                 </table>
                                                                 {{-- ******************** --}}
                                                             </td>
                                                         </tr>


                                                     @empty
                                                         <tr>
                                                             <td colspan="6">No records found..</td>
                                                         </tr>
                                                     @endforelse
                                                 </tbody>




                                                </table>

                                            </div>
                                        </div>
                                        <div style="text-align: center;">
                                            <button type="submit" class="btn btn-primary float-right">Proceed</button>
                                            <button type="reset" class="btn btn-primary float-left">Reset</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

<script>
    function toggleTable() {
        var innerTable = document.querySelector('.inner-table');
        innerTable.style.display = (innerTable.style.display === 'none' || innerTable.style.display === '') ? 'table' :
            'none';
    }
</script>
<script>
    function saveProduct() {
        var formData = $('#inetStockProductForm').serialize();
        $.ajax({
            type: 'POST',
            url: '{{ route('superadmin.InternalStockSaveProduct') }}',
            data: formData,
            success: function(response) {
                console.log(response);
                alert('Product added successfully');
                return false;
            },
            error: function(error) {
                console.log(error);
                alert('Product added failed');
                return false;
            }
        });
    }

    function getLots(id, ordid, ke) {

        if ($('input[name="lots[' + ke + ']"]').is(':checked')) {
            $('#tbl' + ordid).removeClass("d-none");
        }
        if ($('input[name="lots[' + ke + ']"]').is(':unchecked')) {
            $('#tbl' + ordid).addClass("d-none");
        }
    }
</script>

@extends('admin.layouts.app')
@section('content')
    <style>
        .pdf_maindiv {
            border: 1px solid #cccccc;
            width: 100%;
            float: left;
            padding: 2%;
        }

        .form-label blue-ht {
            font-size: 15px;
            color: #000;
            padding: 26px 0 12px 0px;
            position: relative;
            width: 100%;
            float: left;
        }
    </style>

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Application for Transaction Certificate</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Apply for internal stock transfer</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">

                    <div class="live-preview">

                        <div class="row white-inner">
                            <div class="sectitle">
                                <label for="labelInput" class="form-label  blue-ht">Packing Detail(s) Entry</label>
                            </div>
                            <form method="post" action="">
                                @csrf
                                <div class="col-xxl-12 col-md-12 ">
                                    <label for="labelInput" class="form-label blue-ht">Operators details:</label>
                                </div>

                                <div class="col-xxl-12 col-md-9 ms-3">
                                    <div class="row  ">
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                            <tr>
                                                <td class="pdf_txt1">Operator Name :</td>
                                                <td class="pdf_box">{{ Auth::user()->first_name }}
                                                    {{ Auth::user()->last_name }}</td>

                                                <td class="pdf_txt1">Operator Scope certificate Number :</td>
                                                <td class="pdf_box">{{ getScopeCerNoById(Auth::user()->id) }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Operator Type :</td>
                                                <td class="pdf_box">
                                                    {{ getOperatorTypeById(Auth::user()->ref_operator_type_id) }}</td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <hr>
                                </div>

                                <div class="col-xxl-12 col-md-12 ">
                                    <label for="labelInput" class="form-label blue-ht">Product value details:</label>
                                </div>
                                <div class="col-xxl-12 col-md-12">
                                    <div class="row  ">
                                        <div class="col-xxl-4 col-md-3 ">
                                            <div>
                                                <label for="labelInput" class="form-label">Product Name :</label>
                                               wheat

                                            </div>
                                        </div>

                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label for="labelInput" class="form-label">Value INR : </label>
1000

                                            </div>
                                        </div>

                                        <div class="col-xxl-4 col-md-3">
                                            <div>
                                                <label for="labelInput" class="form-label">Trade Name :
                                                </label>
gaurav
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="col-xxl-12 col-md-12 add-edit-div ">
                                    <label for="labelInput" class="form-label blue-ht">Packing details:</label>
                                </div>
                                <div class="col-xxl-12 col-md-12 add-edit-div">
                                    <div class="row ">
                                        <input type="hidden" name="trans_id" value="">

                                        <div class="col-xxl-4 col-md-6">
                                            <div>
                                                <label for="labelInput" class="form-label">Total Qty. Sourced(in Kg)
                                                    :</label>

                                            </div>
                                        </div>

                                        <div class="col-xxl-4 col-md-6">
                                            <div>
                                                <label for="labelInput" class="form-label">Reaming Qty.(in Kg) : </label>


                                            </div>
                                        </div>
                                        <div class="table-responsive">
                                            <table
                                                class="table table-bordered table-striped align-middle dataTable no-footer"
                                                width="100%" id="datatable_">
                                                <thead>
                                                    <tr>
                                                        <th>S.No.</th>
                                                        <th>Packing Type </th>
                                                        <th>No. of units</th>
                                                        <th>Qty. (Pack size in Kg).</th>
                                                        <th>Total Qty. (in Kg)</th>

                                                    </tr>

                                                </thead>
                                                @foreach ($packing as $data)
                                                    <tbody>
                                                        <td>{{ $loop->iteration }}</td>
                                                        <td>{{ getPackinNameById($packing->ref_packing_master_id ?? '') }}</td>
                                                        <td>{{ $packing->no_of_box ?? '' }}</td>
                                                        <td>{{ $packing->pack_size ?? '' }}</td>
                                                        <td>{{ $packing->total_qty_in_kg ?? '' }}</td>

                                                    </tbody>
                                                @endforeach
                                            </table>
                                        </div>
                                        <hr>
                                        <div class="col-xxl-12 col-md-12 ">
                                            <label for="labelInput" class="form-label blue-ht">Producer/Manufacture
                                                details</label>
                                        </div>

                                        <div class="row ">

                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">Name </label>
                                                    <input type="text" class="form-control"
                                                        value="{{ Auth::guard('misadmin')->user()->first_name }}"
                                                        id="" readonly>
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">Address</label>
                                                    <input type="text" class="form-control"
                                                        value="{{ Auth::guard('misadmin')->user()->address }}"
                                                        id="" readonly>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xxl-12 col-md-12">
                                            <label for="labelInput" class="form-label blue-ht">Internal Transfer
                                                Details</label>
                                        </div>
                                        <div class="col-xxl-12 col-md-12">
                                            <div class="row pdf_maindiv ">

                                                <table class="table table-bordered table-striped align-middle dataTable"
                                                    width="100%" id="datatable2">
                                                    <thead class="table-success">
                                                        <tr>
                                                            <th>Internal Transfer No. </th>
                                                            <th>Date Of Transfer</th>

                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>{{ $st->internal_transfer_no ?? '' }}</td>
                                                            <td>{{date('Y-m-d', strtotime( $st->date_of_internal_transfer ?? '')) }}
                                                            </td>

                                                        </tr>
                                                    </tbody>

                                                </table>

                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label class="form-label">Invoice value (in Rs) :</label>
                                                        {{ $st->transfer_value ?? '' }}
                                                    </div>
                                                </div>

                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label class="form-label">Place of Dispatch/origin :</label>
                                                        {{ $st->place_of_dispatch ?? '' }}
                                                    </div>
                                                </div>

                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label class="form-label">Lot number :</label>
                                                        {{ $st->lot_no  ?? ''}}
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label class="form-label">Place of destination :</label>
                                                        {{ $st->place_of_destination ?? '' }}
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label class="form-label">Marks & No. :</label>
                                                        {{ $st->marks_and_no ?? ''}}
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-3">
                                                    <div>
                                                        <label class="form-label">Reference Number : </label>
                                                        {{ $st->reference_no  ?? ''}}
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xxl-12 col-md-12">
                                        <label for="labelInput" class="form-label blue-ht">Transport Details</label>
                                    </div>
                                    <div class="col-xxl-12 col-md-12">
                                        <div class="row  pdf_maindiv">
                                            <div class="col-xxl-4 col-md-3">
                                                <div>
                                                    <label class="form-label">Mode of Transport :
                                                    </label> {{getTransportNameById($st->transportation_mode ?? '') }}
                                                    <br>
                                                    {{-- <input type="radio" id="html" name="transport_mode"
                                                        value="road"
                                                        {{ !empty($st->transportation_mode) && $st->transportation_mode == 'road' ? 'checked' : '' }}>
                                                    <label for="road">Road</label>
                                                    <input type="radio" id="css" name="transport_mode"
                                                        value="train"
                                                        {{ !empty($st->transportation_mode) && $st->transportation_mode == 'train' ? 'checked' : '' }}>
                                                    <label for="train">Train</label>
                                                    <input type="radio" id="html" name="transport_mode"
                                                        value="air"
                                                        {{ !empty($st->transportation_mode) && $st->transportation_mode == 'air' ? 'checked' : '' }}>
                                                    <label for="air">Air</label>
                                                    <input type="radio" id="css" name="transport_mode"
                                                        value="ship"
                                                        {{ !empty($st->transportation_mode) && $st->transportation_mode == 'ship' ? 'checked' : '' }}>
                                                    <label for="ship">Ship</label><br> --}}
                                                </div>
                                            </div>

                                        </div>
                                    </div>

                                    <div class="col-xxl-12 col-md-12 road_div ">
                                        <label for="labelInput" class="form-label blue-ht">Vehicle/Container details</label>
                                    </div>
                                    <div class="col-xxl-12 col-md-12 road_div ">
                                        <div class="row pdf_maindiv ">
                                            <div class="col-xxl-4 col-md-3">
                                                <div>
                                                    <label class="form-label">Vehicle No./Container No. : </label>
                                                    {{ $st->vehicle_no ?? '' }}
                                                </div>
                                            </div>
                                            <div class="col-xxl-4 col-md-3">
                                                <div>
                                                    <label class="form-label">Transport Document No. : </label>
                                                    {{ $st->transport_document_no ?? '' }}
                                                </div>
                                            </div>
                                            <div class="col-xxl-4 col-md-3">
                                                <div>
                                                    <label class="form-label">Date Of Transport :</label>
                                                    {{date('Y-m-d', strtotime( $st->date_of_transport ?? '')) }}
                                                </div>
                                            </div>


                                        </div>
                                    </div>

                                    <div class="col-xxl-4 col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">Gross weight (in MT)</label>
                                            {{ $st->gross_weight ?? '' }}
                                        </div>
                                    </div>
                            </form>

                            <a href="{{ route('superadmin.InternalStockDetail1', $id) }}"
                                class="btn btn-primary mt-2">Back </a>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
@endsection
@push('script')
    <div class="modal fade" id="addBatchModalgrid" tabindex="-1" aria-labelledby="addBatchModalgridLabel"
        aria-modal="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addBatchModalgridLabel">Edit Product</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="batch_popup">

                </div>
            </div>
        </div>
    </div>
    <script></script>
@endpush

@extends('admin.layouts.app')
@section('content')

<style>
    .right-align {
        text-align: right;
    }
</style>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Apply for internal stock transfer</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Apply for internal stock transfer</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">
                    <a class="nav-link" id="step0-tab"
                        href="">Add Product</a>
                    <a class="nav-link active" id="step2-tab"
                        href="">Packing Details</a>
                    <a class="nav-link " id="step3-tab" href="javascript:void(0);">Internal stock Details</a>
                </div>
            </nav>
            @if($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step0">
                    <div class="card">
                        <div class="card-body">
                            <div class="live-preview">

                                <div class="row seperatesec white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="mb-sm-0">PACKING DETAILS(S) ENTRY</label>
                                    </div>

                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label blue-ht">Operator Detail(s)</label>
                                    </div>
                                    <div class="pdf_maindiv">
                                        <!--Operator Detail(s)-->
                                        <div class="container-fluid">
                                            <div class="row">
                                                <div class="col-6">
                                                    <!--form1 tab starts here-->
                                                    <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                        <tr>
                                                            <td class="pdf_txt1">Operator Name :</td>
                                                            <td class="pdf_box">{{ Auth::user()->first_name }}
                                                                {{ Auth::user()->last_name }}</td>
                                                        </tr>
                                                        <tr>
                                                            <td class="pdf_txt1">Operator Type :</td>
                                                            <td class="pdf_box">
                                                                {{ getOperatorTypeById(Auth::user()->ref_operator_type_id) }}
                                                            </td>

                                                            </td>
                                                        </tr>
                                                    </table>
                                                    <!--form1 tab end here-->
                                                </div>
                                                <div class="col-6">
                                                    <!--form1 tab starts here-->
                                                    <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                        <tr>
                                                            <td class="pdf_txt1">Scope Certificate number :</td>
                                                            <td class="pdf_box">{{ getScopeCerNoById(Auth::user()->id) }}
                                                            </td>
                                                        </tr>
                                                    </table>
                                                    <!--form1 tab end here-->
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="row seperatesec white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label blue-ht">Products Sourced
                                            Detail(s)</label>
                                    </div>
                                    <div class="card-body">
                                        <div class="table-responsive">
                                            <table
                                                class="table table-bordered table-striped align-middle dataTable no-footer"
                                                width="100%" id="datatable">
                                                <thead>
                                                    <tr>

                                                        <th>Product</th>
                                                        <th>Status</th>
                                                        <th>Total Quantity (In MT)</th>
                                                        <th>Remaining Quantity (In MT)</th>
                                                        <th>Sourced Quantity (In MT)</th>
                                                        <th>Packing Entered</th>
                                                        {{-- <th>Action</th> --}}
                                                    </tr>
                                                </thead>
                                                @forelse ($packingData as $data)
                                                    <tbody>
                                                        <tr class="pro-tr ">

                                                            <td class="right-align">{{ ($data->product_code ?? '') }}</td>
                                                            <td class="right-align">{{ getRefOrganicStatuscodeByname($data->organic_status ?? '') }}</td>
                                                            <td class="right-align">{{ $data->total_qty ?? '' }}</td>
                                                            <td class="right-align">{{ $data->rem_qty ?? '' }}</td>
                                                            <td class="right-align">{{ $data->quantity_for_tc ?? '' }}</td>
                                                            <td class="right-align">No</td>
                                                            {{-- <td>
                                                        <a href="{{route('superadmin.PackingDetailAddUpdate', $data->id )}}" class="btn btn-soft-primary"></span>Add/Edit/Packing</a>
                                                    </td> --}}
                                                        </tr>
                                                    @empty
                                                    </tbody>
                                                @endforelse
                                            </table>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <form method="post" action="{{ route('superadmin.PackingDetailSave' , $id) }}">
                                    @csrf
                                    @forelse($trans as  $source)


                                    <input type="hidden" name="at_op_transaction_product_sourced_id" value="{{ $source->id ??'' }}">
                                    @empty

                                    @endforelse
                                    <div class="row seperatesec white-inner">
                                        <div class="sectitle">
                                            <label for="labelInput" class="mb-sm-0">Add Product Value Detail(s)</label>
                                        </div>
                                        <div class="pdf_maindiv">
                                            <!--Operator Detail(s)-->
                                            <div class="container-fluid">
                                                <div class="row">
                                                    <div class="col-6">
                                                        <!--form1 tab starts here-->
                                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                            <tr>
                                                                <td class="pdf_txt1">Product Name &nbsp;&nbsp;&nbsp;&nbsp; :
                                                                </td>
                                                                <td class="pdf_box right-align"><input type="text" name="" class="form-control" readonly value="{{ ($data->product_code ?? '') }}">
                                                                    <input type="hidden" name="ref_product_id"  readonly value="{{ ($data->product_code ?? '') }}">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="pdf_txt1 right-align">Value INR:</td>
                                                                <td class="pdf_box"> <input type="text" class="form-control" name="value_inr" >
                                                                </td>
                                                            </tr>
                                                        </table>
                                                        <!--form1 tab end here-->
                                                    </div>
                                                    <div class="col-6">
                                                        <!--form1 tab starts here-->
                                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                            <tr>
                                                                <td class="pdf_txt1 right-align">Trade name :</td>
                                                                <td class="pdf_box"> <input type="text" class="form-control" name="trade_name_of_product" >
                                                                </td>
                                                            </tr>
                                                        </table>
                                                        <!--form1 tab end here-->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="row seperatesec white-inner">
                                        <div class="sectitle">
                                            <label for="labelInput" class="form-label blue-ht">Add/Update Packing
                                                Details</label>
                                        </div>
                                        <div class="container-fluid">
                                            <div class="row">
                                                <div class="col-6">
                                                    <!--form1 tab starts here-->
                                                    <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                        <tr>
                                                            <td class="pdf_txt1 right-align">Total Quantity Sourced (in Kg)
                                                                &nbsp;&nbsp;&nbsp;&nbsp; :</td>
                                                            <td class="pdf_box right-align">
                                                                &nbsp;&nbsp;&nbsp;&nbsp;<input type="text" class="form-control" name="total_qty" readonly value="{{ $data->total_qty }}">
                                                            </td>
                                                        </tr>
                                                    </table>
                                                    <!--form1 tab end here-->
                                                </div>
                                                <div class="col-6">
                                                    <!--form1 tab starts here-->
                                                    <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                        <tr>
                                                            <td class="pdf_txt1 right-align">Remaining Quantity (in Kg) :</td>
                                                            <td class="pdf_box right-align"> <input type="text" class="form-control" name="rem_qty" readonly value="{{ $data->rem_qty }}">
                                                            </td>
                                                        </tr>
                                                    </table>
                                                    <!--form1 tab end here-->
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="table-responsive">
                                                <table
                                                    class="table table-bordered table-striped align-middle dataTable no-footer"
                                                    width="100%" id="datatable">
                                                    <thead>
                                                        <tr>
                                                            <th>S.No</th>
                                                            <th>Packing Type</th>
                                                            <th>No. of Units</th>
                                                            <th>Quantity (Packs Size in Kgs)</th>
                                                            <th>Total Quantity (in Kgs)</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr class="pro-tr">
                                                            <td><input type="checkbox" id="checkbox"></td>
                                                            <td>

                                                                <select id="selectMenu" name="ref_packing_master_id" onchange="checkValue()" class="form-control" >
                                                                    <option value="">Select Packing Type</option>
                                                                    @forelse ($packingType as $data)
                                                                        <option value="{{ $data->id }}">{{ $data->packing_type }}</option>
                                                                    @empty
                                                                        <option value="">No packing types available</option>
                                                                    @endforelse
                                                                </select>

                                                                <div id="otherInput" style="display: none;" >


                                                                    <input type="text" id="other" placeholder="Enter other Packing type" name="other" class="form-control">
                                                                </div>

                                                            </td>
                                                            <td><input type="text" id="no_of_box" name="no_of_box" class="form-control right-align"></td>
                                                            <td><input type="text" id="pack_size" name="pack_size" class="form-control right-align"></td>
                                                            <td><input type="text" id="total_qty_in_kg" name="total_qty_in_kg" class="form-control right-align"></td>
                                                        </tr>
                                                    </tbody>
                                                </table>

                                            </div>
                                        </div>

                                        <div style="text-align: center;">
                                            <span id="successmsg" class="badge badge-soft-success"></span><br>
                                            <a href="{{ route('superadmin.InternalStockAddProduct', $id) }}"
                                                class="btn btn-primary mt-2">Back to Add Product</a>


                                            <button type="submit" class="btn btn-primary mt-2 proceed">Proceed</button>

                                        </div>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
    </div>
@endsection
@push('script')
<script>
    function checkValue() {
        var selectMenu = document.getElementById("selectMenu");
        var otherInput = document.getElementById("otherInput");

        if (selectMenu.value == "8") {
            otherInput.style.display = "block";
        } else {
            otherInput.style.display = "none";

        }
    }
</script>
@endpush

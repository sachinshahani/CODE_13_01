@extends('admin.layouts.app')
@section('content')
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Apply for internal stock transfer</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Apply for internal stock transfer</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <nav>
            <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">
                <a class="nav-link" id="step0-tab" href="{{route('superadmin.InternalStockAddProduct', $id)}}">Add Product</a>
                <a class="nav-link active" id="step2-tab" href="{{route('superadmin.InternalStockPackingDetail', $id)}}">Packing Details</a>
                <a class="nav-link " id="step3-tab" href="javascript:void(0);">Internal stock Details</a>
            </div>
        </nav>
         <div class="tab-content py-4 custom-tab-content">
            <div class="tab-pane fade show active" id="step0">
                <div class="card">
                    <div class="card-body">
                        <div class="live-preview">
                            <div class="row seperatesec white-inner">
                                <div class="sectitle">
                                    <label for="labelInput" class="mb-sm-0">PACKING DETAILS(S) ENTRY</label>
                                </div>

                                <div class="sectitle">
                                    <label for="labelInput" class="form-label blue-ht">Operator Detail(s)</label>
                                </div>
                                 <div class="pdf_maindiv">
                                <!--Operator Detail(s)-->
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-6">
                                            <!--form1 tab starts here-->
                                            <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                <tr>
                                                    <td class="pdf_txt1">Operator Name:</td>
                                                    <td class="pdf_box">{{Auth::user()->first_name}} {{Auth::user()->last_name}}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Operator Type       :</td>
                                                    <td class="pdf_box">{{getOperatorTypeById(Auth::user()->ref_operator_type_id)}}</td>
                                                </tr>
                                            </table>
                                            <!--form1 tab end here-->
                                        </div>
                                        <div class="col-6">
                                            <!--form1 tab starts here-->
                                            <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                <tr>
                                                    <td class="pdf_txt1">Operator scope Certificate number     :</td>
                                                    <td class="pdf_box">{{getScopeCerNoById(Auth::user()->id)}}</td>
                                                </tr>
                                            </table>
                                            <!--form1 tab end here-->
                                        </div>
                                    </div>
                                </div>
                            </div>

                            </div>  <div class="row seperatesec white-inner">
                                <div class="sectitle">
                                    <label for="labelInput" class="form-label blue-ht">Products Sourced Detail(s)</label>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped align-middle dataTable no-footer" width="100%" id="datatable">
                                            <thead>
                                                <tr>

                                                    <th>Product</th>
                                                    <th>Status</th>
                                                    <th>Total Quantity (In MT)</th>
                                                    <th>Remaining Quantity (In MT)</th>
                                                    <th>Sourced Quantity (In MT)</th>
                                                    <th>Packing Entered</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            @forelse ($packingData as $data )


                                            <tbody>
                                                <tr class="pro-tr">

                                                    <td>{{$data->product_code ?? ''}}</td>
                                                    <td>{{$data->organic_status ?? ''}}</td>
                                                    <td>{{$data->total_qty ?? ''}}</td>
                                                    <td>{{$data->rem_qty ?? ''}}</td>
                                                    <td>{{$data->quantity_for_tc ?? ''}}</td>
                                                    <td>No</td>
                                                    <td>
                                                        <a href="{{route('superadmin.PackingDetailAddUpdate', $data->id )}}" class="btn btn-soft-primary"></span>Add/Edit/Packing</a>
                                                    </td>
                                                </tr>
                                                @empty
                                            </tbody>


                                            @endforelse
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

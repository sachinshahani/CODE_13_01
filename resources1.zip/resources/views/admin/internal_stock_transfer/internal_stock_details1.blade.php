@extends('admin.layouts.app')
@section('content')
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Apply for internal stock transfer</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Apply for internal stock transfer</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">
                    <a class="nav-link " id="step0-tab" href="">Add Product</a>
                    <a class="nav-link " id="step2-tab" href="">Packing Details</a>
                    <a class="nav-link active" id="step3-tab" href="">Internal Stock Details</a>
                </div>
            </nav>
        </div>
        <div class="tab-content py-4 custom-tab-content">
            <div class="tab-pane fade show active" id="step1">

                <div class="live-preview">

                    <div class="row white-inner">
                        <form method="post" action="{{ route('superadmin.forwadToCbSave') }}">
                            @csrf
                            <input type="hidden" value="{{ $id }}" name="row_id">

                            <div style="text-align: center;">
                                <a href="{{ route('superadmin.viewApplication', $id) }}"
                                class="">Click here to preview the Internal Stock Application</a>
                                <span id="successmsg" class="badge badge-soft-success"></span><br>
                                <a href="{{ route('superadmin.InternalStockDetail', $id) }}"
                                    class="btn btn-primary mt-2">Edit</a>
                                <button type="submit" class="btn btn-primary mt-2">Forward To CB</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection


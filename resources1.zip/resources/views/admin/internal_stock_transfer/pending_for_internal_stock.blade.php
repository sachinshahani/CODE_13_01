@extends('admin.layouts.app')
@section('content')
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Pendding Application for internal stock Transfer</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Pendding Application for internal stock Transfer</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <div class="row">
        <div class="tab-content py-4 custom-tab-content">
            <div class="tab-pane fade show active" id="step1">

                <div class="live-preview">

                    <div class="row  white-inner">

                        <div class="col-lg-12">
                            <div class="card">

                                <div class="card-body table-responsive">
                                    <b>
                                        <p>PENDDING APPLICATION FOR INTERNAL STOCK TRANSFER:</p>
                                    </b>
                                    <table id="searchResultsTable" class="table table-bordered table-striped align-middle"
                                        style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>S.No.</th>
                                                <th>ST Application No </th>
                                                <th>Date of Application</th>
                                                <th>Transfer</th>
                                                <th>Transferee</th>
                                                {{-- <th>Status</th>
                                                <th>Day Left To Issue ST</th> --}}
                                                <th>Action</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>


                                            </tr>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!--end col-->
                    </div>
                    <script>
                        $(document).ready(function() {
                            var searchResultsTable = $('#searchResultsTable').DataTable({
                                processing: true,
                                serverSide: true,
                                lengthMenu: [
                                    [10, 25, 50, 100, -1],
                                    [10, 25, 50, 100, "All"]
                                ],
                                order: [
                                    [0, 'asc']
                                ],
                                ajax: {
                                    url: '{{ route('superadmin.SearchST') }}',
                                    type: 'GET',
                                    data: function(d) {

                                        d._token = "{{ csrf_token() }}";
                                        d.registration_no = $('#registration_no').val();
                                    }
                                },
                                columns: [{
                                        data: 'DT_RowIndex',
                                        name: 'DT_RowIndex',
                                        searchable: false
                                    },
                                    {
                                        data: 'st_no',
                                        name: 'st_no'
                                    },
                                    {
                                        data: 'date_app',
                                        name: 'date_app'
                                    },
                                    {
                                        data: 'transfer',
                                        name: 'transfer'
                                    },
                                    {
                                        data: 'transferee',
                                        name: 'transferee'
                                    },
                                    // {
                                    //     data: 'status',
                                    //     name: 'status'
                                    // },
                                    // {
                                    //     data: 'days_left',
                                    //     name: 'days_left'
                                    // },

                                    {
                                        data: 'action',
                                        name: 'action',
                                        orderable: false,
                                        searchable: false
                                    }
                                ]
                            });

                            // Event handler for the search button
                            $('#searchBtn').click(function(e) {
                                e.preventDefault();
                                searchResultsTable.ajax.reload();
                            });
                        });
                    </script>

                </div>
            </div>
        </div>
    </div>
@endsection

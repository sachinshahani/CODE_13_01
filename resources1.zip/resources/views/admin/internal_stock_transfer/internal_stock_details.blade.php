@extends('admin.layouts.app')
@section('content')
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Apply for internal stock transfer</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Apply for internal stock transfer</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">
                    <a class="nav-link " id="step0-tab" href="">Add Product</a>
                    <a class="nav-link " id="step2-tab" href="">Packing Details</a>
                    <a class="nav-link active" id="step3-tab" href="">Internal Stock Details</a>
                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step0">
                    <div class="card">
                        <div class="card-body">
                            <form method="post" action="{{ route('superadmin.InternalStockDetailSave', $id) }}">
                                @csrf
                            <div class="live-preview">
                                <div class="row seperatesec white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="mb-sm-0">Processor/Manufacturer</label>
                                    </div>
                                    <div class="pdf_maindiv">
                                        <!--Operator Detail(s)-->
                                        <div class="container-fluid">
                                            <div class="row">
                                                <div class="col-6">
                                                    <!--form1 tab starts here-->
                                                    <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                        <tr>
                                                            <td class="pdf_txt1">Name :</td>
                                                            <td class="pdf_box"><input type="text" name="producer_name" readonly  value="{{ Auth::user()->first_name }}" class="form-control road_field" >

                                                            </td>
                                                        </tr>

                                                    </table>
                                                    <!--form1 tab end here-->
                                                </div>
                                                <div class="col-6">
                                                    <!--form1 tab starts here-->
                                                    <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                        <tr>
                                                            <td class="pdf_txt1">Address:</td>
                                                            <td class="pdf_box"><input type="text" name="address1" readonly  value="{{ Auth::user()->address }}" class="form-control road_field" >

                                                            </td>
                                                        </tr>
                                                    </table>
                                                    <!--form1 tab end here-->
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="row seperatesec white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label blue-ht">Transfered By
                            </label>
                                    </div>

                                    <div class="pdf_maindiv">
                                        <!--Operator Detail(s)-->
                                        <div class="container-fluid">
                                            <div class="row">
                                                <div class="col-6">
                                                    <!--form1 tab starts here-->
                                                    <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                        <tr>
                                                            <td class="pdf_txt1">Scope certificate Number :</td>
                                                            <td class="pdf_box"><input type="text" name="scope_certification_no" readonly  value="{{ getScopeCerNoById(Auth::user()->id) }}" class="form-control road_field" >

                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td class="pdf_txt1">Transfer Name :</td>
                                                            <td class="pdf_box"><input type="text" name="transfer_name" readonly  value="{{ Auth::user()->first_name }}" class="form-control road_field">

                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td class="pdf_txt1">Address :</td>
                                                            <td class="pdf_box"><input type="text" name="address2" readonly  value="{{ Auth::user()->address }}" class="form-control road_field" >

                                                            </td>
                                                        </tr>

                                                    </table>
                                                    <!--form1 tab end here-->
                                                </div>
                                                <div class="col-6">
                                                    <!--form1 tab starts here-->
                                                    <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                        <tr>
                                                            <td class="pdf_txt1">Seller ID Proof:</td>
                                                            <td class="pdf_box"><input type="text" name="seller_id_proof" readonly  value=" DERTR2232E" class="form-control road_field" >

                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td class="pdf_txt1">Email:</td>
                                                            <td class="pdf_box"><input type="text" name="email_id" readonly  value="{{ Auth::user()->email }}" class="form-control road_field" >

                                                            </td>
                                                        </tr>

                                                    </table>
                                                    <!--form1 tab end here-->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                    <input type="hidden" name="at_op_transaction_product_sourced_id" value="">

                                    <div class="row seperatesec white-inner">
                                        <div class="sectitle">
                                            <label for="labelInput" class="mb-sm-0">Transferee Detail(s)</label>
                                        </div>
                                        <div class="pdf_maindiv">
                                            <!--Operator Detail(s)-->
                                            <div class="container-fluid">
                                                <div class="row">
                                                    <div class="col-6">
                                                        <!--form1 tab starts here-->
                                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                            <tr>
                                                                <td class="pdf_txt1">Enter Transferee Scope Certificate No:
                                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                                </td>
                                                                <td class="pdf_box"><input type="text"
                                                                        name="transferee_scope_certification_no"  value="" class="form-control road_field">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="pdf_txt1">Transferee Name:</td>
                                                                <td class="pdf_box"> <input type="text" name="transferee_name" class="form-control road_field">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="pdf_txt1">State/UT:</td>
                                                                <td class="pdf_box">

                                                                    <select class="form-select state" name="ref_state_id" id="ref_state_id" required>
                                                                        <option value="">Select State</option>
                                                                        @forelse(getAllState() as $state)
                                                                        <option value="{{ $state->id }}" @selected(old('state')==$state->
                                                                            id)>{{ $state->state_name }}
                                                                        </option>
                                                                        @empty
                                                                        @endforelse
                                                                    </select>
                                                                    {{-- <input type="text" name="ref_state_id" class="form-control road_field"> --}}
                                                                </td>
                                                            </tr>
                                                        </table>
                                                        <!--form1 tab end here-->
                                                    </div>
                                                    <div class="col-6">
                                                        <!--form1 tab starts here-->
                                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                            <tr>
                                                                <td class="pdf_txt1">Transferee ID Proof:</td>
                                                                <td class="pdf_box"> <input type="text"
                                                                        name="transferee_id_proof" class="form-control road_field">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="pdf_txt1">Address:</td>
                                                                <td class="pdf_box"> <input type="text"
                                                                        name="transferee_address" class="form-control road_field">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="pdf_txt1">Email:</td>
                                                                <td class="pdf_box"> <input type="text"
                                                                        name="transferee_email_id" class="form-control road_field">
                                                                </td>
                                                            </tr>
                                                        </table>
                                                        <!--form1 tab end here-->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="row seperatesec white-inner">
                                        <div class="sectitle">
                                            <label for="labelInput" class="form-label blue-ht">Transfered
                                                 To</label>
                                        </div>
                                        <div class="table-responsive">
                                            <table
                                                class="table table-bordered table-striped align-middle dataTable no-footer"
                                                width="100%" id="datatable_">
                                                <thead>
                                                    <tr>
                                                        <th>Internal Transfer No.</th>
                                                        <th>Date Of Transfer</th>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td class="pdf_box">
                                                            &nbsp;&nbsp;<input type="text" name="internal_transfer_no"
                                                                value="" class="form-control road_field">
                                                        </td>
                                                        <td class="pdf_box">
                                                            &nbsp;&nbsp;<input type="date" name="date_of_internal_transfer"
                                                                value="" class="form-control road_field">
                                                        </td>

                                                    </tr>

                                                </tbody>
                                            </table>
                                            <div class="container-fluid">
                                                <div class="row">
                                                    <div class="col-6">
                                                        <!--form1 tab starts here-->
                                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                            <tr>
                                                                <td class="pdf_txt1">Transfer Value (in Rs)
                                                                    &nbsp;&nbsp;&nbsp;&nbsp; :</td>
                                                                <td class="pdf_box">
                                                                    &nbsp;&nbsp;&nbsp;&nbsp;<input type="text"
                                                                        name="transfer_value"  value="" class="form-control road_field">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="pdf_txt1">Batch No
                                                                    &nbsp;&nbsp;&nbsp;&nbsp; :</td>
                                                                <td class="pdf_box">
                                                                    &nbsp;&nbsp;&nbsp;&nbsp;<input type="text"
                                                                        name="lot_no"  value="" class="form-control road_field">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="pdf_txt1">Marks & No
                                                                    &nbsp;&nbsp;&nbsp;&nbsp; :</td>
                                                                <td class="pdf_box">
                                                                    &nbsp;&nbsp;&nbsp;&nbsp;<input type="text"
                                                                        name="marks_and_no"  value="" class="form-control road_field">
                                                                </td>
                                                            </tr>
                                                        </table>
                                                        <!--form1 tab end here-->
                                                    </div>
                                                    <div class="col-6">
                                                        <!--form1 tab starts here-->
                                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                            <tr>
                                                                <td class="pdf_txt1">Place of Dispatch/Origin
                                                                    &nbsp;&nbsp;&nbsp;&nbsp;:</td>
                                                                <td class="pdf_box"> <input type="text" name="place_of_dispatch"
                                                                         value="" class="form-control road_field">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="pdf_txt1">Place of Destination
                                                                    &nbsp;&nbsp;&nbsp;&nbsp; :</td>
                                                                <td class="pdf_box">
                                                                    &nbsp;&nbsp;&nbsp;&nbsp;<input type="text"
                                                                        name="place_of_destination"  value="" class="form-control road_field">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="pdf_txt1">Reference No
                                                                    &nbsp;&nbsp;&nbsp;&nbsp; :</td>
                                                                <td class="pdf_box">
                                                                    &nbsp;&nbsp;&nbsp;&nbsp;<input type="text"
                                                                        name="reference_no"  value="" class="form-control road_field">
                                                                </td>
                                                            </tr>
                                                        </table>
                                                        <!--form1 tab end here-->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row seperatesec white-inner">
                                            <div class="sectitle">
                                                <label for="labelInput" class="form-label blue-ht">Transport Details
                                                </label>
                                            </div>
                                            <div class="col-xxl-12 col-md-12">
                                                <div class="row  pdf_maindiv">
                                                    <div class="col-xxl-4 col-md-3">
                                                        <div>
                                                            <label class="form-label">Mode of Transport<span
                                                                    class="required">
                                                                    *</span></label>
                                                            <br>
                                                            <input type="radio" id="html" name="transportation_mode"
                                                                value="1"
                                                                {{ !empty($data->transport_mode) && $data->transport_mode == 'road' ? 'checked' : '' }}>
                                                            <label for="road">Road</label>
                                                            <input type="radio" id="css" name="transportation_mode"
                                                                value="2"
                                                                {{ !empty($data->transport_mode) && $data->transport_mode == 'train' ? 'checked' : '' }}>
                                                            <label for="train">Train</label>
                                                            <input type="radio" id="html" name="transportation_mode"
                                                                value="3"
                                                                {{ !empty($data->transport_mode) && $data->transport_mode == 'air' ? 'checked' : '' }}>
                                                            <label for="air">Air</label>
                                                            <input type="radio" id="css" name="transportation_mode"
                                                                value="4"
                                                                {{ !empty($data->transport_mode) && $data->transport_mode == 'ship' ? 'checked' : '' }}>
                                                            <label for="ship">Ship</label><br>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xxl-12 col-md-12 road_div ">
                                            <label for="labelInput" class="pdf_heading">Road details</label>
                                        </div>
                                        <div class="col-xxl-12 col-md-12 road_div">
                                            <div class="row pdf_maindiv ">
                                                <div class="col-xxl-3 col-md-3">
                                                    <div>
                                                        <label class="form-label">Vehicle No./Container No.<span
                                                                class="required"> *</span></label>
                                                        <input type="text" class="form-control road_field"
                                                            value="" id="" name="vehicle_no">
                                                    </div>
                                                </div>
                                                <div class="col-xxl-3 col-md-3">
                                                    <div>
                                                        <label class="form-label">Transport Document No.<span
                                                                class="required">
                                                                *</span></label>
                                                        <input type="text" class="form-control road_field"
                                                            value="" id="" name="transport_document_no">
                                                    </div>
                                                </div>
                                                <div class="col-xxl-3 col-md-3">
                                                    <div>
                                                        <label class="form-label">Date Of Transport<span class="required">
                                                                *</span></label>
                                                        <input type="date" class="form-control road_field"
                                                            value="" id="" name="date_of_transport">
                                                    </div>
                                                </div>
                                                <div class="col-xxl-3 col-md-3">
                                                    <div>
                                                        <label class="form-label">Gross Weight(in MT)<span class="required">
                                                                *</span></label>
                                                        <input type="text" class="form-control road_field"
                                                            value="" id="" name="gross_weight">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                        <div style="text-align: center;">
                                            <span id="successmsg" class="badge badge-soft-success"></span><br>
                                            <a href="" class="btn btn-primary mt-2">Back to Packing Details </a>
                                            <button type="submit" class="btn btn-primary mt-2 proceed">Save</button>
                                        </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@extends('admin.layouts.app')

@section('content')
    <style>
        .customtextarea {
            height: 80px;
        }
    </style> <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">INTC Report after added

                </h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">INTC Report after added
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div>

        <div class="row white-inner">

            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Name of Operator<span class="required"></span></label>
                   <input type="text" class="form-control" >
                </div>
            </div>

            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">CB<span class="required"></span></label>
                    <select class="form-select state" name="operatorType" id="operatorType" required>
                        <option value="">--Select--</option>
                        <option value="1">All</option>


                    </select>
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Operator Type<span class="required"></span></label>
                    <select class="form-select state" name="operatorType" id="operatorType" required>
                        <option value="">--Select--</option>
                        <option value="1">Grower Group</option>
                        <option value="2">IP</option>
                        <option value="3">Trader</option>
                        <option value="4">Processor</option>
                        <option value="5">Wild Harvet</option>
                    </select>
                </div>
            </div>

            <div class="col-xxl-1 col-md-4 gy-2">
                <div class="text-center">
                    <button type="submit" id="searchBtn" class="btn btn-primary" style="margin: 36px;">Search</button>
                </div>
            </div>




        </div>


    </div>

    <div>
        <div class="row">

            <div class="col-lg-12">
                <div class="card">

                    <div class="card-body table-responsive">
                        <p> List of Operator while Adding INTC
                        </p>
                        <table id="searchResultsTable" class="table table-bordered table-striped align-middle"
                            style="width:100%">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Registration No</th>
                                    <th>Operator Name</th>
                                    <th>INTC No</th>
                                    <th>INTC Date</th>
                                    <th>INTC Status</th>
                                    <th>INTC Description</th>
                                    <th>Date of Notitifcation</th>
                                    <th>Notifying Country</th>
                                    <th>Date of Shipment</th>
                                    <th>Shipping Bill No</th>
                                    <th>Date of Certificate of Inspection(COI)Issued</th>
                                    <th>Past Hostory</th>
                                    <th>Action</th>




                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="14">No Record found.</td>

                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!--end col-->
        </div>

        <script>

        </script>
    @endsection

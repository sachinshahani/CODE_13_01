@extends('admin.layouts.app')

@section('content')
    <style>
        .customtextarea {
            height: 80px;
        }
    </style> <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Suspended/Terminated Operator</h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Suspended/Terminated Operator</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div>
        <div class="row white-inner">
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Operator Name/ Registration No<span class="required"></span></label>
                    <select class="form-select state" name="operatorType" id="operatorType" required>
                        <option value="">--Select--</option>
                        <option value="2">Grower Group</option>
                        <option value="3">Individual Producer</option>
                        <option value="4">Wild</option>
                        <option value="5">Trader</option>
                        <option value="6">Processor</option>
                    </select>                
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">CB<span class="required"></span></label>
                    <select class="form-select state" name="active_cbf" id="active_cbf" required>
                        <option value="">--Select--</option>
                        @php
                            $cbNames = getCBNamesById(1);
                        @endphp
                        @foreach($cbNames as $id => $cbName)
                            <option value="{{$id}}">{{ $cbName }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Action on Operator<span class="required"></span></label>
                    <select class="form-select state" name="operatorAction" id="operatorAction" required>
                        <option value="">--Select--</option>
                        <option value="0">All</option>
                        <option value="1">Suspend</option>
                        <option value="2">Terminate</option>
                        <option value="3">Withdrawal By CB</option>
                        <option value="4">Withdrawal By Operator</option>
                        <option value="5">De-registration</option>
                    </select>
                </div>
            </div>
        </div>
    </div>
    <div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body table-responsive">
                        <p> List of Suspended/Terminated Operators</p>
                        <table id="searchResultsTable" class="table table-bordered table-striped align-middle" style="width:100%">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Certification Body Name</th>
                                    <th>Registration No</th>
                                    <th>Scope Certification No</th>
                                    <th>Operator Name</th>
                                    <th>Operator Type</th>
                                    <th>Validity Start Date</th>
                                    <th>Validity End Date</th>
                                    <th>Action (Suspension/ Termination)</th>
                                    <th>Action From Date</th>
                                    <th>Action To Date</th>
                                    <th>CB Remarks</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="12">No Record found.</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!--end col-->
        </div>
    </div>
@endsection

@push('script')
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    var table = $('#searchResultsTable').DataTable({
        dom: 'Bfrtip',
        lengthMenu: [
            [10, 25, 50, -1],
            [10, 25, 50, "All"]
        ],
        processing: true,
        serverSide: true,
        ajax: {
            url: '{{ route('superadmin.report-on-suspended-terminated') }}',
            type: 'GET',
            data: function(d) {
                d.operatorType = $('#operatorType').val();
                d.active_cbf = $('#active_cbf').val();
                d.operatorAction = $('#operatorAction').val();
            },
            error: function(xhr, error, code) {
                console.log(xhr.responseText);
            }
        },
        columns: [
            { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: true },
            { data: 'scope_certificate_no', name: 'scope_certificate_no', orderable: true },
            { data: 'registration_no', name: 'registration_no', orderable: true },
            { data: 'scope_certificate_no', name: 'scope_certificate_no', orderable: true },
            { data: 'operator_type', name: 'operator_type', orderable: true },
            { data: 'ref_operator_type_id', name: 'ref_operator_type_id', orderable: true },
            { data: 'validity_start_date', name: 'validity_start_date', orderable: true },
            { data: 'validity_end_date', name: 'validity_end_date', orderable: true },
            { data: 'operator_status', name: 'operator_status', orderable: true },
            { data: 'from_date', name: 'from_date', orderable: true },
            { data: 'to_date', name: 'to_date', orderable: true },
            { data: 'cb_reg_remarks', name: 'cb_reg_remarks', orderable: true },
        ],
        order: [
            [0, 'asc']
        ],
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    });

    $('#operatorType, #active_cbf, #operatorAction').on('change', function() {
        table.draw();
    });
</script>
@endpush

@extends('admin.layouts.app')

@section('content')
<style>
    .customtextarea {
        height: 80px;
    }
</style> 

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Report on Farm Count</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Report on Farm Count</li>
                </ol>
            </div>
        </div>
    </div>
</div>
<div>
    <div class="row white-inner">
        <div class="col-xxl-2 col-md-4 gy-3">
            <div>
                <label class="form-label">State<span class="required"></span></label>
                <select class="form-select state" name="state" id="state" required>
                    <option value="" name="state_name">--Select--</option>
                    @foreach(getAllState() as $state)
                        <option value="{{ $state->id }}">{{ $state->state_name }}</option>
                    @endforeach
                </select>
            </div>
        </div>
        <div class="col-xxl-2 col-md-4 gy-3">
            <div>
                <label class="form-label">District<span class="required"></span></label>
                <select class="form-select district" name="district" id="district" required>
                    <option value="" name="district_name">--Select--</option>
                </select>
            </div>
        </div>
        <div class="col-xxl-2 col-md-4 gy-3">
            <div>
                <label class="form-label">CB<span class="required"></span></label>
                <select class="form-select state" name="operatorType" id="operatorType" required>
                    <option value="">--Select--</option>
                    @php
                        $cbNames = getCBNamesById(1);
                    @endphp
                    @foreach($cbNames as $id => $cbName)
                        <option value="{{ $id }}">{{ $cbName }}</option>
                    @endforeach
                </select>
            </div>
        </div>
    </div>
</div>
<div>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body table-responsive">
                    <p>List of Farmer Count</p>
                    <table id="searchResultsTable" class="table table-bordered table-striped align-middle" style="width:100%">
                        <thead>
                            <tr>
                                <th>S.No.</th>
                                <th>State</th>
                                <th>State Count</th>
                                <th>District</th>
                                <th>District Count</th>
                                <th>CB wise</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('script')
<script>
$(document).ready(function() {
    $('#state').change(function() {
        var stateId = $(this).val();
        if (stateId) {
            $.ajax({
                url: '{{ route('getDistrictsByStateId') }}',
                type: 'GET',
                data: { state_id: stateId },
                success: function(data) {
                    $('#district').empty().append('<option value="">--Select--</option>');
                    $.each(data, function(key, value) {
                        $('#district').append('<option value="' + key + '">' + value + '</option>');
                    });
                }
            });
        } else {
            $('#district').empty().append('<option value="">--Select--</option>');
        }
    });

    var table = $('#searchResultsTable').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: '{{ route('superadmin.state-district-farmer-list') }}',
            type: 'GET',
            data: function(d) {
                d.state = $('#state').val();
                d.district = $('#district').val();
                d.operatorType = $('#operatorType').val();
            },
            dataSrc: function(json) {
                $('#stateCount').text(json.stateCount);
                $('#districtCount').text(json.districtCount);
                return json.data;
            },
            error: function(xhr, error, code) {
                console.error(xhr.responseText);
            }
        },
        columns: [
            { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false },
            { data: 'state', name: 'state' },
            { data: 'state_count', name: 'state_count' },
            { data: 'district', name: 'district' },
            { data: 'district_count', name: 'district_count' },
            { data: 'cb_wise', name: 'cb_wise' }
        ],
        language: {
            emptyTable: "No matching records found"
        }
    });

    $('#state, #district, #operatorType').on('change', function() {
        table.ajax.reload();
    });
});
</script>
@endpush

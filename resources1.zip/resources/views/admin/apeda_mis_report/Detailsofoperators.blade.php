@extends('admin.layouts.app')

@section('content')
    <style>
        .customtextarea {
            height: 80px;
        }
    </style> <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Details of ID-Proof of operators

                </h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Details of ID-Proof of operators
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div>
        <div class="row white-inner">
        <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Operator Type: <span class="required"></span></label>
                    <select class="form-select state" name="operatorType" id="operatorType" required>
                        <option value="">--Select--</option>
                        <option value="2">Grower Group</option>
                        <option value="3">INDIVIDUAL PRODUCER</option>
                        <option value="4">WILD</option>
                        <option value="5">TRADER</option>
                        <option value="6">PROCESSOR</option>
                    </select>
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
            <div>
                <label class="form-label">CB<span class="required"></span></label>
                <select class="form-select state" name="active_cbf" id="active_cbf" required>
                    <option value="">--Select--</option>
                    @php
                        $cbNames = getCBNamesById(1);
                    @endphp
                    @foreach($cbNames as $id => $cbName)
                        <option value="{{ $id }}">{{ $cbName }}</option>
                    @endforeach
                </select>
            </div>
        </div>
          {{--  <div class="col-xxl-1 col-md-4 gy-2">
                <div class="text-center">
                    <button type="submit" id="searchBtn" class="btn btn-primary" style="margin: 36px;">Search</button>
                </div>
            </div>--}}
        </div>
    </div>
    <div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body table-responsive">
                        <p> List of Ammendment Annexure
                        </p>
                        <table id="searchResultsTable" class="table table-bordered table-striped align-middle"
                            style="width:100%">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>CB Name</th>
                                    <th>Registration No.</th>
                                    <th>Operator Name</th>
                                    <th>Scope Certificate No.</th>
                                    <th>Operator Type</th>
                                    <th>Date of Registration</th>
                                    <th>Address</th>
                                    <th>Communication Detail(s)</th>
                                    <th>Manage By (Self/Mandator)</th>
                                    <th>View Supporting Document(Registration Certificate/Contact Person Photo/Contact Person Photo)</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="13">No Record found.</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!--end col-->
        </div>
        @endsection
        @push('script')
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    var table = $('#searchResultsTable').DataTable({
        dom: 'Bfrtip',
        lengthMenu: [
            [10, 25, 50, -1],
            [10, 25, 50, "All"]
        ],
        processing: true,
        serverSide: true,
        ajax: {
            url: '{{ route('superadmin.detail-id-proof-operator') }}',
            type: 'GET',
            data: function(d) {
                d.operatorType = $('#operatorType').val();
                d.active_cbf = $('#active_cbf').val();
            },
            error: function(xhr, error, code) {
                console.log(xhr.responseText); // This will print the error response
            }
        },
        columns: [
            { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: true },
            { data: 'first_name', name: 'first_name', orderable: true },
            { data: 'registration_no', name: 'registration_no', orderable: true },
            { data: 'ref_operator_type', name: 'ref_operator_type', orderable: true },
            { data: 'scope_certificate_no', name: 'scope_certificate_no', orderable: true },
            { data: 'ref_operator_type', name: 'ref_operator_type', orderable: true },
            { data: 'date_of_registration', name: 'date_of_registration', orderable: true },
            { data: 'address1', name: 'address1', orderable: true },
            { data: 'mobile', name: 'mobile', orderable: true },
            { data: 'mand_type', name: 'mand_type', orderable: true },
            { data: 'profile_photo', name: 'profile_photo', orderable: true },
            { data: 'status', name: 'status', orderable: true }
        ],
        columnDefs: [{
            targets: [10],
            render: function(data, type, row, meta) {
                return type === 'display' ? $('<div />').html(data).text() : data;
            }
        }],
        paging: false,
        buttons: [
            'excelHtml5',
            {
                extend: 'csvHtml5',
                title: function() {
                    return "REPORTS";
                },
                titleAttr: 'CSV REPORTS'
            },
            {
                extend: 'pdfHtml5',
                title: function() {
                    return "PDF REPORTS";
                },
                orientation: 'landscape',   
                pageSize: 'A4',
                titleAttr: 'PDF REPORTS'
            }
        ],
        language: {
            emptyTable: "No Record found."
        }
    });

    $('#active_cbf, #operatorType').on('change', function() {
        table.draw();
    });
</script>
@endpush


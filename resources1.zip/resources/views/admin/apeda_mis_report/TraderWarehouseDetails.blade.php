@extends('admin.layouts.app')

@section('content')
    <style>
        .customtextarea {
            height: 80px;
        }
    </style> <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Trader Warehouse Details

                </h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Trader Warehouse Details
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div>

        <div class="row white-inner">

            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Name of Operator<span class="required"></span></label>
                   <input type="text" class="form-control" >
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">State<span class="required"></span></label>
                    <select class="form-select state" name="state" id="state" required>
                        <option value="">--Select--</option>
                        @forelse(getAllState() as $state)
                            <option value="{{ $state->id }}" @selected(old('state') == $state->id)>{{ $state->state_name }}
                            </option>
                        @empty
                        @endforelse



                    </select>
                </div>
            </div>

            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">CB<span class="required"></span></label>
                    <select class="form-select state" name="operatorType" id="operatorType" required>
                        <option value="">--Select--</option>
                        <option value="1">All</option>


                    </select>
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Contract  Type<span class="required"></span></label>
                    <select class="form-select state" name="operatorType" id="operatorType" required>
                        <option value="">--Select--</option>
                      
                    </select>
                </div>
            </div>

            <div class="col-xxl-1 col-md-4 gy-2">
                <div class="text-center">
                    <button type="submit" id="searchBtn" class="btn btn-primary" style="margin: 36px;">Search</button>
                </div>
            </div>




        </div>


    </div>

    <div>
        <div class="row">

            <div class="col-lg-12">
                <div class="card">

                    <div class="card-body table-responsive">
                        <p> List of Trader Warehouse
                        </p>
                        <table id="searchResultsTable" class="table table-bordered table-striped align-middle"
                            style="width:100%">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Certification Body</th>
                                    <th>Operator Registration No.</th>
                                    <th>Scope Certificate No.</th>
                                    <th>Scope Certificate No.</th>
                                    <th>Validity Start Date</th>
                                    <th>Validity End Date</th>
                                    <th>Contract Type</th>
                                    <th>Warehouse Name</th>
                                    <th>Address</th>
                                    <th>City</th>
                                    <th>State</th>
                                    <th>Pin</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="13">No Record found.</td>

                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!--end col-->
        </div>

        <script>

        </script>
    @endsection

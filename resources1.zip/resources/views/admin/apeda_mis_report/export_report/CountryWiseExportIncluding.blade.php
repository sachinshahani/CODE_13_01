@extends('admin.layouts.app')

@section('content')
    <style>
        .customtextarea {
            height: 80px;
        }
    </style> <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Country wise export Including exporter details, product and category
                </h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Country wise export Including exporter details, product and
                            category</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div>

        <div class="row white-inner">

            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">State<span class="required"></span></label>
                    <select class="form-select state" name="state" id="state" required>
                        <option value="">--Select--</option>
                        @forelse(getAllState() as $state)
                            <option value="{{ $state->id }}" @selected(old('state') == $state->id)>{{ $state->state_name }}
                            </option>
                        @empty
                        @endforelse



                    </select>
                </div>
            </div>
            {{-- <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">CB<span class="required"></span></label>
                    <select class="form-select state" name="state" id="state" required>
                        <option value="">--Select--</option>

                        <option value="1">All</option>




                    </select>
                </div>
            </div> --}}
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Operator<span class="required"></span></label>
                    <select class="form-select" name="operator" id="operator">
                        <option value="">--Select--</option>
                        <option value="1">IP</option>
                        <option value="2">Wild Harvest</option>
                        <option value="3">Trader</option>
                        <option value="6">Processor</option>
                        <option value="2">ICS</option>
                    </select>
                </div>
            </div>
            {{-- <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Country<span class="required"></span></label>
                    <select class="form-select state" name="state" id="state" required>
                        <option value="">--Select--</option>

                        <option value="1">All</option>

                    </select>
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Category<span class="required"></span></label>
                    <select class="form-select state" name="state" id="state" required>
                        <option value="">--Select--</option>

                        <option value="1">All</option>

                    </select>
                </div>
            </div> --}}


            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">From: <span class="required"></span></label>
                    <input type="date" class="form-control" name="from_date" id="from_date">
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">To: <span class="required"></span></label>
                    <input type="date" class="form-control" name="to_date" id="to_date">
                </div>
            </div>
        </div>
    </div>

    <div>
        <div class="row">

            <div class="col-lg-12">
                <div class="card">

                    <div class="card-body table-responsive">
                        <p>List Country wise export Including exporter</p>
                        <table id="searchResultsTable" class="table table-bordered table-striped align-middle"
                            style="width:100%">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Exporter Name</th>
                                    <th>Address</th>
                                    <th>Mobile No.</th>
                                    <th>Email ID</th>
                                    <th>Category</th>
                                    <th>Product Name</th>
                                    <th>HSCODE</th>
                                    <th>Operator Type</th>
                                    <th>Exported Qty (In MT)</th>
                                    <th>Total Value (In Lakh)</th>
                                    <th>Total Value (In Crore)</th>
                                    <th>Total Value (In USD Million)</th>




                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="14">No Record found.</td>

                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!--end col-->
        </div>
    @endsection
    @push('script')
        <script>
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var table = $('#searchResultsTable').DataTable({
                dom: 'Bfrtip',
                lengthMenu: [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
                processing: true,
                serverSide: true,
                ajax: {
                    url: '{{ route('superadmin.CountryWiseExportIncludingSearch') }}',
                    type: 'GET',
                    data: function(d) {
                        d.state = $('#state').val();
                        d.from_date = $('#from_date').val();
                        d.to_date = $('#to_date').val();
                        d.operator = $('#operator').val();
                    },
                    error: function(xhr, error, code) {
                        console.log(xhr.responseText); // This will print the error response
                    }
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: true
                    },
                    {
                        data: 'exporter',
                        name: 'exporter',
                        orderable: true
                    },
                    {
                        data: 'address',
                        name: 'address',
                        orderable: true
                    },

                    {
                        data: 'mobile_no',
                        name: 'mobile_no',
                        orderable: true
                    },
                    {
                        data: 'email',
                        name: 'email',
                        orderable: true
                    },
                    {
                        data: 'category',
                        name: 'category',
                        orderable: true
                    },
                    {
                        data: 'product_name',
                        name: 'product_name',
                        orderable: true
                    },
                    {
                        data: 'hscode',
                        name: 'hscode',
                        orderable: true
                    },
                    {
                        data: 'operator_type',
                        name: 'operator_type',
                        orderable: true
                    },

                    {
                        data: 'exported_qty',
                        name: 'exported_qty',
                        orderable: true
                    },
                    {
                        data: 'total_value_in_lakh',
                        name: 'total_value_in_lakh',
                        orderable: true
                    },
                    {
                        data: 'total_value_in_crore',
                        name: 'total_value_in_crore',
                        orderable: true
                    },
                    {
                        data: 'total_value_in_usd',
                        name: 'total_value_in_usd',
                        orderable: true
                    },
                ],
                paging: false,
                buttons: [
                    'excelHtml5',
                    {
                        extend: 'csvHtml5',
                        title: function() {
                            return "REPORTS";
                        },
                        titleAttr: 'CSV REPORTS'
                    },
                    {
                        extend: 'pdfHtml5',
                        title: function() {
                            return "PDF REPORTS";
                        },
                        orientation: 'landscape',
                        pageSize: 'A4',
                        titleAttr: 'PDF REPORTS'
                    }
                ],
                language: {
                    emptyTable: "No Record found."
                }
            });

            $('#state, #from_date, #to_date, #operator').change(function() {
                table.draw();
            });
        </script>
    @endpush

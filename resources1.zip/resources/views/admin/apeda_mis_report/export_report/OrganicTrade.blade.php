@extends('admin.layouts.app')

@section('content')
    <style>
        .customtextarea {
            height: 80px;
        }
    </style> <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Organic Trade
                </h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Organic Trade</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div>

        <div class="row white-inner">


            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">TC Type<span class="required"></span></label>
                    <select class="form-select state" name="state" id="state" required>
                        <option value="">--Select--</option>

                        <option value="1">TC</option>
                        <option value="2">PTC</option>




                    </select>
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">View<span class="required"></span></label>
                    <select class="form-select state" name="state" id="state" required>
                        <option value="">--Select--</option>

                        <option value="1">Top 10</option>
                        <option value="2">Top 20</option>
                        <option value="3">Top 50</option>
                        <option value="4">Top 100</option>

                    </select>
                </div>
            </div>

            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">From: <span class="required"></span></label>
                    <input type="date" class="form-control">
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">To: <span class="required"></span></label>
                    <input type="date" class="form-control">
                </div>
            </div>

            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Financial Year<span class="required"></span></label>
                    <select class="form-select state" name="state" id="state" required>
                        <option value="">--Select--</option>

                        <option value="1">2022-23</option>
                        <option value="2">2023-24</option>




                    </select>
                </div>
            </div>

        </div>


    </div>

    <div>
        <div class="row">

            <div class="col-lg-12">
                <div class="card">

                    <div class="card-body table-responsive">
                        <p>List of Organic Trade</p>
                        <table id="searchResultsTable" class="table table-bordered table-striped align-middle"
                            style="width:100%">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>TC Application No.</th>
                                    <th>Transaction Certificate No.</th>
                                    <th>Date of Application.</th>
                                    <th>TC Date.</th>
                                    <th>TC Type (Domestic/ PTC/ Export TC).</th>
                                    <th>Organic Status.</th>
                                    <th>Certification Body Name.</th>
                                    <th>Seller Name.</th>
                                    <th>Seller Registration No.</th>
                                    <th>Buyer Name.</th>
                                    <th>Buyer Registration No.</th>
                                    <th>Country.</th>
                                    <th>Category.</th>
                                    <th>Name Of Product.</th>
                                    <th>Quantity(In MT).</th>
                                    <th>Value(In RS).</th>
                                    <th>Action (View PDF).</th>




                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="18">No Record found.</td>

                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!--end col-->
        </div>
    @endsection
    @push('script')
        <script>
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

           

            var table = $('#searchResultsTable').DataTable({
                dom: 'Bfrtip',
                lengthMenu: [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
                processing: true,
                serverSide: true,
                paging: true,
                ajax: {
                    url: '{{ route('superadmin.OrganicTradeSearch') }}',
                    type: 'GET',
                    data: function(d) {
                        d.financial = $('#financial').val();
                        d.country = $('#country').val();
                        d.product = $('#product').val();

                    },
                    error: function(xhr, error, code) {
                        console.log(xhr.responseText); // This will print the error response
                    }
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: true
                    },

                    {
                        data: 'tc_Application',
                        name: 'tc_Application',
                        orderable: true
                    },
                    {
                        data: 'tc_no',
                        name: 'tc_no',
                        orderable: true
                    },
                    {
                        data: 'date',
                        name: 'date',
                        orderable: true
                    },
                    {
                        data: 'tc_date',
                        name: 'tc_date',
                        orderable: true
                    },
                    {
                        data: 'tc_type',
                        name: 'tc_type',
                        orderable: true
                    },
                    {
                        data: 'organic_status',
                        name: 'organic_status',
                        orderable: true
                    },
                    {
                        data: 'cb_name',
                        name: 'cb_name',
                        orderable: true
                    },
                    {
                        data: 'seller_name',
                        name: 'seller_name',
                        orderable: true
                    },
                    {
                        data: 'seller_reg_no',
                        name: 'seller_reg_no',
                        orderable: true
                    },
                    {
                        data: 'buyer_name',
                        name: 'buyer_name',
                        orderable: true
                    },
                    {
                        data: 'buyer_reg_no',
                        name: 'buyer_reg_no',
                        orderable: true
                    },
                    {
                        data: 'country',
                        name: 'country',
                        orderable: true
                    },
                    {
                        data: 'category',
                        name: 'category',
                        orderable: true
                    },
                    {
                        data: 'product',
                        name: 'product',
                        orderable: true
                    },
                    {
                        data: 'quantity',
                        name: 'quantity',
                        orderable: true
                    },
                    {
                        data: 'value',
                        name: 'value',
                        orderable: true
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: true
                    },

                ],
                paging: false,
                buttons: [
                    'excelHtml5',
                    {
                        extend: 'csvHtml5',
                        title: function() {
                            return "REPORTS";
                        },
                        titleAttr: 'CSV REPORTS'
                    },
                    {
                        extend: 'pdfHtml5',
                        title: function() {
                            return "PDF REPORTS";
                        },
                        orientation: 'landscape',
                        pageSize: 'A4',
                        titleAttr: 'PDF REPORTS'
                    }
                ],
                language: {
                    emptyTable: "No Record found."
                }
            });

            $('#financial, #country, #product').change(function() {
                table.draw();
            });
        </script>
    @endpush

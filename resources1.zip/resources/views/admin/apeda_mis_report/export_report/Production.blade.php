@extends('admin.layouts.app')

@section('content')
    <style>
        .customtextarea {
            height: 80px;
        }
    </style> <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0"> Production
                </h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Production</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div>

        <div class="row white-inner">

            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">State<span class="required"></span></label>
                    <select class="form-select state" name="state" id="state" required>
                        <option value="">Select State</option>
                        @forelse(getAllState() as $state)
                            <option value="{{ $state->id }}" @selected(old('state') == $state->id)>{{ $state->state_name }}
                            </option>
                        @empty
                        @endforelse
                    </select>

                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">District<span class="required"></span></label>
                    <select class="form-select district" name="dist" id="dist" required>
                        @forelse(getDistrictByStateID(old('state')) as $district)
                            <option value="{{ $district->id }}" @selected(old('district') == $district->id)>
                                {{ $district->district_name }}
                            </option>
                        @empty
                            <option value="">-Select District-</option>
                        @endforelse


                    </select>
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Category<span class="required"></span></label>
                    <select class="form-select state" name="category" id="category" required>
                        <option value="">--Select--</option>

                        @forelse(getAllCategory() as $category)
                            <option value="{{ $category->id }}" @selected(old('category') == $category->id)>{{ $category->category_name }}
                            </option>
                        @empty
                        @endforelse

                    </select>
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Product<span class="required"></span></label>
                    <select class="form-select state" name="product" id="product" required>
                        <option value="">--Select--</option>

                        @forelse(getAllProduct() as $product)
                            <option value="{{ $product->id }}" @selected(old('product') == $product->id)>{{ $product->product_name }}
                            </option>
                        @empty
                        @endforelse

                    </select>
                </div>
            </div>
            {{-- <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">CB<span class="required"></span></label>
                    <select class="form-select state" name="state" id="state" required>
                        <option value="">--Select--</option>

                        <option value="1">ALL</option>

                    </select>
                </div>
            </div> --}}
        </div>


    </div>

    <div>
        <div class="row">

            <div class="col-lg-12">
                <div class="card">

                    <div class="card-body table-responsive">
                        <p>List of Production</p>
                        <table id="searchResultsTable" class="table table-bordered table-striped align-middle"
                            style="width:100%">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>State Name.</th>
                                    <th>Product name.</th>
                                    <th>Organic Production (In MT).</th>
                                    <th>Conversion Production(In MT).</th>
                                    <th>Total Production (MT).</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="6">No Record found.</td>

                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!--end col-->
        </div>
    @endsection
    @push('script')
        <script>
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var table = $('#searchResultsTable').DataTable({
                dom: 'Bfrtip',
                lengthMenu: [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
                processing: true,
                serverSide: true,
                ajax: {
                    url: '{{ route('superadmin.ProductionSearch') }}',
                    type: 'GET',
                    data: function(d) {
                        d.state = $('#state').val();
                        d.dist = $('#dist').val();
                        d.category = $('#category').val();
                        d.product = $('#product').val();

                    },
                    error: function(xhr, error, code) {
                        console.log(xhr.responseText); // This will print the error response
                    }
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: true
                    },
                    {
                        data: 'state',
                        name: 'state',
                        orderable: true
                    },
                    {
                        data: 'product_name',
                        name: 'product_name',
                        orderable: true
                    },
                    {
                        data: 'organic_production',
                        name: 'organic_production',
                        orderable: true
                    },
                    {
                        data: 'conversion_production',
                        name: 'conversion_production',
                        orderable: true
                    },
                    {
                        data: 'total_production',
                        name: 'total_production',
                        orderable: true
                    },

                ],
                paging: false,
                buttons: [
                    'excelHtml5',
                    {
                        extend: 'csvHtml5',
                        title: function() {
                            return "REPORTS";
                        },
                        titleAttr: 'CSV REPORTS'
                    },
                    {
                        extend: 'pdfHtml5',
                        title: function() {
                            return "PDF REPORTS";
                        },
                        orientation: 'landscape',
                        pageSize: 'A4',
                        titleAttr: 'PDF REPORTS'
                    }
                ],
                language: {
                    emptyTable: "No Record found."
                }
            });

            $('#state, #dist, #category, #product').change(function() {
                table.draw();
            });
        </script>
    @endpush

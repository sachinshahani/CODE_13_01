@extends('admin.layouts.app')

@section('content')
    <style>
        .customtextarea {
            height: 80px;
        }
    </style> <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Monthly Comparative Statement
                </h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Monthly Comparative Statement</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div>





        <div class="row white-inner">

            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Financial Year<span class="required"></span></label>
                    <select class="form-select state" name="financial" id="financial" required>
                        <option value="">--Select--</option>
                        {{-- @forelse ($financialYears as $fy)
                            <option value="{{ $fy }}" {{ $fy == $financialYear ? 'selected' : '' }}>
                                {{ $fy }}
                            </option>
                        @empty
                            <option value="" disabled>No financial years available</option>
                        @endforelse --}}
                    </select>
                </div>
            </div>

            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Country<span class="required"></span></label>
                    <select class="form-select state" name="country" id="country" required>
                        <option value="">--Select--</option>

                        @forelse(getRefCountryMaster() as $country)
                            <option value="{{ $country->id }}" @selected(old('country') == $country->id)>{{ $country->country_name }}
                            </option>
                        @empty
                        @endforelse

                    </select>
                </div>
            </div>


        </div>


    </div>

    <div>
        <div class="row">

            <div class="col-lg-12">
                <div class="card">

                    <div class="card-body table-responsive">
                        <p>List of Monthly Comparative Statement</p>
                        <table id="searchResultsTable" class="table table-bordered table-striped align-middle"
                            style="width:100%">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Month</th>
                                    <th>Quantity (in MT)</th>
                                    <th>Value (In Lakh)</th>
                                    <th>Value (In Crore)</th>
                                    <th>Value (In USD Million)</th>
                                    <th>% Growth (Quantity)</th>
                                    <th>% Growth (Value) USD</th>


                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="8">No Record found.</td>

                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!--end col-->
        </div>
    @endsection
    @push('script')
        <script>
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var table = $('#searchResultsTable').DataTable({
                dom: 'Bfrtip',
                lengthMenu: [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
                processing: true,
                serverSide: true,
                ajax: {
                    url: '{{ route('superadmin.MonthlyComparativeStatementSearch') }}',
                    type: 'GET',
                    data: function(d) {
                        d.financial = $('#financial').val();
                        d.country = $('#country').val();

                    },
                    error: function(xhr, error, code) {
                        console.log(xhr.responseText); // This will print the error response
                    }
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: true
                    },

                    {
                        data: 'month',
                        name: 'month',
                        orderable: true
                    },
                    {
                        data: 'exported_qty',
                        name: 'exported_qty',
                        orderable: true
                    },
                    {
                        data: 'total_value_in_lakh',
                        name: 'total_value_in_lakh',
                        orderable: true
                    },
                    {
                        data: 'total_value_in_crore',
                        name: 'total_value_in_crore',
                        orderable: true
                    },
                    {
                        data: 'total_value_in_usd',
                        name: 'total_value_in_usd',
                        orderable: true
                    },
                    {
                        data: 'Growth_Quantity',
                        name: 'Growth_Quantity',
                        orderable: true
                    },
                    {
                        data: 'Growth_Value',
                        name: 'Growth_Value',
                        orderable: true
                    },
                ],
                paging: false,
                buttons: [
                    'excelHtml5',
                    {
                        extend: 'csvHtml5',
                        title: function() {
                            return "REPORTS";
                        },
                        titleAttr: 'CSV REPORTS'
                    },
                    {
                        extend: 'pdfHtml5',
                        title: function() {
                            return "PDF REPORTS";
                        },
                        orientation: 'landscape',
                        pageSize: 'A4',
                        titleAttr: 'PDF REPORTS'
                    }
                ],
                language: {
                    emptyTable: "No Record found."
                }
            });

            $('#financial, #country').change(function() {
                table.draw();
            });
        </script>
    @endpush

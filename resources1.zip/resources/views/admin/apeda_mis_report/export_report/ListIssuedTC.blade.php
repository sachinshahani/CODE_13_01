@extends('admin.layouts.app')

@section('content')
    <style>
        .customtextarea {
            height: 80px;
        }
    </style> <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Issued TCs
                </h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Issued TCs</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div>

        <div class="row white-inner">


            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">TC Type<span class="required"></span></label>
                    <select class="form-select state" name="tc_application_no" id="tc_application_no" >
                        <option value="">--Select--</option>

                        <option value="TC" >TC</option>
                        <option value="PTC" >PTC</option>

                    </select>
                </div>
            </div>
            {{-- <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">View<span class="required"></span></label>
                    <select class="form-select state" name="state" id="state" required>
                        <option value="">--Select--</option>

                        <option value="1" >Top 10</option>
                        <option value="2" >Top 20</option>
                        <option value="3" >Top 50</option>
                        <option value="4" >Top 100</option>

                    </select>
                </div>
            </div> --}}

            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">From: <span class="required"></span></label>
                    <input type="date" class="form-control" name="from_date" id="from_date">
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">To: <span class="required"></span></label>
                    <input type="date" class="form-control" name="to_date" id="to_date">
                </div>
            </div>

            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Financial Year<span class="required"></span></label>
                    <select class="form-select state" name="financial" id="financial" required>
                        <option value="">--Select--</option>

                        <option value="247" >2022-23</option>
                        <option value="299" >2023-24</option>

                    </select>
                </div>
            </div>

        </div>

    </div>

    <div>
        <div class="row">

            <div class="col-lg-12">
                <div class="card">

                    <div class="card-body table-responsive">
                        <p>List Issued TCs</p>
                        <table id="searchResultsTable" class="table table-bordered table-striped align-middle"
                            style="width:100%">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Application No.</th>
                                    <th>Certificate No.</th>
                                    <th>TC Issued On.</th>
                                    <th>TC Date</th>
                                    <th>Application Type</th>
                                    <th>Certification Body Name.</th>
                                    <th>Seller Name.</th>
                                    <th>Buyer</th>
                                    <th>State</th>

                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="12">No Record found.</td>

                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!--end col-->
        </div>
    @endsection
    @push('script')
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        var table = $('#searchResultsTable').DataTable({
            dom: 'Bfrtip',
            lengthMenu: [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
            ],
            processing: true,
            serverSide: true,
            ajax: {
                url: '{{ route('superadmin.ListIssuedTCSearch') }}',
                type: 'GET',
                data: function(d) {
                    d.financial = $('#financial').val();
                    d.from_date = $('#from_date').val();
                    d.to_date = $('#to_date').val();
                    d.tc_application_no = $('#tc_application_no').val();

                },
                error: function(xhr, error, code) {
                    console.log(xhr.responseText); // This will print the error response
                }
            },
            columns: [{
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex',
                    orderable: true
                },
                {
                    data: 'tc_application',
                    name: 'tc_application',
                    orderable: true
                },
                {
                    data: 'tc_no',
                    name: 'tc_no',
                    orderable: true
                },
                {
                    data: 'tc_issue_date',
                    name: 'tc_issue_date',
                    orderable: true
                },
                {
                    data: 'tc_date',
                    name: 'tc_date',
                    orderable: true
                },
                {
                    data: 'tc_type',
                    name: 'tc_type',
                    orderable: true
                },
                {
                    data: 'cb_name',
                    name: 'cb_name',
                    orderable: true
                },
                {
                    data: 'seller_name',
                    name: 'seller_name',
                    orderable: true
                },
                {
                    data: 'buyer_name',
                    name: 'buyer_name',
                    orderable: true
                },
                {
                    data: 'state',
                    name: 'state',
                    orderable: true
                },

            ],
            paging: false,
            buttons: [
                'excelHtml5',
                {
                    extend: 'csvHtml5',
                    title: function() {
                        return "REPORTS";
                    },
                    titleAttr: 'CSV REPORTS'
                },
                {
                    extend: 'pdfHtml5',
                    title: function() {
                        return "PDF REPORTS";
                    },
                    orientation: 'landscape',
                    pageSize: 'A4',
                    titleAttr: 'PDF REPORTS'
                }
            ],
            language: {
                emptyTable: "No Record found."
            }
        });

        $('#tc_application_no, #from_date, #to_date, #financial').change(function() {
            table.draw();
        });
    </script>
@endpush


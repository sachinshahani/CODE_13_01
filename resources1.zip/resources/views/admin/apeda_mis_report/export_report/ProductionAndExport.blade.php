@extends('admin.layouts.app')

@section('content')
    <style>
        .customtextarea {
            height: 80px;
        }
    </style> <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0"> Production and Export
                </h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active"> Production and Export</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div>

        <div class="row white-inner">

            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">State<span class="required"></span></label>
                    <select class="form-select state" name="state" id="state" required>
                        <option value="">--Select--</option>
                        @forelse(getAllState() as $state)
                            <option value="{{ $state->id }}" @selected(old('state') == $state->id)>{{ $state->state_name }}
                            </option>
                        @empty
                        @endforelse



                    </select>
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Product<span class="required"></span></label>
                    <select class="form-select state" name="product" id="product" required>
                        <option value="">--Select--</option>

                        @forelse(getAllProduct() as $product)
                            <option value="{{ $product->id }}" @selected(old('product') == $product->id)>{{ $product->product_name }}
                            </option>
                        @empty
                        @endforelse

                    </select>
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Country<span class="required"></span></label>
                    <select class="form-select state" name="country" id="country" required>
                        <option value="">--Select--</option>

                        @forelse(getRefCountryMaster() as $country)
                            <option value="{{ $country->id }}" @selected(old('country') == $country->id)>{{ $country->country_name }}
                            </option>
                        @empty
                        @endforelse

                    </select>
                </div>
            </div>

            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Category<span class="required"></span></label>
                    <select class="form-select state" name="category" id="category" required>
                        <option value="">--Select--</option>

                        @forelse(getAllCategory() as $category)
                            <option value="{{ $category->id }}" @selected(old('category') == $category->id)>{{ $category->category_name }}
                            </option>
                        @empty
                        @endforelse

                    </select>
                </div>
            </div>
            {{-- <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">CB<span class="required"></span></label>
                    <select class="form-select state" name="state" id="state" required>
                        <option value="">--Select--</option>

                        <option value="1">ALL</option>

                    </select>
                </div>
            </div> --}}

        </div>

    </div>

    <div>
        <div class="row">

            <div class="col-lg-12">
                <div class="card">

                    <div class="card-body table-responsive">
                        <p>List Production and Export 2 years 3 years and 5 years Trend (graphs) for Area</p>
                        <table id="searchResultsTable" class="table table-bordered table-striped align-middle"
                            style="width:100%">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>State.</th>
                                    <th>CB.</th>
                                    <th>Country.</th>
                                    <th>Category.</th>
                                    <th>Product name.</th>
                                    <th>HS Code.</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="7">No Record found.</td>

                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!--end col-->
        </div>
    @endsection
    @push('script')
        <script>
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var table = $('#searchResultsTable').DataTable({
                dom: 'Bfrtip',
                lengthMenu: [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
                processing: true,
                serverSide: true,
                ajax: {
                    url: '{{ route('superadmin.ProductionAndExportSearch') }}',
                    type: 'GET',
                    data: function(d) {
                        d.state = $('#state').val();
                        d.country = $('#country').val();
                        d.category = $('#category').val();
                        d.product = $('#product').val();
                    },
                    error: function(xhr, error, code) {
                        console.log(xhr.responseText); // This will print the error response
                    }
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: true
                    },
                    {
                        data: 'state',
                        name: 'state',
                        orderable: true
                    },
                    {
                        data: 'cb_name',
                        name: 'cb_name',
                        orderable: true
                    },
                    {
                        data: 'country',
                        name: 'country',
                        orderable: true
                    },
                    {
                        data: 'category',
                        name: 'category',
                        orderable: true
                    },
                    {
                        data: 'product_name',
                        name: 'product_name',
                        orderable: true
                    },
                    {
                        data: 'hs_code',
                        name: 'hs_code',
                        orderable: true
                    },
                ],
                paging: false,
                buttons: [
                    'excelHtml5',
                    {
                        extend: 'csvHtml5',
                        title: function() {
                            return "REPORTS";
                        },
                        titleAttr: 'CSV REPORTS'
                    },
                    {
                        extend: 'pdfHtml5',
                        title: function() {
                            return "PDF REPORTS";
                        },
                        orientation: 'landscape',
                        pageSize: 'A4',
                        titleAttr: 'PDF REPORTS'
                    }
                ],
                language: {
                    emptyTable: "No Record found."
                }
            });

            $('#state, #country, #category, #product').change(function() {
                table.draw();
            });
        </script>
    @endpush

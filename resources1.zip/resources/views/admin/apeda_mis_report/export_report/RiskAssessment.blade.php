@extends('admin.layouts.app')

@section('content')
    <style>
        .customtextarea {
            height: 80px;
        }
    </style> <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Risk Assessment of operators
                </h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Risk Assessment of operators</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div>

        <div class="row white-inner">

            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">CB<span class="required"></span></label>
                    <select class="form-select" name="cbname" id="cbname" required>
                        <option value="">--ALL--</option>


                        @forelse(getCBNamesById() as $cbName)
                            <option value="{{ $cbName->id }}" @selected(old('cbName') == $cbName->id)>{{ $cbName->first_name }}
                            </option>
                        @empty
                        @endforelse


                    </select>
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Operator Type<span class="required"></span></label>
                    <select class="form-select" name="operator" id="operator">
                        <option value="">--Select--</option>
                        <option value="2">ICS</option>
                        <option value="3">IP</option>
                        <option value="5">Trader</option>
                        <option value="6">Processor</option>
                        <option value="4">Wild Harvest</option>
                    </select>
                </div>
            </div>
        </div>
    </div>

    <div>
        <div class="row">

            <div class="col-lg-12">
                <div class="card">

                    <div class="card-body table-responsive">
                        <p>List of Risk Assessment of operators </p>
                        <table id="searchResultsTable" class="table table-bordered table-striped align-middle"
                            style="width:100%">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>State Name</th>
                                    <th>Operator Registration No</th>
                                    <th>Scope Certificate No</th>
                                    <th>Operator Name</th>
                                    <th>Address</th>
                                    <th>Operator type</th>
                                    <th>Change In Production Plan</th>
                                    <th>Contamination</th>
                                    <th>Degree Of Similarity</th>
                                    <th>Joining Of New Members</th>
                                    <th>Local Hazards</th>
                                    <th>Number Of Members</th>
                                    <th>Parallel Production</th>
                                    <th>Risk Type</th>
                                    <th>Size Of Holding</th>
                                    <th>Split Production</th>

                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="18">No Record found.</td>

                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!--end col-->
        </div>
    @endsection
    @push('script')
        <script>
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var table = $('#searchResultsTable').DataTable({
                dom: 'Bfrtip',
                lengthMenu: [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
                processing: true,
                serverSide: true,
                ajax: {
                    url: '{{ route('superadmin.RiskAssessmentSearch') }}',
                    type: 'GET',
                    data: function(d) {
                        d.operator = $('#operator').val();
                        d.cbname = $('#cbname').val();



                    },

                    error: function(xhr, error, code) {
                        console.log(xhr.responseText); // This will print the error response
                    }
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: true
                    },

                    {
                        data: 'state_name',
                        name: 'state_name',
                        orderable: true
                    },
                    {
                        data: 'operator_reg',
                        name: 'operator_reg',
                        orderable: true
                    },
                    {
                        data: 'scope_no',
                        name: 'scope_no',
                        orderable: true
                    },
                    {
                        data: 'operator_name',
                        name: 'operator_name',
                        orderable: true
                    },
                    {
                        data: 'address',
                        name: 'address',
                        orderable: true
                    },
                    {
                        data: 'operator_type',
                        name: 'operator_type',
                        orderable: true
                    },
                    {
                        data: 'plan',
                        name: 'plan',
                        orderable: true
                    },
                    {
                        data: 'contamination',
                        name: 'contamination',
                        orderable: true
                    },
                    {
                        data: 'Degree_Of_Similarity',
                        name: 'Degree_Of_Similarity',
                        orderable: true
                    },
                    {
                        data: 'Joining_Of_New_Members',
                        name: 'Joining_Of_New_Members',
                        orderable: true
                    },
                    {
                        data: 'Local_Hazards',
                        name: 'Local_Hazards',
                        orderable: true
                    },

                    {
                        data: 'Number_Of_Members',
                        name: 'Number_Of_Members',
                        orderable: true
                    },
                    {
                        data: 'Parallel_Production',
                        name: 'Parallel_Production',
                        orderable: true
                    },
                    {
                        data: 'Risk_Type',
                        name: 'Risk_Type',
                        orderable: true
                    },
                    {
                        data: 'Size_Of_Holding',
                        name: 'Size_Of_Holding',
                        orderable: true
                    },
                    {
                        data: 'Split_Production',
                        name: 'Split_Production',
                        orderable: true
                    },

                ],
                paging: false,
                buttons: [
                    'excelHtml5',
                    {
                        extend: 'csvHtml5',
                        title: function() {
                            return "REPORTS";
                        },
                        titleAttr: 'CSV REPORTS'
                    },
                    {
                        extend: 'pdfHtml5',
                        title: function() {
                            return "PDF REPORTS";
                        },
                        orientation: 'landscape',
                        pageSize: 'A4',
                        titleAttr: 'PDF REPORTS'
                    }
                ],
                language: {
                    emptyTable: "No Record found."
                }
            });

            $('#operator, #cbname').change(function() {
                table.draw();
            });
        </script>
    @endpush

@extends('admin.layouts.app')

@section('content')
    <style>
        .customtextarea {
            height: 80px;
        }
    </style> <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">External Inspction
                </h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">External Inspction</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div>

        <div class="row white-inner">

            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">CB<span class="required"></span></label>
                    <select class="form-select state" name="cbname" id="cbname" required>
                        <option value="">--Select--</option>
                        @forelse(getCBNamesById() as $cbName)
                            <option value="{{ $cbName->id }}" @selected(old('cbName') == $cbName->id)>{{ $cbName->first_name }}
                            </option>
                        @empty
                        @endforelse


                    </select>
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Operator Type<span class="required"></span></label>
                    <select class="form-select" name="operator" id="operator">
                        <option value="">--Select--</option>
                        <option value="2">ICS</option>
                        <option value="3">IP</option>
                        <option value="5">Trader</option>
                        <option value="6">Processor</option>
                        <option value="4">Wild Harvest</option>
                    </select>
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Inspection Type<span class="required"></span></label>
                    <select class="form-select state" name="Type" id="Type" required>
                        <option value="">--Select--</option>
                        <option value="false">Active</option>
                        <option value="true">Inactive</option>


                    </select>
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Financial Year<span class="required"></span></label>
                    <select class="form-select state" name="financial" id="financial" required>
                        <option value="">--Select--</option>
                        {{-- <option value="1">2018-19</option>
                        <option value="2">2019-20</option>
                        <option value="3">2020-21</option> --}}
                        <option value="4">2021-22</option>
                        <option value="1">2022-23</option>

                    </select>
                </div>
            </div>

            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">From: <span class="required"></span></label>
                    <input type="date" class="form-control" name="from_Date" id="from_Date">
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">To: <span class="required"></span></label>
                    <input type="date" class="form-control" name="to_Date" id="to_date">
                    <!-- Corrected ID to match JavaScript -->
                </div>
            </div>

        </div>
    </div>

    <div>
        <div class="row">

            <div class="col-lg-12">
                <div class="card">

                    <div class="card-body table-responsive">
                        <p>List of External Inspction </p>
                        <table id="searchResultsTable" class="table table-bordered table-striped align-middle"
                            style="width:100%">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    {{-- <th>CB Name</th> --}}
                                    <th>State Name</th>
                                    <th>Operator Registration No</th>
                                    <th>Scope Certificate No</th>
                                    <th>Operator Name</th>
                                    <th>Operator Type</th>
                                    <th>Address</th>
                                    {{-- <th>Inspection Type (renewal, additional and unannounced)</th> --}}
                                    <th>Inspector Name</th>
                                    <th>Date of Inpsection</th>
                                    <th>Description of NC</th>
                                    <th>NC Grade</th>
                                    <th>Date of NC closure</th>
                                    <th>Reason for Closure</th>

                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="14">No Record found.</td>

                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!--end col-->
        </div>
    @endsection
    @push('script')
        <script>
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var table = $('#searchResultsTable').DataTable({
                dom: 'Bfrtip',
                lengthMenu: [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
                processing: true,
                serverSide: true,
                ajax: {
                    url: '{{ route('superadmin.ExternalInspctionSearch') }}',
                    type: 'GET',
                    data: function(d) {
                        d.financial = $('#financial').val();
                        d.operator = $('#operator').val();
                        d.cbname = $('#cbname').val();
                        d.to_date = $('#to_date').val();
                        d.from_date = $('#from_Date').val();
                        d.Type = $('#Type').val();

                    },
                    error: function(xhr, error, code) {
                        console.log(xhr.responseText); // This will print the error response
                    }
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: true
                    },
                    // {
                    //     data: 'cb_name',
                    //     name: 'cb_name',
                    //     orderable: true
                    // },

                    {
                        data: 'state_name',
                        name: 'state_name',
                        orderable: true
                    },
                    {
                        data: 'operator_reg',
                        name: 'operator_reg',
                        orderable: true
                    },

                    {
                        data: 'scope_name',
                        name: 'scope_name',
                        orderable: true
                    },
                    {
                        data: 'operator_name',
                        name: 'operator_name',
                        orderable: true
                    },
                    {
                        data: 'operator_type',
                        name: 'operator_type',
                        orderable: true
                    },
                    {
                        data: 'address',
                        name: 'address',
                        orderable: true
                    },
                    // {
                    //     data: 'type',
                    //     name: 'type',
                    //     orderable: true
                    // },
                    {
                        data: 'inspector_name',
                        name: 'inspector_name',
                        orderable: true
                    },
                    {
                        data: 'date_of_inspection',
                        name: 'date_of_inspection',
                        orderable: true
                    },
                    {
                        data: 'description_of_nc',
                        name: 'description_of_nc',
                        orderable: true
                    },
                    {
                        data: 'nc_grade',
                        name: 'nc_grade',
                        orderable: true
                    },
                    {
                        data: 'date_of_closure',
                        name: 'date_of_closure',
                        orderable: true
                    },

                    {
                        data: 'remark',
                        name: 'remark',
                        orderable: true
                    },
                ],
                paging: false,
                buttons: [
                    'excelHtml5',
                    {
                        extend: 'csvHtml5',
                        title: function() {
                            return "REPORTS";
                        },
                        titleAttr: 'CSV REPORTS'
                    },
                    {
                        extend: 'pdfHtml5',
                        title: function() {
                            return "PDF REPORTS";
                        },
                        orientation: 'landscape',
                        pageSize: 'A4',
                        titleAttr: 'PDF REPORTS'
                    }
                ],
                language: {
                    emptyTable: "No Record found."
                }
            });

            $('#financial, #operator, #cbname, #from_Date, #to_date, #Type').change(function() {
                table.draw();
            });
        </script>
    @endpush

@extends('admin.layouts.app')

@section('content')
    <style>
        .customtextarea {
            height: 80px;
        }
    </style> <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Report On Operator NOC Details

                </h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Report On Operator NOC Details
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div>
        <div class="row white-inner">
        <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Operator Type: <span class="required"></span></label>
                    <select class="form-select state" name="operatorType" id="operatorType" required>
                        <option value="">--Select--</option>
                        <option value="2">Grower Group</option>
                        <option value="3">INDIVIDUAL PRODUCER</option>
                        <option value="4">WILD</option>
                        <option value="5">TRADER</option>
                        <option value="6">PROCESSOR</option>
                    </select>
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Registration No<span class="required"></span></label>
                   <input type="text"  name = "registration_no" id = "registration_no" class="form-control">
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
            <div>
                <label class="form-label">CB<span class="required"></span></label>
                <select class="form-select state" name="active_cbf" id="active_cbf" required>
                    <option value="">--Select--</option>
                    @php
                        $cbNames = getCBNamesById(1);
                    @endphp
                    @foreach($cbNames as $id => $cbName)
                        <option value="{{ $id }}">{{ $cbName }}</option>
                    @endforeach
                </select>
            </div>
        </div>
        <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">From: <span class="required"></span></label>
                    <input type="date" class="form-control" name="from_date" id="from_date">
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">To: <span class="required"></span></label>
                    <input type="date" class="form-control" name="updated_at" id="to_date">
                </div>
            </div>
          {{--  <div class="col-xxl-1 col-md-4 gy-2">
                <div class="text-center">
                    <button type="submit" id="searchBtn" class="btn btn-primary" style="margin: 36px;">Search</button>
                </div>
            </div>--}}
        </div>
    </div>
    <div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body table-responsive">
                        <p> List of Operator NOC Details
                        </p>
                        <table id="searchResultsTable" class="table table-bordered table-striped align-middle"
                            style="width:100%">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>NOC Application No.</th>
                                   {{-- <th>Certification Body Name</th>--}}
                                    <th>Operator Name</th>
                                    <th>Name of Certification Body</th>
                                    <th>Operator Type</th>
                                    <th>Registration No.</th>
                                    <th>Scope Certificate No.</th>
                                    <th>Applied On</th>
                                    <th>Approved On</th>
                                    <th>NOC Status</th>
                                    <th>Registered On</th>
                                    <th>New CB</th>
                                    <th>New Registration No.</th>
                                    <th>New Scope Certificate</th>
                                    <th>Validity Start Date</th>
                                    <th>Validity End Date</th>
                                    <th>New Company Name</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="18">No Record found.</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!--end col-->
        </div>
    @endsection
    @push('script')
    <script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    var table = $('#searchResultsTable').DataTable({
        dom: 'Bfrtip',
        lengthMenu: [
            [10, 25, 50, -1],
            [10, 25, 50, "All"]
        ],
        processing: true,
        serverSide: true,
        ajax: {
            url: '{{ route('superadmin.report-on-operator-noc') }}',
            type: 'GET',
            data: function(d) {
                d.operatorType = $('#operatorType').val();
                d.registration_no = $('#registration_no').val();
                d.active_cbf = $('#active_cbf').val();
                d.from_date = $('#from_date').val();
                d.to_date = $('#to_date').val();
            },
            error: function(xhr, error, code) {
                console.log(xhr.responseText); 
            }
        },
        columns: [
            { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: true },
            { data: 'noc_application_no', name: 'noc_application_no', orderable: true },
            { data: 'ref_operator_type_id', name: 'ref_operator_type_id', orderable: true },
            { data: 'registration_no', name: 'registration_no', orderable: true },
            { data: 'ref_operator_type_id', name: 'ref_operator_type_id', orderable: true },
            { data: 'registration_no', name: 'registration_no', orderable: true },
            { data: 'scope_certificate_no', name: 'scope_certificate_no', orderable: true },

            
            { data: 'applied_on', name: 'applied_on', orderable: true },
            { data: 'approved_on', name: 'approved_on', orderable: true },
            { data: 'noc_status', name: 'noc_status', orderable: true },
            { data: 'created_at', name: 'created_at', orderable: true },
        ],
        paging: false,
        buttons: [
            'excelHtml5',
            {
                extend: 'csvHtml5',
                title: function() {
                    return "REPORTS";
                },
                titleAttr: 'CSV REPORTS'
            },
            {
                extend: 'pdfHtml5',
                title: function() {
                    return "PDF REPORTS";
                },
                orientation: 'landscape',
                pageSize: 'A4',
                titleAttr: 'PDF REPORTS'
            }
        ],
        language: {
            emptyTable: "No Record found."
        }
    });

    $('#operatorType, #registration_no, #active_cbf, #from_date, #to_date').on('change', function() {
        table.draw();
    });
</script>

@endpush


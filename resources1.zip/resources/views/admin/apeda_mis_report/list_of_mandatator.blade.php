@extends('admin.layouts.app')

@section('content')
    <style>
        .customtextarea {
            height: 80px;
        }
    </style> <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Report On List of Mandatator(s)
                </h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Report On List of Mandatator(s)</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div>

        <div class="row white-inner">

            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">State<span class="required"></span></label>
                    <select class="form-select state" name="state" id="state" required>
                        <option value="" name="state_name">--Select--</option>
                        @forelse(getAllState() as $state)
                            <option value="{{ $state->id }}" @selected(old('state') == $state->id)>{{ $state->state_name }}
                            </option>
                        @empty
                        @endforelse
                    </select>
                </div>
            </div>


            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Status of Mandator<span class="required"></span></label>
                    <select class="form-select state" name="operatorType" id="operatorType" required>
                        <option value="">--Select--</option>
                        <option value="1">All</option>
                        <option value="2">Registered</option>
                        <option value="3">Active</option>
                        <option value="4">Expired</option>
                        <option value="5">Discontinued</option>
                        <option value="6"> De-regsitered</option>

                    </select>
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">CB<span class="required"></span></label>
                    <select class="form-select state" name="operatorType" id="operatorType" required>
                        <option value="">--Select--</option>
                        <option value="1">All</option>
                    </select>
                </div>
            </div>




         {{--  <div class="col-xxl-1 col-md-4 gy-2">
                <div class="text-center">
                    <button type="submit" id="searchBtn" class="btn btn-primary" style="margin: 36px;">Search</button>
                </div>
            </div>--}}




        </div>


    </div>

    <div>
        <div class="row">

            <div class="col-lg-12">
                <div class="card">

                    <div class="card-body table-responsive">
                        <p> List of Mandatator(s)</p>
                        <table id="searchResultsTable" class="table table-bordered table-striped align-middle"
                            style="width:100%">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>CB name</th>
                                    <th>Mandator Name</th>
                                    <th>Registration No.</th>
                                    <th>Address</th>
                                    <th>Operator Type</th>
                                    <th>State Name</th>
                                    <th>Mobile No</th>
                                    <th>Email ID</th>
                                    <th>Name of grower Groups managed by the mandator</th>
                                    <th>Scope No. of oeprators</th>
                                    <th>View Proof (Agreement)</th>



                                </tr>
                            </thead>
                            <tbody>
                                <!-- Data will be inserted here by DataTables -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!--end col-->
        </div>

        <script>

        </script>
    @endsection
    @push('script')
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    var table = $('#searchResultsTable').DataTable({
    dom: 'Bfrtip',
    lengthMenu: [
        [10, 25, 50, -1],
        [10, 25, 50, "All"]
    ],
    processing: true,
    serverSide: true,
    ajax: {
        url: '{{ route('superadmin.report-on-mandator-list') }}',
        type: 'GET',
        data: function(d) {
            d.state = $('#state').val();
            // Add additional parameters for filtering if needed
        },
        error: function(xhr, error, code) {
            console.error(xhr.responseText); // Log error response for debugging
        }
    },
    columns: [
        { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: true },
        { data: 'cb_name', name: 'cb_name', orderable: true },
        { data: 'mandator_name', name: 'mandator_name', orderable: true },
        { data: 'registration_no', name: 'registration_no', orderable: true },
        { data: 'address', name: 'address', orderable: true },
        { data: 'operator_type', name: 'operator_type', orderable: true },
        { data: 'state_id', name: 'state_id', orderable: true },
        { data: 'mobile', name: 'mobile', orderable: true },
        { data: 'email', name: 'email', orderable: true },
        { data: 'grower_grp_name', name: 'grower_grp_name', orderable: true },
        { data: 'scope_no_of_operators', name: 'scope_no_of_operators', orderable: true }, 
        { data: 'id_proof', name: 'id_proof', orderable: true },
    ],
    paging: false,
    buttons: [
        'excelHtml5',
        {
            extend: 'csvHtml5',
            title: function() {
                return "REPORTS";
            },
            titleAttr: 'CSV REPORTS'
        },
        {
            extend: 'pdfHtml5',
            title: function() {
                return "PDF REPORTS";
            },
            orientation: 'landscape',   
            pageSize: 'A4',
            titleAttr: 'PDF REPORTS'
        }
    ],
    columnDefs: [{
        targets: [11],
        render: function(data, type, row, meta) {
            return type === 'display' ? $('<div />').html(data).text() : data;
        }
    }],
    language: {
        emptyTable: "No Record found."
    }
});

$('#state, #from_date, #to_date').on('change', function() {
    table.draw();
});

</script>
@endpush
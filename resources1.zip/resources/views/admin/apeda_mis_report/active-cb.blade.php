@extends('admin.layouts.app')

@section('content')
    <style>
        .customtextarea {
            height: 80px;
        }
    </style> <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">State Wise Active CB</h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">State Wise Active CB</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div>
        <div class="row white-inner">
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">State<span class="required"></span></label>
                    <select class="form-select state" name="state" id="state" required>
                        <option value="" name="state_name">--Select--</option>
                        @forelse(getAllState() as $state)
                            <option value="{{ $state->id }}" @selected(old('state') == $state->id)>{{ $state->state_name }}</option>
                        @empty
                        @endforelse
                    </select>
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">From: <span class="required"></span></label>
                    <input type="date" class="form-control" name="from_date" id="from_date">
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">To: <span class="required"></span></label>
                    <input type="date" class="form-control" name="updated_at" id="to_date">
                </div>
            </div>
        </div>
    </div>

    <div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body table-responsive">
                        <p>List of State wise Active Certification Bodies</p>
                        <table id="searchResultsTable" class="table table-bordered table-striped align-middle" style="width:100%">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>CB name</th>
                                    <th>Accreditation No.</th>
                                    <th>Validity from</th>
                                    <th>Validity up to</th>
                                    <th>Scope of Accreditation</th>
                                    <th>Past History (If sanctioned)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Data will be inserted here by DataTables -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection
@push('script')
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    var table = $('#searchResultsTable').DataTable({
        dom: 'Bfrtip',
        lengthMenu: [
            [10, 25, 50, -1],
            [10, 25, 50, "All"]
        ],
        processing: true,
        serverSide: true,
        ajax: {
            url: '{{ route('superadmin.statewiseActiveCB') }}',
            type: 'GET',
            data: function(d) {
                d.state = $('#state').val();
                d.from_date = $('#from_date').val();
                d.to_date = $('#to_date').val();
            },
            error: function(xhr, error, code) {
                console.log(xhr.responseText); // This will print the error response
            }
        },
        columns: [
            { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: true },
            { data: 'ref_operator_type_id', name: 'ref_operator_type_id', orderable: true },
            { data: 'at_user_id', name: 'at_user_id', orderable: true },
            { data: 'created_at', name: 'created_at', orderable: true },
            { data: 'updated_at', name: 'updated_at', orderable: true },
            { data: 'scope_of_accreditation', name: 'scope_of_accreditation', orderable: true },
            { data: 'past_history', name: 'past_history', orderable: true },
        ],
        paging: false,
        buttons: [
            'excelHtml5',
            {
                extend: 'csvHtml5',
                title: function() {
                    return "REPORTS";
                },
                titleAttr: 'CSV REPORTS'
            },
            {
                extend: 'pdfHtml5',
                title: function() {
                    return "PDF REPORTS";
                },
                orientation: 'landscape',   
                pageSize: 'A4',
                titleAttr: 'PDF REPORTS'
            }
        ],
        language: {
            emptyTable: "No Record found."
        }
    });

    $('#state, #from_date, #to_date').on('change', function() {
        table.draw();
    });
</script>
@endpush

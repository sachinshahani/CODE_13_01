@extends('admin.layouts.app')

@section('content')
    <style>
        .customtextarea {
            height: 80px;
        }
    </style> <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Details of TC/Lot/Batch self consumption

                </h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Details of TC/Lot/Batch self consumption
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div>

        <div class="row white-inner">


            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Operator Name/ Registration No<span class="required"></span></label>
                    <select class="form-select state" name="operatorType" id="operatorType" required>
                        <option value="">--Select--</option>
                        <option value="2">Grower Group</option>
                        <option value="3">INDIVIDUAL PRODUCER</option>
                        <option value="4">WILD</option>
                        <option value="5">TRADER</option>
                        <option value="6">PROCESSOR</option>
                    </select>                
                </div>
            </div>

            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">CB<span class="required"></span></label>
                    <select class="form-select state" name="active_cbf" id="active_cbf" required>
                    <option value="">--Select--</option>
                    @php
                        $cbNames = getCBNamesById(1);
                    @endphp
                    @foreach($cbNames as $id => $cbName)
                        <option value="{{$id}}">{{ $cbName }}</option>
                    @endforeach
                </select>
                </div>
            </div>
           {{-- <div class="col-xxl-1 col-md-4 gy-2">
                <div class="text-center">
                    <button type="submit" id="searchBtn" class="btn btn-primary" style="margin: 36px;">Search</button>
                </div>
            </div>--}}
        </div>
    </div>
    <div>
        <div class="row">

            <div class="col-lg-12">
                <div class="card">

                    <div class="card-body table-responsive">
                        <p> List of TC/Lot/Batch self consumption
                        </p>
                        <table id="searchResultsTable" class="table table-bordered table-striped align-middle"
                            style="width:100%">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Lot/Batch Id</th>
                                    <th>Product Name</th>
                                    <th>Type TC/Lot/Batch</th>
                                    <th>Quantity (in MT)</th>
                                    <th>Sourced Quantity (in MT)</th>
                                    <th>Self Consumed Quantity (in MT)</th>
                                    <th>Total Quantity Used (in MT)</th>
                                    <th>Available Quantity (in MT)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="9">No Record found.</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!--end col-->
        </div>
    @endsection
    @push('script')
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    var table = $('#searchResultsTable').DataTable({
        dom: 'Bfrtip',
        lengthMenu: [
            [10, 25, 50, -1],
            [10, 25, 50, "All"]
        ],
        processing: true,
        serverSide: true,
        ajax: {
            url: '{{ route('superadmin.report-on-lot-batch-self-consumption') }}',
            type: 'GET',
            data: function(d) {
                d.operatorType = $('#operatorType').val();
                d.active_cbf = $('#active_cbf').val();
            },
            error: function(xhr, error, code) {
                console.log(xhr.responseText);
            }
        },
        columns: [
            { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: true },
            { data: 'lot_number', name: 'lot_number', orderable: true },
            { data: 'product_name', name: 'product_name', orderable: true },
            { data: 'source_from', name: 'source_from', orderable: true },
            { data: 'total_quantity', name: 'total_quantity', orderable: true },
            { data: 'quantity_source', name: 'quantity_source', orderable: true },
            { data: 'self_qty_consumed', name: 'self_qty_consumed', orderable: true },
            { data: 'used_quantity', name: 'used_quantity', orderable: true },
            { data: 'available_quantity', name: 'available_quantity', orderable: true },
        ],
        order: [
            [0, 'asc']
        ],
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    });

    $('#operatorType, #active_cbf').on('change', function() {
        table.draw();
    });
</script>
@endpush

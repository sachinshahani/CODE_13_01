@extends('admin.layouts.app')

@section('content')
    <style>
        .customtextarea {
            height: 80px;
        }
    </style> <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Report on Scope Certificate NPOP


                </h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Report on Scope Certificate NPOP

                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div>

        <div class="row white-inner">

            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">State<span class="required"></span></label>
                    <select class="form-select state" name="state" id="state" required>
                        <option value="">--Select--</option>
                        @forelse(getAllState() as $state)
                            <option value="{{ $state->id }}" @selected(old('state') == $state->id)>{{ $state->state_name }}
                            </option>
                        @empty
                        @endforelse
                    </select>
                </div>
            </div>

            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Operator Type: <span class="required"></span></label>
                    <select class="form-select state" name="operatorType" id="operatorType" required>
                        <option value="">--Select--</option>
                        <option value="2">Grower Group</option>
                        <option value="3">INDIVIDUAL PRODUCER</option>
                        <option value="4">WILD</option>
                        <option value="5">TRADER</option>
                        <option value="6">PROCESSOR</option>
                    </select>
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">From: <span class="required"></span></label>
                    <input type="date" class="form-control" name="from_date" id="from_date">
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">To: <span class="required"></span></label>
                    <input type="date" class="form-control" name="to_date" id="to_date">
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
            <div>
    <label class="form-label">CB<span class="required"></span></label>
<select class="form-select state" name="active_cbf" id="active_cbf" required>
                    <option value="">--Select--</option>
                    @php
                        $cbNames = getCBNamesById(1);
                    @endphp
                    @foreach($cbNames as $id => $cbName)
                        <option value="{{$id}}">{{ $cbName }}</option>
                    @endforeach
                </select>
            </div>
            </div>
          {{--  <div class="col-xxl-1 col-md-4 gy-2">
                <div class="text-center">
                    <button type="submit" id="searchBtn" class="btn btn-primary" style="margin: 36px;">Search</button>
                </div>
            </div>--}}




        </div>


    </div>

    <div>
        <div class="row">

            <div class="col-lg-12">
                <div class="card">

                    <div class="card-body table-responsive">
                        <p>Report on Scope Certificate NPOP

                        </p>
                        <table id="searchResultsTable" class="table table-bordered table-striped align-middle"
                            style="width:100%">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Scope Certificate No.</th>
                                    <th>Operator Name</th>
                                    <th>Registration No.</th>
                                    <th>Address</th>
                                    <th>Operator Type</th>
                                    <th>Name of Certification Body</th>
                                    <th>Validity Start Date</th>
                                    <th>Email ID</th>
                                    <th>Validity End Date</th>
                                    <th>Date of Registration</th>
                                    <th>Issued Date</th>
                                    <th>Action(Viw scope certificate, View amended scope certificate)</th>
                                    <th>View scope certificate</th>
                                    <th>Letter Of Registration</th>
                                </tr>
                            </thead>
                            <tbody>                               
                                <!-- Data will be inserted here by DataTables -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!--end col-->
        </div>
    @endsection
    @push('script')
    <script>
   var table = $('#searchResultsTable').DataTable({
    dom: 'Bfrtip',
    lengthMenu: [
        [10, 25, 50, -1],
        [10, 25, 50, "All"]
    ],
    processing: true,
    serverSide: true,
    ajax: {
        url: '{{ route('superadmin.report-on-scope-certificate') }}',
        type: 'GET',
        data: function(d) {
            d.state = $('#state').val();
            d.operatorType = $('#operatorType').val();
            d.from_date = $('#from_date').val();
            d.to_date = $('#to_date').val();
            d.active_cbf = $('#active_cbf').val();
        },
        error: function(xhr, error, code) {
            console.log(xhr.responseText);
        }
    },
    columns: [
        { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: true },
        { data: 'scope_certificate_no', name: 'scope_certificate_no', orderable: true },
        { data: 'first_name', name: 'first_name', orderable: true },
        { data: 'registration_no', name: 'registration_no', orderable: true },
        { data: 'address', name: 'address', orderable: true },
        { data: 'ref_operator_type_id', name: 'ref_operator_type_id', orderable: true },
        { data: 'file_name', name: 'file_name', orderable: true },
        { data: 'validity_start_date', name: 'validity_start_date', orderable: true },
        { data: 'email', name: 'email', orderable: true },
        { data: 'validity_end_date', name: 'validity_end_date', orderable: true },
        { data: 'date_of_registration', name: 'date_of_registration', orderable: true },
        { data: 'created_at', name: 'created_at', orderable: true },
        { data: 'file_name', name: 'file_name', orderable: false },
        { data: 'registration_certificate', name: 'registration_certificate', orderable: false },
    ],
    order: [
        [0, 'asc']
    ],
    buttons: [
        'copy', 'csv', 'excel', 'pdf', 'print'
    ],
    columnDefs: [{
        targets: [12, 13, 14],
        render: function(data, type, row, meta) {
            return type === 'display' ? $('<div />').html(data).text() : data;
        }
    }]
});

$('#state, #operatorType, #from_date, #to_date, #active_cbf').on('change', function() {
    table.draw();
});

</script>

@endpush

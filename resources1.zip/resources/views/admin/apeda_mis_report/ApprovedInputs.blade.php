@extends('admin.layouts.app')

@section('content')
    <style>
        .customtextarea {
            height: 80px;
        }
    </style> <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Details of Approved Inputs

                </h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Details of Approved Inputs
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div>

        <div class="row white-inner">


            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Operator Name/ Registration No<span class="required"></span></label>
                   <input type="text" class="form-control" >
                </div>
            </div>
           
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">CB<span class="required"></span></label>
                    <select class="form-select state" name="operatorType" id="operatorType" required>
                        <option value="">--Select--</option>
                        <option value="1">All</option>


                    </select>
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Operator Status<span class="required"></span></label>
                    <select class="form-select state" name="operatorType" id="operatorType" required>
                        <option value="">--Select--</option>
                        <option value="1">Active</option>
                        <option value="2">Inactive</option>


                    </select>
                </div>
            </div>


            <div class="col-xxl-1 col-md-4 gy-2">
                <div class="text-center">
                    <button type="submit" id="searchBtn" class="btn btn-primary" style="margin: 36px;">Search</button>
                </div>
            </div>




        </div>


    </div>

    <div>
        <div class="row">

            <div class="col-lg-12">
                <div class="card">

                    <div class="card-body table-responsive">
                        <p> List of Ammendment Annexure
                        </p>
                        <table id="searchResultsTable" class="table table-bordered table-striped align-middle"
                            style="width:100%">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Certification Body Name</th>
                                    <th>Operator Name</th>
                                    <th>Operator Address </th>
                                    <th>Mobile No.</th>
                                    <th>Email-Id</th>
                                    <th>Contact Person Name</th>
                                    <th>Date of Registration</th>
                                    <th>Statement of Compliance No.</th>
                                    <th>Issued Date</th>
                                    <th>Validity From</th>
                                    <th>Validity To</th>
                                    <th>Operator Status</th>
                                    <th>Statement of Compliance</th>

                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="15">No Record found.</td>

                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!--end col-->
        </div>

        <script>

        </script>
    @endsection

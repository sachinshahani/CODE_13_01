@extends('admin.layouts.app')

@section('content')
    <style>
        .customtextarea {
            height: 80px;
        }
    </style> <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Certification Body Activity Details
                </h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Certification Body Activity Details
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div>
        <div class="row white-inner">
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">CB<span class="required"></span></label>
                    <select class="form-select state" name="active_cbf" id="active_cbf" required>
                    <option value="">--Select--</option>
                    @php
                        $cbNames = getCBNamesById(1);
                    @endphp
                    @foreach($cbNames as $id => $cbName)
                        <option value="{{ $id }}">{{ $cbName }}</option>
                    @endforeach
                </select>
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">From: <span class="required"></span></label>
                    <input type="date" class="form-control" name="from_date" id="from_date">
                </div>
            </div>
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">To: <span class="required"></span></label>
                    <input type="date" class="form-control" name="updated_at" id="to_date">
                </div>
            </div>
            {{--<div class="col-xxl-1 col-md-4 gy-2">
                <div class="text-center">
                    <button type="submit" id="searchBtn" class="btn btn-primary" style="margin: 36px;">Search</button>
                </div>
            </div>--}}
        </div>
    </div>
    <div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body table-responsive">
                        <p> List of Certification Body Activity
                        </p>
                        <table id="searchResultsTable" class="table table-bordered table-striped align-middle"
                            style="width:100%">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>CB Name</th>
                                    <th>No. of Domestic TC issued</th>
                                    <th>No. of PTC Issued</th>
                                    <th>No. of Export TC Issued</th>
                                    <th>No. of Lot/Batch approved</th>
                                    <th>No. of NOC applied by operator</th>
                                    <th>No. of NOC approved by CB</th>
                                    <th>No. of operator registered with new CB</th>
                                    <th>No. of operator registered through NOC</th>
                                    <th>No. of amended scope issued</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="11">No Record found.</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!--end col-->
        </div>
    @endsection
    @push('script')
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    var table = $('#searchResultsTable').DataTable({
        dom: 'Bfrtip',
        lengthMenu: [
            [10, 25, 50, -1],
            [10, 25, 50, "All"]
        ],
        processing: true,
        serverSide: true,
        ajax: {
            url: '{{ route('superadmin.report-certification-body-activity') }}',
            type: 'GET',
            data: function(d) {
                d.active_cbf = $('#active_cbf').val();
                d.from_date = $('#from_date').val();
                d.to_date = $('#to_date').val();
            },
            error: function(xhr, error, code) {
                console.log(xhr.responseText); // This will print the error response
            }
        },
        columns: [
            { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: true },
            { data: 'operator_type_count', name: 'operator_type_count', orderable: true },
            { data: 'nop_status_count', name: 'nop_status_count', orderable: true },
        ],
        paging: false,
        buttons: [
            'excelHtml5',
            {
                extend: 'csvHtml5',
                title: function() {
                    return "REPORTS";
                },
                titleAttr: 'CSV REPORTS'
            },
            {
                extend: 'pdfHtml5',
                title: function() {
                    return "PDF REPORTS";
                },
                orientation: 'landscape',   
                pageSize: 'A4',
                titleAttr: 'PDF REPORTS'
            }
        ],
        language: {
            emptyTable: "No Record found."
        }
    });

    $('#active_cbf, #from_date, #to_date').on('change', function() {
        table.draw();
    });
</script>
@endpush
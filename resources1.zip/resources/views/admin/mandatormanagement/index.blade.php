@extends('admin.layouts.app')

@section('content')
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <!-- @php
                    $tit = '';
                    $ids = request()->segment(count(request()->segments()));
                    if ($ids == 2) {
                        $tit = 'ICS';
                    } elseif ($ids == 3) {
                        $tit = 'Individual Producer';
                    } elseif ($ids == 4) {
                        $tit = 'Wild Harvester';
                    } elseif ($ids == 5) {
                        $tit = 'Trader';
                    } else {
                        $tit = '';
                    }
                    
                @endphp -->
                <h4 class="mb-sm-0">
                Service Provider Details
                    <!-- @if (isset(auth()->user()->ref_operator_type_id) && auth()->user()->ref_operator_type_id != 1)
                        My Details
                    @else
                        Users
                    @endif -->
                </h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);"> Service Provider Management</a></li>
                        <li class="breadcrumb-item active">
                            @if (isset(auth()->user()->ref_operator_type_id) && auth()->user()->ref_operator_type_id != 1)
                                My Details
                            @else
                            Service Provider
                            @endif
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>

    <div class="col-md-12 mt-2">
        @if (session('success'))
            <div class="alert alert-success" id="validate">
                {{ session('success') }}
            </div>
        @endif

        @if (session('importErrors'))
            <div class="alert alert-danger">
                <p>Following Errors Occured While Uploading the list, Please fix and upload again</p>
                <ul>
                    @foreach (session('importErrors') as $failure)
                        @foreach ($failure->errors() as $f)
                            <li>{{ $f . ' at row ' . $failure->row() }}</li>
                        @endforeach
                    @endforeach
                </ul>
            </div>
        @endif
    </div>
 
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0" style="float: left">
                        @if (isset(auth()->user()->ref_operator_type_id) && auth()->user()->ref_operator_type_id != 1)
                            My Details
                        @else
                            {{ $tit }} Service Provider List
                        @endif
                    </h5>
                    @if (Auth::guard('misadmin')->user()->roles[0]->id == 1)
                        <a href="{{route('superadmin.mandatormanagement.create')}}" class="btn btn-primary"
                            style="float: right">Add Service Provider</a>
                    @endif
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="mandatorUsers" class="table table-bordered dt-responsive nowrap table-striped align-middle">     
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Registration No</th>
                                    <th>Service Provider Details</th>
                                    <th>Contact Person Details</th>
                                    <th>Supported Documents</th>
                                    <!-- <th>Name</th>
                                    <th>Email</th>
                                    <th>Mobile</th>
                                    <th>Created On</th> -->
                                    {{-- <th>Status</th> --}}
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!--end col-->
    </div>
    <!--end row-->

@endsection



@push('script')
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        var table = $('#mandatorUsers').DataTable({
            //dom: 'l<"clear">Bfrtip',
            //dom:'Bfrtip',
            //dom:'Blfrtip',
            lengthMenu: [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
            ],
            processing: true,
            serverSide: true,
            ajax: {
                url: '{{ route('superadmin.mandatormanagement.mandatorlist') }}',
                type: 'GET',
                data: function(d) {

                }
            },
            columns: [{
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex',
                    orderable: true
                },
                {
                    data: 'id',
                    name: 'id',
                    orderable: true
                },
                {
                    data: 'name',
                    name: 'name',
                    orderable: true
                },
                {
                    data: 'contact_details',
                    name: 'contact_details',
                    orderable: true
                },
                {
                    data: 'doc',
                    name: 'doc',
                    orderable: true
                },
              
                // {
                //     data: 'status',
                //     name: 'status',
                //     orderable: true
                // },
                {
                    data: 'action',
                    name: 'name',
                    orderable: false
                },
            ],
            // initComplete: function () {
            //     var btns = $('.dt-button');
            //     //btns.addClass('btn btn-success btn-success');
            //     btns.removeClass('dt-button');

            // },

        });


        $(document).on('click', '.deletedata', function() {
            var id = $(this).attr('data-value');

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.value) {
                    $.ajax({
                        url: "{{ route('superadmin.usermanagement.deptUser.delete') }}",
                        method: "POST",
                        dataType: 'json',
                        data: {
                            'id': id,
                        },
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function(result) {
                            Swal.fire('Deleted!', 'Record Deleted Successfully..', 'success')
                                .then((result) => {
                                    window.location.href =
                                        '{{ route('superadmin.usermanagement.deptUser', $ids) }}';
                                });
                        }

                    });
                }
            });
        });

        $(document).on('click', '.viewdata', function() {
            var id = $(this).attr('data-id');

            $.ajax({
                url: "{{ route('superadmin.usermanagement.deptUser.view') }}",
                method: "POST",
                dataType: 'json',
                data: {
                    'id': id,
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(result) {
                    if (result.status == "success") {
                        $('#viewDataModal').modal('show');
                        $('#viewDataModal #htmlData').html(result.html);
                        return true;
                    } else {
                        Swal.fire('', result.msg, 'warning');
                    }
                },
                error: function(result) {

                }
            });
        });
    </script>
@endpush

@extends('admin.layouts.app')
@section('content')
    <style>
        .overlay {
            background: rgb(0 0 0 / 50%);
            position: fixed;
            top: 0;
            z-index: 11111;
            left: 0;
            right: 0;
            bottom: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            display: none;
        }

        .loader {
            position: fixed !important;
            left: 50% !important;
            margin-left: -4em !important;
            top: 20em !important;
        }

        .wrapper {
            max-width: 1240px;
            margin: 0 auto;
        }

        .white-bg {
            background-color: white;
            /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
            border-bottom: 5px solid #ff9800;
            margin-bottom: 15px;
        }

        .auth-one-bg .slide .carousel-indicators {
            bottom: 25px;
        }

        .auth-page-wrapper .auth-page-content {
            padding-bottom: 0px !important;
        }

        .auth-page-content .card {
            margin-bottom: 0rem;
        }

        .data-tabs .wrapper .nav-tabs button {
            font-size: 17px;
            color: black;
        }

        .data-tabs .wrapper .nav-tabs .active {
            background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
            */ color: white;
            background: orange;
            border-radius: 0px;
        }

        .carousel-caption.d-none.d-md-block {
            background-color: #000000bf;
            left: 0;
            width: 100%;
            bottom: 0;
        }

        .carousel-indicators {
            display: none;
        }

        .custom-banner-caption {
            color: white !important;
        }

        .announcement-heading {
            font-size: 1.2em;
            font-weight: 600;
        }

        .data-tabs .tab-pane ul li {
            font-size: 1em;
            padding: 5px 0;

        }

        .main-logo {
            padding: 10px;
        }

        .data-tabs .nav-item .nav-link {
            background-image: none;
        }

        /* .right-sec{
                    box-shadow: 5px 10px 18px #888888;
                } */
        .navbar-brand-box {
            background: #fff;
        }

        [data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
            color: white !important;
        }

        .header-buttons .btn-primary {
            margin-right: 10px;
            padding: 6px 15px;
            font-weight: 600;
            background-color: #207005;
            border: none;
            box-shadow: 0px 2px 7px #888888;
        }

        .header-buttons .btn-secondary {
            margin-right: 10px;
            padding: 6px 15px;
            font-weight: 600;
            background-color: #72a055;
            border: none;
            box-shadow: 0px 2px 7px #888888;
        }


        .right-sec {
            border-left: 5px solid #ede7e7;
        }

        .tabdiv {
            background: white;
            padding: 20px;
            margin-top: 10px;
            border: 10px solid #dfdbd5;
        }

        .nav-tabs {
            border-bottom: 0px;
        }

        div#myTabContent {
            border: 1px solid #cccccc;
        }

        .frontfooter footer {
            padding: 20px calc(1.5rem / 2);
            position: static;
            color: #000;
            height: 60px;
            background-color: #f9f9f9;
            margin-top: 30px;
            border-top: 1px solid #e1dfdf;
        }

        span.logo-sm img {
            width: 69px;
        }

        .seperatesec {
            margin-top: 20px;
        }

        .simplebar-content li.nav-item:hover {
            background: #4caf50;
        }

        .sectitle {
            font-size: 14px;
        }

        .required {
            color: red;
        }

        .customtextarea {
            height: 120px;
        }

        ul.boxsection {
            margin: 0;
            padding: 0;
        }

        ul.boxsection li {
            list-style-type: none;
            padding: 7px 0;
            border-bottom: 1px solid #efeded;
        }

        .boxcard .col:nth-child(1) {
            background: #effcfb;
        }

        .boxcard .col:nth-child(2) {
            background: #fdfdfd;
        }

        .boxcard .col:nth-child(3) {
            background: #effcfb;
        }

        .boxcard .col:nth-child(4) {
            background: #fdfdfd;
        }

        .boxcard .col:nth-child(5) {
            background: #effcfb;
        }

        /* --registration-form css  */
        .custom-tab-content {
            padding-top: 0 !important;
            padding-bottom: 0px !important;
        }

        .custom-tab-nav {
            background: white;

        }

        .custom-tab-nav .nav-link {
            border-radius: 0 !important;
            border-bottom: 1px solid #e9ebec;
            border-right: 1px solid #e9ebec;
            font-size: 14px;
            padding: 10px;
        }

        .custom-tab-nav .nav-link.active,
        .custom-tab-nav .show>.nav-link {
            color: rgb(255, 255, 255) !important;
            background-color: #2c8c6d;
            border-bottom: #2c8c6d !important;
            /* border-bottom: #207005 !important; */
            position: relative;
        }

        .custom-tab-nav .nav-link:hover,
        .custom-tab-nav .nav-link:focus {
            border-bottom: 1px solid #207005;
            border-radius: 0;
            font-size: 14px;
            transition: background-color 0.20s linear;
        }

        .custom-tab-nav .nav-link.active:after {
            content: "";
            position: absolute;
            bottom: -16px;
            left: 50%;
            border: 8px solid transparent;
            border-top-color: #2c8c6d;
            z-index: 999;
        }

        .reg-form-btns {
            margin-bottom: 15px;
        }

        .reg-form-btns .btn-secondary {
            color: #fff;
            background-color: #405189;
            border-color: #405189;
        }

        .btn-soft-success:active,
        .btn-soft-success:focus,
        .btn-soft-success:hover {
            border: none;
        }

        .custom-tab-nav ul {
            padding: 0px;
            margin: 0px;
        }

        .custom-tab-nav ul li {
            padding: 0px;
            margin: 0px;
            display: inline-block;
            list-style: none;
        }

        /* -------  */
        .btn-email {
            font-size: 13px;
            padding: 1px 7px;
            line-height: 17px;

        }

        .btn-mailsend {
            font-size: 13px;
            padding: 1px 7px;
            line-height: 17px;
        }

        .btn-verify {
            font-size: 13px;
            padding: 1px 7px;
            line-height: 34px;
        }

        .inputEmail .input-group-append {
            display: flex;
            align-items: end;
        }

        .inputEmail .validateEmailId {
            border-radius: 4px 0 0 4px;
        }

        .input-group-append .verifiEmail_otp,
        .input-group-append .resendEmail_otp {
            margin-left: 10px;
        }

        .login-pass.otp-email {
            margin-top: 5px
        }

        .login-pass.otp-email .inp-b {
            border-radius: 0 4px 4px 0
        }
    </style>







    <div class="overlay">
        <div class="loader"></div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Edit Service Provider</h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Service Provider Management</a></li>
                        <li class="breadcrumb-item active">Edit Service Provider</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
              {{--   <div class="card-header align-items-center d-flex">
				  <h4 class="card-title mb-0 flex-grow-1">Registration of Mandator</h4>
                    
                </div> --}}

                <div class="card-body">
				<div class="flex-shrink-0">
                        @if (session('error'))
                            <div class="alert alert-danger">
                                {{ session('error') }}
                            </div>
                        @endif
                        @if (session('success'))
                            <div class="alert alert-success">
                                {{ session('success') }}
                            </div>
                        @endif
                        @if ($errors)
                            @foreach ($errors->all() as $error)
                                <div class="alert alert-danger">{{ $error }}</div>
                            @endforeach
                        @endif
                    </div>
                    <div class="live-preview">
                        <form action="{{ route('superadmin.mandatormanagement.mandatorupdate') }}" class="commonform1"
                            method="POST" enctype="multipart/form-data" id="commonform1" autocomplete="off">
                            @csrf
                            <div class="row gy-4 white-inner">
                                 
                                <div class="row seperatesec">
								<input type="hidden" name="editId" value="{{$edit->id}}">
                                    <div class="sectitle">
                                        <!-- <label for="labelInput" class="form-label">Name of the Operator</label> -->
                                    </div>

                                    <div class="col-xxl-3 col-md-6">
                                        <div>
                                            <label class="form-label">Name of the Service Provider <span
                                                    class="required">*</span></label>
                                            <input type="text" class="form-control" id="name"
                                                placeholder="Company Name" name="mandator_name" required
                                                value="{{ $edit->mandator_name}}">
                                        </div>
                                    </div>
                                </div>  
                                <div class="row seperatesec">
                                    {{-- <div class="sectitle">
                                    <label for="labelInput" class="form-label">Address</label>
                                </div> --}}
                                    <div class="row">
                                        <div class="col-xxl-3 col-md-3">
                                            <div class="row">
                                                <div class="col-xx-12 col-md-12">
                                                    <label for="labelInput" class="form-label ">Address <span
                                                            class="required">*</span></label>
                                                    <textarea class="form-control customtextarea" name="address" required>{{ $edit->address }}</textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xxl-9 col-md-9">
                                            <div class="row">
                                                <div class="col-xxl-4 col-md-4">
                                                    <label for="labelInput" class="form-label">State <span
                                                            class="required">*</span></label>
                                                    <select class="form-select state" name="state_id" id="state"
                                                        required>
                                                        <option value="">Select State</option>
                                                        @forelse(getAllState() as $state)
                                                            <option value="{{ $state->id }}"
                                                                @selected($edit->state_id == $state->id)>{{ $state->state_name }}
                                                            </option>
                                                        @empty
                                                        @endforelse
                                                    </select>
                                                </div>
                                                <div class="col-xxl-4 col-md-4">
                                                    <label for="labelInput" class="form-label">District <span
                                                            class="required">*</span></label>
                                                    <select class="form-select district" name="district_id" id="district"
                                                        required>
                                                        @forelse(getDistrictByStateID($edit->state_id) as $district)
                                                            <option value="{{ $district->id }}"
                                                                @selected($edit->district_id == $district->id)>
                                                                {{ $district->district_name }}</option>
                                                        @empty
                                                            <option value="">-Select District-</option>
                                                        @endforelse


                                                    </select>
                                                </div>
                                                <div class="col-xxl-4 col-md-4">
                                                    <label for="labelInput" class="form-label">Taluka/Mandal <span
                                                            class="required">*</span></label>
                                                    <select class="form-select block_tehsil" name="taluka_mandal_id"
                                                        id="block_tehsil" required>

                                                        @forelse(getBlockTehsilByDistrictID($edit->district_id) as $block)
                                                            <option value="{{ $block->id }}"
                                                                @selected($edit->taluka_mandal_id == $block->id)>
                                                                {{ $block->block_tehsil_name }}</option>
                                                        @empty
                                                            <option value="">-Select Taluka/Mandal-</option>
                                                        @endforelse


                                                    </select>
                                                </div>

                                                <div class="col-xxl-6 col-md-6 gy-3">
                                                    <label for="labelInput" class="form-label">Village <span
                                                            class="required">*</span></label>
                                                    <select class="form-select village" name="village_id" id="village"
                                                        required>
                                                        @forelse(getVillageByBlock($edit->taluka_mandal_id) as $village)
                                                            <option value="{{ $village->id }}"
                                                                @selected($edit->village_id == $village->id)>
                                                                {{ $village->village_name }}</option>
                                                        @empty
                                                            <option value="">-Select Village-</option>
                                                        @endforelse
                                                    </select>
                                                </div>
                                                <div class="col-xxl-6 col-md-6 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">Pin Code<span
                                                                class="required">*</span></label>
                                                        <input type="text" class="form-control" id="pin_code"
                                                            name="pin_code" placeholder="Pin Code" maxlength="6"
                                                            required value="{{$edit->pin_code }}">
                                                    </div>
                                                </div>

                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="row seperatesec">
                                    <div class="col-xxl-3 col-md-6 ">
                                        <div>
                                            <label for="labelInput" class="form-label">Mobile Number <span
                                                    class="required">*</span></label>
                                            <input type="text" class="form-control numbersonly phone" required
                                                name="mobile" placeholder="Mobile Number" onblur="phonenumber(this)"
                                                maxlength="10" value="{{ $edit->mobile}}">
                                        </div>
                                    </div>

                                    <!-- get otp  -->

                                    <div class="col-xxl-3 col-md-4">
                                        <div class="inputEmail  col-12 col-sm-12 col-md-12 col-lg-12">
                                            <div class="form-group d-flex justify-content-center ge-otp-form">
                                                <div class="col-12 col-sm-12 col-md-10 col-lg-10">
                                                    <label>Email ID<span class="text-danger">*</span></label>
                                                    <input
                                                        class="form-control validateEmailId col-12 col-sm-12 col-md-12 col-lg-12"
                                                        type="text" value="{{$edit->email }}" placeholder="Email Id"
                                                        id="email_id1" name="email" required  />
                                                </div>
                                                <div class="input-group-append col-12 col-sm-12 col-md-2 col-lg-2">
                                                    <button type="button"
                                                        class="btn-email btn btn-outline-success waves-effect waves-light visitorCat2">Get
                                                        OTP</button>
                                                    <button type="button"
                                                        class="btn btn-ghost-success waves-effect waves-light btn-mailsend"
                                                        style="display:none">Mail Send</button>
                                                    <button type="button"
                                                        class="btn btn-ghost-success waves-effect waves-light btn-verify"
                                                        style="display:none">Verified</button>
                                                </div>
                                            </div>
                                            <div class="verify-email justify-content-center">
                                                <div class="login-pass mb-4 otp-email col-12 col-sm-12 col-md-5 col-lg-12 pl-2"
                                                    style="display:none">
                                                    <div class="input-group">
                                                        <span class="input-group-text mdi mdi-key"
                                                            id="inputGroup-sizing-default"></span>
                                                        <input type="text" class="form-control inp-b"
                                                            aria-label="Sizing example input"
                                                            aria-describedby="inputGroup-sizing-default" id="email_otp1">
                                                        <div class="input-group-append">
                                                            <a href="javascript:void(0)"
                                                                class="verifiEmail_otp btn btn-outline-success waves-effect waves-light">Verify</a>
                                                            <a href="javascript:void(0)"
                                                                class="resendEmail_otp btn btn-outline-danger waves-effect waves-light">Resend</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                        </div>
                                        
                                    </div>
                                    <div class="col-xxl-3 col-md-6">
                                        <div>
                                            <label for="labelInput" class="form-label">Pan Number<span
                                                    class="required">*</span></label>
                                            <input type="text" class="form-control pan" name="pan"
                                                placeholder="Pan Number*" value="{{ $edit->pan }}" required
                                                maxlength="12">
                                        </div>
                                    </div>
                                    <!-- end -->
                                </div>
							</div>
							 
                                <div class="row seperatesec gy-4 white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label blue-ht">Contact Person Details</label>
                                    </div>

                                    <div class="col-xxl-3 col-md-6">
                                        <div>
                                            <label class="form-label">Contact Person First Name <span
                                                    class="required">*</span></label>
                                            <input type="text" class="form-control" id="contact_first_name"
                                                placeholder="First Name" name="contact_first_name"
                                                value="{{$edit->contact_first_name }}" required>
                                        </div>
                                    </div>

                                    <div class="col-xxl-3 col-md-6">
                                        <div>
                                            <label class="form-label">Contact Person Middle Name</label>
                                            <input type="text" class="form-control" id="middle_name"
                                                name="contact_middle_name" placeholder="Middle Name"
                                                value="{{ $edit->contact_middle_name }}">
                                        </div>
                                    </div>

                                    <div class="col-xxl-3 col-md-6">
                                        <div>
                                            <label class="form-label">Contact Person Last Name <span
                                                    class="required">*</span></label>
                                            <input type="text" class="form-control" id="last_name"
                                                name="contact_last_name" placeholder="Last Name" required
                                                value="{{ $edit->contact_last_name }}">
                                        </div>
                                    </div>
                                    <div class="col-xxl-3 col-md-6 ">
                                        <div>
                                            <label for="labelInput" class="form-label">Contact Person Mobile Number <span
                                                    class="required">*</span></label>
                                            <input type="text" class="form-control numbersonly phone" required
                                                name="cp_mobile" placeholder="Mobile Number" onblur="phonenumber(this)"
                                                maxlength="10" value="{{ $edit->contact_mobile }}">
                                        </div>
                                    </div>

                                    <!-- get otp  -->

                                    <div class="col-xxl-3 col-md-4 gy-3">
                                        <div class="inputEmail  col-12 col-sm-12 col-md-12 col-lg-12">
                                            <div class="form-group d-flex justify-content-center ge-otp-form">
                                                <div class="col-12 col-sm-12 col-md-10 col-lg-10">
                                                    <label>Contact Person Email ID<span
                                                            class="text-danger">*</span></label>
                                                    <input
                                                        class="form-control validateEmailId col-12 col-sm-12 col-md-12 col-lg-12"
                                                        type="text" value="{{ $edit->contact_email }}" placeholder="Email Id"
                                                        id="cp_email_id" name="cp_email" required  />
                                                </div>
                                                <div class="input-group-append col-12 col-sm-12 col-md-2 col-lg-2">
                                                    <button type="button"
                                                        class="btn-email btn btn-outline-success waves-effect waves-light visitorCat2">Get
                                                        OTP</button>
                                                    <button type="button"
                                                        class="btn btn-ghost-success waves-effect waves-light btn-mailsend"
                                                        style="display:none">Mail Send</button>
                                                    <button type="button"
                                                        class="btn btn-ghost-success waves-effect waves-light btn-verify"
                                                        style="display:none">Verified</button>
                                                </div>
                                            </div>
                                            <div class="verify-email justify-content-center">
                                                <div class="login-pass mb-4 otp-email col-12 col-sm-12 col-md-5 col-lg-12 pl-2"
                                                    style="display:none">
                                                    <div class="input-group">
                                                        <span class="input-group-text mdi mdi-key"
                                                            id="inputGroup-sizing-default"></span>
                                                        <input type="text" class="form-control inp-b"
                                                            aria-label="Sizing example input"
                                                            aria-describedby="inputGroup-sizing-default" id="email_otp1">
                                                        <div class="input-group-append">
                                                            <a href="javascript:void(0)"
                                                                class="verifiEmail_otp btn btn-outline-success waves-effect waves-light">Verify</a>
                                                            <a href="javascript:void(0)"
                                                                class="resendEmail_otp btn btn-outline-danger waves-effect waves-light">Resend</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- end -->

                                    <div class="col-xxl-3 col-md-6 gy-3">
                                        <div>
                                            <label for="labelInput" class="form-label">Designation of Contact
                                                Person</label>
                                            <input type="text" class="form-control" name="contact_designation"
                                                placeholder="Designation of Contact Person"
                                                value="{{ $edit->contact_designation }}">
                                        </div>
                                    </div>

                                    <div class="col-xxl-3 col-md-6 gy-3">
                                        <div>
                                            <label for="labelInput" class="form-label">Aadhar Number<span
                                                    class="required">*</span></label>
                                            <input type="text" class="form-control numbersonly" name="aadhar_no"
                                                placeholder="Aadhar Number*" value="{{ $edit->aadhar_no }}" required
                                                maxlength="12">
                                        </div>
                                    </div>
                                    <div class="col-xxl-3 col-md-4 gy-3 address_proof_doc">
                                        <div>
                                            <label class="form-label"> Upload Photo of Contact Person</label>
                                            <input type="file" class="form-control" name="contact_photo" id="">
                                            <span class="form-text">Supported formats:JPG, PNG, PDF. Upto 2MB</span>
                                            @if (!empty($edit->contact_photo))
                                            <input type="hidden" name="contact_photo_edit"
                                                value="{{ $edit->contact_photo ?? '' }}">
                                            <a target="_BLANK"
                                                href="{{ asset('public/mandator/contact_photo/' . $edit->contact_photo) }}"
                                                class="text-decoration-underline">See Doc</a>
                                        @endif
                                        </div>
                                    </div>


                                    <div class="col-xxl-3 col-md-4 gy-3 address_proof_doc">
                                        <div>
                                            <label class="form-label"> Scan Copy of ID Proof</label>
                                            <input type="file" class="form-control" name="id_proof" id="">
                                            <span class="form-text">Supported formats:JPG, PNG, PDF. Upto 2MB</span>
                                            @if (!empty($edit->id_proof))
                                            <input type="hidden" name="id_proof_edit"
                                                value="{{ $edit->id_proof ?? '' }}">
                                            <a target="_BLANK"
                                                href="{{ asset('public/mandator/id_proof/' . $edit->id_proof) }}"
                                                class="text-decoration-underline">See Doc</a>
                                        @endif
                                        </div>
                                    </div>
                                    <div class="col-xxl-3 col-md-4 gy-3 address_proof_doc">
                                        <div>
                                            <label class="form-label"> Upload Service Provider Resume </label>
                                            <input type="file" class="form-control" name="mandator_resume" id="">
                                            <span class="form-text">Supported formats:JPG, PNG, PDF. Upto 2MB</span>
                                            @if (!empty($edit->mandator_resume))
                                            <input type="hidden" name="mandator_resume_edit"
                                                value="{{ $edit->mandator_resume ?? '' }}">
                                            <a target="_BLANK"
                                                href="{{ asset('public/mandator/mandator_resume/' . $edit->mandator_resume) }}"
                                                class="text-decoration-underline">See Doc</a>
                                        @endif
                                        </div>
                                    </div>

                                   
                                    {{-- <div class="col-xxl-3 col-md-6 gy-3">
                                    <label for="labelInput" class="form-label"></label><br>
                                     <button type="button" class="btn btn-primary" style="margin-top:2.5%!important">Send OTP</button>
                                    
                                </div> --}}


                                    <div class="row">
                                        <div class="col-lg-12 gy-4">
                                            <div class="hstack gap-2">
                                                <button type="submit" class="btn btn-primary">Update</button>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('script')
    <script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
    <script type="text/javascript">
        $(".btn-email").click(function(e) {
            e.preventDefault();
            var user_email = $('#email_id1').val();


            if (user_email != "") {
                $(".overlay").show();
                $.ajax({
                    type: 'POST',
                    url: "{{ route('superadmin.usermanagement.email_mobile_OTP') }}",
                    data: {
                        'user_email': user_email
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(resp) {
                        if (resp == 1) {

                            Swal.fire({
                                text: "Please verify OTP send on Email id",
                                icon: 'success',
                                confirmButtonText: 'OK'
                            }).then((result) => {
                                $('.otp-email').show(500);
                                $('#email_id1').val(user_email);
                                $('#email_id1').prop('readonly', true);
                                $('.btn-email').hide(500);
                                $('.btn-mailsend').show(100);
                            });

                        }
                        $(".overlay").hide();
                    }
                });
            } else {
                Swal.fire("", "Please enter Email ID", "error");
            }
        });


        $(".verifiEmail_otp").click(function(e) {
            e.preventDefault();
            var email_otp = $('#email_otp1').val();
            $(".overlay").show();
            if (email_otp != "") {

                $.ajax({
                    type: 'POST',
                    url: "{{ route('superadmin.usermanagement.email_mobile_OTP_check') }}",
                    data: {
                        'email_otp': email_otp
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(html) {
                        if (html == 1) {
                            $('#email_otp').prop('readonly', true);
                            $('.otp-email1').hide(500);
                            $('.btn-email').hide(500);
                            $('.btn-verify').show(500);
                            $('.visitorCat').hide(500);
                            $('.visitorCat1').hide(500);
                            $('.user_detail_page').show(500);
                            $('#email_id').prop('readonly', true);
                            $('.btn-mailsend').hide();
                            $('.login-pass').hide();
                        } else {
                            Swal.fire("", "Please enter Valid OTP", "error");

                        }
                        $(".overlay").hide();
                    }
                });
            } else {
                Swal.fire("", "Please enter OTP", "error");
            }
        });

        $(".resendEmail_otp").click(function(e) {
            e.preventDefault();
            var user_email = $('#email_id1').val();

            $.ajax({
                type: 'POST',
                url: "{{ route('superadmin.usermanagement.email_mobile_OTP') }}",
                data: {
                    'user_email': user_email
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(html) {
                    Swal.fire("", "Re OTP Send!!", "success");
                }
            });
        });
    </script>




    <script>
        $("#commonform1").validate({
            rules: {
                // user_password: { 
                // 	required: true,
                // 	minlength: 8,
                // 	maxlength: 10,
                // } ,
                mobile: {
                    required: true,
                }
            },
            messages: {
                // user_password: { 
                // 	required:"This field is required and should be 8 digits, contains upper,lowerCase,and a special Character"   
                // },
                mobile: {
                    required: "This field is required",
                }
            }

        });

        function CheckPassword(inputtxt) {
            if (inputtxt.value.length > 0) {
                var decimal = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
                if (inputtxt.value.match(decimal)) {
                    return true;
                } else {
                    Swal.fire('',
                        'Password should be 8 digits,contains upperCase letter,lowerCase letter,and a special Character',
                        'warning');
                    $("#user_password").val('');
                    return false;
                }
            }
        }

        function phonenumber(inputtxt) {
            var phoneno = /^\d{10}$/;
            if (inputtxt.value.match(phoneno)) {
                return true;
            } else {
                Swal.fire('', 'Please enter a valid mobile number.', 'warning');
                $("#mobile").val('');
                return false;
            }
        }




        $(document).on('change', '.pan', function() {

            var inputvalues = $(this).val();
            var regex = /[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
            if (!regex.test(inputvalues)) {
                console.log(inputvalues);
                $(".pan").val("");
                alert("invalid PAN no");
                return regex.test(inputvalues);
            }
        });
    </script>
    @php
        $salt = rand('1000', '9999');
        session(['salt' => $salt]);
    @endphp
    <script type="text/javascript" src="{{ asset('public/backend/js/sha.js') }}"></script>
    <script>
        // $(document).on('submit','#commonform1',function(){
        //     var salt = '{{ $salt }}';
        //     var secret = $('#password').val();
        //     var shaObj = new jsSHA("SHA-256", "TEXT");
        //     shaObj.update(secret);
        //     var hashPass = shaObj.getHash("HEX");
        //     $('#password').val(hashPass);
        //     var secretcurrent = $('#confirm_password').val();
        //     var shaObjcurrent = new jsSHA("SHA-256", "TEXT");
        //     shaObjcurrent.update(secretcurrent);
        //     var hashPasscurrent = shaObjcurrent.getHash("HEX");
        //     $('#confirm_password').val(hashPasscurrent);
        // });
    </script>
@endpush

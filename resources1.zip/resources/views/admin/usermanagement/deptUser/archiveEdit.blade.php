@extends('admin.layouts.app')
@section('content')
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Edit User</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">User Management</a></li>
                    <li class="breadcrumb-item active">Edit User</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1">Edit User</h4>
                <div class="flex-shrink-0">
                    @if (session('error'))
                    <div class="alert alert-danger">
                        {{ session('error') }}
                    </div>
                    @endif
                    @if (session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                    @endif
                    @if($errors)
                    @foreach ($errors->all() as $error)
                    <div class="alert alert-danger">{{ $error }}</div>
                    @endforeach
                    @endif
                </div>
            </div>

            <div class="card-body">
                <div class="live-preview">
                    <form action="{{ route('superadmin.usermanagement.archive.update', $user['id']) }}" class="commonform1"
                        method="POST" enctype="multipart/form-data" id="commonform1" autocomplete="off">
                        @csrf
                        <div class="row gy-4">
                           
                            <div class="row seperatesec">
                              
                                <div class="col-xxl-4 col-md-4">
                                    <div>
                                        <label class="form-label">First Name <span class="required">*</span></label>
                                        <input type="text" class="form-control" id="first_name"
                                            placeholder="First Name" name="name_of_inspector"
                                            value="{{ $user['name_of_inspector']??''}}" readonly>
                                    </div>
                                </div>
                                <div class="col-xxl-4 col-md-4 ">
                                    <div>
                                        <label for="labelInput" class="form-label">Mobile Number<span
                                                class="required">*</span></label>
                                        <input type="text" class="form-control numbersonly phone" id="mobile" required
                                            name="mobile" placeholder="Mobile Number" onblur="phonenumber(this)"
                                            maxlength="10" value="{{ $user['mobile_no']??''}}">
                                    </div>
                                </div>

                                <div class="col-xxl-4 col-md-4">
                                    <div>
                                        <label for="labelInput" class="form-label">Email Id<span
                                                class="required">*</span></label>
                                        <input type="email" class="form-control validateEmail" id="email" name="email"
                                            placeholder="Email Id*" value="{{ $user['email']??''}}" required>
                                    </div>
                                </div>

                                

                                <div class="row">
                                    <div class="col-lg-12 gy-4">
                                        <div class="hstack gap-2">
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                            <button type="button" class="btn btn-soft-success">Cancel</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@push('script')
<script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
<script type="text/javascript">
$("#commonform1").validate({
    rules: {
        // user_password: { 
        // 	required: true,
        // 	minlength: 8,
        // 	maxlength: 10,
        // } ,
        mobile: {
            required: true,
        }
    },
    messages: {
        // user_password: { 
        // 	required:"This field is required and should be 8 digits, contains upper,lowerCase,and a special Character"   
        // },
        mobile: {
            required: "This field is required",
        }
    }

});

function CheckPassword(inputtxt) {
    if (inputtxt.value.length > 0) {
        var decimal = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
        if (inputtxt.value.match(decimal)) {
            return true;
        } else {
            Swal.fire('',
                'Password should be 8 digits,contains upperCase letter,lowerCase letter,and a special Character',
                'warning');
            $("#user_password").val('');
            return false;
        }
    }
}

function phonenumber(inputtxt) {
    var phoneno = /^\d{10}$/;
    if (inputtxt.value.match(phoneno)) {
        return true;
    } else {
        Swal.fire('', 'Please enter a valid mobile number.', 'warning');
        $("#mobile").val('');
        return false;
    }
}
</script>
@php
$salt = rand('1000','9999');
session(['salt' => $salt]);
@endphp
<script type="text/javascript" src="{{ asset('public/backend/js/sha.js') }}"></script>
<script>
// $(document).on('submit','#commonform1',function(){
//     var salt = '{{ $salt }}';
//     var secret = $('#password').val();
//     var shaObj = new jsSHA("SHA-256", "TEXT");
//     shaObj.update(secret);
//     var hashPass = shaObj.getHash("HEX");
//     $('#password').val(hashPass);
//     var secretcurrent = $('#confirm_password').val();
//     var shaObjcurrent = new jsSHA("SHA-256", "TEXT");
//     shaObjcurrent.update(secretcurrent);
//     var hashPasscurrent = shaObjcurrent.getHash("HEX");
//     $('#confirm_password').val(hashPasscurrent);
// });
</script>
@endpush
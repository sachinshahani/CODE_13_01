@extends('admin.layouts.app')

@section('content')
<style>
    .wrapper {
        max-width: 1240px;
        margin: 0 auto;
    }

    .white-bg {
        background-color: white;
        /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
        border-bottom: 5px solid #ff9800;
        margin-bottom: 15px;
    }

    .auth-one-bg .slide .carousel-indicators {
        bottom: 25px;
    }

    .auth-page-wrapper .auth-page-content {
        padding-bottom: 0px !important;
    }

    .auth-page-content .card {
        margin-bottom: 0rem;
    }

    .data-tabs .wrapper .nav-tabs button {
        font-size: 17px;
        color: black;
    }

    .data-tabs .wrapper .nav-tabs .active {
        background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
        */ color: white;
        background: orange;
        border-radius: 0px;
    }

    .carousel-caption.d-none.d-md-block {
        background-color: #000000bf;
        left: 0;
        width: 100%;
        bottom: 0;
    }

    .carousel-indicators {
        display: none;
    }

    .custom-banner-caption {
        color: white !important;
    }

    .announcement-heading {
        font-size: 1.2em;
        font-weight: 600;
    }

    .data-tabs .tab-pane ul li {
        font-size: 1em;
        padding: 5px 0;

    }

    .main-logo {
        padding: 10px;
    }

    .data-tabs .nav-item .nav-link {
        background-image: none;
    }

    /* .right-sec{
    box-shadow: 5px 10px 18px #888888;
} */
    .navbar-brand-box {
        background: #fff;
    }

    .btn-danger {
        background-color: #40895a;
        border: 1px solid #40895a;
    }

    [data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
        color: white !important;
    }

    .header-buttons .btn-primary {
        margin-right: 10px;
        padding: 6px 15px;
        font-weight: 600;
        background-color: #207005;
        border: none;
        box-shadow: 0px 2px 7px #888888;
    }

    .header-buttons .btn-secondary {
        margin-right: 10px;
        padding: 6px 15px;
        font-weight: 600;
        background-color: #72a055;
        border: none;
        box-shadow: 0px 2px 7px #888888;
    }


    .right-sec {
        border-left: 5px solid #ede7e7;
    }

    .tabdiv {
        background: white;
        padding: 20px;
        margin-top: 10px;
        border: 10px solid #dfdbd5;
    }

    .nav-tabs {
        border-bottom: 0px;
    }

    div#myTabContent {
        border: 1px solid #cccccc;
    }

    .frontfooter footer {
        padding: 20px calc(1.5rem / 2);
        position: static;
        color: #000;
        height: 60px;
        background-color: #f9f9f9;
        margin-top: 30px;
        border-top: 1px solid #e1dfdf;
    }

    span.logo-sm img {
        width: 69px;
    }

    .seperatesec {
        margin-top: 20px;
    }

    .simplebar-content li.nav-item:hover {
        background: #4caf50;
    }

    .sectitle {
        font-size: 14px;
    }

    .required {
        color: red;
    }

    .customtextarea {
        height: 120px;
    }

    ul.boxsection {
        margin: 0;
        padding: 0;
    }

    ul.boxsection li {
        list-style-type: none;
        padding: 7px 0;
        border-bottom: 1px solid #efeded;
    }

    .boxcard .col:nth-child(1) {
        background: #effcfb;
    }

    .boxcard .col:nth-child(2) {
        background: #fdfdfd;
    }

    .boxcard .col:nth-child(3) {
        background: #effcfb;
    }

    .boxcard .col:nth-child(4) {
        background: #fdfdfd;
    }

    .boxcard .col:nth-child(5) {
        background: #effcfb;
    }

    /* --registration-form css  */
    .custom-tab-content {
        padding-top: 0 !important;
        padding-bottom: 0px !important;
    }

    .custom-tab-nav {
        background: white;

    }

    .custom-tab-nav .nav-link {
        border-radius: 0 !important;
        border-bottom: 1px solid #e9ebec;
        border-right: 1px solid #e9ebec;
        font-size: 14px;
        padding: 10px;
    }

    .custom-tab-nav .nav-link.active,
    .custom-tab-nav .show>.nav-link {
        color: rgb(255, 255, 255) !important;
        background-color: #2c8c6d;
        border-bottom: #2c8c6d !important;
        /* border-bottom: #207005 !important; */
        position: relative;
    }

    .custom-tab-nav .nav-link:hover,
    .custom-tab-nav .nav-link:focus {
        border-bottom: 1px solid #207005;
        border-radius: 0;
        font-size: 14px;
        transition: background-color 0.20s linear;
    }

    .custom-tab-nav .nav-link.active:after {
        content: "";
        position: absolute;
        bottom: -16px;
        left: 50%;
        border: 8px solid transparent;
        border-top-color: #2c8c6d;
        z-index: 999;
    }

    .reg-form-btns {
        margin-bottom: 15px;
    }

    .reg-form-btns .btn-secondary {
        color: #fff;
        background-color: #405189;
        border-color: #405189;
    }

    .btn-soft-success:active,
    .btn-soft-success:focus,
    .btn-soft-success:hover {
        border: none;
    }

    .custom-tab-nav ul {
        padding: 0px;
        margin: 0px;
    }

    .custom-tab-nav ul li {
        padding: 0px;
        margin: 0px;
        display: inline-block;
        list-style: none;
    }
</style>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0"> वन फ़सल काटने वाले की प्रोफ़ाइल/Wild Harvester Profile </h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Wild Harvester Profile</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <form method="post" enctype="multipart/form-data" id="registration"
            action="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserStore',$id) }}">
            @csrf
            <input type="hidden" name="ref_operator_type_id" value="{{$harvester->ref_operator_type_id}}">
            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                    <a class="nav-link active" id="step1-tab"
                        href="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserAdd',$id) }}">General
                        Details</a>
                    <a class="nav-link" id="step2-tab"
                        href="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep2',$id) }}">Bank
                        Details</a>
                    <a class="nav-link" id="step3-tab"
                        href="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep3',$id) }}">Forest
                        Details</a>
                    <a class="nav-link" id="step4-tab"
                        href="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep4',$id) }}">Geo Tagging
                        of Permitted Forest Area</a>
                    <a class="nav-link" id="step5-tab"
                        href="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep5',$id) }}">Details of
                        Forest Product</a>
                    <a class="nav-link" id="step6-tab"
                        href="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep6',$id) }}">List of
                        Documents</a>
                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">
                        <!-- <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1">
                                Contact Person Details
                            </h4>

                        </div> -->
                        <!-- end card header -->
                        <div class="card-body">
                            <div class="live-preview">

                                <div class="row seperatesec white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label blue-ht">वन कटाईकर्ता का विवरण/General Details<span
                                                class="required">*</span></label>
                                    </div>
                                    <hr>


                                    <div class="col-xxl-3 col-md-6 mt-1">
                                        <div>
                                            <label class="form-label">पैन / PAN</label>
                                            <input type="text" class="form-control" id="user_name"
                                                placeholder="User Name" name="user_name"
                                                value="{{ ($harvester) ? $harvester->user_name : '' }}" readonly>
                                        </div>
                                    </div>

                                    <div class="col-xxl-3 col-md-6 mt-1">
                                        <div>
                                            <label class="form-label">वन उत्पादक का पहला नाम/Wild Harvester Name</label>
                                            <input type="text" class="form-control" id="first_name"
                                                placeholder="First Name" name="first_name"
                                                value="{{ ($harvester) ? $harvester->first_name : '' }} {{ ($harvester) ? $harvester->middle_name : '' }} {{ ($harvester) ? $harvester->last_name : '' }}" readonly>
                                        </div>
                                    </div>

                                    <!-- <div class="col-xxl-3 col-md-6 mt-1">
                                        <div>
                                            <label class="form-label">वन उत्पादक का मध्य नाम/Wild Harvester Middle Name</label>
                                            <input type="text" class="form-control" id="middle_name"
                                                placeholder="Middle Name" name="middle_name"
                                                value="{{ ($harvester) ? $harvester->middle_name : '' }}">
                                        </div>
                                    </div> -->

                                    <!-- <div class="col-xxl-3 col-md-6 mt-1">
                                        <div>
                                            <label class="form-label">वन उत्पादक का अंतिम नाम/Wild Harvester Last Name</label>
                                            <input type="text" class="form-control" id="last_name" name="last_name"
                                                placeholder="Last Name"
                                                value="{{ ($harvester) ? $harvester->last_name : '' }}">
                                        </div>
                                    </div> -->

                                    <!-- <div class="col-xxl-3 col-md-6 mt-1">
                                        <div>
                                            <label class="form-label">लिंग/Gender<span style="color:red;">*</span></label>
                                            <select class="form-select" name="gender" required disabled>
                                                <option value="">--Select--</option>
                                                @foreach(getGenderName() as $key=> $gender)
                                                <option value="{{ $key}}" @if($harvester->gender ==
                                                    $key) selected @endif>{{$gender}}</option>
                                                @endforeach
                                            </select>
                                                @if($errors->has('gender'))
                                            <div class="error text-danger">{{ $errors->first('gender') }}</div>
                                            @endif 
                                        </div>
                                    </div> -->
                                    <!-- <div class="col-xxl-3 col-md-6 mt-1">
                                        <div>
                                            <label class="form-label">वन लाइसेंस नंबर / Forest License No <span style="color:red;">*</span></label>
                                            <input type="text" class="form-control forest_license_number" id="forest_license_number"
                                                placeholder="Forest License Number" name="forest_licence"
                                                value="{{$harvester->forest_licence ?? ''}}" readonly>
                                            @if($errors->has('gender'))
                                            <div class="error text-danger">{{ $errors->first('gender') }}</div>
                                            @endif 
                                        </div>
                                    </div> -->

                                    <!-- <div class="col-xxl-4 col-md-6 gy-3">
                                        <div>
                                            <label class="form-label">पिता का पहला नाम/Father's First Name</label>
                                            <input type="text" class="form-control" id="father_first_name"
                                                placeholder="First Name" value="{{$harvester->getWildHarvesterDetail->father_first_name ?? '' }}" name="father_first_name" readonly >
                                        </div>
                                    </div>

                                    <div class="col-xxl-4 col-md-6 gy-3">
                                        <div>
                                            <label class="form-label">पिता का मध्य नाम/Father's Middle Name</label>
                                            <input type="text" class="form-control" id="father_middle_name"
                                                placeholder="Middle Name" value="{{$harvester->getWildHarvesterDetail->father_middle_name ?? '' }}" name="father_middle_name" readonly>
                                        </div>
                                    </div>

                                    <div class="col-xxl-4 col-md-6 gy-3">
                                        <div>
                                            <label class="form-label">
                                                पिता का अंतिम नाम/Father's Last Name</label>
                                            <input type="text" class="form-control" id="father_last_name"
                                                name="father_last_name" value="{{$harvester->getWildHarvesterDetail->father_last_name ??'' }}" placeholder="Last Name" readonly>
                                        </div>
                                    </div> -->
                                </div>

                                <!-- End New fields as per new Database -->

                                <div class="row seperatesec white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label blue-ht">पता/Address</label>
                                    </div>
                                    <hr>
                                    <div class="col-xxl-3 col-md-3">
                                        <div class="row">
                                            <div class="col-xx-12 col-md-12">
                                                <label for="labelInput" class="form-label ">पता/Address <span
                                                        class="required">*</span></label>
                                                <textarea class="form-control customtextarea" required name="address" readonly>{{ ($harvester) ? $harvester->address : '' }}</textarea>
                                                <!-- @if($errors->has('address'))
                                                <div class="error text-danger">{{ $errors->first('address') }}</div>
                                                @endif -->
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xxl-9 col-md-9">
                                        <div class="row">
                                            <div class="col-xxl-4 col-md-4 mt-1">
                                                <label for="labelInput" class="form-label">राज्य/State<span
                                                        class="required">*</span></label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" value="{{getStateNameById($harvester->ref_state_id)}}" name="state" readonly="" required>
                                                    {{-- <select class="form-select state" name="state" required readonly>
                                                        <option value="">Select State</option>
                                                        @if(isset($states))
                                                        @forelse($states as $state)
                                                        <option value="{{$state->id}}" @if($harvester->ref_state_id ==
                                                    $state->id) selected @endif>{{$state->state_name}}</option>
                                                    @empty
                                                    @endforelse
                                                    @endif

                                                    </select>--}}

                                                </div>
                                                <!-- @if($errors->has('state'))
                                                <div class="error text-danger">{{ $errors->first('state') }}</div>
                                                @endif -->
                                            </div>

                                            <div class="col-xxl-4 col-md-4 mt-1">
                                                <label for="labelInput" class="form-label">जिला/District <span
                                                        class="required">*</span></label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" value="{{getDistrictNameById($harvester->ref_district_id)}}" name="district" readonly="" required>
                                                    {{-- <select class="form-select district" name="district" required> 
                                                        <option value="">Select District</option>
                                                        @if(isset($districts))
                                                        @forelse($districts as $district)
                                                        <option value="{{$district->id}}"
                                                    {{ ($harvester && $harvester->ref_district_id == $district->id) ? 'selected' : '' }}>
                                                    {{$district->district_name}}</option>
                                                    @empty
                                                    @endforelse
                                                    @endif
                                                    </select>--}}

                                                </div>
                                                <!-- @if($errors->has('district'))
                                                <div class="error text-danger">{{ $errors->first('district') }}</div>
                                                @endif -->
                                            </div>


                                            <div class="col-xxl-4 col-md-4 mt-1">
                                                <label for="labelInput" class="form-label">तहसील/मंडल/Taluka/Mandal <span
                                                        class="required">*</span></label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" value="{{getBlockTehsilByID($harvester->ref_block_tehsil_id)}}" name="taluka" readonly="" required>
                                                    {{--<select class="form-select block_tehsil" name="taluka" required>
                                                        <option value="">Select Taluka/Mandal</option>
                                                        @if(isset($regions))
                                                        @forelse($regions as $region)
                                                        <option value="{{$region->id}}" @if($harvester->
                                                    ref_block_tehsil_id == $region->id) selected
                                                    @endif>{{$region->block_tehsil_name}}</option>
                                                    @empty
                                                    @endforelse
                                                    @endif
                                                    </select>--}}

                                                </div>
                                                <!-- @if($errors->has('taluka'))
                                                <div class="error text-danger">{{ $errors->first('taluka') }}</div>
                                                @endif -->
                                            </div>


                                            <div class="col-xxl-6 col-md-6 mt-3">
                                                <label for="labelInput" class="form-label">गांव/Village <span
                                                        class="required">*</span></label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" value="{{getVillageNameById($harvester->ref_village_id)}}" name="village" readonly="" required>
                                                    {{--<select class="form-select village" name="village" required>
                                                        <option value="">Select Village</option>
                                                        @if(isset($villages))
                                                        @forelse($villages as $village)
                                                        <option value="{{$village->id}}" @if($harvester->ref_village_id
                                                    == $village->id) selected @endif>{{$village->village_name}}
                                                    </option>
                                                    @empty
                                                    @endforelse
                                                    @endif
                                                    </select>--}}

                                                </div>
                                                <!-- @if($errors->has('village'))
                                                <div class="error text-danger">{{ $errors->first('village') }}</div>
                                                @endif -->
                                            </div>

                                            <div class="col-xxl-6 col-md-6 mt-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">पिन कोड/Pin Code<span
                                                            class="required">*</span></label>
                                                    <input type="text" class="form-control numbersonly" id="pin_code"
                                                        name="pin_code" value="{{ ($harvester) ? $harvester->pin : '' }}" placeholder="Pin Code" maxlength="6" required readonly>
                                                    <!-- @if($errors->has('pin_code'))
                                                    <div class="error text-danger">{{ $errors->first('pin_code') }}
                                                    </div>
                                                    @endif -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                </div>
                                <div class="row seperatesec white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label blue-ht">वन उत्पादक के संपर्क विवरण/Contact Details of Wild Harvest</label>
                                    </div>
                                    <hr>
                                    <div class="col-xxl-3 col-md-6 mt-1">
                                        <div>
                                            <label class="form-label">मोबाइल नंबर/Mobile No.<span
                                                    class="required">*</span></label>
                                            <input type="text" class="form-control numbersonly" id="mobile_number" maxlength="10"
                                                placeholder="Mobile Number" value="{{ ($harvester) ? $harvester->contact_person_mobile_number : '' }}" name="mobile_number" readonly required>
                                            <!-- @if($errors->has('mobile_number'))
                                            <div class="error text-danger">{{ $errors->first('mobile_number') }}</div>
                                            @endif -->
                                        </div>
                                    </div>

                                                    @php
                                                   
                                                        $maskedAadhar = '';
                                                        try {
                                                            if ($harvester->contact_person_aadhar_number) {
                                                                $decryptedAadhar = Crypt::decrypt(
                                                                    $harvester->contact_person_aadhar_number,
                                                                );
                                                                $maskedAadhar = maskAadhaarNumber($decryptedAadhar);
                                                            }
                                                        } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
                                                            $maskedAadhar = 'Invalid Aadhaar Number';
                                                        }
                                                    @endphp
                                    

                                    <div class="col-xxl-3 col-md-6 mt-1">
                                        <div>
                                            <label class="form-label">आधार नंबर/Aadhaar No. <span
                                                    class="required">*</span></label>
                                            <input type="text" class="form-control numbersonly" id="aadhar_number" maxlength="12"
                                                name="" value="{{$maskedAadhar}}" placeholder="Aadhar Number" readonly required>
                                            <!-- @if($errors->has('aadhar_number'))
                                            <div class="error text-danger">{{ $errors->first('aadhar_number') }}</div>
                                            @endif -->
                                        </div>
                                    </div>

                                    <!-- <div class="col-xxl-3 col-md-6 mt-1">
                                        <div>
                                            <label class="form-label">Pan Number <span class="required">*</span></label>
                                            <input type="text" class="form-control pan" value="{{ ($harvester) ? $harvester->contact_person_pan_number : '' }}" id="pan_number" readonly  name="pan_number"
                                                placeholder="ABCTY1234D" required>
                                            @if($errors->has('pan_number'))
                                            <div class="error text-danger">{{ $errors->first('pan_number') }}</div>
                                            @endif
                                        </div>
                                    </div> -->

                                    <div class="col-xxl-3 col-md-6 mt-1">
                                        <div>
                                            <label class="form-label">ईमेल आईडी/Email Id <span class="required">*</span></label>
                                            <input type="email" class="form-control" value="{{ ($harvester) ? $harvester->contact_person_email : '' }}" id="email_id" readonly name="email_id"
                                                placeholder="Email Id" required>
                                            <!-- @if($errors->has('email_id'))
                                            <div class="error text-danger">{{ $errors->first('email_id') }}</div>
                                            @endif -->
                                        </div>
                                    </div>
                                    <div class="col-xxl-3 col-md-6 mt-1">
                                        <!-- <div>
                                            <label class="form-label">कलेक्टरों की संख्या/No. of collectors<span
                                                    class="required">*</span></label>
                                            <input type="text" class="form-control numbersonly" id="no_of_collectors"
                                                name="no_of_collectors" value="{{ ($harvester) ? $harvester->no_of_collectors : '' }}" placeholder="No. of collectors" required>
                                             @if($errors->has('no_of_collectors'))
                                            <div class="error text-danger">{{ $errors->first('no_of_collectors') }}
                                            </div>
                                            @endif
                                        </div> -->
                                        <div>
                                            <label class="form-label">संपर्ककर्ता का पदनाम/Designation of Contact Person<span
                                                    class="required">*</span></label>
                                            <select name="contact_designation" class="form-select" disabled>
                                                <option value="">Select Designation</option>
                                                <option value="Manager" <?php if ($harvester->contact_designation == 'Manager') {
                                                                            echo 'selected';
                                                                        } else {
                                                                            echo '';
                                                                        } ?>>Manager</option>
                                            </select>
                                            <!-- @if($errors->has('no_of_collectors'))
                                            <div class="error text-danger">{{ $errors->first('no_of_collectors') }}
                                            </div>
                                            @endif -->
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12 gy-4">
                                            <div class="hstack gap-2">
                                                <!-- <input type="submit" class="btn btn-primary" value="Submit"> -->
                                                <a href="{{route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep2',$id)}}"
                                                    class="btn btn-soft-success">
                                                    Next
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </form>
    </div>
</div>



@endsection
@push('script')

<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $("#registration").validate({
        rules: {

        },
        messages: {

        }

    });
    $(document).on('change', '.pan', function() {

        var inputvalues = $(this).val();
        var regex = /[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
        if (!regex.test(inputvalues)) {
            console.log(inputvalues);
            $(".pan").val("");
            alert("invalid PAN no");
            return regex.test(inputvalues);
        }
    });
    // Dropzone has been added as a global variable.
    const dropzone = new Dropzone("div.dropzone", {
        url: "{{ route('storeMedia') }}",
        paramName: "file",
        maxFilesize: 2,
        maxFiles: 1,
        acceptedFiles: ".jpeg,.jpg,.png,.mp4,.webm,.html5",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        init: function() {
            var drop = this; // Closure
            this.on('error', function(file, errorMessage) {
                if (errorMessage.indexOf('Error 404') !== -1) {
                    var errorDisplay = document.querySelectorAll('[data-dz-errormessage]');
                    errorDisplay[errorDisplay.length - 1].innerHTML =
                        'Error 404: The upload page was not found on the server';
                }
                if (errorMessage.indexOf('File is too big') !== -1) {
                    alert('Unable to upload image size is greated than 2 MB');
                    // i remove current file
                    drop.removeFile(file);
                }
            });
            this.on("maxfilesexceeded", function(file) {
                    this.removeAllFiles();
                    this.addFile(file);
                }),
                this.on("success", function(file, response) {
                    console.log(response);
                    var hiddenImage = $('<input type="hidden" name="_hidden_legal_doc_upload" value="' +
                        response.name + '"/>');
                    $('.hidden_images_area').html(hiddenImage);
                })
        }
    });
</script>

@endpush
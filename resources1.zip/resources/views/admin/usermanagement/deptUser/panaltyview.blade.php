@extends('admin.layouts.app')
@section('content')


<style>
body {
    margin: 0px;
    padding: 0px;
    font-family: "Segoe UI";
}

.maindiv {
    width: 80%;
    margin: 0 auto;
}

.pdf_maindiv {
    border: 1px solid #cccccc;
    width: 100%;
    float: left;
    padding: 2% 1%;
}

.pdf_heading {
    font-size: 20px;
    color: #000;
    padding: 26px 0 20px 0px;
    position: relative;
    width: 100%;
    float: left;
}

.brd_heading {
    border-bottom: 2px solid #ee5e24;
    padding-bottom: 8px;
    padding-right: 8px;
    width: 60px;
}

.pdf_input1 {
    background: #eeeeee;
}

.pdf_txt1 {
    color: #000;
    font-size: 14px;
    width: 45%;
    float: left;
    padding-bottom: 10px;
    font-weight: bold;
}

.pdf_box {
    color: #000;
    font-size: 14px;
    width: 55%;
    float: left;
    padding-bottom: 10px;
}

@keyframes blink-animation {
    0% {
        opacity: 1;
    }

    50% {
        opacity: 0;
    }

    100% {
        opacity: 1;
    }
}

.table_pdf {
    width: 100%;
}

.pdf_heading:after {
    content: "";
    position: absolute;
    width: 70px;
    height: 2px;
    background-color: #ee5e24;
    bottom: 10px;
    display: block;
}

.pdf_heading:before {
    content: "";
    position: absolute;
    width: 22px;
    height: 6px;
    background-color: #ee5e24;
    bottom: 8px;
    display: block;
}

#step1 .card-body {
    background: #fff
}

.pdf_inner_heading:after {
    display: none;
}

.pdf_inner_heading:before {
    display: none;
}

.pdf_inner_heading {
    padding: 20px 0 12px;
    text-decoration: underline;
    font-size: 16px;
}

.pdf_maindiv hr:last-child {
    display: none;
}

.pdf-img-icon {
    height: 17px;
    width: 15px;
    margin-right: 5px;
}

@media print {

    .pdf_heading {
        font-size: 20px;
        color: #000;
        padding: 26px 0 20px 0px;
        position: relative;
        width: 100%;
        float: left;
        -webkit-print-color-adjust: exact !important;
        Chrome,
        Safari color-adjust: exact !important;
    }

    .pdf_heading:before {
        content: "";
        position: absolute;
        width: 20px;
        height: 4px;
        background-color: #ee5e24;
        bottom: 10px;
        display: block;
        -webkit-print-color-adjust: exact !important;
        Chrome,
        Safari color-adjust: exact !important;
    }


}
</style>
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">View Registration</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">View Registration</li>
                </ol>
            </div>

        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">

        <div class="tab-content py-4 custom-tab-content">
            <div class="tab-pane fade show active" id="step1">
                <div class="card">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1">
                            {{ user_name($user->id) ?? '' }}
                        </h4>

                        <div class="flex-shrink-0  {{(($user->status == 2 || $user->status == 4)? 'flex-grow-1':'')}}">
                            <label for="basiInput"
                                class="form-label">{{ ($user->status == 2? 'Registration Number : '.$user->registration_no:"Application Number : #00".$user->id)}}</label>
                        </div>
                        @if($user->status == 2)
                        <div class="flex-shrink-0 ">
                            <label for="basiInput" class="form-label">Registration Certificate : <a target="_BLANK"
                                    href="{{ asset('public/' . $user->registration_certificate) }}"
                                    class="text-decoration-underline"><img
                                        src="{{ asset('public/assets/images/pdf-icon.png')}}" alt="" height="17px"
                                        class="pdf-img-icon">See Doc</a></label>
                        </div>
                        @endif





                        @if ($user->status == 0 || $user->status == 4)
                        <div class="flex-shrink-0">
                            <a href="{{ route('superadmin.icsuser.step1', $user->id) }}"
                                class="btn btn-soft-success">Back</a>

                        </div>
                        @endif
                    </div>

                    <!-- end card header -->
                    <div class="card-body">

                        <div class="pdf_heading">Personal Details</div>
                        <div class="pdf_maindiv">
                            <!--form1 section starts here-->
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                            <tr>
                                                <td class="pdf_txt1">Operator Name :</td>
                                                <td class="pdf_box">{{ user_name($user->id) ?? '' }}</td>
                                            </tr>
                                            {{-- <tr>
                                                        <td class="pdf_txt1">Status</td>
                                                        <td class="pdf_box">{{ $user->standerd_type ??''}}</td>
                                            </tr>
                                            --}}

                                        </table>
                                        <!--form1 tab end here-->
                                    </div>


                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">

                                            <tr>
                                                <td class="pdf_txt1">Email:</td>
                                                <td class="pdf_box">{{ $user->user_name ?? '' }}</td>
                                            </tr>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="pdf_heading">Status Details</div>
                        <div class="pdf_maindiv">
                            <!--form1 section starts here-->
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                            <tr>
                                                <td class="pdf_txt1">Form Date:</td>
                                                <td class="pdf_box">{{ $user->from_date }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Status :</td>
                                                <td class="pdf_box"
                                                    style="color: <?php echo ($user->operator_status == 1) ? '#f50707' : 'black'; ?>; animation: blink-animation <?php echo ($user->operator_status == 1) ? '1s infinite' : 'initial'; ?>;">
                                                    <?php
    if ($user->operator_status == 1) {
        echo 'Suspended';
    } elseif($user->operator_status == 2) {
        echo 'Terminate';
    } elseif($user->operator_status == 3) {
        echo 'Withdrawal By CB';
    } elseif($user->operator_status == 4) {
        echo 'Withdrawal By Operator';
    } elseif($user->operator_status == 5) {
        echo 'De-d Register';
    }
    ?>
                                                </td>
                                            </tr>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>

                                    <div class="col-6">

                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                            <tr>
                                                <td class="pdf_txt1">To Date:</td>
                                                <td class="pdf_box">{{ $user->to_date }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Report none complain:</td>
                                                <td class="pdf_box">{{ $user->remark }}</td>
                                            </tr>

                                        </table>
                                        <!--form1 tab end here-->
                                    </div>


                                </div>
                            </div>
                        </div>
                        <div class="pdf_heading">ICS Address</div>
                        <div class="pdf_maindiv">
                            <!--form1 section starts here-->
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                            <tr>
                                                <td class="pdf_txt1">State</td>
                                                <td class="pdf_box">{{ getStateName($user->ref_state_id) }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">District</td>
                                                <td class="pdf_box">{{ getDisName($user->ref_district_id) }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Taluka/Mandal</td>
                                                <td class="pdf_box">{{ getTalukName($user->ref_block_tehsil_id) }}</td>
                                            </tr>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>

                                    <div class="col-6">

                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                            <tr>
                                                <td class="pdf_txt1">Village</td>
                                                <td class="pdf_box">{{ getVillName($user->ref_village_id) }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Pin Code</td>
                                                <td class="pdf_box">{{ $user->pin ?? '' }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Address</td>
                                                <td class="pdf_box">{{ $user->address ?? '' }}</td>
                                            </tr>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>


                                </div>
                            </div>
                        </div>
                        <div class="pdf_heading">Contact Person Details</div>
                        <div class="pdf_maindiv">
                            <!--form1 section starts here-->
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                            <tr>
                                                <td class="pdf_txt1">First Name</td>
                                                <td class="pdf_box"> {{ $user->contact_person_first_name ?? '' }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Last Name</td>
                                                <td class="pdf_box"> {{ $user->contact_person_last_name ?? '' }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Email Id</td>
                                                <td class="pdf_box" colspan=2>{{ $user->contact_person_email ?? '' }}
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Gender</td>
                                                <td class="pdf_box">
                                                    @if ($user->contact_gender == 1)
                                                    Male
                                                    @elseif($user->contact_gender == 2)
                                                    Female
                                                    @else
                                                    other
                                                    @endif
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Address proof of ICS Manager</td>
                                                <td class="pdf_box">
                                                    @if ($user->address_proof_of_office == 'electricity_bill')
                                                    Electricity Bill
                                                    @elseif($user->address_proof_of_office == 'water_bill')
                                                    Water Bill
                                                    @elseif($user->address_proof_of_office == 'rent_agreement')
                                                    Rent Agreement
                                                    @else
                                                    N/A
                                                    @endif
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Number of Farmers</td>
                                                <td class="pdf_box">{{ $user->no_of_farmers ?? '' }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Managed by</td>
                                                <td class="pdf_box">{{ $user->managed_by ?? '' }}</td>
                                            </tr>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>

                                    <div class="col-6">

                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                            <tr>
                                                <td class="pdf_txt1">Middle Name</td>
                                                <td class="pdf_box"> {{ $user->contact_person_middle_name ?? '' }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Contact No.</td>
                                                <td class="pdf_box">{{ $user->contact_person_mobile_number ?? '' }}
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Aadhar number</td>
                                                <td class="pdf_box">{{ $user->contact_person_aadhar_number ?? '' }}
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Designation of Contact Person</td>
                                                <td class="pdf_box">{{ $user->contact_designation ?? '' }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Address Proof Doc</td>
                                                <td class="pdf_box">
                                                    @if (!empty($user->address_proof_of_office_doc))
                                                    <a target="_BLANK"
                                                        href="{{ asset('public/ics/address_proof_of_office_doc/' . $user->address_proof_of_office_doc) }}"
                                                        class="text-decoration-underline"><img
                                                            src="{{ asset('public/assets/images/pdf-icon.png')}}" alt=""
                                                            class="pdf-img-icon">See Doc</a>
                                                    @else
                                                    Not Available
                                                    @endif
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Number of Inspector</td>
                                                <td class="pdf_box">{{ $user->no_of_inspector ?? '' }}</td>
                                            </tr>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

</div>
</div>
@endsection

@push('script')
<script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
<script>
$(document).on('click', '#submitbtn', function() {

    if (checkValidation("registration")) {
        $('#registration').submit();
        return true;
    } else {
        return false;
    }
});
</script>
@endpush
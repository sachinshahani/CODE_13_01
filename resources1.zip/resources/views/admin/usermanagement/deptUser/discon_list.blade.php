@extends('admin.layouts.app')

@section('content')
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">
                     List of Discontinued Operators
                </h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        {{-- <li class="breadcrumb-item"><a href="javascript: void(0);"> User Management</a></li> --}}
                        <li class="breadcrumb-item active">

                              List of Discontinued Operators

                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0" style="float: left">


                       List of Discontinued Operators

                    </h5>

                   
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="deptUser" class="table table-bordered table-striped align-middle" style="width:100%">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Application Details</th>
                                    <th>Registration Details</th>
                                    <th>Operator Details</th>
                                    <th>Operator Type</th>
                                    <th>Scope Certificate</th>
                                    <th>Discontinue Date</th>
                                    <th>Contact Person Details</th>
                                    <th>State</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!--end col-->
    </div>
@endsection

@push('script')
    <script>
        $("#search").on('change', function(e) {
            table.ajax.reload(); // Reload the table data
            e.preventDefault();
        });

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        var table = $('#deptUser').DataTable({
            dom: 'Bfrtip',
            lengthMenu: [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
            ],
            processing: true,
            serverSide: true,
            ajax: {
                url: '{{ route('superadmin.usermanagement.discon') }}',
                type: 'GET',
                data: function(d) {
                    d._token = "{{ csrf_token() }}";
                    d.operator_status = $("#search").val();
                    // Send operator_status parameter
                }
            },

            columns: [{
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex',
                    orderable: true
                },
                {
                    data: 'app_no',
                    name: 'app_no',
                    orderable: true
                },
                {
                    data: 'reg_details',
                    name: 'reg_details',
                    orderable: true
                },
                {
                    data: 'opr_details',
                    name: 'opr_details',
                    orderable: true
                },
                {
                    data: 'ref_operator_type_id',
                    name: 'ref_operator_type_id',
                    orderable: true
                },
                {
                    data: 'scp_no',
                    name: 'scp_no',
                    orderable: true
                },
                
               
                {
                    data: 'created_on',
                    name: 'created_on',
                    orderable: true
                },

                {
                    data: 'contact_details',
                    name: 'contact_details',
                    orderable: true
                },
                {
                    data: 'ref_state_id',
                    name: 'state',
                    orderable: true
                },
                // {
                //     data: 'action',
                //     name: 'name',
                //     orderable: false
                // },
            ],
            buttons: [

                {
                    extend: 'excelHtml5',
                    title: function() {
                        return "Operator Discontinued  List";
                    },
                    titleAttr: 'CSV REPORTS'
                },
                {
                    extend: 'pdfHtml5',
                    title: function() {
                        return "Operator Discontinued  List";
                    },
                    orientation: 'landscape',
                    pageSize: 'A4',
                    titleAttr: 'Operator Discontinued  List'
                }
            ]
        });
    </script>
@endpush
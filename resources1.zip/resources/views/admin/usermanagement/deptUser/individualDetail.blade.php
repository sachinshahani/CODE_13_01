@extends('admin.layouts.app')

@section('content')
    <style>
        /* email verification css */
        .overlay {
            background: rgb(0 0 0 / 50%);
            position: fixed;
            top: 0;
            z-index: 11111;
            left: 0;
            right: 0;
            bottom: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            display: none;
        }

        .loader {
            position: fixed !important;
            left: 50% !important;
            margin-left: -4em !important;
            top: 20em !important;
        }

        .wrapper {
            max-width: 1240px;
            margin: 0 auto;
        }

        .white-bg {
            background-color: white;
            /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
            border-bottom: 5px solid #ff9800;
            margin-bottom: 15px;
        }

        .auth-one-bg .slide .carousel-indicators {
            bottom: 25px;
        }

        .auth-page-wrapper .auth-page-content {
            padding-bottom: 0px !important;
        }

        .auth-page-content .card {
            margin-bottom: 0rem;
        }

        .data-tabs .wrapper .nav-tabs button {
            font-size: 17px;
            color: black;
        }

        .data-tabs .wrapper .nav-tabs .active {
            background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
            */ color: white;
            background: orange;
            border-radius: 0px;
        }

        .carousel-caption.d-none.d-md-block {
            background-color: #000000bf;
            left: 0;
            width: 100%;
            bottom: 0;
        }

        .carousel-indicators {
            display: none;
        }

        .custom-banner-caption {
            color: white !important;
        }

        .announcement-heading {
            font-size: 1.2em;
            font-weight: 600;
        }

        .data-tabs .tab-pane ul li {
            font-size: 1em;
            padding: 5px 0;

        }

        .main-logo {
            padding: 10px;
        }

        .data-tabs .nav-item .nav-link {
            background-image: none;
        }

        /* .right-sec{
            box-shadow: 5px 10px 18px #888888;
        } */
        .navbar-brand-box {
            background: #fff;
        }

        [data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
            color: white !important;
        }

        .header-buttons .btn-primary {
            margin-right: 10px;
            padding: 6px 15px;
            font-weight: 600;
            background-color: #207005;
            border: none;
            box-shadow: 0px 2px 7px #888888;
        }

        .header-buttons .btn-secondary {
            margin-right: 10px;
            padding: 6px 15px;
            font-weight: 600;
            background-color: #72a055;
            border: none;
            box-shadow: 0px 2px 7px #888888;
        }


        .right-sec {
            border-left: 5px solid #ede7e7;
        }

        .tabdiv {
            background: white;
            padding: 20px;
            margin-top: 10px;
            border: 10px solid #dfdbd5;
        }

        .nav-tabs {
            border-bottom: 0px;
        }

        div#myTabContent {
            border: 1px solid #cccccc;
        }

        .frontfooter footer {
            padding: 20px calc(1.5rem / 2);
            position: static;
            color: #000;
            height: 60px;
            background-color: #f9f9f9;
            margin-top: 30px;
            border-top: 1px solid #e1dfdf;
        }

        span.logo-sm img {
            width: 69px;
        }

        .seperatesec {
            margin-top: 20px;
        }

        .simplebar-content li.nav-item:hover {
            background: #4caf50;
        }

        .sectitle {
            font-size: 14px;
        }

        .required {
            color: red;
        }

        .customtextarea {
            height: 120px;
        }

        ul.boxsection {
            margin: 0;
            padding: 0;
        }

        ul.boxsection li {
            list-style-type: none;
            padding: 7px 0;
            border-bottom: 1px solid #efeded;
        }

        .boxcard .col:nth-child(1) {
            background: #effcfb;
        }

        .boxcard .col:nth-child(2) {
            background: #fdfdfd;
        }

        .boxcard .col:nth-child(3) {
            background: #effcfb;
        }

        .boxcard .col:nth-child(4) {
            background: #fdfdfd;
        }

        .boxcard .col:nth-child(5) {
            background: #effcfb;
        }

        /* --registration-form css  */
        .custom-tab-content {
            padding-top: 0 !important;
            padding-bottom: 0px !important;
        }

        .custom-tab-nav {
            background: white;

        }

        .custom-tab-nav .nav-link {
            border-radius: 0 !important;
            border-bottom: 1px solid #e9ebec;
            border-right: 1px solid #e9ebec;
            font-size: 14px;
            padding: 10px;
        }

        .custom-tab-nav .nav-link.active,
        .custom-tab-nav .show>.nav-link {
            color: rgb(255, 255, 255) !important;
            background-color: #2c8c6d;
            border-bottom: #2c8c6d !important;
            /* border-bottom: #207005 !important; */
            position: relative;
        }

        .custom-tab-nav .nav-link:hover,
        .custom-tab-nav .nav-link:focus {
            border-bottom: 1px solid #207005;
            border-radius: 0;
            font-size: 14px;
            transition: background-color 0.20s linear;
        }

        .custom-tab-nav .nav-link.active:after {
            content: "";
            position: absolute;
            bottom: -16px;
            left: 50%;
            border: 8px solid transparent;
            border-top-color: #2c8c6d;
            z-index: 999;
        }

        .reg-form-btns {
            margin-bottom: 15px;
        }

        .reg-form-btns .btn-secondary {
            color: #fff;
            background-color: #405189;
            border-color: #405189;
        }

        .btn-soft-success:active,
        .btn-soft-success:focus,
        .btn-soft-success:hover {
            border: none;
        }

        .custom-tab-nav ul {
            padding: 0px;
            margin: 0px;
        }

        .custom-tab-nav ul li {
            padding: 0px;
            margin: 0px;
            display: inline-block;
            list-style: none;
        }

        /* -------  */
        .btn-email {
            font-size: 13px;
            padding: 1px 7px;
            line-height: 17px;

        }

        .btn-mailsend {
            font-size: 13px;
            padding: 1px 7px;
            line-height: 17px;
        }

        .btn-verify {
            font-size: 13px;
            padding: 1px 7px;
            line-height: 34px;
        }

        .inputEmail .input-group-append {
            display: flex;
            align-items: end;
        }

        .inputEmail .validateEmailId {
            border-radius: 4px 0 0 4px;
        }

        .input-group-append .verifiEmail_otp,
        .input-group-append .resendEmail_otp {
            margin-left: 10px;
        }

        .login-pass.otp-email {
            margin-top: 5px
        }

        .login-pass.otp-email .inp-b {
            border-radius: 0 4px 4px 0
        }

        /* end */



        .wrapper {
            max-width: 1240px;
            margin: 0 auto;
        }

        .white-bg {
            background-color: white;
            /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
            border-bottom: 5px solid #ff9800;
            margin-bottom: 15px;
        }

        .auth-one-bg .slide .carousel-indicators {
            bottom: 25px;
        }

        .auth-page-wrapper .auth-page-content {
            padding-bottom: 0px !important;
        }

        .auth-page-content .card {
            margin-bottom: 0rem;
        }

        .data-tabs .wrapper .nav-tabs button {
            font-size: 17px;
            color: black;
        }

        .data-tabs .wrapper .nav-tabs .active {
            background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
            */ color: white;
            background: orange;
            border-radius: 0px;
        }

        .carousel-caption.d-none.d-md-block {
            background-color: #000000bf;
            left: 0;
            width: 100%;
            bottom: 0;
        }

        .carousel-indicators {
            display: none;
        }

        .custom-banner-caption {
            color: white !important;
        }

        .announcement-heading {
            font-size: 1.2em;
            font-weight: 600;
        }

        .data-tabs .tab-pane ul li {
            font-size: 1em;
            padding: 5px 0;

        }

        .main-logo {
            padding: 10px;
        }

        .data-tabs .nav-item .nav-link {
            background-image: none;
        }

        /* .right-sec{
        box-shadow: 5px 10px 18px #888888;
    } */
        .navbar-brand-box {
            background: #fff;
        }

        .btn-danger {
            background-color: #40895a;
            border: 1px solid #40895a;
        }

        [data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
            color: white !important;
        }

        .header-buttons .btn-primary {
            margin-right: 10px;
            padding: 6px 15px;
            font-weight: 600;
            background-color: #207005;
            border: none;
            box-shadow: 0px 2px 7px #888888;
        }

        .header-buttons .btn-secondary {
            margin-right: 10px;
            padding: 6px 15px;
            font-weight: 600;
            background-color: #72a055;
            border: none;
            box-shadow: 0px 2px 7px #888888;
        }


        .right-sec {
            border-left: 5px solid #ede7e7;
        }

        .tabdiv {
            background: white;
            padding: 20px;
            margin-top: 10px;
            border: 10px solid #dfdbd5;
        }

        .nav-tabs {
            border-bottom: 0px;
        }

        div#myTabContent {
            border: 1px solid #cccccc;
        }

        .frontfooter footer {
            padding: 20px calc(1.5rem / 2);
            position: static;
            color: #000;
            height: 60px;
            background-color: #f9f9f9;
            margin-top: 30px;
            border-top: 1px solid #e1dfdf;
        }

        span.logo-sm img {
            width: 69px;
        }

        .seperatesec {
            margin-top: 20px;
        }

        .simplebar-content li.nav-item:hover {
            background: #4caf50;
        }

        .sectitle {
            font-size: 14px;
        }

        .required {
            color: red;
        }

        .customtextarea {
            height: 120px;
        }

        ul.boxsection {
            margin: 0;
            padding: 0;
        }

        ul.boxsection li {
            list-style-type: none;
            padding: 7px 0;
            border-bottom: 1px solid #efeded;
        }

        .boxcard .col:nth-child(1) {
            background: #effcfb;
        }

        .boxcard .col:nth-child(2) {
            background: #fdfdfd;
        }

        .boxcard .col:nth-child(3) {
            background: #effcfb;
        }

        .boxcard .col:nth-child(4) {
            background: #fdfdfd;
        }

        .boxcard .col:nth-child(5) {
            background: #effcfb;
        }

        /* --registration-form css  */
        .custom-tab-content {
            padding-top: 0 !important;
            padding-bottom: 0px !important;
        }

        .custom-tab-nav {
            background: white;

        }

        .custom-tab-nav .nav-link {
            border-radius: 0 !important;
            border-bottom: 1px solid #e9ebec;
            border-right: 1px solid #e9ebec;
            font-size: 14px;
            padding: 10px;
        }

        .custom-tab-nav .nav-link.active,
        .custom-tab-nav .show>.nav-link {
            color: rgb(255, 255, 255) !important;
            background-color: #2c8c6d;
            border-bottom: #2c8c6d !important;
            /* border-bottom: #207005 !important; */
            position: relative;
        }

        .custom-tab-nav .nav-link:hover,
        .custom-tab-nav .nav-link:focus {
            border-bottom: 1px solid #207005;
            border-radius: 0;
            font-size: 14px;
            transition: background-color 0.20s linear;
        }

        .custom-tab-nav .nav-link.active:after {
            content: "";
            position: absolute;
            bottom: -16px;
            left: 50%;
            border: 8px solid transparent;
            border-top-color: #2c8c6d;
            z-index: 999;
        }

        .reg-form-btns {
            margin-bottom: 15px;
        }

        .reg-form-btns .btn-secondary {
            color: #fff;
            background-color: #405189;
            border-color: #405189;
        }

        .btn-soft-success:active,
        .btn-soft-success:focus,
        .btn-soft-success:hover {
            border: none;
        }

        .custom-tab-nav ul {
            padding: 0px;
            margin: 0px;
        }

        .custom-tab-nav ul li {
            padding: 0px;
            margin: 0px;
            display: inline-block;
            list-style: none;
        }
    </style>
    <div class="overlay">
        <div class="loader"></div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">व्यक्तिगत किसान/Individual Farmer</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Individual Farmer</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <form method="post" enctype="multipart/form-data" id="registration"
                action="{{ route('superadmin.usermanagement.deptUser.individualUserStore', $id) }}">
                @csrf
                <nav>
                    <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">
                        <a class="nav-link active" id="step1-tab"
                            href="{{ route('superadmin.usermanagement.deptUser.individualUserAdd', [$id]) }}">General
                            Details</a>
                        <a class="nav-link" id="step2-tab"
                            href="{{ route('superadmin.usermanagement.deptUser.individualUserAddStep2', [$id]) }}">Bank
                            Details</a>
                        <a class="nav-link" id="step3-tab"
                            href="{{ route('superadmin.usermanagement.deptUser.individualUserAddStep3', [$id]) }}">Geo
                            Tagging of Farm</a>
                        <a class="nav-link" id="step4-tab"
                            href="{{ route('superadmin.usermanagement.deptUser.individualUserAddStep4', [$id]) }}">Details
                            of standing Crop</a>
                        <a class="nav-link" id="step5-tab"
                            href="{{ route('superadmin.usermanagement.deptUser.individualUserAddStep5', [$id]) }}">Details
                            of Proposed Crop</a>
                        <a class="nav-link" id="step6-tab"
                            href="{{ route('superadmin.usermanagement.deptUser.individualUserAddStep6', [$id]) }}">List of
                            Documents</a>
                    </div>
                </nav>
                <div class="tab-content py-4 custom-tab-content">
                    <div class="tab-pane fade show active" id="step1">
                        <div class="card">
                            <div class="card-body">
                                <div class="flex-shrink-0">
                                    @if (session('error'))
                                        <div class="alert alert-danger">
                                            {{ session('error') }}
                                        </div>
                                    @endif
                                    @if (session('success'))
                                        <div class="alert alert-success">
                                            {{ session('success') }}
                                        </div>
                                    @endif
                                    @if ($errors)
                                        @foreach ($errors->all() as $error)
                                            <div class="alert alert-danger">{{ $error }}</div>
                                        @endforeach
                                    @endif
                                </div>
                                <div class="live-preview">
                                    <input type="hidden" name="ref_operator_type_id" value="3">
                                    <div class="row seperatesec white-inner">
                                        <div class="sectitle">
                                            <label for="labelInput" class="form-label">General Details<span
                                                    class="required">*</span></label>
                                        </div>
                                        <hr>
                                        <div class="col-xxl-2 col-md-6 mt-1">
                                            <div>
                                                <label class="form-label">पैन / PAN <span class="required">
                                                        *</span></label>
                                                <input type="text" class="form-control" id="user_name" placeholder="PAN"
                                                    name="user_name"
                                                    value="{{ $userdetails ? $userdetails->user_name : '' }}" required
                                                    readonly>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-6 mt-1">
                                            <div>
                                                <label class="form-label">आईसीएस / Individual Producer *<span
                                                        class="required">
                                                    </span></label>
                                                <input type="text" class="form-control" id="farmer_first_name"
                                                    placeholder="First Name" name="farmer_first_name"
                                                    value="{{ $farmerDetails ? $farmerDetails->farmer_first_name : '' }} {{ $farmerDetails ? $farmerDetails->farmer_middle_name : '' }} {{ $farmerDetails ? $farmerDetails->farmer_last_name : '' }}"
                                                    required>
                                            </div>
                                        </div>

                                        {{-- <div class="col-xxl-3 col-md-6 mt-1">
                                        <div>
                                            <label class="form-label">किसान का मध्य नाम/Farmer Middle Name</label>
                                            <input type="text" class="form-control" id="farmer_middle_name" placeholder="Middle Name" name="farmer_middle_name" value="{{ ($farmerDetails) ? $farmerDetails->farmer_middle_name : '' }}">
                                        </div>
                                    </div>

                            <div class="col-xxl-3 col-md-6 mt-1">
                                <div>
                                    <label class="form-label">किसान का उपनाम/Farmer Last Name<span class="required">*</span></label>
                                    <input type="text" class="form-control" id="farmer_last_name" name="farmer_last_name" placeholder="Last Name" value="{{ ($farmerDetails) ? $farmerDetails->farmer_last_name : '' }}" required>
                                </div>
                            </div> --}}
                                        <div class="col-xxl-2 col-md-6 mt-1">
                                            <div>
                                                <label class="form-label">लिंग/Gender<span class="required">
                                                        *</span></label>
                                                {{-- <input type="hidden" name="gender"
                                                    value="{{ $farmerDetails->gender ?? '' }} "> --}}
                                                <select class="form-select" name="gender" required >
                                                    <option value="">--Select--</option>
                                                    <option value="1" {{ $farmerDetails && $farmerDetails->gender == 1 ? 'selected ' : '' }}> Male</option>
                                                    <option value="2" {{ $farmerDetails && $farmerDetails->gender == 2 ? 'selected' : '' }}> Female</option>
                                                    <option value="3" {{ $farmerDetails && $farmerDetails->gender == 3 ? 'selected' : '' }}> Other</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row seperatesec white-inner">
                                        <div class="col-xxl-2 col-md-6 mt-1">
                                            <div>
                                                <label class="form-label">पिता/पति/Father/ Husband<span class="required">*</span></label>
                                                <select class="form-select" name="father_husband_flag" required>
                                                    <option value="">--Select--</option>
                                                    <option value="1" {{ $farmerDetails && $farmerDetails->father_husband_flag == 1 ? 'selected' : '' }}> Father</option>
                                                    <option value="2" {{ $farmerDetails && $farmerDetails->father_husband_flag == 2 ? 'selected' : '' }}> Husband</option>

                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-xxl-4 col-md-6 mt-1">
                                            <div>
                                                <label class="form-label">पिता / पति का नाम/Father's / Husband First
                                                    Name<span class="required">
                                                        *</span></label>
                                                <input type="text" class="form-control" id="father_first_name"
                                                    placeholder="First Name" name="father_first_name"
                                                    value="{{ $farmerDetails ? $farmerDetails->father_husband_first_name : '' }}"
                                                    required>
                                            </div>
                                        </div>

                                        <div class="col-xxl-3 col-md-6 mt-1">
                                            <div>
                                                <label class="form-label">पिता का मध्य नाम/Father's Middle Name</label>
                                                <input type="text" class="form-control" id="father_middle_name"
                                                    placeholder="Middle Name" name="father_middle_name"
                                                    value="{{ $farmerDetails ? $farmerDetails->father_husband_middle_name : '' }}"
                                                    >
                                            </div>
                                        </div>

                                        <div class="col-xxl-3 col-md-6 mt-1">
                                            <div>
                                                <label class="form-label">पिता का उपनाम/Father's Last Name<span
                                                        class="required">
                                                        *</span></label>
                                                <input type="text" class="form-control" id="father_last_name"
                                                    name="father_last_name" placeholder="Last Name"
                                                    value="{{ $farmerDetails ? $farmerDetails->father_husband_last_name : '' }}"
                                                    required >
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row seperatesec white-inner">
                                        <div class="sectitle">
                                            <label for="labelInput" class="form-label">किसान का पता/Address of
                                                Farmer</label>
                                        </div>
                                        <hr>
                                        <div class="col-xxl-3 col-md-3">
                                            <div class="row">
                                                <div class="col-xx-12 col-md-12">
                                                    <label for="labelInput" class="form-label ">पता/Address <span
                                                            class="required">*</span></label>
                                                    <textarea class="form-control customtextarea" name="address" readonly> {{ $user ? $user->address : '' }}</textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xxl-9 col-md-9">
                                            <div class="row">
                                                <div class="col-xxl-4 col-md-4 mt-1">
                                                    <label for="labelInput" class="form-label">राज्य/State <span
                                                            class="required">*</span></label>
                                                    <div class="input-group">
                                                        <input type="hidden" name="state" value="{{ $user->ref_state_id?? '' }} ">
                                                        <select class="form-select state" name="state" required
                                                            disabled>
                                                            <option value="">Select State</option>
                                                            @forelse($states as $state)
                                                                <option value="{{ $state->id }}"
                                                                    @if ($user->ref_state_id == $state->id) selected @endif>
                                                                    {{ $state->state_name }}</option>
                                                            @empty
                                                            @endforelse
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-xxl-4 col-md-4 mt-1">
                                                    <label for="labelInput" class="form-label">ज़िला/District <span
                                                            class="required">*</span></label>
                                                    <div class="input-group">
                                                            
                                                        <input type="hidden" name="district" value="{{ $user->ref_district_id ?? '' }} ">
                                                        <select class="form-select district" name="district" required
                                                            disabled>
                                                            <option value="{{ $user->ref_district_id }}">
                                                                {{ get_district_name_by_id($user->ref_district_id) }}
                                                            </option>
                                                            <option value="">Select District</option>
                                                            {{-- @forelse($districts as $district)
                                                        <option value="{{$district->id}}">{{$district->district_name}}
                                                </option>
                                                @empty
                                                @endforelse --}}
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-xxl-4 col-md-4 mt-1">
                                                    <label for="labelInput" class="form-label">तालुका/मंडल/Taluka/Mandal
                                                        <span class="required">*</span></label>
                                                    <div class="input-group">
                                                        <input type="hidden" name="taluka" value="{{ $user->ref_block_tehsil_id ?? '' }} ">
                                                        <select class="form-select block_tehsil" name="taluka" required
                                                            disabled>
                                                            <option value="{{ $user->ref_block_tehsil_id }}">
                                                                {{ getBlockTehsilByID($user->ref_block_tehsil_id) }}
                                                            </option>
                                                            <option value="">Select Taluka/Mandal</option>
                                                            {{-- @forelse($regions as $region)
                                                        <option value="{{$region->id}}">{{$region->region_name}}
                                                </option>
                                                @empty
                                                @endforelse --}}
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-xxl-6 col-md-6 mt-1">
                                                    <label for="labelInput" class="form-label">गाँव/Village <span
                                                            class="required">*</span></label>
                                                    <div class="input-group">
                                                        <input type="hidden" name="village" value="{{ $user->ref_village_id ?? '' }} ">
                                                        <select class="form-select village" name="village" required
                                                            disabled>
                                                            <option value="{{ $user->ref_village_id }}">
                                                                {{ get_village_name_by_id($user->ref_village_id) }}
                                                            </option>
                                                            <option value="">Select Village</option>
                                                            {{-- @forelse($villages as $village)
                                                        <option value="{{$district->id}}">{{$village->village_name}}
                                                </option>
                                                @empty
                                                @endforelse --}}
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-xxl-6 col-md-6 mt-1">
                                                    <div>
                                                        <label for="labelInput" class="form-label">पिन कोड/Pin Code<span
                                                                class="required">*</span></label>
                                                        <input type="text" class="form-control numbersonly"
                                                            id="pin_code" name="pin_code" placeholder="Pin Code"
                                                            maxlength="6" value="{{ $user ? $user->pin : '' }}"
                                                            required readonly>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                    <div class="row seperatesec white-inner">
                                        <div class="sectitle">
                                            <label for="labelInput" class="form-label">व्यक्तिगत निर्माता का संपर्क
                                                विवरण/Contact Details of Individual Producer </label>
                                        </div>
                                        <hr>
                                        <div class="col-xxl-2 col-md-6 mt-1">
                                            <div>
                                                <label class="form-label">मोबाइल नंबर/Mobile No. <span
                                                        class="required">*</span></label>
                                                <input type="text" class="form-control numbersonly" id="mobile_number"
                                                    placeholder="Mobile Number" name="mobile_number" maxlength="10"
                                                    value="{{ $user ? $user->contact_person_mobile_number : '' }}"
                                                    readonly>
                                            </div>
                                        </div>

                                        <div class="col-xxl-3 col-md-6 mt-1">
                                            <div>
                                                <label class="form-label">आधार नंबर/Aadhaar No. <span
                                                        class="required">*</span></label>
                                                {{-- <input type="text" class="form-control numbersonly" id="aadhar_number"
                                                name="aadhar_number" placeholder="Aadhar Number" maxlength="12" readonly
                                                value="{{ $user && $user->contact_person_aadhar_number ? maskAadhaarNumber(Crypt::decrypt($user->contact_person_aadhar_number)) : '' }}"
                                    required> --}}

                                                <input type="text" class="form-control numbersonly" id="aadhar_number"
                                                    name="aadhar_number" placeholder="Aadhar Number" maxlength="12"
                                                    readonly
                                                    value="{{ maskAadhaarNumber($user->contact_person_aadhar_number) }}"
                                                    required>

                                            </div>
                                        </div>

                                        {{-- --- <div class="col-xxl-3 col-md-6 mt-1">
                                        <div>
                                            <label class="form-label">पैन नंबर/PAN Number <span class="required">*</span></label>
                                            <input type="text" class="form-control" id="pan_number" name="pan_number"
                                                placeholder="Pan Number"
                                                value="{{ ($user) ? $user->user_name : '' }}"
                            required maxlength="10" readonly>
                        </div>
                    </div>- --}}

                                        <div class="col-xxl-3 col-md-6 mt-1">
                                            <div>
                                                <!-- <label class="form-label">Email Id <span class="required">*</span></label>
                                                <input type="email" class="form-control" id="email_id" name="email_id" placeholder="Email Id" value="{{ $user ? $user->email : '' }}" required> -->
                                                <div class="inputEmail  col-12 col-sm-12 col-md-12 col-lg-12">
                                                    <div class="form-group d-flex justify-content-center ge-otp-form">
                                                        <div class="col-12 col-sm-12 col-md-10 col-lg-10">
                                                            <label>ईमेल आईडी/Email ID<span
                                                                    class="text-danger">*</span></label>
                                                            <input
                                                                class="form-control validateEmailId col-12 col-sm-12 col-md-12 col-lg-12"
                                                                type="text" value="{{ $user ? $user->email : '' }}"
                                                                placeholder="Email Id" id="email_id1" name="email_id"
                                                                @if ($user->email) readonly @endif />
                                                        </div>
                                                        @if (empty($user->email))
                                                            <div
                                                                class="input-group-append col-12 col-sm-12 col-md-2 col-lg-2">
                                                                <button type="button"
                                                                    class="btn-email btn btn-outline-success waves-effect waves-light visitorCat2">Get
                                                                    OTP</button>
                                                                <button type="button"
                                                                    class="btn btn-ghost-success waves-effect waves-light btn-mailsend"
                                                                    style="display:none">Mail Send</button>
                                                                <button type="button"
                                                                    class="btn btn-ghost-success waves-effect waves-light btn-verify"
                                                                    style="display:none">Verified</button>
                                                            </div>
                                                        @endif
                                                    </div>
                                                    <div class="verify-email justify-content-center">
                                                        <div class="login-pass mb-4 otp-email col-12 col-sm-12 col-md-5 col-lg-12 pl-2"
                                                            style="display:none">
                                                            <div class="input-group">
                                                                <span class="input-group-text mdi mdi-key"
                                                                    id="inputGroup-sizing-default"></span>
                                                                <input type="text" class="form-control inp-b"
                                                                    aria-label="Sizing example input"
                                                                    aria-describedby="inputGroup-sizing-default"
                                                                    id="email_otp1">
                                                                <div class="input-group-append">
                                                                    <a href="javascript:void(0)"
                                                                        class="verifiEmail_otp btn btn-outline-success waves-effect waves-light">Verify</a>
                                                                    <a href="javascript:void(0)"
                                                                        class="resendEmail_otp btn btn-outline-danger waves-effect waves-light">Resend</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xxl-4 col-md-6 mt-1">
                                            <div>
                                                <label for="labelInput" class="form-label">संपर्ककर्ता का
                                                    पदनाम/Designation of Contact Person</label>
                                                    
                                                <select name="contact_designation" class="form-select" disabled>
                                                    <option value="">Select Designation</option>
                                                    <option value="Manager" value="Manager"
                                                        {{ $user->contact_designation == 'Manager' ? 'selected' : '' }}>
                                                        Manager</option>
                                                </select>
                                            </div>
                                        </div>



                                        <!-- end -->













                                        <div class="row">
                                            <div class="col-lg-12 gy-4">
                                                <div class="hstack gap-2">
                                                    <button type="submit" class="btn btn-primary">
                                                        Submit
                                                    </button>
                                                    <a href="{{ route('superadmin.usermanagement.deptUser.individualUserAddStep2', $userdetails->id) }}"
                                                        class="btn btn-soft-success">
                                                        Next
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

@endsection
@push('script')
    <script>
        // email verification code --------

        $(".btn-email").click(function(e) {
            e.preventDefault();
            var user_email = $('#email_id1').val();


            if (user_email != "") {
                $(".overlay").show();
                $.ajax({
                    type: 'POST',
                    url: "{{ route('superadmin.usermanagement.email_mobile_OTP') }}",
                    data: {
                        'user_email': user_email
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(resp) {
                        if (resp == 1) {

                            Swal.fire({
                                text: "Please verify OTP send on Email id",
                                icon: 'success',
                                confirmButtonText: 'OK'
                            }).then((result) => {
                                $('.otp-email').show(500);
                                $('#email_id1').val(user_email);
                                $('#email_id1').prop('readonly', true);
                                $('.btn-email').hide(500);
                                $('.btn-mailsend').show(100);
                            });

                        }
                        $(".overlay").hide();
                    }
                });
            } else {
                Swal.fire("", "Please enter Email ID", "error");
            }
        });


        $(".verifiEmail_otp").click(function(e) {
            e.preventDefault();
            var email_otp = $('#email_otp1').val();
            $(".overlay").show();
            if (email_otp != "") {

                $.ajax({
                    type: 'POST',
                    url: "{{ route('superadmin.usermanagement.email_mobile_OTP_check') }}",
                    data: {
                        'email_otp': email_otp
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(html) {
                        if (html == 0) {
                            Swal.fire("", "Please enter Valid OTP", "error");
                        } else {
                            $('#email_otp').prop('readonly', true);
                            $('.otp-email1').hide(500);
                            $('.btn-email').hide(500);
                            $('.btn-verify').show(500);
                            $('.visitorCat').hide(500);
                            $('.visitorCat1').hide(500);
                            $('.user_detail_page').show(500);
                            $('#email_id').prop('readonly', true);
                            $('.btn-mailsend').hide();
                            $('.login-pass').hide();
                        }
                        $(".overlay").hide();
                    }
                });
            } else {
                Swal.fire("", "Please enter OTP", "error");
            }
        });

        $(".resendEmail_otp").click(function(e) {
            e.preventDefault();
            var user_email = $('#email_id1').val();

            $.ajax({
                type: 'POST',
                url: "{{ route('superadmin.usermanagement.email_mobile_OTP') }}",
                data: {
                    'user_email': user_email
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(html) {
                    Swal.fire("", "Re OTP Send!!", "success");
                }
            });
        });


        // end-------------










        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $("#registration").validate({
            rules: {

            },
            messages: {

            }

        });
        // Dropzone has been added as a global variable.


        $(document).on('change', '#pan_number', function() {

            var inputvalues = $(this).val();
            var regex = /[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
            if (!regex.test(inputvalues)) {
                //console.log(inputvalues);
                $("#pan_number").val("");
                alert("invalid PAN no");
                return regex.test(inputvalues);
            }
        });
    </script>
@endpush

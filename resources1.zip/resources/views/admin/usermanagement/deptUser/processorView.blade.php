@extends('admin.layouts.app')
@section('content')
    <style>
        body {
            margin: 0px;
            padding: 0px;
            font-family: "Segoe UI";
        }

        .maindiv {
            width: 80%;
            margin: 0 auto;
        }

        .pdf_maindiv {
            border: 1px solid #cccccc;
            width: 100%;
            float: left;
            padding: 2% 1%;
        }

        .pdf_heading {
            font-size: 20px;
            color: #000;
            padding: 26px 0 20px 0px;
            position: relative;
            width: 100%;
            float: left;
        }

        .brd_heading {
            border-bottom: 2px solid #ee5e24;
            padding-bottom: 8px;
            padding-right: 8px;
            width: 60px;
        }

        .pdf_input1 {
            background: #eeeeee;
        }

        .pdf_txt1 {
            color: #000;
            font-size: 14px;
            width: 45%;
            float: left;
            padding-bottom: 10px;
            font-weight: bold;
        }

        .pdf_box {
            color: #000;
            font-size: 14px;
            width: 55%;
            float: left;
            padding-bottom: 10px;
        }

        .table_pdf {
            width: 100%;
        }

        .pdf_heading:after {
            content: "";
            position: absolute;
            width: 70px;
            height: 2px;
            background-color: #ee5e24;
            bottom: 10px;
            display: block;
        }

        .pdf_heading:before {
            content: "";
            position: absolute;
            width: 22px;
            height: 6px;
            background-color: #ee5e24;
            bottom: 8px;
            display: block;
        }

        #step1 .card-body {
            background: #fff
        }

        .pdf_inner_heading:after {
            display: none;
        }

        .pdf_inner_heading:before {
            display: none;
        }

        .pdf_inner_heading {
            padding: 20px 0 12px;
            text-decoration: underline;
            font-size: 16px;
        }

        .pdf_maindiv hr:last-child {
            display: none;
        }

        .pdf-img-icon {
            height: 17px;
            width: 15px;
            margin-right: 5px;
        }

        @media print {

            .pdf_heading {
                font-size: 20px;
                color: #000;
                padding: 26px 0 20px 0px;
                position: relative;
                width: 100%;
                float: left;
                -webkit-print-color-adjust: exact !important;
                Chrome,
                Safari color-adjust: exact !important;
            }

            .pdf_heading:before {
                content: "";
                position: absolute;
                width: 20px;
                height: 4px;
                background-color: #ee5e24;
                bottom: 10px;
                display: block;
                -webkit-print-color-adjust: exact !important;
                Chrome,
                Safari color-adjust: exact !important;
            }


        }
    </style>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0"> {{ getOperatorTypeById($user->ref_operator_type_id ?? '') }} Profile</h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        {{-- <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li> --}}
                        <li class="breadcrumb-item active">{{ getOperatorTypeById($user->ref_operator_type_id ?? '') }} Profile</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">

            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1">
                                {{ user_name($user->id) ?? '' }}
                            </h4>
    
                            <div class="flex-shrink-0  {{(($user->status == 2 || $user->status == 4)? 'flex-grow-1':'')}}">
                                <label for="basiInput" class="form-label">{{ ($user->status == 2? 'Registration Number : '.$user->registration_no:"Application Number : #00".$user->id)}}</label>
                            </div>
                            @if($user->status == 2)
                            <div class="flex-shrink-0 flex-grow-1">
                                <label for="basiInput" class="form-label">Registration Certificate : <a target="_BLANK" href="{{ asset('public/' . $user->registration_certificate) }}" class="text-decoration-underline"><img src="{{ asset('public/assets/images/pdf-icon.png')}}" alt="" height="17px" class="pdf-img-icon">See Doc</a></label>
                            </div>
                                @if ($eMSignedModuleAlow['status'] == 'success')
                                    <div class="flex-shrink-0">
                                        @if ($eMSignedModuleResult['status'] == 'success')
                                            @php
                                                $publicPath = str_replace('var/www/html/apeda/', '', $eMSignedModuleResult['signedPath']);
                                            @endphp
                                            <a class="btn btn-success btn-sm" download href="{{ $hostName . $publicPath }}">Download Signed PDF</a>
                                        @else
                                            <button type="button" class="btn btn-primary btn-sm" id="generateDigitalSign"
                                                data-filename="{{ basename($user->registration_certificate) }}"
                                                data-path="/{{ basename(dirname($user->registration_certificate)) }}/"
                                                data-filestored="public"
                                                data-certificate="RC">
                                                Digital Sign
                                            </button>
                                        @endif
                                    </div>
                                @endif
                            @endif
                            @if ($user->status == 0 || $user->status == 4)
                            <div class="flex-shrink-0">
                                <a href="{{ route('superadmin.icsuser.step1', $user->id) }}" class="btn btn-soft-success">Back</a>
                            </div>
                            @endif
                        </div>








                        @if($user->ref_operator_type_id == 3)
                        <div class="card-body">
                        @include('admin.usermanagement.deptUser.individual_producer_view');
                        </div>
                        
                        @else

                        <!-- end card header -->
                        <div class="card-body">
                            <div class="pdf_heading">{{ getOperatorTypeById($user->ref_operator_type_id ?? '') }} Details</div>
                            <div class="pdf_maindiv">
                                <!--form1 section starts here-->
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-6">
                                            <!--form1 tab starts here-->
                                            <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                <tr>
                                                    <td class="pdf_txt1">Date of Registration :</td>
                                                    <td class="pdf_box">
                                                        {{ date('d-m-Y', strtotime($user->created_at)) ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Photo of the Processing Unit:</td>
                                                    <td class="pdf_box">
                                                        @if (!empty($user->processor_photo))
                                                            <a target="_BLANK"
                                                                href="{{ asset('public/processor_photo/' . $user->processor_photo) }}"
                                                                class="text-decoration-underline"><img
                                                                    src="{{ asset('public/assets/images/pdf-icon.png') }}"
                                                                    alt="" class="pdf-img-icon">See Doc</a>
                                                        @else
                                                            NOt Available
                                                        @endif
                                                    </td>
                                                </tr>
                                            </table>
                                            <!--form1 tab end here-->
                                        </div>
                                        <div class="col-6">
                                            <!--form1 tab starts here-->
                                            <table style="padding: 10px; border: 0px;" class="table_pdf">

                                                <tr>
                                                    <td class="pdf_txt1">Name of Processor :</td>
                                                    <td class="pdf_box">{{ user_name($user->id) ?? '' }}</td>
                                                </tr>


                                            </table>
                                            <!--form1 tab end here-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="pdf_heading">{{ getOperatorTypeById($user->ref_operator_type_id ?? '') }} Address</div>
                            <div class="pdf_maindiv">
                                <!--form1 section starts here-->
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-6">
                                            <!--form1 tab starts here-->
                                            <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                <tr>
                                                    <td class="pdf_txt1">State</td>
                                                    <td class="pdf_box">{{ getStateName($user->ref_state_id) }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">District</td>
                                                    <td class="pdf_box">{{ getDisName($user->ref_district_id) }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Taluka/Mandal</td>
                                                    <td class="pdf_box">{{ getTalukName($user->ref_block_tehsil_id) }}</td>
                                                </tr>
                                            </table>
                                            <!--form1 tab end here-->
                                        </div>

                                        <div class="col-6">

                                            <!--form1 tab starts here-->
                                            <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                <tr>
                                                    <td class="pdf_txt1">Village</td>
                                                    <td class="pdf_box">{{ getVillName($user->ref_village_id) }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Pin Code</td>
                                                    <td class="pdf_box">{{ $user->pin ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Address</td>
                                                    <td class="pdf_box">{{ $user->address ?? '' }}</td>
                                                </tr>
                                            </table>
                                            <!--form1 tab end here-->
                                        </div>


                                    </div>
                                </div>
                            </div>
                            <div class="pdf_heading">Contact Person Details</div>
                            <div class="pdf_maindiv">
                                <!--form1 section starts here-->
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-6">
                                            <!--form1 tab starts here-->
                                            <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                <tr>
                                                    <td class="pdf_txt1">First Name</td>
                                                    <td class="pdf_box"> {{ $user->contact_person_first_name ?? '' }}  {{ $user->contact_person_middle_name ?? '' }} {{ $user->contact_person_last_name ?? '' }} </td>
                                                </tr>
                                                {{-- <tr>
                                                    <td class="pdf_txt1">Last Name</td>
                                                    <td class="pdf_box"> {{ $user->contact_person_last_name ?? '' }}</td>
                                                </tr> --}}
                                                <tr>
                                                    <td class="pdf_txt1">Email Id</td>
                                                    <td class="pdf_box" colspan=2>{{ $user->contact_person_email ?? '' }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Gender</td>
                                                    <td class="pdf_box">
                                                        @if ($user->contact_person_gender == 1)
                                                            Male
                                                        @elseif($user->contact_person_gender == 2)
                                                            Female
                                                        @else
                                                            other
                                                        @endif
                                                    </td>
                                                </tr>
                                                {{-- <tr>
                                                    <td class="pdf_txt1">Contact Person Photo</td>
                                                    <td class="pdf_box">
                                                        @if (!empty($user->contact_person_photo))
                                                            <a target="_BLANK"
                                                                href="{{ asset('public/contact_person_photo/' . $user->contact_person_photo) }}"
                                                                class="text-decoration-underline"><img
                                                                    src="{{ asset('public/assets/images/pdf-icon.png') }}"
                                                                    alt="" class="pdf-img-icon">See Doc</a>
                                                        @else
                                                            NOt Available
                                                        @endif
                                                    </td>
                                                </tr> --}}

                                            </table>

                                            <!--form1 tab end here-->
                                        </div>

                                        <div class="col-6">

                                            <!--form1 tab starts here-->
                                            <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                {{-- <tr>
                                                    <td class="pdf_txt1">Middle Name</td>
                                                    <td class="pdf_box"> {{ $user->contact_person_middle_name ?? '' }}</td>
                                                </tr> --}}
                                                <tr>
                                                    <td class="pdf_txt1">Contact No.</td>
                                                    <td class="pdf_box">{{ $user->contact_person_mobile_number ?? '' }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Aadhaar No.</td>
                                                    <td class="pdf_box">{{ ($user->contact_person_aadhar_number) }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">PAN</td>
                                                    <td class="pdf_box">{{ $user->contact_person_pan_number ?? '' }}
                                                    </td>
                                                </tr>


                                            </table>
                                            <!--form1 tab end here-->
                                        </div>

                                        <div class="pdf_heading pdf_inner_heading">Contact Person Address</div>
                                        <div class="col-6">
                                            <!--form1 tab starts here-->
                                            <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                <tr>
                                                    <td class="pdf_txt1">State</td>
                                                    <td class="pdf_box">{{ getStateName($user->processor_state_id) }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">District</td>
                                                    <td class="pdf_box">{{ getDisName($user->processor_district_id) }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Taluka/Mandal</td>
                                                    <td class="pdf_box">
                                                        {{ getTalukName($user->processor_block_tehsil_id) }}</td>
                                                </tr>
                                            </table>
                                            <!--form1 tab end here-->
                                        </div>

                                        <div class="col-6">

                                            <!--form1 tab starts here-->
                                            <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                <tr>
                                                    <td class="pdf_txt1">Village</td>
                                                    <td class="pdf_box">{{ getVillName($user->processor_village_id) }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Pin Code</td>
                                                    <td class="pdf_box">{{ $user->processor_pin ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Address</td>
                                                    <td class="pdf_box">{{ $user->address ?? '' }}</td>
                                                </tr>
                                            </table>
                                            <!--form1 tab end here-->
                                        </div>
                                        <div class="pdf_heading pdf_inner_heading">Bank Details of the {{ getOperatorTypeById($user->ref_operator_type_id ?? '') }}</div>
                                        <div class="col-6">
                                            <!--form1 tab starts here-->
                                            <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                <tr>
                                                    <td class="pdf_txt1">Bank Name</td>
                                                    <td class="pdf_box">
                                                        @if (isset($user->bankDetails))
                                                            {{ $user->bankDetails->ref_bank_id }}
                                                        @endif
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Account No.</td>
                                                    <td class="pdf_box">{{ $user->bankDetails->account_number ?? '' }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">IFSC Code</td>
                                                    <td class="pdf_box">{{ $user->bankDetails->ifsc_code ?? '' }}</td>
                                                </tr>
                                            </table>
                                            <!--form1 tab end here-->
                                        </div>

                                        <div class="col-6">

                                            <!--form1 tab starts here-->
                                            <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                <tr>
                                                    <td class="pdf_txt1">Branch Name</td>
                                                    <td class="pdf_box">{{ $user->bankDetails->branch_name ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Pin Code</td>
                                                    <td class="pdf_box">{{ $user->bankDetails->pincode ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Address</td>
                                                    <td class="pdf_box">
                                                        {{ $userdetails->bankDetails->bank_address ?? '' }}</td>
                                                </tr>
                                            </table>
                                            <!--form1 tab end here-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="pdf_heading">Geo Tagging of {{ getOperatorTypeById($user->ref_operator_type_id ?? '') }} Unit</div>
                            <div class="pdf_maindiv">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-6">
                                            <!--form1 tab starts here-->
                                            <table style="padding: 10px; border: 0px;"
                                                class="table_pdf table_contact_person">
                                                <tr>
                                                    <td class="pdf_txt1">Enter the number of {{ getOperatorTypeById($user->ref_operator_type_id ?? '') }} Unit</td>
                                                    <td class="pdf_box">
                                                        {{ isset($gtDetail[0]->number_of_processing_unit) && !empty($gtDetail[0]->number_of_processing_unit) ? $gtDetail[0]->number_of_processing_unit : '' }}

                                                    </td>
                                                </tr>

                                            </table>
                                            <!--form1 tab end here-->
                                        </div>

                                    </div>
                                    @forelse($gtDetail as $key=>$val)
                                        <div class="col-12">
                                            <h6
                                                style="padding:0;padding-bottom:15px;width: 100%;text-decoration: underline;">
                                                {{ $key + 1 }}.
                                                </caption>
                                        </div>
                                        <div class="row">

                                            <div class="col-6">
                                                <!--form1 tab starts here-->
                                                <table style="padding: 10px; border: 0px;"
                                                    class="table_pdf table_contact_person">
                                                    <tr>
                                                        <td class="pdf_txt1">Processing Unit ID</td>
                                                        <td class="pdf_box">{{ $val->processing_unit_id ?? '' }}</td>
                                                    </tr>

                                                    <tr>
                                                        <td class="pdf_txt1">Name of the Processing Units</td>
                                                        <td class="pdf_box">{{ $val->processing_units_name ?? '' }}</td>
                                                    </tr>

                                                    <tr>
                                                        <td class="pdf_txt1">FSSAI License Number</td>
                                                        <td class="pdf_box">{{ $val->fssai_license_number ?? '' }}</td>
                                                    </tr>

                                                    <tr>
                                                        <td class="pdf_txt1">License Document</td>
                                                        <td class="pdf_box">
                                                            @if (!empty($val->license_document))
                                                                <a target="_BLANK"
                                                                    href="{{ asset('public/processor/license_document/' . $val->license_document) }}"
                                                                    class="text-decoration-underline"><img
                                                                        src="{{ asset('public/assets/images/pdf-icon.png') }}"
                                                                        alt="" class="pdf-img-icon">See Doc</a>
                                                            @else
                                                                NOt Available
                                                            @endif
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td class="pdf_txt1">FSSAI License Validity From</td>
                                                        <td class="pdf_box">
                                                            {{ date('d-m-Y', strtotime($val->license_validity_from)) ?? '' }}
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td class="pdf_txt1">FSSAI License Validity To</td>
                                                        <td class="pdf_box">
                                                            
                                                            {{ date('d-m-Y', strtotime($val->license_validity_to)) ?? '' }}
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td class="pdf_txt1">No. of Processing Lines</td>
                                                        <td class="pdf_box">{{ $val->no_of_processing_lines ?? '' }}</td>
                                                    </tr>

                                                    <tr>
                                                        <td class="pdf_txt1">Status of Agreement </td>
                                                        <td class="pdf_box">{{ $val->agreement_status ?? '' }}</td>
                                                    </tr>

                                                    <tr>
                                                        <td class="pdf_txt1">Number of Products</td>
                                                        <td class="pdf_box">{{ $val->number_of_product ?? '' }}</td>
                                                    </tr>

                                                    <tr>
                                                        <td class="pdf_txt1">Additional Certificate</td>
                                                        <td class="pdf_box">
                                                            @if (!empty($val->additional_certificate))
                                                                <a target="_BLANK"
                                                                    href="{{ asset('public/processor/additional_certificate/' . $val->additional_certificate) }}"
                                                                    class="text-decoration-underline"><img
                                                                        src="{{ asset('public/assets/images/pdf-icon.png') }}"
                                                                        alt="" class="pdf-img-icon">See Doc</a>
                                                            @else
                                                                NOt Available
                                                            @endif
                                                        </td>
                                                    </tr>


                                                </table>
                                                <!--form1 tab end here-->
                                            </div>
                                            <div class="col-6">
                                                <!--form1 tab starts here-->
                                                <table style="padding: 10px; border: 0px;"
                                                    class="table_pdf table_contact_person">
                                                    <tr>
                                                        <td class="pdf_txt1">Geo Tagging of {{ getOperatorTypeById($user->ref_operator_type_id ?? '') }} Unit</td>
                                                        <td class="pdf_box">{{ $val->geo_tagging_processing_unit ?? '' }}
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td class="pdf_txt1">Reflect Farm</td>
                                                        <td class="pdf_box">{{ $val->reflect_farm ?? '' }}</td>
                                                    </tr>

                                                    <tr>
                                                        <td class="pdf_txt1">Reflect Farm Image after Tagging</td>
                                                        <td class="pdf_box">
                                                            @if (!empty($val->image_after_tagging))
                                                                <a target="_BLANK"
                                                                    href="{{ asset('public/processor/image_after_tagging/' . $val->image_after_tagging) }}"
                                                                    class="text-decoration-underline"><img
                                                                        src="{{ asset('public/assets/images/pdf-icon.png') }}"
                                                                        alt="" class="pdf-img-icon">See Doc</a>
                                                            @endif
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td class="pdf_txt1">Total Capacity of {{ getOperatorTypeById($user->ref_operator_type_id ?? '') }} Unit</td>
                                                        <td class="pdf_box">{{ $val->total_capacity ?? '' }}</td>
                                                    </tr>

                                                    <tr>
                                                        <td class="pdf_txt1">Installed Capacity Under Organic Processing
                                                        </td>
                                                        <td class="pdf_box">
                                                            {{ $val->installed_capacity_under_organic ?? '' }}</td>
                                                    </tr>

                                                    <tr>
                                                        <td class="pdf_txt1">Daily Processing Capacity</td>
                                                        <td class="pdf_box">{{ $val->daily_processing_capacity ?? '' }}
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td class="pdf_txt1">Types of Processing</td>
                                                        <td class="pdf_box">{{ $val->processing_type ?? '' }}</td>
                                                    </tr>

                                                    <tr>
                                                        <td class="pdf_txt1">Address</td>
                                                        <td class="pdf_box">{{ $val->address ?? '' }}</td>
                                                    </tr>

                                                    <tr>
                                                        <td class="pdf_txt1">Photo of Processing Unit </td>
                                                        <td class="pdf_box">
                                                            @if (!empty($val->processing_unit_image))
                                                                <a target="_BLANK"
                                                                    href="{{ asset('public/processor/processing_unit_image/' . $val->processing_unit_image) }}"
                                                                    class="text-decoration-underline"><img
                                                                        src="{{ asset('public/assets/images/pdf-icon.png') }}"
                                                                        alt="" class="pdf-img-icon">See Doc</a>
                                                            @endif
                                                        </td>
                                                    </tr>



                                                </table>
                                                <!--form1 tab end here-->
                                            </div>
                                            <hr>
                                        @empty
                                    @endforelse
                                </div>
                            </div>
                        </div>
                    </div>
                   @endif
                   
                   
                    {{-- <div class="pdf_heading">Details of Products</div>
                    <div class="pdf_maindiv">
                        <!--form1 section starts here-->
                        @forelse ($ppDetail as $key => $val)
                            <h6 style="padding:0;padding-bottom:15px;width: 100%;text-decoration: underline;">
                                {{ $key + 1 }}.
                                </caption>
                                <div class="container-fluid">

                                    <div class="row">
                                        <div class="col-6">
                                            <!--form1 tab starts here-->
                                            <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                <tr>
                                                    <td class="pdf_txt1">Processing Unit ID</td>
                                                    <td class="pdf_box"> {{ $val->processing_unit_id ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">HS Code of the Product </td>
                                                    <td class="pdf_box"> {{ getHscodeById($val->ref_hscode_id) ?? '' }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Processor Name of the Product</td>
                                                    <td class="pdf_box" colspan=2>
                                                        {{ getHscodeProductName($val->ref_product_id) ?? '' }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Product Description</td>
                                                    <td class="pdf_box">
                                                        {{ $val->product_description }}
                                                    </td>
                                                </tr>


                                            </table>

                                            <!--form1 tab end here-->
                                        </div>

                                        <div class="col-6">

                                            <!--form1 tab starts here-->
                                            <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                <tr>
                                                    <td class="pdf_txt1">Name of {{ getOperatorTypeById($user->ref_operator_type_id ?? '') }}: </td>
                                                    <td class="pdf_box"> {{ $val->product_processor_name ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Organic Status: </td>
                                                    <td class="pdf_box">
                                                        {{ getRefOrganicStatusMasterByID($val->organic_status) ?? '' }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Photo of the Product: </td>
                                                    <td class="pdf_box">
                                                        @if (!empty($val->product_image))
                                                            <a target="_BLANK"
                                                                href="{{ asset('public/processor/product_photo/' . $val->product_image) }}"
                                                                class="text-decoration-underline"><img
                                                                    src="{{ asset('public/assets/images/pdf-icon.png') }}"
                                                                    alt="" class="pdf-img-icon">See Doc</a>
                                                        @else
                                                            NOt Available
                                                        @endif
                                                    </td>
                                                </tr>

                                            </table>
                                            <!--form1 tab end here-->
                                        </div>

                                    </div>
                                </div>
                            @empty
                        @endforelse
                    </div> --}}
                    

                    @if (!empty(Auth::guard('misadmin')->user()->role) && Auth::guard('misadmin')->user()->role->role_id == 1)
                        <div class="row">
                            <div class="col-lg-12">
                                @if($user->status == 1 && $user->status == 1)
                                <div class="tab-content py-4 custom-tab-content">
                                    <div class="tab-pane fade show active" id="step1">
                                        <div class="card">
                                            <div class="card-header align-items-center d-flex">
                                                <h4 class="card-title mb-0 flex-grow-1">
                                                    Remarks:
                                                </h4>
                                            </div>
                                            <!-- end card header -->
                                            <div class="card-body">
                                                <div class="live-preview">

                                                    {{-- <div class="col-xxl-4 col-md-4 gy-4 ">
                                                            <div>
                                                                <label for="basiInput"
                                                                    class="form-label">Remarks :
                                                                </label>
                                                                <label for="basiInput">{{ $user->cb_reg_remarks ?? '' }}
                                                                </label>

                                                            </div>
                                                        </div> --}}

                                                    <form method="post" id=""
                                                        action="{{ route('superadmin.usermanagement.deptUser.previewpost') }}">
                                                        @csrf
                                                        <input type="hidden" name="at_user_id"
                                                            value="{{ $user->id }}">
                                                        <input type="hidden" name="id"
                                                            value="{{ $user->ref_operator_type_id }}">
                                                        <div class="col-xxl-4 col-md-4 gy-4 ">
                                                            <div>
                                                                <label for="basiInput" class="form-label">Status<span
                                                                        class="required">*</span>
                                                                </label>

                                                                <select class="form-select" name="status" required>
                                                                    <option value="">-Select-
                                                                    </option>
                                                                    <option value="2"
                                                                        {{ $user->status == 2 ? 'selected' : '' }}>Approve
                                                                    </option>
                                                                    <option value="3"
                                                                        {{ $user->status == 3 ? 'selected' : '' }}>Reject

                                                                    </option>
                                                                </select>

                                                            </div>
                                                        </div>

                                                        <div class="col-xxl-6 col-md-6 gy-6 mt-3">
                                                            <div>
                                                                <label class="form-label">Submit Your
                                                                    Remarks:<span class="required">
                                                                        *</span></label>
                                                                <textarea placeholder="Address of The Inspector" class="form-control customtextarea" name="cb_remarks" required>{{ $user->cb_reg_remarks ?? '' }}</textarea>
                                                            </div>
                                                        </div>
                                                        {{-- @if ($regDetail->cb_remarks == '' && $regDetail->cb_status == '') --}}
                                                        <div class="row">
                                                            <div class="col-xxl-4 col-md-4 gy-4 ">
                                                                <div class="hstack gap-2">

                                                                    <button type="submit" id="submitbtn"
                                                                        class="btn btn-primary submit-button">Submit</button>

                                                                </div>
                                                            </div>
                                                        </div>
                                                        {{-- @endif --}}

                                                    </form>


                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                @else
                                
                                @endif

                            </div>
                        </div>
                    @else
                        <div class="row">
                            <div class="col-lg-12 gy-4">
                                <div class="hstack gap-2">
                                    <br>

                                   @if ($user->status == 0 || $user->status == 3)
                                     
                                     
                                        <form method="post" id=""
                                        action="{{ route('superadmin.icsuser.previewpost') }}">
                                        @csrf
                                        <input type="hidden" name="at_user_id"
                                            value="{{ $user->id }}">
                                        <button type="submit" class="btn btn-primary" id="submitbtn">
                                            Final Submit
                                        </button>
                                        </form>
                                   
                                  @endif
                                   @if ($user->status == 3)

                                        <div class="col-xxl-4 col-md-4 gy-4 ">
                                            <a href="{{ route('superadmin.icsuser.step1', $user->id) }}"
                                                class="btn btn-soft-success">
                                                Edit
                                            </a>

                                  @endif
                                </div>
                            </div>
                        </div>
                    @endif


                </div>
            </div>
        </div>
    </div>
    </div>
</div>
</div>
@endsection

@push('script')
    <script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
    <script>
        $(document).on('click', '#submitbtn', function() {

            if (checkValidation("registration")) {
                $('#registration').submit();
                return true;
            } else {
                return false;
            }
        });
    </script>
@endpush

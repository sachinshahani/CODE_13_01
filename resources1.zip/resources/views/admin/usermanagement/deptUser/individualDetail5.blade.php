@extends('admin.layouts.app')

@section('content')
<style>
    .wrapper {
        max-width: 1240px;
        margin: 0 auto;
    }

    .white-bg {
        background-color: white;
        /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
        border-bottom: 5px solid #ff9800;
        margin-bottom: 15px;
    }

    .auth-one-bg .slide .carousel-indicators {
        bottom: 25px;
    }

    .auth-page-wrapper .auth-page-content {
        padding-bottom: 0px !important;
    }

    .auth-page-content .card {
        margin-bottom: 0rem;
    }

    .data-tabs .wrapper .nav-tabs button {
        font-size: 17px;
        color: black;
    }

    .data-tabs .wrapper .nav-tabs .active {
        background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
        */ color: white;
        background: orange;
        border-radius: 0px;
    }

    .carousel-caption.d-none.d-md-block {
        background-color: #000000bf;
        left: 0;
        width: 100%;
        bottom: 0;
    }

    .carousel-indicators {
        display: none;
    }

    .custom-banner-caption {
        color: white !important;
    }

    .announcement-heading {
        font-size: 1.2em;
        font-weight: 600;
    }

    .data-tabs .tab-pane ul li {
        font-size: 1em;
        padding: 5px 0;

    }

    .main-logo {
        padding: 10px;
    }

    .data-tabs .nav-item .nav-link {
        background-image: none;
    }

    /* .right-sec{
    box-shadow: 5px 10px 18px #888888;
} */
    .navbar-brand-box {
        background: #fff;
    }

    /* .btn-danger {
        background-color: #40895a;
        border: 1px solid #40895a;
    } */

    [data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
        color: white !important;
    }

    .header-buttons .btn-primary {
        margin-right: 10px;
        padding: 6px 15px;
        font-weight: 600;
        background-color: #207005;
        border: none;
        box-shadow: 0px 2px 7px #888888;
    }

    .header-buttons .btn-secondary {
        margin-right: 10px;
        padding: 6px 15px;
        font-weight: 600;
        background-color: #72a055;
        border: none;
        box-shadow: 0px 2px 7px #888888;
    }


    .right-sec {
        border-left: 5px solid #ede7e7;
    }

    .tabdiv {
        background: white;
        padding: 20px;
        margin-top: 10px;
        border: 10px solid #dfdbd5;
    }

    .nav-tabs {
        border-bottom: 0px;
    }

    div#myTabContent {
        border: 1px solid #cccccc;
    }

    .frontfooter footer {
        padding: 20px calc(1.5rem / 2);
        position: static;
        color: #000;
        height: 60px;
        background-color: #f9f9f9;
        margin-top: 30px;
        border-top: 1px solid #e1dfdf;
    }

    span.logo-sm img {
        width: 69px;
    }

    .seperatesec {
        margin-top: 20px;
    }

    .simplebar-content li.nav-item:hover {
        background: #4caf50;
    }

    .sectitle {
        font-size: 14px;
    }

    .required {
        color: red;
    }

    .customtextarea {
        height: 120px;
    }

    ul.boxsection {
        margin: 0;
        padding: 0;
    }

    ul.boxsection li {
        list-style-type: none;
        padding: 7px 0;
        border-bottom: 1px solid #efeded;
    }

    .boxcard .col:nth-child(1) {
        background: #effcfb;
    }

    .boxcard .col:nth-child(2) {
        background: #fdfdfd;
    }

    .boxcard .col:nth-child(3) {
        background: #effcfb;
    }

    .boxcard .col:nth-child(4) {
        background: #fdfdfd;
    }

    .boxcard .col:nth-child(5) {
        background: #effcfb;
    }

    /* --registration-form css  */
    .custom-tab-content {
        padding-top: 0 !important;
        padding-bottom: 0px !important;
    }

    .custom-tab-nav {
        background: white;

    }

    .custom-tab-nav .nav-link {
        border-radius: 0 !important;
        border-bottom: 1px solid #e9ebec;
        border-right: 1px solid #e9ebec;
        font-size: 14px;
        padding: 10px;
    }

    .custom-tab-nav .nav-link.active,
    .custom-tab-nav .show>.nav-link {
        color: rgb(255, 255, 255) !important;
        background-color: #2c8c6d;
        border-bottom: #2c8c6d !important;
        /* border-bottom: #207005 !important; */
        position: relative;
    }

    .custom-tab-nav .nav-link:hover,
    .custom-tab-nav .nav-link:focus {
        border-bottom: 1px solid #207005;
        border-radius: 0;
        font-size: 14px;
        transition: background-color 0.20s linear;
    }

    .custom-tab-nav .nav-link.active:after {
        content: "";
        position: absolute;
        bottom: -16px;
        left: 50%;
        border: 8px solid transparent;
        border-top-color: #2c8c6d;
        z-index: 999;
    }

    .reg-form-btns {
        margin-bottom: 15px;
    }

    .reg-form-btns .btn-secondary {
        color: #fff;
        background-color: #405189;
        border-color: #405189;
    }

    .btn-soft-success:active,
    .btn-soft-success:focus,
    .btn-soft-success:hover {
        border: none;
    }

    .custom-tab-nav ul {
        padding: 0px;
        margin: 0px;
    }

    .custom-tab-nav ul li {
        padding: 0px;
        margin: 0px;
        display: inline-block;
        list-style: none;
    }
</style>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">व्यक्तिगत निर्माता प्रोफ़ाइल/Individual Producer Profile </h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Individual Producer Profile</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <form method="post" enctype="multipart/form-data" id="registration" action="{{route('superadmin.usermanagement.deptUser.individualUserStoreStep6',$id)}}">
            @csrf
            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                    <a class="nav-link" id="step1-tab" href="{{ route('superadmin.usermanagement.deptUser.individualUserAdd', [$id]) }}">General Details</a>
                    <a class="nav-link" id="step2-tab" href="{{ route('superadmin.usermanagement.deptUser.individualUserAddStep2', [$id]) }}">Bank Details</a>
                    <a class="nav-link" id="step3-tab" href="{{ route('superadmin.usermanagement.deptUser.individualUserAddStep3', [$id]) }}">Geo Tagging of Farm Details</a>
                    <a class="nav-link" id="step4-tab" href="{{ route('superadmin.usermanagement.deptUser.individualUserAddStep4', [$id]) }}">Details of standing Crop</a>
                    <a class="nav-link" id="step5-tab" href="{{ route('superadmin.usermanagement.deptUser.individualUserAddStep5', [$id]) }}">Details of Proposed Crop</a>
                    <a class="nav-link active" id="step6-tab" href="{{ route('superadmin.usermanagement.deptUser.individualUserAddStep6', [$id]) }}">List of Documents</a>
                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step6">
                    <div class="card">
                        <!-- <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1">
                                Contact Person Details
                            </h4>

                        </div> -->
                        <!-- end card header -->
                        <div class="card-body">
                            <div class="live-preview">
                                <input type="hidden" name="ref_operator_id" value="3">
                                <div class="row seperatesec white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label">दस्तावेज़ों की सूची/List of Documents</label>
                                    </div>
                                    <hr>
                                    {{-- <div class="col-xxl-3 col-md-6 mt-1">
                                        <div>
                                            <label class="form-label">Aadhaar Numbar of Contact Person/संपर्ककर्ता का आधार नंबर<span class="required">*</span></label>
                                            <input type="file" class="form-control" name="aadhar_card" {{ $document->aadhar_card_image_path ?? 'required'}}>
                                            @if(!empty($document->aadhar_card_image_path))
                                                <input type="hidden" name="aadhar_card_edit" value="{{ ($document->aadhar_card_image_path) ?? ''}}">
                                                <a target="_BLANK" href="{{asset('public/individualProducer/documents/aadhar_card/'.$document->aadhar_card_image_path)}}" class="text-decoration-underline">See Doc</a>
                                            @endif
                                        </div>
                                    </div> --}}

                                    <!-- <div class="col-xxl-3 col-md-6 mt-1">
                                        <div>
                                            <label class="form-label">PAN of Producer/उत्पादक का पैन<span class="required">*</span></label>
                                            <input type="file" class="form-control" name="pan_card" {{ $document->pan_card_image_path ?? 'required'}}>
                                            @if(!empty($document->pan_card_image_path))
                                                <input type="hidden" name="pan_card_edit" value="{{ ($document->pan_card_image_path) ?? ''}}">
                                                <a target="_BLANK" href="{{asset('public/individualProducer/documents/pan_card/'.$document->pan_card_image_path)}}" class="text-decoration-underline">See Doc</a>
                                            @endif
                                        </div>
                                    </div> -->

                                    <div class="col-xxl-3 col-md-6 mt-1">
                                        <div>
                                            <label class="form-label">खेत के भूमि दस्तावेज/Land Documents of Farm<span class="required"></span></label>
                                             {{-- {{ $document->land_documents_image_path ?? ''}} --}}
                                            <input type="file" class="form-control upload_document" name="land_document">
                                            @if(!empty($document->land_documents_image_path))
                                                <input type="hidden" name="land_document_edit" value="{{ ($document->land_documents_image_path) ?? ''}}">
                                                <a target="_BLANK" href="{{asset('public/individualProducer/documents/land_document/'.$document->land_documents_image_path)}}" class="text-decoration-underline">See Doc</a>
                                            @endif
                                        </div>
                                        <p>Allowed Format : PDF only</p>
                                    </div>

                                    <!-- <div class="col-xxl-3 col-md-6 mt-1">
                                        <div>
                                            <label class="form-label">Bank copy/ Passbook of Producer/उत्पादक की बैंक कॉपी/पासबुक<span class="required">*</span></label>
                                            <input type="file" class="form-control" name="bank_passbook" {{ $document->passbook_image_path ?? 'required'}}>
                                            @if(!empty($document->passbook_image_path))
                                                <input type="hidden" name="bank_passbook_edit" value="{{ ($document->passbook_image_path) ?? ''}}">
                                                <a target="_BLANK" href="{{asset('public/individualProducer/documents/bank_passbook/'.$document->passbook_image_path)}}" class="text-decoration-underline">See Doc</a>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="col-xxl-3 col-md-6 mt-3">
                                        <div>
                                            <label class="form-label">Contact Person Sign/Thumb Impression/संपर्ककर्ता  का हस्ताक्षर/अंगूठे का निशान<span class="required"> </span></label>
                                            <input type="file" class="form-control" name="farmer_sign_thumb_Impression" id="farmer_sign_thumb_Impression" {{ $document->contact_person_sign_image_path ?? 'required'}}>
                                            @if(!empty($document->contact_person_sign_image_path))
                                                <input type="hidden" name="farmer_sign_thumb_Impression_edit" value="{{ ($document->contact_person_sign_image_path) ?? ''}}">
                                                <a target="_BLANK" href="{{asset('public/individualProducer/documents/farmer_sign_thumb_Impression/'.$document->contact_person_sign_image_path)}}" class="text-decoration-underline">See Doc</a>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="col-xxl-3 col-md-6 mt-3">
                                        <div>
                                            <label class="form-label">Live Signature/Thumb Impression/हस्ताक्षर/अंगूठे का निशान<span class="required"> </span></label>
                                            <input type="file" class="form-control" name="live_signature_thumb_impression" id="live_signature_thumb_impression" {{ $document->live_signature_image_path ?? 'required'}}>
                                            @if(!empty($document->live_signature_image_path))
                                                <input type="hidden" name="live_signature_thumb_impression_edit" value="{{ ($document->live_signature_image_path) ?? ''}}">
                                                <a target="_BLANK" href="{{asset('public/individualProducer/documents/live_signature_thumb_impression/'.$document->live_signature_image_path)}}" class="text-decoration-underline">See Doc</a>
                                            @endif
                                        </div>
                                    </div> -->
                                    <div class="row">
                                        <div class="col-lg-12 gy-4">
                                            <div class="hstack gap-2">
                                                <a href="{{route('superadmin.usermanagement.deptUser.individualUserAddStep5',$id)}}" class="btn btn-soft-secondary">
                                                    Back
                                                </a>
                                                <button type="submit" class="btn btn-primary">
                                                    Submit
                                                </button>
                                                <!-- <a href="{{route('superadmin.icsuser.step2',$userdetails->id)}}" class="btn btn-soft-success">
                                                    Next
                                                </a> -->
                                            </div>
                                        </div>
                                    </div>
                                </div>






                            </div>
                        </div>
                    </div>
                </div>
        </form>
    </div>
</div>



@endsection
@push('script')

<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $("#registration").validate({
            rules: {
                area_in_hectars: {
                    required: true,
                    digits: true
                },
                khasra_number: {
                    required: true,
                    digits: true
                }
            },
            messages: {

            }

        });
    // Dropzone has been added as a global variable.
    const dropzone = new Dropzone("div.dropzone", {
        url: "{{ route('storeMedia') }}",
        paramName: "file",
        maxFilesize: 2,
        maxFiles: 1,
        acceptedFiles: ".jpeg,.jpg,.png,.mp4,.webm,.html5",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        init: function() {
            var drop = this; // Closure
            this.on('error', function(file, errorMessage) {
                if (errorMessage.indexOf('Error 404') !== -1) {
                    var errorDisplay = document.querySelectorAll('[data-dz-errormessage]');
                    errorDisplay[errorDisplay.length - 1].innerHTML =
                        'Error 404: The upload page was not found on the server';
                }
                if (errorMessage.indexOf('File is too big') !== -1) {
                    alert('Unable to upload image size is greated than 2 MB');
                    // i remove current file
                    drop.removeFile(file);
                }
            });
            this.on("maxfilesexceeded", function(file) {
                    this.removeAllFiles();
                    this.addFile(file);
                }),
                this.on("success", function(file, response) {
                    console.log(response);
                    var hiddenImage = $('<input type="hidden" name="_hidden_legal_doc_upload" value="' +
                        response.name + '"/>');
                    $('.hidden_images_area').html(hiddenImage);
                })
        }
    });

    $(document).ready(function() {
        $("body").on("click", ".add-more-corp", function() {
            var html = $(".after-add-more-corp").first().clone();
            $(html).find(".change-corp").html("<label for=''>&nbsp;</label><br/><a class='btn btn-danger remove-corp'><i class='ri-close-line'></i></a>");
            $(".after-add-more-corp").last().after(html);
        });

        $("body").on("click", ".remove-corp", function() {
            $(this).parents(".after-add-more-corp").remove();
        });
    });



    $('.upload_document').on('change', function() {
            var $this = $(this);
            var file = $this[0].files[0];
            var fileType = file.type;
            var fileSize = file.size;
            var allowedTypes = ['application/pdf'];

            // Check for file type
            if (!allowedTypes.includes(fileType)) {
                Swal.fire({
                    icon: 'error',
                    title: 'Invalid File Extension',
                    text: 'Please upload PDF only.',
                });
                $this.val("");
                return false;
            }

            // Check for file size
            if (fileSize > 1000000) { // 2 MB in bytes
                Swal.fire({
                    icon: 'error',
                    title: 'File Size Too Large',
                    text: 'Please upload files of size 1 MB or less only.',
                });
                $this.val("");
                return false;
            }
        });
</script>

@endpush
@extends('admin.layouts.app')
@section('content')
<style>
    .overlay {
        background: rgb(0 0 0 / 50%);
        position: fixed;
        top: 0;
        z-index: 11111;
        left: 0;
        right: 0;
        bottom: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        display: none;
    }

    .loader {
        position: fixed !important;
        left: 50% !important;
        margin-left: -4em !important;
        top: 20em !important;
    }

    .wrapper {
        max-width: 1240px;
        margin: 0 auto;
    }

    .white-bg {
        background-color: white;
        /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
        border-bottom: 5px solid #ff9800;
        margin-bottom: 15px;
    }

    .auth-one-bg .slide .carousel-indicators {
        bottom: 25px;
    }

    .auth-page-wrapper .auth-page-content {
        padding-bottom: 0px !important;
    }

    .auth-page-content .card {
        margin-bottom: 0rem;
    }

    .data-tabs .wrapper .nav-tabs button {
        font-size: 17px;
        color: black;
    }

    .data-tabs .wrapper .nav-tabs .active {
        background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
        */ color: white;
        background: orange;
        border-radius: 0px;
    }

    .carousel-caption.d-none.d-md-block {
        background-color: #000000bf;
        left: 0;
        width: 100%;
        bottom: 0;
    }

    .carousel-indicators {
        display: none;
    }

    .custom-banner-caption {
        color: white !important;
    }

    .announcement-heading {
        font-size: 1.2em;
        font-weight: 600;
    }

    .data-tabs .tab-pane ul li {
        font-size: 1em;
        padding: 5px 0;

    }

    .main-logo {
        padding: 10px;
    }

    .data-tabs .nav-item .nav-link {
        background-image: none;
    }

    /* .right-sec{
                                                        box-shadow: 5px 10px 18px #888888;
                                                    } */
    .navbar-brand-box {
        background: #fff;
    }

    [data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
        color: white !important;
    }

    .header-buttons .btn-primary {
        margin-right: 10px;
        padding: 6px 15px;
        font-weight: 600;
        background-color: #207005;
        border: none;
        box-shadow: 0px 2px 7px #888888;
    }

    .header-buttons .btn-secondary {
        margin-right: 10px;
        padding: 6px 15px;
        font-weight: 600;
        background-color: #72a055;
        border: none;
        box-shadow: 0px 2px 7px #888888;
    }


    .right-sec {
        border-left: 5px solid #ede7e7;
    }

    .tabdiv {
        background: white;
        padding: 20px;
        margin-top: 10px;
        border: 10px solid #dfdbd5;
    }

    .nav-tabs {
        border-bottom: 0px;
    }

    div#myTabContent {
        border: 1px solid #cccccc;
    }

    .frontfooter footer {
        padding: 20px calc(1.5rem / 2);
        position: static;
        color: #000;
        height: 60px;
        background-color: #f9f9f9;
        margin-top: 30px;
        border-top: 1px solid #e1dfdf;
    }

    span.logo-sm img {
        width: 69px;
    }

    .seperatesec {
        margin-top: 20px;
    }

    .simplebar-content li.nav-item:hover {
        background: #4caf50;
    }

    .sectitle {
        font-size: 14px;
    }

    .required {
        color: red;
    }

    .customtextarea {
        height: 120px;
    }

    ul.boxsection {
        margin: 0;
        padding: 0;
    }

    ul.boxsection li {
        list-style-type: none;
        padding: 7px 0;
        border-bottom: 1px solid #efeded;
    }

    .boxcard .col:nth-child(1) {
        background: #effcfb;
    }

    .boxcard .col:nth-child(2) {
        background: #fdfdfd;
    }

    .boxcard .col:nth-child(3) {
        background: #effcfb;
    }

    .boxcard .col:nth-child(4) {
        background: #fdfdfd;
    }

    .boxcard .col:nth-child(5) {
        background: #effcfb;
    }

    /* --registration-form css  */
    .custom-tab-content {
        padding-top: 0 !important;
        padding-bottom: 0px !important;
    }

    .custom-tab-nav {
        background: white;

    }

    .custom-tab-nav .nav-link {
        border-radius: 0 !important;
        border-bottom: 1px solid #e9ebec;
        border-right: 1px solid #e9ebec;
        font-size: 14px;
        padding: 10px;
    }

    .custom-tab-nav .nav-link.active,
    .custom-tab-nav .show>.nav-link {
        color: rgb(255, 255, 255) !important;
        background-color: #2c8c6d;
        border-bottom: #2c8c6d !important;
        /* border-bottom: #207005 !important; */
        position: relative;
    }

    .custom-tab-nav .nav-link:hover,
    .custom-tab-nav .nav-link:focus {
        border-bottom: 1px solid #207005;
        border-radius: 0;
        font-size: 14px;
        transition: background-color 0.20s linear;
    }

    .custom-tab-nav .nav-link.active:after {
        content: "";
        position: absolute;
        bottom: -16px;
        left: 50%;
        border: 8px solid transparent;
        border-top-color: #2c8c6d;
        z-index: 999;
    }

    .reg-form-btns {
        margin-bottom: 15px;
    }

    .reg-form-btns .btn-secondary {
        color: #fff;
        background-color: #405189;
        border-color: #405189;
    }

    .btn-soft-success:active,
    .btn-soft-success:focus,
    .btn-soft-success:hover {
        border: none;
    }

    .custom-tab-nav ul {
        padding: 0px;
        margin: 0px;
    }

    .custom-tab-nav ul li {
        padding: 0px;
        margin: 0px;
        display: inline-block;
        list-style: none;
    }

    /* -------  */
    .btn-email {
        font-size: 13px;
        padding: 1px 7px;
        line-height: 17px;

    }

    .btn-mailsend {
        font-size: 13px;
        padding: 1px 7px;
        line-height: 17px;
    }

    .btn-verify {
        font-size: 13px;
        padding: 1px 7px;
        line-height: 34px;
    }

    .inputEmail .input-group-append {
        display: flex;
        align-items: end;
    }

    .inputEmail .validateEmailId {
        border-radius: 4px 0 0 4px;
    }

    .input-group-append .verifiEmail_otp,
    .input-group-append .resendEmail_otp {
        margin-left: 10px;
    }

    .login-pass.otp-email {
        margin-top: 5px
    }

    .login-pass.otp-email .inp-b {
        border-radius: 0 4px 4px 0
    }

    #loader {
        position: fixed;
        /* Stay in place */
        left: 50%;
        /* Center horizontally */
        top: 50%;
        /* Center vertically */
        transform: translate(-50%, -50%);
        /* Translate to center from top-left corner */
        z-index: 9999;
        /* Ensure it stays on top of other content */
        width: 100px;
        /* Optional: Adjust loader size */
        height: 100px;
        /* Optional: Adjust loader size */
    }
</style>

<div class="overlay">
    <div class="loader"></div>
</div>
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">ऑपरेटर जोड़ें/Add Operator</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">User Management</a></li>
                    <li class="breadcrumb-item active">Add Operator</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                @if ($id == 3)
                <h4 class="card-title mb-0 flex-grow-1">व्यक्तिगत उत्पादक का पंजीकरण/Registration of {{ getOperatorTypeById($id) }}/</h4>
                @elseif($id == 5)
                <h4 class="card-title mb-0 flex-grow-1">व्यापारी का पंजीकरण/Registration of {{ getOperatorTypeById($id) }}</h4>
                @elseif($id == 4)
                <h4 class="card-title mb-0 flex-grow-1">वन कटाईकर्ता का पंजीकरण/Registration of {{ getOperatorTypeById($id) }}</h4>
                @elseif($id == 6)
                <h4 class="card-title mb-0 flex-grow-1">प्रोसेसर का पंजीकरण/Registration of {{ getOperatorTypeById($id) }}</h4>
                @else
                <h4 class="card-title mb-0 flex-grow-1">उत्पादक समूह का पंजीकरण/Registration of {{ getOperatorTypeById($id) }}</h4>
                @endif
                <div class="flex-shrink-0">
                    @if (session('error'))
                    <div class="alert alert-danger">
                        {{ session('error') }}
                    </div>
                    @endif
                    @if (session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                    @endif
                    @if ($errors)
                    @foreach ($errors->all() as $error)
                    <div class="alert alert-danger">{{ $error }}</div>
                    @endforeach
                    @endif
                </div>
            </div>
            <div class="card-body">
                <div class="live-preview">
                    <form action="{{ route('superadmin.usermanagement.deptUser.store') }}" class="commonform1"
                        method="POST" enctype="multipart/form-data" id="commonform1" autocomplete="off">
                        @csrf
                        <input type="hidden" name="role_id" id="role_id" value="{{ $id }}">
                        <input type="hidden" name="user_id" id="user_id" value="{{ $cbId }}">
                        <input type="hidden" name="standerd_type" value="Crop_Production">
                        <input type="hidden" name="registration_form" id="registration_form" value="internal_registration">
                        <input type="hidden" name="panNumberResponse" id="panNumberResponse" value="">
                        <input type="hidden" name="panNameResponse" id="panNameResponse" value="">
                        <input type="hidden" name="panDobResponse" id="panDobResponse" value="">
                        <input type="hidden" name="panVerifyResponse" id="panVerifyResponse" value="">
                        <div class="row gy-4">
                            <div class="col-xxl-3 col-md-6">
                                <div>
                                    {{-- <label for="basiInput" class="form-label">Select Operator Type<span
                                            class="required">*</span></label>
                                     <select name="role_id" id="member" class="form-select" disabled>
                                        <option value="">Select Operator</option>
                                        @if (count(get_roles()) > 0)
                                        @foreach (get_roles() as $role)
                                        @if ($role->id != Auth::guard('misadmin')->user()->role->role_id)
                                        <option value="{{$role->id}}"
                                    {{ $role->id==$id?'selected':''}}>{{$role->title}}</option>
                                    @endif
                                    @endforeach
                                    @endif
                                    </select> --}}

                                </div>
                            </div>
                            <div class="row white-inner">
                                {{-- <div class="row seperatesec white-inner"> --}}

                                {{-- <div class="col-xxl-3 col-md-6">
                                    <div>
                                        <label class="form-label">Standerd Type <span class="required">*</span></label>
                                        <select class="form-select" name="standerd_type">
                                            <option value="Crop_Production" selected>Crop Production</option>
                                        </select>
                                    </div>
                                </div>
                                 --}}
                                {{-- @if ($id == 6)
                                        <div class="col-xxl-3 col-md-6">
                                            <div>
                                                <label class="form-label">FSSAI License Number<span class="required">
                                                        *</span></label>
                                                <input type="text" class="form-control  fssai_license_number"
                                                    id="fssai_license_number" placeholder="FSSAI License Number"
                                                    name="fssai_license_number[]" required>
                                                <label for="agreement_status" class="success fssi_success d-none"
                                                    style="color:green">License Verified.</label>
                                            </div>
                                        </div>
                                    @endif --}}

                                <div class="col-xxl-3 col-md-6 mb-4">
                                    <div>
                                        <label for="basiInput" class="form-label">कानूनी दस्तावेज़ चयन करें/Legal Document<span class="required">*</span></label>
                                        <select class="form-select" name="document_type" id="document_type" required>
                                            <option value="">select</option>
                                            <option value="PAN" {{isset($userdetails->document_type) && $userdetails->document_type == 'PAN' ? 'selected' : '' }}> PAN</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-xxl-3 col-md-6 mb-4">
                                    <div>
                                        <label for="labelInput" class="form-label">कानूनी प्रतिष्ठान प्रकार/Legal Entity Type</label>
                                        <select name="entity_firm" id="entity_firm" class="form-select">
                                            <option value="">--Select Entity--</option>
                                            @if ($id == 2)
                                            <!-- <option
                                                        value="Society Registration Act"{{ old('entity_firm') == 'Society_Registered' ? 'selected' : '' }}>
                                                        Society Registration Act</option> -->
                                            <option value="Registered Society" data-docType="NA" title="Society registered under the Societies Registration Act, 1860 or relevant State Societies Act/Rules" {{ old('entity_firm') == 'Society_Registered' ? 'selected' : '' }}> Registered Society </option>



                                            <option value="FPO/FPC" data-docType="NA" title="Farmers Producer Organization (FPO)/Farmers Producer Company (FPC) incorporated under the Companies Act, 2013, as amended from time to time" {{ old('entity_firm') == 'Registered_society' ? 'selected' : '' }}> FPO/FPC</option>
                                            <option value="Co-operative society/PACs/FPO" data-docType="NA" title=" Co-operative society, including Primary Agricultural Co-operative Societies (PACs) and Farmers Producer Organization (FPO), registered under the relevant state Co-operative Societies Act/Rules" {{ old('entity_firm') == 'Society_Cooperative' ? 'selected' : '' }}> Co-operative society/PACs/FPO</option>

                                            {{-- <option value="Indian Companies Act"{{ old('entity_firm') == 'Indian_Companies' ? 'selected' : '' }}>Indian Companies Act</option> --}}
                                            @elseif($id == 3)
                                            <option value="Indian Companies Act" data-docType="NA" {{ old('entity_firm') == 'Individual_Producer_Company' ? 'selected' : '' }}> Indian Companies Act</option>
                                            <option value="Propietor" data-docType="Y" {{ old('entity_firm') == 'Propietor' ? 'selected' : '' }}>Propietor</option>
                                            @elseif($id == 4)
                                            <option value="Indian Companies Act" data-docType="NA" {{ old('entity_firm') == 'Individual_Producer_Company' ? 'selected' : '' }}>Indian Companies Act</option>
                                            @elseif($id == 5)
                                            <option value="Indian Companies Act" data-docType="NA" {{ old('entity_firm') == 'Individual_Producer_Company' ? 'selected' : '' }}> Indian Companies Act</option>
                                            @elseif($id == 6)
                                            <option value="Indian Companies Act" data-docType="NA" {{ old('entity_firm') == 'Individual_Producer_Company' ? 'selected' : '' }}> Indian Companies Act</option>
                                            @endif
                                        </select>
                                    </div>
                                </div>
                                <div class="col-xxl-6 col-md-6 mb-4"></div>
                                <div class="col-xxl-3 col-md-6 mb-4">
                                    <div>
                                        @if ($id == 6)
                                        <label class="form-label">प्रोसेसर का नाम/Name of Processor<span class="form-text">(As per Legal Document)</span><span class="required">*</span></label>
                                        @elseif($id == 4)
                                        <label class="form-label">वन कटाईकर्ता का नाम/Name of Wild Harvester<span class="form-text">(As per PAN)/(कानूनी दस्तावेज़ के अनुसार)</span><span class="required">*</span></label>
                                        @else
                                        <label class="form-label">उत्पादक समूह का नाम/Name of {{ getOperatorTypeById($id) }} <span class="form-text">(As per PAN)</span><span class="required">*</span></label>
                                        @endif
                                        <input type="text" class="form-control keyValueChecker" id="name" placeholder="Name of {{ $id == 3 ? 'Individual Producer' : getOperatorTypeById($id) }} " name="first_name" required value="{{ old('first_name') }}">
                                    </div>
                                    <div class="mt-1" id="panName_response"></div>
                                </div>
                                <div class="col-xxl-3 col-md-6 mb-4">
                                    <div>
                                        @if ($id == 2)
                                        <label class="form-label">संस्थापन की तारीख/Date of incorporation<span class="form-text">(As per PAN)</span>
                                            <span class="required">*</span></label>
                                        <input type="hidden" name="detailType" id="detailType" value="OG">
                                        @else
                                        <label class="form-label"><span id="dob_doi_date_label">जन्म तिथि/Date of Birth/</span><span class="form-text">(As per PAN)</span>
                                            <span class="required">*</span></label>
                                        <input type="hidden" name="detailType" id="detailType" value="IN">
                                        @endif
                                        <input type="date" class="form-control" id="dob_doi_date" name="dob_doi_date" required value="{{ old('dob_doi_date', isset($yourModel) ?  $yourModel->dob_doi_date->format('Y-m-d') : '') }}" max="{{ now()->format('Y-m-d') }}">
                                    </div>
                                    <div class="mt-1" id="panDob_response"></div>
                                </div>
                                <div class="col-xxl-3 col-md-6 mb-4 d-none" id="fatherName_add">
                                    <div class="mb-2">
                                        <label class="form-label"> पिता का नाम/Father Name<span class="form-text">(As per PAN)</span> <span class="required">*</span></label>
                                        <input type="text" class="form-control" id="father_name" placeholder="Father Name" name="father_name" value="{{ old('father_name') }}" required>
                                    </div>
                                    <div class="mt-1" id="fatherName_response"></div>
                                </div>
                                <div class="col-xxl-3 col-md-6 mb-4">
                                    <div class="mb-2">
                                        <label class="form-label">पैन संख्या/PAN Number<span class="required">*</span></label>
                                        <input type="text" class="form-control pan" id="operator_pan" placeholder="PAN Number" name="user_name" value="{{ old('user_name') }}" maxlength="10" required onblur="getDetailsPan(this.value)">
                                    </div>
                                    <div class="mt-1" id="panNumber_response"></div>
                                    <div class="text-end"><button type="button" id="panVerificationForm" class="btn btn-sm btn-success fs-13 text-decoration-underline"> पैन सत्यापित करें/Verfiy PAN</button></div>
                                </div>
                                @if ($id == 6)
                                <div class="col-xxl-3 col-md-6 mb-3">
                                    <label class="form-label">प्रोसेसर लाइसेंस प्रकार/Processor License Type<span class="required">*</span></label>

                                    <select class="form-control" id="processor_type" name="processor_type" required onchange="toggleLicenseInputs()">
                                        <option value="" disabled selected>Select Processor License Type </option>
                                        <option value="fssai"> एफएसएसएआई लाइसेंस नंबर/FSSAI License No.</option>
                                        <option value="ayush">आयुष लाइसेंस नंबर/AYUSH License No.</option>
                                    </select>

                                </div>

                                <div id="fssai_section" class="license-inputs d-none ">
                                    <div class="col-xxl-3 col-md-6 mb-3">
                                        <div>
                                            <label class="form-label">एफएसएसएआई लाइसेंस नंबर/FSSAI License No.<span class="required">*</span></label>
                                            <input type="text" class="form-control fssai_license_number @if ($errors->has('fssai_licence')) is-invalid @endif" id="fssai_license_number" placeholder="FSSAI License Number" name="fssai_licence" required>
                                            <label for="agreement_status" class="success fssi_success d-none" style="color:green">लाइसेंस सत्यापित किया गया/License Verified.</label>
                                        </div>
                                        @if ($errors->has('fssai_licence'))
                                        <div class="invalid-feedback"> {{ $errors->first('fssai_licence') }} </div>
                                        @endif
                                    </div>
                                    <div class="col-xxl-3 col-md-6 mb-3 mt-3">
                                        <div>
                                            <label class="form-label">एफएसएसएआई लाइसेंस वैधता तिथि/FSSAI License Validity Date<span class="required">*</span></label>
                                            <input type="date" class="form-control ayush_license_validity_date @if ($errors->has('ayush_validity')) is-invalid @endif" id="fssai_license_validity_date" name="fssai_validity" required>
                                            <label for="agreement_status" class="success ayush_validity_date_success d-none" style="color:green">लाइसेंस तिथि सत्यापित की गई/License Date Verified.</label>
                                        </div>
                                        @if ($errors->has('fssai_validity'))
                                        <div class="invalid-feedback"> {{ $errors->first('fssai_validity') }} </div>
                                        @endif
                                    </div>
                                </div>
                                <div id="ayush_section" class="license-inputs d-none">
                                    <div class="col-xxl-3 col-md-6 mb-3 mt-3">
                                        <div>
                                            <label class="form-label">आयुष लाइसेंस संख्या/AYUSH License No.<span class="required">*</span></label>
                                            <input type="text" class="form-control ayush_license_number @if ($errors->has('ayush_licence')) is-invalid @endif" id="ayush_license_number" placeholder="Ayush License Number" name="ayush_licence" required>
                                            <label for="agreement_status" class="success ayush_success d-none" style="color:green">लाइसेंस सत्यापित किया गया/License Verified.</label>
                                        </div>
                                        @if ($errors->has('ayush_licence'))
                                        <div class="invalid-feedback">
                                            {{ $errors->first('ayush_licence') }}
                                        </div>
                                        @endif
                                    </div>
                                    <div class="col-xxl-3 col-md-6 mb-3 mt-3">
                                        <div>
                                            <label class="form-label"> आयुष लाइसेंस वैधता तिथि/AYUSH License Validity Date<span class="required">*</span></label>
                                            <input type="date" class="form-control ayush_license_validity_date @if ($errors->has('ayush_validity')) is-invalid @endif" id="ayush_license_validity_date" name="ayush_validity" required>
                                            <label for="agreement_status" class="success ayush_validity_date_success d-none" style="color:green">लाइसेंस तिथि सत्यापित की गई/License Date Verified.</label>
                                        </div>
                                        @if ($errors->has('ayush_validity'))
                                        <div class="invalid-feedback">
                                            {{ $errors->first('ayush_validity') }}
                                        </div>
                                        @endif
                                    </div>

                                    <div class="col-xxl-3 col-md-6 mb-3 mt-3">
                                        <div>
                                            <label class="form-label">आयुष लाइसेंस अटैचमेंट/AYUSH License Attachment <span
                                                    class="required">*</span></label>
                                            <input type="file"
                                                class="form-control ayush_license_validity_date @if ($errors->has('ayush_license_file')) is-invalid @endif"
                                                id="ayush_license_file" name="ayush_license_file" required>

                                        </div>
                                        @if ($errors->has('ayush_validity'))
                                        <div class="invalid-feedback">
                                            {{ $errors->first('ayush_validity') }}
                                        </div>
                                        @endif
                                    </div>
                                </div>
                            </div>
                            @elseif ($id == 5)
                            <div class="col-xxl-3 col-md-6 mb-3 mt-3">
                                <div>
                                    <label class="form-label">एफएसएसएआई लाइसेंस नंबर/FSSAI License No.<span class="required">
                                            *</span></label>
                                    <input type="text"
                                        class="form-control fssai_license_number @if ($errors->has('fssai_licence')) is-invalid @endif"
                                        id="fssai_license_number" placeholder="FSSAI License Number"
                                        name="fssai_licence" value="{{ old('fssai_licence') }}" required>
                                    <label for="agreement_status" class="success fssi_success d-none"
                                        style="color:green">License Verified.</label>
                                </div>
                                @if ($errors->has('fssai_licence'))
                                <div class="invalid-feedback">
                                    {{ $errors->first('fssai_licence') }}
                                </div>
                                @endif
                            </div>

                            <div class="col-xxl-3 col-md-6 mb-3 mt-3">
                                <div>
                                    <label class="form-label">एफएसएसएआई लाइसेंस वैधता तिथि/FSSAI License Validity Date<span class="required">
                                            *</span></label>
                                    <input type="date"
                                        class="form-control  ayush_license_validity_date @if ($errors->has('fssai_validity')) is-invalid @endif"
                                        id="ayush_license_validity_date" name="fssai_validity"
                                        value="{{ old('fssai_validity') }}" required>
                                    <label for="agreement_status" class="success ayush_validity_date_success d-none"
                                        style="color:green">License Date Verified.</label>
                                </div>
                                @if ($errors->has('fssai_validity'))
                                <div class="invalid-feedback">
                                    {{ $errors->first('fssai_validity') }}
                                </div>
                                @endif
                            </div>
                            <div class="col-xxl-3 col-md-6 mb-3 mt-3">
                                <div>
                                    <label class="form-label">आईईकोड/IECODE</label>
                                    <input type="input"
                                        class="form-control ie_code @if ($errors->has('iecode')) is-invalid @endif"
                                        id="ie_code" placeholder="IECODE" name="iecode"
                                        value="{{ old('iecode') }}">
                                    <label for="agreement_status" class="success ie_code_success d-none"
                                        style="color:green">IECODE Verified.</label>
                                </div>
                                @if ($errors->has('iecode'))
                                <div class="invalid-feedback">
                                    {{ $errors->first('iecode') }}
                                </div>
                                @endif
                            </div>
                            <div class="col-xxl-3 col-md-6 mb-3 mt-3">
                                <div>
                                    <label class="form-label">आईईकोड अटैचमेंट/IECODE Attachment</label>
                                    <input type="file"
                                        class="form-control ayush_license_attachment @if ($errors->has('ayush_doc_path')) is-invalid @endif"
                                        id="ayush_license_attachment" placeholder="AYUSH License Attachment"
                                        name="icode_attachment" accept=".pdf,.doc,.png,.jpeg,.jpg">
                                </div>
                                @if ($errors->has('ayush_doc_path'))
                                <div class="invalid-feedback">
                                    {{ $errors->first('ayush_doc_path') }}
                                </div>
                                @endif
                                <span class="form-text">Supported formats:JPG, PNG, PDF. Upto 2MB</span>
                            </div>
                            @elseif ($id == 4)
                            <div class="col-xxl-3 col-md-6 mb-3">
                                <div>
                                    <label class="form-label">वन लाइसेंस नंबर/Forest License No.<span class="required">
                                            *</span></label>
                                    <input type="text"
                                        class="form-control forest_license_number @if ($errors->has('forest_licence')) is-invalid @endif"
                                        id="forest_license_number" placeholder="Forest License Number"
                                        name="forest_licence" required>
                                    <label for="agreement_status" class="success forest_success d-none"
                                        style="color:green">License Number Verified.</label>
                                </div>
                                @if ($errors->has('forest_licence'))
                                <div class="invalid-feedback">
                                    {{ $errors->first('forest_licence') }}
                                </div>
                                @endif
                            </div>
                            <div class="col-xxl-3 col-md-6 mb-3">
                                <div>
                                    <label class="form-label">वन लाइसेंस अटैचमेंट/Forest License Attachment<span class="required">
                                            *</span></label>
                                    <input type="file" class="form-control  forest_license_attachment"
                                        id="forest_license_attachment" placeholder="Forest License Attachment"
                                        name="forest_doc_path" required accept=".pdf,.doc,.png,.jpeg,.jpg">
                                    <label for="agreement_status" class="success forest_attachment_success d-none"
                                        style="color:green">Forest Attachment Uploaded.</label>
                                </div>
                                @if ($errors->has('employee_code'))
                                <div class="invalid-feedback">
                                    {{ $errors->first('employee_code') }}
                                </div>
                                @endif
                                <span class="form-text">Supported formats:JPG, PNG, PDF. Upto 2MB</span>
                            </div>
                            @endif
                        </div>

                        <div class="row seperatesec white-inner">
                            <div class="sectitle">
                                @if ($id == 6)
                                <label for="labelInput" class="form-label">Address of Processing Unit(as per license)</label>
                                @else
                                <label for="labelInput" class="form-label">आईसीएस का पता/{{ getOperatorTypeById($id) }}
                                    Address</label>
                                @endif

                            </div>
                            <div class="row">
                                <div class="col-xxl-3 col-md-3">
                                    <div class="row">
                                        <div class="col-xx-12 col-md-12">
                                            <label for="labelInput" class="form-label ">पता/Address<span
                                                    class="required">*</span></label>
                                            <textarea class="form-control customtextarea" name="address" required maxlength="250">{{ old('address') }}</textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xxl-9 col-md-9">
                                    <div class="row">
                                        <div class="col-xxl-4 col-md-4">
                                            <label for="labelInput" class="form-label">राज्य/State / UT <span
                                                    class="required">*</span></label>
                                            <select class="form-select state" name="state" id="state" required>
                                                <option value="">Select State</option>
                                                {{-- @forelse(getAllState() as $state)
                                                        <option value="{{ $state->id }}" @selected(old('state') == $state->id)>
                                                {{ $state->state_name }}
                                                </option>
                                                @empty
                                                @endforelse --}}

                                                @forelse($CBstateAssign as $state)
                                                <option value="{{ $state->refStateId  }}" @selected(old('state')==$state->id)>
                                                    {{ $state->state_name }}
                                                </option>
                                                @empty
                                                @endforelse

                                            </select>
                                        </div>
                                        <div class="col-xxl-4 col-md-4">
                                            <label for="labelInput" class="form-label">जिला/District<span
                                                    class="required">*</span></label>
                                            <select class="form-select district" name="district" id="district"
                                                required>
                                                @forelse(getDistrictByStateID(old('state')) as $district)
                                                <option value="{{ $district->id }}" @selected(old('district')==$district->id)>
                                                    {{ $district->district_name }}
                                                </option>
                                                @empty
                                                <option value="">-Select District-</option>
                                                @endforelse


                                            </select>
                                        </div>
                                        <div class="col-xxl-4 col-md-4">
                                            <label for="labelInput" class="form-label">तालुका/मंडल/Taluka/Mandal
                                                <span class="required">*</span></label>
                                            <select class="form-select block_tehsil" name="taluka" id="block_tehsil"
                                                required>

                                                @forelse(getBlockTehsilByDistrictID(old('district')) as $block)
                                                <option value="{{ $block->id }}" @selected(old('taluka')==$block->id)>
                                                    {{ $block->block_tehsil_name }}
                                                </option>
                                                @empty
                                                <option value="">-Select Taluka/Mandal-</option>
                                                @endforelse


                                            </select>
                                        </div>

                                        <div class="col-xxl-6 col-md-6 gy-3">
                                            <label for="labelInput" class="form-label">गाँव/Village<span
                                                    class="required">*</span></label>

                                            <select class="form-select village" name="village" id="village"
                                                required>
                                                @forelse(getVillageByBlock(old('taluka')) as $village)
                                                <option value="{{ $village->id }}" @selected(old('village')==$village->id)>
                                                    {{ $village->village_name }}
                                                </option>
                                                @empty
                                                <option value="">-Select Village-</option>
                                                @endforelse
                                            </select>

                                        </div>
                                        <div class="col-xxl-6 col-md-6 gy-3">
                                            <div>
                                                <label for="labelInput" class="form-label">पिन कोड/Pin Code<span
                                                        class="required">*</span></label>
                                                <input type="text" class="form-control numbersonly" id="pin_code"
                                                    name="pin_code" placeholder="Pin Code" maxlength="6" required
                                                    value="{{ old('pin_code') }}">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="row seperatesec white-inner">
                            <div class="sectitle">
                                <label for="labelInput" class="form-label">
                                    @if ($id == 3)
                                    व्यक्तिगत उत्पादक से
                                    संपर्ककर्ता/Contact Person From {{ getOperatorTypeById($id) }}
                                    @elseif($id == 5)
                                    व्यापारी से संपर्ककर्ता/Contact Person From {{ getOperatorTypeById($id) }}
                                    @elseif($id == 4)
                                    वन कटाईकर्ता
                                    से संपर्ककर्ता/Contact Person From {{ getOperatorTypeById($id) }}
                                    @elseif($id == 6)
                                    प्रोसेसर से संपर्ककर्ता/Contact Person From {{ getOperatorTypeById($id) }}
                                    @else
                                    उत्पादक समूह से संपर्क व्यक्ति/Contact Person From {{ getOperatorTypeById($id) }}
                                    @endif
                                </label>

                                <img src="{{ asset('public/assets/images/load.gif') }}" id="loader"
                                    style="display:none;" alt="Loading...">
                            </div>





                            <div class="col-xxl-3 col-md-6 mt-4">
                                <div>
                                    <label class="form-label">संपर्ककर्ता का नाम/Contact Person First Name<span
                                            class="required">*</span></label>
                                    <input type="text" class="form-control textonly" id="contact_first_name"
                                        placeholder="First Name" name="contact_first_name"
                                        value="{{ old('contact_first_name') }}" required>
                                </div>
                            </div>

                            <div class="col-xxl-3 col-md-6 mt-4">
                                <div>
                                    <label class="form-label">संपर्ककर्ता का मध्य
                                        नाम/Contact Person Middle Name</label>
                                    <input type="text" class="form-control textonly" id="contact_middle_name"
                                        name="contact_middle_name" placeholder="Middle Name"
                                        value="{{ old('contact_middle_name') }}">
                                </div>
                            </div>

                            <div class="col-xxl-3 col-md-6 mt-4">
                                <div>
                                    <label class="form-label">संपर्ककर्ता का उपनाम/Contact Person Last Name<span
                                            class="required">*</span></label>
                                    <input type="text" class="form-control textonly" id="contact_last_name"
                                        name="contact_last_name" placeholder="Last Name" required
                                        value="{{ old('contact_last_name') }}">
                                </div>
                            </div>
                            <div class="col-xxl-3 col-md-6 mt-4">
                                <div>
                                    <label for="labelInput" class="form-label">लिंग/Gender</label>
                                    <select name="contact_gender" class="form-select">
                                        <option value="">Select Gender</option>
                                        @foreach (getGenderName() as $key => $value)
                                        <option value="{{ $key }}"
                                            {{ old('contact_gender') == 1 ? 'selected' : '' }}>
                                            {{ $value }}
                                        </option>
                                        @endforeach

                                    </select>
                                </div>
                            </div>

                            {{-- </div> --}}
                            {{-- <div class="row white-inner"> --}}
                            {{-- <div class="col-xxl-3 col-md-6 gy-3 mt-4">
                    <div>
                        <label for="labelInput" class="form-label">Contact Person Mobile
                            Number(mask as per the guidelines of Aadhaar )/संपर्ककर्ता का मोबाइल नंबर<span class="required">*</span></label>
                        <input type="text" class="form-control numbersonly phone" id="mobile" required name="mobile"
                            placeholder="Mobile Number" onblur="phonenumber(this)" maxlength="10"
                            value="{{ old('mobile') }}">
                        </div>
                </div> --}}

                {{-- <div class="col-xxl-3 col-md-6 gy-3 mt-4">
                                        <div>
                                            <label for="labelInput" class="form-label">
                                                Contact Person Mobile Number (mask as per the guidelines of
                                                Aadhaar)/संपर्ककर्ता का मोबाइल नंबर
                                                <span class="required">*</span>
                                            </label>
                                            <input type="text" class="form-control numbersonly phone"
                                                id="mobile_number" required name="mobile_number"
                                                placeholder="Mobile Number" maxlength="10"
                                                value="{{ old('mobile_number') }}">
                <button type="button" class="btn btn-primary mt-2" onclick="sendOtp()">Get
                    OTP</button>



            </div>
        </div> --}}

        {{-- <div class="col-xxl-3 col-md-6 gy-3 mt-4">
                                        <div>
                                            <label for="labelInput" class="form-label">
                                                Contact Person Mobile Number (mask as per the guidelines of
                                                Aadhaar)/संपर्ककर्ता का मोबाइल नंबर
                                                <span class="required">*</span>
                                            </label>
                                            <input type="text" class="form-control numbersonly phone"
                                                id="mobile_number" required name="mobile_number"
                                                placeholder="Mobile Number" onblur="phonenumber(this)" maxlength="10"
                                                value="{{ old('mobile_number') }}">

        <button type="button" class="btn btn-primary mt-2" id="getOtpBtn"
            onclick="sendOtp()">Get OTP</button>


        <button type="button" class="btn btn-success mt-2" id="verifiedBtn"
            style="display: none;" disabled>Verified</button>

    </div>
</div> --}}


<div class="col-xxl-3 col-md-6 gy-3 mt-4">
    <div>
        <label for="labelInput" class="form-label">
            संपर्ककर्ता का मोबाइल नंबर/Contact Person Mobile Number
            <span class="required">*</span>
        </label>

        <!-- Mobile Number Input -->
        <input type="text" class="form-control numbersonly phone" id="mobile_number"
            required name="mobile_number" placeholder="Mobile Number"
            onchange="phonenumber(this)" maxlength="10"
            value="{{ old('mobile_number') }}">

        <!-- Get OTP Button -->
        <button type="button" class="btn btn-primary mt-2" id="getOtpBtn"
            onclick="sendOtp()">Get OTP</button>

        <!-- Resend OTP Button (Initially Hidden) -->
        <button type="button" class="btn btn-warning mt-2" id="resendOtpBtn"
            onclick="sendOtp()" style="display: none;">Resend OTP</button>

        <!-- Verified Button (Initially Hidden) -->
        <button type="button" class="btn btn-success mt-2" id="verifiedBtn"
            style="display: none;" disabled>Verified</button>

        <!-- OTP Input Section (Initially Hidden) -->
        <div id="otp_section" style="display: none;">
            <input type="text" id="otp_input" class="form-control mt-2"
                placeholder="Enter OTP" maxlength="6">
            <button type="button" class="btn btn-primary mt-2"
                onclick="verifyOtp()">Verify OTP</button>
        </div>
    </div>
</div>


<div class="col-xxl-3 col-md-6 gy-3 mt-4" id="otp_section" style="display:none;">
    <div>
        <label for="otpInput" class="form-label">Enter OTP</label>
        <input type="text" class="form-control" id="otp" required
            name="otp" placeholder="Enter OTP" maxlength="6">
        <button type="button" class="btn btn-success mt-2" onclick="verifyOtp()">Verify
            OTP</button>
    </div>
</div>



<!-- <div class="col-xxl-3 col-md-6 gy-3">
                                                                                    <div>
                                                                                        <label for="labelInput" class="form-label">Email Id<span
                                                                                                class="required">*</span></label>
                                                                                        <input type="email" class="form-control validateEmail" id="email" name="email"
                                                                                            placeholder="Email Id*" value="{{ old('email') }}" required>
                                                                                    </div>
                                                                                </div> -->


<!-- email verification  -->

<div class="col-xxl-3 col-md-6 gy-3 mt-4">
    <div class="inputEmail  col-12 col-sm-12 col-md-12 col-lg-12">
        <div class="form-group d-flex justify-content-center ge-otp-form">
            <div class="col-12 col-sm-12 col-md-10 col-lg-10">
                <label>संपर्ककर्ता की ईमेल आईडी/Contact Person Email Id<span
                        class="text-danger">*</span></label>
                <input
                    class="form-control validateEmailId col-12 col-sm-12 col-md-12 col-lg-12"
                    type="text" value="{{ old('email') }}" placeholder="Email Id"
                    id="email_id1" name="email" />
            </div>
            <div class="input-group-append col-12 col-sm-12 col-md-2 col-lg-2">
                <button type="button"
                    class="btn-email btn btn-outline-success waves-effect waves-light visitorCat2">Get
                    OTP</button>
                <button type="button"
                    class="btn btn-ghost-success waves-effect waves-light btn-mailsend"
                    style="display:none">Mail Send</button>
                <button type="button"
                    class="btn btn-ghost-success waves-effect waves-light btn-verify"
                    style="display:none">Verified</button>
            </div>
        </div>
        <div class="verify-email justify-content-center">
            <div class="login-pass mb-4 otp-email col-12 col-sm-12 col-md-5 col-lg-12 pl-2"
                style="display:none">
                <div class="input-group">
                    <span class="input-group-text mdi mdi-key"
                        id="inputGroup-sizing-default"></span>
                    <input type="text" class="form-control inp-b"
                        aria-label="Sizing example input"
                        aria-describedby="inputGroup-sizing-default" id="email_otp1">
                    <div class="input-group-append">
                        <a href="javascript:void(0)"
                            class="verifiEmail_otp btn btn-outline-success waves-effect waves-light">Verify</a>
                        <a href="javascript:void(0)"
                            class="resendEmail_otp btn btn-outline-danger waves-effect waves-light">Resend</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end -->
<div class="col-xxl-3 col-md-6 gy-3 mt-4">
    <div>
        <label for="labelInput" class="form-label">संपर्ककर्ता का आधार नंबर/Contact
            Person Aadhaar Number<span
                class="required">*</span></label>
        <input type="text" class="form-control numbersonly"
            name="contact_person_aadhar_number" required placeholder="Aadhaar Number*" id="contact_person_aadhar_number"
            value="" maxlength="12">
    </div>
</div>
<div class="col-xxl-3 col-md-6 gy-3 mt-4">
    <div>
        <label for="labelInput" class="form-label">संपर्ककर्ता का पदनाम/Designation of Contact Person</label>
        <select name="contact_designation" class="form-select">
            <option value="">Select Designation</option>
            {{-- <option value="{{ getOperatorTypeById($id) }} Manager"
            {{ old('contact_designation') == 'Manager' ? 'selected' : '' }}>
            {{ getOperatorTypeById($id) }} Manager</option> --}}
            <option value="Manager"
                {{ old('contact_designation') == 'Manager' ? 'selected' : '' }}>Manager
            </option> -
            {{-- <option value="Owner" {{ old('contact_designation') == 'Owner' ? 'selected' : '' }}>Owner</option> --}}
            <!-- <option value="CEO" {{ old('contact_designation') == 'CEO' ? 'selected' : '' }}>CEO</option>
                                                                        <option value="MD" {{ old('contact_designation') == 'MD' ? 'selected' : '' }}>MD</option>
                                                                        <option value="Director" {{ old('contact_designation') == 'Director' ? 'selected' : '' }}>Director
                                                                        </option>
                                                                        <option value="Partner" {{ old('contact_designation') == 'Partner' ? 'selected' : '' }}>Partner
                                                                        </option>
                                                                        <option value="Proprietor" {{ old('contact_designation') == 'Proprietor' ? 'selected' : '' }}>
                                                                            Proprietor</option> -->
        </select>

    </div>
</div>



{{-- <div class="col-xxl-3 col-md-6 gy-3">
                                    <label for="labelInput" class="form-label"></label><br>
                                     <button type="button" class="btn btn-primary" style="margin-top:2.5%!important">Send OTP</button>

                                </div> --}}


<div class="col-xxl-3 col-md-7 gy-4 form-check">
    <input type="checkbox" class="form-check-input" id="declaration_consent">
    <label style="color: blue; width: 1100px ">
        मैं/हम, {{ Auth::guard('misadmin')->user()->first_name }} द्वारा यह घोषित करता/करते हैं कि सभी जानकारी/दस्तावेज़ सत्य, सटीक हैं और मूल रूप में सत्यापित किए गए हैं। मैं/हम ऑपरेटर के अनुरोध को स्वीकार करता/करते हैं कि उनका पैन/आधार और अन्य दस्तावेज/लाइसेंस सत्यापन उद्देश्यों के लिए उपयोग किए जाएं और समय-समय पर आवश्यकतानुसार नियामक निकायों के साथ जानकारी/दस्तावेज़ साझा करने के लिए सहमति प्रदान करता/करते हैं। ऑपरेटर से लिखित सहमति प्राप्त की गई है।
        <br>
        I/We
        {{ Auth::guard('misadmin')->user()->first_name }} hereby declare that all the
        information/documents provided is true, accurate and have been verified in original.
        I/We acknowledge and agree to the operator's request<br> to use their PAN/Aadhaar and
        other documents/licenses for verification purposes and consent for sharing of
        the information/documents with regulatory bodies as required from time to time. The
        written consent has been obtained from the operator.</label>
</div>


<div class="row">
    <div class="col-lg-12 gy-4">
        <div class="hstack gap-2">
            <button type="submit" class="btn btn-primary w-25" id="resigterBtn"
                style="display: none;">Register</button>
            <!-- <button type="button" class="btn btn-soft-success">Cancel</button> -->
        </div>
    </div>
</div>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
</div>




<div class="modal fade" id="getDetailsPan" tabindex="-1" aria-labelledby="exampleModalXlLabel" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title h4" id="exampleModalXlLabel" style="color: red">PAN Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="htmlpandetails"></div>
            </div>
        </div>
    </div>
</div>


@endsection
@push('script')
<script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
<script type="text/javascript">
    // email verification


    $(".btn-email").click(function(e) {
        e.preventDefault();
        var user_email = $('#email_id1').val();

        if (IsEmail(user_email) == false) {
            $(".overlay").hide();
            Swal.fire({
                text: "Invalid email",
                icon: 'error',
                confirmButtonText: 'OK'
            });
            return false;
        }
        if (user_email != "") {
            $(".overlay").show();
            $.ajax({
                type: 'POST',
                url: "{{ route('superadmin.usermanagement.email_mobile_OTP') }}",
                data: {
                    'user_email': user_email
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                beforeSend: function() {
                    $(".overlay").css({
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        position: 'fixed',
                        top: 0,
                        left: 0,
                        right: 0,
                        bottom: 0,
                        backgroundColor: 'rgba(0, 0, 0, 0.5)',
                        zIndex: 1000
                    }).html(`
                            <div style="text-align: center;">
                                <div class="spinner-border" role="status" style="width: 3rem; height: 3rem;">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                                <div style="color: white; margin-top: 10px;">Please wait...</div>
                            </div>
                        `);
                },
                success: function(resp) {
                    if (resp == 1) {
                        Swal.fire({
                            text: "Please verify the OTP sent to your Email ID",
                            icon: 'success',
                            confirmButtonText: 'OK'
                        }).then((result) => {
                            $('.otp-email').show(500);
                            $('#email_id1').val(user_email).prop('readonly', true);
                            $('.btn-email').hide(500);
                            $('.btn-mailsend').show(100);
                        });
                    } else {
                        Swal.fire({
                            title: "Error",
                            text: resp.message,
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    }
                    $(".overlay").hide();
                },
                error: function(xhr) {
                    // Handle error response
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        Swal.fire({
                            title: "Error",
                            text: xhr.responseJSON.message,
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    } else {
                        Swal.fire({
                            title: "Error",
                            text: "An unexpected error occurred.",
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    }
                    $(".overlay").hide();
                }
            });
        } else {
            Swal.fire("", "Please enter Email ID", "error");
        }
    });


    function IsEmail(email) {
        var regex =
            /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if (!regex.test(email)) {
            return false;
        } else {
            return true;
        }
    }



    $(".verifiEmail_otp").click(function(e) {
        e.preventDefault();
        var email_otp = $('#email_otp1').val();
        $(".overlay").show();
        if (email_otp != "") {

            $.ajax({
                type: 'POST',
                url: "{{ route('superadmin.usermanagement.email_mobile_OTP_check') }}",
                data: {
                    'email_otp': email_otp
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                beforeSend: function() {
                    $(".overlay").css({
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        position: 'fixed',
                        top: 0,
                        left: 0,
                        right: 0,
                        bottom: 0,
                        backgroundColor: 'rgba(0, 0, 0, 0.5)',
                        zIndex: 1000
                    }).html(` <div style="text-align: center;"> <div class="spinner-border" role="status" style="width: 3rem; height: 3rem;"> <span class="visually-hidden">Loading...</span> </div> <div style="color: white; margin-top: 10px;">Please wait...</div> </div> `);
                },
                success: function(html) {
                    if (html == 0) {
                        Swal.fire("", "Please enter Valid OTP", "error");
                    } else {
                        $('#email_otp').prop('readonly', true);
                        $('.otp-email1').hide(500);
                        $('.btn-email').hide(500);
                        $('.btn-verify').show(500);
                        $('.visitorCat').hide(500);
                        $('.visitorCat1').hide(500);
                        $('.user_detail_page').show(500);
                        $('#email_id').prop('readonly', true);
                        $('.btn-mailsend').hide();
                        $('.login-pass').hide();
                    }
                    $(".overlay").hide();
                },
                error: function(html) {
                    $(".overlay").hide();

                }
            });
        } else {
            Swal.fire("", "Please enter OTP", "error");
        }
    });

    $(".resendEmail_otp").click(function(e) {
        e.preventDefault();
        var user_email = $('#email_id1').val();

        $.ajax({
            type: 'POST',
            url: "{{ route('superadmin.usermanagement.email_mobile_OTP') }}",
            data: {
                'user_email': user_email
            },
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            beforeSend: function() {
                $(".overlay").css({
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    position: 'fixed',
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    backgroundColor: 'rgba(0, 0, 0, 0.5)',
                    zIndex: 1000
                }).html(` <div style="text-align: center;"> <div class="spinner-border" role="status" style="width: 3rem; height: 3rem;"> <span class="visually-hidden">Loading...</span> </div> <div style="color: white; margin-top: 10px;">Please wait...</div> </div> `);
            },
            success: function(html) {
                Swal.fire("", "Re OTP Send!!", "success");
            }
        });
    });

    // end-----





    $("#commonform1").validate({
        rules: {
            // user_password: {
            // 	required: true,
            // 	minlength: 8,
            // 	maxlength: 10,
            // } ,
            mobile: {
                required: true,
            }
        },
        messages: {
            // user_password: {
            // 	required:"This field is required and should be 8 digits, contains upper,lowerCase,and a special Character"
            // },
            mobile: {
                required: "This field is required",
            }
        }

    });

    function CheckPassword(inputtxt) {
        if (inputtxt.value.length > 0) {
            var decimal = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
            if (inputtxt.value.match(decimal)) {
                return true;
            } else {
                Swal.fire('',
                    'Password should be 8 digits,contains upperCase letter,lowerCase letter,and a special Character',
                    'warning');
                $("#user_password").val('');
                return false;
            }
        }
    }

    function phonenumber(inputtxt) {
        var phoneno = /^\d{10}$/;
        if (inputtxt.value.match(phoneno)) {
            return true;
        } else {
            Swal.fire('', 'Please enter a valid mobile number.', 'warning');
            $("#mobile").val('');
            return false;
        }
    }



    $(document).on('change', '.fssai_license_number', function() {

        var th = $(this);
        var license_number = this.value;

        $.ajax({
            type: 'POST',
            url: "{{ route('superadmin.trader.getFSSAIDetails') }}",
            data: {
                'license_number': license_number
            },
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(response) {
                if (response)
                    var res = JSON.parse(response);
                //console.log(res.premiseAddress);
                if (res.expiryDate !== undefined) {
                    var dateAr = res.expiryDate.split('-');
                    var newDate = dateAr[2] + '-' + dateAr[1] + '-' + dateAr[0].slice(-2);
                    $(th).parent().parent().parent().find('input[name="license_validity[]"]').val(
                        newDate);
                    $(th).parent().parent().parent().find('textarea[name="address[]"]').val(res
                        .premiseAddress);
                    $(th).parent().parent().parent().find('input[name="fssai_license_record[]"]')
                        .val(response);

                    //$('#license_validity').val(newDate);
                    //$('#address').val(res.premiseAddress);
                    $(".fssi_success").removeClass("d-none");
                } else {
                    $(".fssi_success").addClass("d-none");
                    Swal.fire(
                        'Warning!',
                        'Invalid FSSAI License Number .',
                        'warning'
                    );
                }

                // if()
                //Swal.fire("", "Re OTP Send!!", "success");
            }
        });

    });

    function viewLicense(id) {
        //alert(id);
        $("#myModal").modal('show');

    }
</script>
@php
$salt = rand('1000', '9999');
session(['salt' => $salt]);
@endphp
<script type="text/javascript" src="{{ asset('public/backend/js/sha.js') }}"></script>
<script>
    // $(document).on('submit','#commonform1',function(){
    //     var salt = '{{ $salt }}';
    //     var secret = $('#password').val();
    //     var shaObj = new jsSHA("SHA-256", "TEXT");
    //     shaObj.update(secret);
    //     var hashPass = shaObj.getHash("HEX");
    //     $('#password').val(hashPass);
    //     var secretcurrent = $('#confirm_password').val();
    //     var shaObjcurrent = new jsSHA("SHA-256", "TEXT");
    //     shaObjcurrent.update(secretcurrent);
    //     var hashPasscurrent = shaObjcurrent.getHash("HEX");
    //     $('#confirm_password').val(hashPasscurrent);
    // });


    $('#document_type').change(function() {
        if ($('#document_type').val() != '') {

            if ($('#document_type').val() == 'PAN') {
                $('[name=user_name]').addClass('pan');
            } else {
                $('[name=user_name]').removeClass('pan');
            }
            $('.legal_doc_div').show();
            $('[name=user_name]').attr('required', 'required');

        } else {
            $('.legal_doc_div').hide();
            $('[name=user_name]').removeAttr('required');
        }
    });
    // $(document).on('change', '.pan', function() {

    //     var inputvalues = $(this).val();
    //     var regex = /[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
    //     if (!regex.test(inputvalues)) {
    //         console.log(inputvalues);
    //         $(".pan").val("");
    //         alert("invalid PAN no");
    //         return regex.test(inputvalues);
    //     }
    // });

    $(document).on('change', '.pan', function() {

        var inputvalues = $(this).val();
        var regex = /[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
        if (!regex.test(inputvalues)) {
            console.log(inputvalues);
            $(".pan").val("");
            // Replace standard alert with SweetAlert
            Swal.fire({
                icon: 'error',
                title: 'Invalid PAN Number',
                text: 'Please enter a valid PAN Number',
            });

            return regex.test(inputvalues);
        }
    });

    // Pin Code validation
    $("#operator_pan").keyup(function() {
        $(this).val($(this).val().toUpperCase());
    });
    $(document).on('change', '#pin_code', function() {
        var pinCode = $(this).val();
        var pinRegex = /^[0-9]{6}$/;
        if (!pinRegex.test(pinCode)) {
            console.log(pinCode);
            $("#pin_code").val("");

            Swal.fire({
                icon: 'error',
                title: 'Invalid Pin Code',
                text: 'Please enter a valid 6-digit Pin Code',
            });

            return pinRegex.test(pinCode);
        }
    });

    // Email validation
    $(document).on('change', '#email_id1', function() {
        var email = $(this).val();
        var emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/; // Basic email validation regex
        if (!emailRegex.test(email)) {
            console.log(email);
            $("#email_id1").val("");

            // SweetAlert for invalid email
            Swal.fire({
                icon: 'error',
                title: 'Invalid Email Address',
                text: 'Please enter a valid email address',
            });

            return emailRegex.test(email);
        }
    });

    //Declaration validation
    $(document).on('change', '#declaration_consent', function() {
        if ($(this).is(':checked')) {
            $('#resigterBtn').show();
        } else {
            $('#resigterBtn').hide();
        }
    });
</script>

<script>
    function sendOtp() {
        var mobile = document.getElementById('mobile_number').value;
        var getOtpButton = document.getElementById('getOtpBtn');
        var resendOtpButton = document.getElementById('resendOtpBtn');
        var otpSection = document.getElementById('otp_section');
        var loader = document.getElementById('loader'); // Assume there's a loader with this ID

        if (mobile.length === 10) {
            // Show loader and hide Get OTP button
            loader.style.display = 'inline-block'; // Show the loader
            getOtpButton.style.display = 'none'; // Hide Get OTP button

            fetch('{{ route('superadmin.sendOtp') }}', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '{{ csrf_token() }}'
                        },
                        body: JSON.stringify({
                            mobile_number: mobile
                        })
                    })
                .then(response => response.json())
                .then(data => {
                    // Hide loader once we get the response
                    loader.style.display = 'none';

                    if (data.status === 'success') {
                        Swal.fire({
                            icon: 'success',
                            title: 'Valid Mobile Number',
                            text: 'OTP sent successfully!',
                        });

                        // Show OTP input section and Resend OTP button, hide Get OTP button
                        otpSection.style.display = 'block';
                        resendOtpButton.style.display = 'inline-block';
                        getOtpButton.style.display = 'none'; // Keep the Get OTP button hidden
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Failed to send OTP',
                            text: 'Please try again.',
                        });

                        // Show Get OTP button again if failed
                        getOtpButton.style.display = 'inline-block';
                    }
                })
                .catch(error => {
                    console.error('Error:', error);

                    // Hide loader and show Get OTP button again in case of error
                    loader.style.display = 'none';
                    getOtpButton.style.display = 'inline-block';

                    Swal.fire({
                        icon: 'error',
                        title: 'An error occurred',
                        text: 'Please try again.',
                    });
                });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Invalid Mobile Number',
                text: 'Please Enter a Valid 10-digit Mobile Number.',
            });
        }
    }

    function verifyOtp() {
        var mobile = document.getElementById('mobile_number').value;
        var otp = document.getElementById('otp_input').value; // Updated to use the correct OTP input field
        if (otp.length === 4) {
            fetch('{{ route('superadmin.verifyOtp') }}', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '{{ csrf_token() }}'
                        },
                        body: JSON.stringify({
                            mobile_number: mobile,
                            otp: otp
                        })
                    })
                .then(response => {
                    const contentType = response.headers.get("content-type");
                    if (contentType && contentType.includes("application/json")) {
                        return response.json();
                    } else {
                        throw new Error('Received non-JSON response');
                    }
                })
                .then(data => {
                    if (data.status === 'success') {
                        Swal.fire({
                            icon: 'success',
                            title: 'OTP Verified',
                            text: 'Your OTP has been verified successfully!',
                        });

                        // Hide Get OTP button and Resend OTP button, show Verified button
                        document.getElementById('mobile_number').readOnly = true;
                        document.getElementById('getOtpBtn').style.display = 'none';
                        document.getElementById('resendOtpBtn').style.display = 'none'; // Hide Resend OTP button
                        document.getElementById('verifiedBtn').style.display =
                            'inline-block'; // Show Verified button

                        // Hide the OTP input section after successful verification
                        document.getElementById('otp_section').style.display = 'none';
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Invalid OTP',
                            text: 'The OTP you entered is incorrect. Please try again.',
                        });
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    Swal.fire({
                        icon: 'error',
                        title: 'An error occurred',
                        text: 'Unable to verify the OTP. Please try again.',
                    });
                });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Invalid OTP',
                text: 'Please enter a valid 4-digit OTP.',
            });
        }
    }

    function toggleLicenseInputs() {
        const processorType = document.getElementById('processor_type').value;
        const fssaiSection = document.getElementById('fssai_section');
        const ayushSection = document.getElementById('ayush_section');

        if (processorType === 'fssai') {
            fssaiSection.classList.remove('d-none');
            ayushSection.classList.add('d-none');
        } else if (processorType === 'ayush') {
            ayushSection.classList.remove('d-none');
            fssaiSection.classList.add('d-none');
        } else {
            fssaiSection.classList.add('d-none');
            ayushSection.classList.add('d-none');
        }
    }

    document.getElementById('commonform1').addEventListener('submit', function(event) {
        var aadhar_number = $('#contact_person_aadhar_number').val();

        if (aadhar_number == null || aadhar_number.trim() === '') {
            event.preventDefault();
            $('#contact_person_aadhar_number').val('');
            Swal.fire({
                title: "Error",
                text: "Aadhar Number is required.",
                icon: "warning",
                confirmButtonText: "OK"
            });
        } else if (!/^\d{12}$/.test(aadhar_number)) {
            event.preventDefault();
            $('#contact_person_aadhar_number').val('');
            Swal.fire({
                title: "Invalid Aadhaar Number",
                text: "Please enter a valid Aadhar Number (12 digits only).",
                icon: "error",
                confirmButtonText: "OK"
            });
        } else {
            // Encode Aadhaar and allow submission
            // var encoded_aadhar = encodeURIComponent(window.btoa(aadhar_number));
            // $('#contact_person_aadhar_number').val(encoded_aadhar);
        }
    });


    function getDetailsPan(Pan_id) {
            var role_id = $('#role_id').val();
            var user_name = $('#operator_pan').val();
            $.ajax({
                url: "{{route('validation-pan-number')}}",
                type: 'GET',
                contentType: 'application/json',
                dataType: 'json',
                data: {
                    role_id: role_id,
                    user_name: user_name
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(resp) {
                   
                    Swal.fire({
                        title: resp.message,
                        // html: validationErrors.join('<br>'),
                        icon: 'warning',
                        confirmButtonText: 'OK'
                    });
                }
            });
        $.ajax({
            type: 'POST',
            url: "{{ route('superadmin.GetPanDetail') }}",
            data: {
                'PanID': Pan_id
            },
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            beforeSend: function() {
                $(".overlay").css({
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    position: 'fixed',
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    backgroundColor: 'rgba(0, 0, 0, 0.5)',
                    zIndex: 1000
                }).html(`
                        <div style="text-align: center;">
                            <div class="spinner-border" role="status" style="width: 3rem; height: 3rem;">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                            <div style="color: white; margin-top: 10px;">Please wait...</div>
                        </div>
                    `);
            },
            success: function(resp) {
                if (resp.status == true) {
                    $('#htmlpandetails').html(resp.html);
                    $('#getDetailsPan').modal('show');
                }
                $(".overlay").hide();
            },
            error: function(xhr) {
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    Swal.fire({
                        title: "Error",
                        text: xhr.responseJSON.message,
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                } else {
                    Swal.fire({
                        title: "Error",
                        text: "An unexpected error occurred.",
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                }
                $(".overlay").hide();
            }
        });
    // },
                
    //         });
    }
</script>
<script>
    $(document).ready(function() {
        // $('#panVerificationForm').on('click', function (event) {
        //     event.preventDefault();
        //     const doctype = $('#entity_firm').find('option:selected').data('doctype');
        //     //console.log(doctype);
        //     if (doctype === 'Y') {
        //         $('#name, #dob_doi_date, #father_name, #operator_pan').removeClass('is-invalid is-valid');
        //     }else{
        //         $('#name, #dob_doi_date, #operator_pan').removeClass('is-invalid is-valid');
        //     }

        //     $('#panName_response, #panDob_response, #panNumber_response').html('');
        //     $('#panNumberResponse, #panNameResponse, #panDobResponse').val('');

        //     // Form input values
        //     const name = $('#name').val();
        //     const dob = $('#dob_doi_date').val();
        //     const pan = $('#operator_pan').val();
        //     const type = $('#detailType').val();
        //     const userId = $('#user_id').val();
        //     const registraionId = $('#role_id').val();
        //     const registrationForm = $('#registration_form').val();
        //     const fatherName = $('#father_name').val();
        //     // Validate inputs
        //     let validationErrors = [];
        //     if (!name || !/^[a-zA-Z\s]+$/.test(name)) {
        //         validationErrors.push("Name is required and should only contain alphabetic characters.");
        //         $('#name').addClass('is-invalid');
        //     }

        //     if (!dob || new Date(dob) > new Date()) {
        //         validationErrors.push("Date of Birth is required and must be a past date.");
        //         $('#dob_doi_date').addClass('is-invalid');
        //     }

        //     if (doctype === 'Y') {
        //         if (!fatherName || !/^[a-zA-Z\s]+$/.test(fatherName)) {
        //             validationErrors.push("Father Name is required and should only contain alphabetic characters.");
        //             $('#father_name').addClass('is-invalid');
        //         }
        //     }

        //     const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
        //     if (!pan || !panRegex.test(pan)) {
        //         validationErrors.push("PAN Number is required and must be in the format (AAAAA1234A).");
        //         $('#operator_pan').addClass('is-invalid');
        //     }

        //     if (validationErrors.length > 0) {
        //         Swal.fire({
        //             title: "Validation Error",
        //             html: validationErrors.join('<br>'),
        //             icon: 'warning',
        //             confirmButtonText: 'OK'
        //         });
        //         return;
        //     }

        //     // Prepare form data
        //     const formData = {
        //         pan: pan,
        //         name: name,
        //         dob: dob,
        //         type: type,
        //         user: userId,
        //         registraionId: registraionId,
        //         registrationForm: registrationForm,
        //         fatherName:fatherName
        //     };

        //     const encryptedData = btoa(JSON.stringify(formData));

        //     // AJAX request
        //     $.ajax({
        //         url: '/api/validate-pan-v1',
        //         type: 'POST',
        //         contentType: 'application/json',
        //         dataType: 'json',
        //         data: JSON.stringify({ data: encryptedData }),
        //         headers: {
        //             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        //         },
        //         beforeSend: function () {
        //             $(".overlay").css({
        //                 display: 'flex',
        //                 justifyContent: 'center',
        //                 alignItems: 'center',
        //                 position: 'fixed',
        //                 top: 0,
        //                 left: 0,
        //                 right: 0,
        //                 bottom: 0,
        //                 backgroundColor: 'rgba(0, 0, 0, 0.5)',
        //                 zIndex: 1000
        //             }).html(`
        //                 <div style="text-align: center;">
        //                     <div class="spinner-border" role="status" style="width: 3rem; height: 3rem;">
        //                         <span class="visually-hidden">Loading...</span>
        //                     </div>
        //                     <div style="color: white; margin-top: 10px;">Please wait...</div>
        //                 </div>
        //             `);
        //         },
        //         // success: function (response) {
        //         //     $(".overlay").hide();

        //         //     const data = JSON.parse(atob(response.data));
        //         //     console.log(data);
        //         //     $('#panNumberResponse').val(data.outputData.pan_status);
        //         //     $('#panNameResponse').val(data.outputData.name);
        //         //     $('#panDobResponse').val(data.outputData.dob);
        //         //     const panStatusClass = data.outputData.pan_status === 'E' ? 'text-success' : 'text-danger';
        //         //     const nameStatusClass = data.outputData.name === 'Y' ? 'text-success' : 'text-danger';
        //         //     const dobStatusClass = data.outputData.dob === 'Y' ? 'text-success' : 'text-danger';

        //         //     const detailsHtml = `
        //         //         <ul class="text-start">
        //         //             <li><strong>Name Message:</strong> <span class="${nameStatusClass}">${data.outputData.name_message}</span></li>
        //         //             <li><strong>PAN Status Message:</strong> 
        //         //                 <span class="${panStatusClass}">${data.outputData.pan_status_message}</span>
        //         //             </li>
        //         //             <li><strong>Date of Birth Match:</strong>
        //         //                 <span class="${dobStatusClass}">${data.outputData.dob_message || 'N/A'}</span>
        //         //             </li>

        //         //         </ul>
        //         //     `;
        //         //     // Handle PAN status conditions
        //         //     if (data.outputData.pan_status === 'E') {
        //         //         Swal.fire({
        //         //             title: "Success",
        //         //             text: data.message,
        //         //             html: detailsHtml,
        //         //             icon: 'success',
        //         //             confirmButtonText: 'OK'
        //         //         });
        //         //         $('#operator_pan').addClass('is-valid');
        //         //     } else if (data.outputData.pan_status === 'F' || data.outputData.pan_status === 'X') {
        //         //         Swal.fire({
        //         //             title: "Error",
        //         //             text: data.outputData.pan_status_message,
        //         //             icon: 'error',
        //         //             confirmButtonText: 'OK'
        //         //         });
        //         //         $('#operator_pan').addClass('is-invalid');
        //         //     } else {
        //         //         Swal.fire({
        //         //             title: "Warning",
        //         //             text: "Unexpected response.",
        //         //             html: detailsHtml,
        //         //             icon: 'warning',
        //         //             confirmButtonText: 'OK'
        //         //         });
        //         //     }

        //         //     // Update name validation response
        //         //     if (data.outputData.name === 'Y') {
        //         //         $('#panName_response').html(data.outputData.name_message)
        //         //             .removeClass('text-danger text-warning').addClass('text-success');
        //         //         $('#name').addClass('is-valid');
        //         //     } else if (data.outputData.name === 'N') {
        //         //         $('#panName_response').html(data.outputData.name_message)
        //         //             .addClass('text-danger').removeClass('text-success');
        //         //         $('#name').addClass('is-invalid');
        //         //     }

        //         //     // Update DOB validation response
        //         //     if (data.outputData.dob === 'Y') {
        //         //         $('#panDob_response').html(data.outputData.dob_message)
        //         //             .removeClass('text-danger text-warning').addClass('text-success');
        //         //         $('#dob_doi_date').addClass('is-valid');
        //         //     } else if (data.outputData.dob === 'N') {
        //         //         $('#panDob_response').html(data.outputData.dob_message)
        //         //             .addClass('text-danger').removeClass('text-success');
        //         //         $('#dob_doi_date').addClass('is-invalid');
        //         //     }

        //         //     // Update PAN Number validation response
        //         //     if (data.outputData.pan_status === 'E') {
        //         //         $('#panNumber_response').html(data.outputData.pan_status_message)
        //         //             .removeClass('text-danger text-warning').addClass('text-success');
        //         //         $('#operator_pan').addClass('is-valid');
        //         //     } else{
        //         //         $('#panNumber_response').html(data.outputData.pan_status_message)
        //         //             .addClass('text-danger').removeClass('text-success');
        //         //         $('#operator_pan').addClass('is-invalid');
        //         //     }

        //         // },
        //         success: function (response) {
        //             $(".overlay").hide();

        //             const data = JSON.parse(atob(response.data));
        //             console.log(data);

        //             $('#panNumberResponse').val(data.outputData.pan_status);
        //             $('#panNameResponse').val(data.outputData.name);
        //             $('#panDobResponse').val(data.outputData.dob);

        //             const panStatusClass = data.outputData.pan_status === 'E' ? 'text-success' : 'text-danger';
        //             const nameStatusClass = data.outputData.name === 'Y' ? 'text-success' : 'text-danger';
        //             const dobStatusClass = data.outputData.dob === 'Y' ? 'text-success' : 'text-danger';

        //             const detailsHtml = `
        //                 <ul class="text-start">
        //                     <li><strong>Name Message:</strong> <span class="${nameStatusClass}">${data.outputData.name_message}</span></li>
        //                     <li><strong>PAN Status Message:</strong> 
        //                         <span class="${panStatusClass}">${data.outputData.pan_status_message}</span>
        //                     </li>
        //                     <li><strong>Date of Birth Match:</strong>
        //                         <span class="${dobStatusClass}">${data.outputData.dob_message || 'N/A'}</span>
        //                     </li>
        //                 </ul>
        //             `;

        //             console.log(doctype);
        //             // Logic for individual PAN validation
        //             if (doctype === 'Y' || doctype === 'NA') {
        //                if (data.outputData.seeding_status === 'Y' && doctype === 'Y') {
        //                     Swal.fire({
        //                         title: "Success",
        //                         text: data.message,
        //                         html: detailsHtml,
        //                         icon: 'success',
        //                         confirmButtonText: 'OK'
        //                     });
        //                     $('#panVerifyResponse').val('1');
        //                 } else if (doctype === 'NA' || data.outputData.seeding_status !== 'Y') {
        //                     $('#name, #dob_doi_date, #operator_pan').removeClass('is-invalid is-valid');
        //                     Swal.fire({
        //                         title: "Warning",
        //                         text: "This PAN card belongs to an individual user and cannot be used for registration.",
        //                         icon: 'warning',
        //                         confirmButtonText: 'OK'
        //                     });

        //                     // Add invalid classes
        //                     $('#panVerifyResponse').val('0');
        //                     $('#name').addClass('is-invalid');
        //                     $('#dob_doi_date').addClass('is-invalid');
        //                     $('#operator_pan').addClass('is-invalid');
        //                     $('#panNumber_response').html('Invalid PAN for this account type.')
        //                         .addClass('text-danger').removeClass('text-success');
        //                 }
        //             } else if (data.outputData.pan_status === 'E') {
        //                 Swal.fire({
        //                     title: "Success",
        //                     text: data.message,
        //                     html: detailsHtml,
        //                     icon: 'success',
        //                     confirmButtonText: 'OK'
        //                 });
        //             } else if (data.outputData.pan_status === 'F' || data.outputData.pan_status === 'X') {
        //                 Swal.fire({
        //                     title: "Error",
        //                     text: data.outputData.pan_status_message,
        //                     icon: 'error',
        //                     confirmButtonText: 'OK'
        //                 });
        //                 $('#operator_pan').addClass('is-invalid');
        //             } else {
        //                 Swal.fire({
        //                     title: "Warning",
        //                     text: "Unexpected response.",
        //                     html: detailsHtml,
        //                     icon: 'warning',
        //                     confirmButtonText: 'OK'
        //                 });
        //             }

        //             // Update name validation response
        //             if (data.outputData.name === 'Y') {
        //                 $('#panName_response').html(data.outputData.name_message)
        //                     .removeClass('text-danger text-warning').addClass('text-success');
        //                 $('#name').addClass('is-valid');
        //             } else if (data.outputData.name === 'N') {
        //                 $('#panName_response').html(data.outputData.name_message)
        //                     .addClass('text-danger').removeClass('text-success');
        //                 $('#name').addClass('is-invalid');
        //             }

        //             // Update DOB validation response
        //             if (data.outputData.dob === 'Y') {
        //                 $('#panDob_response').html(data.outputData.dob_message)
        //                     .removeClass('text-danger text-warning').addClass('text-success');
        //                 $('#dob_doi_date').addClass('is-valid');
        //             } else if (data.outputData.dob === 'N') {
        //                 $('#panDob_response').html(data.outputData.dob_message)
        //                     .addClass('text-danger').removeClass('text-success');
        //                 $('#dob_doi_date').addClass('is-invalid');
        //             }

        //             // Update PAN Number validation response
        //             if (data.outputData.pan_status === 'E') {
        //                 $('#panNumber_response').html(data.outputData.pan_status_message)
        //                     .removeClass('text-danger text-warning').addClass('text-success');
        //                 $('#operator_pan').addClass('is-valid');
        //             } else {
        //                 $('#panNumber_response').html(data.outputData.pan_status_message)
        //                     .addClass('text-danger').removeClass('text-success');
        //                 $('#operator_pan').addClass('is-invalid');
        //             }
        //         },

        //         error: function (xhr) {
        //             $(".overlay").hide();
        //             let errorMessage = "An unexpected error occurred.";
        //             if (xhr.responseJSON && xhr.responseJSON.message) {
        //                 errorMessage = xhr.responseJSON.message;
        //             }

        //             Swal.fire({
        //                 title: 'A service error occurred during PAN validation.',
        //                 text: 'Please reload your browser or revalidate the PAN',
        //                 icon: 'error',
        //                 confirmButtonText: 'OK'
        //             });
        //         }
        //     });
        // });
        $('#panVerificationForm').on('click', function(event) {
            event.preventDefault();
            const documentVType = $('#document_type').find('option:selected').val();
            const doctype = $('#entity_firm').find('option:selected').data('doctype');
            const legalEntityType = $('#entity_firm').find('option:selected').val();

            // Reset validation classes
            if (documentVType === 'PAN') {
                if (doctype === 'Y') {
                    $('#detailType').val('IN');
                    $('#name, #dob_doi_date, #father_name, #operator_pan, #entity_firm, #document_type').removeClass('is-invalid is-valid');
                } else {
                    $('#detailType').val('OG');
                    $('#name, #dob_doi_date, #operator_pan, #entity_firm, #document_type').removeClass('is-invalid is-valid');
                }
            }

            // Clear responses
            $('#panName_response, #panDob_response, #panNumber_response').html('');
            $('#panNumberResponse, #panNameResponse, #panDobResponse').val('');

            // Form input values
            const name = $('#name').val();
            const dob = $('#dob_doi_date').val();
            const pan = $('#operator_pan').val();
            const type = $('#detailType').val();
            const userId = $('#user_id').val();
            const registrationId = $('#role_id').val();

            const registrationForm = $('#registration_form').val();
            const fatherName = $('#father_name').val();
            const panVerifyResponse = $('#panVerifyResponse').val();

            // Input validation
            let validationErrors = [];
            if (!documentVType) {
                validationErrors.push("Please Select Legal Document Type");
                $('#document_type').addClass('is-invalid');
            }
            if (!doctype) {
                validationErrors.push("Please Select Legal Entity Type");
                $('#entity_firm').addClass('is-invalid');
            }

            // if (!name || !/^[a-zA-Z\s]+$/.test(name)) {
            //     validationErrors.push("Name is required and should only contain alphabetic characters.");
            //     $('#name').addClass('is-invalid');
            // }

            if (!name || !/^[a-zA-Z\s\-\.\/\\\{\}\[\]\(\)\*\#\$\&]+$/.test(name)) {
                validationErrors.push("Name is required and should only contain alphabetic characters and specific special characters.");
                $('#name').addClass('is-invalid');
            }


            if (!dob || new Date(dob) > new Date()) {
                if (doctype == 'NA') {
                    validationErrors.push("Date of incorporation is required and must be a past date.");
                } else {
                    validationErrors.push("Date of Birth is required and must be a past date.");
                }

                $('#dob_doi_date').addClass('is-invalid');
            }

            if (doctype === 'Y' && (!fatherName || !/^[a-zA-Z\s]+$/.test(fatherName))) {
                validationErrors.push("Father Name is required and should only contain alphabetic characters.");
                $('#father_name').addClass('is-invalid');
            }

            const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
            if (!pan || !panRegex.test(pan)) {
                validationErrors.push("PAN Number is required and must be in the format (AAAAA1234A).");
                $('#operator_pan').addClass('is-invalid');
            }

            if (validationErrors.length > 0) {
                Swal.fire({
                    title: "Validation Error",
                    html: validationErrors.join('<br>'),
                    icon: 'warning',
                    confirmButtonText: 'OK'
                });
                return;
            }

            // Prepare form data
            const formData = {
                pan: pan,
                name: name,
                dob: dob,
                type: type,
                user: userId,
                registrationId: registrationId,
                registrationForm: registrationForm,
                fatherName: fatherName,
                legalEntityType: legalEntityType,
                doctype: doctype,
            };

            const encryptedData = btoa(JSON.stringify(formData));

            // AJAX request
            $.ajax({
                url: '/api/validate-pan-v1',
                type: 'POST',
                contentType: 'application/json',
                dataType: 'json',
                data: JSON.stringify({
                    data: encryptedData
                }),
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                beforeSend: function() {
                    $(".overlay").css({
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        position: 'fixed',
                        top: 0,
                        left: 0,
                        right: 0,
                        bottom: 0,
                        backgroundColor: 'rgba(0, 0, 0, 0.5)',
                        zIndex: 1000
                    }).html(`
                            <div style="text-align: center;">
                                <div class="spinner-border" role="status" style="width: 3rem; height: 3rem;">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                                <div style="color: white; margin-top: 10px;">Please wait...</div>
                            </div>
                        `);
                },
                success: function(response) {
                    $(".overlay").hide();

                    const data = JSON.parse(atob(response.data));
                    //console.log(data);

                    $('#panNumberResponse').val(data.outputData.pan_status);
                    $('#panNameResponse').val(data.outputData.name);
                    $('#panDobResponse').val(data.outputData.dob);

                    const panStatusClass = data.outputData.pan_status === 'E' ? 'text-success' : 'text-danger';
                    const nameStatusClass = data.outputData.name === 'Y' ? 'text-success' : 'text-danger';
                    const dobStatusClass = data.outputData.dob === 'Y' ? 'text-success' : 'text-danger';
                    const swalTitleClass = data.outputData.name === 'Y' && data.outputData.dob === 'Y' && data.outputData.pan_status === 'E' ? 'text-success' : 'text-warning';

                    const detailsHtml = `
                            <ul class="text-start">
                                <li><strong>Name Message:</strong> <span class="${nameStatusClass}">${data.outputData.name_message}</span></li>
                                <li><strong>PAN Status Message:</strong> 
                                    <span class="${panStatusClass}">${data.outputData.pan_status_message}</span>
                                </li>
                                <li><strong>${data.outputData.seeding_status === 'NA' ? 'Date of Incorporation' : 'Date of Birth'}:</strong>
                                    <span class="${dobStatusClass}">${data.outputData.dob_message || 'N/A'}</span>
                                </li>
                            </ul>
                        `;

                    if (data.outputData.seeding_status === 'Y' && doctype === 'Y') {
                        if (data.outputData.name === 'Y' && data.outputData.dob === 'Y' && data.outputData.pan_status === 'E') {
                            Swal.fire({
                                title: `<span class="${swalTitleClass}">This PAN card belongs to an individual user account and has been successfully verified.</span>`,
                                text: data.message,
                                html: detailsHtml,
                                icon: 'success',
                                confirmButtonText: 'OK'
                            });
                        } else {

                            Swal.fire({
                                title: `<span class="text-danger">Verification Failed</span>`,
                                text: "Name and Date of Birth do not match the records. Please check the details and try again.",
                                html: detailsHtml,
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        }
                        $('#panVerifyResponse').val(data.outputData.name === 'Y' && data.outputData.dob === 'Y' ? 'S' : 'F');
                    } else if (data.outputData.seeding_status === 'NA' && doctype === 'NA') {
                        if (data.outputData.name === 'N' || data.outputData.dob === 'N') {
                            Swal.fire({
                                title: `<span class="text-danger">Verification Failed</span>`,
                                text: "Name and Date of Incorporation do not match the records. Please verify the details.",
                                html: detailsHtml,
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        } else {
                            Swal.fire({
                                title: `<span class="${swalTitleClass}">This PAN card belongs to a company or organization account and has been successfully verified.</span>`,
                                text: data.message,
                                html: detailsHtml,
                                icon: 'success',
                                confirmButtonText: 'OK'
                            });
                        }
                        $('#panVerifyResponse').val(data.outputData.name === 'Y' && data.outputData.dob === 'Y' ? 'S' : 'F');
                    } else if (doctype === 'NA' || data.outputData.seeding_status !== 'Y') {
                        Swal.fire({
                            title: "Warning",
                            text: "This PAN card belongs to an individual user and cannot be used for registration.",
                            icon: 'warning',
                            confirmButtonText: 'OK'
                        });
                        $('#panVerifyResponse').val('F');
                    } else {
                        Swal.fire({
                            title: "Unexpected Response",
                            text: "Unexpected response received from the server.",
                            icon: 'warning',
                            confirmButtonText: 'OK'
                        });
                    }
                    // Update field validations
                    if (data.outputData.seeding_status === doctype) {
                        if (data.outputData.name === 'Y') {
                            $('#panName_response').html(data.outputData.name_message)
                                .removeClass('text-danger text-warning').addClass('text-success');
                            $('#name').addClass('is-valid');
                        } else if (data.outputData.name === 'N') {
                            $('#panName_response').html(data.outputData.name_message)
                                .addClass('text-danger').removeClass('text-success');
                            $('#name').addClass('is-invalid');
                        }
                        if (data.outputData.dob === 'Y') {
                            $('#panDob_response').html(data.outputData.dob_message)
                                .removeClass('text-danger text-warning').addClass('text-success');
                            $('#dob_doi_date').addClass('is-valid');
                        } else if (data.outputData.dob === 'N') {
                            $('#panDob_response').html(data.outputData.dob_message)
                                .addClass('text-danger').removeClass('text-success');
                            $('#dob_doi_date').addClass('is-invalid');
                        }
                        if (data.outputData.pan_status === 'E') {
                            $('#panNumber_response').html(data.outputData.pan_status_message)
                                .removeClass('text-danger text-warning').addClass('text-success');
                            $('#operator_pan').addClass('is-valid');
                        } else {
                            $('#panNumber_response').html(data.outputData.pan_status_message)
                                .addClass('text-danger').removeClass('text-success');
                            $('#operator_pan').addClass('is-invalid');
                        }
                    } else {
                        $('#name, #dob_doi_date, #operator_pan').addClass('is-invalid');
                        $('#panNumber_response').html('Invalid PAN for this account type.')
                            .addClass('text-danger').removeClass('text-success');
                        $('#panName_response').html('Invalid Name for this account type.')
                            .addClass('text-danger').removeClass('text-success');
                        $('#panDob_response').html('Invalid DOB/DOI for this account type.')
                            .addClass('text-danger').removeClass('text-success');
                    }
                },
                error: function(xhr) {
                    $(".overlay").hide();
                    let errorMessage = "An unexpected error occurred. Please reload the page.";
                    // if (xhr.responseJSON && xhr.responseJSON.message) {
                    //     errorMessage = xhr.responseJSON.message;
                    // }
                    Swal.fire({
                        title: "Error",
                        text: errorMessage,
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                }
            });
        });

        $('#resigterBtn').on('click', function(event) {
            event.preventDefault(); // Prevent the default form submission
            const doctype = $('#entity_firm').find('option:selected').data('doctype');
            const panNumberResponse = $('#panNumberResponse').val();
            const panNameResponse = $('#panNameResponse').val();
            const panDobResponse = $('#panDobResponse').val();
            const contact_first_name = $('#contact_first_name').val();
            const contact_last_name = $('#contact_last_name').val();
            const address = $('#address').val();
            const mobile_number = $('#mobile_number').val();
            const email_id1 = $('#email_id1').val();
            const state = $('#email_id1').val();
            const district = $('#district').val();
            const block_tehsil = $('#block_tehsil').val();
            const village = $('#village').val();
            const pin_code = $('#village').val();


            // Conditions to validate PAN, Name, and DOB
            if (panNumberResponse !== 'E') {
                Swal.fire({
                    title: "Validation Error",
                    text: "Kindly enter a valid PAN number. Otherwise, this user account cannot be registered.",
                    icon: 'error',
                    confirmButtonText: 'OK'
                });
                return;
            }

            if (panNameResponse === 'N') {
                const swalPanNameTitle = doctype === 'NA' ? 'Company or Organization Name' : 'Name';
                Swal.fire({
                    title: "Validation Error",
                    text: `The "${swalPanNameTitle}" provided does not match. Kindly use the correct name or you will not be able to register.`,
                    icon: 'error',
                    confirmButtonText: 'OK'
                });
                return;
            }

            if (panDobResponse === 'N') {
                const swalDobTitle = doctype === 'NA' ? 'Date of incorporation' : 'Date of Birth';
                Swal.fire({
                    title: "Validation Error",
                    text: `The "${swalDobTitle}" provided is incorrect. Kindly enter the correct date.`,
                    icon: 'error',
                    icon: 'error',
                    confirmButtonText: 'OK'
                });
                return;
            }


            if (contact_first_name === null || contact_first_name === '') {
                alert('Contact first name is required');
                return false;
            }


            if (contact_last_name === null || contact_last_name === '') {
                alert('Contact last name is required');
                return false;
            }

            if (address === null || address === '') {
                alert('address is required');
                return false;
            }

            if (mobile_number === null || mobile_number === '') {
                alert('mobile number is required');
                return false;
            }


            if (email_id1 === null || email_id1 === '') {
                alert('email_id is required');
                return false;
            }


            if (state === null || state === '') {
                alert('state is required');
                return false;
            }

            if (district === null || district === '') {
                alert('district is required');
                return false;
            }

            if (block_tehsil === null || block_tehsil === '') {
                alert('block tehsil is required');
                return false;
            }

            if (village === null || village === '') {
                alert('village is required');
                return false;
            }

            if (pin_code === null || pin_code === '') {
                alert('pin code is required');
                return false;
            }

            $('#commonform1').submit();
        });
    });

    // Track original values
    $(document).ready(function() {
        let originalPan = $('#panNumberResponse').val();
        let originalName = $('#panNameResponse').val();
        let originalDob = $('#panDobResponse').val();

        //console.log('Original Values on Load:', { originalPan, originalName, originalDob });

        // Add change event listeners to the fields
        $('#name, #dob_doi_date, #operator_pan').on('change', function() {
            const currentPan = $('#panNumberResponse').val();
            const currentName = $('#panNameResponse').val();
            const currentDob = $('#panDobResponse').val();


            // Check if any field is modified after the last verification
            if (currentPan != originalPan || currentName != originalName || currentDob != originalDob) {
                Swal.fire({
                    title: "Validation Required",
                    text: "Changes have been detected. Please revalidate the PAN details.",
                    icon: "warning",
                    confirmButtonText: "OK"
                });

                // Clear the hidden input fields to enforce re-verification

                if (this.id == 'name') {
                    $('#panNameResponse').val('');
                    $('#name').removeClass('is-valid').addClass('is-invalid');
                    $('#panName_response').html('Name has been changed.').removeClass('is-valid').addClass('text-warning');
                } else if (this.id == 'dob_doi_date') {
                    $('#panDobResponse').val('');
                    $('#dob_doi_date').removeClass('is-valid').addClass('is-invalid');
                    $('#panDob_response').html('PAN date has been changed.').removeClass('is-valid').addClass('text-warning');
                } else if (this.id == 'operator_pan') {
                    $('#panNumberResponse').val('');
                    $('#operator_pan').removeClass('is-valid').addClass('is-invalid');
                    $('#panNumber_response').html('PAN number has been changed.').removeClass('is-valid').addClass('text-warning');
                } else {
                    $('#panNameResponse, #panDobResponse, #panNumberResponse').val('');
                    $('#name, #dob_doi_date, #operator_pan').removeClass('is-invalid');
                }
                //$('#panName_response, #panDob_response, #panNumber_response').html('');
                // if (currentPan != originalPan) {
                //     $('#operator_pan').removeClass('is-valid').addClass('is-invalid');
                //     $('#panNumber_response').html('PAN number has been changed.').removeClass('is-valid').addClass('text-warning');
                // } else {
                //     $('#operator_pan').removeClass('is-invalid');
                // }

                // if (currentName != originalName) {
                //     $('#name').removeClass('is-valid').addClass('is-invalid');
                //     $('#panName_response').html('Name has been changed.').removeClass('is-valid').addClass('text-warning');
                // } else {
                //     $('#name').removeClass('is-invalid');
                // }

                // if (currentDob != originalDob) {
                //     $('#dob_doi_date').removeClass('is-valid').addClass('is-invalid');
                //     $('#panDob_response').html('PAN date has been changed.').removeClass('is-valid').addClass('text-warning');
                // } else {
                //     $('#dob_doi_date').removeClass('is-invalid');
                // }
            }
        });
    });
    //Indiviual father Name
    $(document).ready(function() {
        $('#entity_firm').on('change', function() {
            const doctype = $(this).find('option:selected').data('doctype');

            $('#panName_response, #panDob_response, #fatherName_response, #panNumber_response').html('');
            $('#name, #dob_doi_date, #father_name, #operator_pan, #entity_firm, #document_type').removeClass('is-invalid is-valid');

            $('#dob_doi_date_label').html('');
            if (doctype === 'Y') {
                $('#dob_doi_date_label').html('जन्म तिथि/Date of Birth');
                $('#fatherName_add').removeClass('d-none');
            } else {
                $('#dob_doi_date_label').html('संस्थापन की तारीख/Date of incorporation');
                $('#fatherName_add').addClass('d-none');
            }
        });

        //Space Trim 
        $('.keyValueChecker').on('input', function() {
            let value = $(this).val();
            value = value.replace(/[^a-zA-Z\s\-\.\/\\\{\}\[\]\(\)\*\#\$\&]/g, '');
            value = value.replace(/\s+$/, ' ');
            $(this).val(value);
        });




    });
</script>
@endpush
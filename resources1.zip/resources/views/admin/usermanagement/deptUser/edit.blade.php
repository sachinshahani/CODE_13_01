@extends('admin.layouts.app')
@section('content')
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Add User</h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">User Management</a></li>
                        <li class="breadcrumb-item active">Add User</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header align-items-center d-flex">
                    <h4 class="card-title mb-0 flex-grow-1">Registration of {{ getOperatorTypeById($user->ref_operator_type_id) }} </h4>
                    <div class="flex-shrink-0">
                        @if (session('error'))
                            <div class="alert alert-danger">
                                {{ session('error') }}
                            </div>
                        @endif
                        @if (session('success'))
                            <div class="alert alert-success">
                                {{ session('success') }}
                            </div>
                        @endif
                        @if ($errors)
                            @foreach ($errors->all() as $error)
                                <div class="alert alert-danger">{{ $error }}</div>
                            @endforeach
                        @endif
                    </div>
                </div>

                <div class="card-body">
                    <div class="live-preview">
                        <form action="{{ route('superadmin.usermanagement.deptUser.deptUserUpdate', $id) }}"
                            class="commonform1" method="POST" enctype="multipart/form-data" id="commonform1"
                            autocomplete="off">
                            @csrf
                            <input type="hidden"  name="role_id" value="{{ $user->ref_operator_type_id }}">
                            <input type="hidden"  name="standerd_type" value="{{ $user->standerd_type }}">
                            <div class="row gy-4">
                                {{-- <div class="col-xxl-3 col-md-6">
                                    <div>
                                        <label for="basiInput" class="form-label">Select Operator Type<span
                                                class="required">*</span></label>

                                        <select name="role_id" id="member" class="form-select" disabled>
                                            <option value="">Select Operator</option>
                                            @if (count(get_roles()) > 0)
                                                @foreach (get_roles() as $role)
                                                    @if ($role->id != Auth::guard('misadmin')->user()->role->role_id)
                                                        <option value="{{ $role->id }}"
                                                            {{ $role->id == $user->ref_operator_type_id ? 'selected' : '' }}>
                                                            {{ $role->title }}</option>
                                                    @endif
                                                @endforeach
                                            @endif
                                        </select>

                                    </div>
                                </div> --}}

                                <div class="row seperatesec white-inner">
                                    {{-- <div class="sectitle">
                                        <label for="labelInput" class="form-label">Name of the Operator</label>
                                    </div> --}}
                                    <div class="col-xxl-3 col-md-6">
                                        <div>
                                            @if($user->ref_operator_type_id==6)
                                            <label class="form-label">Name of Company <span class="form-text">(As per Legal Document)</span><span class="required">*</span></label>
                                            
                                            @else
                                            <label class="form-label">Name of {{getOperatorTypeById($user->ref_operator_type_id)}}  <span class="form-text">(As per Legal Document)</span><span class="required">*</span></label>
                                            @endif
                                            <input type="text" class="form-control" id="name" placeholder="First Name"
                                                name="first_name" required value="{{ $user->first_name }}">
                                        </div>
                                    </div>

                                    <div class="col-xxl-3 col-md-6">
                                        <div>
                                            <label for="labelInput" class="form-label">Entity/Firm Type</label>

                                            <select name="entity_firm" class="form-select">
                                            <option value="">Select Entity/Firm</option>
                                            {{-- <option value="Partnership" {{($user->entity_firm=='Partnership' ? 'selected':'')}}>Partnership</option> --}}
                                            <option value="Private Limited" {{($user->entity_firm=='Private Limited' ? 'selected':'')}}>Private Limited</option>
                                            <option value="Limited" {{($user->entity_firm=='Limited' ? 'selected':'')}}>Limited</option>
                                            <option value="Cooperative Society/Trust" {{($user->entity_firm=='Cooperative Society/Trust' ? 'selected':'')}}>Cooperative Society/Trust</option>
                                            </select>

                                        </div>
                                    </div>
                                </div>


                                <div class="row seperatesec white-inner">
                                    <div class="sectitle">
                                        @if($user->ref_operator_type_id==6)
                                        <label for="labelInput" class="form-label">Address of Processing Unit</label>
                                        @else
                                            <label for="labelInput" class="form-label">{{ getOperatorTypeById($user->ref_operator_type_id)}} Address</label>
                                        @endif
                                    </div>
                                    <div class="row">
                                        <div class="col-xxl-3 col-md-3">
                                            <div class="row">
                                                <div class="col-xx-12 col-md-12">
                                                    <label for="labelInput" class="form-label ">Address <span
                                                            class="required">*</span></label>
                                                    <textarea class="form-control customtextarea" name="address" required>{{ $user->address ?? '' }}</textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xxl-9 col-md-9">
                                            <div class="row">
                                                <div class="col-xxl-4 col-md-4">
                                                    <label for="labelInput" class="form-label">State <span
                                                            class="required">*</span></label>
                                                    <select class="form-select state" name="state" id="state"
                                                        required>
                                                        <option value="">Select State</option>
                                                        @forelse(getAllState() as $state)
                                                            <option value="{{ $state->id }}"
                                                                @selected($user->ref_state_id == $state->id)>{{ $state->state_name }}
                                                            </option>
                                                        @empty
                                                        @endforelse
                                                    </select>
                                                </div>
                                                <div class="col-xxl-4 col-md-4">
                                                    <label for="labelInput" class="form-label">District <span
                                                            class="required">*</span></label>
                                                    <select class="form-select district" name="district"
                                                        id="district" required>
                                                        @forelse(getDistrictByStateID($user->ref_state_id) as $district)
                                                            <option value="{{ $district->id }}"
                                                                @selected($user->ref_district_id == $district->id)>
                                                                {{ $district->district_name }}</option>
                                                        @empty
                                                            <option value="">-Select District-</option>
                                                        @endforelse


                                                    </select>
                                                </div>
                                                <div class="col-xxl-4 col-md-4">
                                                    <label for="labelInput" class="form-label">Taluka/Mandal <span
                                                            class="required">*</span></label>
                                                    <select class="form-select block_tehsil" name="taluka"
                                                        id="block_tehsil" required>

                                                        @forelse(getBlockTehsilByDistrictID($user->ref_district_id) as $block)
                                                            <option value="{{ $block->id }}"
                                                                @selected($user->ref_block_tehsil_id == $block->id)>
                                                                {{ $block->block_tehsil_name }}</option>
                                                        @empty
                                                            <option value="">-Select Taluka/Mandal-</option>
                                                        @endforelse


                                                    </select>
                                                </div>

                                                <div class="col-xxl-6 col-md-6 gy-3">
                                                    <label for="labelInput" class="form-label">Village <span
                                                            class="required">*</span></label>
                                                    <select class="form-select village" name="village" id="village"
                                                        required>
                                                        @forelse(getVillageByBlock($user->ref_block_tehsil_id) as $village)
                                                            <option value="{{ $village->id }}"
                                                                @selected($user->ref_village_id == $village->id)>
                                                                {{ $village->village_name }}</option>
                                                        @empty
                                                            <option value="">-Select Village-</option>
                                                        @endforelse
                                                    </select>
                                                </div>
                                                <div class="col-xxl-6 col-md-6 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">Pin Code<span
                                                                class="required">*</span></label>
                                                        <input type="text" class="form-control" id="pin_code"
                                                            name="pin_code" placeholder="Pin Code" maxlength="6"
                                                            required value="{{ $user->pin ?? '' }}">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="row seperatesec white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label">Contact Person Details</label>
                                    </div>

                                    <div class="col-xxl-3 col-md-6">
                                        <div>
                                            <label class="form-label">Contact Person First Name <span class="required">*</span></label>
                                            <input type="text" class="form-control textonly" id="contact_first_name"
                                                placeholder="First Name" name="contact_first_name"
                                                value="{{ $user->contact_person_first_name ?? '' }}" required>
                                        </div>
                                    </div>

                                    <div class="col-xxl-3 col-md-6">
                                        <div>
                                            <label class="form-label">Contact Person Middle Name</label>
                                            <input type="text" class="form-control textonly" id="contact_middle_name"
                                                name="contact_middle_name" placeholder="Middle Name"
                                                value="{{ $user->contact_person_middle_name ?? '' }}">
                                        </div>
                                    </div>

                                    <div class="col-xxl-3 col-md-6">
                                        <div>
                                            <label class="form-label">Contact Person Last Name <span class="required">*</span></label>
                                            <input type="text" class="form-control textonly" id="contact_last_name"
                                                name="contact_last_name" placeholder="Last Name" required
                                                value="{{ $user->contact_person_last_name ?? '' }}">
                                        </div>
                                    </div>
                                   
                                    <div class="col-xxl-3 col-md-6">
                                        <div>
                                            <label for="labelInput" class="form-label">Gender</label>
                                            <select name="contact_gender" class="form-select">
                                                <option value="">Select Gender</option>
												@foreach(getGenderName() as $key=> $value)
													<option value="{{$key}}" {{(old('contact_gender',$user->contact_gender)==$key ? 'selected':'')}}>{{$value}}</option>
												@endforeach

                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-xxl-3 col-md-6 gy-3">
                                        <div>
                                            <label for="labelInput" class="form-label">Contact Person Mobile Number<span
                                                    class="required">*</span></label>
                                            <input type="text" class="form-control numbersonly phone" id="mobile"
                                                required name="mobile" placeholder="Mobile Number"
                                                onblur="phonenumber(this)" maxlength="10"
                                                value="{{ $user->mobile_no ?? '' }}">
                                        </div>
                                    </div>

                                    <div class="col-xxl-3 col-md-6 gy-3">

                                        <div class="inputEmail  col-12 col-sm-12 col-md-12 col-lg-12">
                                            <div class="form-group d-flex justify-content-center ge-otp-form">
                                                <div class="col-10 col-sm-10 col-md-10 col-lg-12">
                                                    <label>Contact Person Email ID<span class="text-danger">*</span></label>
                                                    <input
                                                        class="form-control validateEmailId col-10 col-sm-10 col-md-10 col-lg-10"
                                                        type="text" value="{{ $user ? $user->email : '' }}"
                                                        placeholder="Email Id" id="email_id1" name="email"
                                                        @if ($user->email) readonly @endif />
                                                </div>
                                                @if (empty($user->email))
                                                    <div class="input-group-append col-2 col-sm-2 col-md-2 col-lg-2">
                                                        <button type="button"
                                                            class="btn-email btn btn-outline-success waves-effect waves-light visitorCat2"
                                                            style="font-size: 13px;padding: 1px 7px;line-height: 17px;margin-top: 27px;">Get
                                                            OTP</button>
                                                        <button type="button"
                                                            class="btn btn-ghost-success waves-effect waves-light btn-mailsend"
                                                            style="display:none">Mail Send</button>
                                                        <button type="button"
                                                            class="btn btn-ghost-success waves-effect waves-light btn-verify"
                                                            style="display:none">Verified</button>
                                                    </div>
                                                @endif
                                            </div>
                                            <div class="verify-email justify-content-center">
                                                <div class="login-pass mb-4 otp-email col-12 col-sm-12 col-md-5 col-lg-12 pl-2"
                                                    style="display:none">
                                                    <div class="input-group">
                                                        <span class="input-group-text mdi mdi-key"
                                                            id="inputGroup-sizing-default"></span>
                                                        <input type="text" class="form-control inp-b"
                                                            aria-label="Sizing example input"
                                                            aria-describedby="inputGroup-sizing-default" id="email_otp1">
                                                        <div class="input-group-append">
                                                            <a href="javascript:void(0)"
                                                                class="verifiEmail_otp btn btn-outline-success waves-effect waves-light">Verify</a>
                                                            <a href="javascript:void(0)"
                                                                class="resendEmail_otp btn btn-outline-danger waves-effect waves-light">Resend</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="col-xxl-3 col-md-6 gy-3">
                                        <div>
                                            <label for="labelInput" class="form-label">Contact
                                                Person Aadhar Number<span
                                                    class="required">*</span></label>
                                            <input type="text" class="form-control numbersonly"
                                                name="contact_person_aadhar_number" placeholder="Aadhar Number*"
                                                value="{{ $user->contact_person_aadhar_number ?? '' }}" required
                                                maxlength="12">
                                        </div>
                                    </div>


                                    <div class="col-xxl-3 col-md-6 gy-3">
                                        <div>
                                            <label for="labelInput" class="form-label">Designation of Contact
                                                Person</label>
                                            <input type="text" class="form-control" name="contact_designation"
                                                placeholder="Designation of Contact Person"
                                                value="{{ $user->contact_designation }}">
                                        </div>
                                    </div>

                                    {{-- <div class="col-xxl-3 col-md-6 gy-3">
                                    <label for="labelInput" class="form-label"></label><br>
                                     <button type="submit" class="btn btn-primary" style="margin-top:2.5%!important">Send OTP</button>

                                </div> --}}


                                    <div class="row">
                                        <div class="col-lg-12 gy-4">
                                            <div class="hstack gap-2">
                                                <button type="submit" class="btn btn-primary">Submit</button>
                                                <!-- <button type="button" class="btn btn-soft-success">Cancel</button> -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('script')
    <script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
    <script type="text/javascript">
        // email verification  details ---
        $(".btn-email").click(function(e) {
            e.preventDefault();
            var user_email = $('#email_id1').val();


            if (user_email != "") {
                $(".overlay").show();
                $.ajax({
                    type: 'POST',
                    url: "{{ route('superadmin.usermanagement.email_mobile_OTP') }}",
                    data: {
                        'user_email': user_email
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(resp) {
                        if (resp == 1) {

                            Swal.fire({
                                text: "Please verify OTP send on Email id",
                                icon: 'success',
                                confirmButtonText: 'OK'
                            }).then((result) => {
                                $('.otp-email').show(500);
                                $('#email_id1').val(user_email);
                                $('#email_id1').prop('readonly', true);
                                $('.btn-email').hide(500);
                                $('.btn-mailsend').show(100);
                            });

                        }
                        $(".overlay").hide();
                    }
                });
            } else {
                Swal.fire("", "Please enter Email ID", "error");
            }
        });


        $(".verifiEmail_otp").click(function(e) {
            e.preventDefault();
            var email_otp = $('#email_otp1').val();
            $(".overlay").show();
            if (email_otp != "") {

                $.ajax({
                    type: 'POST',
                    url: "{{ route('superadmin.usermanagement.email_mobile_OTP_check') }}",
                    data: {
                        'email_otp': email_otp
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(html) {
                        if (html == 0) {
                            Swal.fire("", "Please enter Valid OTP", "error");
                        } else {
                            $('#email_otp').prop('readonly', true);
                            $('.otp-email1').hide(500);
                            $('.btn-email').hide(500);
                            $('.btn-verify').show(500);
                            $('.visitorCat').hide(500);
                            $('.visitorCat1').hide(500);
                            $('.user_detail_page').show(500);
                            $('#email_id').prop('readonly', true);
                            $('.btn-mailsend').hide();
                            $('.login-pass').hide();
                        }
                        $(".overlay").hide();
                    }
                });
            } else {
                Swal.fire("", "Please enter OTP", "error");
            }
        });

        $(".resendEmail_otp").click(function(e) {
            e.preventDefault();
            var user_email = $('#email_id1').val();

            $.ajax({
                type: 'POST',
                url: "{{ route('superadmin.usermanagement.email_mobile_OTP') }}",
                data: {
                    'user_email': user_email
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(html) {
                    Swal.fire("", "Re OTP Send!!", "success");
                }
            });
        });

        // end






        $("#commonform1").validate({
            rules: {
                // user_password: {
                // 	required: true,
                // 	minlength: 8,
                // 	maxlength: 10,
                // } ,
                mobile: {
                    required: true,
                }
            },
            messages: {
                // user_password: {
                // 	required:"This field is required and should be 8 digits, contains upper,lowerCase,and a special Character"
                // },
                mobile: {
                    required: "This field is required",
                }
            }

        });

        function CheckPassword(inputtxt) {
            if (inputtxt.value.length > 0) {
                var decimal = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
                if (inputtxt.value.match(decimal)) {
                    return true;
                } else {
                    Swal.fire('',
                        'Password should be 8 digits,contains upperCase letter,lowerCase letter,and a special Character',
                        'warning');
                    $("#user_password").val('');
                    return false;
                }
            }
        }

        function phonenumber(inputtxt) {
            var phoneno = /^\d{10}$/;
            if (inputtxt.value.match(phoneno)) {
                return true;
            } else {
                Swal.fire('', 'Please enter a valid mobile number.', 'warning');
                $("#mobile").val('');
                return false;
            }
        }
    </script>
    @php
        $salt = rand('1000', '9999');
        session(['salt' => $salt]);
    @endphp
    <script type="text/javascript" src="{{ asset('public/backend/js/sha.js') }}"></script>
    <script>
        // $(document).on('submit','#commonform1',function(){
        //     var salt = '{{ $salt }}';
        //     var secret = $('#password').val();
        //     var shaObj = new jsSHA("SHA-256", "TEXT");
        //     shaObj.update(secret);
        //     var hashPass = shaObj.getHash("HEX");
        //     $('#password').val(hashPass);
        //     var secretcurrent = $('#confirm_password').val();
        //     var shaObjcurrent = new jsSHA("SHA-256", "TEXT");
        //     shaObjcurrent.update(secretcurrent);
        //     var hashPasscurrent = shaObjcurrent.getHash("HEX");
        //     $('#confirm_password').val(hashPasscurrent);
        // });
    </script>
@endpush

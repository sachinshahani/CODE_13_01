@extends('admin.layouts.app')
@section('content')
<style>
    body {
        margin: 0px;
        padding: 0px;
        font-family: "Segoe UI";
    }

    .maindiv {
        width: 80%;
        margin: 0 auto;
    }

    .pdf_maindiv {
        border: 1px solid #cccccc;
        width: 100%;
        float: left;
        padding: 2% 1%;
    }

    .pdf_heading {
        font-size: 20px;
        color: #000;
        padding: 26px 0 20px 0px;
        position: relative;
        width: 100%;
        float: left;
    }

    .brd_heading {
        border-bottom: 2px solid #ee5e24;
        padding-bottom: 8px;
        padding-right: 8px;
        width: 60px;
    }

    .pdf_input1 {
        background: #eeeeee;
    }

    .pdf_txt1 {
        color: #000;
        font-size: 14px;
        width: 45%;
        float: left;
        padding-bottom: 10px;
        font-weight: bold;
    }

    .pdf_box {
        color: #000;
        font-size: 14px;
        width: 55%;
        float: left;
        padding-bottom: 10px;
    }

    .table_pdf {
        width: 100%;
    }

    .pdf_heading:after {
        content: "";
        position: absolute;
        width: 70px;
        height: 2px;
        background-color: #ee5e24;
        bottom: 10px;
        display: block;
    }

    .pdf_heading:before {
        content: "";
        position: absolute;
        width: 22px;
        height: 6px;
        background-color: #ee5e24;
        bottom: 8px;
        display: block;
    }

    #step1 .card-body {
        background: #fff
    }

    .pdf_inner_heading:after {
        display: none;
    }

    .pdf_inner_heading:before {
        display: none;
    }

    .pdf_inner_heading {
        padding: 20px 0 12px;
        text-decoration: underline;
        font-size: 16px;
    }

    .pdf_maindiv hr:last-child {
        display: none;
    }

    .pdf-img-icon {
        height: 17px;
        width: 15px;
        margin-right: 5px;
    }

    @media print {

        .pdf_heading {
            font-size: 20px;
            color: #000;
            padding: 26px 0 20px 0px;
            position: relative;
            width: 100%;
            float: left;
            -webkit-print-color-adjust: exact !important;
            Chrome,
            Safari color-adjust: exact !important;
        }

        .pdf_heading:before {
            content: "";
            position: absolute;
            width: 20px;
            height: 4px;
            background-color: #ee5e24;
            bottom: 10px;
            display: block;
            -webkit-print-color-adjust: exact !important;
            Chrome,
            Safari color-adjust: exact !important;
        }


    }
/* Styling for the icon container */
.icon-container {
  display: flex;
  justify-content: center;
  align-items: center;
  margin-bottom: 20px;
}

/* Styling for the info icon */
.icon-info {
  width: 50px; /* Set the size of the icon */
  height: 50px;
  color: #17a2b8; /* Change color to info blue */
}

/* Style for the modal title */
.modal-title {
  font-size: 1.25rem;
  font-weight: bold;
  color: #17a2b8; /* Info blue color for the title */
}

/* Style for the modal body */
.modal-body {
  text-align: center;
  font-size: 1.1rem;
  color: #333;
}

/* Adjust modal size for better presentation */
.modal-dialog.modal-alert {
  max-width: 400px;
  margin: 1.75rem auto;
}

/* Style for the Close button */
.demo-close2 {
  background-color: #17a2b8;
  color: white;
  border: none;
  font-weight: bold;
  padding: 10px 20px;
}
.demo-close2:hover {
  background-color: #138496;
}


</style>
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">{{ getOperatorTypeById($user->ref_operator_type_id ?? '') }} Profile</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">{{ getOperatorTypeById($user->ref_operator_type_id ?? '') }} Profile</li>
                </ol>
            </div>

        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">

        <div class="tab-content py-4 custom-tab-content">
            <div class="tab-pane fade show active" id="step1">
                <div class="card">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1">
                            {{ user_name($user->id) ?? '' }}
                        </h4>

                        <div class="flex-shrink-0  {{(($user->status == 2 || $user->status == 4)? 'flex-grow-1':'')}}">
                            <label for="basiInput" class="form-label">{{ ($user->status == 2? 'Registration Number : '.$user->registration_no:"Application Number : #00".$user->id)}}</label>
                        </div>
                        @if($user->status == 2)
                        <div class="flex-shrink-0 flex-grow-1">
                            <label for="basiInput" class="form-label">Registration Certificate : <a target="_BLANK" href="{{ asset('public/' . $user->registration_certificate) }}" class="text-decoration-underline"><img src="{{ asset('public/assets/images/pdf-icon.png')}}" alt="" height="17px" class="pdf-img-icon">See Doc</a></label>
                        </div>
                            @if ($eMSignedModuleAlow['status'] == 'success')
                                <div class="flex-shrink-0">
                                    @if ($eMSignedModuleResult['status'] == 'success')
                                        @php
                                            $publicPath = str_replace('var/www/html/apeda/', '', $eMSignedModuleResult['signedPath']);
                                        @endphp
                                        <a class="btn btn-success btn-sm" download href="{{ $hostName . $publicPath }}">Download Signed PDF</a>
                                    @else
                                        <button type="button" class="btn btn-primary btn-sm" id="generateDigitalSign"
                                            data-filename="{{ basename($user->registration_certificate) }}"
                                            data-path="/{{ basename(dirname($user->registration_certificate)) }}/"
                                            data-filestored="public"
                                            data-certificate="RC">
                                            Digital Sign
                                        </button>
                                    @endif
                                </div>
                            @endif
                    
                        @endif
                        @if ($user->status == 0 || $user->status == 4)
                        {{-- <div class="flex-shrink-0">
                            <a href="{{ route('superadmin.icsuser.step1', $user->id) }}" class="btn btn-soft-success">Back</a>

                        </div> --}}
                        @endif
                    </div>

                    <!-- end card header -->
                    <div class="card-body">

                        <div class="pdf_heading">{{ getOperatorTypeById($user->ref_operator_type_id ?? '') }} Details</div>
                        <div class="pdf_maindiv">
                            <!--form1 section starts here-->
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                            <tr>
                                                <td class="pdf_txt1">{{ getOperatorTypeById($user->ref_operator_type_id ?? '') }} Name :</td>
                                                <td class="pdf_box">{{ user_name($user->id) ?? '' }}</td>
                                            </tr>
                                            {{-- <tr>
                                                        <td class="pdf_txt1">Standerd Type</td>
                                                        <td class="pdf_box">{{ $user->standerd_type ??''}}</td>
                                            </tr>
                                            --}}

                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">

                                            <tr>
                                                <td class="pdf_txt1">PAN No.</td>
                                                <td class="pdf_box">{{ $user->user_name ?? '' }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Photo of {{ getOperatorTypeById($user->ref_operator_type_id ?? '') }} Office building</td>
                                                <td class="pdf_box">
                                                    @if (!empty($user->office_building_photo))
                                                    <a target="_BLANK" href="{{ asset('public/ics/office_building_photo/' . $user->office_building_photo) }}" class="text-decoration-underline"><img src="{{ asset('public/assets/images/pdf-icon.png')}}" alt="" class="pdf-img-icon">See Doc</a>
                                                    @else
                                                    Not Available
                                                    @endif
                                                </td>
                                            </tr>

                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="pdf_heading">{{ getOperatorTypeById($user->ref_operator_type_id ?? '') }} Address</div>
                        <div class="pdf_maindiv">
                            <!--form1 section starts here-->
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                            <tr>
                                                <td class="pdf_txt1">State</td>
                                                <td class="pdf_box">{{ getStateName($user->ref_state_id) }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">District</td>
                                                <td class="pdf_box">{{ getDisName($user->ref_district_id) }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Taluka/Mandal</td>
                                                <td class="pdf_box">{{ getTalukName($user->ref_block_tehsil_id) }}</td>
                                            </tr>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>

                                    <div class="col-6">

                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                            <tr>
                                                <td class="pdf_txt1">Village</td>
                                                <td class="pdf_box">{{ getVillName($user->ref_village_id) }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Pin Code</td>
                                                <td class="pdf_box">{{ $user->pin ?? '' }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Address</td>
                                                <td class="pdf_box">{{ $user->address ?? '' }}</td>
                                            </tr>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>


                                </div>
                            </div>
                        </div>
                        <div class="pdf_heading">Contact Person Details</div>
                        <div class="pdf_maindiv">
                            <!--form1 section starts here-->
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                            {{-- <tr>
                                                <td class="pdf_txt1">First Name</td>
                                                <td class="pdf_box"> {{ $user->contact_person_first_name ?? '' }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Last Name</td>
                                                <td class="pdf_box"> {{ $user->contact_person_last_name ?? '' }}</td>
                                            </tr> --}}
                                            <tr>
                                                <td class="pdf_txt1">Full Name</td>
                                                <td class="pdf_box" colspan="2">{{ $user->contact_person_first_name ?? '' }} {{ $user->contact_person_middle_name ?? '' }} {{ $user->contact_person_last_name ?? '' }} </td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Email Id</td>
                                                <td class="pdf_box" colspan=2>{{ $user->contact_person_email ?? '' }}
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Gender</td>
                                                <td class="pdf_box">
                                                    @if ($user->contact_person_gender == 1)
                                                    Male
                                                    @elseif($user->contact_person_gender == 2)
                                                    Female
                                                    @else
                                                    other
                                                    @endif
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Address proof of {{ getOperatorTypeById($user->ref_operator_type_id ?? '') }} Manager</td>
                                                <td class="pdf_box">
                                                    @if ($user->address_proof_of_office == 'electricity_bill')
                                                    Electricity Bill
                                                    @elseif($user->address_proof_of_office == 'water_bill')
                                                    Water Bill
                                                    @elseif($user->address_proof_of_office == 'rent_agreement')
                                                    Rent Agreement
                                                    @else
                                                    N/A
                                                    @endif
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Number of Farmers</td>
                                                <td class="pdf_box">{{ $user->no_of_farmers ?? '' }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Managed by</td>
                                                <td class="pdf_box">{{ $user->managed_by ?? '' }}</td>
                                            </tr>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>

                                    <div class="col-6">

                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                            {{-- <tr>
                                                <td class="pdf_txt1">Middle Name</td>
                                                <td class="pdf_box"> {{ $user->contact_person_middle_name ?? '' }}</td>
                                            </tr> --}}
                                            <tr>
                                                <td class="pdf_txt1">Contact No.</td>
                                                <td class="pdf_box">{{ $user->contact_person_mobile_number ?? '' }}
                                                </td>
                                            </tr>
                                            {{-- <tr>
                                                <td class="pdf_txt1">Aadhaar No.</td>
                                                <td class="pdf_box">{{ $user->contact_person_aadhar_number ?? '' }}
                                                </td>
                                            </tr> --}}

                                            <tr>
                                                {{-- @php
                                                    $addhar = $user->contact_person_aadhar_number;        
                                                    if (preg_match('/^eyJpdiI6.*$/', $addhar)) {
                                                    try {
                                                        $addhar = Crypt::decrypt($addhar);
                                                    } catch (DecryptException $e) {
                                                        $addhar = 'Invalid Aadhaar No';
                                                    }
                                                     }
                                           
                                                @endphp --}}

                                                        @php
                                                        $maskedAadhar = '';
                                                        try {
                                                            if ($user->contact_person_aadhar_number) {
                                                                $decryptedAadhar = Crypt::decrypt(
                                                                    $user->contact_person_aadhar_number,
                                                                );
                                                                $maskedAadhar = maskAadhaarNumber($decryptedAadhar);
                                                            }
                                                        } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
                                                            $maskedAadhar = 'Invalid Aadhaar Number';
                                                        }
                                                    @endphp


                                                  <td class="pdf_txt1">Aadhaar No.</td>
                                                  <td class="pdf_box">{{$maskedAadhar}}
                                                  </td>
                                              </tr>

                                            
                                            <tr>
                                                <td class="pdf_txt1">Designation of Contact Person</td>
                                                <td class="pdf_box">{{ $user->contact_designation ?? '' }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Address Proof Doc</td>
                                                <td class="pdf_box">
                                                    @if (!empty($user->address_proof_of_office_doc))
                                                    <a target="_BLANK" href="{{ asset('public/ics/address_proof_of_office_doc/' . $user->address_proof_of_office_doc) }}" class="text-decoration-underline"><img src="{{ asset('public/assets/images/pdf-icon.png')}}" alt="" class="pdf-img-icon">See Doc</a>
                                                    @else
                                                    Not Available
                                                    @endif
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Number of Inspector</td>
                                                <td class="pdf_box">{{ $user->no_of_inspector ?? '' }}</td>
                                            </tr>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>


                                </div>
                            </div>
                        </div>
                        <div class="pdf_heading">Self/Service Provider Details</div>
                        <div class="pdf_maindiv">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf table_contact_person">
                                            <tr>
                                                <td class="pdf_txt1">First Name</td>
                                                <td class="pdf_box"> {{ $icsmandator->first_name ?? '' }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Last Name</td>
                                                <td class="pdf_box"> {{ $icsmandator->last_name ?? '' }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Email Id</td>
                                                <td class="pdf_box" colspan=2>{{ $icsmandator->email_id ?? '' }}</td>
                                            </tr>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf table_contact_person">
                                            <tr>
                                                <td class="pdf_txt1">Middle Name</td>
                                                <td class="pdf_box"> {{ $icsmandator->middle_name ?? '' }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Contact No.</td>
                                                <td class="pdf_box">{{ $icsmandator->mobile_no ?? '' }}</td>
                                            </tr>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="pdf_heading">Office Address</div>
                        <div class="pdf_maindiv">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf table_contact_person">
                                            <tbody>
                                                <tr>
                                                    <td class="pdf_txt1">State</td>
                                                    <td class="pdf_box">{{ getStateName($icsmandator->ref_state_id??'') }}
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td class="pdf_txt1">Taluka/Mandal</td>
                                                    <td class="pdf_box" colspan=2>
                                                        {{ getTalukName($icsmandator->ref_block_tehsil_id ??'' ) }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Pin Code</td>
                                                    <td class="pdf_box">{{ $icsmandator->pin_code ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">ID Proof</td>
                                                    <td class="pdf_box">{{ $icsmandator->id_proof ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Photo of {{ getOperatorTypeById($user->ref_operator_type_id ?? '') }} Manager</td>
                                                    <td class="pdf_box">
                                                        @if (!empty($icsmandator->profile_photo))
                                                        <a target="_BLANK" href="{{ asset('public/ics/profile_photo/' . $icsmandator->profile_photo) }}" class="text-decoration-underline"><img src="{{ asset('public/assets/images/pdf-icon.png')}}" alt="" class="pdf-img-icon">See Doc</a>
                                                        @else
                                                        Not Available
                                                        @endif
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf table_contact_person">
                                            <tbody>
                                                <tr>
                                                    <td class="pdf_txt1">District</td>
                                                    <td class="pdf_box">
                                                        {{ getDisName($icsmandator->ref_district_id ?? '') }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Village</td>
                                                    <td class="pdf_box">
                                                        {{ getVillName($icsmandator->ref_village_id ?? '') }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Address</td>
                                                    <td class="pdf_box">{{ $icsmandator->address1 ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">ID Proof Doc</td>
                                                    <td class="pdf_box">
                                                        @if (!empty($icsmandator->address_proof_of_office_doc))
                                                        <a target="_BLANK" href="{{ asset('public/ics/address_proof_of_office_doc/' . $icsmandator->address_proof_of_office_doc) }}" class="text-decoration-underline"><img src="{{ asset('public/assets/images/pdf-icon.png')}}" alt="" class="pdf-img-icon">See Doc</a>
                                                        @else
                                                        Not Available
                                                        @endif
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Appointment Letter of {{ getOperatorTypeById($user->ref_operator_type_id ?? '') }} Manager</td>
                                                    <td class="pdf_box">
                                                        @if (!empty($icsmandator->appointment_doc))
                                                        <a target="_BLANK" href="{{ asset('public/ics/appointment_doc/' . $icsmandator->appointment_doc) }}" class="text-decoration-underline"><img src="{{ asset('public/assets/images/pdf-icon.png')}}" alt="" class="pdf-img-icon">See Doc</a>
                                                        @else
                                                        Not Available
                                                        @endif
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="pdf_heading">Farmer Details</div>
                        <div class="pdf_maindiv">
                            <!-- farmer-1 container start  -->
                            @forelse($farmerDetails as $key => $val)
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-12">
                                        <h6 style="padding:0;padding-bottom:15px;width: 100%;text-decoration: underline;">Farmer : {{ $val->registration_no ?? '' }}
                                            </caption>
                                    </div>
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf table_contact_person">

                                            <tbody>
                                                <tr>
                                                    <td class="pdf_txt1">Farmer Name</td>
                                                    <td class="pdf_box">{{ $val->farmer_first_name ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Email Id</td>
                                                    <td class="pdf_box">{{ $val->email_id ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">District</td>
                                                    <td class="pdf_box"> {{ getDisName($val->ref_district_id) }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Village</td>
                                                    <td class="pdf_box">{{ getVillName($val->ref_village_id) }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Address</td>
                                                    <td class="pdf_box">{{ $val->farmer_address ?? '' }}</td>
                                                </tr>
                                                @php
                                                $maskedAadhar = '';
                                                try {
                                                    if ($val->aadhar_number) {
                                                        $decryptedAadhar = Crypt::decrypt(
                                                            $val->aadhar_number,
                                                        );
                                                        $maskedAadhar = maskAadhaarNumber($decryptedAadhar);
                                                    }
                                                } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
                                                    $maskedAadhar = 'Invalid Aadhaar Number';
                                                }
                                              @endphp

                                                <tr>
                                                    <td class="pdf_txt1">Aadhaar No.</td>
                                                    {{-- <td class="pdf_box"> --}}
                                                    {{-- @if (!empty($val->aadhar_number))

                                                            <a target="_BLANK"
                                                                href="{{ asset('public/farmer/aadhar_card/' . $val->aadhar_number) }}"
                                                    class="text-decoration-underline"><img src="{{ asset('public/assets/images/pdf-icon.png')}}" alt="" class="pdf-img-icon">See Doc</a>
                                                    @else
                                                    Not Available
                                                    @endif --}}
                                                    <td class="pdf_box">{{$maskedAadhar}}</td>
                                                    {{-- </td> --}}
                                                </tr>
                                            </tbody>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf table_contact_person">
                                            <tbody>
                                                <tr>
                                                    <td class="pdf_txt1">Mobile No.</td>
                                                    <td class="pdf_box"> {{ $val->mobile_no ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">State</td>
                                                    <td class="pdf_box">{{ getStateName($val->ref_state_id) }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Taluka/Mandal</td>
                                                    <td class="pdf_box" colspan=2>{{ getTalukName($val->ref_block_tehsil_id) }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Pin Code</td>
                                                    <td class="pdf_box">{{ $val->pin ?? '' }}</td>
                                                </tr>

                                                <tr>
                                                    <td class="pdf_txt1">Landmark </td>
                                                    <td class="pdf_box">{{ $val->landmark ?? '' }}</td>
                                                </tr>

                                            </tbody>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                </div>
                            </div>
                            <!-- Farmer - 1 container ended  -->
                            <hr>
                            @empty
                            @endforelse
                            <!-- farmer - 2 container start  -->

                            <!-- farmer -2 container end  -->
                        </div>
                        <div class="pdf_heading">Internal Inspector Details</div>
                        <div class="pdf_maindiv">
                            <!-- Inspector -1 container start  -->
                            @forelse ($userInsp as $key => $value)
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-12">
                                        <h6 style="padding:0;padding-bottom:15px;width: 100%;text-decoration: underline;">Inspector {{ $key+1 }}</caption>
                                    </div>
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf table_contact_person">

                                            <tbody>
                                                <tr>
                                                    <td class="pdf_txt1">Name of Inspector</td>
                                                    <td class="pdf_box">{{ $value->name_of_inspector ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Email Id</td>
                                                    <td class="pdf_box">{{ $value->email ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">District</td>
                                                    <td class="pdf_box"> {{ getDisName($value->ref_district_id) }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Village</td>
                                                    <td class="pdf_box">{{ getVillName( $value->ref_village_id) }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Address</td>
                                                    <td class="pdf_box">{{ $value->address ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">ID Proof Doc</td>
                                                    <td class="pdf_box">
                                                        {{ $icsmandator->id_proof_doc ?? '' }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Address Proof of Doc</td>
                                                    <td class="pdf_box">
                                                        @if (!empty($value->address_proof_of_office_doc))

                                                        <a target="_BLANK" href="{{ asset('public/inspector/address_proof_of_office_doc/' . $value->address_proof_of_office_doc) }}" class="text-decoration-underline"><img src="{{ asset('public/assets/images/pdf-icon.png')}}" alt="" class="pdf-img-icon">See Doc</a>
                                                        @endif
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Appointment Letter</td>
                                                    <td class="pdf_box">
                                                        @if (!empty($value->appointment_doc))

                                                        <a target="_BLANK" href="{{ asset('public/inspector/appointment_doc/' . $value->appointment_doc) }}" class="text-decoration-underline"><img src="{{ asset('public/assets/images/pdf-icon.png')}}" alt="" class="pdf-img-icon">See Doc</a>
                                                        @endif
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf table_contact_person">
                                            <tbody>
                                                <tr>
                                                    <td class="pdf_txt1">Mobile No.</td>
                                                    <td class="pdf_box"> {{ $value->mobile_no ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">State</td>
                                                    <td class="pdf_box">{{ getStateName($value->ref_state_id) }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Taluka/Mandal</td>
                                                    <td class="pdf_box" colspan=2>{{ getTalukName($value->ref_block_tehsil_id) }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Pin Code</td>
                                                    <td class="pdf_box">{{ $value->pin ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">ID Proof</td>
                                                    <td class="pdf_box"> @if($value->id_proof == 'aadhar')
                                                        Aadhaar
                                                        @elseif ($value->id_proof == 'voter_id')
                                                        Voter Id
                                                        @elseif ($value->id_proof == 'driving_licence')
                                                        Driving Licence
                                                        @else
                                                        @endif</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Address Proof</td>
                                                    <td class="pdf_box">
                                                        @if($value->address_proof_of_office == 'electricity_bill')
                                                        Electricity Bill
                                                        @elseif ($value->address_proof_of_office == 'rent_agreement')
                                                        Rent Agreement
                                                        @elseif ($value->address_proof_of_office == 'driving_licence')
                                                        Driving Licence
                                                        @else
                                                        @endif
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Photo of Inspector</td>
                                                    <td class="pdf_box"> @if (!empty($value->profile_photo))

                                                        <a target="_BLANK" href="{{ asset('public/inspector/profile_photo/' . $value->profile_photo) }}" class="text-decoration-underline"><img src="{{ asset('public/assets/images/pdf-icon.png')}}" alt="" class="pdf-img-icon">See Doc</a>
                                                        @endif
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                </div>
                            </div>
                            <!-- Inspector - 1 container ended  -->
                            <hr>
                            @empty
                            @endforelse
                            <!-- Inspector - 2 container start  -->

                            <!-- Inspector -2  container end  -->
                        </div>
                        <div class="pdf_heading">Warehouse Details</div>
                        <div class="pdf_maindiv">
                            <div class="pdf_heading pdf_inner_heading">Details Of Warehouse Manager</div>
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf table_contact_person">
                                            <tbody>
                                                <tr>
                                                    <td class="pdf_txt1">Warehouse Available</td>
                                                    <td class="pdf_box">
                                                        @if(isset($warehs->warehouse_available))
                                                        @if($warehs->warehouse_available == 'ics')
                                                        {{ getOperatorTypeById($user->ref_operator_type_id ?? '') }}
                                                        @elseif ($warehs->warehouse_available == 'mandator')
                                                        Mandator
                                                        @elseif ($warehs->warehouse_available == 'both')
                                                        Both
                                                        @elseif ($warehs->warehouse_available == 'none')
                                                        None
                                                        @endif
                                                        @endif
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td class="pdf_txt1">Warehouse Type</td>
                                                    <td class="pdf_box" colspan=2>
                                                        @if(isset($warehs->warehouse_available))
                                                        @if($warehs->warehouse_type == 'own')
                                                        Own
                                                        @elseif ($warehs->warehouse_type == 'lease')
                                                        Lease
                                                        @endif
                                                        @endif
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Number of Warehouses</td>
                                                    <td class="pdf_box">{{ $warehs->number_of_warehouse ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Warehouse Licence Number</td>
                                                    <td class="pdf_box">{{$warehs->licence_number ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Area (Sq.MT) </td>
                                                    <td class="pdf_box">{{ $warehs->warehouse_area ?? '' }}</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf table_contact_person">
                                            <tbody>
                                                <tr>
                                                    <td class="pdf_txt1">Capacity (MT)</td>
                                                    <td class="pdf_box"> {{ $warehs->capacity ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Warehouse Proof Of Office</td>
                                                    <td class="pdf_box">
                                                        @if(isset($warehs->address_proof_of_office) && $warehs->address_proof_of_office == 'electricity_bill')
                                                        Electricity Bill
                                                        @elseif (isset($warehs->address_proof_of_office) && $warehs->warehouse_type == 'rent_agreement')
                                                        Rent Agreement
                                                        @endif
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Warehouse Proof Of Office Doc</td>
                                                    <td class="pdf_box">@if (!empty($warehs->address_proof_of_office_doc))

                                                        <a target="_BLANK" href="{{ asset('public/warehouse/address_proof_of_office_doc/' . $warehs->address_proof_of_office_doc) }}" class="text-decoration-underline"><img src="{{ asset('public/assets/images/pdf-icon.png')}}" alt="" class="pdf-img-icon">See Doc</a>
                                                        @else
                                                        Not Avialable
                                                        @endif
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Photo of warehouse</td>
                                                    <td class="pdf_box">
                                                        @if (!empty($warehs->office_building_photo))

                                                        <a target="_BLANK" href="{{ asset('public/warehouse/office_building_photo/' . $warehs->office_building_photo) }}" class="text-decoration-underline"><img src="{{ asset('public/assets/images/pdf-icon.png')}}" alt="" class="pdf-img-icon">See Doc</a>
                                                        @else
                                                        Not Avialable
                                                        @endif
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="pdf_heading pdf_inner_heading">Address Of Warehouse</div>
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf table_contact_person">
                                            <tbody>
                                                <tr>
                                                    <td class="pdf_txt1">State</td>
                                                    <td class="pdf_box">{{ getStateName($warehs->ref_state_id??'') }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Taluka/Mandal</td>
                                                    <td class="pdf_box" colspan=2>{{ getTalukName($warehs->ref_block_tehsil_id ??'') }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Pin Code</td>
                                                    <td class="pdf_box">{{ $warehs->pin_code ?? '' }}</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf table_contact_person">
                                            <tbody>
                                                <tr>
                                                    <td class="pdf_txt1">District</td>
                                                    <td class="pdf_box"> {{ getDisName($warehs->ref_district_id ??'') }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Village</td>
                                                    <td class="pdf_box">{{ getVillName( $warehs->ref_village_id ??'') }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Address</td>
                                                    <td class="pdf_box">{{ $warehs->address ?? '' }}</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="pdf_heading pdf_inner_heading">Details Of Warehouse Manager</div>
                            <!-- Warehouse Manager -1 container start  -->
                            @forelse($wmanager as $key => $wm)
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-12">
                                        <h6 style="padding:0;padding-bottom:15px;width: 100%;text-decoration: underline;">Warehouse Manager {{ $key+1 }}</caption>
                                    </div>
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf table_contact_person">

                                            <tbody>
                                                <tr>
                                                    <td class="pdf_txt1">First Name</td>
                                                    <td class="pdf_box">{{ $wm->first_name ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Last Name</td>
                                                    <td class="pdf_box">{{ $wm->last_name ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Contact No.</td>
                                                    <td class="pdf_box">{{ $wm->contact_number?? '' }}</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf table_contact_person">
                                            <tbody>
                                                <tr>
                                                    <td class="pdf_txt1">Middle Name</td>
                                                    <td class="pdf_box"> {{ $wm->middle_name ?? '' }}</td>
                                                </tr>

                                                @php
                                                $maskedAadhar = '';
                                                try {
                                                    if ($wm->aadhar_card_number) {
                                                        $decryptedAadhar = Crypt::decrypt(
                                                            $wm->aadhar_card_number,
                                                        );
                                                        $maskedAadhar = maskAadhaarNumber($decryptedAadhar);
                                                    }
                                                } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
                                                    $maskedAadhar = 'Invalid Aadhaar Number';
                                                }
                                              @endphp
                                                <tr>
                                                    <td class="pdf_txt1">Aadhaar No.</td>
                                                    <td class="pdf_box">{{$maskedAadhar}}</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                </div>
                            </div>
                            <!-- Warehouse Manager - 1 container ended  -->
                            <hr>
                            @empty
                            @endforelse
                            <!-- Warehouse Manager - 2 container start  -->

                            <!-- Warehouse Manager -2  container end  -->
                        </div>
                        {{-- <div class="pdf_heading">{{ getOperatorTypeById($user->ref_operator_type_id ?? '') }} Official Details</div>
                          <div class="pdf_maindiv">

                            @forelse($pmanager as $key=>$pm)
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-12">
                                        @if($key==0)
                                        <h6 style="padding:0;padding-bottom:15px;width: 100%;text-decoration: underline;">Details Of
                                            Purchase Manager</h6>
                                        @endif
                                    </div>
                                    <div class="col-12">
                                        <h6 style="padding:0;padding-bottom:15px;width: 100%;text-decoration: underline;">Purchase Manager {{ $key+1 }}.</h6>
                                    </div>
                                    <div class="col-6">


                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf table_contact_person">
                                            <tbody>
                                                <tr>
                                                    <td class="pdf_txt1">First Name</td>
                                                    <td class="pdf_box">{{ $pm->first_name ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Last Name</td>
                                                    <td class="pdf_box">{{ $pm->last_name ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Contact Number</td>
                                                    <td class="pdf_box">{{ $pm->contact_number ?? ''}}</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf table_contact_person">
                                            <tbody>
                                                <tr>
                                                    <td class="pdf_txt1">Middle Name</td>
                                                    <td class="pdf_box"> {{ $pm->middle_name ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Aadhar Card</td>
                                                    <td class="pdf_box">{{ $pm->aadhar_card_number ?? '' }}</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                </div>
                            </div>
                            <!-- Details Of Purchase Manager container ended  -->
                            <hr>
                            @empty
                            @endforelse
                            <!-- Details of Field Officers container start  -->
                            @forelse($foanager as $key=>$fo)
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-12">
                                        @if($key==0)
                                        <h6 style="padding:0;padding-bottom:15px;width: 100%;text-decoration: underline;">Details of
                                            Field Officers</caption>
                                            @endif
                                    </div>
                                    <div class="col-12">
                                        <h6 style="padding:0;padding-bottom:15px;width: 100%;text-decoration: underline;">Field Officers {{ $key+1 }}.</h6>
                                    </div>
                                    <div class="col-6">

                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf table_contact_person">
                                            <tbody>
                                                <tr>
                                                    <td class="pdf_txt1">First Name</td>
                                                    <td class="pdf_box">{{ $fo->first_name ??'' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Last Name</td>
                                                    <td class="pdf_box">{{ $fo->last_name ??'' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Contact Number</td>
                                                    <td class="pdf_box">{{ $fo->contact_number ?? '' }}</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf table_contact_person">
                                            <tbody>
                                                <tr>
                                                    <td class="pdf_txt1">Middle Name</td>
                                                    <td class="pdf_box"> {{ $fo->middle_name  ?? ''}}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Aadhar Card</td>
                                                    <td class="pdf_box">{{ $fo->aadhar_card_number ?? '' }}</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                </div>
                            </div>
                            <!-- Details of Field Officers  container end  -->
                            <hr>
                            @empty
                            @endforelse

                            <!-- Details Of Approval Manager\Committee container start  -->
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-12">
                                        <h6 style="padding:0;padding-bottom:15px;width: 100%;text-decoration: underline;">Details Of
                                            Approval Manager</caption>
                                    </div>
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf table_contact_person">
                                            <tbody>
                                                <tr>
                                                    <td class="pdf_txt1">First Name</td>
                                                    <td class="pdf_box">{{ $amanager->first_name ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Last Name</td>
                                                    <td class="pdf_box">{{ $amanager->last_name ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Contact Number</td>
                                                    <td class="pdf_box">{{ $amanager->contact_number ?? '' }}</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf table_contact_person">
                                            <tbody>
                                                <tr>
                                                    <td class="pdf_txt1">Middle Name</td>
                                                    <td class="pdf_box"> {{ $amanager->middle_name ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Email ID</td>
                                                    <td class="pdf_box">{{ $amanager->email_id ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Aadhar Card</td>
                                                    <td class="pdf_box">{{ $amanager->aadhar_card_number ?? '' }}</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                </div>
                            </div>
                            <!-- Details Of Approval Manager\Committee container ended  -->
                        </div> --}}
                        <div class="row">
                            <div class="col-lg-12">

                                <div class="tab-content py-4 custom-tab-content">
                                    <div class="tab-pane fade show active" id="step1">
                                        @if($user->status!=2)
                                        <div class="card">
                                            <div class="card-header align-items-center d-flex">
                                                <h4 class="card-title mb-0 flex-grow-1">
                                                    Remarks:

                                                </h4>
                                            </div>
                                            <!-- end card header -->
                                            <div class="card-body">
                                                <div class="live-preview">

                                                    {{-- <div class="col-xxl-4 col-md-4 gy-4 ">
                                                            <div>
                                                                <label for="basiInput"
                                                                    class="form-label">Remarks :
                                                                </label>
                                                                <label for="basiInput">{{ $user->cb_reg_remarks ?? '' }}
                                                    </label>

                                                </div>
                                            </div> --}}

                                            <form method="post" id="" action="{{ route('superadmin.usermanagement.deptUser.previewpost') }}">
                                                @csrf
                                                <input type="hidden" name="at_user_id" value="{{ $user->id }}">
                                                <input type="hidden" name="id" value="{{ $user->ref_operator_type_id }}">
                                                <div class="col-xxl-4 col-md-4 gy-4 ">
                                                    <div>
                                                        <label for="basiInput" class="form-label">Status<span class="required">*</span>
                                                        </label>

                                                        <select class="form-select" name="status" required onchange="getwarning(this.value)">
                                                            <option value="">-Select-
                                                            </option>
                                                            <option value="2" {{  $user->status==2 ?'selected':'' }}>Approved
                                                            </option>
                                                            <option value="4" {{  $user->status==4 ?'selected':'' }}>Review</option>
                                                            <option value="3" {{  $user->status==3 ?'selected':'' }}>Rejected

                                                            </option>
                                                        </select>

                                                    </div>
                                                </div>

                                                <div class="col-xxl-6 col-md-6 gy-6 mt-3">
                                                    <div>
                                                        <label class="form-label">Submit Your
                                                            Remarks:<span class="required">
                                                                *</span></label>
                                                        <textarea placeholder="Address of The Inspector" class="form-control customtextarea" name="cb_remarks" required>{{ $user->cb_reg_remarks ?? '' }}</textarea>
                                                    </div>
                                                </div>
                                                {{-- @if ($regDetail->cb_remarks == '' && $regDetail->cb_status == '') --}}
                                                <div class="row">
                                                    <div class="col-xxl-4 col-md-4 gy-4 ">
                                                        <div class="hstack gap-2">

                                                            <button type="submit" id="submitbtn" class="btn btn-primary submit-button">Submit</button>

                                                        </div>
                                                    </div>
                                                </div>
                                                {{-- @endif --}}
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                @endif
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

</div>
</div>


<div class="modal fade" id="exampleModal2" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="exampleModalLabel2" aria-hidden="true">
  <div class="modal-dialog modal-alert w-100">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-info" id="exampleModalLabel2">Information</h5>
      </div>
      <div class="modal-body">
        <div class="text-info icon-container">
          <!-- Information Icon (SVG) -->
          <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-info" viewBox="0 0 24 24" width="50" height="50">
            <circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" stroke-width="2"/>
            <line x1="12" y1="16" x2="12" y2="12" stroke="currentColor" stroke-width="2"/>
            <line x1="12" y1="8" x2="12" y2="8" stroke="currentColor" stroke-width="2"/>
          </svg>
        </div>
        <h5 class="mt-2">Please ensure that the information provided is accurate before proceeding with certificate generation. </h5>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-info demo-close2">Close</button>
      </div>
    </div>
  </div>
</div>





@endsection

@push('script')

<script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
<script>
    $(document).on('click', '#submitbtn', function() {

        if (checkValidation("registration")) {
            $('#registration').submit();
            return true;
        } else {
            return false;
        }
    });

    function getwarning(id) {
    if(id == 2){
    $('#exampleModal2').modal('show');
    const modal2 = document.querySelector('#exampleModal2');
    const close2 = document.querySelector('.demo-close2');

    close2.addEventListener('click', () => {
        $('#exampleModal2').modal('hide'); 
    });
}  
}

     

</script>
@endpush

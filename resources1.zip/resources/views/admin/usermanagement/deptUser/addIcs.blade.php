@extends('admin.layouts.app')
@section('content')
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Add ICS User</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">User Management</a></li>
                    <li class="breadcrumb-item active">Add ICS User</li>
                </ol>
            </div>
        </div>
    </div>
</div>

  <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-header align-items-center d-flex">
                                    <h4 class="card-title mb-0 flex-grow-1">Add ICS User </h4>
                                    <div class="flex-shrink-0">
                                         @if (session('error'))
											<div class="alert alert-danger">
												{{ session('error') }}
											</div>
										@endif
										@if (session('success'))
											<div class="alert alert-success">
												{{ session('success') }}
											</div>
										@endif
										@if($errors)
											@foreach ($errors->all() as $error)
												<div class="alert alert-danger">{{ $error }}</div>
											@endforeach
										@endif
                                    </div>
                                </div><!-- end card header -->

                                <div class="card-body">
                                    <div class="live-preview">
                                        <form action="{{ route('superadmin.usermanagement.deptUser.store') }}" class="commonform1" method="POST" enctype="multipart/form-data" id="commonform1" autocomplete="off">
										@csrf
                                        <div class="row gy-4">
                                            <div class="col-xxl-3 col-md-6">
                                                <div>
                                                    <label for="basiInput" class="form-label">Select Operator Type</label>
                                                    <div class="input-group">
                                                   <select name="role_id" id="member" class="form-control" required>
                                                   <option value="">Select Operator</option>
                                                   @if(count(get_roles()) > 0)
														@foreach(get_roles() as $role)
															@if($role->id!=Auth::guard('misadmin')->user()->role->role_id)
															<option value="{{$role->id}}" >{{$role->title}}</option>
															@endif
														@endforeach
													@endif
													</select>
                                                    </div>


                                                </div>
                                            </div>

                                            <div class="row seperatesec">
                                                <div class="sectitle">
                                                    <label for="labelInput" class="form-label">Name of the Operator<span class="required">*</span></label>
                                                    </div>

                                                    <div class="col-xxl-4 col-md-6">
                                                        <div>
                                                            <label class="form-label">First Name</label>
                                                            <input type="text" class="form-control" id="name" placeholder="First Name" name="first_name">
                                                        </div>
                                                    </div>

                                                    <div class="col-xxl-4 col-md-6">
                                                        <div>
                                                        <label class="form-label">Middle Name</label>
                                                         <input type="text" class="form-control" id="m_name" placeholder="Middle Name" name="middle_name">
                                                        </div>
                                                    </div>

                                                    <div class="col-xxl-4 col-md-6">
                                                        <div>
                                                            <label class="form-label">Last Name</label>
                                                            <input type="text" class="form-control" id="last_name" name="last_name" placeholder="Last Name">
                                                        </div>
                                                    </div>

                                            </div>



                                            <div class="row seperatesec">
                                                <div class="sectitle">
                                                    <label for="labelInput" class="form-label">Name of the Contact Person<span class="required">*</span></label>
                                                    </div>

                                                    <div class="col-xxl-4 col-md-6">
                                                        <div>
                                                            <label class="form-label">First Name</label>
                                                            <input type="text" class="form-control" id="contact_first_name" placeholder="First Name" name="contact_first_name">
                                                        </div>
                                                    </div>

                                                    <div class="col-xxl-4 col-md-6">
                                                        <div>
                                                        <label class="form-label">Middle Name</label>
                                                         <input type="text" class="form-control" id="contact_middle_name" name="contact_middle_name" placeholder="Middle Name">
                                                        </div>
                                                    </div>

                                                    <div class="col-xxl-4 col-md-6">
                                                        <div>
                                                            <label class="form-label">Last Name</label>
                                                            <input type="text" class="form-control" id="contact_last_name" name="contact_last_name" placeholder="Last Name">
                                                        </div>
                                                    </div>

                                                    <div class="col-xxl-4 col-md-6">
                                                        <div>
                                                            <label for="labelInput" class="form-label">Mobile Number<span class="required">*</span></label>
                                                            <input type="text"  class="form-control numbersonly phone" id="mobile" name="mobile" placeholder="Mobile Number" onblur="phonenumber(this)">
                                                        </div>
                                                    </div>

                                                    <div class="col-xxl-4 col-md-6 gy-3">
                                                        <div>
                                                            <label for="labelInput" class="form-label">Email Id<span class="required">*</span></label>
                                                            <input type="email" class="form-control validateEmail"  id="email" name="email" placeholder="Email Id*">
                                                        </div>
                                                    </div>

    <!--address sec start-->

    <div class="row seperatesec">
        <div class="sectitle">
            <label for="labelInput" class="form-label">Address</label>
            </div>


            <div class="row">
                <div class="col-xxl-9 col-md-9">
                   <div class="row">
                    <div class="col-xxl-4 col-md-4">
                            <label for="labelInput" class="form-label">State <span class="required">*</span></label>
                            <div class="input-group" >
                                <select class="form-select" name="state">
                  					<option value="">Select State</option>
                  					@if(isset($states))
                                    @forelse($states as $state)
										<option value="{{$state->id}}" >{{$state->state_name}}</option>
										@empty
									@endforelse
                                    @endif

                                    </select>
                                </div>
                                </div>

								<div class="col-xxl-4 col-md-4">
                                <label for="labelInput" class="form-label">Taluka/Mandal <span class="required">*</span></label>
                                <div class="input-group">
                                    <select class="form-select" name="taluka">
										<option value="">Select Taluka/Mandal</option>
                                    @if(isset($regions))
										@forelse($regions as $region)
										<option value="{{$region->id}}" >{{$region->region_name}}</option>
										@empty
									@endforelse
                                    @endif
                                    </select>
                                </div>
                                </div>

                                <div class="col-xxl-4 col-md-4">
                                    <label for="labelInput" class="form-label">District <span class="required">*</span></label>
                                <div class="input-group">
                                    <select class="form-select" name="district">
                                    	<option value="">Select District</option>
                                        @if(isset($districts))
                                         @forelse($districts as $district)
										<option value="{{$district->id}}" >{{$district->district_name}}</option>
										@empty
									@endforelse
                                    @endif
                                    </select>
                                </div>
                                </div>

                                <div class="col-xxl-6 col-md-6 gy-3">
                                   <label for="labelInput" class="form-label">Village <span class="required">*</span></label>
		                            <div class="input-group">
		                                <select class="form-select" name="village">
		                                	<option value="">Select Village</option>
	                                        @if(isset($villages))
                                            @forelse($villages as $village)
												<option value="{{$district->id}}" >{{$village->village_name}}</option>
											@empty
											@endforelse
                                            @endif
	                                    </select>
	                                </div>
                                </div>

                    <div class="col-xxl-6 col-md-6 gy-3">
                        <div>
                            <label for="labelInput" class="form-label">Pin Code<span class="required">*</span></label>
                         <input type="text" class="form-control" id="pin_code" name="pin_code" placeholder="Pin Code">
                        </div>
                    </div>




                   </div>
                </div>


            <div class="col-xxl-3 col-md-3">
               <div class="row">
                <div class="col-xx-12 col-md-12">
                    <label for="labelInput" class="form-label ">Address <span class="required">*</span></label>
                    <textarea class="form-control customtextarea" name="address"></textarea>
                </div>
               </div>
            </div>
            </div>


        </div>
    <!--address sec end-->

    <div class="row">
        <div class="col-lg-12 gy-4">
            <div class="hstack gap-2">
                <button type="submit" class="btn btn-primary">Submit</button>
                <button type="button" class="btn btn-soft-success">Cancel</button>
            </div>
        </div>
    </div>



							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

@endsection





	@push('script')
<script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
<script type="text/javascript">


$("#commonform1").validate({
	rules: {
		// user_password: {
		// 	required: true,
		// 	minlength: 8,
		// 	maxlength: 10,
		// } ,
		mobile: {
			required: true,
		}
	},
	messages:{
		// user_password: {
		// 	required:"This field is required and should be 8 digits, contains upper,lowerCase,and a special Character"
		// },
		mobile: {
			required:"This field is required",
		}
	}

});



function CheckPassword(inputtxt){
	if(inputtxt.value.length>0){
		var decimal=  /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
		if(inputtxt.value.match(decimal)){
			return true;
		}else{
			Swal.fire('','Password should be 8 digits,contains upperCase letter,lowerCase letter,and a special Character','warning');
			$("#user_password").val('');
			return false;
		}
	}
}

function phonenumber(inputtxt){
	var phoneno=  /^\d{10}$/;
	if(inputtxt.value.match(phoneno)){
		return true;
	}else{
		Swal.fire('','Please enter a valid mobile number.','warning');
		$("#mobile").val('');
		return false;
	}
}
</script>
@php
	$salt = rand('1000','9999');
    session(['salt' => $salt]);
@endphp
<script type="text/javascript" src="{{ asset('public/backend/js/sha.js') }}"></script>
<script>
    // $(document).on('submit','#commonform1',function(){

    //     var salt = '{{ $salt }}';
    //     var secret = $('#password').val();
    //     var shaObj = new jsSHA("SHA-256", "TEXT");
    //     shaObj.update(secret);
    //     var hashPass = shaObj.getHash("HEX");
    //     $('#password').val(hashPass);


    //     var secretcurrent = $('#confirm_password').val();
    //     var shaObjcurrent = new jsSHA("SHA-256", "TEXT");
    //     shaObjcurrent.update(secretcurrent);
    //     var hashPasscurrent = shaObjcurrent.getHash("HEX");
    //     $('#confirm_password').val(hashPasscurrent);

    // });
</script>
@endpush

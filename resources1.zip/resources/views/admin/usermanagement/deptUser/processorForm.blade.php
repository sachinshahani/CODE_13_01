@extends('admin.layouts.app')
@section('content')
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Processor Form</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Processor Management</a></li>
                    <li class="breadcrumb-item active">Processor Form</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1">Processor Form</h4>
                <div class="flex-shrink-0">
                    @if (session('error'))
                    <div class="alert alert-danger">
                        {{ session('error') }}
                    </div>
                    @endif
                    @if (session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                    @endif
                    @if($errors)
                    @foreach ($errors->all() as $error)
                    <div class="alert alert-danger">{{ $error }}</div>
                    @endforeach
                    @endif
                </div>
            </div><!-- end card header -->

            <div class="card-body">
                <div class="live-preview">
                    <form action="" class="commonform1" method="POST" enctype="multipart/form-data" id="commonform1" autocomplete="off">
                        @csrf
                        <div class="row gy-4">

                            <div class="row seperatesec">

                                <div class="col-xxl-4 col-md-6">
                                    <div>
                                        <label class="form-label">Name of Processor<span class="required"> *</span></label>
                                        <input type="text" class="form-control" id="name" placeholder="Name of Processor" name="name">
                                    </div>
                                </div>

                                <div class="col-xxl-4 col-md-6">
                                    <div>
                                        <label class="form-label">Gender<span class="required"> *</span></label>
                                        <select class="form-select" name="gender">
                                            <option value="">--Select--</option>
                                            <option value="1">Male</option>
                                            <option value="2">Female</option>
                                            <option value="2">Other</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-xxl-4 col-md-12">
                                    <div>
                                        <label class="form-label">Address of Processor Office<span class="required"> *</span></label>
                                        <textarea name="address" id="" class="form-control"></textarea>
                                    </div>
                                </div>

                            </div>



                            <div class="row seperatesec">

                                <div class="col-xxl-4 col-md-4">
                                    <div>
                                        <label class="form-label">Village<span class="required"> *</span></label>
                                        <input type="text" class="form-control" id="contact_first_name" placeholder="Village" name="contact_first_name">
                                    </div>
                                </div>

                                <div class="col-xxl-4 col-md-4">
                                    <div>
                                        <label class="form-label">Taluka/Mandal<span class="required"> *</span></label>
                                        <input type="text" class="form-control" id="contact_middle_name" name="contact_middle_name" placeholder="Taluka/Mandal">
                                    </div>
                                </div>

                                <div class="col-xxl-4 col-md-4">
                                    <div>
                                        <label class="form-label">City<span class="required"> *</span></label>
                                        <select class="form-select" name="city">
                                            <option value="">--Select--</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-xxl-4 col-md-4">
                                    <div>
                                        <label for="labelInput" class="form-label">District<span class="required"> *</span></label>
                                        <select class="form-select" name="district">
                                            <option value="">--Select--</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-xxl-4 col-md-4">
                                    <div>
                                        <label for="labelInput" class="form-label">State<span class="required"> *</span></label>
                                        <select class="form-select" name="state">
                                            <option value="">--Select--</option>
                                        </select>
                                    </div>
                                </div>


                                <div class="col-xxl-4 col-md-4">
                                    <div>
                                        <label for="labelInput" class="form-label">Pin Code<span class="required"> *</span></label>
                                        <input type="text" class="form-control validateEmail" id="email" name="email" placeholder="Pin Code">
                                    </div>
                                </div>

                                <div class="col-xxl-4 col-md-4">
                                    <div>
                                        <label for="labelInput" class="form-label">Photo of Processor<span class="required"> *</span></label>
                                        <input type="file" class="filepond filepond-input-multiple" name="filepond" data-allow-reorder="true" data-max-file-size="3MB" data-max-files="3">
                                    </div>
                                </div>

                            </div>
                            <!--Self Address-->

                            <div class="row seperatesec" id="">

                                <div class="col-xxl-8 col-md-12 gy-3">
                                    <div>
                                        <label for="labelInput" class="form-label"> Name of Contact Person<span class="required"> </span></label>
                                        <div class="form-check form-check-inline">
                                            <input type="text" class="form-control" id="first_name" name="first_name" placeholder="First Name">
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input type="text" class="form-control" id="middle_name" name="middle_name" placeholder="Middle Name">
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input type="text" class="form-control" id="last_name" name="last_name" placeholder="Last Name">
                                        </div>
                                    </div>
                                </div>

                                <div class="col-xxl-4 col-md-6">
                                    <div>
                                        <label class="form-label">Gender<span class="required"> *</span></label>
                                        <select class="form-select" name="gender">
                                            <option value="">--Select--</option>
                                            <option value="1">Male</option>
                                            <option value="2">Female</option>
                                            <option value="2">Other</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-xxl-8 col-md-12">
                                    <div>
                                        <label class="form-label">Address of Contact Person<span class="required"> </span></label>
                                        <textarea name="" id="" class="form-control"></textarea>
                                    </div>
                                </div>

                                <div class="col-xxl-4 col-md-4">
                                    <div>
                                        <label class="form-label">Village<span class="required"> </span></label>
                                        <input type="text" class="form-control" id="village" name="village" placeholder="Village">
                                    </div>
                                </div>

                                <div class="col-xxl-4 col-md-4">
                                    <div>
                                        <label class="form-label">Taluka/Mandal<span class="required"> </span></label>
                                        <input type="text" class="form-control" id="village" name="village" placeholder="Taluka/Mandal">
                                    </div>
                                </div>

                                <div class="col-xxl-4 col-md-4">
                                    <div>
                                        <label class="form-label">City<span class="required"> </span></label>
                                        <select class="form-select" name="city">
                                            <option value="">--Select--</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-xxl-4 col-md-4">
                                    <div>
                                        <label for="labelInput" class="form-label">District<span class="required"> </span></label>
                                        <select class="form-select" name="district">
                                            <option value="">--Select--</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-xxl-4 col-md-4">
                                    <div>
                                        <label for="labelInput" class="form-label">State<span class="required"> </span></label>
                                        <select class="form-select" name="state">
                                            <option value="">--Select--</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-xxl-4 col-md-4">
                                    <div>
                                        <label class="form-label">Pin Code<span class="required"> </span></label>
                                        <input type="text" class="form-control" id="village" name="state" placeholder="Pin Code">
                                    </div>
                                </div>
                                <div class="col-xxl-4 col-md-4">
                                    <div>
                                        <label class="form-label">Mobile Number<span class="required"> </span></label>
                                        <input type="number" class="form-control" id="contact_detail" name="contact_detail" placeholder="Mobile Number">
                                    </div>
                                </div>

                                <div class="col-xxl-4 col-md-4">
                                    <div>
                                        <label class="form-label">Email Id<span class="required"> </span></label>
                                        <input type="text" class="form-control" id="email_id" name="email_id" placeholder="Email ID">
                                    </div>
                                </div>

                                <div class="col-xxl-4 col-md-4">
                                    <div>
                                        <label class="form-label">PAN Number<span class="required"> </span></label>
                                        <input type="text" class="form-control" name="" placeholder="PAN Number">
                                    </div>
                                </div>

                                <div class="col-xxl-4 col-md-4">
                                    <div>
                                        <label class="form-label">Aadhar Number<span class="required"> </span></label>
                                        <input type="text" class="form-control" name="" placeholder="Aadhar Number">
                                    </div>
                                </div>

                                <div class="col-xxl-4 col-md-4">
                                    <div>
                                        <label class="form-label">Bank Name<span class="required"> </span></label>
                                        <input type="text" class="form-control" name="" placeholder="Bank Name">
                                    </div>
                                </div>

                                <div class="col-xxl-4 col-md-4">
                                    <div>
                                        <label class="form-label">Account Number<span class="required"> </span></label>
                                        <input type="text" class="form-control" name="" placeholder="Account Number">
                                    </div>
                                </div>

                                <div class="col-xxl-4 col-md-4">
                                    <div>
                                        <label class="form-label">IFSC Code<span class="required"> </span></label>
                                        <input type="text" class="form-control" name="" placeholder="IFSC Code">
                                    </div>
                                </div>

                                <div class="col-xxl-4 col-md-4">
                                    <div>
                                        <label class="form-label">Branch Name<span class="required"> </span></label>
                                        <input type="text" class="form-control" name="" placeholder="Branch Name">
                                    </div>
                                </div>

                                <div class="col-xxl-4 col-md-12">
                                    <div>
                                        <label class="form-label">Address<span class="required"> </span></label>
                                        <textarea name="" id="" class="form-control"></textarea>
                                    </div>
                                </div>

                                <div class="col-xxl-4 col-md-4">
                                    <div>
                                        <label class="form-label">Pin Code<span class="required"> </span></label>
                                        <input type="text" class="form-control" name="" placeholder="Pin Code">
                                    </div>
                                </div>
                                <div class="col-xxl-4 col-md-4">
                                    <div>
                                        <label class="form-label">Contact Person Photo<span class="required"> </span></label>
                                        <input type="file" class="filepond filepond-input-multiple" name="filepond" data-allow-reorder="true" data-max-file-size="3MB" data-max-files="3">
                                    </div>
                                </div>

                            </div>

                            <!--- End Self Address --->

                            <!-- Dropzon-preview -->
                            <div class="dropzone">

                            </div>

                            <ul class="list-unstyled mb-0" id="dropzone-preview">
                                <li class="mt-2" id="dropzone-preview-list">
                                    <!-- This is used as the file preview template -->
                                    <div class="border rounded">
                                        <div class="d-flex p-2">
                                            <div class="flex-shrink-0 me-3">
                                                <div class="avatar-sm bg-light rounded">
                                                    <img data-dz-thumbnail class="img-fluid rounded d-block" src="#" alt="Dropzone-Image" />
                                                </div>
                                            </div>
                                            <div class="flex-grow-1">
                                                <div class="pt-1">
                                                    <h5 class="fs-14 mb-1" data-dz-name>&nbsp;</h5>
                                                    <p class="fs-13 text-muted mb-0" data-dz-size></p>
                                                    <strong class="error text-danger" data-dz-errormessage></strong>
                                                </div>
                                            </div>
                                            <div class="flex-shrink-0 ms-3">
                                                <button data-dz-remove class="btn btn-sm btn-danger">Delete</button>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                            <!-- end dropzon-preview -->

                            <div class="row">
                                <div class="col-lg-12 gy-4">
                                    <div class="hstack gap-2">
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                        <button type="button" class="btn btn-soft-success">Cancel</button>
                                    </div>
                                </div>
                            </div>


                        </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

@endsection





@push('script')
<script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
<script>
    $("#selfDetail").show();
    $("#mandatorDetail").hide();
    $(document).on('change', '#manageBySelf', function() {
        $("#selfDetail").show();
        $("#mandatorDetail").hide();
    });
    $(document).on('change', '#manageByMandator', function() {
        $("#selfDetail").hide();
        $("#mandatorDetail").show();
    });
</script>
<script type="text/javascript">
    $("#commonform1").validate({
        rules: {
            // user_password: { 
            // 	required: true,
            // 	minlength: 8,
            // 	maxlength: 10,
            // } ,
            mobile: {
                required: true,
            }
        },
        messages: {
            // user_password: { 
            // 	required:"This field is required and should be 8 digits, contains upper,lowerCase,and a special Character"   
            // },
            mobile: {
                required: "This field is required",
            }
        }

    });



    function CheckPassword(inputtxt) {
        if (inputtxt.value.length > 0) {
            var decimal = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
            if (inputtxt.value.match(decimal)) {
                return true;
            } else {
                Swal.fire('', 'Password should be 8 digits,contains upperCase letter,lowerCase letter,and a special Character', 'warning');
                $("#user_password").val('');
                return false;
            }
        }
    }

    function phonenumber(inputtxt) {
        var phoneno = /^\d{10}$/;
        if (inputtxt.value.match(phoneno)) {
            return true;
        } else {
            Swal.fire('', 'Please enter a valid mobile number.', 'warning');
            $("#mobile").val('');
            return false;
        }
    }
</script>
@php
$salt = rand('1000','9999');
session(['salt' => $salt]);
@endphp
<script type="text/javascript" src="{{ asset('public/backend/js/sha.js') }}"></script>
<script>
    // $(document).on('submit','#commonform1',function(){

    //     var salt = '{{ $salt }}';
    //     var secret = $('#password').val();
    //     var shaObj = new jsSHA("SHA-256", "TEXT");
    //     shaObj.update(secret);
    //     var hashPass = shaObj.getHash("HEX");
    //     $('#password').val(hashPass);


    //     var secretcurrent = $('#confirm_password').val();
    //     var shaObjcurrent = new jsSHA("SHA-256", "TEXT");
    //     shaObjcurrent.update(secretcurrent);
    //     var hashPasscurrent = shaObjcurrent.getHash("HEX");
    //     $('#confirm_password').val(hashPasscurrent);

    // });
</script>
@endpush
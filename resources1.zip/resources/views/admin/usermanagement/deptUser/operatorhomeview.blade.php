@extends('admin.layouts.app')
@section('content')
    <style>
        .overlay {
            background: rgb(0 0 0 / 50%);
            position: fixed;
            top: 0;
            z-index: 11111;
            left: 0;
            right: 0;
            bottom: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            display: none;
        }

        .loader {
            position: fixed !important;
            left: 50% !important;
            margin-left: -4em !important;
            top: 20em !important;
        }
    </style>
    <div class="overlay">
        <div class="loader"></div>
    </div>
    <div class="row seperatesec white-inner">
        <div class="col-12">
            <h3>Review Online Application</h3>
        </div>

        <div class="col-12 mt-4">
            <h4>Operator Details</h4>
        </div>
        <div class="col-xxl-3">
            <div>
                <label class="form-label">Legal Document<span class="required">*</span></label>
                <select class="form-select" name="document_type" id="document_type" disabled>
                    <option value="">select</option>
                    <option value="PAN" {{ $data->document_type == 'PAN' ? 'selected' : '' }}>PAN</option>
                </select>
            </div>
        </div>
        <div class="col-xxl-3 mb-4">
            <input type="hidden" name="standerd_type" value="Crop_Production">
            <div>
                <label for="operator_type_id" class="form-label">Operator Type<span class="required">*</span></label>

                <input type="text" class="form-control"
                    Value="{{ getOperatorTypeById($data->ref_operator_type_id ?? '') }}" disabled>

            </div>
        </div>
        <div class="col-xxl-3">
            <div>
                <label class="form-label">Legal Entity Type <span class="required">*</span></label>
                <select name="entity_firm" id="entity_firm" class="form-select" disabled>
                    <option value="">--Select Entity--</option>
                    @if ($data->ref_operator_type_id == 2)
                        <option value="Registered Society" data-docType="NA"
                            title="Society registered under the Societies Registration Act, 1860 or relevant State Societies Act/Rules"
                            {{ $data->entity_firm == 'Registered Society' ? 'selected' : '' }}>
                            Registered Society
                        </option>
                        <option value="FPO/FPC" data-docType="NA"
                            title="Farmers Producer Organization (FPO)/Farmers Producer Company (FPC) incorporated under the Companies Act, 2013, as amended from time to time"
                            {{ $data->entity_firm == 'FPO/FPC' ? 'selected' : '' }}>
                            FPO/FPC</option>
                        <option value="Co-operative society/PACs/FPO" data-docType="NA"
                            title=" Co-operative society, including Primary Agricultural Co-operative Societies (PACs) and Farmers Producer Organization (FPO), registered under the relevant state Co-operative Societies Act/Rules"
                            {{ $data->entity_firm == 'Co-operative society/PACs/FPO' ? 'selected' : '' }}>
                            Co-operative society/PACs/FPO</option>
                    @elseif($data->ref_operator_type_id == 3)
                        <option value="Indian Companies Act" data-docType="NA"
                            {{ $data->entity_firm == 'Indian Companies Act' ? 'selected' : '' }}>
                            Indian Companies Act</option>
                        <option value="Propietor" data-docType="Y"
                            {{ $data->entity_firm == 'Propietor' ? 'selected' : '' }}>Propietor
                        </option>
                    @elseif($data->ref_operator_type_id == 4)
                        <option value="Indian Companies Act" data-docType="NA"
                            {{ $data->entity_firm == 'Indian Companies Act' ? 'selected' : '' }}>
                            Indian Companies Act</option>
                    @elseif($data->ref_operator_type_id == 5)
                        <option value="Indian Companies Act" data-docType="NA"
                            {{ $data->entity_firm == 'Indian Companies Act' ? 'selected' : '' }}>
                            Indian Companies Act</option>
                    @elseif($data->ref_operator_type_id == 6)
                        <option value="Indian Companies Act" data-docType="NA"
                            {{ $data->entity_firm == 'Indian Companies Act' ? 'selected' : '' }}>
                            Indian Companies Act</option>
                    @endif
                </select>
            </div>
            <div class="mt-1" id="panName_response"></div>
        </div>
        <div class="col-xxl-3">
            <div>
                <label class="form-label">Operator Name<span class="required">*</span></label>
                <input type="text" class="form-control" id="first_name" name="first_name"
                    value="{{ $data->first_name ?? '' }}" disabled>
            </div>
            <div class="mt-1" id="panName_response"></div>
        </div>
        <div class="col-xxl-3">
            <div>
                <label class="form-label">Date of Birth/जन्म तिथि (As per Pan)<span class="required">*</span></label>
                <input type="date" class="form-control" id="dob_doi_date" name="dob_doi_date" required
                    value="{{ old('dob_doi_date', isset($data->dob_doi_date) ? \Carbon\Carbon::parse($data->dob_doi_date)->format('Y-m-d') : '') }}"
                    max="{{ now()->format('Y-m-d') }}" disabled>

            </div>
            <div class="mt-1" id="panDob_response"></div>
        </div>
        @if ($data->ref_operator_type_id == 3 || $data->entity_firm == 'Propietor')
            <div class="col-xxl-3">
                <div class="mb-2">
                    <label class="form-label">Father Name<span class="form-text">(As per PAN)</span>
                        <span class="required">*</span></label>
                    <input type="text" class="form-control" id="father_name" placeholder="Father Name" name="father_name"
                        value="{{ $data->father_name }}" disabled>
                </div>
                <div class="mt-1" id="fatherName_response"></div>
            </div>
        @endif
        <div class="col-xxl-3 ">
            <div>
                <label class="form-label">PAN Number/पैन संख्या<span class="required">*</span></label>
                <input type="text" class="form-control" id="user_name" name="user_name"
                    value="{{ $data->user_name ?? '' }}" maxlength="10" disabled>
            </div>
            <div class="mt-1" id="panNumber_response"></div>
            <div class="text-end mt-2"><button type="button" id="panVerificationForm"
                    class="btn btn-sm btn-success fs-13 text-decoration-underline">Verfiy Pan</button></div>
        </div>

        <!-- Address Section -->
        <div class="col-xxl-3 ">
            <div>
                <label for="address" class="form-label">Address <span class="required">*</span></label>
                <textarea class="form-control customtextarea" name="address" required maxlength="200" style="height: 50px;"
                    disabled>{{ $data->address ?? '' }}</textarea>
            </div>
        </div>

        <div class="col-xxl-3 mt-4">
            <div>
                <label for="pin" class="form-label">Pin Code <span class="required">*</span></label>
                <input type="text" class="form-control numbersonly" id="pin" required name="pin"
                    placeholder="Pin Code" maxlength="6" value="{{ $data->pin ?? '' }}" disabled>
            </div>
        </div>


        <div class="col-xxl-3 mt-4">
            <div>

                <label for="stateID" class="form-label">State <span class="required">*</span></label>
                <input type="text" class="form-control numbersonly" id="pin" required name="pin"
                    placeholder="Pin Code" maxlength="6" value="{{ getStateNameById($data->ref_state_id ?? '') }}"
                    disabled>
            </div>

        </div>

        <div class="col-xxl-3 mt-4">

            <div>

                <label for="district" class="form-label">District <span class="required">*</span></label>
                <input type="text" class="form-control numbersonly" id="pin" required name="pin"
                    placeholder="Pin Code" maxlength="6"
                    value="{{ getDistrictNameById($data->ref_district_id ?? '') }}" disabled>
            </div>

        </div>


        <div class="col-xxl-3 mt-4">
            <div>
                <label for="block_tehsil" class="form-label">Taluka/Mandal <span class="required">*</span></label>
                <input type="text" class="form-control numbersonly" id="pin" required name="pin"
                    placeholder="Pin Code" maxlength="6"
                    value="{{ getBlockTehsilByID($data->ref_block_tehsil_id ?? '') }}" disabled>
            </div>

        </div>

        <div class="col-xxl-3 mt-4">

            <div>
                <label for="village" class="form-label">Village <span class="required">*</span></label>
                <input type="text" class="form-control numbersonly" id="pin" required name="pin"
                    placeholder="Pin Code" maxlength="6" value="{{ getVillageNameById($data->ref_village_id ?? '') }}"
                    disabled>
            </div>

        </div>



        <div class="col-12 mt-4">
            <h4>Contact Person Details</h4>
        </div>

        <div class="col-xxl-3 mt-4">
            <div>
                <label class="form-label">Contact Person First Name<span class="required">*</span></label>
                <input type="text" class="form-control textonly" id="contact_person_first_name" required
                    name="contact_person_first_name" value="{{ $data->contact_person_first_name ?? '' }}" disabled>
            </div>
        </div>

        <div class="col-xxl-3 mt-4">
            <div>
                <label class="form-label">Contact Person Middle Name</label>
                <input type="text" class="form-control textonly" id="contact_person_middle_name"
                    name="contact_person_middle_name" value="{{ $data->contact_person_middle_name ?? '' }}" disabled>
            </div>
        </div>

        <div class="col-xxl-3 mt-4">
            <div>
                <label class="form-label">Contact Person Last Name<span class="required">*</span></label>
                <input type="text" class="form-control textonly" id="contact_person_last_name" required
                    name="contact_person_last_name" value="{{ $data->contact_person_last_name ?? '' }}" disabled>
            </div>
        </div>

        <div class="col-xxl-3 mt-4">
            <div>
                <label for="contact_person_gender" class="form-label">Gender</label>
                <input type="text" class="form-control textonly" id="contact_person_last_name" required
                    name="contact_person_last_name" value="{{ getGenderNameByID($data->contact_person_gender ?? '') }}"
                    disabled>
            </div>
        </div>

        <div class="col-xxl-3 mt-4">
            <div>
                <label for="contact_person_email" class="form-label">Contact Person Email Id<span
                        class="required">*</span></label>
                <input type="text" class="form-control textonly" id="contact_person_last_name" required
                    name="contact_person_last_name" value="{{ $data->contact_person_email ?? '' }}" disabled>
            </div>
        </div>

        <div class="col-xxl-3 mt-4">
            <div>
                <label for="contact_person_mobile_number" class="form-label">Contact Person Mobile Number<span
                        class="required">*</span></label>
                <input type="text" class="form-control textonly" id="contact_person_last_name" required
                    name="" value="{{ $data->contact_person_mobile_number ?? '' }}" disabled>
            </div>
        </div>

        @php
            $addhar = $data->contact_person_aadhar_number;

            if (preg_match('/^eyJpdiI6.*$/', $addhar)) {
                try {
                    $addhar = Crypt::decrypt($addhar);
                } catch (DecryptException $e) {
                    $addhar = 'Invalid Aadhar No';
                }
            }
        @endphp

        <div class="col-xxl-3 mt-4">
            <div>
                <label for="contact_person_aadhar_number" class="form-label">Contact Person Aadhar Number</label>
                <input type="text" class="form-control textonly" id="contact_person_last_name" required
                    name="contact_person_last_name" value="{{ maskAadhaarNumber($addhar) }}" disabled>
            </div>
        </div>

        @if ($data->status !== 2)
            <!-- Check if status is not Approved -->
            <form method="post" action="{{ route('superadmin.usermanagement.deptUser.previewpost') }}">
                @csrf

                <input type="hidden" name="at_user_id" id="at_user_id" value="{{ $data->id }}">
                <input type="hidden" name="id" id="role_id" value="{{ $data->ref_operator_type_id }}">
                <input type="hidden" name="user_id" id="user_id" value="{{ $cbId }}">
                <input type="hidden" name="registration_form" id="registration_form" value="client_registration">
                @if ($data->ref_operator_type_id == 2)
                    <input type="hidden" name="detailType" id="detailType" value="OG">
                @else
                    <input type="hidden" name="detailType" id="detailType" value="IN">
                @endif
                <input type="hidden" name="panNumberResponse" id="panNumberResponse" value="">
                <input type="hidden" name="panNameResponse" id="panNameResponse" value="">
                <input type="hidden" name="panDobResponse" id="panDobResponse" value="">
                <!-- Remarks Section -->
                <div class="col-3 mt-4">
                    <h4>Remarks</h4>
                    <textarea class="form-control" name="remarks" id="remarks" rows="3" placeholder="Add remarks here..."></textarea>
                </div>

                <!-- Action Buttons -->
                <div class="col-xxl-3 col-md-4 gy-4">
                    <div>
                        <label for="basiInput" class="form-label">Status<span class="required">*</span></label>
                        <select class="form-select" name="status" required>
                            <option value="">-Select-</option>
                            <option value="2" {{ $data->status == 2 ? 'selected' : '' }}>Accepted</option>
                            <!-- <option value="4" {{ $data->status == 4 ? 'selected' : '' }}>Review</option> -->
                            <option value="3" {{ $data->status == 3 ? 'selected' : '' }}>Rejected</option>
                        </select>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xxl-4 col-md-4 gy-4">
                        <div class="hstack gap-2">
                            <button type="submit" id="submitbtn"
                                class="btn btn-primary submit-button w-50">Submit</button>
                        </div>
                    </div>
                </div>
            </form>
        @endif




    </div>
@endsection
@push('script')
    <script type="text/javascript">
        $('#panVerificationForm').on('click', function(event) {
            event.preventDefault();

            const documentVType = $('#document_type').find('option:selected').val();
            const doctype = $('#entity_firm').find('option:selected').data('doctype');
            const legalEntityType = $('#entity_firm').find('option:selected').val();

            // Reset validation classes
            if (documentVType === 'PAN') {
                if (doctype === 'Y') {
                    $('#detailType').val('IN');
                    $('#name, #dob_doi_date, #father_name, #operator_pan, #entity_firm, #document_type')
                        .removeClass('is-invalid is-valid');
                } else {
                    $('#detailType').val('OG');
                    $('#name, #dob_doi_date, #operator_pan, #entity_firm, #document_type').removeClass(
                        'is-invalid is-valid');
                }
            }

            // Clear responses
            $('#panName_response, #panDob_response, #panNumber_response').html('');
            $('#panNumberResponse, #panNameResponse, #panDobResponse').val('');

            // $('#first_name, #dob_doi_date, #user_name').removeClass('is-invalid is-valid');
            // $('#panName_response, #panDob_response, #panNumber_response').html('');
            // $('#panNumberResponse, #panNameResponse, #panDobResponse').val('');

            $('select[name="status"] option[value="2"]').prop('disabled', false);
            // Form input values
            const name = $('#first_name').val();
            const dob = $('#dob_doi_date').val();
            const pan = $('#user_name').val();
            const type = $('#detailType').val();
            const userId = $('#user_id').val();
            const atUserId = $('#at_user_id').val();
            const registrationForm = $('#registration_form').val();
            const registrationId = $('#role_id').val();
            const fatherName = $('#father_name').val();

            // Validate inputs
            let validationErrors = [];
            if (!name || !/^[a-zA-Z\s]+$/.test(name)) {
                validationErrors.push("Name is required and should only contain alphabetic characters.");
                $('#first_name').addClass('is-invalid');
            }

            if (!dob || new Date(dob) > new Date()) {
                validationErrors.push("Date of Birth is required and must be a past date.");
                $('#dob_doi_date').addClass('is-invalid');
            }

            const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
            if (!pan || !panRegex.test(pan)) {
                validationErrors.push("PAN Number is required and must be in the format (AAAAA1234A).");
                $('#user_name').addClass('is-invalid');
            }

            if (validationErrors.length > 0) {
                Swal.fire({
                    title: "Validation Error",
                    html: validationErrors.join('<br>'),
                    icon: 'warning',
                    confirmButtonText: 'OK'
                });
                return;
            }

            // Prepare form data
            const formData = {
                pan: pan,
                name: name,
                dob: dob,
                type: type,
                user: userId,
                registrationId: registrationId,
                registrationForm: registrationForm,
                fatherName: fatherName,
                legalEntityType: legalEntityType,
                doctype: doctype,
                atUserId:atUserId
            };
            //console.log(formData);
            const encryptedData = btoa(JSON.stringify(formData));

            // AJAX request
            $.ajax({
                url: '/api/validate-pan-v1',
                type: 'POST',
                contentType: 'application/json',
                dataType: 'json',
                data: JSON.stringify({
                    data: encryptedData
                }),
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                beforeSend: function() {
                    $(".overlay").css({
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        position: 'fixed',
                        top: 0,
                        left: 0,
                        right: 0,
                        bottom: 0,
                        backgroundColor: 'rgba(0, 0, 0, 0.5)',
                        zIndex: 1000
                    }).html(`
                        <div style="text-align: center;">
                            <div class="spinner-border" role="status" style="width: 3rem; height: 3rem;">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                            <div style="color: white; margin-top: 10px;">Please wait...</div>
                        </div>
                    `);
                },
                success: function(response) {
                    $(".overlay").hide();

                    const data = JSON.parse(atob(response.data));
                    //console.log(data);
                    $('#panNumberResponse').val(data.outputData.pan_status);
                    $('#panNameResponse').val(data.outputData.name);
                    $('#panDobResponse').val(data.outputData.dob);

                    // const panStatusClass = data.outputData.pan_status === 'E' ? 'text-success' :
                    //     'text-danger';
                    // const nameStatusClass = data.outputData.name === 'Y' ? 'text-success' :
                    //     'text-danger';
                    // const dobStatusClass = data.outputData.dob === 'Y' ? 'text-success' : 'text-danger';

                    const panStatusClass = data.outputData.pan_status === 'E' ? 'text-success' :
                        'text-danger';
                    const nameStatusClass = data.outputData.name === 'Y' ? 'text-success' :
                        'text-danger';
                    const dobStatusClass = data.outputData.dob === 'Y' ? 'text-success' : 'text-danger';
                    const swalTitleClass = data.outputData.name === 'Y' && data.outputData.dob ===
                        'Y' && data.outputData.pan_status === 'E' ? 'text-success' : 'text-warning';

                    const detailsHtml = `
                            <ul class="text-start">
                                <li><strong>Name Message:</strong> <span class="${nameStatusClass}">${data.outputData.name_message}</span></li>
                                <li><strong>PAN Status Message:</strong> 
                                    <span class="${panStatusClass}">${data.outputData.pan_status_message}</span>
                                </li>
                                <li><strong>${data.outputData.seeding_status === 'NA' ? 'Date of Incorporation' : 'Date of Birth'}:</strong>
                                    <span class="${dobStatusClass}">${data.outputData.dob_message || 'N/A'}</span>
                                </li>
                            </ul>
                        `;

                    // // Handle PAN status conditions
                    // if (data.outputData.pan_status === 'E') {
                    //     Swal.fire({
                    //         title: "Success",
                    //         text: data.message,
                    //         html: detailsHtml,
                    //         icon: 'success',
                    //         confirmButtonText: 'OK'
                    //     });
                    //     $('#user_name').addClass('is-valid');
                    // } else if (data.outputData.pan_status === 'F' || data.outputData.pan_status ===
                    //     'X') {
                    //     Swal.fire({
                    //         title: "Error",
                    //         text: data.outputData.pan_status_message,
                    //         icon: 'error',
                    //         confirmButtonText: 'OK'
                    //     });
                    //     $('#user_name').addClass('is-invalid');
                    //     $('select[name="status"] option[value="2"]').prop('disabled', true);
                    // } else {
                    //     Swal.fire({
                    //         title: "Warning",
                    //         text: "Unexpected response.",
                    //         html: detailsHtml,
                    //         icon: 'warning',
                    //         confirmButtonText: 'OK'
                    //     });
                    //     $('select[name="status"] option[value="2"]').prop('disabled', true);
                    // }

                    // // Update name validation response
                    // if (data.outputData.name === 'Y') {
                    //     $('#panName_response').html(data.outputData.name_message)
                    //         .removeClass('text-danger').addClass('text-success');
                    //     $('#first_name').addClass('is-valid');
                    //     //} else if (data.outputData.name === 'N') {
                    // } else {
                    //     $('#panName_response').html(data.outputData.name_message)
                    //         .addClass('text-danger').removeClass('text-success');
                    //     $('#first_name').addClass('is-invalid');
                    // }

                    // // Update DOB validation response
                    // if (data.outputData.dob === 'Y') {
                    //     $('#panDob_response').html(data.outputData.dob_message)
                    //         .removeClass('text-danger').addClass('text-success');
                    //     $('#dob_doi_date').addClass('is-valid');
                    //     //} else if (data.outputData.dob === 'N') {
                    // } else {
                    //     $('#panDob_response').html(data.outputData.dob_message)
                    //         .addClass('text-danger').removeClass('text-success');
                    //     $('#dob_doi_date').addClass('is-invalid');
                    // }

                    // // Update PAN Number validation response
                    // if (data.outputData.pan_status === 'E') {
                    //     $('#panNumber_response').html(data.outputData.pan_status_message)
                    //         .removeClass('text-danger').addClass('text-success');
                    //     $('#user_name').addClass('is-valid');
                    // } else {
                    //     $('#panNumber_response').html(data.outputData.pan_status_message)
                    //         .addClass('text-danger').removeClass('text-success');
                    //     $('#user_name').addClass('is-invalid');
                    // }
                    if (data.outputData.seeding_status === 'Y' && doctype === 'Y') {
                        if (data.outputData.name === 'Y' && data.outputData.dob === 'Y' && data
                            .outputData.pan_status === 'E') {
                            Swal.fire({
                                title: `<span class="${swalTitleClass}">This PAN card belongs to an individual user account and has been successfully verified.</span>`,
                                text: data.message,
                                html: detailsHtml,
                                icon: 'success',
                                confirmButtonText: 'OK'
                            });
                        } else {

                            Swal.fire({
                                title: `<span class="text-danger">Verification Failed</span>`,
                                text: "Name and Date of Birth do not match the records. Please check the details and try again.",
                                html: detailsHtml,
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        }
                        $('#panVerifyResponse').val(data.outputData.name === 'Y' && data.outputData
                            .dob === 'Y' ? 'S' : 'F');
                    } else if (data.outputData.seeding_status === 'NA' && doctype === 'NA') {
                        if (data.outputData.name === 'N' || data.outputData.dob === 'N') {
                            Swal.fire({
                                title: `<span class="text-danger">Verification Failed</span>`,
                                text: "Name and Date of Incorporation do not match the records. Please verify the details.",
                                html: detailsHtml,
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        } else {
                            Swal.fire({
                                title: `<span class="${swalTitleClass}">This PAN card belongs to a company or organization account and has been successfully verified.</span>`,
                                text: data.message,
                                html: detailsHtml,
                                icon: 'success',
                                confirmButtonText: 'OK'
                            });
                        }
                        $('#panVerifyResponse').val(data.outputData.name === 'Y' && data.outputData
                            .dob === 'Y' ? 'S' : 'F');
                    } else if (doctype === 'NA' || data.outputData.seeding_status !== 'Y') {
                        Swal.fire({
                            title: "Warning",
                            text: "This PAN card belongs to an individual user and cannot be used for registration.",
                            icon: 'warning',
                            confirmButtonText: 'OK'
                        });
                        $('#panVerifyResponse').val('F');
                    } else {
                        Swal.fire({
                            title: "Unexpected Response",
                            text: "Unexpected response received from the server.",
                            icon: 'warning',
                            confirmButtonText: 'OK'
                        });
                    }
                    // Update field validations
                    if (data.outputData.seeding_status === doctype) {
                        if (data.outputData.name === 'Y') {
                            $('#panName_response').html(data.outputData.name_message)
                                .removeClass('text-danger text-warning').addClass('text-success');
                            $('#name').addClass('is-valid');
                        } else if (data.outputData.name === 'N') {
                            $('#panName_response').html(data.outputData.name_message)
                                .addClass('text-danger').removeClass('text-success');
                            $('#name').addClass('is-invalid');
                        }
                        if (data.outputData.dob === 'Y') {
                            $('#panDob_response').html(data.outputData.dob_message)
                                .removeClass('text-danger text-warning').addClass('text-success');
                            $('#dob_doi_date').addClass('is-valid');
                        } else if (data.outputData.dob === 'N') {
                            $('#panDob_response').html(data.outputData.dob_message)
                                .addClass('text-danger').removeClass('text-success');
                            $('#dob_doi_date').addClass('is-invalid');
                        }
                        if (data.outputData.pan_status === 'E') {
                            $('#panNumber_response').html(data.outputData.pan_status_message)
                                .removeClass('text-danger text-warning').addClass('text-success');
                            $('#operator_pan').addClass('is-valid');
                        } else {
                            $('#panNumber_response').html(data.outputData.pan_status_message)
                                .addClass('text-danger').removeClass('text-success');
                            $('#operator_pan').addClass('is-invalid');
                        }
                    } else {
                        $('#name, #dob_doi_date, #operator_pan').addClass('is-invalid');
                        $('#panNumber_response').html('Invalid PAN for this account type.')
                            .addClass('text-danger').removeClass('text-success');
                        $('#panName_response').html('Invalid Name for this account type.')
                            .addClass('text-danger').removeClass('text-success');
                        $('#panDob_response').html('Invalid DOB/DOI for this account type.')
                            .addClass('text-danger').removeClass('text-success');
                    }

                },
                error: function(xhr) {
                    $(".overlay").hide();
                    let errorMessage = "An unexpected error occurred.";
                    // if (xhr.responseJSON && xhr.responseJSON.message) {
                    //     errorMessage = xhr.responseJSON.message;
                    // }

                    Swal.fire({
                        title: 'An API error has occurred.',
                        text: 'Please reload your browser or revalidate the PAN',
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                }
            });
        });
    </script>
@endpush

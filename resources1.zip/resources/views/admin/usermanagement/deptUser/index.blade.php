@extends('admin.layouts.app')

@section('content')
<style>
.remaining-time {
    font-weight: bold;
    color: green; /* Green color for remaining time */
}

.remaining-time.expired {
    color: red; /* Red color when expired */
}
</style>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                @php
                    $tit = '';
                    $ids = request()->segment(count(request()->segments()));
                    if ($ids == 2) {
                        $tit = 'Grower Group';
                    } elseif ($ids == 3) {
                        $tit = 'Individual Producer';
                    } elseif ($ids == 4) {
                        $tit = 'Wild Harvester';
                    } elseif ($ids == 5) {
                        $tit = 'Trader';
                    } elseif ($ids == 6) {
                        $tit = 'Processor';
                    } else {
                        $tit = '';
                    }

                @endphp
                <h4 class="mb-sm-0">
                    @if (isset(auth()->user()->ref_operator_type_id) && auth()->user()->ref_operator_type_id != 1)
                        My Details
                    @else
                        Operators
                    @endif
                </h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);"></a></li>
                        <li class="breadcrumb-item active">
                            @if (isset(auth()->user()->ref_operator_type_id) && auth()->user()->ref_operator_type_id != 1)
                                My Details
                            @else
                                Operators
                            @endif
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>

    <div class="col-md-12 mt-2">
        @if (session('success'))
            <div class="alert alert-success" id="validate">
                {{ session('success') }}
            </div>
        @endif

        @if (session('importErrors'))
            <div class="alert alert-danger">
                <p>Following Errors Occured While Uploading the list, Please fix and upload again</p>
                <ul>
                    @foreach (session('importErrors') as $failure)
                        @foreach ($failure->errors() as $f)
                            <li>{{ $f . ' at row ' . $failure->row() }}</li>
                        @endforeach
                    @endforeach
                </ul>
            </div>
        @endif
    </div>

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0" style="float: left">
                        @if (isset(auth()->user()->ref_operator_type_id) && auth()->user()->ref_operator_type_id != 1)
                            My Details
                        @else
                            {{ $tit }} List
                        @endif
                    </h5>

                    <div class="row justify-content-end ">
                        <div class="col-12 col-md-5 col-lg-3 col-xl-3 text-right mb-2">
                            <select class="form-select" name="status" id="search" data-label-msg="Status" required>
                                <option value="">Select status</option>
                                <option value="all">All</option>
                                <option value="0">Profile Incomplete</option>
                                <option value="1">Profile Completed</option>
                                <option value="2">Approved</option>
                                <option value="3">Rejected</option>
                            </select>
                        </div>
                        {{-- <div class="col-1">
                            <button class="btn btn-primary" type="button" id="filter"> Submit </button>
                        </div> --}}
                        <div class="col-12 col-md-4 col-lg-3 col-xl-2 mb-2">
                            @if (Auth::guard('misadmin')->user()->roles[0]->id == 1)
                                <a href="{{ route('superadmin.usermanagement.deptUser.add', $id) }}" class="btn btn-primary w-100"
                                    style="float: right">Add Operator</a>
                            @endif

                            <!-- Add Excel and PDF download buttons here -->
                            <!-- <a href="{{ route('superadmin.usermanagement.export', ['id' => $id, 'type' => 'pdf']) }}" class="btn btn-danger" style="float: right; margin-right: 10px;">PDF</a>
                            <a href="{{ route('superadmin.usermanagement.export', ['id' => $id, 'type' => 'excel']) }}" class="btn btn-success" style="float: right; margin-right: 10px;">Excel</a> -->

                        </div>
                    </div>

                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="deptUser" class="table table-bordered table-striped align-middle" style="width:100%">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Application Details</th>
                                    <th>Registration Details</th>
                                    <th>Operator Details</th>
                                    <!-- <th>Date Of Registration</th> -->
                                    <th>Contact Person Details</th>
                                    <!-- <th>State</th> -->
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!--end col-->
    </div>
    <!--end row-->

@endsection



@push('script')
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        var table = $('#deptUser').DataTable({
            //dom: 'l<"clear">Bfrtip',
            dom: 'Bfrtip',
            pageLength: 25,

            //dom:'Blfrtip',
            lengthMenu: [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
            ],
            processing: true,
            serverSide: true,
            ajax: {
                url: '{{ route('superadmin.usermanagement.deptUser', $ids) }}',
                type: 'GET',
                data: function(d) {
                    d._token = "{{ csrf_token() }}";
                    d.status = $("#search").val();
                }

            },
            columns: [{
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex',
                    orderable: true
                },
                {
                    data: 'application_no',
                    name: 'application_no',
                    orderable: true
                },
                {
                    data: 'reg_no',
                    name: 'reg_no',
                    orderable: true
                },
                
                {
                    data: 'name',
                    name: 'name',
                    orderable: true
                },
                // {
                //     data: 'created_on',
                //     name: 'created_on',
                //     orderable: true
                // },


                {
                    data: 'contact_details',
                    name: 'contact_details',
                    orderable: true
                },
                // {
                //     data: 'mobile',
                //     name: 'mobile',
                //     orderable: true
                // },

                // {
                //     data: 'ref_state_id',
                //     name: 'ref_state_id',
                //     orderable: true
                // },
                {
                    data: 'status',
                    name: 'status',
                    orderable: true
                },
                {
                    data: 'action',
                    name: 'name',
                    orderable: false
                },
            ],
            // initComplete: function () {
            //     var btns = $('.dt-button');
            //     //btns.addClass('btn btn-success btn-success');
            //     btns.removeClass('dt-button');

            // },

            paging: true,
            dom: 'Bfrtip',
            buttons: [{
                    extend: 'excelHtml5',
                    title: function() {
                        return "{{ $tit }} List"; 
                    },
                    titleAttr: 'CSV REPORTS'
                },
                {
                    extend: 'pdfHtml5',
                    title: function() {
                        return "{{ $tit }} List"; 
                    },
                    orientation: 'landscape',
                    pageSize: 'A4',
                    titleAttr: 'PDF REPORTS'
                }
            ]
        });


//$(document).ready(function() {
   // function updateRemainingTime() {
     //   $('.remaining-time').each(function() {
      //      var remainingTime = parseInt($(this).data('seconds')); 

      //      if (remainingTime > 0) {
      //          var hours = Math.floor(remainingTime / 3600);
      //          var minutes = Math.floor((remainingTime % 3600) / 60);
       //         var seconds = remainingTime % 60;

       //         var formattedTime = (hours < 10 ? '0' : '') + hours + ':' + 
       //                             (minutes < 10 ? '0' : '') + minutes + ':' + 
       //                             (seconds < 10 ? '0' : '') + seconds;

         //       $(this).text(formattedTime);
        //        $(this).data('seconds', remainingTime - 1); 
         //   } else {
         //       $(this).text('Expired');
        //    }
      //  });
  //  }

 //   setInterval(updateRemainingTime, 1000);
//});



        $("#search").on('change', function(e) {
            table.draw();
            e.preventDefault();
        });


        $(document).on('click', '.deletedata', function() {
            var id = $(this).attr('data-value');

            Swal.fire({
                title: 'Are you sure?',
                html: '<input type="text" id="deletionReason" class="swal2-input" placeholder="Enter reason for deletion...">',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.value) {
                    var deletionReason = $('#deletionReason').val();
                    $.ajax({
                        url: "{{ route('superadmin.usermanagement.deptUser.delete') }}",
                        method: "POST",
                        dataType: 'json',
                        data: {
                            'id': id,
                            'deletionReason': deletionReason,
                            '_token': '{{ csrf_token() }}',
                        },
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function(result) {
                            Swal.fire('Deleted!', 'Record Deleted Successfully..', 'success')
                                .then((result) => {
                                    window.location.href =
                                        '{{ route('superadmin.usermanagement.deptUser', $ids) }}';
                                });
                        }

                    });
                }
            });
        });

        $(document).on('click', '.viewdata', function() {
            var id = $(this).attr('data-id');

            $.ajax({
                url: "{{ route('superadmin.usermanagement.deptUser.view') }}",
                method: "POST",
                dataType: 'json',
                data: {
                    'id': id,
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(result) {
                    if (result.status == "success") {
                        $('#viewDataModal').modal('show');
                        $('#viewDataModal #htmlData').html(result.html);
                        return true;
                    } else {
                        Swal.fire('', result.msg, 'warning');
                    }
                },
                error: function(result) {

                }
            });
        });
    </script>
@endpush

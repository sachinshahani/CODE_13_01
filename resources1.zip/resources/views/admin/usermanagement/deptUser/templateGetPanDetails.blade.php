<div class="container">
	<div class="form-wrap">	
		<form id="survey-form">
			<div class="row">
				<div class="col-md-6">
					<div class="form-group">
						<label id="name-label" for="name">PAN Number/पैन संख्या</label>
						<input type="text" name="name" id="name" placeholder="PAN Number/पैन संख्या" value="{{$result->user_name ?? 'N/A'}}" class="form-control" required readonly>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label id="email-label" for="email">Name /नाम</label>
						<input type="text" name="email" id="email" placeholder="Enter your email"  value="{{$result->first_name ?? ''}} {{$result->last_name ?? ''}}"class="form-control" required readonly>
					</div>
				</div>
			</div>
            <div class="row mt-4">
				<div class="col-md-6">
					<div class="form-group">
						<label id="name-label" for="name">State/राज्य </label>
						<input type="text" name="name" id="name" placeholder="Enter your name"  value="{{getStateName($result->ref_state_id ?? '0')}}"class="form-control" required readonly>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label id="email-label" for="email">District/जिला</label>
						<input type="text" name="email" id="email" placeholder="Enter your email" value="{{getDisName($result->ref_district_id ?? '0')}}" class="form-control" required readonly>
					</div>
				</div>
			</div>

            <div class="row mt-4">
				<div class="col-md-6">
					<div class="form-group">
						<label id="name-label" for="name">Taluka/Mandal/तालुका/मंडल</label>
						<input type="text" name="name" id="name" placeholder="Enter your name"  value="{{getTalukName($result->ref_block_tehsil_id ?? '0')}}"class="form-control" required readonly>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label id="email-label" for="email">Village/गाँव </label>
						<input type="text" name="email" id="email" placeholder="Enter your email"  value="{{getVillName($result->ref_village_id ?? '0')}}"class="form-control" required readonly>
					</div>
				</div>
			</div>

            <div class="row mt-4">
				<div class="col-md-6">
					<div class="form-group">
						<label id="name-label" for="name">Pin Code/पिन कोड</label>
						<input type="text" name="name" id="name" placeholder="Enter your name"  value="{{$result->pin ?? 'N/A'}}" class="form-control" required readonly
					</div>
				</div>
			 
			</div>

		</form>
	</div>	
</div>
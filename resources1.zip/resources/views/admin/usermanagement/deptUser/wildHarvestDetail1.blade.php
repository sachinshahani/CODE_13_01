@extends('admin.layouts.app')

@section('content')
<style>
.wrapper {
    max-width: 1240px;
    margin: 0 auto;
}

.white-bg {
    background-color: white;
    /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
    border-bottom: 5px solid #ff9800;
    margin-bottom: 15px;
}

.auth-one-bg .slide .carousel-indicators {
    bottom: 25px;
}

.auth-page-wrapper .auth-page-content {
    padding-bottom: 0px !important;
}

.auth-page-content .card {
    margin-bottom: 0rem;
}

.data-tabs .wrapper .nav-tabs button {
    font-size: 17px;
    color: black;
}

.data-tabs .wrapper .nav-tabs .active {
    background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
    */ color: white;
    background: orange;
    border-radius: 0px;
}

.carousel-caption.d-none.d-md-block {
    background-color: #000000bf;
    left: 0;
    width: 100%;
    bottom: 0;
}

.carousel-indicators {
    display: none;
}

.custom-banner-caption {
    color: white !important;
}

.announcement-heading {
    font-size: 1.2em;
    font-weight: 600;
}

.data-tabs .tab-pane ul li {
    font-size: 1em;
    padding: 5px 0;

}

.main-logo {
    padding: 10px;
}

.data-tabs .nav-item .nav-link {
    background-image: none;
}

/* .right-sec{
    box-shadow: 5px 10px 18px #888888;
} */
.navbar-brand-box {
    background: #fff;
}

.btn-danger {
    background-color: #40895a;
    border: 1px solid #40895a;
}

[data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
    color: white !important;
}

.header-buttons .btn-primary {
    margin-right: 10px;
    padding: 6px 15px;
    font-weight: 600;
    background-color: #207005;
    border: none;
    box-shadow: 0px 2px 7px #888888;
}

.header-buttons .btn-secondary {
    margin-right: 10px;
    padding: 6px 15px;
    font-weight: 600;
    background-color: #72a055;
    border: none;
    box-shadow: 0px 2px 7px #888888;
}


.right-sec {
    border-left: 5px solid #ede7e7;
}

.tabdiv {
    background: white;
    padding: 20px;
    margin-top: 10px;
    border: 10px solid #dfdbd5;
}

.nav-tabs {
    border-bottom: 0px;
}

div#myTabContent {
    border: 1px solid #cccccc;
}

.frontfooter footer {
    padding: 20px calc(1.5rem / 2);
    position: static;
    color: #000;
    height: 60px;
    background-color: #f9f9f9;
    margin-top: 30px;
    border-top: 1px solid #e1dfdf;
}

span.logo-sm img {
    width: 69px;
}

.seperatesec {
    margin-top: 20px;
}

.simplebar-content li.nav-item:hover {
    background: #4caf50;
}

.sectitle {
    font-size: 14px;
}

.required {
    color: red;
}

.customtextarea {
    height: 120px;
}

ul.boxsection {
    margin: 0;
    padding: 0;
}

ul.boxsection li {
    list-style-type: none;
    padding: 7px 0;
    border-bottom: 1px solid #efeded;
}

.boxcard .col:nth-child(1) {
    background: #effcfb;
}

.boxcard .col:nth-child(2) {
    background: #fdfdfd;
}

.boxcard .col:nth-child(3) {
    background: #effcfb;
}

.boxcard .col:nth-child(4) {
    background: #fdfdfd;
}

.boxcard .col:nth-child(5) {
    background: #effcfb;
}

/* --registration-form css  */
.custom-tab-content {
    padding-top: 0 !important;
    padding-bottom: 0px !important;
}

.custom-tab-nav {
    background: white;

}

.custom-tab-nav .nav-link {
    border-radius: 0 !important;
    border-bottom: 1px solid #e9ebec;
    border-right: 1px solid #e9ebec;
    font-size: 14px;
    padding: 10px;
}

.custom-tab-nav .nav-link.active,
.custom-tab-nav .show>.nav-link {
    color: rgb(255, 255, 255) !important;
    background-color: #2c8c6d;
    border-bottom: #2c8c6d !important;
    /* border-bottom: #207005 !important; */
    position: relative;
}

.custom-tab-nav .nav-link:hover,
.custom-tab-nav .nav-link:focus {
    border-bottom: 1px solid #207005;
    border-radius: 0;
    font-size: 14px;
    transition: background-color 0.20s linear;
}

.custom-tab-nav .nav-link.active:after {
    content: "";
    position: absolute;
    bottom: -16px;
    left: 50%;
    border: 8px solid transparent;
    border-top-color: #2c8c6d;
    z-index: 999;
}

.reg-form-btns {
    margin-bottom: 15px;
}

.reg-form-btns .btn-secondary {
    color: #fff;
    background-color: #405189;
    border-color: #405189;
}

.btn-soft-success:active,
.btn-soft-success:focus,
.btn-soft-success:hover {
    border: none;
}

.custom-tab-nav ul {
    padding: 0px;
    margin: 0px;
}

.custom-tab-nav ul li {
    padding: 0px;
    margin: 0px;
    display: inline-block;
    list-style: none;
}
</style>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">वन फ़सल काटने वाले की प्रोफ़ाइल/Wild Harvester Profile</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Wild Harvester Profile</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <form method="post" enctype="multipart/form-data" id=""
            action="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserStoreStep2',$id) }}">
            <input type="hidden" name="ref_operator_type_id" value="{{$harvester->ref_operator_type_id}}">
            @csrf
            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                    <a class="nav-link" id="step1-tab"
                        href="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserAdd',$id) }}">General
                        Details</a>
                    <a class="nav-link active" id="step2-tab"
                        href="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep2',$id) }}">Bank
                        Details</a>
                    <a class="nav-link" id="step3-tab"
                        href="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep3',$id) }}">Forest
                        Details</a>
                    <a class="nav-link" id="step4-tab"
                        href="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep4',$id) }}">Geo Tagging
                        of Permitted Forest Area</a>
                    <a class="nav-link" id="step5-tab"
                        href="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep5',$id) }}">Details of
                        Forest Product</a>
                    <a class="nav-link" id="step6-tab"
                        href="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep6',$id) }}">List of
                        Documents</a>
                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step2">
                    <div class="card">
                        <!-- <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1">
                                Contact Person Details
                            </h4>

                        </div> -->
                        <!-- end card header -->
                        <div class="card-body">
                            <div class="live-preview">

                                <div class="row seperatesec white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label">बैंक विवरण/Bank Details</label>
                                    </div>
                                    <hr>
                                    <div class="col-xxl-3 col-md-6 mt-1">
                                        <label for="labelInput" class="form-label">बैंक का नाम/Bank Name</label>
                                        <select class="form-select" name="bank_name" >
										<option value="">Bank Name</option>
										@foreach($bankName as $name)
											<option value="{{ $name->id }}" 
												{{ ($bankDetail && $bankDetail->ref_bank_id == $name->id) ? 'selected' : '' }}>
												{{ $name->bank_name }}
											</option>
										@endforeach
									</select>

                                        
                                    </div>

                                    <div class="col-xxl-3 col-md-6 mt-1">
                                        <div>
                                            <label class="form-label">खाता नंबर/Account No.</label>
                                            <input type="text" class="form-control numbersonly" id="account_number"
                                                name="account_number" placeholder="Account Number" maxlength="17"
                                                value="{{ ($bankDetail) ? $bankDetail->account_number : '' }}" >
                                        </div>
                                    </div>

                                    <div class="col-xxl-3 col-md-6 mt-1">
                                        <div>
                                            <label class="form-label">आईएफएससी कोड/IFSC Code</label>
                                            <input type="text" class="form-control" id="ifsc_code" name="ifsc_code"
                                                placeholder="IFSC Code"
                                                value="{{ ($bankDetail) ? $bankDetail->ifsc_code : '' }}" >
                                        </div>
                                    </div>

                                    <div class="col-xxl-3 col-md-6 mt-1">
                                        <div>
                                            <label class="form-label">शाखा का नाम/Branch Name</label>
                                            <input type="text" class="form-control" id="branch_name" name="branch_name"
                                                placeholder="Branch Name"
                                                value="{{ ($bankDetail) ? $bankDetail->branch_name : '' }}" >
                                        </div>
                                    </div>

                                    <div class="col-xxl-3 col-md-6 gy-3">
                                        <div>
                                            <label class="form-label">बैंक का पता/Bank Address</label>
                                            <input type="text" class="form-control" id="bank_address"
                                                name="bank_address" placeholder="Bank Address"
                                                value="{{ ($bankDetail) ? $bankDetail->bank_address : '' }}" >
                                        </div>
                                    </div>

                                    <div class="col-xxl-3 col-md-6 gy-3">
                                        <div>
                                            <label class="form-label">बैंक पिनकोड/Bank Pincode</label>
                                            <input type="text" class="form-control numbersonly" id="bank_pincode"
                                                name="bank_pincode" placeholder="Bank Pincode" maxlength="6"
                                                value="{{ ($bankDetail) ? $bankDetail->pincode : '' }}" >
                                        </div>
                                    </div>

                                    {{-- <div class="col-xxl-3 col-md-6 gy-3">
                                        <div>
                                            <label class="form-label">Wild Harvester Photo <span class="required">*</span> 
                                                @if(isset($bankDetail->farmer_photo) && $bankDetail->farmer_photo!='') 
                                                 <a href="{{ asset('public/research/uploads/'.$bankDetail->farmer_photo) }}"
                                                    target="_blank">View Image</a>
                                                @endif
                                            </label>
                                            <input type="file" class="form-control" id="harvester_photo"
                                                name="harvester_photo" {{ $bankDetail->farmer_photo ?? 'required'}}>
                                        </div>
                                    </div> --}}
                                    <div class="row">
                                        <div class="col-lg-12 gy-4">
                                            <div class="hstack gap-2">
                                                <a href="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserAdd',$id) }}"
                                                    class="btn btn-soft-secondary">
                                                    Back
                                                </a>
                                                <input type="submit" class="btn btn-primary" value="Save">
												
                                                <a href="{{route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep3',$id)}}"
                                                    class="btn btn-soft-success">
                                                    Next
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
        </form>
    </div>
</div>



@endsection
@push('script')
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.min.js"></script>

<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

$(document).ready(function() {
    // jQuery Validation
    $("#registration").validate({
        rules: {
            bank_name: {
                required: true
            },
            account_number: {
                required: true
            },
            ifsc_code: {
                required: true
            },
            branch_name: {
                required: true
            },
            bank_address: {
                required: true
            },
            bank_pincode: {
                required: true
            }
        },
        messages: {
            bank_name: {
                required: "Bank name is required"
            },
            account_number: {
                required: "Account number is required"
            },
            ifsc_code: {
                required: "IFSC code is required"
            },
            branch_name: {
                required: "Branch name is required"
            },
            bank_address: {
                required: "Bank address is required"
            },
            bank_pincode: {
                required: "Bank pincode is required"
            }
        },

    });

    
});

$(document).ready(function() {
    $('#registration').on('submit', function(event) {
        var accountNumber = $('#account_number').val();
        if (accountNumber) {
            var encodedAccountNumber = btoa(accountNumber);  
            $('#account_number').val(encodedAccountNumber); 
        }
    });
});



 $('#ifsc_code').on('input', function() {
                let ifscCode = $(this).val().toUpperCase().replace(/\s+/g, ''); 
                $(this).val(ifscCode);
            });
 $('#account_number').on('keyup', function() {
                const accountNumber = $(this).val();
                if (!/^\d{8,17}$/.test(accountNumber) && accountNumber.length > 0) {
                    $(this).css('border-color', 'red');  
                } else {
                    $(this).css('border-color', '');
                }
            });
			
			

// Dropzone has been added as a global variable.
const dropzone = new Dropzone("div.dropzone", {
    url: "{{ route('storeMedia') }}",
    paramName: "file",
    maxFilesize: 2,
    maxFiles: 1,
    acceptedFiles: ".jpeg,.jpg,.png,.mp4,.webm,.html5",
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    init: function() {
        var drop = this; // Closure
        this.on('error', function(file, errorMessage) {
            if (errorMessage.indexOf('Error 404') !== -1) {
                var errorDisplay = document.querySelectorAll('[data-dz-errormessage]');
                errorDisplay[errorDisplay.length - 1].innerHTML =
                    'Error 404: The upload page was not found on the server';
            }
            if (errorMessage.indexOf('File is too big') !== -1) {
                alert('Unable to upload image size is greated than 2 MB');
                // i remove current file
                drop.removeFile(file);
            }
        });
        this.on("maxfilesexceeded", function(file) {
                this.removeAllFiles();
                this.addFile(file);
            }),
            this.on("success", function(file, response) {
                console.log(response);
                var hiddenImage = $('<input type="hidden" name="_hidden_legal_doc_upload" value="' +
                    response.name + '"/>');
                $('.hidden_images_area').html(hiddenImage);
            })
    }
});
</script>

@endpush
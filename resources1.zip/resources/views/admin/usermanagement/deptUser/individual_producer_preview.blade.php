@extends('admin.layouts.app')
@section('content')
<style>
    body {
        margin: 0px;
        padding: 0px;
        font-family: "Segoe UI";
    }

    .maindiv {
        width: 80%;
        margin: 0 auto;
    }

    .pdf_maindiv {
        border: 1px solid #cccccc;
        width: 100%;
        float: left;
        padding: 3%;
    }

    .pdf_heading {
        font-size: 20px;
        color: #000;
        padding: 26px 0 12px 0px;
        position: relative;
        width: 100%;
        float: left;
    }

    .brd_heading {
        border-bottom: 2px solid #ee5e24;
        padding-bottom: 8px;
        padding-right: 8px;
        width: 60px;
    }

    .pdf_input1 {
        background: #eeeeee;
    }

    .pdf_txt1 {
        color: #000;
        font-size: 14px;
        width: 45%;
        float: left;
        padding-bottom: 10px;
        font-weight: bold;
    }

    .pdf_box {
        color: #000;
        font-size: 14px;
        width: 55%;
        float: left;
        padding-bottom: 10px;
    }

    .table_pdf {
        width: 100%;
    }


    @media print {
        /*
                               .pdf_heading {
                                font-size: 20px;
                                color: #000;
                                padding: 26px 0 12px 0px;
                                position: relative;
                                width: 100%;
                                float: left;
                                -webkit-print-color-adjust: exact !important;
                                Chrome,
                                Safari color-adjust: exact !important;
                               } */

        /* .pdf_heading:before{content: ""; position: absolute; width:20px; height: 4px; background-color:#ee5e24; bottom:10px; display: block;-webkit-print-color-adjust: exact !important;    Chrome, Safari
                                color-adjust: exact !important;  } */


    }
</style>
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Individual Producer Profile</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Individual Producer Profile</li>
                </ol>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">

        <div class="tab-content py-4 custom-tab-content">
            <div class="tab-pane fade show active" id="step1">
                <div class="card">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1">
                            {{ user_name($user->id) ?? '' }}
                        </h4>
                        <div class="flex-shrink-0  {{ $user->status == 2 || $user->status == 4 ? 'flex-grow-1' : '' }}">
                            <label for="basiInput" class="form-label">{{ $user->status == 2 ? 'Registration Number : ' . $user->registration_no : 'Application Number : #00' . $user->id }}</label>
                        </div>
                        &nbsp;&nbsp;&nbsp;
                        @if ($user->status == 2)
                        <div class="flex-shrink-0 flex-grow-1">
                            <label for="basiInput" class="form-label">Registration Certificate : <a target="_BLANK" href="{{ asset('public/' . $user->registration_certificate) }}"class="text-decoration-underline"><img src="{{ asset('public/assets/images/pdf-icon.png') }}" alt="" class="pdf-img-icon" height="17px">See Doc</a></label>
                        </div>
                            @if ($eMSignedModuleAlow['status'] == 'success')
                                <div class="flex-shrink-0">
                                    @if ($eMSignedModuleResult['status'] == 'success')
                                        @php
                                            $publicPath = str_replace('var/www/html/apeda/', '', $eMSignedModuleResult['signedPath']);
                                        @endphp
                                        <a class="btn btn-success btn-sm" download href="{{ $hostName . $publicPath }}">Download Signed PDF</a>
                                    @else
                                        <button type="button" class="btn btn-primary btn-sm" id="generateDigitalSign" data-filename="{{ basename($user->registration_certificate) }}" data-path="/{{ basename(dirname($user->registration_certificate)) }}/" data-filestored="public" data-certificate="RC"> Digital Sign </button>
                                    @endif
                                </div>
                            @endif
                        @endif
                        @if ($user->status == 0 || $user->status == 3)
                        <div class="flex-shrink-0">
                            <a href="{{ route('superadmin.usermanagement.deptUser.individualUserAdd', $user->id) }}" class="btn btn-soft-success">Back</a>
                        </div>
                        @endif
                    </div>
                    <!-- end card header -->
                    <div class="card-body white-inner">
                        <div class="pdf_heading">Individual Producer Details</div>
                        <div class="pdf_maindiv">
                            <!--form1 section starts here-->
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                            <tr>
                                                <td class="pdf_txt1">Individual Producer Name</td>
                                                <td class="pdf_box"> {{ user_name($user->id) ?? '' }}</td>
                                            </tr>
                                            {{-- <tr>
                                                    <td class="pdf_txt1">Standerd Type</td>
                                                    <td class="pdf_box">{{ $user->standerd_type ??''}}</td>
                                            </tr>
                                            --}}
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        {{-- <table style="padding: 10px; border: 0px;" class="table_pdf">

                                                <tr>
                                                    <td class="pdf_txt1">Legal Document Number</td>
                                                    <td class="pdf_box">{{ $user->legal_document_number ?? '' }}</td>
                                        </tr>
                                        <tr>
                                            <td class="pdf_txt1">Photo of Individual Producer building</td>
                                            <td class="pdf_box">
                                                @if (!empty($user->office_building_photo))
                                                <a target="_BLANK"
                                                    href="{{ asset('public/ics/office_building_photo/' . $user->office_building_photo) }}"
                                                    class="text-decoration-underline">See Doc</a>
                                                @else
                                                NOt Available
                                                @endif
                                            </td>
                                        </tr>

                                        </table> --}}
                                        <!--form1 tab end here-->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="pdf_heading">Individual Producer Address</div>
                        <div class="pdf_maindiv">
                            <!--form1 section starts here-->
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                            <tr>
                                                <td class="pdf_txt1">State</td>
                                                <td class="pdf_box">{{ getStateName($user->ref_state_id) }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">District</td>
                                                <td class="pdf_box">{{ getDisName($user->ref_district_id) }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Taluka/Mandal</td>
                                                <td class="pdf_box">{{ getTalukName($user->ref_block_tehsil_id) }}</td>
                                            </tr>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>

                                    <div class="col-6">

                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                            <tr>
                                                <td class="pdf_txt1">Village</td>
                                                <td class="pdf_box">{{ getVillName($user->ref_village_id) }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Pin Code</td>
                                                <td class="pdf_box">{{ $user->pin ?? '' }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Address</td>
                                                <td class="pdf_box">{{ $user->address ?? '' }}</td>
                                            </tr>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>


                                </div>
                            </div>
                        </div>
                        <div class="pdf_heading">Contact Details of Individual Producer</div>
                        <div class="pdf_maindiv">
                            <!--form1 section starts here-->
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                            <tr>
                                                <td class="pdf_txt1">Mobile Number</td>
                                                <td class="pdf_box"> {{ $user->mobile_no ?? '' }}</td>
                                            </tr>
                                            @php
                                                        $maskedAadhar = '';
                                                        try {
                                                            if ($user->contact_person_aadhar_number) {
                                                                $decryptedAadhar = Crypt::decrypt(
                                                                    $user->contact_person_aadhar_number,
                                                                );
                                                                $maskedAadhar = maskAadhaarNumber($decryptedAadhar);
                                                            }
                                                        } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
                                                            $maskedAadhar = 'Invalid Aadhaar Number';
                                                        }
                                                    @endphp
                                            
                                            <tr>
                                                <td class="pdf_txt1">Aadhaar No.</td>
                                                <td class="pdf_box">{{$maskedAadhar}}
                                                    
                                                </td>
                                            </tr>

                                        </table>
                                        <!--form1 tab end here-->
                                    </div>

                                    <div class="col-6">

                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                                            <tr>
                                                <td class="pdf_txt1">PAN No.</td>
                                                <td class="pdf_box"> {{ $user->user_name }}
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Email ID</td>
                                                <td class="pdf_box">{{ $user->email ?? '' }}
                                                </td>
                                            </tr>

                                        </table>
                                        <!--form1 tab end here-->
                                    </div>


                                </div>
                            </div>
                        </div>

                        <div class="pdf_heading">Farmer Details</div>
                        <div class="pdf_maindiv">
                            <!-- farmer-1 container start  -->
                            @forelse($farmerDetails as $key => $val)
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-12">
                                        <h6
                                            style="padding:0;padding-bottom:15px;width: 100%;text-decoration: underline;">
                                            Farmer {{ $key + 1 }}
                                            </caption>
                                    </div>
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;"
                                            class="table_pdf table_contact_person">

                                            <tbody>
                                                <tr>
                                                    <td class="pdf_txt1">Farmer Full Name</td>
                                                    <td class="pdf_box">{{ $val->farmer_first_name ?? '' }} {{ $val->farmer_middle_name ?? '' }} {{ $val->farmer_last_name ?? '' }}</td>
                                                </tr>
                                                {{-- <tr>
                                                            <td class="pdf_txt1">Farmer Middle Name</td>
                                                            <td class="pdf_box">{{ $val->farmer_middle_name ?? 'N/A' }}
                                                </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Farmer Last Name</td>
                                                    <td class="pdf_box"> {{ $val->farmer_last_name ?? '' }}
                                                    </td>
                                                </tr> --}}
                                                <tr>
                                                    <td class="pdf_txt1">Gender</td>
                                                    <td class="pdf_box">
                                                        @if ($val->gender == 1)
                                                        Male
                                                        @elseif ($val->gender == 2)
                                                        Female
                                                        @elseif ($val->gender == 3)
                                                        Other
                                                        @else
                                                        N/A
                                                        @endif
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="col-6">
                                        <table style="padding: 10px; border: 0px;"
                                            class="table_pdf table_contact_person">
                                            <tbody>
                                                <tr>
                                                    <td class="pdf_txt1">Father/ Husband</td>
                                                    <td class="pdf_box">
                                                        @if ($val->father_husband_flag == 1)
                                                        Father
                                                        @elseif ($val->father_husband_flag == 2)
                                                        Husband
                                                        @else
                                                        N/A
                                                        @endif
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">
                                                        @if ($val->father_husband_flag == 1)
                                                        Father's
                                                        @else
                                                        Husband's
                                                        @endif
                                                        Full Name
                                                    </td>
                                                    <td class="pdf_box">{{ $val->father_husband_first_name }} {{ $val->father_husband_middle_name ?? '' }} {{ $val->father_husband_last_name ?? '' }}
                                                    </td>
                                                </tr>
                                                {{-- <tr>
                                                            <td class="pdf_txt1">Father's Middle Name</td>
                                                            <td class="pdf_box" colspan=2>
                                                                {{ $val->father_husband_middle_name ?? 'N/A' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Father's Last Name</td>
                                                    <td class="pdf_box">{{ $val->father_husband_last_name ?? '' }}
                                                    </td>
                                                </tr> --}}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            @empty
                            @endforelse
                        </div>
                        <div class="pdf_heading">Document Details</div>
                        <div class="pdf_maindiv">
                            @forelse($producer_docs as $key => $val)
                            <div class="container-fluid">
                                <div class="row">
                                    {{-- <div class="col-12">
                                                <h6
                                                    style="padding:0;padding-bottom:15px;width: 100%;text-decoration: underline;">
                                                    Farmer {{ $key + 1 }}
                                    </caption>
                                </div> --}}
                                <div class="col-6">
                                    <!--form1 tab starts here-->
                                    <table style="padding: 10px; border: 0px;"
                                        class="table_pdf table_contact_person">

                                        <tbody>
                                           
                                            <tr>
                                                <td class="pdf_txt1">Land Doc</td>
                                                <td class="pdf_box"> {{ $val->land_documets }} @if (!empty($val->land_documents_image_path))
                                                    <a target="_BLANK"
                                                        href="{{ asset('public/individualProducer/documents/land_document/' . $val->land_documents_image_path) }}"
                                                        class="text-decoration-underline">See Doc</a>
                                                    @endif
                                                </td>
                                            </tr>
                                           

                                        </tbody>
                                    </table>
                                    <!--form1 tab end here-->
                                </div>
                                <div class="col-6">
                                    <!--form1 tab starts here-->
                                    <table style="padding: 10px; border: 0px;"
                                        class="table_pdf table_contact_person">
                                        <tbody>
                                          

                                            <!-- <tr>
                                                <td class="pdf_txt1">Land Doc</td>
                                                <td class="pdf_box"> {{ $val->land_documets }} @if (!empty($val->land_documents_image_path))
                                                    <a target="_BLANK"
                                                        href="{{ asset('public/individualProducer/documents/land_document/' . $val->land_documents_image_path) }}"
                                                        class="text-decoration-underline">See Doc</a>
                                                    @endif
                                                </td>
                                            </tr> -->


                                        </tbody>
                                    </table>
                                    <!--form1 tab end here-->
                                </div>
                            </div>
                        </div>
                        <!-- Farmer - 1 container ended  -->

                        @empty
                        No Record found..
                        @endforelse
                        <!-- Docs - 2 container start  -->

                        <!-- Docs -2 container end  -->
                    </div>
                    <!-- END PRoducer Documents-->


                    <!-- Start Form Details -->
                    <div class="pdf_heading">Farm Details</div>
                    <div class="pdf_maindiv">
                        <!-- farmer-1 container start  -->
                        @forelse($producer_farm_detail as $key => $val)
                        
                        @forelse($geo_taggings as $key1 => $val1)

                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-12">
                                        <h6
                                            style="padding:0;padding-bottom:15px;width: 100%;text-decoration: underline;">
                                            Farm {{ $key1 + 1 }}
                                            </caption>
                                    </div>
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;"
                                            class="table_pdf table_contact_person">

                                            <tbody>
                                                <tr>
                                                    <td class="pdf_txt1">Land Holding Type</td>
                                                    <td class="pdf_box">{{ $val->land_holding_type ?? '' }}</td>
                                                </tr>
                                                
                                                <tr>
                                                    <td class="pdf_txt1">Khasra/Survey/GAT Number</td>
                                                    <td class="pdf_box"> {{ $val->survay_no }}</td>
                                                </tr>  
                                                <tr>
                                                    <td class="pdf_txt1"></td>
                                                    <td class="pdf_box"></td>
                                                </tr>
                                                
                                                
                                                
                                                <tr>
                                                    <td class="pdf_txt1">Geo Tagging of Farm</td>
                                                    <td class="pdf_box">{{ $val1->geo_tagging_of_farm ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1"></td>
                                                    <td class="pdf_box"></td>
                                                </tr> 
                                                <tr>
                                                    <td class="pdf_txt1">Total Area of Farm</td>
                                                    <td class="pdf_box"> {{ $val1->under_organic_cultivation }}</td>
                                                </tr>  

                                            </tbody>

                                            <!-- <tbody>
                                                <tr>
                                                    <td class="pdf_txt1">Registration No</td>
                                                    <td class="pdf_box">{{ $val->registration_no ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Farmar Name</td>
                                                    <td class="pdf_box">{{ $val->farm_name ?? '' }} </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Landmark</td>
                                                    <td class="pdf_box"> {{ $val->landmark }}</td>
                                                </tr>

                                                <tr>
                                                    <td class="pdf_txt1">Farm No</td>
                                                    <td class="pdf_box">{{ $val->farm_no ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Area (Ha)</td>
                                                    <td class="pdf_box">{{ $val->area_in_ha ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Total Area (Ha)</td>
                                                    <td class="pdf_box"> {{ $val->total_area ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Survay No.</td>
                                                    <td class="pdf_box"> {{ $val->survay_no ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Latitude</td>
                                                    <td class="pdf_box"> {{ $val->latitude ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Logititude</td>
                                                    <td class="pdf_box"> {{ $val->logititude ?? '' }}</td>
                                                </tr>

                                            </tbody> -->
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;"
                                            class="table_pdf table_contact_person">
                                            <tbody>

                                                <tr>
                                                    <td class="pdf_txt1">Land Holding Details</td>
                                                    <td class="pdf_box">{{ $val->farm_name ?? '' }} </td>
                                                </tr>     
                                                <tr>
                                                    <td class="pdf_txt1"></td>
                                                    <td class="pdf_box"></td>
                                                </tr>    
                                                <tr>
                                                    <td class="pdf_txt1"></td>
                                                    <td class="pdf_box"></td>
                                                </tr>
                                                
                                                <tr>
                                                    <td class="pdf_txt1"></td>
                                                    <td class="pdf_box"></td>
                                                </tr> 
                                                <tr>
                                                    <td class="pdf_txt1">Total Area of Farm under organic cultivation</td>
                                                    <td class="pdf_box">{{ $val1->total_area_of_farm ?? '' }} </td>
                                                </tr>     
                                                <tr>
                                                    <td class="pdf_txt1"></td>
                                                    <td class="pdf_box"></td>
                                                </tr> 

                                            </tbody>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                </div>                            
                            </div>
                            <hr>
                            @empty
                            No Record found..
                            @endforelse
                            <!-- Farmer - 1 container ended  -->
                      
                        @empty
                        No Record found..
                        @endforelse

                    </div>
                    <!-- END PRoducer Form Details -->

                    <!-- Start Producer standing_crop -->
                    <div class="pdf_heading">Standing Crop Details</div>
                    <div class="pdf_maindiv">
                        <!-- farmer-1 container start  -->
                        @forelse($producer_standing_corp as $key => $val)
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-12">
                                    <h6
                                        style="padding:0;padding-bottom:15px;width: 100%;text-decoration: underline;">
                                        {{ $key + 1 }}
                                        </caption>
                                </div>
                                <div class="col-6">
                                    <!--form1 tab starts here-->
                                    <table style="padding: 10px; border: 0px;"
                                        class="table_pdf table_contact_person">

                                        <tbody>
                                            <tr>
                                                <td class="pdf_txt1">Season Name</td>
                                                <td class="pdf_box">{{ $val->season_name ?? '' }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Area (Ha)</td>
                                                <td class="pdf_box">{{ $val->area ?? '' }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Crop Photo</td>
                                                <td class="pdf_box">
                                                    @if (!empty($val->crop_photo))
                                                    <a target="_BLANK"
                                                        href="{{ $val->crop_photo }}">View</a>
                                                    @endif
                                                </td>
                                            </tr>



                                        </tbody>
                                    </table>
                                    <!--form1 tab end here-->
                                </div>
                                <div class="col-6">
                                    <!--form1 tab starts here-->
                                    <table style="padding: 10px; border: 0px;"
                                        class="table_pdf table_contact_person">
                                        <tbody>
                                            <tr>
                                                <td class="pdf_txt1">Organic Status</td>
                                                <td class="pdf_box">
                                                    {{ getRefOrganicStatusMasterByID($val->organic_status) }}
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Name Of Crop</td>
                                                <td class="pdf_box">{{ $val->name_of_corp ?? '' }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Geotag Photo</td>
                                                <td class="pdf_box">
                                                    @if (!empty($val->geotag_photo))
                                                    <a target="_BLANK"
                                                        href="{{ $val->geotag_photo }}">View</a>
                                                    @endif
                                                </td>
                                            </tr>

                                        </tbody>
                                    </table>
                                    <!--form1 tab end here-->
                                </div>
                            </div>
                        </div>
                        <!-- Farmer - 1 container ended  -->
                        <hr>
                        @empty
                        No Record found..
                        @endforelse
                    </div>
                    <!-- END PRoducer standing_crop-->

                    <!-- Start Producer standing_crop -->
                    <div class="pdf_heading">Proposed Crop Details</div>
                    <div class="pdf_maindiv">
                        <!-- farmer-1 container start  -->
                        @forelse($producer_proposed_corp as $key => $val)
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-12">
                                    <h6
                                        style="padding:0;padding-bottom:15px;width: 100%;text-decoration: underline;">
                                        {{ $key + 1 }}
                                        </caption>
                                </div>
                                <div class="col-6">
                                    <!--form1 tab starts here-->
                                    <table style="padding: 10px; border: 0px;"
                                        class="table_pdf table_contact_person">

                                        <tbody>
                                            <tr>
                                                <td class="pdf_txt1">Season Name</td>
                                                <td class="pdf_box">{{ $val->season_name ?? '' }}</td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Area(Ha)</td>
                                                <td class="pdf_box">{{ $val->area ?? '' }}</td>
                                            </tr>

                                        </tbody>
                                    </table>
                                    <!--form1 tab end here-->
                                </div>
                                <div class="col-6">
                                    <!--form1 tab starts here-->
                                    <table style="padding: 10px; border: 0px;"
                                        class="table_pdf table_contact_person">
                                        <tbody>
                                            <tr>
                                                <td class="pdf_txt1">Organic Status</td>
                                                <td class="pdf_box">
                                                    {{ getRefOrganicStatusMasterByID($val->organic_status) }}
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="pdf_txt1">Name Of Crop</td>
                                                <td class="pdf_box">{{ $val->details_name_of_corp ?? '' }}
                                                </td>
                                            </tr>


                                        </tbody>
                                    </table>
                                    <!--form1 tab end here-->
                                </div>
                            </div>
                        </div>
                        <!-- Farmer - 1 container ended  -->
                        <hr>
                        @empty
                        No Record found..
                        @endforelse

                        @if (!empty(Auth::guard('misadmin')->user()->role) && Auth::guard('misadmin')->user()->role->role_id == 1)
                        <div class="row">
                            <div class="col-lg-12">
                                @if ($user->status != 2)
                                <div class="pdf_heading">Remarks</div>
                                <!-- end card header -->

                                <div class="live-preview">

                                    {{-- <div class="col-xxl-4 col-md-4 gy-4 ">
                                                            <div>
                                                                <label for="basiInput"
                                                                    class="form-label">Remarks :
                                                                </label>
                                                                <label for="basiInput">{{ $user->cb_reg_remarks ?? '' }}
                                    </label>

                                </div>
                            </div> --}}

                            <form method="post" id=""
                                action="{{ route('superadmin.usermanagement.deptUser.previewpost') }}">
                                @csrf
                                <input type="hidden" name="at_user_id"
                                    value="{{ $user->id }}">
                                <input type="hidden" name="id"
                                    value="{{ $user->ref_operator_type_id }}">
                                <div class="col-xxl-4 col-md-4 gy-4 ">
                                    <div>
                                        <label for="basiInput" class="form-label">Status<span
                                                class="required">*</span>
                                        </label>

                                        <select class="form-select" name="status" required>
                                            <option value="">-Select-
                                            </option>
                                            <option value="2"
                                                {{ $user->status == 2 ? 'selected' : '' }}>
                                                Approved
                                            </option>
                                            <option value="4"
                                                {{ $user->status == 4 ? 'selected' : '' }}>
                                                Review
                                            </option>
                                            <option value="3"
                                                {{ $user->status == 3 ? 'selected' : '' }}>
                                                Rejected

                                            </option>
                                        </select>

                                    </div>
                                </div>

                                <div class="col-xxl-6 col-md-6 gy-6 mt-3">
                                    <div>
                                        <label class="form-label">Submit Your
                                            Remarks:<span class="required">
                                                *</span></label>
                                        <textarea placeholder="Address of The Inspector" class="form-control customtextarea" name="cb_remarks" required>{{ $user->cb_reg_remarks ?? '' }}</textarea>
                                    </div>
                                </div>
                                {{-- @if ($regDetail->cb_remarks == '' && $regDetail->cb_status == '') --}}
                                <div class="row">
                                    <div class="col-xxl-4 col-md-4 gy-4 ">
                                        <div class="hstack gap-2">

                                            <button type="submit" id="submitbtn"
                                                class="btn btn-primary submit-button">Submit</button>

                                        </div>
                                    </div>
                                </div>
                                {{-- @endif --}}
                            </form>
                        </div>
                        @endif


                    </div>
                </div>
                @else
                <div class="row">
                    <div class="col-lg-12 gy-4">
                        <div class="hstack gap-2">
                            <br>
                            <!-- @if($user->status == 0)
                            <form method="post" id=""
                                action="{{ route('superadmin.individualProducer.preview.pdf',$user->id) }}">
                                @csrf
                                <input type="hidden" name="redirect_url" value="{{ url()->full() }}">
                                <button type="submit" class="btn btn-primary" id="submitbtn">Download</button>
                            </form> -->
                            
                            
                           @if ($user->status == 0 || $user->status == 3)
                            
                            @if($user->esign_authentication== '' || $user->esign_authentication==0)
                                <!-- 
                            <form method="post" id=""
                                action="{{ route('getesignapprove') }}">
                                @csrf
                                <input type="hidden" name="redirect_url"
                                    value="{{ url()->full() }}">
                                <button type="submit" class="btn btn-primary" id="submitbtn">
                                    E-Sign Authentication
                                </button>
                            </form> -->

                            <form method="post" id="" action="{{ route('superadmin.icsuser.previewpost') }}">
                                @csrf
                                <input type="hidden" name="at_user_id"
                                    value="{{ $user->id }}">
                                <button type="submit" class="btn btn-primary" id="submitbtn">
                                    Final Submit
                                </button>
                            </form>


                            @endif
                            @if ($user->esign_authentication==1)
                            <!-- <form method="post" id="" action="{{ route('superadmin.icsuser.previewpost') }}">
                                @csrf
                                <input type="hidden" name="at_user_id"
                                    value="{{ $user->id }}">
                                <button type="submit" class="btn btn-primary" id="submitbtn">
                                    Final Submit
                                </button>
                            </form> -->
                            @endif

                            @endif
                            @if ($user->status == 3)

                            <div class="col-xxl-4 col-md-4 gy-4 ">
                                <a href="{{ route('superadmin.icsuser.step1', $user->id) }}"
                                    class="btn btn-soft-success">
                                    Edit
                                </a>

                                @endif
                            </div>
                            @if ($user->status == 3)
                            <div class="hstack gap-2">
                                <br>
                                <div class="col-xxl-4 col-md-4 gy-4 ">
                                    <a href="{{ route('superadmin.processorUseredit', $user->id) }}"
                                        class="btn btn-soft-success">
                                        Edit
                                    </a>
                                </div>
                                @endif
                                @endif
                                @endif
                            </div>
                        </div>



                    </div>



                    <!-- END PRoducer standing_crop-->

                    {{-- <div class="row">
                                <div class="col-lg-12 gy-4">
                                    <div class="hstack gap-2">

                                        @if ($user->status == 3 || $user->status == 2)
                                            <div class="col-xxl-4 col-md-4 gy-4 ">
                                                <div>
                                                    <label for="basiInput"
                                                        class="form-label">{{ $user->status == 2 ? 'Status :' : '' }}
                    </label>
                    <label
                        for="basiInput">
                        @php
                        if($user->status==2){
                        echo 'Application Approved By CB';
                        }else if($user->status==3){
                        echo 'Application Rejected By CB';
                        }else if($user->status==4){
                        echo 'Review';
                        }else{
                        echo 'Pending';
                        }
                        @endphp

                    </label>

                </div>
            </div>

            <div class="col-xxl-4 col-md-4 gy-4 ">
                <div>
                    <label for="basiInput" class="form-label">Remarks :
                    </label>
                    <label for="basiInput">{{ $user->cb_reg_remarks ?? '' }}
                    </label>

                </div>
            </div>
        </div>

        @endif
        <div class="hstack gap-2">
            <br>
            @if ($user->status == 0 || $user->status == 3)
            <form method="post" id=""
                action="{{ route('superadmin.icsuser.previewpost') }}">
                @csrf
                <input type="hidden" name="at_user_id"
                    value="{{ $user->id }}">
                <button type="submit" class="btn btn-primary" id="submitbtn">
                    Final Submit
                </button>
            </form>
            @endif
            @if ($user->status == 3)

            <div class="col-xxl-4 col-md-4 gy-4 ">
                <a href="{{ route('superadmin.icsuser.step1', $user->id) }}"
                    class="btn btn-soft-success">
                    Edit
                </a>
                @endif
            </div>
        </div>
    </div>
</div> --}}




</div>
</div>
</div>
</div>

</div>
</div>

@endsection

@push('script')
<script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
<script>
    $(document).on('click', '#submitbtn', function() {

        if (checkValidation("registration")) {
            $('#registration').submit();
            return true;
        } else {
            return false;
        }
    });
</script>


@endpush
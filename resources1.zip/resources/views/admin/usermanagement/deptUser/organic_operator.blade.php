@extends('admin.layouts.app')

@section('content')
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">
                Online Request List
            </h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);"> </a></li>
                    <li class="breadcrumb-item active">
                        Online Request
                    </li>
                </ol>
            </div>
        </div>
    </div>
</div>
<div class="clearfix"></div>

<div class="col-md-12 mt-2">
    @if (session('success'))
    <div class="alert alert-success" id="validate">
        {{ session('success') }}
    </div>
    @endif

    @if (session('importErrors'))
    <div class="alert alert-danger">
        <p>Following Errors Occured While Uploading the list, Please fix and upload again</p>
        <ul>
            @foreach (session('importErrors') as $failure)
            @foreach ($failure->errors() as $f)
            <li>{{ $f . ' at row ' . $failure->row() }}</li>
            @endforeach
            @endforeach
        </ul>
    </div>
    @endif
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0" style="float: left">


                    Online Request For Registration

                </h5>


            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="online" class="table table-bordered table-striped align-middle" style="width:100%">
                        <thead>
                            <tr>
                                <th>S.No.</th>
                                <th>Application Details</th>
                                <th>Registration Details</th>
                                <!-- <th>Registration Date</th> -->
                                <th>Operator Details</th>
                                <th>Operator Type</th>
                                <!-- <th>Operator Address</th> -->
                                <th>Contact Person Details</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!--end col-->
</div>
<!--end row-->
@endsection

@push('script')
<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

var table = $('#online').DataTable({
    dom: 'Bfrtip',
    pageLength: 25,
    lengthMenu: [
        [5, 5, 5, -1],
        [5, 5, 5, "All"]
    ],
    processing: true,
    serverSide: true,
    ajax: {
        url: '{{ route("superadmin.usermanagement.operatorhome") }}',
        type: 'GET',
        data: function(d) {
            d._token = "{{ csrf_token() }}";
            d.operator_status = $("#search").val();
            // Send operator_status parameter
        }
    },

    columns: [
        {
            data: 'DT_RowIndex',
            name: 'DT_RowIndex',
            orderable: true
        },
        {
            data: 'ref_no',
            name: 'ref_no',
            orderable: true
        },
        
        {
            data: 'reg_no',
            name: 'reg_no',
            orderable: true
        },
    
        {
            data: 'operator_name',
            name: 'operator_name',
            orderable: true
        },
        {
            data: 'operator_type',
            name: 'operator_type',
            orderable: true
        },
    
        {
            data: 'cont_details',
            name: 'cont_details',
            orderable: true
        },

        {
            data: 'action',
            name: 'name',
            orderable: false
        },
    ],
    buttons: [

        // {
        //     extend: 'excelHtml5 ',
        //     title: function() {
        //         return "Online Applications List";
        //     },
        //     titleAttr: 'CSV REPORTS'
        // },
        {
            extend: 'pdfHtml5',
            title: function() {
                return "Online Applications List";
            },
            orientation: 'landscape',
            pageSize: 'A4',
            titleAttr: 'Online Applications List'
        }
    ]
});

$("#search").on('change', function(e) {
    table.ajax.reload(); // Reload the table data
    e.preventDefault();
});

$(document).on('click', '.deletedata', function() {
    var id = $(this).attr('data-value');
    alert(id);
    var deletionReason = $('#deletionReason').val();

    Swal.fire({
        title: 'Are you sure?',
        html: '<input type="text" id="deletionReason" class="swal2-input" placeholder="Enter reason for deletion...">',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                url: '{{ route("superadmin.usermanagement.panaltydelete") }}', // Update with correct route name
                method: "POST",
                dataType: 'json',
                data: {
                    'id': id,
                    'deletionReason': deletionReason,
                    '_token': '{{ csrf_token() }}',
                },
                success: function(result) {
                    Swal.fire('Deleted!', 'Record Deleted Successfully..', 'success')
                        .then((result) => {
                            window.location
                                .reload(); // Reload the page after successful deletion
                        });
                },
                error: function(xhr, status, error) {
                    // Handle error
                }
            });
        }
    });
});


</script>


@endpush

@extends('admin.layouts.app')

@section('content')
    <style>
        .wrapper {
            max-width: 1240px;
            margin: 0 auto;
        }

        .white-bg {
            background-color: white;
            /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
            border-bottom: 5px solid #ff9800;
            margin-bottom: 15px;
        }

        .auth-one-bg .slide .carousel-indicators {
            bottom: 25px;
        }

        .auth-page-wrapper .auth-page-content {
            padding-bottom: 0px !important;
        }

        .auth-page-content .card {
            margin-bottom: 0rem;
        }

        .data-tabs .wrapper .nav-tabs button {
            font-size: 17px;
            color: black;
        }

        .data-tabs .wrapper .nav-tabs .active {
            background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
            */ color: white;
            background: orange;
            border-radius: 0px;
        }

        .carousel-caption.d-none.d-md-block {
            background-color: #000000bf;
            left: 0;
            width: 100%;
            bottom: 0;
        }

        .carousel-indicators {
            display: none;
        }

        .custom-banner-caption {
            color: white !important;
        }

        .announcement-heading {
            font-size: 1.2em;
            font-weight: 600;
        }

        .data-tabs .tab-pane ul li {
            font-size: 1em;
            padding: 5px 0;

        }

        .main-logo {
            padding: 10px;
        }

        .data-tabs .nav-item .nav-link {
            background-image: none;
        }

        /* .right-sec{
        box-shadow: 5px 10px 18px #888888;
    } */
        .navbar-brand-box {
            background: #fff;
        }

        .btn-danger {
            background-color: #40895a;
            border: 1px solid #40895a;
        }

        [data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
            color: white !important;
        }

        .header-buttons .btn-primary {
            margin-right: 10px;
            padding: 6px 15px;
            font-weight: 600;
            background-color: #207005;
            border: none;
            box-shadow: 0px 2px 7px #888888;
        }

        .header-buttons .btn-secondary {
            margin-right: 10px;
            padding: 6px 15px;
            font-weight: 600;
            background-color: #72a055;
            border: none;
            box-shadow: 0px 2px 7px #888888;
        }


        .right-sec {
            border-left: 5px solid #ede7e7;
        }

        .tabdiv {
            background: white;
            padding: 20px;
            margin-top: 10px;
            border: 10px solid #dfdbd5;
        }

        .nav-tabs {
            border-bottom: 0px;
        }

        div#myTabContent {
            border: 1px solid #cccccc;
        }

        .frontfooter footer {
            padding: 20px calc(1.5rem / 2);
            position: static;
            color: #000;
            height: 60px;
            background-color: #f9f9f9;
            margin-top: 30px;
            border-top: 1px solid #e1dfdf;
        }

        span.logo-sm img {
            width: 69px;
        }

        .seperatesec {
            margin-top: 20px;
        }

        .simplebar-content li.nav-item:hover {
            background: #4caf50;
        }

        .sectitle {
            font-size: 14px;
        }

        .required {
            color: red;
        }

        .customtextarea {
            height: 120px;
        }

        ul.boxsection {
            margin: 0;
            padding: 0;
        }

        ul.boxsection li {
            list-style-type: none;
            padding: 7px 0;
            border-bottom: 1px solid #efeded;
        }

        .boxcard .col:nth-child(1) {
            background: #effcfb;
        }

        .boxcard .col:nth-child(2) {
            background: #fdfdfd;
        }

        .boxcard .col:nth-child(3) {
            background: #effcfb;
        }

        .boxcard .col:nth-child(4) {
            background: #fdfdfd;
        }

        .boxcard .col:nth-child(5) {
            background: #effcfb;
        }

        /* --registration-form css  */
        .custom-tab-content {
            padding-top: 0 !important;
            padding-bottom: 0px !important;
        }

        .custom-tab-nav {
            background: white;

        }

        .custom-tab-nav .nav-link {
            border-radius: 0 !important;
            border-bottom: 1px solid #e9ebec;
            border-right: 1px solid #e9ebec;
            font-size: 14px;
            padding: 10px;
        }

        .custom-tab-nav .nav-link.active,
        .custom-tab-nav .show>.nav-link {
            color: rgb(255, 255, 255) !important;
            background-color: #2c8c6d;
            border-bottom: #2c8c6d !important;
            /* border-bottom: #207005 !important; */
            position: relative;
        }

        .custom-tab-nav .nav-link:hover,
        .custom-tab-nav .nav-link:focus {
            border-bottom: 1px solid #207005;
            border-radius: 0;
            font-size: 14px;
            transition: background-color 0.20s linear;
        }

        .custom-tab-nav .nav-link.active:after {
            content: "";
            position: absolute;
            bottom: -16px;
            left: 50%;
            border: 8px solid transparent;
            border-top-color: #2c8c6d;
            z-index: 999;
        }

        .reg-form-btns {
            margin-bottom: 15px;
        }

        .reg-form-btns .btn-secondary {
            color: #fff;
            background-color: #405189;
            border-color: #405189;
        }

        .btn-soft-success:active,
        .btn-soft-success:focus,
        .btn-soft-success:hover {
            border: none;
        }

        .custom-tab-nav ul {
            padding: 0px;
            margin: 0px;
        }

        .custom-tab-nav ul li {
            padding: 0px;
            margin: 0px;
            display: inline-block;
            list-style: none;
        }
    </style>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Wild Harvester Profile / वन फ़सल काटने वाले की प्रोफ़ाइल</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Wild Harvester Profile</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">
            <form method="post" enctype="multipart/form-data" id="registration"
                action="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserStoreStep5', $id) }}">
                @csrf
                <nav>
                    <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                        <a class="nav-link" id="step1-tab"
                            href="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserAdd', $id) }}">General
                            Details</a>
                        <a class="nav-link" id="step2-tab"
                            href="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep2', $id) }}">Bank
                            Details</a>
                        <a class="nav-link" id="step3-tab"
                            href="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep3', $id) }}">Forest
                            Details</a>
                        <a class="nav-link" id="step4-tab"
                            href="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep4', $id) }}">Geo Tagging
                            of Permitted Forest Area</a>
                        <a class="nav-link active" id="step5-tab"
                            href="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep5', $id) }}">Details of
                            Forest Product</a>
                        <a class="nav-link" id="step6-tab"
                            href="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep6', $id) }}">List of
                            Documents</a>
                    </div>
                </nav>
                <div class="tab-content py-4 custom-tab-content">
                    <div class="tab-pane fade show active" id="step5">
                        <div class="card">
                            <!-- <div class="card-header align-items-center d-flex">
                                <h4 class="card-title mb-0 flex-grow-1">
                                    Contact Person Details
                                </h4>

                            </div> -->
                            <!-- end card header -->
                            <div class="card-body">
                                <div class="live-preview">

                                    <div class="row seperatesec white-inner">
                                        <div class="sectitle">
                                            <label for="labelInput" class="form-label">Details of Forest Product/वन उत्पाद का विवरण</label>
                                        </div>
                                        <hr>

                                        <div class="row">
                                            @if (count($productDetails) > 0)
                                                @foreach ($productDetails as $pd)
                                                    @if (!empty($pd))
                                                        <div class="col-md-12" id="row{{ $pd->id }}">
                                                            <input type="text" class="form-control" placeholder="Farm Id"
                                                                value="{{ $pd->id }}" name="row_id[]"
                                                                style="display: none;" />
                                                            <div class="col-md-2 mt-1 p-1" style="float: left;">
                                                                <div class="form-group">
                                                                    <label class="control-label">Forest Area/Land ID<span
                                                                            class="required">*</span></label>
                                                                    <select name="forest_land_id[]"
                                                                        class="form-select" required>
                                                                        <option value="">Select</option>
                                                                        @forelse($permittedDetails as $row)
                                                                            <option value="{{ $row->id }}"
                                                                                {{ $pd->at_wh_forest_details_id == $row->id ? 'selected' : '' }}>
                                                                                {{ $row->area_cultivation }}</option>
                                                                        @empty
                                                                        @endforelse

                                                                    </select>
                                                                    {{-- <input type="text" class="form-control" placeholder="Farm Id"
                                                        name="forest_land_id[]"
                                                        value="{{ $pd->getForestProductDetail->at_wh_forest_details_id ?? '' }}" required> --}}
                                                                </div>
                                                            </div>
                                                            <div class="col-md-2 mt-1 p-1" style="float: left;">
                                                                <div class="form-group">
                                                                    <label class="control-label">Type of Forest Product/वन उत्पाद का प्रकार<span
                                                                            class="required">*</span></label>
                                                                    <input type="text" class="form-control"
                                                                        placeholder="Type of the Forest Product"
                                                                        name="type_of_the_forest_product[]"
                                                                        value="{{ $pd->type_of_the_forest_product ?? '' }}"
                                                                        required>
                                                                </div>
                                                            </div>

                                                            @php
                                                                $productID = getProductBYCBName($cbID->id);
                                                                $refProductIDs = $productID->pluck('ref_product_id')->toArray();
                                                            @endphp
                                                            <div class="col-md-2 mt-1 p-1" style="float: left;">
                                                                <div class="form-group">
                                                                    <label class="control-label">Name of Forest Product/वन उत्पाद का नाम<span
                                                                            class="required">*</span></label>
                                                                    <select class="form-select js-example-basic-single" name="name_of_the_forest_product[]" >
                                                                        <option value="">Select Product</option>
                                                                        @foreach(getRefProduct() as $hscode)
                                                                        @if(in_array($hscode->id, $refProductIDs)) 
                                                                            @continue
                                                                        @endif
                                                                        <option value="{{ $hscode->id }}" @selected($hscode->id==$pd->name_of_the_forest_product)>{{ $hscode->product_name }}</option>
                                                                        
                                                                        @endforeach
                                                                    </select>
                                                                </div>
                                                            </div>

                                                            <div class="col-md-2 mt-1 p-1" style="float: left;">
                                                                <div class="form-group">
                                                                    <label class="control-label">Area Under Cultivation/खेती योग्य क्षेत्र
                                                                        <span class="required">*</span></label>
                                                                    <input type="text" class="form-control"
                                                                        placeholder="Area Under Cultivation "
                                                                        name="area_under_cultivation[]"
                                                                        value="{{ $pd->area_under_cultivation ?? '' }}"
                                                                        required>
                                                                </div>
                                                            </div>
                                                            <!-- <div class="col-md-2 mt-1 p-1" style="float: left;">
                                                                <div class="form-group">
                                                                    <label class="control-label">Photo of Forest product/वन उत्पाद का फोटो
                                                                        @if (isset($pd->forest_product_image) &&
                                                                                !empty($pd->forest_product_image))
                                                                            <a href="{{ asset('public/research/uploads/' . $pd->forest_product_image ?? '') }}"
                                                                                target="_blank">View Image</a>
                                                                        @endif
                                                                    </label>
                                                                    <input type="file" class="form-control upload_document1"
                                                                        name="photo_of_forest_product[]" />
                                                                        <span class="form-text">Supported formats:jpg, jpeg. Upto 1MB</span>

                                                                </div>
                                                            </div> -->
                                                            <div class="col-md-2 mt-1 p-1" style="float: left;">
                                                                <div class="form-group">
                                                                    <label class="control-label">Organic Status </label>
                                                                    {{-- <input type="text" class="form-control"
                                                                        placeholder="Organic Status "
                                                                        name="details_organic_status[]"
                                                                        value="{{ $pd->getForestProductDetail->organic_status ?? '' }}" /> --}}
                                                                    <select class="form-select hscode" name="details_organic_status[]" >
                                                                        <option value="">Select Status</option>
                                                                        @foreach(getRefOrganicStatusMaster() as $sts)
                                                                        <option value="{{ $sts->id }}" @selected($sts->id==$pd->organic_status)>{{ $sts->organic_status }}</option>
                                                                        @endforeach
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-1 mt-1 p-1" style="float: right;">
                                                                    <div class="form-group change-details">
                                                                        <label for="">&nbsp;</label><br />
                                                                        <a class="btn btn-success add-more-details"><i
                                                                                class="ri-add-line"></i></a>
                                                                    </div>
                                                                </div>
                                                            
                                                            <!-- <div class="col-md-11 mt-1 p-1" style="float: left;">
                                                                <div class="form-group">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-1 mt-1 p-1" style="float: left;">
                                                                <div class="form-group">
                                                                    <label for="">&nbsp;</label><br />
                                                                    <a class="btn btn-danger" href="javascript:;"
                                                                        onclick="confirmDelete('{{ $pd->id }}')"><i
                                                                            class="ri-close-line"></i></a>
                                                                </div>
                                                            </div> -->
                                                        </div>
                                                    @endif
                                                @endforeach
                                            @endif
                                            <div class="after-add-more-details">
                                                <div class="col-md-2 mt-1 p-1" style="float: left;">
                                                    <div class="form-group">
                                                        <label class="control-label">Forest Area/Land ID</label>
                                                        {{-- <input type="text" class="form-control" placeholder="Farm Id"
                                                        name="forest_land_id[]" /> --}}
                                                        <select name="forest_land_id[]" class="form-select" >
                                                            <option value="">Select</option>
                                                            @forelse($permittedDetails as $row)
                                                                <option value="{{ $row->id }}">
                                                                    {{ $row->area_cultivation }}</option>
                                                            @empty
                                                            @endforelse
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-2 mt-1 p-1" style="float: left;">
                                                    <div class="form-group">
                                                        <label class="control-label">Type of Forest Product/वन उत्पाद का प्रकार</label>
                                                        <input type="text" class="form-control"
                                                            placeholder="Type of the Forest Product"
                                                            name="type_of_the_forest_product[]" />
                                                    </div>
                                                </div>
                                                @php
                                                    $productID = getProductBYCBName($cbID->id);
                                                    $refProductIDs = $productID->pluck('ref_product_id')->toArray();
                                                @endphp
                                                <div class="col-md-2 mt-1 p-1" style="float: left;">
                                                    <div class="form-group">
                                                        <label class="control-label">Name of Forest Product/वन उत्पाद का नाम</label>
                                                        
                                                        <select class="form-select js-example-basic-single" name="name_of_the_forest_product[]" >
                                                            <option value="">Select Product</option>
                                                            @foreach(getRefProduct() as $hscode)
                                                            @if(in_array($hscode->id, $refProductIDs)) 
                                                                @continue
                                                            @endif
                                                            <option value="{{ $hscode->id }}">{{ $hscode->product_name }}</option>
                                                            @endforeach
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-2 mt-1 p-1" style="float: left;">
                                                    <div class="form-group">
                                                        <label class="control-label">खेती योग्य क्षेत्र/Area Under Cultivation </label>
                                                        <input type="text" class="form-control"
                                                            placeholder="Area in Hactare "
                                                            name="area_under_cultivation[]" />
                                                    </div>
                                                </div>
                                                <!-- <div class="col-md-2 mt-1 p-1" style="float: left;">
                                                    <div class="form-group">
                                                        <label class="control-label">वन उत्पाद का फोटो/Photo of Forest product</label>
                                                        <input type="file" class="form-control upload_document1"
                                                            name="photo_of_forest_product[]" />
                                                            <span class="form-text">Supported formats:jpg, jpeg. Upto 1MB</span>
                                                    </div>
                                                </div> -->

                                                <div class="col-md-2 mt-1 p-1" style="float: left;">
                                                    <div class="form-group">
                                                        <label class="control-label">Organic Status </label>
                                                        {{-- <input type="text" class="form-control"
                                                            placeholder="Organic Status "
                                                            name="details_organic_status[]" /> --}}
                                                        <select class="form-select hscode" name="details_organic_status[]" >
                                                            <option value="">Select Status</option>
                                                            @foreach(getRefOrganicStatusMaster() as $sts)
                                                            <option value="{{ $sts->id }}">{{ $sts->organic_status }}</option>
                                                            @endforeach
                                                        </select>
                                                    </div>
                                                </div>
                                                <!-- <div class="col-md-11 mt-1 p-1" style="float: left;">
                                                    <div class="form-group">
                                                    </div>
                                                </div> -->
                                                <div class="col-md-1 mt-1 p-1" style="float: right;">
                                                    <div class="form-group change-details">
                                                        <label for="">&nbsp;</label><br />
                                                        <a class="btn btn-success add-more-details"><i
                                                                class="ri-add-line"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12 gy-4">
                                                <div class="hstack gap-2">
                                                    <a href="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep4', $id) }}"
                                                        class="btn btn-soft-secondary">
                                                        Back
                                                    </a>
                                                    <button type="submit" class="btn btn-primary">
                                                        Save
                                                    </button>
                                                    <a href="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep6', $id) }}"
                                                        class="btn btn-soft-success">
                                                        Next
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>





                                </div>
                            </div>
                        </div>
                    </div>
            </form>
        </div>
    </div>



@endsection
@push('script')
    <script>
        function confirmDelete(id) {
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.value) {
                    $.ajax({
                        url: "{{ route('superadmin.usermanagement.deptUser.wildHarvestDeleteForestProduct') }}",
                        method: "POST",
                        dataType: 'json',
                        data: {
                            'id': id,
                        },
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function(result) {
                            $('#row' + id).remove();
                            Swal.fire(
                                'Deleted!',
                                'Record Deleted Successfully..',
                                'success'
                            );

                        }
                    });

                }
            })
        }

        $(document).ready(function() {
            $("body").on("click", ".add-more-details", function() {
                var html = $(".after-add-more-details").first().clone();
                $(html).find(".change-details").html(
                    "<label for=''>&nbsp;</label><br/><a class='btn btn-danger remove-details'><i class='ri-close-line'></i></a>"
                );
                $(".after-add-more-details").last().after(html);
            });

            $("body").on("click", ".remove-details", function() {
                $(this).parents(".after-add-more-details").remove();
            });
        });



        $('.upload_document1').on('change', function() {
    var $this = $(this);
    var file = $this[0].files[0];
    var fileType = file.type;
    var fileSize = file.size;
    var allowedTypes = ['image/jpeg', 'image/jpg'];

    // Check for file type
    if (!allowedTypes.includes(fileType)) {
        Swal.fire({
            icon: 'error',
            title: 'Invalid File Extension',
            text: 'Please upload JPEG, JPG only.',
        });
        $this.val("");
        return false;
    }

    // Check for file size (1 MB = 1,048,576 bytes)
    if (fileSize > 1048576) {
        Swal.fire({
            icon: 'error',
            title: 'File Size Too Large',
            text: 'Please upload files of size 1 MB or less only.',
        });
        $this.val("");
        return false;
    }
});


$(document).ready(function() {
    $('.js-example-basic-single').select2();
});


    </script>
@endpush

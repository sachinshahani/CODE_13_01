@extends('admin.layouts.app')

@section('content')
<style>
    .wrapper {
        max-width: 1240px;
        margin: 0 auto;
    }

    .white-bg {
        background-color: white;
        /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
        border-bottom: 5px solid #ff9800;
        margin-bottom: 15px;
    }

    .auth-one-bg .slide .carousel-indicators {
        bottom: 25px;
    }

    .auth-page-wrapper .auth-page-content {
        padding-bottom: 0px !important;
    }

    .auth-page-content .card {
        margin-bottom: 0rem;
    }

    .data-tabs .wrapper .nav-tabs button {
        font-size: 17px;
        color: black;
    }

    .data-tabs .wrapper .nav-tabs .active {
        background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
        */ color: white;
        background: orange;
        border-radius: 0px;
    }

    .carousel-caption.d-none.d-md-block {
        background-color: #000000bf;
        left: 0;
        width: 100%;
        bottom: 0;
    }

    .carousel-indicators {
        display: none;
    }

    .custom-banner-caption {
        color: white !important;
    }

    .announcement-heading {
        font-size: 1.2em;
        font-weight: 600;
    }

    .data-tabs .tab-pane ul li {
        font-size: 1em;
        padding: 5px 0;

    }

    .main-logo {
        padding: 10px;
    }

    .data-tabs .nav-item .nav-link {
        background-image: none;
    }

    /* .right-sec{
    box-shadow: 5px 10px 18px #888888;
} */
    .navbar-brand-box {
        background: #fff;
    }

    /* .btn-danger {
        background-color: #40895a;
        border: 1px solid #40895a;
    } */

    [data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
        color: white !important;
    }

    .header-buttons .btn-primary {
        margin-right: 10px;
        padding: 6px 15px;
        font-weight: 600;
        background-color: #207005;
        border: none;
        box-shadow: 0px 2px 7px #888888;
    }

    .header-buttons .btn-secondary {
        margin-right: 10px;
        padding: 6px 15px;
        font-weight: 600;
        background-color: #72a055;
        border: none;
        box-shadow: 0px 2px 7px #888888;
    }


    .right-sec {
        border-left: 5px solid #ede7e7;
    }

    .tabdiv {
        background: white;
        padding: 20px;
        margin-top: 10px;
        border: 10px solid #dfdbd5;
    }

    .nav-tabs {
        border-bottom: 0px;
    }

    div#myTabContent {
        border: 1px solid #cccccc;
    }

    .frontfooter footer {
        padding: 20px calc(1.5rem / 2);
        position: static;
        color: #000;
        height: 60px;
        background-color: #f9f9f9;
        margin-top: 30px;
        border-top: 1px solid #e1dfdf;
    }

    span.logo-sm img {
        width: 69px;
    }

    .seperatesec {
        margin-top: 20px;
    }

    .simplebar-content li.nav-item:hover {
        background: #4caf50;
    }

    .sectitle {
        font-size: 14px;
    }

    .required {
        color: red;
    }

    .customtextarea {
        height: 120px;
    }

    ul.boxsection {
        margin: 0;
        padding: 0;
    }

    ul.boxsection li {
        list-style-type: none;
        padding: 7px 0;
        border-bottom: 1px solid #efeded;
    }

    .boxcard .col:nth-child(1) {
        background: #effcfb;
    }

    .boxcard .col:nth-child(2) {
        background: #fdfdfd;
    }

    .boxcard .col:nth-child(3) {
        background: #effcfb;
    }

    .boxcard .col:nth-child(4) {
        background: #fdfdfd;
    }

    .boxcard .col:nth-child(5) {
        background: #effcfb;
    }

    /* --registration-form css  */
    .custom-tab-content {
        padding-top: 0 !important;
        padding-bottom: 0px !important;
    }

    .custom-tab-nav {
        background: white;

    }

    .custom-tab-nav .nav-link {
        border-radius: 0 !important;
        border-bottom: 1px solid #e9ebec;
        border-right: 1px solid #e9ebec;
        font-size: 14px;
        padding: 10px;
    }

    .custom-tab-nav .nav-link.active,
    .custom-tab-nav .show>.nav-link {
        color: rgb(255, 255, 255) !important;
        background-color: #2c8c6d;
        border-bottom: #2c8c6d !important;
        /* border-bottom: #207005 !important; */
        position: relative;
    }

    .custom-tab-nav .nav-link:hover,
    .custom-tab-nav .nav-link:focus {
        border-bottom: 1px solid #207005;
        border-radius: 0;
        font-size: 14px;
        transition: background-color 0.20s linear;
    }

    .custom-tab-nav .nav-link.active:after {
        content: "";
        position: absolute;
        bottom: -16px;
        left: 50%;
        border: 8px solid transparent;
        border-top-color: #2c8c6d;
        z-index: 999;
    }

    .reg-form-btns {
        margin-bottom: 15px;
    }

    .reg-form-btns .btn-secondary {
        color: #fff;
        background-color: #405189;
        border-color: #405189;
    }

    .btn-soft-success:active,
    .btn-soft-success:focus,
    .btn-soft-success:hover {
        border: none;
    }

    .custom-tab-nav ul {
        padding: 0px;
        margin: 0px;
    }

    .custom-tab-nav ul li {
        padding: 0px;
        margin: 0px;
        display: inline-block;
        list-style: none;
    }
</style>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">व्यक्तिगत निर्माता प्रोफ़ाइल/Individual Producer Profile</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Individual Producer Profile</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <form method="post" enctype="multipart/form-data" id="registration" action="{{route('superadmin.usermanagement.deptUser.individualUserStoreStep5',$id)}}">
            @csrf
            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                    <a class="nav-link" id="step1-tab" href="{{ route('superadmin.usermanagement.deptUser.individualUserAdd', [$id]) }}">General Details</a>
                    <a class="nav-link" id="step2-tab" href="{{ route('superadmin.usermanagement.deptUser.individualUserAddStep2', [$id]) }}">Bank Details</a>
                    <a class="nav-link" id="step3-tab" href="{{ route('superadmin.usermanagement.deptUser.individualUserAddStep3', [$id]) }}">Geo Tagging of Farm Details</a>
                    <a class="nav-link" id="step4-tab" href="{{ route('superadmin.usermanagement.deptUser.individualUserAddStep4', [$id]) }}">Details of standing Crop</a>
                    <a class="nav-link active" id="step5-tab" href="{{ route('superadmin.usermanagement.deptUser.individualUserAddStep5', [$id]) }}">Details of Proposed Crop</a>
                    <a class="nav-link" id="step6-tab" href="{{ route('superadmin.usermanagement.deptUser.individualUserAddStep6', [$id]) }}">List of Documents</a>
                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step5">
                    <div class="card">
                        <!-- <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1">
                                Contact Person Details
                            </h4>

                        </div> -->
                        <!-- end card header -->
                        <div class="card-body">
                            <div class="live-preview">

                            <div class="row seperatesec white-inner">
                                <div class="sectitle">
                                    <input type="hidden" name="ref_operator_id" value="3">
                                    <label for="labelInput" class="form-label">प्रस्तावित फसल का विवरण/Details of Proposed Crop </label>
                                </div>
                                <hr>
                                <div class="row">
                                    @if(count($proposed_corps) > 0)
                                        @foreach ($proposed_corps as $pc)
                                            @if (!empty($pc))
                                                <div class="table-responsive col-md-12" id="row{{ $pc->id }}">
                                                    <input type="text" class="form-control" placeholder="Farm Id" value="{{ $pc->id }}" name="row_id[]" style="display: none;"/>
                                                    <div class=" mt-1 p-2" style="float: left;">                                
                                                        <div class="form-group">
                                                            <label class="control-label">फार्म का नाम/Farm Name</label>

                                                            <select name="details_farm_id[]" class="form-select">
                                                                <option value="">Select</option>
                                                                @foreach($farm_detail as $row)
                                                                    <option value="{{ $row->id }}" @if($pc->at_ip_farm_details_id == $row->id) selected @endif>{{ $row->farm_name }}</option>
                                                                @endforeach
                                                            </select>
                                                        </div>
                                                    </div>
                                                    @php
                                                       // $productID = getProductBYCBName($cbID->id);
                                                       // $refProductIDs = $productID->pluck('ref_product_id')->toArray();
                                                       
                                                    @endphp

                                                    <div class="col-md-3 mt-1 p-2" style="float: left;">                                
                                                        <div class="form-group">
                                                        <label class="form-label">उत्पाद का एचएस कोड/HSN Code of the Product<span class="required"> *</span></label>
                                                        <select class="form-select hscode js-example-basic-single"  name="ref_hscode_id[]" onchange="getHscodeProduct(this)">
                                                            <option value="">--Select--</option>
                                                            @forelse(getRefProduct() as $hscode)
                                                            <option value="{{ $hscode->id }}" data-name="{{ $hscode->product_name }}" data-des="{{ $hscode->hscode_description }}"  {{ $pc->ref_hscode_id == $hscode->id ? 'selected' : '' }}>
                                                                {{ $hscode->hs_code }} - {{ $hscode->product_name }} </option>
                                                            @empty
                                                            @endforelse
                                                        </select>
                                                        </div>
                                                    </div>



                                                    <div class=" mt-1 p-2" style="float: left;">
                                                        <div class="form-group">
                                                            <label class="control-label">फसल का नाम/Name of the Crop</label>
                                                            <input type="text" class="form-control" placeholder="Name of the Crop" name="details_name_of_corp[]" value="{{ $pc->details_name_of_corp }}"/>
                                                        </div>
                                                    </div>
                                                    <div class=" mt-1 p-2" style="float: left;">
                                                        <div class="form-group">
                                                            {{-- {{  $pc->season_name}} --}}
                                                            <label class="control-label">ऋतु का नाम/Name of Season</label>
                                                            <select name="details_name_of_season[]" class="form-select">
                                                                <option value="">Select</option>
                                                                <option value="Rabi" @if($pc->season_name == 'Rabi') selected @endif>Rabi</option>
                                                                <option value="Khariff" @if($pc->season_name == 'Khariff') selected @endif>Khariff</option>
                                                                <option value="Zaid" @if($pc->season_name == 'Zaid') selected @endif>Zaid</option>
                                                               
                                                            </select>
                                                            {{-- <input type="text" class="form-control" placeholder="Name of Season" name="details_name_of_season[]" value="{{ $pc->season_name }}"/> --}}
                                                        </div>
                                                    </div>
                                                    <div class="mt-1 p-2" style="float: left;">
                                                        <div class="form-group">
                                                            <label class="control-label">क्षेत्र/Area </label>
                                                            <input type="text" class="form-control numbersonly" placeholder="Area " name="details_area[]" value="{{ $pc->area }}" />
                                                        </div>
                                                    </div>
                                                    <div class=" mt-1 p-2" style="float: left;">
                                                        <div class="form-group">
                                                            <label class="control-label">जैविक स्थिति/Organic Status </label>
                                                            {{-- <input type="text" class="form-control" placeholder="Organic Status " name="details_organic_status[]" value="{{ $pc->organic_status }}"/> --}}
                                                            <select name="details_organic_status[]" class="form-select">
                                                                <option value="">Select</option>
                                                                @foreach (getRefOrganicStatusMaster() as $row)
                                                                <option value="{{ $row->id }}" @if($pc->organic_status == $row->id ) selected @endif>{{ $row->organic_status }}</option> 
                                                                @endforeach
                                                                
                                                               
                                                            </select>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class=" mt-1 p-1" style="float: right;">
                                                        <div class="form-group change-details">
                                                            <label for="">&nbsp;</label><br/>
                                                            <a class="btn btn-danger" href="javascript:;" onclick="confirmDelete('{{$pc->id}}')"><i class="ri-close-line"></i></a>
                                                        </div>
                                                    </div>
                                                </div> 
                                            @endif
                                        @endforeach
                                    @endif
                                    <div class="table-responsive after-add-more-details">
                                        <div class=" mt-1 p-2" style="float: left;">                                
                                            <div class="form-group">
                                                <label class="control-label">फार्म का नाम/Farm Name</label>
                                                <select name="details_farm_id[]" class="form-select">
                                                    <option value="">Select</option>
                                                    @foreach($farm_detail as $row)
                                                        <option value="{{ $row->id }}">{{ $row->farm_name }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        @php
                                               // $productID = getProductBYCBName($cbID->id);
                                               // $refProductIDs = $productID->pluck('ref_product_id')->toArray();
                                                
                                        @endphp

                                        <div class="col-md-3 mt-1 p-2" style="float: left;">                                
                                            <div class="form-group">
                                               <label class="form-label">उत्पाद का एचएस कोड/HSN Code of the Product<span class="required"> *</span></label>
										    <select class="form-select hscode js-example-basic-single" name="ref_hscode_id[]" onchange="getHscodeProduct(this)">
                                                <option value="">--Select--</option>
                                                @forelse(getRefProduct() as $hscode)
                                               
                                                <option value="{{ $hscode->id }}" data-name="{{ $hscode->product_name }}" data-des="{{ $hscode->hscode_description }}">
                                                    {{ $hscode->hs_code }}  - {{ $hscode->product_name }}</option>
                                                @empty
                                                @endforelse
                                            </select>
                                            </div>
                                        </div>



                                        <div class=" mt-1 p-2" style="float: left;">
                                            <div class="form-group">
                                                <label class="control-label">फसल का नाम/Name of the Crop</label>
                                                <input type="text" class="form-control" placeholder="Name of the Crop" name="details_name_of_corp[]" />
                                            </div>
                                        </div>
                                        <div class=" mt-1 p-2" style="float: left;">
                                            <div class="form-group">
                                                <label class="control-label">ऋतु का नाम/Name of Season</label>
                                                {{-- <input type="text" class="form-control" placeholder="Name of Season" name="details_name_of_season[]" /> --}}
                                                <select name="details_name_of_season[]" class="form-select">
                                                    <option value="">Select</option>
                                                    <option value="Rabi" >Rabi</option>
                                                    <option value="Khariff" >Khariff</option>
                                                    <option value="Zaid" >Zaid</option>
                                                   
                                                </select>
                                            </div>
                                        </div>
                                        <div class="mt-1 p-2" style="float: left;">
                                            <div class="form-group">
                                                <label class="control-label">क्षेत्र/Area </label>
                                                <input type="text" class="form-control" placeholder="Area " name="details_area[]"  oninput="this.value = formatInput(this.value)"/>
                                            </div>
                                        </div>
                                        
                                        <div class=" mt-1 p-1" style="float: left;">
                                            <div class="form-group">
                                                <label class="control-label">जैविक स्थिति/Organic Status </label>
                                                {{-- <input type="text" class="form-control" placeholder="Organic Status " name="details_organic_status[]" /> --}}
                                                <select name="details_organic_status[]" class="form-select">
                                                    <option value="">Select</option>
                                                    @foreach (getRefOrganicStatusMaster() as $row)
                                                    <option value="{{ $row->id }}" >{{ $row->organic_status }}</option> 
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                       
                                        <div class="mt-1 p-1" style="float: right;">
                                            <div class="form-group change-details">
                                                <label for="">&nbsp;</label><br/>
                                                <a class="btn btn-success add-more-details"><i class="ri-add-line"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                        <div class="col-lg-12 gy-4">
                                            <div class="hstack gap-2">
                                                <a href="{{route('superadmin.usermanagement.deptUser.individualUserAddStep4',$id)}}" class="btn btn-soft-secondary">
                                                    Back
                                                </a>
                                                <button type="submit" class="btn btn-primary">
                                                    Submit
                                                </button>
                                                <a href="{{route('superadmin.usermanagement.deptUser.individualUserAddStep6',$id)}}" class="btn btn-soft-success">
                                                    Next
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                            </div>
                                    




                            </div>
                        </div>
                    </div>
                </div>
        </form>
    </div>
</div>



@endsection
@push('script')

<script>

function getHscodeProduct(th) {
        //alert(th.value);
        //var ref_id = $(this).val();
        var name = $('option:selected',th).data("name");
        var des = $('option:selected',th).data("des");
        $(th).parent().parent().parent().find('input[name="ref_product_id[]"]').val(th.value);
        $(th).parent().parent().parent().find('input[name="details_name_of_corp[]"]').val(name);
        $(th).parent().parent().parent().find('input[name="product_description[]"]').val(des);


    }





    function confirmDelete(id) {
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.value) {
                $.ajax({
                    url: "{{ route('superadmin.usermanagement.deptUser.individualUserDeleteProposedCorp') }}",
                    method: "POST",
                    dataType: 'json',
                    data: {
                        'id': id,
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(result) {
                        $('#row'+id).remove();
                        Swal.fire(
                            'Deleted!',
                            'Record Deleted Successfully..',
                            'success'
                        );
                            
                    }
                });
            
            }
        })
    }

    $(document).ready(function() {
        $("body").on("click",".add-more-details",function(){ 
            var html = $(".after-add-more-details").first().clone().find("input").val("").end();
            $(html).find(".change-details").html("<label for=''>&nbsp;</label><br/><a class='btn btn-danger remove-details'><i class='ri-close-line'></i></a>");
            $(".after-add-more-details").last().after(html);
        });

        $("body").on("click",".remove-details",function(){ 
            $(this).parents(".after-add-more-details").remove();
        });
    });
</script>
<script>
function formatInput(value) {
  // Remove all non-numeric characters except for the dot
  value = value.replace(/[^0-9.]/g, '');

  // Ensure only one dot is allowed
  const dotCount = (value.match(/\./g) || []).length;
  if (dotCount > 1) {
    value = value.replace(/\.+$/, '');  // Remove extra dots if more than 1
  }

  // Limit digits after the dot to 3
  const parts = value.split('.');
  if (parts.length > 1) {
    parts[1] = parts[1].substring(0, 3);  // Limit to 3 digits after the dot
    value = parts.join('.');
  }

  return value;
}


$(document).ready(function() {
    $('.js-example-basic-single').select2();
});

</script>

@endpush
@extends('admin.layouts.app')

@section('content')
<style>
    .wrapper {
        max-width: 1240px;
        margin: 0 auto;
    }

    .white-bg {
        background-color: white;
        /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
        border-bottom: 5px solid #ff9800;
        margin-bottom: 15px;
    }

    .auth-one-bg .slide .carousel-indicators {
        bottom: 25px;
    }

    .auth-page-wrapper .auth-page-content {
        padding-bottom: 0px !important;
    }

    .auth-page-content .card {
        margin-bottom: 0rem;
    }

    .data-tabs .wrapper .nav-tabs button {
        font-size: 17px;
        color: black;
    }

    .data-tabs .wrapper .nav-tabs .active {
        background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
        */ color: white;
        background: orange;
        border-radius: 0px;
    }

    .carousel-caption.d-none.d-md-block {
        background-color: #000000bf;
        left: 0;
        width: 100%;
        bottom: 0;
    }

    .carousel-indicators {
        display: none;
    }

    .custom-banner-caption {
        color: white !important;
    }

    .announcement-heading {
        font-size: 1.2em;
        font-weight: 600;
    }

    .data-tabs .tab-pane ul li {
        font-size: 1em;
        padding: 5px 0;

    }

    .main-logo {
        padding: 10px;
    }

    .data-tabs .nav-item .nav-link {
        background-image: none;
    }

    /* .right-sec{
    box-shadow: 5px 10px 18px #888888;
} */
    .navbar-brand-box {
        background: #fff;
    }

    .btn-danger {
        background-color: #40895a;
        border: 1px solid #40895a;
    }

    [data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
        color: white !important;
    }

    .header-buttons .btn-primary {
        margin-right: 10px;
        padding: 6px 15px;
        font-weight: 600;
        background-color: #207005;
        border: none;
        box-shadow: 0px 2px 7px #888888;
    }

    .header-buttons .btn-secondary {
        margin-right: 10px;
        padding: 6px 15px;
        font-weight: 600;
        background-color: #72a055;
        border: none;
        box-shadow: 0px 2px 7px #888888;
    }


    .right-sec {
        border-left: 5px solid #ede7e7;
    }

    .tabdiv {
        background: white;
        padding: 20px;
        margin-top: 10px;
        border: 10px solid #dfdbd5;
    }

    .nav-tabs {
        border-bottom: 0px;
    }

    div#myTabContent {
        border: 1px solid #cccccc;
    }

    .frontfooter footer {
        padding: 20px calc(1.5rem / 2);
        position: static;
        color: #000;
        height: 60px;
        background-color: #f9f9f9;
        margin-top: 30px;
        border-top: 1px solid #e1dfdf;
    }

    span.logo-sm img {
        width: 69px;
    }

    .seperatesec {
        margin-top: 20px;
    }

    .simplebar-content li.nav-item:hover {
        background: #4caf50;
    }

    .sectitle {
        font-size: 14px;
    }

    .required {
        color: red;
    }

    .customtextarea {
        height: 120px;
    }

    ul.boxsection {
        margin: 0;
        padding: 0;
    }

    ul.boxsection li {
        list-style-type: none;
        padding: 7px 0;
        border-bottom: 1px solid #efeded;
    }

    .boxcard .col:nth-child(1) {
        background: #effcfb;
    }

    .boxcard .col:nth-child(2) {
        background: #fdfdfd;
    }

    .boxcard .col:nth-child(3) {
        background: #effcfb;
    }

    .boxcard .col:nth-child(4) {
        background: #fdfdfd;
    }

    .boxcard .col:nth-child(5) {
        background: #effcfb;
    }

    /* --registration-form css  */
    .custom-tab-content {
        padding-top: 0 !important;
        padding-bottom: 0px !important;
    }

    .custom-tab-nav {
        background: white;

    }

    .custom-tab-nav .nav-link {
        border-radius: 0 !important;
        border-bottom: 1px solid #e9ebec;
        border-right: 1px solid #e9ebec;
        font-size: 14px;
        padding: 10px;
    }

    .custom-tab-nav .nav-link.active,
    .custom-tab-nav .show>.nav-link {
        color: rgb(255, 255, 255) !important;
        background-color: #2c8c6d;
        border-bottom: #2c8c6d !important;
        /* border-bottom: #207005 !important; */
        position: relative;
    }

    .custom-tab-nav .nav-link:hover,
    .custom-tab-nav .nav-link:focus {
        border-bottom: 1px solid #207005;
        border-radius: 0;
        font-size: 14px;
        transition: background-color 0.20s linear;
    }

    .custom-tab-nav .nav-link.active:after {
        content: "";
        position: absolute;
        bottom: -16px;
        left: 50%;
        border: 8px solid transparent;
        border-top-color: #2c8c6d;
        z-index: 999;
    }

    .reg-form-btns {
        margin-bottom: 15px;
    }

    .reg-form-btns .btn-secondary {
        color: #fff;
        background-color: #405189;
        border-color: #405189;
    }

    .btn-soft-success:active,
    .btn-soft-success:focus,
    .btn-soft-success:hover {
        border: none;
    }

    .custom-tab-nav ul {
        padding: 0px;
        margin: 0px;
    }

    .custom-tab-nav ul li {
        padding: 0px;
        margin: 0px;
        display: inline-block;
        list-style: none;
    }
</style>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0"> वन फ़सल काटने वाले की प्रोफ़ाइल/Wild Harvester Profile</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Wild Harvester Profile</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <form method="post" enctype="multipart/form-data" id="registration" action="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserStoreStep3',$id) }}">
            <input type="hidden" name="ref_operator_type_id" value="{{$harvester->ref_operator_type_id}}">
            @csrf
          
            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                    <a class="nav-link" id="step1-tab" href="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserAdd',$id) }}">General Details</a>
                    <a class="nav-link" id="step2-tab" href="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep2',$id) }}">Bank Details</a>
                    <a class="nav-link active" id="step3-tab" href="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep3',$id) }}">Forest Details</a>
                    <a class="nav-link" id="step4-tab" href="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep4',$id) }}">Geo Tagging of Permitted Forest Area</a>
                    <a class="nav-link" id="step5-tab" href="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep5',$id) }}">Details of Forest Product</a>
                    <a class="nav-link" id="step6-tab" href="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep6',$id) }}">List of Documents</a>
                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step3">
                    <div class="card">
                        <!-- <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1">
                                Contact Person Details
                            </h4>

                        </div> -->
                        <!-- end card header -->
                        <div class="card-body">
                            <div class="live-preview">

                                <div class="row seperatesec white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label blue-ht">वन विवरण/Forest Details</label>
                                    </div>
                                    <hr>
                                    <div class="col-xxl-4 col-md-4 mt-1">
                                        <div>
                                            <label class="form-label">खेत/फसल क्षेत्र का  विवरण/Enter Area Details Under Cultivation<span class="required">*</span></label>
                                            <input type="text" class="form-control" id="area_in_hectars" placeholder="Area in Hectare" name="area_in_hectars" value="{{ $forestDetail->getWildHarvesterDetail->area_cultivation ?? '' }}" required oninput="this.value=this.value.replace(/[^0-9.]/g, '')">
                                        </div>
                                    </div>
                                    <div class="col-xxl-4 col-md-4 mt-1">
                                        <div>
                                            <label class="form-label">एमओयू/वन परमिट संख्या/MoU/Forest Permit Number<span class="required">*</span></label>
                                            <input type="number" class="form-control" id="mou_permit_no" placeholder="MoU/Forest PermitNumber" name="mou_permit_no" value="{{   $forestDetail->getWildHarvesterDetail->mou_permit_no ?? '' }}"  required oninput="this.value=this.value.replace(/[^0-9.]/g, '')">
                                        </div>
                                    </div>
                                    <div class="col-xxl-4 col-md-4 mt-1">
                                        <div>
                                            <label class="form-label">एमओयू/वन परमिट संख्या वैधता की तारीख/MoU/Forest Permit Number Valid up to <span class="required">*</span></label>
                                            <input type="date" class="form-control" id="forest_permit_number_up_to" placeholder="MoU/Forest Permit Number Valid up to" name="forest_permit_number_up_to" value="{{$forestDetail->getWildHarvesterDetail->permit_no_valid_upto ?? '' }}" required>
                                        </div>
                                    </div>
                                </div>

                                <div class="row seperatesec white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label">पता/Address</label>
                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="col-xxl-3 col-md-3 mt-1">
                                            <div>
                                                <label for="labelInput" class="form-label">राज्य/State <span class="required">*</span></label>
                                                
                                                    <select class="form-select state" name="state" required>
                                                        <option value="">Select State</option>
                                                        @if(isset($states))
                                                            @forelse($states as $state)
                                                               <option value="{{$state->id}}" {{ (isset($forestDetail->getWildHarvesterDetail->ref_state_id) &&$forestDetail->getWildHarvesterDetail->ref_state_id) == $state->id ? 'selected' : '' }}>{{$state->state_name}}</option>
                                                            @empty
                                                            @endforelse
                                                        @endif
                                                    </select>
                                                
                                            </div>
                                        </div>
                                       <!-- <div class="col-xxl-3 col-md-3 mt-1" >
                                            <div>
                                                <label class="form-label">Circle/क्षेत्र <span class="required">*</span></label>
                                                <input type="text" class="form-control" id="circle" placeholder="Circle" name="circle" value="{{$forestDetail->getWildHarvesterDetail->circle ?? '' }}" required>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 mt-1">
                                            <div>
                                                <label class="form-label">Division/विभाजन <span class="required">*</span></label>
                                                <input type="text" class="form-control" id="division" required placeholder="Division" name="division" value="{{  $forestDetail->getWildHarvesterDetail->division ?? '' }}">
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 mt-1">
                                            <div>
                                                <label class="form-label">Sub Division/उप विभाजन <span class="required">*</span></label>
                                                <input type="text" class="form-control" id="sub_division" required placeholder="Sub Division" name="sub_division" value="{{  $forestDetail->getWildHarvesterDetail->sub_division ?? '' }}">
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 mt-1">
                                            <div>
                                                <label class="form-label">Range/सीमा  <span class="required">*</span></label>
                                                <input type="text" class="form-control" id="range" placeholder="Range" required name="range" value="{{  $forestDetail->getWildHarvesterDetail->range ?? '' }}">
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 mt-1">
                                            <div>
                                                <label class="form-label">Sub Range/उप सीमा<span class="required">*</span></label>
                                                <input type="text" class="form-control" id="sub_range" required placeholder="Sub Range" name="sub_range" value="{{  $forestDetail->getWildHarvesterDetail->sub_range ?? '' }}">
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 mt-1">
                                            <div>
                                                <label class="form-label">Beat/बीट<span class="required">*</span></label>
                                                <input type="text" class="form-control" id="beat" required placeholder="Beat" name="beat" value="{{ $forestDetail->getWildHarvesterDetail->beat ?? '' }}">
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 mt-1">
                                            <div>
                                                <label class="form-label">Compartment No./कम्पार्टमेंट संख्या<span class="required">*</span></label>
                                                <input type="text" class="form-control" id="compartment_no" required placeholder="Compartment No." name="compartment_no" value="{{$forestDetail->getWildHarvesterDetail->compartment_no ?? '' }}">
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 mt-1">
                                            <div>
                                                <label class="form-label">Latitude/चौड़ाई (लैटिट्यूड)<span class="required">*</span></label>
                                                <input type="text" class="form-control" id="latitude" required placeholder="Latitude" name="latitude" value="{{$forestDetail->getWildHarvesterDetail->latitude ?? '' }}">
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 mt-1">
                                            <div>
                                                <label class="form-label">Longitude/लम्बाई (लान्जिटूड)<span class="required">*</span></label>
                                                <input type="text" class="form-control" id="longitude" required placeholder="Longitude" name="longitude" value="{{ $forestDetail->getWildHarvesterDetail->longitude ?? '' }}">
                                            </div>
                                        </div> -->
										
										
										
										
										
										
										<div class="col-xxl-3 col-md-3 mt-1">
											<div>
												<label class="form-label">क्षेत्र/Circle<span class="required">*</span></label>
												<input type="text" class="form-control" id="circle" placeholder="Circle" name="circle" value="{{$forestDetail->getWildHarvesterDetail->circle ?? '' }}" required maxlength="50">
											</div>
										</div>
										<div class="col-xxl-3 col-md-3 mt-1">
											<div>
												<label class="form-label">विभाजन/Division<span class="required">*</span></label>
												<input type="text" class="form-control" id="division" required placeholder="Division" name="division" value="{{  $forestDetail->getWildHarvesterDetail->division ?? '' }}" maxlength="50">
											</div>
										</div>
										<div class="col-xxl-3 col-md-3 mt-1">
											<div>
												<label class="form-label">उप विभाजन/Sub Division<span class="required">*</span></label>
												<input type="text" class="form-control" id="sub_division" required placeholder="Sub Division" name="sub_division" value="{{  $forestDetail->getWildHarvesterDetail->sub_division ?? '' }}" maxlength="50">
											</div>
										</div>
										<div class="col-xxl-3 col-md-3 mt-1">
											<div>
												<label class="form-label">सीमा/Range<span class="required">*</span></label>
												<input type="text" class="form-control" id="range" placeholder="Range" required name="range" value="{{  $forestDetail->getWildHarvesterDetail->range ?? '' }}" maxlength="50">
											</div>
										</div>
										<div class="col-xxl-3 col-md-3 mt-1">
											<div>
												<label class="form-label">उप सीमा/Sub Range<span class="required">*</span></label>
												<input type="text" class="form-control" id="sub_range" required placeholder="Sub Range" name="sub_range" value="{{  $forestDetail->getWildHarvesterDetail->sub_range ?? '' }}" maxlength="50">
											</div>
										</div>
										<div class="col-xxl-3 col-md-3 mt-1">
											<div>
												<label class="form-label">बीट/Beat<span class="required">*</span></label>
												<input type="text" class="form-control" id="beat" required placeholder="Beat" name="beat" value="{{ $forestDetail->getWildHarvesterDetail->beat ?? '' }}" maxlength="50">
											</div>
										</div>
										<div class="col-xxl-3 col-md-3 mt-1">
											<div>
												<label class="form-label">कम्पार्टमेंट संख्या/Compartment No.<span class="required">*</span></label>
												<input type="text" class="form-control" id="compartment_no" required placeholder="Compartment No." name="compartment_no" value="{{$forestDetail->getWildHarvesterDetail->compartment_no ?? '' }}" maxlength="50">
											</div>
										</div>
										<div class="col-xxl-3 col-md-3 mt-1">
											<div>
												<label class="form-label">अक्षांश (लैटिट्यूड)/Latitude<span class="required">*</span></label>
												<input type="text" class="form-control" id="latitude" required placeholder="Latitude" name="latitude" value="{{$forestDetail->getWildHarvesterDetail->latitude ?? '' }}" maxlength="10">
											</div>
										</div>
										<div class="col-xxl-3 col-md-3 mt-1">
											<div>
												<label class="form-label">देशांतर  (लान्जिटूड)/Longitude<span class="required">*</span></label>
												<input type="text" class="form-control" id="longitude" required placeholder="Longitude" name="longitude" value="{{ $forestDetail->getWildHarvesterDetail->longitude ?? '' }}" maxlength="10">
											</div>
										</div>



                                        
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12 gy-4">
                                            <div class="hstack gap-2">
                                                <a href="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep2',$id) }}" class="btn btn-soft-secondary">
                                                    Back
                                                </a>
                                                <input type="submit" class="btn btn-primary" value="Save">
                                                <a href="{{route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep4',$id)}}" class="btn btn-soft-success">
                                                    Next
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </form>
    </div>
</div>



@endsection
@push('script')

<script>
    $("#registration").validate({
    rules: {
        
    },
    messages: {

    }

});
    // $.ajaxSetup({
    //     headers: {
    //         'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    //     }
    // });
    // // Dropzone has been added as a global variable.
    // const dropzone = new Dropzone("div.dropzone", {
    //     url: "{{ route('storeMedia') }}",
    //     paramName: "file",
    //     maxFilesize: 2,
    //     maxFiles: 1,
    //     acceptedFiles: ".jpeg,.jpg,.png,.mp4,.webm,.html5",
    //     headers: {
    //         'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    //     },
    //     init: function() {
    //         var drop = this; // Closure
    //         this.on('error', function(file, errorMessage) {
    //             if (errorMessage.indexOf('Error 404') !== -1) {
    //                 var errorDisplay = document.querySelectorAll('[data-dz-errormessage]');
    //                 errorDisplay[errorDisplay.length - 1].innerHTML =
    //                     'Error 404: The upload page was not found on the server';
    //             }
    //             if (errorMessage.indexOf('File is too big') !== -1) {
    //                 alert('Unable to upload image size is greated than 2 MB');
    //                 // i remove current file
    //                 drop.removeFile(file);
    //             }
    //         });
    //         this.on("maxfilesexceeded", function(file) {
    //                 this.removeAllFiles();
    //                 this.addFile(file);
    //             }),
    //             this.on("success", function(file, response) {
    //                 console.log(response);
    //                 var hiddenImage = $('<input type="hidden" name="_hidden_legal_doc_upload" value="' +
    //                     response.name + '"/>');
    //                 $('.hidden_images_area').html(hiddenImage);
    //             })
    //     }
    // });

    $(document).ready(function() {
        $("body").on("click",".add-more",function(){ 
            var html = $(".after-add-more").first().clone();
            $(html).find(".change").html("<label for=''>&nbsp;</label><br/><a class='btn btn-danger remove'><i class='ri-close-line'></i></a>");
            $(".after-add-more").last().after(html);
        });

        $("body").on("click",".remove",function(){ 
            $(this).parents(".after-add-more").remove();
        });
    });
</script>

@endpush
@extends('admin.layouts.app')

@section('content')
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">
                Registration List
            </h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                   {{-- <li class="breadcrumb-item"><a href="javascript: void(0);"> User Management</a></li> --}}
                    <li class="breadcrumb-item active">

                        Operators List

                    </li>
                </ol>
            </div>
        </div>
    </div>
</div>
<div class="clearfix"></div>

<div class="col-md-12 mt-2">
    @if (session('success'))
    <div class="alert alert-success" id="validate">
        {{ session('success') }}
    </div>
    @endif

    @if (session('importErrors'))
    <div class="alert alert-danger">
        <p>Following Errors Occured While Uploading the list, Please fix and upload again</p>
        <ul>
            @foreach (session('importErrors') as $failure)
            @foreach ($failure->errors() as $f)
            <li>{{ $f . ' at row ' . $failure->row() }}</li>
            @endforeach
            @endforeach
        </ul>
    </div>
    @endif
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0" style="float: left">


                    Operator Registered List

                </h5>

                <div class="row justify-content-end">
                    <div class="col-12 col-md-5 col-lg-3 col-xl-3 text-right mb-2">
                    <!-- <label for="" class="form-label">Search State</label> -->
                        <select class="form-select" name="state_id" id="state_id" data-label-msg="Status" required>
                            <option value="0">Search State...!</option>
                            @forelse(getAllState() as $state)
                            <option value="{{ $state->id }}" @selected(old('state') == $state->id)>
                                {{ $state->state_name }}
                            </option>
                            @empty
                            @endforelse
                        </select>
                    </div>
                 
                </div>

            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="deptUser" class="table table-bordered table-striped align-middle" style="width:100%">
                        <thead>
                            <tr>
                                <th>S.No.</th>
                                <th>Application Details</th>
                                <th>Registration Details</th>
                                <th>Scope Certificate</th>
                                <th>Operator Details</th>
                                <th>Contact Person Details</th>
                                <!-- <th>State</th> -->
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!--end col-->
</div>  
<!--end row-->
<!-- Suspend Form Modal -->
<div class="modal fade" id="suspendForm" tabindex="-1" aria-labelledby="suspendFormLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <!-- <h5 class="modal-title" id="suspendFormLabel">Suspend Operator</h5> -->
                <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="updatertemplate"></div>
                <!-- Dummy input field for Suspend form -->
                {{-- <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="formDate" class="form-label">Operator name:</label>
                            <input type="text" class="form-control" name="contact_person_pan_number" value="">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="toDate" class="form-label">PAN No:</label>
                            <input type="text" class="form-control" name="to_date" value="">
                        </div>
                    </div>
                </div> --}}
                {{-- <div class="mb-3 statusdata">
                    <label for="search" id="search" class="form-label">STATUS:</label>
                    <div class="input-group mt-2 statusdata" id="selectedStatusSection">
                        <select class="form-select" name="selectedStatusInput" id="selectedStatusInput"
                            data-label-msg="Status" required>
                            <option value="0">Select status</option>
                            <option value="1">Suspend</option>
                            <option value="2">Terminate</option>
                            <option value="3">Withdrawal By CB</option>
                            <option value="4">Withdrawal By Operator</option>
                            <option value="5">De Register</option>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="formDate" class="form-label">From Date:</label>
                            <input type="date" class="form-control" name="from_date" id="formDate" value="">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="toDate" class="form-label">To Date:</label>
                            <input type="date" class="form-control" name="to_date" id="toDate"  value="">
                        </div>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="toDate" class="form-label">Till Date:</label>
                    <input type="date" class="form-control" value="" name="to_years" id="years"
                        placeholder="Enter Years and Month" readonly>
                </div>
                <div class="mb-3">
                    <label for="suspendReason" class="form-label">Report Non-Compliance:</label>
                    <textarea class="form-control" id="suspendRemark" name="remark" rows="3"></textarea>
                </div>
                <div class="mb-3">
                    <label for="declaration_consent" style="color: blue; display: none;">
                        <input type="checkbox" id="declaration_consent" name="declaration_consent">
                        We hereby declare that <span style="color: black; font-weight: bold;">{{(Auth::guard('misadmin')->user()->id ?? '')}}</span>, as the certifying body, has identified <span style="color: black; font-weight: bold;">{{ ($operator->id ?? '')}}</span> to be
                        in violation of organic integrity standards and non-compliance with regulations, significantly
                        impacting organic integrity. Pursuant to the norms and guidelines outlined under the National
                        Programme for Organic Production (NPOP), appropriate disciplinary action has been imposed on the
                        said operator. This action is undertaken to uphold the sanctity of organic practices and
                        maintain the credibility of organic certification processes.
                    </label>
                </div>
                <div class="text-center">
                    <button type="button" class="btn btn-primary suspendBtn" id='suspendBtn'>Submit</button>

                </div>
            </div> --}}


        </div>
    </div>
</div>



@endsection



@push('script')
<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

var table = $('#deptUser').DataTable({
    dom: 'Bfrtip',
    lengthMenu: [
        [10, 25, 50, -1],
        [10, 25, 50, "All"]
    ],
    processing: true,
    serverSide: true,
    ajax: {
        url: '{{ route("superadmin.usermanagement.panalty") }}',
        type: 'GET',
        data: function(d) {
            d._token = "{{ csrf_token() }}";
            d.operator_status = $("#search").val();
            d.state_id = $("#state_id").val();
            // Send operator_status parameter
        }
    },

    columns: [{
            data: 'DT_RowIndex',
            name: 'DT_RowIndex',
            orderable: true
        },
        {
            data: 'application_no',
            name: 'application_no',
            orderable: true
        },
        {
            data: 'reg_no',
            name: 'reg_no',
            orderable: true
        },
        {
            data: 'scp_no',
            name: 'scp_no',
            orderable: true
        },
        // {
        //     data: 'ref_operator_type_id',
        //     name: 'ref_operator_type_id',
        //     orderable: true
        // },

        {
            data: 'operator_name',
            name: 'operator_name',
            orderable: true
        },
        // {
        //     data: 'created_on',
        //     name: 'created_on',
        //     orderable: true
        // },

        {
            data: 'contact_details',
            name: 'contact_details',
            orderable: true
        },
        // {
        //     data: 'ref_state_id',
        //     name: 'state',
        //     orderable: true
        // },

        {
            data: 'operator_status',
            name: 'operator_status',
            orderable: true
        },
        {
            data: 'action',
            name: 'name',
            orderable: false
        },
    ],
    buttons: [
    {
            extend: 'excelHtml5',
            title: function() {
                return "Operator Registered List";
            },
            titleAttr: 'Excel Reports',
            exportOptions: {
                columns: ':not(:last-child)'
            }
        },
        {
            extend: 'pdfHtml5',
            title: function() {
                return "Operator Registered List";
            },
            orientation: 'landscape',
            pageSize: 'A4',
            titleAttr: 'PDF Reports',
            exportOptions: {
                columns: ':not(:last-child)'
            }
        }
    ]
});

$("#search,#state_id").on('change', function(e) {
    table.ajax.reload(); 
    e.preventDefault();
});

 

$(document).on('click', '.deletedata', function() {
    var id = $(this).attr('data-value');
   // alert(id);
    var deletionReason = $('#deletionReason').val();

    Swal.fire({
        title: 'Are you sure?',
        html: '<input type="text" id="deletionReason" class="swal2-input" placeholder="Enter reason for deletion...">',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                url: '{{ route("superadmin.usermanagement.panaltydelete") }}', // Update with correct route name
                method: "POST",
                dataType: 'json',
                data: {
                    'id': id,
                    'deletionReason': deletionReason,
                    '_token': '{{ csrf_token() }}',
                },
                success: function(result) {
                    Swal.fire('Deleted!', 'Record Deleted Successfully..', 'success')
                        .then((result) => {
                            window.location
                                .reload(); // Reload the page after successful deletion
                        });
                },
                error: function(xhr, status, error) {
                    // Handle error
                }
            });
        }
    });
});




$(document).on('click', '.viewdata', function() {
    var id = $(this).attr('data-id');

    $.ajax({
        url: "#",
        method: "POST",
        dataType: 'json',
        data: {
            'id': id,
        },
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        success: function(result) {
            if (result.operator_status == "success") {
                $('#viewDataModal').modal('show');
                $('#viewDataModal #htmlData').html(result.html);
                return true;
            } else {
                Swal.fire('', result.msg, 'warning');
            }
        },
        error: function(result) {

        }
    });
});




// Add event listener for Suspend button click
$(document).on('click', '#suspendBtn', function() {
    var userId = $(this).data('userid');
    // Get the user ID from the button data attribute
    $('#suspendForm').modal('show'); // Show the suspend modal
    $('#suspendForm').attr('data-userid', userId); // Set the user ID in the suspend modal
});


$(document).on('change', '.statusdata select', function() {

    var selectedStatus = $(this).val();
    //    alert(selectedStatus);
    $('#selectedStatusInput').val(selectedStatus);
    var userId = $(this).attr('data-value');

    // if (selectedStatus === '1' || selectedStatus === '2') {
    //     $('#declaration_consent').closest('label').show();
    // } else {
    //     $('#declaration_consent').prop('checked', true).closest('label').show();
    // }


    $('.modal').on('click', '.btn-close', function() {
        $(this).closest('.modal').modal('hide'); // Hide the modal when close button is clicked
    });

    if (selectedStatus === '1') {
    $('#formDate, #toDate').closest('.row').show();
    $('#years').closest('.mb-3').hide();
} else if (selectedStatus === '2') {
    $('#formDate, #toDate').closest('.row').hide();
    $('#years').closest('.mb-3').show();

    // If Terminate is selected, set the default value to 1 year and the current month
    var currentDate = new Date();
    currentDate.setFullYear(currentDate.getFullYear() + 2);
    var defaultDate = currentDate.toISOString().slice(0, 10); // Format as yyyy-mm-dd
    $('#years').val(defaultDate);
} else if (selectedStatus === 'De-d Registration' ||
           selectedStatus === 'Withdrawal By Operator' ||
           selectedStatus === 'Withdrawal By CB') {
    // Calculate 2 years from current date
    var currentDate = new Date();
    currentDate.setFullYear(currentDate.getFullYear() + 2);
    var defaultDate = currentDate.toISOString().slice(0, 10); // Format as yyyy-mm-dd
    $('#years').val(defaultDate);
} else {
    $('#formDate, #toDate').closest('.row').hide();
    $('#years').closest('.mb-3').hide();
}

    // $(document).on('change', '#declaration_consent', function() {
    //     if ($(this).is(':checked') && (selectedStatus !== '3' && selectedStatus !== '4' &&
    //             selectedStatus !== '5')) {
    //         $('#suspendBtn').show();
    //     } else {
    //         $('#suspendBtn').hide();
    //     }
    // });



    // Check the selected status and open corresponding modal
    if (selectedStatus === 'Suspend') {

        $('#suspendForm').modal('show'); // Open Suspend form modal
    } else if (selectedStatus === 'Terminate' || 'De-d Registration' || 'Withdrawal By Operator' ||
        'Withdrawal By CB') {
        $('#suspendForm').modal('show'); // Open Terminate form modal
    }

    $('#suspendForm').on('click', '.btn-primary', function() {
        var userid = userId;
        var status = $('#selectedStatusInput').val();
        var fromDate = $('#formDate').val();
        var toDate = $('#toDate').val();
        var years = $('#years').val();
        var remark = $('#suspendRemark').val();

        // Send AJAX request to update user status
        $.ajax({
            url: '{{ route("superadmin.usermanagement.updateUserStatus") }}',
            type: 'POST',
            dataType: 'json',
            data: {
                user_id: userId, // Include the user ID in the request data
                status: status,
                from_date: fromDate,
                to_date: toDate,
                to_years: years,
                remark: remark,
                _token: '{{ csrf_token() }}'
            },
            success: function(response) {
                Swal.fire('Successfully!', 'Operator Status Updated Successfully..', 'success')
                    .then((result) => {
                        window.location
                            .reload(); // Reload the page after successful deletion
                    });
                // alert('Data submitted successfully');
                console.log('Data submitted successfully:', response);
                $('#suspendForm').modal(
                    'hide'); // Hide the Suspend modal after successful submission
            },
            error: function(xhr, status, error) {
                // Handle error
                console.error('Error:', error);
            }
        });
    });
});


function getModelSTWWDR(id,selectVal)
{
   
     
    $('#whole_page_loader').show();
    $.ajax({
            url: "{{route('superadmin.usermanagement.panaltyTemplate')}}",
            type: 'POST',
            data: {
                user_id: id,  
                selectVal: selectVal,  
                _token: '{{ csrf_token() }}'
            },
            success: function(response) {
                $('#whole_page_loader').hide();
                $('#updatertemplate').html(response);
            },
            error: function(xhr, status, error) {
                $('#whole_page_loader').hide();
                console.error('Error:', error);
            }
        });
}
</script>
@endpush

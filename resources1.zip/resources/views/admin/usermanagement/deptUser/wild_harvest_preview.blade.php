@extends('admin.layouts.app')
@section('content')
    <style>
        body {
            margin: 0px;
            padding: 0px;
            font-family: "Segoe UI";
        }

        .maindiv {
            width: 80%;
            margin: 0 auto;
        }

        .pdf_maindiv {
            border: 1px solid #cccccc;
            width: 100%;
            float: left;
            padding: 1%;
        }

        .pdf_heading {
            font-size: 20px;
            color: #000;
            padding: 16px 0 12px 0px;
            position: relative;
            width: 100%;
            float: left;
        }

        .brd_heading {
            border-bottom: 2px solid #ee5e24;
            padding-bottom: 8px;
            padding-right: 8px;
            width: 60px;
        }

        .pdf_input1 {
            background: #eeeeee;
        }

        .pdf_txt1 {
            color: #000;
            font-size: 14px;
            width: 45%;
            float: left;
            padding-bottom: 5px;
            font-weight: bold;
        }

        .pdf_box {
            color: #000;
            font-size: 14px;
            width: 35%;
            float: left;
            padding-bottom: 5px;
        }

        .table_pdf {
            width: 100%;
        }


        @media print {
            /*
                       .pdf_heading {
                        font-size: 20px;
                        color: #000;
                        padding: 26px 0 12px 0px;
                        position: relative;
                        width: 100%;
                        float: left;
                        -webkit-print-color-adjust: exact !important;
                        Chrome,
                        Safari color-adjust: exact !important;
                       } */

            /* .pdf_heading:before{content: ""; position: absolute; width:20px; height: 4px; background-color:#ee5e24; bottom:10px; display: block;-webkit-print-color-adjust: exact !important;    Chrome, Safari
                        color-adjust: exact !important;  } */


        }
    </style>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Wild Harvester Profile</h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Wild Harvester Profile</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">

            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1">
                                {{ user_name($user->id) ?? '' }}
                            </h4>

                            <div
                                class="flex-shrink-0  {{ $user->status == 2 || $user->status == 4 ? 'flex-grow-1' : '' }}">
                                <label for="basiInput"
                                    class="form-label">{{ $user->status == 2 ? 'Registration Number : ' . $user->registration_no : 'Application Number : #00' . $user->id }}</label>
                            </div>
                            &nbsp;&nbsp;&nbsp;
                            @if ($user->status == 2)
                                <div class="flex-shrink-0 flex-grow-1">
                                    <label for="basiInput" class="form-label">Reg Certificate (ENG) : <a target="_BLANK"
                                            href="{{ asset('public/' . $user->registration_certificate) }}"
                                            class="text-decoration-underline"><img
                                                src="{{ asset('public/assets/images/pdf-icon.png') }}" alt=""
                                                class="pdf-img-icon" height="17px">See Doc</a></label>
                                </div>
                              {{-----  <div class="flex-shrink-0 flex-grow-1">
                                    <label for="basiInput" class="form-label">Reg Certificate (HIN) : <a target="_BLANK"
                                            href="{{ asset('public' . $user->hindi_registration_certificate) }}"
                                            class="text-decoration-underline"><img
                                                src="{{ asset('public/assets/images/pdf-icon.png') }}" alt=""
                                                class="pdf-img-icon" height="17px">See Doc</a></label>
                                </div>----}}
                                @if ($eMSignedModuleAlow['status'] == 'success')
                                    <div class="flex-shrink-0">
                                        @if ($eMSignedModuleResult['status'] == 'success')
                                            @php
                                                $publicPath = str_replace('var/www/html/apeda/', '', $eMSignedModuleResult['signedPath']);
                                            @endphp
                                            <a class="btn btn-success btn-sm" download href="{{ $hostName . $publicPath }}">Download Signed PDF</a>
                                        @else
                                            <button type="button" class="btn btn-primary btn-sm" id="generateDigitalSign"
                                                data-filename="{{ basename($user->registration_certificate) }}"
                                                data-path="/{{ basename(dirname($user->registration_certificate)) }}/"
                                                data-filestored="public"
                                                data-certificate="RC">
                                                Digital Sign
                                            </button>
                                        @endif
                                    </div>
                                @endif
                            @endif

                            @if ($user->status == 0 || $user->status == 3)
                                <div class="flex-shrink-0">
                                    <a href="{{ route('superadmin.usermanagement.deptUser.wildHarvestUserAdd', $user->id) }}"
                                        class="btn btn-soft-success">Back</a>

                                </div>
                            @endif
                            
                        </div>

                        <!-- end card header -->
                        <div class="card-body white-inner">

                            <div class="pdf_heading">Wild Harvester Details </div>
                            <div class="pdf_maindiv">
                                <!--form1 section starts here-->
                                <div class="container-fluid white-inner">
                                    <div class="row ">
                                        <div class="col-6">
                                            <!--form1 tab starts here-->
                                            <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                <tr>
                                                    <td class="pdf_txt1">Wild Harvester Name :</td>
                                                    <td class="pdf_box">{{ user_name($user->id) ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Gender</td>
                                                    <td class="pdf_box">
                                                        @if ($user->gender == 1)
                                                            Male
                                                        @elseif($user->gender == 2)
                                                            Female
                                                        @else
                                                            Other
                                                        @endif
                                                    </td>
                                                </tr>


                                            </table>
                                            <!--form1 tab end here-->
                                        </div>
                                        <div class="col-6">
                                            <!--form1 tab starts here-->
                                           {{-- <table style="padding: 10px; border: 0px;" class="table_pdf">

                                                <tr>
                                                    <td class="pdf_txt1">Father's Full Name :</td>
                                                    <td class="pdf_box">{{ $wh_details->father_first_name ?? '' }} {{ $wh_details->father_middle_name ?? '' }} {{ $wh_details->father_last_name ?? '' }}</td>
                                                </tr>
                                                   <!-- <tr>
                                                    <td class="pdf_txt1">Father's Middle Name :</td>
                                                    <td class="pdf_box">{{ $wh_details->father_middle_name ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Father's Last Name :</td>
                                                    <td class="pdf_box">{{ $wh_details->father_last_name ?? '' }}</td>
                                                </tr>  -->

                                            </table> --}}
                                            <!--form1 tab end here-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="pdf_heading">Wild Harvester Address</div>
                            <div class="pdf_maindiv">
                                <!--form1 section starts here-->
                                <div class="container-fluid white-inner">
                                    <div class="row">
                                        <div class="col-6">
                                            <!--form1 tab starts here-->
                                            <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                <tr>
                                                    <td class="pdf_txt1">State</td>
                                                    <td class="pdf_box">{{ getStateName($user->ref_state_id) }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">District</td>
                                                    <td class="pdf_box">{{ getDisName($user->ref_district_id) }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Taluka/Mandal</td>
                                                    <td class="pdf_box">{{ getTalukName($user->ref_block_tehsil_id) }}</td>
                                                </tr>
                                            </table>
                                            <!--form1 tab end here-->
                                        </div>

                                        <div class="col-6">

                                            <!--form1 tab starts here-->
                                            <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                <tr>
                                                    <td class="pdf_txt1">Village</td>
                                                    <td class="pdf_box">{{ getVillName($user->ref_village_id) }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Pin Code</td>
                                                    <td class="pdf_box">{{ $user->pin ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Address</td>
                                                    <td class="pdf_box">{{ $user->address ?? '' }}</td>
                                                </tr>
                                            </table>
                                            <!--form1 tab end here-->
                                        </div>


                                    </div>
                                </div>
                            </div>
                            <div class="pdf_heading">Contact Person Details</div>
                            <div class="pdf_maindiv">
                                <!--form1 section starts here-->
                                <div class="container-fluid white-inner">
                                    <div class="row">
                                        <div class="col-6">
                                            <!--form1 tab starts here-->
                                            <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                <tr>
                                                    <td class="pdf_txt1">Mobile No. </td>
                                                    <td class="pdf_box"> {{ $user->contact_person_mobile_number ?? '' }}
                                                    </td>
                                                </tr>
                                                {{-- <tr>
                                                    <td class="pdf_txt1">Aadhaar No.</td>
                                                    <td class="pdf_box"> {{ ($user->contact_person_aadhar_number) ?? '' }}
                                                    </td>
                                                </tr> --}}
                                                <tr>
                                                    <td class="pdf_txt1">Aadhaar No.</td>
                                                    <td class="pdf_box">
                                                        @php
                                                            // Assuming the Aadhaar number is stored as plain text
                                                            $aadhaarNumber = $user->contact_person_aadhar_number ?? '';
                                                        @endphp
                                                
                                                        {{ !empty($aadhaarNumber) ? '********' . substr($aadhaarNumber, -4) : '' }}
                                                    </td>
                                                </tr>
                                                
                                                <tr>
                                                    <td class="pdf_txt1">Pan No.</td>
                                                    <td class="pdf_box" colspan=2>
                                                        {{ $user->user_name ?? '' }}
                                                    </td>
                                                </tr>

                                            </table>
                                            <!--form1 tab end here-->
                                        </div>

                                        <div class="col-6">

                                            <!--form1 tab starts here-->
                                            <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                <tr>
                                                    <td class="pdf_txt1">Email Id </td>
                                                    <td class="pdf_box"> {{ $user->contact_person_email ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">No. of collectors </td>
                                                    <td class="pdf_box">{{ $user->no_of_collectors ?? '' }}
                                                    </td>
                                                </tr>

                                            </table>
                                            <!--form1 tab end here-->
                                        </div>


                                    </div>
                                </div>
                            </div>
                            <div class="pdf_heading">Bank Details</div>
                            <div class="pdf_maindiv">
                                <!--form1 section starts here-->
                                <div class="container-fluid white-inner">
                                    <div class="row">
                                        <div class="col-6">
                                            <!--form1 tab starts here-->
                                            <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                <tr>
                                                    <td class="pdf_txt1">Bank Name</td>
                                                    <td class="pdf_box">
                                                        {{ !empty($wh_bankDetail->ref_bank_id) ? getRefBankById($wh_bankDetail->ref_bank_id) : '' }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">IFSC Code</td>
                                                    <td class="pdf_box">
                                                        {{ !empty($wh_bankDetail->ifsc_code) ? $wh_bankDetail->ifsc_code : '' }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Bank Address</td>
                                                    <td class="pdf_box" colspan="2">
                                                        {{ !empty($wh_bankDetail->bank_address) ? $wh_bankDetail->bank_address : '' }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Wild Harvester Photo</td>
                                                    <td class="pdf_box" colspan="2">
                                                        @if (!empty($wh_bankDetail->farmer_photo))
                                                            <a target="_BLANK"
                                                                href="{{ asset('public/research/uploads/' . $wh_bankDetail->farmer_photo) }}">View</a>
                                                        @endif
                                                    </td>
                                                </tr>
                                            </table>
                                            <!--form1 tab end here-->
                                        </div>
                            
                                        <div class="col-6">
                                            <!--form1 tab starts here-->
                                            <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                <tr>
                                                    <td class="pdf_txt1">Account No.</td>
                                                    <td class="pdf_box">
                                                        {{ !empty($wh_bankDetail->account_number) ? $wh_bankDetail->account_number : '' }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Branch Name</td>
                                                    <td class="pdf_box">
                                                        {{ !empty($wh_bankDetail->branch_name) ? $wh_bankDetail->branch_name : '' }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Bank Pincode</td>
                                                    <td class="pdf_box">
                                                        {{ !empty($wh_bankDetail->pincode) ? $wh_bankDetail->pincode : '' }}
                                                    </td>
                                                </tr>
                                            </table>
                                            <!--form1 tab end here-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                            

                            <div class="pdf_heading">Forest Details</div>
                            <div class="pdf_maindiv">

                                <!-- farmer-1 container start  -->

                                <div class="container-fluid white-inner">
                                    <div class="row">
                                        <div class="col-12">
                                            {{-- <h6 style="padding:0;padding-bottom:15px;width: 100%;text-decoration: underline;">Farmer {{ $key+1 }} --}}
                                            </caption>
                                        </div>
                                        <div class="col-6">
                                            <!--form1 tab starts here-->
                                            <table style="padding: 10px; border: 0px;"
                                                class="table_pdf table_contact_person">

                                                <tbody>
                                                    {{-- <tr>
                                                        <td class="pdf_txt1">Area Under Cultivation</td>
                                                        <td class="pdf_box">{{ $wh_details->area_cultivation ?? '' }}</td>
                                                    </tr> --}}
                                                    <tr>
                                                        <td class="pdf_txt1">MoU/Forest Permit</td>
                                                        <td class="pdf_box">{{ $wh_details->mou_permit_no ?? '' }}</td>
                                                    </tr>

                                                </tbody>
                                            </table>
                                            <!--form1 tab end here-->
                                        </div>
                                        <div class="col-6">
                                            <!--form1 tab starts here-->
                                            <table style="padding: 10px; border: 0px;"
                                                class="table_pdf table_contact_person">
                                                <tbody>
                                                    <tr>
                                                        <td class="pdf_txt1">MoU/Forest Permit Valid up to</td>
                                                        <td class="pdf_box"> {{ date('d-m-Y', strtotime($wh_details->permit_no_valid_upto)) ?? '' }}
                                                        </td>
                                                    </tr>

                                                </tbody>
                                            </table>
                                            <!--form1 tab end here-->
                                        </div>
                                    </div>
                                </div>
                                <!-- Farmer - 1 container ended  -->
                                <hr>
                                <div class="row white-inner">
                                    <div class="col-12">
                                        <h6 style="padding:0;padding-bottom:15px;width: 100%;text-decoration: underline;">
                                            Address
                                            </caption>
                                    </div>
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf table_contact_person">

                                            <tbody>
                                                <tr>
                                                    <td class="pdf_txt1">State</td>
                                                    <td class="pdf_box">
                                                        {{ getStateName($wh_details->ref_state_id) ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Circle</td>
                                                    <td class="pdf_box">{{ $wh_details->circle ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Division</td>
                                                    <td class="pdf_box">{{ $wh_details->division ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Sub Division</td>
                                                    <td class="pdf_box">{{ $wh_details->sub_division ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Range</td>
                                                    <td class="pdf_box">{{ $wh_details->range ?? '' }}</td>
                                                </tr>

                                            </tbody>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                    <div class="col-6">
                                        <!--form1 tab starts here-->
                                        <table style="padding: 10px; border: 0px;" class="table_pdf table_contact_person">
                                            <tbody>
                                                <tr>
                                                    <td class="pdf_txt1">Sub Range </td>
                                                    <td class="pdf_box">{{ $wh_details->sub_range ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Beat</td>
                                                    <td class="pdf_box">{{ $wh_details->beat ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Compartment No.</td>
                                                    <td class="pdf_box">{{ $wh_details->compartment_no ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Latitude</td>
                                                    <td class="pdf_box">{{ $wh_details->latitude ?? '' }}</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Longitude</td>
                                                    <td class="pdf_box">{{ $wh_details->longitude ?? '' }}</td>
                                                </tr>



                                            </tbody>
                                        </table>
                                        <!--form1 tab end here-->
                                    </div>
                                </div>
                                <!-- farmer - 2 container start  -->

                                <!-- farmer -2 container end  -->
                            </div>
                            <!--  End Formar list -->

                            <!-- Start Producer Docs -->

                            <!-- END PRoducer Documents-->


                            <!-- Start Form Details -->
                            <div class="pdf_heading">Details of Forest Product</div>
                            <div class="pdf_maindiv">
                                <!-- farmer-1 container start  -->
                                @forelse($wh_product_details as $key => $val)
                                    <div class="container-fluid white-inner">
                                        <div class="row">
                                            <div class="col-12">
                                                {{-- <h6 style="padding:0;padding-bottom:15px;width: 100%;text-decoration: underline;">Farmer {{ $key+1 }} --}}
                                                </caption>
                                            </div>
                                            <div class="col-6">
                                                <!--form1 tab starts here-->
                                                <table style="padding: 10px; border: 0px;"
                                                    class="table_pdf table_contact_person">

                                                    <tbody>
                                                        <tr>
                                                            <td class="pdf_txt1">Forest Area/Land ID</td>
                                                            <td class="pdf_box">
                                                                {{ getWildHarvesterName($val->at_wh_forest_details_id) ?? '' }}
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td class="pdf_txt1">Type of Forest Product</td>
                                                            <td class="pdf_box">
                                                                {{ $val->type_of_the_forest_product ?? '' }} </td>
                                                        </tr>
                                                        <tr>
                                                            <td class="pdf_txt1">Name of Forest Product</td>
                                                            <td class="pdf_box">
                                                                {{ $val->name_of_the_forest_product ?? '' }}</td>
                                                        </tr>



                                                    </tbody>
                                                </table>
                                                <!--form1 tab end here-->
                                            </div>
                                            <div class="col-6">
                                                <!--form1 tab starts here-->
                                                <table style="padding: 10px; border: 0px;"
                                                    class="table_pdf table_contact_person">
                                                    <tbody>


                                                        <tr>
                                                            <td class="pdf_txt1">Area Under Cultivation</td>
                                                            <td class="pdf_box"> {{ $val->area_under_cultivation }}</td>
                                                        </tr>
                                                        <tr>
                                                            <td class="pdf_txt1">Organic Status</td>
                                                            <td class="pdf_box"> {{ getRefOrganicStatusMasterByID($val->organic_status) }}</td>
                                                        </tr>
                                                        <tr>
                                                            <td class="pdf_txt1">Reflect farm Image After geo gagging</td>
                                                            <td class="pdf_box">
                                                                @if (isset($val->forest_product_image) && !empty($val->forest_product_image))
                                                                    <a target="_BLANK"
                                                                        href="{{ asset('public/research/uploads/' . $val->forest_product_image) }}">View</a>
                                                                @endif
                                                            </td>
                                                        </tr>

                                                    </tbody>
                                                </table>
                                                <!--form1 tab end here-->
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Farmer - 1 container ended  -->
                                    @if (count($wh_product_details) - 1 > $key)
                                        <hr>
                                    @endif

                                @empty
                                    No Record found..
                                @endforelse

                            </div>

                            <div class="pdf_heading">Geo Tagging of Permitted Forest Area</div>
                            <div class="pdf_maindiv">
                                <!-- farmer-1 container start  -->

                                @forelse($wh_forest_details as $key => $val)
                                    <div class="container-fluid white-inner">
                                        <div class="row">
                                            <div class="col-12">
                                                {{-- <h6 style="padding:0;padding-bottom:15px;width: 100%;text-decoration: underline;">Farmer {{ $key+1 }} --}}
                                                </caption>
                                            </div>
                                            <div class="col-6">
                                                <!--form1 tab starts here-->
                                                <table style="padding: 10px; border: 0px;"
                                                    class="table_pdf table_contact_person">

                                                    <tbody>
                                                        <tr>
                                                            <td class="pdf_txt1">Forest Area/Land ID</td>
                                                            <td class="pdf_box">
                                                                {{ getWildHarvesterName($val->at_wh_forest_details_id) ?? '' }}
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td class="pdf_txt1">Geo Tagging of Forest Land</td>
                                                            <td class="pdf_box">{{ $val->image_after_tagging ?? '' }}
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td class="pdf_txt1">Reflect farm Image After geo gagging</td>
                                                            <td class="pdf_box">
                                                                @if (isset($val->forest_farm_image) && !empty($val->forest_farm_image))
                                                                    <a target="_BLANK"
                                                                        href="{{ asset('public/research/uploads/' . $val->forest_farm_image) }}">View</a>
                                                                @endif
                                                            </td>
                                                        </tr>


                                                    </tbody>
                                                </table>
                                                <!--form1 tab end here-->
                                            </div>
                                            <div class="col-6">
                                                <!--form1 tab starts here-->
                                                <table style="padding: 10px; border: 0px;"
                                                    class="table_pdf table_contact_person">
                                                    <tbody>

                                                        <tr>
                                                            <td class="pdf_txt1">Total Area of Forest</td>
                                                            <td class="pdf_box">
                                                                {{ $val->total_forest_area_under_organic }}</td>
                                                        </tr>
                                                        <tr>
                                                            <td class="pdf_txt1">Total Area of Forest under organic
                                                                cultivation</td>
                                                            <td class="pdf_box"> {{ $val->organic_cultivation }}</td>
                                                        </tr>


                                                    </tbody>
                                                </table>
                                                <!--form1 tab end here-->
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Farmer - 1 container ended  -->
                                    @if (count($wh_forest_details) - 1 > $key)
                                        <hr>
                                    @endif

                                @empty
                                    No Record found..
                                @endforelse

                            </div>
                            <!-- END PRoducer Form Details -->
                            <div class="pdf_heading">Document Details</div>
                            <div class="pdf_maindiv">
                                <!-- farmer-1 container start  -->

                                <div class="container-fluid white-inner">
                                    <div class="row">
                                        <div class="col-12">
                                        
                                            </caption>
                                        </div>
                                        <div class="col-6">
                                            
                                            <table style="padding: 10px; border: 0px;"
                                                class="table_pdf table_contact_person">

                                                <tbody>

                                                    <tr>
                                                        <td class="pdf_txt1">Land Doc</td>
                                                        <td class="pdf_box">
                                                            @if (!empty($wh_docs->land_documents_image_path))
                                                                {{-- <a target="_BLANK"
                                                                    href="{{ $wh_docs->pan_card_image_path }}">View</a> --}}
                                                                    <a target="_BLANK"
                                                                    href="{{ asset('public/research/uploads/' . $wh_docs->land_documents_image_path) }}">View</a>
                                                            @else
                                                                NA
                                                            @endif
                                                        </td>
                                                    </tr>
                                                    {{-- <tr>
                                                        <td class="pdf_txt1">Aadhaar No</td>
                                                        <td class="pdf_box">
                                                            @if (!empty($wh_docs->aadhar_card_image_path))
                                                               
                                                                    <a target="_BLANK"
                                                                    href="{{ asset('public/research/uploads/' . $wh_docs->aadhar_card_image_path) }}">View</a>

                                                            @else
                                                                NA
                                                            @endif
                                                        </td>
                                                    </tr> --}}
                                                    {{-- <tr>
                                                        <td class="pdf_txt1">PAN No.</td>
                                                        <td class="pdf_box">
                                                            @if (!empty($wh_docs->pan_card_image_path))
                                                              
                                                                    <a target="_BLANK"
                                                                    href="{{ asset('public/research/uploads/' . $wh_docs->pan_card_image_path) }}">View</a>
                                                            @else
                                                                NA
                                                            @endif
                                                        </td>
                                                    </tr> --}}




                                                </tbody>
                                            </table>
                                            <!--form1 tab end here-->
                                        </div>
                                        <div class="col-6">
                                            <!--form1 tab starts here-->
                                            <table style="padding: 10px; border: 0px;"
                                                class="table_pdf table_contact_person">
                                                <tbody>


                                                
                                                    <!-- <tr>
                                                        <td class="pdf_txt1">Passbook</td>
                                                        <td class="pdf_box">
                                                            @if (!empty($wh_docs->passbook_image_path))
                                                                {{-- <a target="_BLANK"
                                                                    href="{{ $wh_docs->pan_card_image_path }}">View</a> --}}
                                                                    <a target="_BLANK"
                                                                    href="{{ asset('public/research/uploads/' . $wh_docs->passbook_image_path) }}">View</a>
                                                            @else
                                                                NA
                                                            @endif
                                                        </td>
                                                    </tr> -->
                                                    <!-- <tr>
                                                        <td class="pdf_txt1">Contact person sign</td>
                                                        <td class="pdf_box">
                                                            @if (!empty($wh_docs->contact_person_sign_image_path))
                                                                {{-- <a target="_BLANK"
                                                                    href="{{ $wh_docs->pan_card_image_path }}">View</a> --}}
                                                                    <a target="_BLANK"
                                                                    href="{{ asset('public/research/uploads/' . $wh_docs->contact_person_sign_image_path) }}">View</a>
                                                            @else
                                                                NA
                                                            @endif
                                                        </td>
                                                    </tr> -->
                                                    <!-- <tr>
                                                        <td class="pdf_txt1">Live Signature</td>
                                                        <td class="pdf_box">
                                                            @if (!empty($wh_docs->live_signature_image_path))
                                                                {{-- <a target="_BLANK"
                                                                    href="{{ $wh_docs->pan_card_image_path }}">View</a> --}}
                                                                    <a target="_BLANK"
                                                                    href="{{ asset('public/research/uploads/' . $wh_docs->live_signature_image_path) }}">View</a>
                                                            @else
                                                                NA
                                                            @endif
                                                        </td>
                                                    </tr> -->

                                                </tbody>
                                            </table>
                                            <!--form1 tab end here-->
                                        </div>
                                    </div>
                                </div>
                                <!-- Farmer - 1 container ended  -->

                                <!-- Docs - 2 container start  -->

                                <!-- Docs -2 container end  -->
                            </div>
                            @if (auth()->user()->ref_operator_type_id == 1)
                                <div class="row white-inner">
                                    <div class="col-lg-12">

                                        <div class="tab-content py-4 custom-tab-content">
                                            <div class="tab-pane fade show active" id="step1">
                                                @if ($user->status != 2)
                                                    <div class="card">
                                                        <div class="card-header align-items-center d-flex">
                                                            <h4 class="card-title mb-0 flex-grow-1">
                                                                Remarks:

                                                            </h4>
                                                        </div>
                                                        <!-- end card header -->
                                                        <div class="card-body">
                                                            <div class="live-preview">

                                                                {{-- <div class="col-xxl-4 col-md-4 gy-4 ">
                                                            <div>
                                                                <label for="basiInput"
                                                                    class="form-label">Remarks :
                                                                </label>
                                                                <label for="basiInput">{{ $user->cb_reg_remarks ?? '' }}
                                                                </label>

                                                            </div>
                                                        </div> --}}

                                                                <form method="post" id=""
                                                                    action="{{ route('superadmin.usermanagement.deptUser.previewpost') }}">
                                                                    @csrf
                                                                    <input type="hidden" name="at_user_id"
                                                                        value="{{ $user->id }}">
                                                                    <input type="hidden" name="id"
                                                                        value="{{ $user->ref_operator_type_id }}">
                                                                    <div class="col-xxl-4 col-md-4 gy-4 ">
                                                                        <div>
                                                                            <label for="basiInput"
                                                                                class="form-label">Status<span
                                                                                    class="required">*</span>
                                                                            </label>

                                                                            <select class="form-select" name="status"
                                                                                required>
                                                                                <option value="">-Select-
                                                                                </option>
                                                                                <option value="2"
                                                                                    {{ $user->status == 2 ? 'selected' : '' }}>
                                                                                    Approved
                                                                                </option>
                                                                                <option value="4"
                                                                                    {{ $user->status == 4 ? 'selected' : '' }}>
                                                                                    Review</option>
                                                                                <option value="3"
                                                                                    {{ $user->status == 3 ? 'selected' : '' }}>
                                                                                    Rejected

                                                                                </option>
                                                                            </select>

                                                                        </div>
                                                                    </div>

                                                                    <div class="col-xxl-6 col-md-6 gy-6 mt-3">
                                                                        <div>
                                                                            <label class="form-label">Submit Your
                                                                                Remarks:<span class="required">
                                                                                    *</span></label>
                                                                            <textarea placeholder="Remarks" class="form-control customtextarea" name="cb_remarks" required>{{ $user->cb_reg_remarks ?? '' }}</textarea>
                                                                        </div>
                                                                    </div>
                                                                    {{-- @if ($regDetail->cb_remarks == '' && $regDetail->cb_status == '') --}}
                                                                    <div class="row">
                                                                        <div class="col-xxl-4 col-md-4 gy-4 ">
                                                                            <div class="hstack gap-2">

                                                                                <button type="submit" id="submitbtn"
                                                                                    class="btn btn-primary submit-button">Submit</button>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    {{-- @endif --}}
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                @endif
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            @endif
                            @if (auth()->user()->ref_operator_type_id == 4)
                                <div class="row">
                                    <div class="col-lg-12 gy-4">
                                        <div class="hstack gap-2">

                                            @if ($user->status == 3 || $user->status == 2)
                                                <div class="col-xxl-4 col-md-4 gy-4 ">
                                                    <div>
                                                        <label for="basiInput"
                                                            class="form-label">{{ $user->status == 2 ? 'Status :' : '' }}
                                                        </label>
                                                        <label for="basiInput">
                                                            @php
                                                                if ($user->status == 2) {
                                                                    echo 'Application Approved By CB';
                                                                } elseif ($user->status == 3) {
                                                                    echo 'Application Rejected By CB';
                                                                } elseif ($user->status == 4) {
                                                                    echo 'Review';
                                                                } else {
                                                                    echo 'Pending';
                                                                }
                                                            @endphp

                                                        </label>

                                                    </div>
                                                </div>

                                                <div class="col-xxl-4 col-md-4 gy-4 ">
                                                    <div>
                                                        <label for="basiInput" class="form-label">Remarks :
                                                        </label>
                                                        <label for="basiInput">{{ $user->cb_reg_remarks ?? '' }}
                                                        </label>

                                                    </div>
                                                </div>
                                        </div>
                            @endif
                            {{-- <div class="hstack gap-2">
                                <br>
                                @if ($user->status == 0 || $user->status == 3)
                                    <form method="post" id=""
                                        action="{{ route('superadmin.icsuser.previewpost') }}">
                                        @csrf
                                        <input type="hidden" name="at_user_id" value="{{ $user->id }}">
                                        <button type="submit" class="btn btn-primary" id="submitbtn">
                                            Final Submit
                                        </button>
                                    </form>
                                @endif
                                @if ($user->status == 3)
                                    <div class="col-xxl-4 col-md-4 gy-4 ">
                                        <a href="{{ route('superadmin.icsuser.step1', $user->id) }}"
                                            class="btn btn-soft-success">
                                            Edit
                                        </a>
                                @endif
                            </div> --}}
                            <div class="hstack gap-2">
                                <br>

                               @if ($user->status == 0 || $user->status == 3)
                                
                                    <form method="post" id=""
                                    action="{{ route('superadmin.icsuser.previewpost') }}">
                                    @csrf
                                    <input type="hidden" name="at_user_id"
                                        value="{{ $user->id }}">
                                    <button type="submit" class="btn btn-primary" id="submitbtn">
                                        Final Submit
                                    </button>
                                    </form>
                            
                              @endif
                               @if ($user->status == 3)

                                    <div class="col-xxl-4 col-md-4 gy-4 ">
                                        <a href="{{ route('superadmin.icsuser.step1', $user->id) }}"
                                            class="btn btn-soft-success">
                                            Edit
                                        </a>

                              @endif
                            </div>
                        </div>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
    </div>

    </div>
    </div>
@endsection

@push('script')
    <script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
    <script>
        $(document).on('click', '#submitbtn', function() {

            if (checkValidation("registration")) {
                $('#registration').submit();
                return true;
            } else {
                return false;
            }
        });
    </script>
@endpush

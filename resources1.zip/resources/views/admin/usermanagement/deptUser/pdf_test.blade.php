<!DOCTYPE html>
<html>
<head>
    <title>Invoice</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        h1 {
            color: #2c3e50;
        }
        .invoice-details {
            margin-top: 20px;
        }
        .invoice-details td {
            padding: 10px;
        }
        .invoice-header {
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
    <div class="invoice-header">
        <h1>Invoice</h1>
        <p>Invoice Date:</p>
    </div>

    <div class="invoice-details">
        <table border="1" width="100%">
            <tr>
                <td><strong>Name</strong></td>
                <td></td>
            </tr>
            <tr>
                <td><strong>Amount</strong></td>
                <td>$100.00</td>
            </tr>
            <tr>
                <td><strong>Due Date</strong></td>
                <td></td>
            </tr>
        </table>
    </div>
</body>
</html>

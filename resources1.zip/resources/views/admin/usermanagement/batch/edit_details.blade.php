@extends('admin.layouts.app')

@section('content')
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Edit/Approve Batch Details</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Edit Batch Details</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">

        <nav>
            <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                <a class="nav-link " id="step0-tab" href="{{route('superadmin.usermanagement.editbatch')}}">Operator Details</a>
                <a class="nav-link active" id="step4-tab" href="javascript:void(0);">Batch Details</a>

            </div>
        </nav>
    </div>
</div>

<div class="flex-shrink-0">
    @if (session('error'))
        <div class="alert alert-danger">
            {{ session('error') }}
        </div>
    @endif
    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif
    @if ($errors)
        @foreach ($errors->all() as $error)
            <div class="alert alert-danger">{{ $error }}</div>
        @endforeach
    @endif
</div>

{{--
<div class="row white-inner">
    <p class="mb-sm-0">Operator Details <p>
        <div class="col-xxl-4 col-md-4 gy-3">
            <div>
                <label class="form-label">Registration No:</label>
                <input type="text" class="form-control" id="registration_no" name="registration_no" value="{{ $data[0]->registration_no ?? ''}}" readonly>
            </div>
        </div>

        <div class="col-xxl-4 col-md-4 gy-3">
            <div>
                <label class="form-label">Operator Name:</label>
                <input type="text" class="form-control" id="operator_name" name="operator_name" value="{{ $data[0]->operator_name ?? '' }}" readonly>
            </div>
        </div>

        <div class="col-xxl-4 col-md-4 gy-3">
            <div>
                <label class="form-label">Operator Type:</label>
                <input type="text" class="form-control" id="operator_type" name="operator_type" value="{{ ($data[0]->operator_type ?? '') }}" readonly>
            </div>
        </div>
</div> --}}

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <p><b>Batch Details:</b></p>
                <div class="table-responsive">
                    {{-- <form id="dataForm" method="post" action="{{route('superadmin.batchDetailsSave' ,auth()->user()->id)}}">
                        @csrf
                        <table id="searchResultsTable" class="table table-bordered table-striped align-middle" style="width:100%">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Batch ID</th>
                                    <th>Created On</th>
                                    <th>Product Name</th>
                                    <th>Imported Product</th>
                                    <th>By Product</th>
                                    <th>Source Quantity(in MT)</th>
                                    <th>Remaining Quantity(in MT)</th>
                                    <th>Expiry Date<span class="required">
                                        *</span></th>
                                    <th>Batch Quantity(in MT)<span class="required">
                                        *</span></th>
                                    <!-- <th>Status</th> -->
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($data as $index => $product)
                              
                                <tr class="pro-tr">
                                    <td>{{$index + 1}}</td>
                                    <td>
                                        {{ !empty(trim($product->product_code ?? '')) ? 180924 . $product->product_code : 'N/A' }}
                                    </td>
                                    <td>
                                        {{ !empty($product->created_at) ? dateFormat($product->created_at) : 'N/A' }}
                                    </td>
                                    <td>
                                        {{ !empty(trim($product->product_code ?? '')) ? getHscodeProductName($product->product_code) : 'N/A' }}
                                        {{ !empty(trim($product->product_name ?? '')) ? $product->product_name : 'N/A' }}
                                    </td>
                                    <td>NO</td>
                                    <td>NO</td>
                                    <td>
                                        {{ !empty(trim($product->quantity_source ?? '')) ? $product->quantity_source : 'N/A' }}
                                    </td>
                                    <td>
                                        {{ !empty(trim($product->available_quantity ?? '')) ? $product->available_quantity : 'N/A' }}
                                    </td>
                                    
                                    <td><input type="date" name="expiry_date" class="form-control" value="">
                                    <input type="hidden" name="batch_id" class="form-control" value="{{$product->batch_id ?? ''}}">
                                </td>
                                    <td><input type="text" name="quantity"  class="form-control numbersonly" value="">
                                    
                                    <td>
                                        <button type="submit" class="btn btn-primary">Update/Approve</button>

                                    </td>
                                </tr>
                                @empty
                                <tr>
                                <td colspan="12">No Batch available</td> 
                            </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </form> --}}


                    {{-- <form id="dataForm" method="post" action="{{ route('superadmin.batchDetailsSave') }}">
                        @csrf --}}
                        <table id="searchResultsTable" class="table table-bordered table-striped align-middle" style="width:100%">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Batch ID</th>
                                    <th>Created On</th>
                                    <th>Product Name</th>
                                    <th>Imported Product</th>
                                    <th>By Product</th>
                                    <th>Source Quantity(in MT)</th>
                                    <th>Remaining Quantity(in MT)</th>
                                    <th>Expiry Date<span class="required">*</span></th>
                                    <th>Batch Quantity(in MT)<span class="required">*</span></th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($data as $index => $product)
                                @php 
                              
                                @endphp
                                    <tr class="pro-tr">
                                        <td>{{ $index + 1 }}</td>
                                        <td>{{ !empty(trim($product->product_code ?? '')) ? 180924 . $product->product_code : 'N/A' }}</td>
                                        <td>{{ !empty($product->created_at) ? date('d-m-Y', strtotime($product->created_at ?? '')) : 'N/A' }}  </td>
                                        <td>{{ !empty(trim($product->product_code ?? '')) ? getHscodeProductName($product->product_code) : 'N/A' }} {{ !empty(trim($product->product_name ?? '')) ? $product->product_name : 'N/A' }}</td>
                                        <td>NO</td>
                                        <td>NO</td>
                                        <td>{{ !empty(trim($product->quantity_source ?? '')) ? $product->quantity_source : 'N/A' }}</td>
                                        <td>{{ !empty(trim($product->available_quantity ?? '')) ? $product->available_quantity : 'N/A' }}</td>

                                        <form method="POST" action="{{ route('superadmin.batchDetailsSave', auth()->user()->id) }}">
                                            @csrf
                                                <td>                                            
                                                    <input type="date" name="expiry_date" class="form-control expiry_date" value="{{$batchdata->expiry_date}}">
                                                </td>
                                                <td>                                            
                                                    <input type="text" name="quantity" class="form-control numbersonly quantity" value="{{$batchdata->quantity}}">
                                                </td>
                                                <td>                                                
                                                    
                                                        <input type="hidden" name="batch_id" value="{{ $batchdata->id }}">                                               
                                                        <button type="submit" class="btn btn-primary">Update/Approve</button>
                                                    
                                                </td>
                                    </form>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="12">No Batch available</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                        
                        
                    {{-- </form> --}}
                    
                    
                </div>
            </div>
        </div>
    </div>
    <!--end col-->
</div>


@endsection

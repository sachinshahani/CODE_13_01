@extends('admin.layouts.app')

@section('content')
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Edit/Approve Batch Details</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Edit Batch Details</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">

        <nav>
            <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                <a class="nav-link " id="step0-tab" href="{{route('superadmin.usermanagement.editbatch')}}">Operator Details</a>
                <a class="nav-link active" id="step4-tab" href="javascript:void(0);">Batch Details</a>

            </div>
        </nav>
    </div>
</div>

<div class="row white-inner">
    <p class="mb-sm-0">Operator Details</p>
    <div class="col-xxl-4 col-md-4 gy-3">
        <div>
            <label class="form-label">Registration No:</label>
            <input type="text" class="form-control" id="registration_no" name="registration_no" value="{{ $operator->registration_no ?? ''}}" readonly>
        </div>
    </div>

    <div class="col-xxl-4 col-md-4 gy-3">
        <div>
            <label class="form-label">Operator Name:</label>
            <input type="text" class="form-control" id="operator_name" name="operator_name" value="{{ $operator->operator_name ?? '' }}" readonly>
        </div>
    </div>

    <div class="col-xxl-4 col-md-4 gy-3">
        <div>
            <label class="form-label">Operator Type:</label>
            <input type="text" class="form-control" id="operator_type" name="operator_type" value="{{ getOperatorTypeById($operator->operator_type ?? '') }}" readonly>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <p><b>Batch Details:</b></p>
                <div class="table-responsive">
                    <table id="searchResultsTable" class="table table-bordered table-striped align-middle" style="width:100%">
                        <thead>
                            <tr>
                                <th>S.No.</th>
                                <th>Batch ID</th>
                                <th>Created On</th>
                                <th>Organic Status</th>
                                <th>Imported Product</th>
                                <th>By Product</th>
                            <th>Source Quantity(in MT)</th>
                                <th>Remaining Quantity(in MT)</th>
                                <th>Expiry Date</th>
                                <th>Batch Quantity(in MT)</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!--end col-->
</div>
<script>
    $(document).ready(function() {
        var searchResultsTable = $('#searchResultsTable').DataTable({
            processing: true,
            serverSide: true,
            lengthMenu: [
                [10, 25, 50, 100, -1],
                [10, 25, 50, 100, "All"]
            ],
            order: [
                [0, 'asc']
            ],
            ajax: {
                url: '{{ route('superadmin.BatchProceed') }}',
                type: 'GET',
                data: function(d) {

                    d._token = "{{ csrf_token() }}";
                    d.registration_no = $('#registration_no').val();
                }
            },
            columns: [{
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex',
                    searchable: false
                },
                {
                    data: 'batch_id',
                    name: 'batch_id'
                },
                {
                    data: 'created_on',
                    name: 'created_on'
                },
                {
                    data: 'organic_status',
                    name: 'organic_status'
                },
                {
                    data: 'imported_product',
                    name: 'Imported_product'
                },
                {
                    data: 'by_product',
                    name: 'by_product'
                },
                {
                    data: 'Source',
                    name: 'Source'
                },
                {
                    data: 'Remaining',
                    name: 'Remaining'
                },
                {
                    data: 'date',
                    name: 'date'
                },
                {
                    data: 'Quantity',
                    name: 'Quantity'
                },

                {
                    data: 'action',
                    name: 'action',
                    orderable: false,
                    searchable: false
                }
            ]
        });

        // Event handler for the search button
        $('#searchBtn').click(function(e) {
            e.preventDefault();
            searchResultsTable.ajax.reload();
        });
    });
</script>


@endsection

@extends('admin.layouts.app')

@section('content')
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Pending Batch for Approval</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                      <li class="breadcrumb-item"><a href="{{route('superadmin.dashboard')}}">Dashboard</a></li>
                    <li class="breadcrumb-item active">Batch Creation</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">

        <nav>
            <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                <a class="nav-link active" id="step0-tab" href="">Operator Details</a>
                <a class="nav-link" id="step4-tab" href="">Batch Details</a>

            </div>
        </nav>
    </div>
</div>

<br>
{{-- <div class="row white-inner">

    <h6 class="mb-sm-0">Search Operator</h6>


    <div class="col-xxl-2 col-md-4 gy-3 ">
        <div>
            <label class="form-label">Registration No / Operator Name:: <span class="required"></span></label>
            <input type="text" class="form-control" id="registration_no" name="registration_no" value="">
        </div>
    </div>

</div> --}}

<div class="row ">

    <div class="col-lg-12 ">
        <div class="card ">

            <div class="card-body">
                <p><b>Operator Details:</b></p>
                <div class="table-responsive">
                    <table id="searchResultsTable" class="table table-bordered table-striped align-middle" style="width:100%">
                        <thead>
                            <tr>
                                <th>S.No.</th>
                                <th>Registration No</th>
                                <th>Operator Name</th>
                                <th>Operator Type</th>
                                <th>Registration Date</th>
                                <th>Action</th>

                            </tr>
                        </thead>

                    <tbody>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!--end col-->
</div>

<script>
    $(document).ready(function() {
        var searchResultsTable = $('#searchResultsTable').DataTable({
            processing: true,
            serverSide: true,
            lengthMenu: [
                [10, 25, 50, 100, -1],
                [10, 25, 50, 100, "All"]
            ],
            order: [
                [0, 'asc']
            ],
            ajax: {
                url: '{{ route('superadmin.BatchSearch') }}',
                type: 'GET',
                data: function(d) {

                    d._token = "{{ csrf_token() }}";
                    d.registration_no = $('#registration_no').val();
                }
            },
            columns: [{
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex',
                    searchable: false
                },
                {
                    data: 'reg_no',
                    name: 'reg_no'
                },
                {
                    data: 'operator_name',
                    name: 'operator_name'
                },
                {
                    data: 'operator_type',
                    name: 'operator_type'
                },
                {
                    data: 'reg_date',
                    name: 'reg_date'
                },

                 {
                    data: 'action',
                    name: 'action',
                    orderable: false,
                    searchable: false
                }
            ]
        });

        // Event handler for the search button
        $('#searchBtn').click(function(e) {
            e.preventDefault();
            searchResultsTable.ajax.reload();
        });
    });
</script>

@endsection




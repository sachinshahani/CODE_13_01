@extends('admin.layouts.app')
@section('content')



    <div class="overlay">
        <div class="loaderi"></div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Add Employee</h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);"></a></li>
                        <li class="breadcrumb-item active">Add Employee</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header align-items-center d-flex">
                    <h4 class="card-title mb-0 flex-grow-1">Employee Creation </h4>
                    <div class="flex-shrink-0">
                        @if (session('error'))
                            <div class="alert alert-danger">
                                {{ session('error') }}
                            </div>
                        @endif
                        @if (session('success'))
                            <div class="alert alert-success">
                                {{ session('success') }}
                            </div>
                        @endif
                        @if ($errors)
                            @foreach ($errors->all() as $error)
                                <div class="alert alert-danger">{{ $error }}</div>
                            @endforeach
                        @endif
                    </div>
                </div>

                <div class="card-body">
                    <div class="live-preview">
                        <form action="{{ route('superadmin.usermanagement.usercreate.store') }}" class="commonform1"
                            method="POST" enctype="multipart/form-data" id="commonform1" autocomplete="off">
                            @csrf
                            <div class="row gy-4">
                                <div class="row seperatesec">
                                    <div class="col-xxl-3 col-md-3">
                                    </div>
                                    <!-- <div class="col-xxl-6 col-md-6">
                                                        <div>
                                                            <label class="form-label">User/Employee Code<span class="required">*</span></label>
                                                            <input type="text" class="form-control"
                                                                placeholder="User/Employee Code" name="employee_code"
                                                                value="{{ old('employee_code') }}" required>
                                                        </div>
                                                    </div> -->
                                </div>
                                <div class="row seperatesec white-inner">
                                    <div class="col-xxl-6 col-md-6">
                                        <div>
                                            <label class="form-label">Employee Type <span class="required">*</span></label>
                                            <select class="form-select" name="emp_type" id="emp_type" required>
                                                <option value="">Select Employee Type</option>
                                                <option value="Top Management">Top Management</option>
                                                <option value="Operating Official">Operating Official</option>
                                                <option value="Authorized Signatory">Authorized Signatory</option>

                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-xxl-6 col-md-6">
                                        <div>
                                            <label class="form-label">Employee ID <span class="required">*</span></label>
                                            <input type="text" class="form-control" id="employee_id" name="employee_id"
                                                placeholder="Employee Id" value="{{ old('employee_id') }}" required>
                                        </div>
                                    </div>
                                    <div class="col-xxl-6 col-md-6 mt-4">
                                        <div>
                                            <label class="form-label">Employee Name <span class="required">*</span></label>
                                            <input type="text" class="form-control" id="username" name="username"
                                                placeholder="Employee Name" value="{{ old('username') }}" required>
                                        </div>
                                    </div>
                                    <div class="col-xxl-6 col-md-6 mt-4">
                                        <div>
                                            <label class="form-label">Date of Joining<span class="required">*</span></label>
                                            <input type="date" class="form-control" id="join_date" name="join_date"
                                                value="{{ old('join_date') }}" required>
                                        </div>
                                    </div>

                                    <div class="col-xxl-6 col-md-6 mt-4">
                                        <div>
                                            <label class="form-label">Trainings Details<span
                                                    class="required">*</span></label>
                                            <input type="text" class="form-control" id="trainings" name="trainings"
                                                value="{{ old('trainings') }}" required>
                                        </div>
                                    </div>
                                    <div class="col-xxl-6 col-md-6 mt-4">
                                        <div>
                                            <label class="form-label">Experience<span class="required">*</span></label>

                                            <select name="experience" id="experience" class="form-select" required>
                                                <option value="">Select Experience in Years</option>
                                                <option value="1">1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                                <option value="5">5</option>
                                                <option value="6">6</option>
                                                <option value="7">7</option>
                                                <option value="8">8</option>
                                                <option value="9">9</option>
                                                <option value="10">10</option>
                                                <option value="11">11</option>
                                                <option value="12">12</option>
                                                <option value="13">13</option>
                                                <option value="14">14</option>
                                                <option value="15">15</option>
                                                <option value="16">16</option>
                                                <option value="17">17</option>
                                                <option value="18">18</option>
                                                <option value="19">19</option>
                                                <option value="20">20</option>
                                                <option value="21">21</option>
                                                <option value="22">22</option>
                                                <option value="23">23</option>
                                                <option value="24">24</option>
                                                <option value="25">25</option>
                                                <option value="26">26</option>
                                                <option value="27">27</option>
                                                <option value="28">28</option>
                                                <option value="29">29</option>
                                                <option value="30">30</option>
                                                <option value="31">31</option>
                                                <option value="32">32</option>
                                                <option value="33">33</option>
                                                <option value="34">34</option>
                                                <option value="35">35</option>
                                                <option value="36">36</option>
                                                <option value="37">37</option>
                                                <option value="38">38</option>
                                                <option value="39">39</option>
                                                <option value="40">40</option>
                                                <option value="41">41</option>
                                                <option value="42">42</option>
                                                <option value="43">43</option>
                                                <option value="44">44</option>
                                                <option value="45">45</option>
                                                <option value="46">46</option>
                                                <option value="47">47</option>
                                                <option value="48">48</option>
                                                <option value="49">49</option>
                                                <option value="50">50</option>
                                            </select>


                                        </div>
                                    </div>


                                    <div class="col-xxl-6 col-md-6 mt-4">
                                        <div>
                                            <label for="labelInput" class="form-label">Gender</label>
                                            <select class="form-select" name="gender" required>
                                                <option value="">Select Gender</option>
                                                @foreach (getGenderName() as $key => $gender)
                                                    <option value="{{ $key }}" @selected($key == old('gender'))>
                                                        {{ $gender }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-xxl-6 col-md-6 gy-4">
                                        <div>
                                            <label for="labelInput" class="form-label">User Designation</label>
                                            <select class="form-select" name="designation" id="change_dive" required>
                                                <option value="">--Select Designation--</option>
                                                {{-- <option value="Director">Director</option>
                                                <option value="CEO">CEO</option>
                                                <option value="Inspector">Inspector</option>
                                                <option value="Technical Staff">Technical Staff</option>
                                                <option value="Other">Other</option>  --}}

                                                {{-- <option value="Inspector">Inspector</option> --}}
                                                @forelse($des as $data)
                                                    <option value="{{ $data->id }}" @selected(old('designation') == $data->id)>
                                                        {{ $data->designation_name }}
                                                    </option>
                                                @empty
                                                @endforelse




                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-xxl-6 col-md-3 gy-4 name-change ">


                                        <div class="">

                                            <label for="labelInput" class="form-label">Director Identification
                                                No(DIN):</label>
                                            <input type="text" class="form-control " name="din"
                                                placeholder="Enter DIN No:" value="">

                                        </div>


                                    </div>

                                    <div class="col-xxl-6 col-md-3 gy-4 name-change">

                                        <label for="labelInput" class="form-label">Director PAN</label>
                                        <input type="text" class="form-control" name="pan" placeholder="PAN"
                                            value="">
                                    </div>

                                    <div class="col-xxl-6 col-md-6 gy-4">
                                        <div>
                                            <label for="labelInput" class="form-label">Resource Type:</label>
                                            <select class="form-select" name="resource_type" id="change_resource"
                                                required>
                                                <option value="">--Select Resource--</option>
                                                <option value="Internal">Internal Resource</option>
                                                <option value="External">External Resource</option>
                                            </select>
                                        </div>
                                    </div>
                                    <!-- <div class="col-xxl-6 col-md-6 gy-4">
                                                        <div>
                                                            <label class="form-label">User Designation <span class="required">*</span></label>
                                                            <input type="text" class="form-control" id="designation"
                                                                name="designation" placeholder="User Designation" required
                                                                value="{{ old('designation') }}">
                                                        </div>
                                                    </div> -->

                                    <div class="col-xxl-6 col-md-3 gy-4 external_resourse">
                                        <label for="labelInput" class="form-label"> PAN</label>
                                        <input type="text" class="form-control" name="pan" placeholder="PAN"
                                            value="">
                                    </div>
                                    <div class="col-xxl-6 col-md-6 gy-4">
                                        <div>
                                            <label for="labelInput" class="form-label">Higher Qualification<span
                                                    class="required">*</span></label>
                                            <!-- <input type="text" class="form-control" required name="higher_qual"
                                                                placeholder="Higher Qualification" value="{{ old('higher_qual') }}"> -->

                                            <select name="higher_qual" id="higher_qual" class="form-select">
                                                <option value="">Select Qualification</option>
                                                @forelse($qualification as $qualification)
                                                    <option value="{{ $qualification->qualification }}"
                                                        @selected(old('state') == $qualification->id)>{{ $qualification->qualification }}
                                                    </option>
                                                @empty
                                                @endforelse


                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-xxl-6 col-md-6 gy-4">
                                        <div class="inputEmail  col-12 col-sm-12 col-md-12 col-lg-12">
                                            <div class="form-group d-flex justify-content-center ge-otp-form">
                                                <div class="col-12 col-sm-12 col-md-10 col-lg-10">
                                                    <label>Email ID<span class="text-danger">*</span></label>
                                                    <input
                                                        class="form-control validateEmailId col-12 col-sm-12 col-md-12 col-lg-12"
                                                        type="text" value="{{ old('email') }}"
                                                        placeholder="Email Id" id="email_id1" name="email" />
                                                </div>
                                                <div class="input-group-append col-12 col-sm-12 col-md-2 col-lg-2"
                                                    style="padding-top: 28px;">
                                                    <button type="button"
                                                        class="btn-email btn btn-outline-success waves-effect waves-light visitorCat2">Get
                                                        OTP</button>
                                                    <button type="button"
                                                        class="btn btn-ghost-success waves-effect waves-light btn-mailsend"
                                                        style="display:none">Mail Send</button>
                                                    <button type="button"
                                                        class="btn btn-ghost-success waves-effect waves-light btn-verify"
                                                        style="display:none">Verified</button>
                                                </div>
                                            </div>
                                            <div class="verify-email justify-content-center">
                                                <div class="login-pass mb-4 otp-email col-12 col-sm-12 col-md-5 col-lg-12 pl-2"
                                                    style="display:none">
                                                    <div class="input-group">
                                                        <span class="input-group-text mdi mdi-key"
                                                            id="inputGroup-sizing-default"></span>
                                                        <input type="number" class="form-control inp-b"
                                                            aria-label="Sizing example input"
                                                            aria-describedby="inputGroup-sizing-default" id="email_otp1"
                                                            maxlength="4">
                                                        <div class="input-group-append">
                                                            <a href="javascript:void(0)"
                                                                class="verifiEmail_otp btn btn-outline-success waves-effect waves-light">Verify</a>
                                                            <a href="javascript:void(0)"
                                                                class="resendEmail_otp btn btn-outline-danger waves-effect waves-light">Resend</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- <div class="col-xxl-6 col-md-6 gy-4">
                                                        <div>
                                                            <label for="labelInput" class="form-label">Mobile No.<span
                                                                    class="required">*</span></label>
                                                            <input type="text" class="form-control numbersonly phone" name="mobile"
                                                                placeholder="User Mobile Number*" value="{{ old('mobile') }}" required
                                                                maxlength="10" onblur="phonenumber(this)">

                                                        </div>
                                                    </div> -->


                                    <div class="col-xxl-6 col-md-6 gy-4">
                                        <div>
                                            <label for="labelInput" class="form-label">Mobile No.<span
                                                    class="required">*</span></label>
                                            <input type="text" class="form-control numbersonly phone" name="mobile"
                                                id="mobile" placeholder="Mobile Number*" value="{{ old('mobile') }}"
                                                maxlength="10" required>

                                            <!-- Get OTP Button -->
                                            <button type="button" class="btn btn-primary mt-2" id="getOtpBtn"
                                                onclick="sendOtp()">Get OTP</button>

                                            <!-- Resend OTP Button (Initially Hidden) -->
                                            <button type="button" class="btn btn-warning mt-2" id="resendOtpBtn"
                                                onclick="sendOtp()" style="display: none;">Resend OTP</button>

                                            <!-- Verified Button (Initially Hidden) -->
                                            <button type="button" class="btn btn-success mt-2" id="verifiedBtn"
                                                style="display: none;" disabled>Verified</button>

                                            <!-- OTP Input Section (Initially Hidden) -->
                                            <div id="otp_section" style="display: none;">
                                                <input type="text" id="otp_input" class="form-control mt-2"
                                                    placeholder="Enter OTP" maxlength="6">
                                                <button type="button" class="btn btn-primary mt-2"
                                                    onclick="verifyOtp()">Verify OTP</button>
                                            </div>
                                        </div>

                                        <img src="{{ asset('public/assets/images/load.gif') }}" id="loader"
                                            style="display:none;" alt="Loading...">
                                    </div>




                                    <div class="col-xxl-6 col-md-6 gy-4">
                                        <div>
                                            <label for="labelInput" class="form-label">Aadhaar No.<span
                                                    class="required">*</span></label>
                                            <input type="text" class="form-control numbersonly" name="aadhar_number"
                                                placeholder="Aadhaar Number*" value="{{ old('aadhar_number') }}" required
                                                maxlength="12">
                                        </div>
                                    </div>
                                    <div class="col-xxl-6 col-md-6 gy-4">
                                        <div>
                                            <label for="labelInput" class="form-label">Status</label>
                                            <select class="form-select" name="status" required>
                                                <option value="1">Active</option>
                                                <option value="0">Inactive</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-xxl-6 col-md-6 gy-4">
                                        <div>
                                            <label for="labelInput" class="form-label">Remark</label>
                                            <textarea class="form-control customtextarea" name="remark" >{{ old('remark') }}</textarea>
                                        </div>
                                    </div>

                                    <div class="col-xxl-6 col-md-6 mt-4">
                                        <div>
                                            <label class="form-label">Upload Bio Data<span
                                                    class="required">*</span></label>
                                            <input type="file" class="form-control upload_document" id="upload_biodata"
                                                name="upload_biodata" value="{{ old('join_date') }}" required>
                                            <p>In PDF only upto 1MB</p>
                                        </div>
                                    </div>


                                </div>





                                <!-- <div class="row seperatesec">
                                                    <div class="col-xxl-3 col-md-3">
                                                    </div>
                                                    <div class="col-xxl-6 col-md-6">
                                                        <div>
                                                            <label for="labelInput" class="form-label">Role</label>
                                                            <select class="form-select" name="role_id">
                                                               <option value="">Select Role</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div> -->
                                <div class="row seperatesec">

                                    <div class="row">
                                        <div class="col-lg-12 gy-4">
                                            <div class="hstack gap-2">
                                                <button type="submit" class="btn btn-primary">Submit</button>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('script')
    <script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
    <script type="text/javascript">
        // email verification

        $(".btn-email").click(function(e) {
            e.preventDefault();
            var user_email = $('#email_id1').val();


            if (user_email != "") {
                $(".overlay").show();
                $.ajax({
                    type: 'POST',
                    url: "{{ route('superadmin.usermanagement.email_mobile_OTP') }}",
                    data: {
                        'user_email': user_email
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(resp) {
                        if (resp == 1) {

                            Swal.fire({
                                text: "Please verify OTP send on Email id",
                                icon: 'success',
                                confirmButtonText: 'OK'
                            }).then((result) => {
                                $('.otp-email').show(500);
                                $('#email_id1').val(user_email);
                                $('#email_id1').prop('readonly', true);
                                $('.btn-email').hide(500);
                                $('.btn-mailsend').show(100);
                            });

                        }
                        $(".overlay").hide();
                    }
                });
            } else {
                Swal.fire("", "Please enter Email ID", "error");
            }
        });

        $('.upload_document').on('change', function() {
            var $this = $(this);
            var file = $this[0].files[0];
            var fileType = file.type;
            var fileSize = file.size;
            var allowedTypes = ['application/pdf'];

            // Check for file type
            if (!allowedTypes.includes(fileType)) {
                Swal.fire({
                    icon: 'error',
                    title: 'Invalid File Extension',
                    text: 'Please upload PDF only.',
                });
                $this.val("");
                return false;
            }

            // Check for file size
            if (fileSize > 1000000) { // 2 MB in bytes
                Swal.fire({
                    icon: 'error',
                    title: 'File Size Too Large',
                    text: 'Please upload files of size 1 MB or less only.',
                });
                $this.val("");
                return false;
            }
        });



        $(".verifiEmail_otp").click(function(e) {
            e.preventDefault();
            var email_otp = $('#email_otp1').val();
            $(".overlay").show();
            if (email_otp != "") {

                $.ajax({
                    type: 'POST',
                    url: "{{ route('superadmin.usermanagement.email_mobile_OTP_check') }}",
                    data: {
                        'email_otp': email_otp
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(html) {
                        if (html == 1) {
                            $('#email_otp').prop('readonly', true);
                            $('.otp-email1').hide(500);
                            $('.btn-email').hide(500);
                            $('.btn-verify').show(500);
                            $('.visitorCat').hide(500);
                            $('.visitorCat1').hide(500);
                            $('.user_detail_page').show(500);
                            $('#email_id').prop('readonly', true);
                            $('.btn-mailsend').hide();
                            $('.login-pass').hide();

                        } else {
                            Swal.fire("", "Please enter Valid OTP", "error");
                        }
                        $(".overlay").hide();
                    }
                });
            } else {
                Swal.fire("", "Please enter OTP", "error");
            }
        });

        $(".resendEmail_otp").click(function(e) {
            e.preventDefault();
            var user_email = $('#email_id1').val();

            $.ajax({
                type: 'POST',
                url: "{{ route('superadmin.usermanagement.email_mobile_OTP') }}",
                data: {
                    'user_email': user_email
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(html) {
                    Swal.fire("", "Re OTP Send!!", "success");
                }
            });
        });

        // end-----





        $("#commonform1").validate({
            rules: {
                // user_password: {
                // 	required: true,
                // 	minlength: 8,
                // 	maxlength: 10,
                // } ,
                mobile: {
                    required: true,
                }
            },
            messages: {
                // user_password: {
                // 	required:"This field is required and should be 8 digits, contains upper,lowerCase,and a special Character"
                // },
                mobile: {
                    required: "This field is required",
                }
            }

        });

        function CheckPassword(inputtxt) {
            if (inputtxt.value.length > 0) {
                var decimal = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
                if (inputtxt.value.match(decimal)) {
                    return true;
                } else {
                    Swal.fire('',
                        'Password should be 8 digits,contains upperCase letter,lowerCase letter,and a special Character',
                        'warning');
                    $("#user_password").val('');
                    return false;
                }
            }
        }

        function phonenumber(inputtxt) {
            var phoneno = /^\d{10}$/;
            if (inputtxt.value.match(phoneno)) {
                return true;
            } else {
                Swal.fire('', 'Please enter a valid mobile number.', 'warning');
                $("#mobile").val('');
                return false;
            }
        }
    </script>
    @php
        $salt = rand('1000', '9999');
        session(['salt' => $salt]);
    @endphp
    <script type="text/javascript" src="{{ asset('public/backend/js/sha.js') }}"></script>
    <script>
        // $(document).on('submit','#commonform1',function(){
        //     var salt = '{{ $salt }}';
        //     var secret = $('#password').val();
        //     var shaObj = new jsSHA("SHA-256", "TEXT");
        //     shaObj.update(secret);
        //     var hashPass = shaObj.getHash("HEX");
        //     $('#password').val(hashPass);
        //     var secretcurrent = $('#confirm_password').val();
        //     var shaObjcurrent = new jsSHA("SHA-256", "TEXT");
        //     shaObjcurrent.update(secretcurrent);
        //     var hashPasscurrent = shaObjcurrent.getHash("HEX");
        //     $('#confirm_password').val(hashPasscurrent);
        // });


        $(document).ready(function() {
            $(".name-change").hide();

            $("#change_dive").change(function() {
                var selectedOption = $(this).val();

                $(".name-change").hide();

                if (selectedOption === "4") {
                    $(".name-change").show();
                } else {
                    $(".name-change").hide();
                }
            });
        });


        $(document).ready(function() {
            $(".external_resourse").hide();

            $("#change_dive, #change_resource").change(function() {
                var selectedDesignation = $("#change_dive").val();
                var selectedResource = $("#change_resource").val();

                $(".external_resourse").hide();

                if (selectedDesignation === "17" && selectedResource === "External") {
                    $(".external_resourse").show();
                }
            });
        });
    </script>

    <script>
        function sendOtp() {
            var mobile = document.getElementById('mobile').value;
            var getOtpButton = document.getElementById('getOtpBtn');
            var resendOtpButton = document.getElementById('resendOtpBtn');
            var otpSection = document.getElementById('otp_section');
            var loader = document.getElementById('loader'); // Assume there's a loader with this ID

            if (mobile.length === 10) {
                // Show loader and hide Get OTP button
                loader.style.display = 'inline-block'; // Show the loader
                getOtpButton.style.display = 'none'; // Hide Get OTP button

                fetch('{{ route('superadmin.sendOtp') }}', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '{{ csrf_token() }}'
                        },
                        body: JSON.stringify({
                            mobile_number: mobile
                        })
                    })
                    .then(response => response.json())
                    .then(data => {
                        // Hide loader once we get the response
                        loader.style.display = 'none';

                        if (data.status === 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: 'Valid Mobile Number',
                                text: 'OTP sent successfully!',
                            });

                            // Show OTP input section and Resend OTP button, hide Get OTP button
                            otpSection.style.display = 'block';
                            resendOtpButton.style.display = 'inline-block';
                            getOtpButton.style.display = 'none'; // Keep the Get OTP button hidden
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed to send OTP',
                                text: 'Please try again.',
                            });

                            // Show Get OTP button again if failed
                            getOtpButton.style.display = 'inline-block';
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);

                        // Hide loader and show Get OTP button again in case of error
                        loader.style.display = 'none';
                        getOtpButton.style.display = 'inline-block';

                        Swal.fire({
                            icon: 'error',
                            title: 'An error occurred',
                            text: 'Please try again.',
                        });
                    });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Invalid Mobile Number',
                    text: 'Please Enter a Valid 10-digit Mobile Number.',
                });
            }
        }

        function verifyOtp() {
            var mobile = document.getElementById('mobile').value;
            var otp = document.getElementById('otp_input').value; // Updated to use the correct OTP input field

            if (otp.length === 4) {
                fetch('{{ route('superadmin.verifyOtp') }}', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '{{ csrf_token() }}'
                        },
                        body: JSON.stringify({
                            mobile_number: mobile,
                            otp: otp
                        })
                    })
                    .then(response => {
                        const contentType = response.headers.get("content-type");
                        if (contentType && contentType.includes("application/json")) {
                            return response.json();
                        } else {
                            throw new Error('Received non-JSON response');
                        }
                    })
                    .then(data => {
                        if (data.status === 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: 'OTP Verified',
                                text: 'Your OTP has been verified successfully!',
                            });

                            // Hide Get OTP button and Resend OTP button, show Verified button
                            document.getElementById('getOtpBtn').style.display = 'none';
                            document.getElementById('resendOtpBtn').style.display = 'none'; // Hide Resend OTP button
                            document.getElementById('verifiedBtn').style.display =
                                'inline-block'; // Show Verified button

                            // Hide the OTP input section after successful verification
                            document.getElementById('otp_section').style.display = 'none';
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Invalid OTP',
                                text: 'The OTP you entered is incorrect. Please try again.',
                            });
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        Swal.fire({
                            icon: 'error',
                            title: 'An error occurred',
                            text: 'Unable to verify the OTP. Please try again.',
                        });
                    });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Invalid OTP',
                    text: 'Please enter a valid 4-digit OTP.',
                });
            }
        }
    </script>
@endpush

@extends('admin.layouts.app')
@section('content')
 
<style>
    .bold-text {
        font-weight: bold;
        color: #000; /* Change to your desired color */
    }
</style>

<h4 class="card-title mb-0 flex-grow-1">
    <span class="bold-text">Employee Id:</span> {{ !empty($user->employee_id) ? $user->employee_id : 'N/A' }} |
    <span class="bold-text">Employee Name:</span> {{ !empty(user_name($id)) ? user_name($id) : 'N/A' }} |
    <span class="bold-text">Employee Designation:</span> {{ !empty($user->designation) ? $user->designation : 'N/A' }}
</h4>


<div class="overlay">
    <div class="loader"></div>
</div>
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Assign Role</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">User Creation</a></li>
                    <li class="breadcrumb-item active">Assign Role</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                    <h4 class="card-title mb-0 flex-grow-1">
                    <strong style="color: #000;">Employee Id:</strong> {{ !empty($user->employee_id) ? $user->employee_id : 'N/A' }} |
                    <strong style="color: #000;">Employee Name:</strong> {{ !empty(user_name($id)) ? user_name($id) : 'N/A' }} |
                    <strong style="color: #000;">Employee Designation:</strong> {{ !empty($user->designation) ? $user->designation : 'N/A' }}
                   </h4>



                <div class="flex-shrink-0">
                    @if (session('error'))
                    <div class="alert alert-danger">
                        {{ session('error') }}
                    </div>
                    @endif
                    @if (session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                    @endif
                    @if($errors)
                    @foreach ($errors->all() as $error)
                    <div class="alert alert-danger">{{ $error }}</div>
                    @endforeach
                    @endif
                </div>
            </div>

            <div class="card-body">
                <div class="live-preview">
                    <form action="{{ route('superadmin.usermanagement.usercreate.UpdateRole',$id) }}" class="commonform1" method="POST" enctype="multipart/form-data" id="commonform1" autocomplete="off">
                        @csrf
                        <div class="row gy-4">
                            <div class="row seperatesec">
                                <div class="col-xxl-3 col-md-3">
                                </div>
                                <div class="col-xxl-6 col-md-6">
                                    <div>
                                        <label for="labelInput" class="form-label">Role</label>
                                        <select class="form-select" name="role_id" onchange="getpermission(this.value)">
                                           <option value="">Select Role</option> 
                                           @forelse($role as $vals)
                                           <option value="{{$vals->id}}" {{($userrole==$vals->title?"selected":"")}}>{{$vals->title}}</option>
                                           @empty
                                           @endforelse

                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row seperatesec">
                                    <div class="col-lg-12 gy-4">
                                        <div class="hstack gap-2" style="float: right">
                                            @if($userrole==NULL)
                                            <button type="submit" class="btn btn-primary">Assign</button>
                                            @endif
                                        </div>
                                    </div>

                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@push('script')
<script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
<script type="text/javascript">


// email verification 

$(".btn-email").click(function(e) {
    e.preventDefault();
    var user_email = $('#email_id1').val();


    if (user_email != "") {
        $(".overlay").show();
        $.ajax({
            type: 'POST',
            url: "{{ route('superadmin.usermanagement.email_mobile_OTP') }}",
            data: {
                'user_email': user_email
            },
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(resp) {
                if (resp == 1) {

                    Swal.fire({
                        text: "Please verify OTP send on Email id",
                        icon: 'success',
                        confirmButtonText: 'OK'
                    }).then((result) => {
                        $('.otp-email').show(500);
                        $('#email_id1').val(user_email);
                        $('#email_id1').prop('readonly', true);
                        $('.btn-email').hide(500);
                        $('.btn-mailsend').show(100);
                    });

                }
                $(".overlay").hide();
            }
        });
    } else {
        Swal.fire("", "Please enter Email ID", "error");
    }
});


$(".verifiEmail_otp").click(function(e) {
    e.preventDefault();
    var email_otp = $('#email_otp1').val();
    $(".overlay").show();
    if (email_otp != "") {

        $.ajax({
            type: 'POST',
            url: "{{ route('superadmin.usermanagement.email_mobile_OTP_check') }}",
            data: {
                'email_otp': email_otp
            },
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(html) {
                if (html == 1) {
                    $('#email_otp').prop('readonly', true);
                    $('.otp-email1').hide(500);
                    $('.btn-email').hide(500);
                    $('.btn-verify').show(500);
                    $('.visitorCat').hide(500);
                    $('.visitorCat1').hide(500);
                    $('.user_detail_page').show(500);
                    $('#email_id').prop('readonly', true);
                    $('.btn-mailsend').hide();
                    $('.login-pass').hide();
                    
                } else {
                    Swal.fire("", "Please enter Valid OTP", "error");
                }
                $(".overlay").hide();
            }
        });
    } else {
        Swal.fire("", "Please enter OTP", "error");
    }
});

$(".resendEmail_otp").click(function(e) {
    e.preventDefault();
    var user_email = $('#email_id1').val();

    $.ajax({
        type: 'POST',
        url: "{{ route('superadmin.usermanagement.email_mobile_OTP') }}",
        data: {
            'user_email': user_email
        },
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        success: function(html) {
            Swal.fire("", "Re OTP Send!!", "success");
        }
    });
});

// end-----





$("#commonform1").validate({
    rules: {
        // user_password: { 
        // 	required: true,
        // 	minlength: 8,
        // 	maxlength: 10,
        // } ,
        mobile: {
            required: true,
        }
    },
    messages: {
        // user_password: { 
        // 	required:"This field is required and should be 8 digits, contains upper,lowerCase,and a special Character"   
        // },
        mobile: {
            required: "This field is required",
        }
    }

});

function CheckPassword(inputtxt) {
    if (inputtxt.value.length > 0) {
        var decimal = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
        if (inputtxt.value.match(decimal)) {
            return true;
        } else {
            Swal.fire('',
                'Password should be 8 digits,contains upperCase letter,lowerCase letter,and a special Character',
                'warning');
            $("#user_password").val('');
            return false;
        }
    }
}

function getpermission(selectedvalue) {
    $.ajax({
        type: 'POST',
        url: "",
        data: {
            'role': selectedvalue
        },
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        success: function(html) {
            Swal.fire("", "Re OTP Send!!", "success");
        }
    });
}
</script>
@php
$salt = rand('1000','9999');
session(['salt' => $salt]);
@endphp
<script type="text/javascript" src="{{ asset('public/backend/js/sha.js') }}"></script>
<script>
// $(document).on('submit','#commonform1',function(){
//     var salt = '{{ $salt }}';
//     var secret = $('#password').val();
//     var shaObj = new jsSHA("SHA-256", "TEXT");
//     shaObj.update(secret);
//     var hashPass = shaObj.getHash("HEX");
//     $('#password').val(hashPass);
//     var secretcurrent = $('#confirm_password').val();
//     var shaObjcurrent = new jsSHA("SHA-256", "TEXT");
//     shaObjcurrent.update(secretcurrent);
//     var hashPasscurrent = shaObjcurrent.getHash("HEX");
//     $('#confirm_password').val(hashPasscurrent);
// });
</script>
@endpush
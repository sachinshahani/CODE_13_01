@extends('admin.layouts.app')
@section('content')
    <div class="overlay">
        <div class="loader"></div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Role To Employee</h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);"></a></li>
                        <li class="breadcrumb-item active">Add Role To Employee</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header align-items-center d-flex">
                    <h4 class="card-title mb-0 flex-grow-1">Add Role To Employee</h4>
                    <div class="flex-shrink-0">
                        @if (session('error'))
                            <div class="alert alert-danger">
                                {{ session('error') }}
                            </div>
                        @endif
                        @if (session('success'))
                            <div class="alert alert-success">
                                {{ session('success') }}
                            </div>
                        @endif
                        @if ($errors)
                            @foreach ($errors->all() as $error)
                                <div class="alert alert-danger">{{ $error }}</div>
                            @endforeach
                        @endif
                    </div>
                </div>

                <div class="card-body">
                    <div class="live-preview">
                        <form action="#" class="commonform1"
                            method="POST" enctype="multipart/form-data" id="commonform1" autocomplete="off">
                            @csrf
                            <div class="row gy-4">
                                <div class="row seperatesec">
                                    <div class="col-xxl-3 col-md-3"></div>
                                </div>
                                <div class="row seperatesec white-inner">
                                    <div class="col-xxl-6 col-md-6 mt-4">
                                        <div>
                                            <label for="labelInput" class="form-label">Select Employee</label>
                                                <select class="form-select" name="emp_id" id="emp_id" required>
                                                    <option value="">Select Employee</option>
                                                    @forelse($user as $user)
                                                        <option value="{{ $user->id }}" 
                                                            @selected(old('emp_id') == $user->id) 
                                                            @if(in_array($user->id, $existingEmpIds)) disabled @endif>
                                                            {{ $user->first_name ?? '' }}
                                                        </option>
                                                    @empty
                                                        <option value="">No employees available</option>
                                                    @endforelse
                                                </select>
                                        </div>
                                    </div>
                                    <div class="col-xxl-6 col-md-6 gy-4">
                                        <div>
                                            <label for="labelInput" class="form-label">Status</label>
                                            <select class="form-select" name="role_status" id="role_status" required>
                                                <option value="">Select Status</option>
                                                <option value="1">Activate</option>
                                                <option value="0">De-activate</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-xxl-6 col-md-6 gy-4">
                                        <div>
                                            <label for="moduleSelect" class="form-label">Select Module</label>
                                            <select class="form-select select-multiple" name="module[]" multiple="multiple"
                                                id="moduleSelect" required>
                                                <option value="">Select Role</option>
                                                @forelse($module as $module)
                                                    <option value="{{ $module->id }}" @selected(old('module_name') == $module->id)>
                                                        {{ $module->module_name ?? '' }}
                                                    </option>
                                                @empty
                                                @endforelse
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-xxl-6 col-md-6 gy-4">
                                        <div id="subModuleContainer">
                                            <label for="subModuleSelect" class="form-label">Select Sub-Module</label>
                                            <select class="form-select" name="submodule[]" multiple="multiple"
                                                id="submoduleSelect">
                                                <option value="">Select Sub-Module</option>
                                                <!-- Sub-module options will be appended here -->
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-xxl-6 col-md-6 gy-4">
                                        <div>
                                            <label for="labelInput" class="form-label">Remark</label>
                                            <textarea class="form-control customtextarea" name="remark" id="remark" required>{{ old('remark') }}</textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="row seperatesec">
                                    <div class="row">
                                        <div class="col-lg-12 gy-4">
                                            <div class="hstack gap-2">
                                                <button type="button" id="ajaxSubmit"
                                                    class="btn btn-primary">Submit</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const moduleSelect = document.getElementById('moduleSelect');
        const submoduleSelect = document.getElementById('submoduleSelect');

        // Get the submodules data from the backend
        const submodulesData = @json($submodule);

        // To keep track of already added submodules
        let addedSubmoduleIds = new Set();

        moduleSelect.addEventListener('change', function() {
            const selectedModuleIds = Array.from(this.selectedOptions).map(option => option.value);

            // Filter submodules based on the selected modules
            const filteredSubmodules = submodulesData.filter(sub => selectedModuleIds.includes(sub
                .module_id.toString()));

            // Populate the submodule select options, without clearing the previous ones
            filteredSubmodules.forEach(submodule => {
                if (!addedSubmoduleIds.has(submodule.id)) { // Only add if not already added
                    const option = document.createElement('option');
                    option.value = submodule.id; // Adjust based on submodule unique identifier
                    option.textContent = submodule.sub_module_name || '';
                    option.setAttribute('data-module', submodule
                    .module_id); // Add data-module attribute with module_id
                    submoduleSelect.appendChild(option);

                    // Add the submodule ID to the tracking Set
                    addedSubmoduleIds.add(submodule.id);
                }
            });
        });

        document.getElementById('ajaxSubmit').addEventListener('click', function(event) {
            // Prevent the default action
            event.preventDefault();
            const button = this; 
            const formData = new FormData(document.getElementById('commonform1'));

            const selectedSubmodules = Array.from(submoduleSelect.selectedOptions).map(option => {
                return {
                    id: option.value,
                    module_id: option.getAttribute('data-module')
                };
            });


            // Add the selected submodules to the FormData
            formData.append('submodules', JSON.stringify(selectedSubmodules));
            formData.append('_method', 'POST'); // Include _method field for Laravel to interpret as PUT

            // Disable the button and show processing message
            button.disabled = true;
            button.textContent = "Processing..."; // Change button text to "Processing..."
            // AJAX Request
            $.ajax({
                url: "{{ route('superadmin.usermanagement.usercreate_role.store') }}",
                type: "POST",
                data: formData,
                processData: false,
                contentType: false,
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    Swal.fire({
                        title: 'Success',
                        text: "Employee Module and mappings created successfully.",
                        icon: 'success',
                        confirmButtonText: 'Okay'
                    });
                    window.location.href = '/superadmin/usermanagement/rolelist';
                    //console.log(response);
                },
                error: function(xhr, status, error) {
                    Swal.fire({
                        title: 'Error',
                        text: xhr.responseJSON.error || 'Something went wrong!',
                        icon: 'error',
                        confirmButtonText: 'Okay'
                    });
                    //console.log(xhr.responseText);
                },
                complete: function() {
                    // Re-enable the button and reset text once the request is complete
                    button.disabled = false;
                    button.textContent = "Submit"; // Change back to original button text
                }
            });
        });
    });
</script>

@extends('admin.layouts.app')
@section('content')
<style>
    .page-content {
        background: #F2FBF9;
    }

    .marquee-bg{background: #f3f3f3;
        padding: 8px;}
.marquee-container {
  width: 930px;
  overflow: hidden;
  white-space: nowrap;

}

.marquee-content {
  display: inline-block;
  padding-left: 100%;
  animation: scroll-left 10s linear infinite;
  animation-play-state: running; /* Default state is running */
}

/* Stop animation on hover */
.marquee-container:hover .marquee-content {
  animation-play-state: paused;
}

.marquee-title {
margin-right: 30px; 
font-size: 18px;  
color: #333;  
text-decoration: none;
padding: 5px 10px;
transition: color 0.3s ease;
}

.marquee-title:hover {
color: #007BFF;  /* Change color when hovered */
}


@keyframes scroll-left {
  from {
    transform: translateX(0%);
  }
  to {
    transform: translateX(-100%);
  }
}


</style>
    <!-- start page title -->
    {{-- <div class="row">
                        <div class="col-12">
                            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                <h4 class="mb-sm-0">Home</h4>

                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">Home</a></li>

                                    </ol>
                                </div>

                            </div>
                        </div>
                    </div> --}}
    <!-- end page title -->

    @if (isset(auth()->user()->ref_operator_type_id) && auth()->user()->ref_operator_type_id == 1)
        <div class="container-fluid cus-dash-div">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <h4 class="mb-sm-0"></h4>
                        <h5>System IP Address: {{ $ipAddress }}</h5>
                        {{-- <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">As on :</a></li>
                                <li class="breadcrumb-item">
                                    <form class="form-inline">
                                        <div class="form-group">
                                            <input type="date" class="form-control cu-form-control" id="inputPassword2">
                                        </div>
                                    </form>
                                </li>
                            </ol>
                        </div> --}}

                    </div>
                </div>
            </div>


            <!-- end page title -->
            <div class="row">
                <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                    <div class="card dashb-box gradient-colr">
                        <div class="card-body p-0">
                            <div class="img-part">
                                <img src="{{ asset('public/assets/images/micon-1.png') }}" alt="">
                            </div>
                            <div class="txt-part">
                                <p>Total Active Registered Operators
                               
                               </p>
                                <h3 id="user_id"></h3>
                                <p id="user_date"></p>
                                <div class="digital-clock">00:00:00</div>

                            </div>
                        </div><!-- end card body -->
                    </div><!-- end card -->
                </div><!-- end col -->
                <div class="col-12 col-sm-12 col-md-9 col-lg-9 col-xl-9 ps-2">
                    <div class="more-cards-inner">
                        <div class="card dashb-box blue-bx">
                            <a href="{{route('superadmin.GrowerGroup')}}">
                                <div class="card-body p-0">
                                    <div class="img-part">
                                        <img src="{{ asset('public/assets/images/micon-2.png') }}" alt="">
                                    </div>
                                    <div class="txt-part">
                                        <p>Grower Groups</p>
                                        <p class="colr-txt" id="ics_id"></p>

                                    </div>
                                </div>
                            </a>
                            <!-- end card body -->
                        </div><!-- end card -->
                          <div class="card dashb-box green-bx">
                            <a href="{{route('superadmin.Farmer')}}">
                                <div class="card-body p-0">
                                    <div class="img-part">
                                        <img src="{{ asset('public/assets/images/micon-5.png') }}" alt="">
                                    </div>
                                    <div class="txt-part">
                                        <p>No. of Farmers under Grower Groups</p>
                                        <p class="colr-txt" id="farmer_id"></p>
                                    </div>
                                </div>
                            </a> 
                        </div>
                        <div class="card dashb-box pink-bx">
                            <a href="{{route('superadmin.Farm')}}">
                                <div class="card-body p-0">
                                    <div class="img-part">
                                        <img src="{{ asset('public/assets/images/micon-9.png') }}" alt="">
                                    </div>
                                    <div class="txt-part">
                                        <p>No. of Farms under Grower Groups</p>
                                        <p class="colr-txt" id="farm_id"></p>
                                    </div>

                                    <div class="txt-part cust_side_card_content">
                                        <p>Total Land(Ha)</p>
                                        <p class="colr-txt" id="land_id"></p>
                                    </div>
                                </div>
                            </a>
                        </div>
                       
                       
                       

                        <!-- end card -->
                      
                        
                        <div class="card dashb-box purple-bx">
                            <a href="{{route('superadmin.IP')}}">
                                <div class="card-body p-0">
                                    <div class="img-part">
                                        <img src="{{ asset('public/assets/images/micon-3.png') }}" alt="">
                                    </div>
                                    <div class="txt-part">
                                        <p>Individual Producers</p>
                                        <p class="colr-txt" id="individual_id"></p>
                                    </div>
                                </div>
                            </a>
                            
                        </div>
                        <div class="card dashb-box drk-brown-bx">
                            <a href="{{route('superadmin.Processor')}}">
                                <div class="card-body p-0">

                                    <div class="img-part">
                                        <img src="{{ asset('public/assets/images/micon-4.png') }}" alt="">
                                    </div>
                                    <div class="txt-part">
                                        <p>Processors</p>
                                        <p class="colr-txt" id="processor_id"></p>
                                    </div>

                                </div>
                            </a>
                           
                        </div>
                        <div class="card dashb-box yellow-bx">
                            <a href="{{route('superadmin.Trader')}}">
                                <div class="card-body p-0">
                                    <div class="img-part">
                                        <img src="{{ asset('public/assets/images/micon-7.png') }}" alt="">
                                    </div>
                                    <div class="txt-part">
                                        <p>Traders</p>
                                        <p class="colr-txt" id="trader_id"></p>
                                    </div>
                                </div>
                            </a><!-- end card body -->
                        </div>
                        <div class="card dashb-box drk-blue-bx">
                            <a href="{{route('superadmin.Wh')}}">
                                <div class="card-body p-0">
                                    <div class="img-part">
                                        <img src="{{ asset('public/assets/images/micon-6.png') }}" alt="">
                                    </div>
                                    <div class="txt-part">
                                        <p>Wild Harvestor</p>
                                        <p class="colr-txt" id="harvester_id"></p>
                                    </div>
                                </div>
                            </a><!-- end card body -->
                        </div><!-- end card -->
                        <div class="card dashb-box orng-bx">
                            <a href="{{route('superadmin.Products')}}">
                                <div class="card-body p-0">
                                    <div class="img-part">
                                        <img src="{{ asset('public/assets/images/micon-8.png') }}" alt="">
                                    </div>
                                    <div class="txt-part">
                                        <p>Total HSCODE</p>
                                        <p class="colr-txt" id="product_id"></p>
                                    </div>
                                </div>
                            </a>
                            
                        </div>
                    </div>
                </div><!-- end col -->
            </div><!-- end row -->
        </div>
        {{-- <div class="row">
                        <div class="col-xl-12">
                            <div class="card crm-widget">
                                <div class="card-body p-0">
                                    <div class="row row-cols-xxl-5 row-cols-md-4 row-cols-1 g-0 white-inner">
                                        <div class="col-xxl-2 col-md-2">
                                            <div class="mt-2 mt-md-0 py-3 px-3">
                                                <h5 class="text-muted text-uppercase fs-13">ICS <i class="ri-arrow-up-circle-line text-success fs-18 float-end align-middle"></i></h5>
                                                <div class="d-flex align-items-center">
                                                    <div class="flex-shrink-0">
                                                        <i class="ri-user-line display-6 text-muted"></i>
                                                    </div>
                                                    <div class="flex-grow-1 ms-3">
                                                        <h2 class="mb-0"><span class="counter-value" data-target="{{$ics ?? '0'}}">0</span></h2>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!-- end col -->
                                        <div class="col-xxl-2 col-md-2">
                                            <div class="mt-2 mt-md-0 py-3 px-3">
                                                <h5 class="text-muted text-uppercase fs-13"> Individual Producer <i class="ri-arrow-up-circle-line text-success fs-18 float-end align-middle"></i></h5>
                                                <div class="d-flex align-items-center">
                                                    <div class="flex-shrink-0">
                                                        <i class="ri-user-line display-6 text-muted"></i>
                                                    </div>
                                                    <div class="flex-grow-1 ms-3">
                                                        <h2 class="mb-0"> <span class="counter-value" data-target="{{$individual ?? '0'}}">0</span></h2>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!-- end col -->
                                        <div class="col-xxl-2 col-md-2">
                                            <div class="mt-2 mt-md-0 py-3 px-3">
                                                <h5 class="text-muted text-uppercase fs-13">Wild Harvester <i class="ri-arrow-up-circle-line text-success fs-18 float-end align-middle"></i></h5>
                                                <div class="d-flex align-items-center">
                                                    <div class="flex-shrink-0">
                                                        <i class="ri-user-line display-6 text-muted"></i>
                                                    </div>
                                                    <div class="flex-grow-1 ms-3">
                                                        <h2 class="mb-0"><span class="counter-value" data-target="{{$harvester ?? '0'}}">0</span></h2>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!-- end col -->
                                        <div class="col-xxl-2 col-md-2">
                                            <div class="mt-2 mt-lg-0 py-3 px-3">
                                                <h5 class="text-muted text-uppercase fs-13">Trader <i class="ri-arrow-up-circle-line text-success fs-18 float-end align-middle"></i></h5>
                                                <div class="d-flex align-items-center">
                                                    <div class="flex-shrink-0">
                                                        <i class="ri-user-line display-6 text-muted"></i>
                                                    </div>
                                                    <div class="flex-grow-1 ms-3">
                                                        <h2 class="mb-0"><span class="counter-value" data-target="{{$trader ?? '0'}}">0</span></h2>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!-- end col -->
                                        <div class="col-xxl-2 col-md-2">
                                            <div class="mt-3 mt-lg-0 py-3 px-3">
                                                <h5 class="text-muted text-uppercase fs-13">Processor <i class="ri-arrow-up-circle-line text-success fs-18 float-end align-middle"></i></h5>
                                                <div class="d-flex align-items-center">
                                                    <div class="flex-shrink-0">
                                                        <i class="ri-user-line display-6 text-muted"></i>
                                                    </div>
                                                    <div class="flex-grow-1 ms-3">
                                                        <h2 class="mb-0"><span class="counter-value" data-target="{{$processor ?? '0'}}">0</span></h2>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!-- end col -->
                                        <div class="col-xxl-2 col-md-2">
                                            <div class="mt-3 mt-lg-0 py-3 px-3">
                                                <h5 class="text-muted text-uppercase fs-13">Mandator <i class="ri-arrow-up-circle-line text-success fs-18 float-end align-middle"></i></h5>
                                                <div class="d-flex align-items-center">
                                                    <div class="flex-shrink-0">
                                                        <i class="ri-user-line display-6 text-muted"></i>
                                                    </div>
                                                    <div class="flex-grow-1 ms-3">
                                                        <h2 class="mb-0"><span class="counter-value" data-target="{{$mandators ?? '0'}}">0</span></h2>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                         <!-- end col -->
                                    </div><!-- end row -->
                                </div><!-- end card body -->
                            </div><!-- end card -->
                        </div><!-- end col -->
                    </div><!-- end row --> --}}

        {{-- <div class="row">
                        <div class="col-xl-12">
                            <div class="card crm-widget ">
                                <div class="card-body p-0 white-inner">
                                    <div class="row row-cols-xxl-5 row-cols-md-4 row-cols-1 g-0">

                                        <div class="col-xxl-12 col-md-12">
                                            <div class="mt-2 mt-md-0 py-3 px-3">

                                                <div class="d-flex align-items-center">

                                                     text here
                                                </div>
                                            </div>
                                        </div><!-- end col -->


                                         <!-- end col -->
                                    </div><!-- end row -->
                                </div><!-- end card body -->
                            </div><!-- end card -->
                        </div><!-- end col -->
                    </div><!-- end row --> --}}

        <div class="row">

            <div class="col-xl-12">

                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title mb-0">Month-wise Operators Registered by CB</h4>
                    </div>
                    <div class="card-body white-inner">
                        <div id="barchart_material" style="width: 100%; height: 350px;"></div>
                    </div>
                </div>

            </div>

        </div>
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title mb-0">Number of Farmers Under Grower Groups</h4>
                    </div><!-- end card header -->
                    <div class="card-body white-inner">
                        <div id="chart_div" style="width: 100%; height: 350px;" data-colors='["--vz-primary", "--vz-success", "--vz-warning", "--vz-danger"]'
                            class="e-charts" ></div>
                    </div><!-- end card-body -->
                </div><!-- end card -->
            </div>
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title mb-0">No. of Operators Registered State Wise By CB</h4>
                    </div>
                    <div class="card-body white-inner">
                        <div id="chart_div11" style="width: 100%; height: 350px;" data-colors='["--vz-primary", "--vz-success", "--vz-warning", "--vz-danger"]'
                            class="e-charts"></div>
                    </div>
                </div>
            </div>
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title mb-0">Total Transaction Certificate Issued</h4>
                    </div>
                    <div class="card-body white-inner">
                        <div id="chart-area" style="width: 100%; height: 350px;"></div>
                    </div>
                </div>
                
            </div>

            <!-- <div class="col-xl-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title mb-0">Total Scope Certificate Issued</h4>
                    </div>
                    <div class="card-body white-inner">
                        <div id="chart-sc"></div>
                    </div>
                </div>
            </div> -->
        </div>
        <style>
            .form-check-inline {
                display: inline-block;
                margin-right: 0%;
            }
        </style>
    @elseif (isset(auth()->user()->ref_operator_type_id) && auth()->user()->ref_operator_type_id == 2)
        <div class="row">
            <div class="col-xl-12">
                <div class="card crm-widget">
                    <div class="card-body p-0">
                        <div class="row row-cols-xxl-2 row-cols-md-2 row-cols-1 g-0">
                            <div class="col">
                                <div class="py-3 px-3">
                                    <h5 class="text-muted text-uppercase fs-13">No. of Inspectors <i
                                            class="ri-arrow-up-circle-line text-success fs-18 float-end align-middle"></i>
                                    </h5>
                                    <div class="d-flex align-items-center">
                                        <div class="flex-shrink-0">
                                            <i class="ri-user-line display-6 text-muted"></i>
                                        </div>
                                        <div class="flex-grow-1 ms-3">
                                            <h2 class="mb-0"><span class="counter-value"
                                                    data-target="{{ $insp ?? '0' }}">0</span></h2>
                                        </div>
                                    </div>
                                </div>
                            </div><!-- end col -->


                            <div class="col">
                                <div class="mt-3 mt-lg-0 py-3 px-3">
                                    <h5 class="text-muted text-uppercase fs-13">No. of Farmers <i
                                            class="ri-arrow-up-circle-line text-success fs-18 float-end align-middle"></i>
                                    </h5>
                                    <div class="d-flex align-items-center">
                                        <div class="flex-shrink-0">
                                            <i class="ri-user-line display-6 text-muted"></i>
                                        </div>
                                        <div class="flex-grow-1 ms-3">
                                            <h2 class="mb-0"><span class="counter-value"
                                                    data-target="{{ $farmers ?? '0' }}">0</span></h2>
                                        </div>
                                    </div>
                                </div>
                            </div><!-- end col -->
                            <!-- end col -->
                        </div><!-- end row -->
                    </div><!-- end card body -->
                </div><!-- end card -->
            </div><!-- end col -->
        </div><!-- end row -->


        {{-- <section class="content">
                        <div class="row">
                            <div class="col-lg-3 col-3">
                                <div class="small-box p-3 mb-2 bg-danger text-white">
                                    <div class="inner">
                                        <h3>15</h3>
                                        <p>Total no. of Pages</p>
                                    </div>
                                    <div class="icon"><i class="ion ion-bag"></i></div>
                                </div>
                            </div>
                            <div class="col-lg-2 col-2">
                                <div class="small-box bg-success text-white">
                                    <div class="inner">
                                        <h3>ICS</h3>
                                        <p>total  == 120</p>
                                    </div>
                                    <div class="icon"><i class="ion ion-stats-bars"></i></div>
                                </div>
                            </div>
                            <div class="col-lg-2 col-2">
                                <div class="small-box bg-success text-white">
                                    <div class="inner">
                                        <h3>2</h3>
                                        <p>Total no. of</p>
                                    </div>
                                    <div class="icon"><i class="ion ion-person-add"></i></div>
                                </div>
                            </div>
                            <div class="col-lg-2 col-2">
                                <div class="small-box bg-success text-white">
                                    <div class="inner">
                                        <h3>2</h3>
                                        <p>Total no. of Banners </p>
                                    </div>
                                    <div class="icon"><i class="ion ion-pie-graph"></i></div>
                                </div>

                            </div>
                            <div class="col-lg-2 col-2">
                                <div class="small-box bg-success text-white">
                                    <div class="inner">
                                        <h3>2</h3>
                                        <p>Total no. of Banners </p>
                                    </div>
                                    <div class="icon"><i class="ion ion-pie-graph"></i></div>
                                </div>
                            </div>



                            <div class="col-lg-2 col-2">
                                <div class="small-box bg-success text-white">
                                    <div class="inner">
                                        <h3>2</h3>
                                        <p>Total no. of News items</p>
                                    </div>
                                    <div class="icon"><i class="ion ion-stats-bars"></i></div>
                                </div>
                            </div>
                            <div class="col-lg-2 col-2">
                                <div class="small-box bg-success text-white">
                                    <div class="inner">
                                        <h3>2</h3>
                                        <p>Total no. of </p>
                                    </div>
                                    <div class="icon"><i class="ion ion-person-add"></i></div>
                                </div>
                            </div>
                            <div class="col-lg-2 col-2">
                                <div class="small-box bg-success text-white">
                                    <div class="inner">
                                        <h3>2</h3>
                                        <p>Total no. of Banners </p>
                                    </div>
                                    <div class="icon"><i class="ion ion-pie-graph"></i></div>
                                </div>
                            </div>
                            <div class="col-lg-2 col-2">
                                <div class="small-box bg-success text-white">
                                    <div class="inner">
                                        <h3>2</h3>
                                        <p>Total no. of Banners </p>
                                    </div>
                                    <div class="icon"><i class="ion ion-pie-graph"></i></div>
                                </div>
                            </div>
                        </div>
                    </section> --}}
    @endif
    {{-- <div class="row">
                        <div class="col-xxl-6">
                            <div class="card">
                                <div class="card-header align-items-center d-flex">
                                    <h4 class="card-title mb-0 flex-grow-1">Sales Forecast</h4>
                                    <div class="flex-shrink-0">
                                        <div class="dropdown card-header-dropdown">
                                            <a class="text-reset dropdown-btn" href="#" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <span class="fw-semibold text-uppercase fs-12">Sort by: </span><span class="text-muted">Nov 2021<i class="mdi mdi-chevron-down ms-1"></i></span>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-end">
                                                <a class="dropdown-item" href="#">Oct 2021</a>
                                                <a class="dropdown-item" href="#">Nov 2021</a>
                                                <a class="dropdown-item" href="#">Dec 2021</a>
                                                <a class="dropdown-item" href="#">Jan 2022</a>
                                            </div>
                                        </div>
                                    </div>
                                </div><!-- end card header -->
                                <div class="card-body pb-0">
                                    <div id="sales-forecast-chart" data-colors='["--vz-primary", "--vz-success", "--vz-warning"]' class="apex-charts" dir="ltr"></div>
                                </div>
                            </div><!-- end card -->
                        </div><!-- end col -->

                         <!-- end col -->

                        <div class="col-xxl-6">
                            <div class="card card-height-100">
                                <div class="card-header align-items-center d-flex">
                                    <h4 class="card-title mb-0 flex-grow-1">Balance Overview</h4>
                                    <div class="flex-shrink-0">
                                        <div class="dropdown card-header-dropdown">
                                            <a class="text-reset dropdown-btn" href="#" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <span class="fw-semibold text-uppercase fs-12">Sort by: </span><span class="text-muted">Current Year<i class="mdi mdi-chevron-down ms-1"></i></span>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-end">
                                                <a class="dropdown-item" href="#">Today</a>
                                                <a class="dropdown-item" href="#">Last Week</a>
                                                <a class="dropdown-item" href="#">Last Month</a>
                                                <a class="dropdown-item" href="#">Current Year</a>
                                            </div>
                                        </div>
                                    </div>
                                </div><!-- end card header -->
                                <div class="card-body px-0">
                                    <ul class="list-inline main-chart text-center mb-0">
                                        <li class="list-inline-item chart-border-left me-0 border-0">
                                            <h4 class="text-primary">$584k <span class="text-muted d-inline-block fs-13 align-middle ms-2">Revenue</span></h4>
                                        </li>
                                        <li class="list-inline-item chart-border-left me-0">
                                            <h4>$497k<span class="text-muted d-inline-block fs-13 align-middle ms-2">Expenses</span>
                                            </h4>
                                        </li>
                                        <li class="list-inline-item chart-border-left me-0">
                                            <h4><span data-plugin="counterup">3.6</span>%<span class="text-muted d-inline-block fs-13 align-middle ms-2">Profit Ratio</span></h4>
                                        </li>
                                    </ul>

                                    <div id="revenue-expenses-charts" data-colors='["--vz-success", "--vz-danger"]' class="apex-charts" dir="ltr"></div>
                                </div>
                            </div><!-- end card -->
                        </div><!-- end col -->
                    </div><!-- end row --> --}}

    <!-- end row -->
    {{-- <div class="marquee-bg">
        <div class="container">
          <div class="row">
              <div class="col-xl-10">
                  <div class="marquee-container">
                      <div class="marquee-content">
                      @foreach($announcement_list as $value)
                          <a href="{{ asset('public/attachment/attachment/' . $value->attachment) }}" class="marquee-title">{{ $value->title }}</a>
                      @endforeach
                      </div>
                  </div>
              </div>
              <div class="col-xl-2">
                  <div class="d-flex justify-content-end">
                      <a href="{{ route('superadmin.announcementlist') }}" class="btn btn-primary justify-co">View All</a>
                  </div>
              </div>
             </div>
         </div>
       </div> --}}

    <!-- end row -->
@endsection
@push('script')
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>


    <script>
        $('#sc_certificate').on('change', function(e) {
            //alert('aaa');
            $('#sc_form').submit();
        });
        $(document).ready(function() {
            $('#dtBasicExample').DataTable();
            $('.dataTables_length').addClass('bs-select');
        });
        $(document).ready(function() {
            $('#dtBasicExamplesss').DataTable();
            $('.dataTables_length').addClass('bs-select');
        });

        google.charts.load("current", {
            packages: ['corechart', 'bar']
        });
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {
            var data = google.visualization.arrayToDataTable([
                ['Task', 'Hours per Day'],
                ['Total Units', 30],
                ['Dropped Units', 70],
            ]);
            var options = {
                pieHole: 0.5,
            };
            var chart = new google.visualization.PieChart(document.getElementById('donutchart1'));
            chart.draw(data, options);
        }


        // chart 1
        google.charts.load('current', {'packages':['bar']});
        google.charts.setOnLoadCallback(drawChart2);
        function drawChart2() {
            var data = google.visualization.arrayToDataTable(<?php echo json_encode($chartData); ?>);

                var options = {
                    chart: {
                        subtitle: 'Month Wise',
                    },
                    bars: 'vertical', // Render bars vertically
                    hAxis: {
                        title: 'Months',
                    },
                    vAxis: {
                        title: 'Number of Operators',
                    }
                };

                var chart = new google.charts.Bar(document.getElementById('barchart_material'));
                chart.draw(data, google.charts.Bar.convertOptions(options));
            }
        //chart 1


        // chart 2
        google.charts.setOnLoadCallback(drawBasic);

function drawBasic() {
    @if ($icsWithFarmerCount->isEmpty())
        // If $icsWithFarmerCount is empty, show a blank chart (without data points)
        var data = google.visualization.arrayToDataTable([
            ['Farmers', 'Registered', { role: 'style' }],
            // Empty data, blank chart
            ['No Data', 0, '#cccccc'] // Default value to show when no data is available
        ]);
    @else
        // Prepare data for chart if $icsWithFarmerCount is not empty
        var data = google.visualization.arrayToDataTable([
            ['Farmers', 'Registered', { role: 'style' }],
            @foreach ($icsWithFarmerCount as $val)
                ['{{ $val->first_name }}', {{ $val->users }}, '#1b9e77'],
            @endforeach
        ]);
    @endif

    var options = {
        title: 'No. of Farmers Registered.',
        hAxis: {
            title: 'Grower Groups',
        },
        vAxis: {
            title: '',
            format: '0',
        }
    };

    var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));
    chart.draw(data, options);
}

        // chart 2
                // chart 3
        google.charts.setOnLoadCallback(drawBasic111);

        function drawBasic111() {

            @if (!empty($operatorCountByState))
            var data = google.visualization.arrayToDataTable([
                ['State', 'Operators'],
                @foreach ($operatorCountByState as $val)
                    @if (isset($val['ref_state_id']) && $val['ref_state_id'] != '')
                        ['{!! get_state_name($val['ref_state_id']) !!}', {{ $val['users'] }}],
                    @endif
                @endforeach
            ]);
            @else
                // Default data for an empty array
                var data = google.visualization.arrayToDataTable([
                    ['State', 'Operators'],
                    ['No Data', 0]
                ]);
            @endif
        var options = {
            title: 'No. of Operators Registered State Wise By CB',
            bars: 'vertical', // Ensures the bars are vertical
            vAxis: {
                title: '..',
                format: '0' // This will format the vAxis to show only whole numbers
            },
            hAxis: {
                title: 'States'
            },
            // height: 350,
            // width: 600, // Set the width explicitly
            colors: ['#1b9e77']
        };
        var chart = new google.visualization.ColumnChart(document.getElementById('chart_div11'));
        chart.draw(data, options);
        }

        // chart 3

       // chart 4
google.charts.setOnLoadCallback(drawChart4);

function drawChart4() {
    @if ($tcData1->isEmpty())
    // If the collection is empty, show a blank chart (without data points)
    var data = google.visualization.arrayToDataTable([
        ['Transaction Certificate', 'Monthwise'],
        // Empty data - will render a blank chart without bars
        ['No Data', 0]
    ]);
    @else
    // Prepare data for chart if tcData1 is not empty
    var data = google.visualization.arrayToDataTable([
        ['Transaction Certificate', 'Monthwise'],
        @foreach ($tcData1 as $val)
            // Ensure count is a valid number (default to 0 if null or empty)
            ['{{ $val->month_year }}', {{ $val->count ?? 0 }}],
        @endforeach
    ]);
    @endif
    
    // Chart options
  var options = {
                title: 'Month wise Transaction Certificate Issued',
                bars: 'vertical', // Ensures the bars are vertical
                vAxis: {
                    title: '..',
                    format: '0', // This will format the vAxis to show only whole numbers
                },
                hAxis: {
                    title: 'Month-Year'
                }
                // height: 350,
                // width: 600, // Set the width explicitly
                
            };
    // Create the chart and draw it
    var chart = new google.visualization.ColumnChart(document.getElementById('chart-area'));
    chart.draw(data, options);
}


        ///////////chart 5


        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {
            var data = google.visualization.arrayToDataTable([
                ['Operator Type', 'SC'],
                ['Individual Producer', 4],
                ['Processor', 4],
                ['Grower Group', 9],
                ['Trader', 2],
                ['Wild Harvest', 05],
            ]);

            var options = {
                title: 'Certificates Issued',
                isStacked: true,
                hAxis: {
                    title: 'Operators'
                },
                vAxis: {
                    title: 'Number of Certificates'
                }
            };

            var options = {
                title: 'Certificates Issued',
                hAxis: {
                    title: 'Month-Year',
                    slantedText: true, // Optional: Makes the axis labels slanted for better readability
                    slantedTextAngle: 15, // Optional: Adjusts the angle of the slanted labels
                    textStyle: {
                        fontSize: 8,
                        bold:true // Optional: Customize font size for the labels
                    }
                },
                vAxis: {
                
                    minValue: 0
                },
                tooltip: {
                    isHtml: true, // Allow HTML in tooltips (this is optional for the tooltip part)
                    trigger: 'focus'
                }
            };

            var chart = new google.visualization.AreaChart(document.getElementById('chart-sc'));
            chart.draw(data, options);
        }
        ///////////chart 5


        $(document).ready(function() {
            $('#loading').html('Page is loaded!');

        });
    </script>
    <script>
        $(document).ready(function() {

            $('#user_id, #product_id, #farmer_id, #farm_id, #land_id #ics_id, #individual_id, #harvester_id, #trader_id, #processor_id, #mandators_id')
                .html(
                    '<div id="loading"><img id="loading-image" src="{{ asset('public/assets/images/preloader.gif') }}" alt="Loading..." /></div>'
                );
            $.ajax({
                url: "{{ route('superadmin.dashboardajaxcall') }}",
                method: 'POST',
                type: "script",
                success: function(response) {
                    try {
                        $('#user_date').html('Date & Time : ' + response.user_date);
                        $('#user_id').html(response.user);
                        $('#ics_id').html(response.ics);
                        $('#individual_id').html(response.individual);
                        $('#harvester_id').html(response.harvester);
                        $('#trader_id').html(response.trader);
                        $('#processor_id').html(response.processor);
                        $('#farmer_id').html(response.farmer);
                        // $('#farm_id').html('Total Land (Ha): ' + response.farm);
                        $('#farm_id').html(response.farm);
                        $('#land_id').html(response.land);
                        $('#product_id').html('Total Products: ' + response.product);
                        // $('#mandators_id').html(response.mandators);
                    } catch (error) {
                        console.error('Error parsing JSON: ' + error);
                    }
                },
                complete: function(jqXHR, textStatus) {
                    // alert("request complete "+textStatus);
                },
                error: function(xhr, textStatus, errorThrown) {
                    alert('request failed->' + textStatus);
                    console.log('request failed->' + xhr);

                }
            });
        });


        //--------------clock js by gaurav--------------
        $(document).ready(function() {
            clockUpdate();
            setInterval(clockUpdate, 1000);
        })

        function clockUpdate() {
            var date = new Date();
            $('.digital-clock').css({
                'color': '#fff',
                'text-shadow': '0 0 6px #ff0'
            });

            function addZero(x) {
                if (x < 10) {
                    return x = '0' + x;
                } else {
                    return x;
                }
            }

            function twelveHour(x) {
                if (x > 12) {
                    return x = x - 12;
                } else if (x == 0) {
                    return x = 12;
                } else {
                    return x;
                }
            }

            var h = addZero(twelveHour(date.getHours()));
            var m = addZero(date.getMinutes());
            var s = addZero(date.getSeconds());

            $('.digital-clock').text(h + ':' + m + ':' + s)
        }
    </script>
@endpush

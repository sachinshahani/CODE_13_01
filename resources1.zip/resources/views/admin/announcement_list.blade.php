@extends('admin.layouts.app')
@section('content')
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">All Announcement
            </h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">All Announcement</li>
                </ol>
            </div>
        </div>
    </div>
</div>
<div class="row">

    <div class="col-lg-12">
        <div class="card">

            <div class="card-body table-responsive">
            <table id="announcementTable" class="table table-bordered table-striped align-middle" style="width:100%">
                        <thead>
                            <tr>
                                <th>S No.</th>
                                <th>Title</th>
                                <th>Type</th>
                                <th>Content</th>
                                <th>Published Date</th>
                                <th>Related Link</th>
                                <th>Attachment</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td colspan="7">No Record found.</td>
                            </tr>
                        </tbody>
                    </table>
            </div>
        </div>
    </div>
</div>
@endsection
@push('script')
        <script>
         $.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

var table = $('#announcementTable').DataTable({
    dom: 'Bfrtip',
    lengthMenu: [
        [10, 25, 50, -1],
        [10, 25, 50, "All"]
    ],
    processing: true,
    serverSide: true,
    ajax: {
        url: '{{ route('superadmin.announcementlist') }}', 
        type: 'GET',
        error: function(xhr, error, code) {
            console.log(xhr.responseText);  // Log any errors
        }
    },
    columns: [
        { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: true },
        { data: 'title', name: 'title', orderable: true },
        { data: 'type', name: 'type', orderable: true },
        { data: 'content', name: 'content', orderable: true },
        { data: 'published_date', name: 'published_date', orderable: true },
        { data: 'related_link', name: 'related_link', orderable: true },
        { data: 'attachment', name: 'attachment', orderable: true }
    ],
    paging: false,  // Set to false for non-pagination (if needed)
    buttons: [
        'excelHtml5',
        {
            extend: 'csvHtml5',
            title: function() { return "REPORTS"; },
            titleAttr: 'CSV REPORTS'
        },
        {
            extend: 'pdfHtml5',
            title: function() { return "PDF REPORTS"; },
            orientation: 'landscape',
            pageSize: 'A4',
            titleAttr: 'PDF REPORTS'
        }
    ],
    language: {
        emptyTable: "No Record found."
    }
});

$('#financial').change(function() {
    table.draw();  // Trigger table refresh when the filter is changed
});

        </script>
    @endpush

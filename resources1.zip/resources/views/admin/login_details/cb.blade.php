@extends('admin.layouts.app')
@section('title', 'User Profile')
@section('content')

    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Profile</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item active">Profile</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="white-inner">
                <p class="fw-bolder">Last Login Details:</p>
                <div class="table-responsive">
                    <table id="searchResultsTable" class="table table-bordered table-striped align-middle"
                        style="width:100%">
                        <thead>
                            <tr>

                                <th>User Name</th>
                                <th>User Type</th>
                                <th>System IP Address</th>
                                <th>User Action</th>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Browser name</th>
                                <th>Device name</th>
                                <th>Action</th>


                            </tr>
                        </thead>
                        <tbody>


                            @foreach ($cblogindata as $data)
                            
                                <tr class="pro-tr">
                                    <td>{{ $data->user_name ?? '' }}</td>
                                    <td>{{ $data->user_type ?? '' }}</td>
                                    <td>{{ $data->ip_address ?? '' }}</td>
                                    @if($data->user_action === 'Logout Successfully')
                                        <td><span class="badge bg-warning">{{ $data->user_action ?? '' }}</span></td>
                                    @else
                                        <td><span class="badge bg-success">{{ $data->user_action ?? '' }}</span></td>
                                    @endif

                                    <td>{{ isset($data->created_on) ? date('d-m-Y', strtotime($data->created_on)) : '' }}
                                    </td>
                                    <td>{{ isset($data->created_on) ? date('H:i A', strtotime($data->created_on)) : '' }}
                                    </td>
                                     
                                    <td>{{ $data->device_name ?? '' }}</td>
                                    <td>{{ $data->device_type ?? '' }}</td>
                                    <td>{{ $data->action_url ?? '' }}</td>
                                    
                                </tr>
                            @endforeach

                        </tbody>
                    </table>
                </div>

            </div>


        </div>
        <!--end col-->
    </div>

@endsection

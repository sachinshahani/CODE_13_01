@extends('admin.layouts.app')
@section('content')

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Digital Signature Example</title>
</head>

<body>
    <form action="{{route('superadmin.sign-and-verify')}}" method="post">
        @csrf
        <label for="data">Data to Sign:</label>
        <input type="text" class="form-controller" name="data" required>
        <button type="submit" >Sign</button>
    </form>
</body>

</html>










@endsection
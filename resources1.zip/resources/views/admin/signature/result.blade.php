@extends('admin.layouts.app')
@section('content')

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Digital Signature Result</title>
</head>
<body>
    <h2>Signature Result</h2>
    <p>Data: {{ $data }}</p>
    <!-- <p>Encrypted Data: {{ $encryptedData }}</p> -->
    <p>Decrypted Data: {{ $decryptedData }}</p>
</body>
</html>


@endsection
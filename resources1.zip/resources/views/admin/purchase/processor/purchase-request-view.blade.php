@extends('admin.layouts.app')
@section('content')
    <style>
        body {
            margin: 0px;
            padding: 0px;
            font-family: "Segoe UI";
        }

        .maindiv {
            width: 80%;
            margin: 0 auto;
        }

        .pdf_maindiv {
            border: 1px solid #cccccc;
            width: 100%;
            float: left;
            padding: 2% 1%;
        }

        .pdf_heading {
            font-size: 20px;
            color: #000;
            padding: 26px 0 20px 0px;
            position: relative;
            width: 100%;
            float: left;
        }

        .brd_heading {
            border-bottom: 2px solid #ee5e24;
            padding-bottom: 8px;
            padding-right: 8px;
            width: 60px;
        }

        .pdf_input1 {
            background: #eeeeee;
        }

        .pdf_txt1 {
            color: #000;
            font-size: 14px;
            width: 45%;
            float: left;
            padding-bottom: 10px;
            font-weight: bold;
        }

        .pdf_box {
            color: #000;
            font-size: 14px;
            width: 55%;
            float: left;
            padding-bottom: 10px;
        }

        .table_pdf {
            width: 100%;
        }

        .pdf_heading:after {
            content: "";
            position: absolute;
            width: 70px;
            height: 2px;
            background-color: #ee5e24;
            bottom: 10px;
            display: block;
        }

        .pdf_heading:before {
            content: "";
            position: absolute;
            width: 22px;
            height: 6px;
            background-color: #ee5e24;
            bottom: 8px;
            display: block;
        }

        #step1 .card-body {
            background: #fff
        }

        .pdf_inner_heading:after {
            display: none;
        }

        .pdf_inner_heading:before {
            display: none;
        }

        .pdf_inner_heading {
            padding: 20px 0 12px;
            text-decoration: underline;
            font-size: 16px;
        }

        .pdf_maindiv hr:last-child {
            display: none;
        }

        .pdf-img-icon {
            height: 17px;
            width: 15px;
            margin-right: 5px;
        }

        @media print {

            .pdf_heading {
                font-size: 20px;
                color: #000;
                padding: 26px 0 20px 0px;
                position: relative;
                width: 100%;
                float: left;
                -webkit-print-color-adjust: exact !important;
                Chrome,
                Safari color-adjust: exact !important;
            }

            .pdf_heading:before {
                content: "";
                position: absolute;
                width: 20px;
                height: 4px;
                background-color: #ee5e24;
                bottom: 10px;
                display: block;
                -webkit-print-color-adjust: exact !important;
                Chrome,
                Safari color-adjust: exact !important;
            }


        }
    </style>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Purchase Request View</h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Purchase Request View</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>


    <div class="row">
        <div class="col-lg-12">
            <form method="post" enctype="multipart/form-data" id="registration"
                action="{{route('superadmin.purchaseReqPost')}}">
                @csrf
                <div class="tab-content py-4 custom-tab-content">
                    <div class="tab-pane fade show active" id="step1">
                        <div class="card">
                            <div class="card-header align-items-center d-flex">
                                <h4 class="card-title mb-0 flex-grow-1">
                                    Order No. #00{{ $data->id }}
                                </h4>
                                <div class="flex-shrink-0">
                                </div>
                            </div>

                            <!-- end card header -->
                            <div class="card-body">
                                <div class="live-preview">
                                    <div class="row white-inner">
                                        <div class="col-xxl-3 col-md-4 gy-3">
                                            <div>
                                                <label class="form-label">Buyer </label>
                                                <input type="hidden" name="orderno" value="{{ $data->id }}">
                                                <input type="text" class="form-control" name="commodity"
                                                    value="{{ user_name($data->created_by) }}" readonly>
                                            </div>
                                        </div>




                                    <div class="col-xxl-3 col-md-4 gy-3">
                                        <div>
                                            <label for="labelInput" class="form-label">Product </label>
                                            <input type="hidden" name="commodity" value="{{ $data->commodity }}">
                                            <input type="text" class="form-control" name="product"
                                                value="{{ getRefProductById($data->commodity)->product_name ?? '' }}" readonly>
                                        </div>
                                    </div>

                                    <div class="col-xxl-3 col-md-4 gy-3">
                                        <div>
                                            <label for="labelInput" class="form-label">Status </label>
                                            <input type="hidden" name="status" value="{{ $data->status }}">
                                            <input type="text" class="form-control" name="status"
                                                value="{{ getRefOrganicStatusMasterByID($data->status) }}" readonly>

                                        </div>
                                    </div>

                                    <div class="col-xxl-3 col-md-4 gy-3">
                                        <div>
                                            <label for="labelInput" class="form-label">Quantity </label> <span
                                                class="text-success" id="avil_qty"> </span>

                                            <input type="text" class="form-control" name="commodity"
                                                value="{{ $data->quantity }}" readonly>
                                        </div>
                                    </div>

                                    <div class="col-xxl-3 col-md-4 gy-3">
                                        <div>
                                            <label for="labelInput" class="form-label">No. of Packages </label>

                                            <input type="text" class="form-control" id="name"
                                                placeholder="No. of Packages" name="no_of_packages"
                                                value="{{ $data->no_of_packages }}" readonly>
                                        </div>
                                    </div>
                                    <div class="col-xxl-3 col-md-4 gy-3">
                                        <div>
                                            <label for="labelInput" class="form-label">Copy of Performa Invoice </label>
                                            <br>
                                            <a href="{{ asset('public/purchase/' . $data->upload_copy_of_performa_invoice) }}"
                                                target="_blank" class="badge badge-soft-success">View</a>
                                        </div>
                                    </div>

                                    <div class="col-xxl-3 col-md-4 gy-3">
                                        <div>
                                            <label for="labelInput" class="form-label">Order Validity </label>

                                            <input type="text" class="form-control" id="name"
                                                placeholder="Order Validity " name="order_validity "
                                                value="{{ date('Y-m-d',strtotime("+15 days",strtotime($data->created_at)))}}" readonly>
                                        </div>
                                    </div>


                                    <div class="col-xxl-3 col-md-4 gy-3">
                                        <div>
                                            <label for="labelInput" class="form-label">Order Status </label>

                                            <select class="form-select" name="order_status" {{ !empty($data->order_status)?'disabled':'' }}>
                                                <option value="">Select Order Status</option>
                                                <option value="1" {{($data->order_status==1?"selected":'')}} >Accept</option>
                                                <option value="2" {{($data->order_status==2?"selected":'')}}>Reject</option>

                                            </select>
                                        </div>
                                    </div>


                                    </div>

                                    <div class="row">
                                        <div class="col-lg-12 gy-4">
                                            <div class="hstack gap-2">
                                                @if(empty($data->order_status))
                                                 <button type="submit" class="btn btn-primary" id="submitbtn">
                                                    Submit
                                                </button>
                                                @elseif($data->order_status==1)
                                                 <a href="{{ route('superadmin.acceptPurchase',$data->id)}}"
                                                    class="btn btn-soft-success">
                                                    View
                                                </a>
                                                @elseif($data->order_status==2)
                                                <a href="{{ route('superadmin.rejectPurchase',$data->id)}}"
                                                    class="btn btn-soft-success">
                                                    View
                                                </a>
                                                @endif
                                            </div>
                                        </div>
                                    </div>

                                </div>





                            </div>
                        </div>


                    </div>
                </div>





        </div>
        </form>
    </div>
    </div>







    </div>
@endsection

@push('script')
    <script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
    <script></script>
@endpush

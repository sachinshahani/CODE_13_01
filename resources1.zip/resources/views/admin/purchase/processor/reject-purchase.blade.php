@extends('admin.layouts.app')

@section('content')
    <style>
        .has-error {
            border: 1px solid red;
        }

        .errormsg {
            color: red;
            font-size: 14px !important;
        }
    </style>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0"> Reject Order</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Reject Order</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">


                <div class="tab-content py-4 custom-tab-content">
                    <div class="tab-pane fade show active" id="step1">
                        <div class="card">
                            <div class="card-header align-items-center d-flex">
                                <h4 class="card-title mb-0 flex-grow-1">
                                    Reject Order
                                </h4>
                            </div>
                            <form method="post" action="{{ route('superadmin.afterOrderRejectPost') }}">
                                @csrf
                                <div class="card-body">
                                    <div class="live-preview">
                                        <div class="row white-inner mt-1">
                                            <div class="col-xxl-12 col-md-12 gy-3">
                                                <div>
                                                    <label class="form-label">Reject Remark</label>
                                                    <textarea name="remark" class="form-control"></textarea>
                                                    <input type="hidden" name="hid_order_id" value="{{$id}}"> 
                                                </div>
                                            </div>
                                            <div class="col-lg-12 gy-4">
                                                <div class="hstack gap-2" style="float: right;">
                                                    <button type="submit" class="btn btn-primary" id="submitbtn">
                                                        Submit
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
        </div>
    </div>
@endsection
@push('script')
    <script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
    <script>
        $(document).on('click', '#submitbtn', function() {

        });
    </script>
@endpush

@extends('admin.layouts.app')
@section('content')
    <style>
        .wrapper {
            max-width: 1240px;
            margin: 0 auto;
        }

        .white-bg {
            background-color: white;
            border-bottom: 5px solid #ff9800;
            margin-bottom: 15px;
        }

        .auth-one-bg .slide .carousel-indicators {
            bottom: 25px;
        }

        .auth-page-wrapper .auth-page-content {
            padding-bottom: 0px !important;
        }

        .auth-page-content .card {
            margin-bottom: 0rem;
        }

        .data-tabs .wrapper .nav-tabs button {
            font-size: 17px;
            color: black;
        }

        .data-tabs .wrapper .nav-tabs .active {
            background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
            */ color: white;
            background: orange;
            border-radius: 0px;
        }

        .carousel-caption.d-none.d-md-block {
            background-color: #000000bf;
            left: 0;
            width: 100%;
            bottom: 0;
        }

        .carousel-indicators {
            display: none;
        }

        .custom-banner-caption {
            color: white !important;
        }

        .announcement-heading {
            font-size: 1.2em;
            font-weight: 600;
        }

        .data-tabs .tab-pane ul li {
            font-size: 1em;
            padding: 5px 0;
        }

        .main-logo {
            padding: 10px;
        }

        .data-tabs .nav-item .nav-link {
            background-image: none;
        }

        .navbar-brand-box {
            background: #fff;
        }

        .btn-danger {
            background-color: #40895a;
            border: 1px solid #40895a;
        }

        [data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
            color: white !important;
        }

        .header-buttons .btn-primary {
            margin-right: 10px;
            padding: 6px 15px;
            font-weight: 600;
            background-color: #207005;
            border: none;
            box-shadow: 0px 2px 7px #888888;
        }

        .header-buttons .btn-secondary {
            margin-right: 10px;
            padding: 6px 15px;
            font-weight: 600;
            background-color: #72a055;
            border: none;
            box-shadow: 0px 2px 7px #888888;
        }


        .right-sec {
            border-left: 5px solid #ede7e7;
        }

        .tabdiv {
            background: white;
            padding: 20px;
            margin-top: 10px;
            border: 10px solid #dfdbd5;
        }

        .nav-tabs {
            border-bottom: 0px;
        }

        div#myTabContent {
            border: 1px solid #cccccc;
        }

        .frontfooter footer {
            padding: 20px calc(1.5rem / 2);
            position: static;
            color: #000;
            height: 60px;
            background-color: #f9f9f9;
            margin-top: 30px;
            border-top: 1px solid #e1dfdf;
        }

        span.logo-sm img {
            width: 69px;
        }

        .seperatesec {
            margin-top: 20px;
        }

        .simplebar-content li.nav-item:hover {
            background: #4caf50;
        }

        .sectitle {
            font-size: 14px;
        }

        .required {
            color: red;
        }

        .customtextarea {
            height: 120px;
        }

        ul.boxsection {
            margin: 0;
            padding: 0;
        }

        ul.boxsection li {
            list-style-type: none;
            padding: 7px 0;
            border-bottom: 1px solid #efeded;
        }

        .boxcard .col:nth-child(1) {
            background: #effcfb;
        }

        .boxcard .col:nth-child(2) {
            background: #fdfdfd;
        }

        .boxcard .col:nth-child(3) {
            background: #effcfb;
        }

        .boxcard .col:nth-child(4) {
            background: #fdfdfd;
        }

        .boxcard .col:nth-child(5) {
            background: #effcfb;
        }

        .custom-tab-content {
            padding-top: 0 !important;
            padding-bottom: 0px !important;
        }

        .custom-tab-nav {
            background: white;
        }

        .custom-tab-nav .nav-link {
            border-radius: 0 !important;
            border-bottom: 1px solid #e9ebec;
            border-right: 1px solid #e9ebec;
            font-size: 14px;
            padding: 10px;
        }

        .custom-tab-nav .nav-link.active,
        .custom-tab-nav .show>.nav-link {
            color: rgb(255, 255, 255) !important;
            background-color: #2c8c6d;
            border-bottom: #2c8c6d !important;
            /* border-bottom: #207005 !important; */
            position: relative;
        }

        .custom-tab-nav .nav-link:hover,
        .custom-tab-nav .nav-link:focus {
            border-bottom: 1px solid #207005;
            border-radius: 0;
            font-size: 14px;
            transition: background-color 0.20s linear;
        }

        .custom-tab-nav .nav-link.active:after {
            content: "";
            position: absolute;
            bottom: -16px;
            left: 50%;
            border: 8px solid transparent;
            border-top-color: #2c8c6d;
            z-index: 999;
        }

        .reg-form-btns {
            margin-bottom: 15px;
        }

        .reg-form-btns .btn-secondary {
            color: #fff;
            background-color: #405189;
            border-color: #405189;
        }

        .btn-soft-success:active,
        .btn-soft-success:focus,
        .btn-soft-success:hover {
            border: none;
        }

        .custom-tab-nav ul {
            padding: 0px;
            margin: 0px;
        }

        .custom-tab-nav ul li {
            padding: 0px;
            margin: 0px;
            display: inline-block;
            list-style: none;
        }

        .has-error {
            border: 1px solid red;
        }

        .errormsg {
            color: red;
            font-size: 14px !important;
        }
    </style>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">PURCHASE REQUEST</h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">PURCHASE REQUEST</a></li>
                        <li class="breadcrumb-item active">Add PURCHASE REQUEST</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <form method="post" enctype="multipart/form-data" id="registration"
                action="{{ route('superadmin.addpurchaseRequest') }}">
                @csrf

                <div class="tab-content py-4 custom-tab-content">
                    <div class="tab-pane fade show active" id="step1">
                        <div class="card">
                            <div class="card-header align-items-center d-flex">
                                <h4 class="card-title mb-0 flex-grow-1">
                                    Add PURCHASE REQUEST
                                </h4>
                                <div class="flex-shrink-0">
                                    @if (session('error'))
                                        <div class="alert alert-danger">
                                            {{ session('error') }}
                                        </div>
                                    @endif
                                    @if (session('success'))
                                        <div class="alert alert-success">
                                            {{ session('success') }}
                                        </div>
                                    @endif
                                    @if ($errors)
                                        @foreach ($errors->all() as $error)
                                            <div class="alert alert-danger">{{ $error }}</div>
                                        @endforeach
                                    @endif
                                </div>
                            </div>
                            {{-- @php
                                $created_by = auth()->user()->created_by;
                                $opeator = App\Models\User::where('ref_operator_type_id', 2)
                                ->where('created_by', auth()->user()->created_by)
                                ->where('registration_no','!=',null)->get();
                             
                            @endphp --}}
                            <!-- end card header -->
                            <div class="card-body">
                                <div class="live-preview">
                                    <div class="row white-inner">
                                        <div class="col-xxl-3 col-md-4 gy-3">
                                            <div>
                                                <label class="form-label">Select Seller<span
                                                        class="required">*</span></label>
                                                <select name="ics_name" id="ics_name" class="form-select" required>
                                                    <option value="">Select Seller</option>

                                                    
                                                    {{-- @forelse($sellers as $sell)
                                                        <option value="{{ $sell->at_user_id }}" data-id="{{ $sell->at_closing_stock_id }}">
                                                            {{ user_name($sell->at_user_id) }} - {{ getOperatorTypeById($sell->ref_operator_type_id) }}</option>
                                                    @empty
                                                    @endforelse --}}
                                                    @forelse($operator as $ope)
                                                        <option value="{{ $ope->id }}" data-id="{{ $ope->ref_operator_type_id }}">
                                                            {{ $ope->registration_no }}</option>
                                                    @empty
                                                    @endforelse
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-xxl-3 col-md-4 gy-3">
                                            <div>
                                                <label for="labelInput" class="form-label">Product<span
                                                        class="required">*</span> </label>
                                                    <select name="commodity" id="product" class="form-select" required>
                                                        <option value="">Select Product</option>
                                                       
                                        
                                                    </select>
                                                {{-- <input type="text" class="form-control" id="name"
                                                    placeholder="Commodity" name="commodity" value="" required> --}}
                                            </div>
                                        </div>
                                       
                                        <div class="col-xxl-3 col-md-4 gy-3">
                                            <div>
                                                <label for="labelInput" class="form-label">Organic Status<span class="required">*</span></label>
                                                <select name="status" id="org_status" class="form-select" >
                                                    <option value="">Select Status</option>
                                                   
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-xxl-3 col-md-4 gy-3">
                                            <div>
                                                <label for="labelInput" class="form-label">Quantity<span
                                                        class="required">*</span> </label> <span class="text-success"
                                                    id="avil_qty"> </span>

                                                <input type="text" class="form-control" id="qty"
                                                    placeholder="Quantity" name="quantity" value="" required>
                                            </div>
                                        </div>

                                        <div class="col-xxl-3 col-md-4 gy-3">
                                            <div>
                                                <label for="labelInput" class="form-label">Copy of Performa Invoice<span
                                                        class="required">*</span> </label>

                                                <input type="file" class="form-control" id="name"
                                                    placeholder="Copy of Performa Invoice"
                                                    name="upload_copy_of_performa_invoice" value="" required>
                                            </div>
                                        </div>

                                        <div class="col-xxl-3 col-md-4 gy-3">
                                            <div>
                                                <label for="labelInput" class="form-label">No. of Packages<span
                                                        class="required">*</span> </label>

                                                <input type="text" class="form-control" id="name"
                                                    placeholder="No. of Packages" name="no_of_packages" value=""
                                                    required>
                                            </div>
                                        </div>


                                        <div class="row">
                                            <div class="col-lg-12 gy-4">
                                                <div class="hstack gap-2">
                                                    <button type="submit" class="btn btn-primary" id="submitbtn">
                                                        Submit
                                                    </button>

                                                </div>
                                            </div>
                                        </div>

                                    </div>

                                    {{-- ----------  --}}



                                </div>
                            </div>


                        </div>
                    </div>
                    {{-- --------  --}}




                </div>
        </div>
    </div>
    </div>
    </div>
    </form>
    </div>
    </div>
@endsection

@push('script')
    <script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
    <script>
        $("#ics_name").on("change", function() {
            //alert(this.value);
            var operator_type = $("#ics_name").find(':selected').attr('data-id');
            var at_user_id = $("#ics_name").find(':selected').val();
            $.ajax({
                url: "{{ route('superadmin.checkRemainingQuantityInStock') }}",
                method: "POST",
                data: {
                    at_user_id: at_user_id,
                    operator_type: operator_type
                },
                success: function(response) {
                    //console.log(response.length);
                    $('#product').empty().append('');
                    $('#org_status').empty().append('<option value="">Select Status</option>');
                    $('#product').append('<option value="">Select Product</option>');
                    if(response.length>0){
                        for (var i = 0; i < response.length; i++) {
                           //console.log(response[i].id);
                            $("#product").append($('<option/>').attr("value", response[i].id).attr("data-pid",response[i].sts_id).attr("data-pname",response[i].sts_name).text(response[i].product));
                        }
                    } else {
                        $("#product").append($('<option/>').attr("value", "").text("No Data Found."));
                    }
                    
 
                }
            });

        });

        $("#product").on("change", function() {
            var sts_id = $("#product").find(':selected').attr('data-pid');
            var sts_name = $("#product").find(':selected').attr('data-pname');
            $("#org_status").html($('<option/>').attr("value",sts_id).text(sts_name));
                    
        });
    </script>
@endpush

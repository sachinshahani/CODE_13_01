@extends('admin.layouts.app')

@section('content')
    <style>
        .has-error {
            border: 1px solid red;
        }

        .errormsg {
            color: red;
            font-size: 14px !important;
        }
    </style>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0"> Accept Order</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Accept Order</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">


                <div class="tab-content py-4 custom-tab-content">
                    <div class="tab-pane fade show active" id="step1">
                        <div class="card">
                            <div class="card-header align-items-center d-flex">
                                <h4 class="card-title mb-0 flex-grow-1">

                                    Accept Order
                                 
                                </h4>
                                {{-- <a href="{{ route('superadmin.purchaseList') }}">Back</a> --}}
                            </div>
                            <!-- end card header -->

                            <form method="post" action="{{ route('superadmin.afterOrderAcceptPost') }}">
                                @csrf
                                <div class="card-body">
                                    <div class="live-preview">

                                        <div class="row white-inner ">

                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">Name of Seller <span
                                                            class="required">*</span></label>
                                                    <input type="hidden" name="hid_order_id" value="{{$id}}">
                                                    <input type="text" class="form-control" value="{{ user_name($orderReqData->at_user_id) }}"
                                                        name="seller_name" readonly required>
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">Name of Purchaser</label>
                                                    <input type="text" class="form-control" value="{{ user_name($orderReqData->created_by) ?? '' }}"
                                                        name="purchaser_name" readonly required>
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">Quantity</label>
                                                    <input type="text" name="quantity" value="{{ $orderReqData->quantity ?? '' }}"
                                                        class="form-control" readonly>
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">Storage (Warehouse)<span
                                                            class="required">*</span></label>
                                                        <select class="form-select" name="at_ics_warehouse_details_id">
                                                            <option value="">-Select status-</option>
                                                            @forelse($warehouse as $wr)
                                                            <option value="{{$wr->id}}" {{ (isset($ordData[0]->getOrderDetails->at_ics_warehouse_details_id) && $ordData[0]->getOrderDetails->at_ics_warehouse_details_id==$wr->id) ? 'selected' : '' }}>{{$wr->licence_number}}</option>
                                                            @empty
                                                            @endforelse
                                                        </select>
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">Rate <span class="required">*</span></label>
                                                    <input type="text" class="form-control" value="{{ $ordData[0]->getOrderDetails->rate ?? '' }}" name="rate"
                                                        required>
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">Number of Packages<span
                                                            class="required">*</span></label>
                                                    <input type="text" class="form-control" value="{{ $ordData[0]->getOrderDetails->number_of_packages ?? '' }}"
                                                        name="number_of_packages" required>
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <input type="hidden" name="status" value="{{ $orderReqData->status }}">
                                                    <label class="form-label">Status</label>
                                                    <select class="form-select" name="sel-status" disabled>
                                                        <option value="">-Select status-</option>
                                                        @foreach (getRefOrganicStatusMaster() as $value)
                                                            <option value="{{ $value->id }}" @selected($orderReqData->status == $value->id)>{{ $value->organic_status }}</option>
                                                        @endforeach
                                                        {{-- <option value="1">Organic</option>
                                                        <option value="2">Conversion</option> --}}
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">Product</label>
                                                    <input type="hidden" name="commodity" value="{{ $orderReqData->commodity??'' }}">
                                                    <input type="text" name="" value="{{ getRefProductById($orderReqData->commodity)->product_name ?? '' }}"
                                                        class="form-control" readonly>
                                                </div>
                                            </div>

                                        </div>

                                        <div class="row white-inner mt-1">
                                            <h4 class="card-title mb-0 flex-grow-1"> Payment details - Capture
                                            </h4>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">Mode of Payment <span
                                                            class="required">*</span></label>
                                                    <select class="form-select" name="mode_of_payment">
                                                        <option value="">-Select-</option>
                                                        <option value="1" {{ isset($ordData[0]->getOrderDetails->mode_of_payment) && $ordData[0]->getOrderDetails->mode_of_payment==1 ?'selected': '' }}>Cash</option>
                                                        <option value="2" {{ isset($ordData[0]->getOrderDetails->mode_of_payment) && $ordData[0]->getOrderDetails->mode_of_payment==2 ?'selected': '' }}>Bank</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">Bank Details</label>
                                                    <input type="text" name="bank_detail" value="{{ $ordData[0]->getOrderDetails->bank_detail ?? '' }}"
                                                        class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">Transaction ID</label>
                                                    <input type="text" name="if_bank_transaction_id" value="{{ $ordData[0]->getOrderDetails->if_bank_transaction_id ?? '' }}"
                                                        class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">Upload Receipt</label>
                                                    <input type="file" name="upload_cash_receipt" value="{{ $ordData[0]->getOrderDetails->upload_cash_receipt ?? '' }}"
                                                        class="form-control">
                                                </div>
                                            </div>

                                        </div>
                                        <div class="row white-inner mt-1">
                                            <h4 class="card-title mb-0 flex-grow-1"> Transport details - Capture
                                            </h4>

                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">Date of Transportation</label>
                                                    <input type="date" name="transport_date" value="{{ $ordData[0]->getOrderDetails->transport_date ?? '' }}"
                                                        class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">Mode of Transportation</label>
                                                    {{-- <input type="text" name="transportation_mode" value="{{ $ordData[0]->getOrderDetails->transportation_mode ?? '' }}"
                                                        class="form-control"> --}}

                                                        <select class="form-select" name="transportation_mode">
                                                            <option value="">-Select Option-</option>
                                                            @foreach (getRefTransportationMode() as $val)
                                                            <option value="{{ $val->id}}">{{ $val->mode_name }}</option>
                                                            @endforeach
                                                          
                                                        </select>  
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">Vehicle No.</label>
                                                    <input type="text" name="vehicle_number" value="{{ $ordData[0]->getOrderDetails->vehicle_number ?? '' }}"
                                                        class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">Place of Dispatch</label>
                                                    <input type="text" name="place_of_dispatch" value="{{ $ordData[0]->getOrderDetails->place_of_dispatch ?? '' }}"
                                                        class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">Place of Destination</label>
                                                    <input type="text" name="place_of_destination" value="{{ $ordData[0]->getOrderDetails->place_of_destination ?? '' }}"
                                                        class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-lg-12 gy-4">
                                                <div class="hstack gap-2" style="float: right;">
                                                    <button type="submit" class="btn btn-primary" id="submitbtn">
                                                        Submit
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
        </div>
    </div>
@endsection
@push('script')
    <script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
    <script>
        $(document).on('click', '#submitbtn', function() {

        });
    </script>
@endpush

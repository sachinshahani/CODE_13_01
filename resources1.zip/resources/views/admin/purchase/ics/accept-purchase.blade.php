@extends('admin.layouts.app')

@section('content')
    <style>
        .has-error {
            border: 1px solid red;
        }

        .errormsg {
            color: red;
            font-size: 14px !important;
        }
    </style>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0"> Purchase</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Purchase</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">
            <form method="post" enctype="multipart/form-data" id="purchase-form" action="{{ route('superadmin.storeStorageStock') }}">
                @csrf

                <div class="tab-content py-4 custom-tab-content">
                    <div class="tab-pane fade show active" id="step1">
                        <div class="card">
                            <div class="card-header align-items-center d-flex">
                                <h4 class="card-title mb-0 flex-grow-1">

                                    Purchase

                                </h4>
                                <a href="{{ route('superadmin.purchaseList') }}" >Back</a>
                            </div>
                            <!-- end card header -->
                            <div class="card-body">
                                <div class="live-preview">
                                   
                                    <div class="row seperatesec">
                                         
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Name of Seller <span class="required">*</span></label>
                                                <input type="text" class="form-control" value="" name="transportation_date" required>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Name of Purchaser</label>
                                                <input type="text" class="form-control" value="" name="transportation_date" required>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Quantity</label>
                                                <input type="text" name="vehicle_number" value="" class="form-control"  >
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">From which Storage (Warehouse)<span class="required">*</span></label>
                                                <input type="text" class="form-control numbersonly" maxlength="7" value="" name="purchased_qty" id="purchase_qty" required>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Rate <span class="required">*</span></label>
                                                <input type="text" class="form-control" value="" name="place_of_dispatch" required>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Number of Packages<span class="required">*</span></label>
                                                <input type="text" class="form-control" value="" name="place_of_destination" required>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Status</label>
                                                <select class="form-select" name="status">
                                                    <option value="">-Select status-</option>
                                                    <option value="1">Active</option>
                                                    <option value="2">Inactive</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Commodity</label>
                                                <input type="text" name="commodity" value="" class="form-control"  >
                                            </div>
                                        </div>
                                       
                                    </div>
                                    
                                    <div class="row seperatesec">
                                        <h4 class="card-title mb-0 flex-grow-1"> Payment details - Capture
                                        </h4>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Mode of  Payment <span class="required">*</span></label>
                                                <select class="form-select" name="status">
                                                    <option value="">-Select-</option>
                                                    <option value="1">Cash</option>
                                                    <option value="2">Bank</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Bank Details</label>
                                                <input type="text" name="" value="" class="form-control"  >
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Transaction ID</label>
                                                <input type="text" name="" value="" class="form-control"  >
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Upload Receipt</label>
                                                <input type="file" name="" value="" class="form-control"  >
                                            </div>
                                        </div>

                                    </div>
                                    <div class="row seperatesec">
                                        <h4 class="card-title mb-0 flex-grow-1"> Transport details - Capture
                                        </h4>
                                       
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Date of Transportation</label>
                                                <input type="date" name="" value="" class="form-control"  >
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Mode of Transportation</label>
                                                <input type="text" name="" value="" class="form-control"  >
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Vehicle No.</label>
                                                <input type="text" name="" value="" class="form-control"  >
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Place of Dispatch</label>
                                                <input type="text" name="" value="" class="form-control"  >
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Place of Destination</label>
                                                <input type="text" name="" value="" class="form-control"  >
                                            </div>
                                        </div>

                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-lg-12 gy-4">
                                            <div class="hstack gap-2">
                                                <button type="submit" class="btn btn-primary" id="submitbtn">
                                                    Submit
                                                </button>
                                                {{-- <a href="{{ route('superadmin.icsuser.step2', 2) }}"
                                                    class="btn btn-soft-success">
                                                    Next
                                                </a> --}}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>



@endsection
@push('script')
    <script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
    <script>
        $(document).on('click', '#submitbtn', function() {
          
        });

        


        
    </script>
@endpush

@extends('admin.layouts.app')

@section('content')
    <style>
        .has-error {
            border: 1px solid red;
        }

        .errormsg {
            color: red;
            font-size: 14px !important;
        }
    </style>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0"> Storage & Closing of Stock </h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Storage & Closing of Stock </li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">
            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                    <a class="nav-link" href="{{ route('superadmin.purchaseProduct',$result->id ) }}">Purchase Product</a>
                    <a class="nav-link" href="{{ route('superadmin.storageStock',$result->id) }}">Storage of Stock</a>
                    <a class="nav-link active" href="{{ route('superadmin.closingOfStock',$result->id) }}">Storage & Closing of Stock</a>

                </div>
            </nav>
            <form method="post" enctype="multipart/form-data" id="purchase-form" action="{{ route('superadmin.storeClosingOfStock') }}">
                @csrf

                <div class="tab-content py-4 custom-tab-content">
                    <div class="tab-pane fade show active" id="step1">
                        <div class="card">
                            <div class="card-header align-items-center d-flex">
                                <h4 class="card-title mb-0 flex-grow-1">
                                    Storage & Closing of Stock
                                </h4>

                            </div>
                            <!-- end card header -->
                            <div class="card-body">
                                <div class="live-preview">
                                    <input type="hidden" name="at_purchase_details_id" value="{{ $result->id ??'' }}">

                                    <div class="row  white-inner">
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Name of Purchase Manager<span class="required">*</span></label>
                                                <select class="form-select" name="at_ics_warehouse_manager_details_id" required>
                                                    <option value="">-Select Purchase Manager-</option>
                                                    @foreach ($whmData as $val )
                                                    <option value="{{ $val->id }}" {{ (isset($data->at_ics_warehouse_manager_details_id)&& $data->at_ics_warehouse_manager_details_id==$val->id)?'selected':''}}>{{ $val->first_name }}</option>
                                                    @endforeach

                                                </select>
                                            </div>
                                        </div>
                                        @php
                                            $purchase_id = '#'.str_pad($result->id, 5, "0", STR_PAD_LEFT);
                                        @endphp

                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Purchase ID <span class="required">*</span></label>
                                                <input type="text" class="form-control" value="{{ $purchase_id ?? ''}}" name="purchase_id" required readonly>
                                            </div>
                                        </div>

                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Storage to Warehouse ID </label>
                                                <select class="form-select" name="ref_transportation_mode_id">
                                                    <option value="">-Select Option-</option>
                                                    <option value="{{ $whData->id }}" selected>{{ $whData->licence_number }}</option>


                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Address</label>
                                                <input type="text" name="address" value="{{ $data->address ?? '' }}" class="form-control"  >
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Transport Date<span class="required">*</span></label>
                                                <input type="date" class="form-control"  value="{{ $data->transport_date ?? '' }}" name="transport_date" id="transport_date" required>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Organic Status</label>
                                                <input type="hidden" value="{{ $productData['sts_id'] }}"  name="status">
                                                <select class="form-select" disabled>
                                                    <option value="">-Select status-</option>
                                                    @foreach(getRefOrganicStatusMaster() as $val)
                                                    <option value="{{ $val->id }}" {{ ($productData['sts_id']==$val->id) ? 'selected':'' }}>{{ $val->organic_status }}</option>
                                                    @endforeach

                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Product</label>
                                                <input type="text" name="commodity" value="{{ $productData['product'] ?? '' }}" class="form-control" readonly>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Qty.</label>
                                                <input type="text" name="qty" value="{{ $result->purchase_qty ?? '' }}" class="form-control" readonly >
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">No. of bags / packages</label>
                                                <input type="text" name="no_of_bags_packages" value="{{ $data->no_of_bags_packages ?? '' }}" class="form-control"  >
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Weight (in MT)</label>
                                                <input type="text" name="weight" value="{{ $data->weight ?? '' }}" class="form-control"  >
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Date of Storage</label>
                                                <input type="date" name="date_of_storage" value="{{ $data->date_of_storage ?? '' }}" class="form-control"  >
                                            </div>
                                        </div>
                                        <div class="col-lg-12 gy-4">
                                            <div class="hstack gap-2">
                                                <a href="{{ route('superadmin.storageStock',$result->id) }}"
                                                    class="btn btn-soft-success">
                                                    Back
                                                </a>
                                                <button type="submit" class="btn btn-primary" id="submitbtn">
                                                    Submit
                                                </button>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>



@endsection
@push('script')
    <script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
    <script>
        $(document).on('click', '#submitbtn', function() {
            $purchase_qty = $('#purchase_qty').val();
            $closing_stock = $("input[name='closing_stock']").val();

            if (Math.fround($purchase_qty ) > Math.fround($closing_stock)) {
                Swal.fire('', 'Purchase(Sourced Qty. in MT) should not be greater than Closing Stock.', 'warning');
                $('input[name="purchase_qty"]').val('');
                return false;
            }

        });





    </script>
@endpush

@extends('admin.layouts.app')

@section('content')
    <style>
        .has-error {
            border: 1px solid red;
        }

        .errormsg {
            color: red;
            font-size: 14px !important;
        }
    </style>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0"> Purchase Product</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Purchase Product</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">
            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                    <a class="nav-link active" id="step1-tab" data-bs-toggle="tab"
                        href="{{ route('superadmin.purchaseProduct',$result->id ) }}">Purchase Product</a>
                    <a class="nav-link" href="{{ route('superadmin.storageStock',$result->id) }}">Storage of Stock</a>
                    <a class="nav-link" href="{{ route('superadmin.closingOfStock',$result->id) }}">Storage & Closing of Stock</a>
                    
                </div>
            </nav>
            <form method="post" enctype="multipart/form-data" id="purchase-form" action="{{ route('superadmin.storePurchaseProduct') }}">
                @csrf

                <div class="tab-content py-4 custom-tab-content">
                    <div class="tab-pane fade show active" id="step1">
                        <div class="card">
                            <div class="card-header align-items-center d-flex">
                                <h4 class="card-title mb-0 flex-grow-1">
                                    PURCHASE PRODUCT
                                </h4>
                               <div class="flex-shrink-0">
                                    @if (session('error'))
                                    <div class="alert alert-danger">
                                            {{ session('error') }}
                                        </div>
                                    @endif

                                    @if (session('success'))
                                        <div class="alert alert-success">
                                            {{ session('success') }}
                                        </div>
                                    @endif
                                   
                              
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="live-preview">
                                    <div class="row white-inner">
                                        
                                        <input type="hidden" name="row_id" value="{{ $id }}">
                                        @php
                                            $closingStock = App\Models\AtClosingStock::where('id',$result->at_closing_stock_id)->first();

                                        @endphp
                                        <input type="hidden" name="closing_stock" value="{{ $closingStock->closing_stock }}" >
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Farmer Name</label>
                                                <input type="text" name="fid" value="{{ getFarmerNameByID($fid) }}" class="form-control"  readonly>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Date of Purchase<span class="required">*</span></label>
                                                <input type="date" class="form-control" value="{{ $result->date_of_purchase ?? '' }}" name="date_of_purchase" required>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Purchase(Sourced Qty. in MT)<span class="required">*</span></label>
                                                <input type="text" class="form-control numbersonly" maxlength="7" value="{{ $result->purchase_qty ?? '' }}" name="purchase_qty" id="purchase_qty" required>
                                            </div>
                                        </div>

                                        @if (!empty($result->purchase_qty))
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Select Option</label>
                                                <select class="form-select" name="store_warehouse">
                                                    <option value="">-Select Option-</option>
                                                    <option value="1" @selected($result->store_warehouse=='1')>Store in ICS Warehouse</option>
                                                    <option value="2" @selected($result->store_warehouse=='2')>Store in Mandator Warehouse</option>
                                                    <option value="3" @selected($result->store_warehouse=='3')>Direct Sale to Processor/Trader</option>
                                                </select>
                                            </div>
                                        </div>
                                        @endif
                                    </div>


                                    <div class="row white-inner ">
                                        <div class="col-lg-12 gy-4">
                                            <a href="{{ route('superadmin.purchaseList') }}"  class="btn btn-soft-success" >Back</a>
                                            <div class="hstack gap-2" style="float: right">
                                                <button type="submit" class="btn btn-primary" id="submitbtn">
                                                    Submit
                                                </button>
                                                {{-- <a href="{{ route('superadmin.icsuser.step2', 2) }}"
                                                    class="btn btn-soft-success">
                                                    Next
                                                </a> --}}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>



@endsection
@push('script')

    <script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
    <script>
        $(document).on('click', '#submitbtn', function() {
            $purchase_qty = $('#purchase_qty').val();
            $closing_stock = $("input[name='closing_stock']").val();

            if (Math.fround($purchase_qty ) > Math.fround($closing_stock)) {
                Swal.fire('', 'Purchase(Sourced Qty. in MT) should not be greater than Closing Stock.', 'warning');
                $('input[name="purchase_qty"]').val('');
                return false;
            }

        });

    </script>
@endpush

@extends('admin.layouts.app')

@section('content')
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Purchase List</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Purchase List</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">
            <form method="post" enctype="multipart/form-data" id="registration"
                action="{{ route('superadmin.icsuser.step1post', 2) }}">
                @csrf

                <div class="tab-content py-4 custom-tab-content">
                    <div class="tab-pane fade show active" id="step1">
                        <div class="card">
                            <div class="row seperatesec  white-inner">
                                <div class="card-header align-items-center d-flex">
                                    <h4 class="card-title mb-0 flex-grow-1">
                                        Purchase List

                                    </h4>
                                    {{-- <a href="" class="btn btn-primary" style="float: right">Add New</a> --}}
                                </div>
                                <!-- end card header -->
                                <div class="table-responsive">
                                    <table id="inspSchedule"
                                        class="table table-bordered nowrap table-striped align-middle"
                                        style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>S.No.</th>
                                                <th>Farm No.</th>
                                                <th>Farmer Name</th>
                                                <th>Date of Purchase</th>
                                                <th>Purchase ID </th>
                                                <th>Product</th>
                                                <th>District Name</th>
                                                <th>State Name</th>
                                                <th>(Purchase)Sourced Qty. (in MT)</th>
                                                <th>Date of Harvest</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection
@push('script')
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        var table = $('#inspSchedule').DataTable({
            //dom: 'l<"clear">Bfrtip',
            //dom:'Bfrtip',
            //dom:'Blfrtip',
            lengthMenu: [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
            ],
            processing: true,
            serverSide: true,
            ajax: {
                url: '{{ route('superadmin.purchaseList') }}',
                type: 'GET',
                data: function(d) {

                }
            },
            columns: [{
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex',
                    orderable: true
                },
                {
                    data: 'farm_number',
                    name: 'farm_number',
                    orderable: true
                },
                {
                    data: 'farmer_name',
                    name: 'farmer_name',
                    orderable: true
                },
                {
                    data: 'date_of_purchase',
                    name: 'date_of_purchase',
                    orderable: true
                },
                {
                    data: 'purchase_id',
                    name: 'purchase_id',
                    orderable: true
                },
                {
                    data: 'Commodity',
                    name: 'Commodity',
                    orderable: true
                },
                {
                    data: 'district_name',
                    name: 'district_name',
                    orderable: true
                },
                {
                    data: 'state_name',
                    name: 'state_name',
                    orderable: true
                },
                {
                    data: 'purchase_qty',
                    name: 'purchase_qty',
                    orderable: true
                },
                {
                    data: 'date_of_harvest',
                    name: 'date_of_harvest',
                    orderable: true
                },
                {
                    data: 'action',
                    name: 'action',
                    orderable: false
                },
            ],
            // initComplete: function () {
            //     var btns = $('.dt-button');
            //     //btns.addClass('btn btn-success btn-success');
            //     btns.removeClass('dt-button');

            // },

        });



        function confirmDelete_(id) {

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.value) {
                    $.ajax({
                        url: "{{ route('superadmin.icsuser.deleteInspSchedule') }}",
                        method: "POST",
                        dataType: 'json',
                        data: {
                            'id': id,
                        },
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function(result) {

                            Swal.fire(
                                'Deleted!',
                                'Record Deleted Successfully..',
                                'success'
                            );
                            location.reload();

                        }
                    });

                }
            })
        }
    </script>
@endpush

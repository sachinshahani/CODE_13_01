@extends('admin.layouts.app')

@section('content')
    <style>
        .has-error {
            border: 1px solid red;
        }

        .errormsg {
            color: red;
            font-size: 14px !important;
        }
    </style>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0"> Storage of Stock </h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Storage of Stock </li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">
            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                    <a class="nav-link" href="{{ route('superadmin.purchaseProduct',$result->id ) }}">Purchase Product</a>
                    <a class="nav-link active" href="{{ route('superadmin.storageStock',$result->id) }}">Storage of Stock</a>
                    <a class="nav-link" href="{{ route('superadmin.closingOfStock',$result->id) }}">Storage & Closing of Stock</a>
                    
                </div>
            </nav>
            <form method="post" enctype="multipart/form-data" id="purchase-form" action="{{ route('superadmin.storeStorageStock') }}">
                @csrf

                <div class="tab-content py-4 custom-tab-content">
                    <div class="tab-pane fade show active" id="step1">
                        <div class="card">
                            <div class="card-header align-items-center d-flex">
                                <h4 class="card-title mb-0 flex-grow-1">

                                    Storage of Stock
                                </h4>
                                  
                                    <div class="flex-shrink-0">
                                        @if (session('error'))
                                            <div class="alert alert-danger">
                                                {{ session('error') }}
                                            </div>
                                        @endif
                                        @if (session('success'))
                                            <div class="alert alert-success">
                                                {{ session('success') }}
                                            </div>
                                        @endif
                                        @if ($errors)
                                            @foreach ($errors->all() as $error)
                                                <div class="alert alert-danger">{{ $error }}</div>
                                            @endforeach
                                        @endif
                                    </div>
                               
                            </div>
                            <!-- end card header -->
                            <div class="card-body">
                                <div class="live-preview">
                                   
                                    <div class="row white-inner">
                                        <input type="hidden" name="at_purchase_details_id" value="{{ $result->id ??'' }}">
                                        <input type="hidden" name="at_closing_stock_id" value="{{ $result->at_closing_stock_id ??'' }}">
                                        <input type="hidden" name="fid" value="{{ $fid ??'' }}">
                                        
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Date of Transportation<span class="required">*</span></label>
                                                <input type="date" class="form-control" value="{{ date('Y-m-d') }}" name="transportation_date" required>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div> 
                                                {{-- @selected($stockTranDet->ref_transportation_mode_id == $val->id) --}}
                                                <label class="form-label">Mode of Transportation<span class="required">*</span></label>
                                                <select class="form-select" name="ref_transportation_mode_id">
                                                    <option value="">-Select Option-</option>
                                                    @foreach (getRefTransportationMode() as $val)
                                                    <option value="{{ $val->id}}">{{ $val->mode_name }}</option>
                                                    @endforeach
                                                  
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Vehicle No.</label>
                                                <input type="text" name="vehicle_number" value="{{ $stockTranDet->vehicle_number ?? '' }}" class="form-control"  >
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Purchase(Sourced Qty. in MT)<span class="required">*</span></label>
                                                <input type="text" class="form-control numbersonly" maxlength="7" value="{{ $result->purchase_qty ?? '' }}" name="purchased_qty" id="purchase_qty" readonly required>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">From to<span class="required">*</span></label>
                                                <input type="text" class="form-control" value="{{ $stockTranDet->place_of_dispatch ?? '' }}" name="place_of_dispatch" required>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Where<span class="required">*</span></label>
                                                <input type="text" class="form-control" value="{{ $stockTranDet->place_of_destination ?? '' }}" name="place_of_destination" required>
                                            </div>
                                        </div>
                                        @if(isset($result->store_warehouse) && $result->store_warehouse==2)
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Mandator Address <span class="required">*</span></label>
                                                <input type="text" class="form-control" value="{{ $stockTranDet->mandator_address ?? '' }}" name="mandator_address" required>
                                            </div>
                                        </div>
                                        @endif
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Farmer Name</label>
                                                <input type="text" value="{{ getFarmersByFarmID($result->at_farm_details_id)??'' }}" class="form-control"  readonly>
                                            </div>
                                        </div>
                                        
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Product</label>
                                                <input type="text" name="commodity" value="{{ $productData['product'] ?? '' }}" class="form-control"  readonly>
                                            </div>
                                        </div>
                                       
										 <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">Organic Status</label>
                                                <input type="hidden" value="{{ $productData['sts_id'] }}"  name="status">
                                                <select class="form-select" disabled>
                                                    <option value="">-Select status-</option>
                                                    @foreach(getRefOrganicStatusMaster() as $val)
                                                    <option value="{{ $val->id }}" {{ ($productData['sts_id']==$val->id) ? 'selected':'' }}>{{ $val->organic_status }}</option>
                                                    @endforeach
                                                   
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12 gy-4">
                                                <div class="hstack gap-2">
                                                    <a href="{{ route('superadmin.purchaseProduct',$result->id ) }}"
                                                        class="btn btn-soft-success">
                                                        Back
                                                    </a>
                                                    <button type="submit" class="btn btn-primary" id="submitbtn">
                                                        Submit
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                  
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>



@endsection
@push('script')
    <script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
    <script>
        $(document).on('click', '#submitbtn', function() {
            $purchase_qty = $('#purchase_qty').val();
            $closing_stock = $("input[name='closing_stock']").val();
           
            if (Math.fround($purchase_qty ) > Math.fround($closing_stock)) {
                Swal.fire('', 'Purchase(Sourced Qty. in MT) should not be greater than Closing Stock.', 'warning');
                $('input[name="purchase_qty"]').val('');
                return false;
            }
           
        });

        


        
    </script>
@endpush

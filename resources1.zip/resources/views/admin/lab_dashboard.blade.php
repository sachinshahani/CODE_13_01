@extends('admin.layouts.app')
@section('content')
<style>
    .page-content {
    background: #F2FBF9;

}
.c-h {
    min-height: 452px !important;background: #fff
}
.c-h .card-body{background: #fff}
</style>
    {{-- <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Home</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Home</a></li>

                    </ol>
                </div>

            </div>
        </div>
    </div> --}}
    <!-- end page title -->
    @if (isset(auth()->user()->ref_operator_type_id) &&   ( auth()->user()->ref_operator_type_id == 102))



          <div class="container-fluid cus-dash-div">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <h4 class="mb-sm-0">Dashboard</h4>

                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">As on :</a></li>
                                <li class="breadcrumb-item">
                                    <form class="form-inline">
                                        <div class="form-group">
                                            <input type="date" class="form-control cu-form-control" id="inputPassword2">
                                        </div>
                                    </form>
                                </li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <!-- end page title -->
            <div class="row">
                <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                    <div class="card dashb-box gradient-colr">
                        <div class="card-body p-0">
                           <div class="img-part">
                                <img src="{{ asset('public/assets/images/micon-1.png') }}" alt="">
                           </div>
                           <div class="txt-part">
                            <p>Total Registered Users</p>
                            <h3 id="user_id"></h3>
                          <p id="user_date"></p>
                           </div>
                        </div><!-- end card body -->
                    </div><!-- end card -->
                </div><!-- end col -->
                <div class="col-12 col-sm-12 col-md-9 col-lg-9 col-xl-9 ps-2">
                    <div class="more-cards-inner">
                        <div class="card dashb-box blue-bx">
                            <div class="card-body p-0">
                               <div class="img-part">
                                    <img src="{{ asset('public/assets/images/micon-2.png') }}" alt="">
                               </div>
                               <div class="txt-part">
                                <p>ICS</p>
                                <p class="colr-txt" id="ics_id"></p>
                               </div>
                            </div><!-- end card body -->
                        </div><!-- end card -->
                        <div class="card dashb-box purple-bx">
                            <div class="card-body p-0">
                               <div class="img-part">
                                    <img src="{{ asset('public/assets/images/micon-3.png') }}" alt="">
                               </div>
                               <div class="txt-part">
                                <p>Individual Producers</p>
                                <p class="colr-txt" id="individual_id"></p>
                               </div>
                            </div><!-- end card body -->
                        </div><!-- end card -->
                        <div class="card dashb-box drk-brown-bx">
                            <div class="card-body p-0">
                               <div class="img-part">
                                    <img src="{{ asset('public/assets/images/micon-4.png') }}" alt="">
                               </div>
                               <div class="txt-part">
                                <p>Processors</p>
                                <p class="colr-txt" id="processor_id"></p>
                               </div>
                            </div><!-- end card body -->
                        </div><!-- end card -->
                        <div class="card dashb-box drk-blue-bx">
                            <div class="card-body p-0">
                               <div class="img-part">
                                    <img src="{{ asset('public/assets/images/micon-6.png') }}" alt="">
                               </div>
                               <div class="txt-part">
                                <p>Wild Harvester</p>
                                <p class="colr-txt" id="harvester_id"></p>
                               </div>
                            </div><!-- end card body -->
                        </div><!-- end card -->
                        <div class="card dashb-box yellow-bx">
                            <div class="card-body p-0">
                               <div class="img-part">
                                    <img src="{{ asset('public/assets/images/micon-7.png') }}" alt="">
                               </div>
                               <div class="txt-part">
                                <p>Traders</p>
                                <p class="colr-txt" id="trader_id"></p>
                               </div>
                            </div><!-- end card body -->
                        </div><!-- end card -->
                        <div class="card dashb-box green-bx">
                            <div class="card-body p-0">
                               <div class="img-part">
                                    <img src="{{ asset('public/assets/images/micon-5.png') }}" alt="">
                               </div>
                               <div class="txt-part">
                                <p>Farmers</p>
                                <p class="colr-txt" id="farmer_id"></p>
                               </div>
                            </div><!-- end card body -->
                        </div><!-- end card -->
                        <div class="card dashb-box pink-bx">
                            <div class="card-body p-0">
                               <div class="img-part">
                                    <img src="{{ asset('public/assets/images/micon-9.png') }}" alt="">
                               </div>
                               <div class="txt-part">
                                <p>Farms</p>
                                <p class="colr-txt" id="farm_id"></p>
                               </div>
                               <div class="txt-part total-txt">
                                 <p class="colr-txt" id=""></p>
                               </div>
                            </div><!-- end card body -->
                        </div><!-- end card -->
                        <div class="card dashb-box orng-bx">
                            <div class="card-body p-0">
                               <div class="img-part">
                                    <img src="{{ asset('public/assets/images/micon-8.png') }}" alt="">
                               </div>
                               <div class="txt-part">
                                <p>Products</p>
                                <p class="colr-txt" id="product_id"></p>
                               </div>
                            </div><!-- end card body -->
                        </div><!-- end card -->
                    </div>
                </div><!-- end col -->
            </div><!-- end row -->
        </div>
        <div class="row mt-4">
            <div class="col-4">
                <div class="card c-h">
                    <div class="mt-md-0 py-3 px-3">
                        <div class="d-flex align-items-center">
                            <p><h4>Scope Certificate</h4></p>
                        </div>
                    </div>
                    <div id="chart"></div>
                </div>
            </div>

            <div class="col-xl-4">
                <div class="card c-h">
                    <div class="card-header">
                        <h4 class="card-title mb-0">Transaction Certificate</h4>
                    </div>
                    <div class="card-body">
                        <div id="chartsplinearea"></div>
                    </div><!-- end card-body -->
                </div>
            </div>

            <div class="col-xl-4">
                <div class="card c-h">
                    <div class="card-header">
                        <h4 class="card-title mb-0">No-Objection Certificate</h4>
                    </div>

                    <div class="card-body">
                        <div id="multi_chart"></div>
                    </div><!-- end card-body -->
                </div><!-- end card -->
            </div>
        </div>


        {{-- <div class="row">chartsplinearea
            <div class="col-xl-12">
                <div class="card crm-widget ">
                    <div class="card-body p-0 white-inner">
                        <div class="row row-cols-xxl-5 row-cols-md-4 row-cols-1 g-0">

                            <div class="col-xxl-12 col-md-12">
                                <div class="mt-2 mt-md-0 py-3 px-3">

                                    <div class="d-flex align-items-center">

                                        Super Admin Dashboard

                                    </div>
                                </div>
                            </div><!-- end col -->


                            <!-- end col -->
                        </div><!-- end row -->
                    </div><!-- end card body -->
                </div><!-- end card -->
            </div><!-- end col -->
        </div><!-- end row --> --}}
    @endif

@endsection
@push('script')
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script>

        $(document).ready(function() {

         $('#user_id, #product_id, #farmer_id, #farm_id, #ics_id, #individual_id, #harvester_id, #trader_id, #processor_id, #mandators_id').html('<div id="loading"><img id="loading-image" src="{{ asset('public/assets/images/preloader.gif') }}" alt="Loading..." /></div>');
            $.ajax({
                url: "{{ route('superadmin.dashboardajaxcall') }}",
                method: 'POST',
                type:"script",
                success: function(response) {
                    try {
                        $('#user_date').html('Till Today: '+ response.user_date);
                        $('#user_id').html(response.user);
                        $('#ics_id').html(response.ics);
                        $('#individual_id').html(response.individual);
                        $('#harvester_id').html(response.harvester);
                        $('#trader_id').html(response.trader);
                        $('#processor_id').html(response.processor);
                        $('#farmer_id').html(response.farmer);
                        $('#farm_id').html('Total Land (Ha): '+response.farm);
                        $('#product_id').html('Total Product: ' +response.product);
                        $('#mandators_id').html(response.mandators);
                    } catch (error) {
                        console.error('Error parsing JSON: ' + error);
                    }
                },
                complete:function(jqXHR, textStatus) {
                        // alert("request complete "+textStatus);
                     },
                    error: function(xhr, textStatus, errorThrown){

                        console.log('request failed->'+xhr);

                    }
            });
        });

/*Scope Certificate*/
var currentYear = new Date().getFullYear();
var years = [];
for (var i = 2019; i <= currentYear; i++) {
  years.push(i);
}
  var options = {
          series: [{
          name: 'Total',
          data: [44, 55, 57, 56, 400]
        }, {
          name: 'Approve',
          data: [76, 85, 101, 98, 87]
        }, {
          name: 'Pending',
          data: [35, 41, 36, 26, 45]
        }],
          chart: {
          type: 'bar',
          height: 350
        },
        plotOptions: {
          bar: {
            horizontal: false,
            columnWidth: '55%',
            endingShape: 'rounded'
          },
        },
        dataLabels: {
          enabled: false
        },

        stroke: {
          show: true,
          width: 2,
          colors: ['transparent']
        },
        xaxis: {
        categories: years,
        },
        yaxis: {
            logBase: 40,
            tickAmount:9,
            min: 0,
            max: 450,
          title: {
            text: 'Number of Certificate',
          }
        },
        fill: {
          opacity: 1
        },
        tooltip: {
          y: {
            formatter: function (val) {
              return "$ " + val + "Number of Certificate"
            }
          }
        }
        };

        var chart = new ApexCharts(document.querySelector("#chart"), options);
        chart.render();


/*Spline Area Chart*/

        var options = {
          series: [{
          name: 'Totlal',
          data: [31, 40, 28, 51, 42]
        }, {
          name: 'Approve',
          data: [11, 32, 45, 32, 34]
        },{
        name: 'Panding',
        data:[23,4,4,4,34]
        }],
          chart: {
          height: 350,
          type: 'area'
        },
        dataLabels: {
          enabled: false
        },
        stroke: {
          curve: 'smooth'
        },
        xaxis: {
            categories: years,
        },
        tooltip: {
          x: {
            format: 'dd/MM/yy HH:mm'
          },
        },
        yaxis: {
            logBase: 40,
            tickAmount:9,
            min: 0,
            max: 450,
          title: {
            text: 'Number of Certificate'
          }
        },
        fill: {
          opacity: 1
        },
        tooltip: {
          y: {
            formatter: function (val) {
              return "$ " + val + "Number of Certificate"
            }
          }
        }
        };


        var chart = new ApexCharts(document.querySelector("#chartsplinearea"), options);
        chart.render();



/* Multiple Y-Axis Charts */
        var options = {
          series: [44, 444],
          labels: ["Pending","Approve"],
          chart: {
          width: 380,
          type: 'donut',
        },
        dataLabels: {
          enabled: false
        },

        responsive: [{
          breakpoint: 480,
          options: {
            chart: {
              width: 200
            },
            legend: {
              show: false
            }
          }
        }],
        legend: {
          position: 'bottom',
          offsetY: 10,
          height: 30,
        },
        plotOptions: {
          pie: {
            donut: {
              labels: {
                show: true,
                total: {
                  label: 'Received',
                  showAlways: true,
                  show: true
                }
              }
            }
          }
        },

        };

        var chart = new ApexCharts(document.querySelector("#multi_chart"), options);
        chart.render();


        function appendData() {
        var arr = chart.w.globals.series.slice()
        arr.push(Math.floor(Math.random() * (100 - 1 + 1)) + 1)
        return arr;
      }

      function removeData() {
        var arr = chart.w.globals.series.slice()
        arr.pop()
        return arr;
      }

      function randomize() {
        return chart.w.globals.series.map(function() {
            return Math.floor(Math.random() * (100 - 1 + 1)) + 1
        })
      }

      function reset() {
        return options.series
      }



$('#inputPassword2').on('change', function() {
  alert( this.value );
});

</script>
@endpush

@extends('layouts.admin')
@section('title', 'Edit Slider')

@section('content')
    <div class="card">
        <div class="card-header">{{ trans('global.update') }} {{
		trans('global.slider.title_singular') }}</div>

        <div class="card-body">
            <form class="row" enctype="multipart/form-data" method="post"
                  action="{{ route('admin.slider.update', $webinar->id) }}"
                  id="createSchemeForm" style="width: 100%;">
                @csrf @method('PUT')
                <div class="col-md-12">

                    <div class="mt-3"></div>
                    <h5></h5>

                    <div class="form-group">
                        <label>{{ trans('global.slider.title_singular') }} {{ trans('global.heading') }}<span
                                class="text-danger">*</span></label>
                        <input name="heading" type="text"
                               class="form-control {{ $errors->has('heading') ? ' is-invalid' : '' }}"
                               value="{{ $webinar->page_heading }}" placeholder="Enter slider heading" maxlength="20"
                               required="true">
                    </div>


                    <div class="form-group">
                        <label>{{ trans('global.ino.title_singular') }} {{
						trans('global.title') }}<span class="text-danger">*</span>
                        </label> <input name="title" type="text"
                                        class="form-control {{ $errors->has('title') ? ' is-invalid' : '' }}"
                                        value="{{ $webinar->posts_name ?? '' }}"
                                        placeholder="Enter Slider Title" maxlength="50" required="true">
                    </div>

                    <div class="form-group">
                        <label>{{ trans('global.short_description') }}<span class="text-danger">*</span></label>
                        <textarea cols="100"
                                  class="form-control {{ $errors->has('summary') ? ' is-invalid' : '' }}"
                                  name="summary" rows="2" maxlength="100"
                                  required="true">{{ $webinar->short_description ?? '' }}</textarea>
                    </div>

                    <div class="form-group editor-did">
                        <label>{{ trans('global.description') }}<span class="text-danger">*</span></label>
                        <textarea cols="100"
                                  class="form-control {{ $errors->has('description')? ' is-invalid' : ''}}"
                                  id="editor" name="description" rows="2"
                                  required="true">{{ $webinar->description ?? '' }}</textarea>
                    </div>

                    <div class="form-group">
                        <label>{{ trans('global.upload_files') }}
                            <small> (Max 1 Image)</small>
                        </label><span
                            class="text-danger">*</span>
                        <div id="dropzone" class="dropzone"></div>
                        <br> @php if(!empty($webinar->feature_image)) $images
					=explode(',',$webinar->feature_image[0]); @endphp @if(!empty($webinar->feature_image[0]))
                            <div class="row">
                                @foreach($images as $img)

                                    <div class="col-md-3 col-sm-12 col-12 ml-3">
                                        <div class="img-wrapper">
                                            <a href="{{ asset('thumb/thumb_511X455_').$img }}">
                                                <img src="{{ asset('thumb/thumb_511X455_').$img }}" class="img-fluid">
                                            </a>
                                            <div class="middle">

                                                <button class="btn view-m-gbtn btn-webinar-image"
                                                        data-image="{{ $img }}"
                                                        data-id="{{$webinar->postImages[0]->id}}">
                                                    <input type="hidden" name="image_id"
                                                           value="{{$webinar->postImages[0]->id}}">
                                                    <span><i class="fas fa-times"></i></span>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                <!--<a href="{{ URL::asset('research/uploads/'.$img) }}">View</a>-->
                                @endforeach </div>@endif
                        <div class="hidden_images_area"></div>
                    </div>


                    <button type="submit" class="btn btn-primary pull-right">{{
					trans('global.update') }}</button>
                </div>
            </form>
        </div>
    </div>





@section('styles') @parent

<link href="{{ asset('css/dropzone.css') }}" rel="stylesheet"/>
<link href="{{ asset('css/amsify.suggestags.css') }}" rel="stylesheet"/>
<style>
    .form-group.editor-did {
        position: relative;
    }

    label#editor-error {
        position: absolute;
        bottom: -28px;
        z-index: 1111;
        left: 0;
    }

    #tags-error {
        display: none !important;
    }
</style>
@endsection @section('scripts') @parent

<script src="{{ asset('js/dropzone.js') }}"></script>
<script src="{{ asset('js/ckeditor.js') }}"></script>
<script type="text/javascript"
        src="{{ asset('js/jquery.amsify.suggestags.js') }}"></script>
<script type="text/javascript"
        src="{{ asset('js/ckfinder/ckfinder.js') }}"></script>
<script>CKFinder.config({connectorPath: '{{ route("ckfinder_connector") }}'});</script>

<script>

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });


    ClassicEditor
        .create(document.querySelector('#editor'), {
            //toolbar: [ 'heading', '|', 'bold', 'italic', 'link' ]

            toolbar: {
                items: [{!!  Config::get('ckeditor') !!}]
            },
            language: 'en',
            image: {
                toolbar: [
                    'imageTextAlternative',
                    'imageStyle:full',
                    'imageStyle:side'
                ]
            },
            table: {
                contentToolbar: [
                    'tableColumn',
                    'tableRow',
                    'mergeTableCells',
                    'tableCellProperties',
                    'tableProperties'
                ]
            },
            licenseKey: '',
            sidebar: {
                container: document.querySelector('.sidebar')
            },

        })
        .then(editor => {
            window.editor = editor;
            console.log(editor);
        })
        .catch(err => {
            console.error(err.stack);
        });


    $(document).on('click', '.image-holder', function () {

        var imgaePath = null;
        CKFinder.popup({
            chooseFiles: true,
            closePopup: true,
            onInit: function (finder) {
                finder.on('files:choose', function (evt) {
                    console.log(evt.data.files.first().attributes.url);
                    var file = evt.data.files.first();
                    imgaePath = evt.data.files.first().attributes.url;
                    $('.image-holder').html('<img class="img-responsive" src="' + imgaePath + '" style="width:100%;"/>');
                    $('#_hidden_feature_image').val(imgaePath);

                });
                finder.on('file:choose:resizedImage', function (evt) {
                    imgaePath = evt.data.resizedUrl;
                    $('.image-holder').html('<img class="img-responsive" src="' + imgaePath + '" style="width:100%;"/>');

                    $('#_hidden_feature_image').val(imgaePath);
                });
            }
        });
    });


    $("#createSchemeForm").validate({
        ignore: [],
        rules: {
            title: {           //input name: fullName
                required: true,   //required boolean: true/false
                minlength: 10
            },
            _tags: {           //input name: fullName
                required: true,   //required boolean: true/false
            },
            summary: {
                required: true,   //required boolean: true/false
                minlength: 10
            },
            description: {
                required: true,   //required
                minlength: 20
            },
        },
        submitHandler: function (form) {
            form.submit();
        }
    });


    // Dropzone class:
    Dropzone.autoDiscover = false;
    Dropzone.options.dropzone = {
        url: "{{ route('admin.projects.storeMedia') }}",
        paramName: "file",
        maxFilesize: 2,
        maxFiles: 5,
        acceptedFiles: ".jpeg,.jpg,.png",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        init: function () {
            var drop = this; // Closure

            this.on('error', function (file, errorMessage) {
                //alert(maxFilesize);
                //this.removeAllFiles();
                if (errorMessage.indexOf('Error 404') !== -1) {
                    var errorDisplay = document.querySelectorAll('[data-dz-errormessage]');
                    errorDisplay[errorDisplay.length - 1].innerHTML = 'Error 404: The upload page was not found on the server';
                }
                if (errorMessage.indexOf('File is too big') !== -1) {
                    alert('Unable to upload imgae size is greated than 2 MB');
                    // i remove current file
                    drop.removeFile(file);
                }
            });
            this.on("maxfilesexceeded", function (file) {
                this.removeAllFiles();
                this.addFile(file);
            }),
                this.on("success", function (file, response) {
                    var hiddenImage = $('<input type="hidden" name="_hidden_images[]" value="' + response.name + '"/>');
//             $('#createSchemeForm').append(hiddenImage);
                    $('.hidden_images_area').append(hiddenImage);
                })
        }
    }

    //$('#dropzone').dropzone();

    $("input[type='text'][name='start_date']").datepicker({
        dateFormat: 'dd-mm-yy',
        changeMonth: true,
        minDate: '0',
        onSelect: function (date) {
            var nextDay = $(this).datepicker('getDate');
            nextDay.setDate(nextDay.getDate());
            $("input[type='text'][name='end_date']").datepicker("option", "minDate", nextDay);
        },
    });

    $("input[type='text'][name='start_time']").timepicker({
        dynamic: false,
        dropdown: true,
        scrollbar: true,
    });

    $("input[type='text'][name='end_time']").timepicker({
        dynamic: false,
        dropdown: true,
        scrollbar: true,
    });


    $("input[type='text'][name='end_date']").datepicker({
        dateFormat: 'dd-mm-yy',
        changeMonth: true,
        minDate: '0',
        onSelect: function (date) {
            var nextDay = $(this).datepicker('getDate');
            nextDay.setDate(nextDay.getDate());
            $("input[type='text'][name='start_date']").datepicker("option", "maxDate", nextDay);
        },
    });

    $(document).on('change', '.upload_video', function () {
        var file = this.files[0];
        var _size = this.files[0].size;
        var fSExt = new Array('Bytes', 'KB', 'MB', 'GB'),
            i = 0;
        while (_size > 900) {
            _size /= 1024;
            i++;
        }
        var exactSize = (Math.round(_size * 100) / 100) + ' ' + fSExt[i];
        var fileSize = (Math.round(_size * 100) / 100);
        console.log('FILE SIZE = ', exactSize);
        var fileType = file["type"];
        var validImageTypes = ["video/mp4"];
        if ($.inArray(fileType, validImageTypes) < 0) {
            swal.fire('Error', 'Upload only MP4 Video File', 'error');
            $(this).val('');
            return false;
        }
        if (fileSize > '50') {
            swal.fire('Error', 'Upload only 50 MB Video File(Your File Size ' + exactSize + ')', 'error');
            $(this).val('');
            return false;
        }
        return true;
    });

    $(document).on('click', '.btn-webinar-image', function (event) {
        event.preventDefault()
        var image = $(this).attr('data-image');
        var id = $(this).attr('data-id');
        Swal.fire({
            title: 'Are you sure you want to delete this image ?',
            type: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes'
        }).then((result) => {
            if (result.value) {
                Ajax.store({
                    'image': image,
                    'id': id
                }, '{{ route("admin.webinar.deleteImage") }}', 'POST').done(function (response) {
                    if (response.status == true) {
                        swal.fire('', 'Image Deleted Successfully', 'success');
                        location.reload();
                    }
                });
            }
        });
    });
</script>

@endsection @endsection

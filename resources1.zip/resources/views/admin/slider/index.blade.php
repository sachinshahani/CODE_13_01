@extends('admin.layouts.app')

@section('content')
    <div class="card">
        <div class="card-header">
            Slider
            <a href="{{ route('slider.create') }}" class="btn btn-primary"
            style="float: right">Add Slider</a>
        </div>

        <div class="card-body row">

            <div class="col-md-12">

                <div class="">
                   
                </div>

                <div class="table-responsive">
                    <table id="slider" class="table table-bordered nowrap table-striped align-middle" style="width:100%">
                        <thead>
                        <tr>
                            <th width="10">
                                S.No.
                                {{-- <input type="checkbox" name="select_all" id="selectAll"> --}}
                            </th>
                            <th>
                                Title
                            </th>
                            <th>
                                Type
                            </th>
                            <th>
                                Image
                            </th>
                            <th>
                                Language
                            </th>
                            <th>
                                Status
                            </th>
                            <th>
                                Action
                            </th>
                        </tr>
                        </thead>

                        <tbody></tbody>
                    </table>
                </div>

            </div>


        </div>
    </div>

@endsection
@push('script')
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        var table = $('#slider').DataTable({
            //dom: 'l<"clear">Bfrtip',
            //dom:'Bfrtip',
            //dom:'Blfrtip',
            lengthMenu: [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
            ],
            processing: true,
            serverSide: true,
            ajax: {
                url: "{{ route('slider.index') }}",
                type: 'GET',
                data: function(d) {

                }
            },
            columns: [{
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex',
                    orderable: true
                },
                {
                    data: 'title',
                    name: 'title',
                    orderable: true
                },
                {
                    data: 'summary',
                    name: 'summary',
                    orderable: true
                },
                {
                    data: 'image',
                    name: 'image',
                    orderable: true
                },
                {
                    data: 'language',
                    name: 'language',
                    orderable: true
                },
                {
                    data: 'status',
                    name: 'status',
                    orderable: true
                },
               // {
                //     data: 'created_on',
                //     name: 'created_on',
                //     orderable: true
                // },
                {
                    data: 'action',
                    name: 'name',
                    orderable: false
                },
            ],
            // initComplete: function () {
            //     var btns = $('.dt-button');
            //     //btns.addClass('btn btn-success btn-success');
            //     btns.removeClass('dt-button');

            // },

        });

        $(document).on('click', '.deletedata', function() {
            var id = $(this).attr('data-value');
          
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.value) {
                    $.ajax({
                        url: "{{ route('slider.delete') }}",
                        method: "POST",
                        dataType: 'json',
                        data: {
                            'id': id,
                        },
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function(result) {
                            Swal.fire('Deleted!', 'Record Deleted Successfully..', 'success')
                                .then((result) => {
                                    window.location.href =
                                        '{{ route('slider.index') }}';
                                });
                        }

                    });
                }
            });
        });
        
    </script>
@endpush

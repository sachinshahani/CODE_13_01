@extends('admin.layouts.app')
@section('content')
    <div class="card">
        <div class="card-header">
            <h4 class="card-title mb-0 flex-grow-1">@if(isset($data->id) && !empty($data->id) )Update Slider @else Create New Slider @endif</h4>
            <div class="flex-shrink-0">
                @if (session('error'))
                <div class="alert alert-danger">
                    {{ session('error') }}
                </div>
                @endif
                @if (session('success'))
                <div class="alert alert-success">
                    {{ session('success') }}
                </div>
                @endif
                @if($errors)
                @foreach ($errors->all() as $error)
                <div class="alert alert-danger">{{ $error }}</div>
                @endforeach
                @endif
            </div>
        </div>

        <div class="card-body">
            <div class="live-preview">
                @if(isset($data->id))
                <form class="row" enctype="multipart/form-data" method="post" id="createWebinarForm"
                      style="width: 100%;" action="{{ route('slider.update', $data->id) }}">
                    @method('PUT')
                    @else
                        <form class="row" method="post" action="{{ route('slider.store') }}"
                              id="createWebinarForm" style="width: 100%;" enctype="multipart/form-data">
                            @endif
                            @csrf
                   
                    <div class="row gy-4">
                       

                        <div class="row seperatesec">
                           
                            <div class="col-xxl-4 col-md-6">
                                <div>
                                    <label class="form-label">Title<span class="required">*</span></label>
                                    <input type="text" class="form-control" id="title" placeholder="Enter Title"
                                        name="title" required value="{{ old('title',isset($data->title)?$data->title:'') }}">
                                </div>
                            </div>
                            
                        </div>

                        <div class="row seperatesec">
                            <div class="sectitle">
                                <label for="labelInput" class="form-label">Summary<span class="required">*</span></label>
                            </div>

                            <div class="col-xxl-4 col-md-6">
                                <textarea class="form-control customtextarea" name="summary" required>{{ old('summary',isset($data->summary)?$data->summary:'') }}</textarea>
                            </div>
                        </div>  
                        <div class="row seperatesec">
                            <div class="col-xxl-4 col-md-6">
                                <div>
                                    <label class="form-label">Image</label>
                                    <input type="file" class="form-control"
                                        name="image"
                                        id="image">
                                    @if (!empty($data->image))
                                        <input type="hidden" name="image_edit" value="{{ $data->image ?? '' }}">
                                        <a target="_BLANK"
                                            href="{{ asset('public/slider/' . $data->image) }}"
                                            class="text-decoration-underline">See Doc</a>
                                    @endif
                                </div>
                            </div> 
                        </div>
                        <div class="row seperatesec">
                       
                            <div class="col-xxl-4 col-md-6">
                                <div>
                                    <label class="form-label">Language</label>
                                    <select class="form-select" name="language" required>
                                        <option value="">-Select-</option>
                                        <option value="EN" @selected(isset($data) && $data->language == 'EN')>English</option>
                                        <option value="HI" @selected(isset($data) && $data->language == 'HI')>Hindi</option>
                                   </select> 
                                </div>
                            </div> 
                        </div>
                        <div class="row seperatesec">
                            @if(isset($data->id) && !empty($data->id) )
                            <div class="col-xxl-4 col-md-6">
                                <div>
                                    <label class="form-label">Status</label>
                        
                                <select class="form-select" name="status" required>
                                    <option value="">-Select-</option>
                                    <option value="1"  @selected($data->status==1)>Active
                                    </option>
                                    <option value="0"  @selected($data->status==0)>InActive

                                    </option>
                                </select>
                             @endif

                            <div class="row">
                                <div class="col-lg-12 gy-4">
                                    <div class="hstack gap-2">
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                        <button type="button" class="btn btn-soft-success">Cancel</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

    @push('script')
    <script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
    
    <script type="text/javascript">
    $("#commonform1").validate({
        rules: {
            // user_password: { 
            // 	required: true,
            // 	minlength: 8,
            // 	maxlength: 10,
            // } ,
            mobile: {
                required: true,
            }
        },
        messages: {
            // user_password: { 
            // 	required:"This field is required and should be 8 digits, contains upper,lowerCase,and a special Character"   
            // },
            mobile: {
                required: "This field is required",
            }
        }
    
    });
</script>
    
@endpush
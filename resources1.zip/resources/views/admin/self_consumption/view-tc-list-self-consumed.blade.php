@extends('admin.layouts.app')
@section('content')
<style>
   .customtextarea {
   height: 80px;
   }
</style>
<!-- start page title -->
<div class="row">
   <div class="col-12">
      <div class="page-title-box d-sm-flex align-items-center justify-content-between">
         <h4 class="mb-sm-0">View TC list
                                self-consumed
                            
         </h4>
         <div class="page-title-right">
            <ol class="breadcrumb m-0">
                  <li class="breadcrumb-item"><a href="{{route('superadmin.dashboard')}}">Dashboard</a></li>
               <li class="breadcrumb-item active">Self consumption</li>
            </ol>
         </div>
      </div>
   </div>
</div>
<div>
   <div class="row white-inner align-items-end">
      <div class="col-xxl-2 col-lg-3 col-md-3">
          <div>
              <label class="form-label">Search By Registration No.<span class="required"></span></label>
              <input type="text" class="form-control" id="registration_no" name="registration_no" value="">
          </div>
      </div>
      <div class="col-xxl-1 col-lg-2 col-md-2 mt-3">
          <div class="text-left">
              <button type="submit" id="searchBtn" class="btn btn-primary w-100">Search</button>
          </div>
      </div>
  </div>
   <hr>
</div>
<div class="row seperatesec white-inner">
   <div class="sectitle">
      <label for="labelInput" class="form-label blue-ht">Operator Detail
      </label>
   </div>
   <div class="col-xxl-3 col-md-4 gy-3">
      <div>
         <label class="form-label">Operator Name :</label>
         <span class="badge badge-soft-success operator-name">----------</span>
      </div>
   </div>
   <div class="col-xxl-3 col-md-4 gy-3">
      <div>
         <label class="form-label">Scope For :</label>
         <span class="badge badge-soft-secondary scope-for">---------</span>
      </div>
   </div>
   <div class="col-xxl-3 col-md-4 gy-3">
      <div>
         <label class="form-label">Scope Certificate No. :</label>
         <span class="badge badge-soft-secondary certificate-no">------------</span>
      </div>
   </div>
   <div class="col-xxl-3 col-md-4 gy-3">
      <div>
         <label class="form-label">Validity :</label>
         <span class="validity-from">----</span> to <span class="validity-to">----</span>
      </div>
   </div>
</div>
<hr>
<div class="row white-inner">
   <div class="col-lg-12">
      <div class="table-responsive">
         <form id="dataForm" method="post" action="">
            @csrf
            <table id="searchResultsTable" class="table table-bordered table-striped align-middle"
               style="width:100%">
               <thead>
                  <tr>
                     <th>TC No</th>
                     <th>Product Name</th>
                     <th>Organic Status</th>
                     <th>Quantity (MT)</th>
                     <th>Source Quantity(MT)</th>
                     <th>Self Consumed Quantity</th>
                     <th>Total Quantity Used(MT)</th>
                     <th>Available Quantity (MT)</th>
                  </tr>
               </thead>
               <tbody>
               </tbody>
            </table>
            <!-- <button type="button" class="btn btn-primary" id="bulkactionbtn" value="1">Submit</button>  -->
            <!--  <button type="submit" class="btn btn-primary">Submit</button> -->
         </form>
      </div>
   </div>
</div>
<script>
   $(document).ready(function() {
       $('#searchBtn').click(function(e) {
           // alert('hi');
           e.preventDefault();
           $.ajax({
               url: '{{ route("listofregistersearchTc") }}',
               method: 'POST',
               data: {
                   _token: '{{ csrf_token() }}', // Add CSRF token for Laravel
                 
                  registration_no: $('#registration_no').val(),
               },
               success: function(response) {
                    console.log(response.data);
                      $('#searchResultsTable tbody').empty();
                      if(response.msg=='success'){
   
                       var operatorDetail = response.data.operator_detail;
                       $('.operator-name').text(operatorDetail.operator_name);
                       $('.scope-for').text(operatorDetail.scope_for);
                       $('.certificate-no').text(operatorDetail.scope_certificate_no);
                       $('.validity-from').text(operatorDetail.validity_from);
                       $('.validity-to').text(operatorDetail.validity_to);
                        
                           var tbody = '';
                           for(var i = 0,j=1; i < response.data.table_data.length; i++) {
                    
                              tbody += '<tr><td>' + response.data[i]['transaction_certificate_no'] + '</td><td>' + response.data[i]['product_name'] + '</td><td>' + response.data[i]['organic_status']+'</td><td>' + response.data[i]['quantity']+'</td><td>'+response.data[i]['quantity_source'] + '</td><td>'+response.data[i]['self_qty_consumed']+ '</td><td>'+response.data[i]['used_quantity']+ '</td><td>'+response.data[i]['remaining_quantity']+ '</td></tr>';
                           }
                           $('#searchResultsTable tbody').append(tbody);
                    }
                     else {
                       $('#searchResultsTable tbody').append('<tr><td colspan="11">No Data found.</td></tr>');
                   }
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
   
   
   $(document).on('change', '#select_all', function() {
   $(".ss_id").prop('checked', $(this).prop("checked"));
   });
   
   $(document).on('change', '.ss_id', function() {
   if (false == $(this).prop("checked")) {
   $("#select_all").prop('checked', $(this).prop("checked"));
   }
   if ($('.ss_id:checked').length == $('.ss_id').length) {
   $("#select_all").prop('checked', true);
   }
   });
   
   $(document).on('click', '#bulkactionbtn', function() {
   
   var ids = []; 
   var organic_status = []; 
   var self_consumption = []; 
   var remark = []; 
   
   $(".ss_id:checked").each(function() {  
   ids.push($(this).val());
   
   }); 
   $('.self_consumption').each(function(){
   self_consumption.push($(this).val());
   });
   $('.remark').each(function(){
   remark.push($(this).val());
   });
   $('.organic_status').each(function() {
    organic_status.push($(this).val());
   });
   if(ids.length === 0){
   Swal.fire({
     "title": "Warning",
     "text": "Please select atleast one checkbox.",
     "timer": 5000,
     "width": "32rem",
     "heightAuto": true,
     "padding": "1.25rem",
     "showConfirmButton": true,
     "showCloseButton": false,
     "icon": "warning"
   }); 
   return false;
   }else{
   Swal.fire({
     title: 'Are you sure?',
     text: "You won't be able to revert this!",
     icon: 'warning',
     showCancelButton: true,
     confirmButtonColor: '#3085d6',
     cancelButtonColor: '#d33',
     confirmButtonText: 'Ok !'
   }).then((result) => {
     if (result.value) {
       $.ajax({
     
         url: "{{route('superadmin.consumptionsave')}}",
         method: "POST",
         dataType: 'json',
         data: {
           ids: ids,
           self_consumption: self_consumption,
           remark: remark,
           organic_status: organic_status
         },
         headers: {
           'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
         },
         success: function(result) {
           console.log(result);
           if(result.status == '1'){
             Swal.fire('Alert',result.message,'success');
             window.location.reload();
   
           }
   
           if(result.status == '0'){
             Swal.fire('Alert',result.message,'warning');
             table_schedule();
              window.location.reload();
           }
         }
       });
     }
   });     
   }
   
   });
   
</script>
@endsection
@extends('admin.layouts.app')

@section('content')
    <div style="padding: 20px;">
        <div class="row gy-4">
            <div class="col-xxl-3 col-md-6">
                <div style="border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); padding: 20px; background-color: #fff;">
                    <h5 style="font-size: 1.1rem; font-weight: 500;">Self Consumed Quantity</h5>
                    <p>
                        <span style="background-color: #28a745; color: #fff; font-size: 1rem; padding: 0.5em 0.75em; border-radius: 0.25rem;">{{ $self_qty_consumed }}</span>
                    </p>
                </div>
            </div>
            <div class="col-xxl-3 col-md-6">
                <div style="border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); padding: 20px; background-color: #fff;">
                    <h5 style="font-size: 1.1rem; font-weight: 500;">Organic Status</h5>
                    <p>
                        <span style="background-color: #28a745; color: #fff; font-size: 1rem; padding: 0.5em 0.75em; border-radius: 0.25rem;">{{ getRefOrganicStatuscodeByname($org_status) }}</span>
                    </p>
                </div>
            </div>
            <div class="col-xxl-3 col-md-6">
                <div style="border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); padding: 20px; background-color: #fff;">
                    <h5 style="font-size: 1.1rem; font-weight: 500;">Type</h5>
                    <p>
                        <span style="background-color: #28a745; color: #fff; font-size: 1rem; padding: 0.5em 0.75em; border-radius: 0.25rem;">Lot</span>
                    </p>
                </div>
            </div>
            <div class="col-xxl-3 col-md-6">
                <div style="border-radius: 10px; box-shadow: 0 4px 8px #28a745; padding: 20px; background-color: #fff;">
                    <h5 style="font-size: 1.1rem; font-weight: 500;">Creation Date</h5>
                    <p>
                        @php
                            try {
                                $decodedCreatedAt = urldecode($created_at);
                                $createdAt = \Carbon\Carbon::parse($decodedCreatedAt);
                                $formattedDate = $createdAt->format('d-m-y');
                            } catch (\Exception $e) {
                                $formattedDate = 'N/A';
                            }
                        @endphp
                        <span style="background-color: #28a745; color: #fff; font-size: 1rem; padding: 0.5em 0.75em; border-radius: 0.25rem;">{{ $formattedDate }}</span>
                    </p>
                </div>
            </div>
            <div class="col-xxl-3 col-md-6">
                <div style="border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); padding: 20px; background-color: #fff;">
                    <h5 style="font-size: 1.1rem; font-weight: 500;">Remarks</h5>
                    <p>
                        <span style="background-color: #28a745; color: #fff; font-size: 1rem; padding: 0.5em 0.75em; border-radius: 0.25rem;">{{ $remark }}</span>
                    </p>
                </div>
            </div>
        </div>
    </div>
@endsection

<input type="hidden" value="{{url('/')}}" id="url" name="url">
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 text-center">
                <script>document.write(new Date().getFullYear())</script><strong>
                     © copyright APEDA</strong>
            </div>
         
            
        </div>
    </div>
</footer>
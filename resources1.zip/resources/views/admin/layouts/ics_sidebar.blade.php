<!-- Sidebar start -->
<div id="scrollbar">
    <div class="container-fluid">

        <div id="two-column-menu">
        </div>
        <ul class="navbar-nav" id="navbar-nav">
            <!-- <li class="menu-title"><span data-key="t-menu">Menu</span></li> -->
            <li class="nav-item">
                <a class="nav-link menu-link" href="{{ route('superadmin.dashboard') }}" role="button">
                    <i class="ri-dashboard-2-line"></i> <span data-key="t-dashboards">Home</span>
                </a>
            </li> <!-- end Dashboard Menu -->

            <li @if (Request::routeIs('superadmin.usermanagement.*')) class="nav-item active" @else class="nav-item" @endif>
                <a class="nav-link menu-link" href="#sidebarAuth" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarAuth">
                    <i class="ri-account-circle-line"></i> <span data-key="t-authentication">Registration</span> </a>
                <div class="collapse menu-dropdown" id="sidebarAuth">
                    <ul class="nav nav-sm flex-column">

                        @if (auth()->user()->status == 0)
                            <li class="nav-item">
                                <a href="{{ route('superadmin.icsuser.step1', [auth()->user()->id]) }}" class="nav-link"
                                    role="button" aria-expanded="false" aria-controls="sidebarSignUp"> My Application </a>
                            </li>
                        @else
                            <li class="nav-item">
                                <a href="{{ route('superadmin.icsuser.preview', auth()->user()->id) }}" class="nav-link"
                                    role="button" aria-expanded="false" aria-controls="sidebarSignUp"> My Application
                                </a>
                            </li>
                        @endif
                        {{-- <li class="nav-item">
                            <a href="javascript:void(0)" class="nav-link" role="button" aria-expanded="false"
                                aria-controls="sidebarSignUp">Add
                                Farmers </a>
                        </li>
                        <li class="nav-item">
                            <a href="javascript:void(0)" class="nav-link" role="button" aria-expanded="false"
                                aria-controls="sidebarSignUp">Add View OSP</a>
                        </li> --}}
                        <li class="nav-item">
                            <a href="{{ route('superadmin.icsuser.farmerList') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">List Of Registered
                                Farmers</a>
                        </li>
                        {{-- <li class="nav-item">
                            <a href="javascript:void(0)" class="nav-link" role="button" aria-expanded="false"
                                aria-controls="sidebarSignUp">List Of Producer
                                Products
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="javascript:void(0)" class="nav-link" role="button" aria-expanded="false"
                                aria-controls="sidebarSignUp"> View / Update
                                Farmer Aadhar / Bank Details </a>
                        </li> --}}
                    </ul>
                </div>
            </li>
            <li @if (Request::routeIs('superadmin.external.*')) class="nav-item active" @else class="nav-item" @endif>
                <a class="nav-link menu-link" href="#sidebarFarmer2" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarFarmer">
                    <i class="ri-user-follow-line"></i> <span data-key="t-authentication">Inspection</span>
                </a>
                <div class="collapse menu-dropdown" id="sidebarFarmer2">
                    <ul class="nav nav-sm flex-column">

                        {{-- <li class="nav-item">
                            <a href="javascript:void(0)" class="nav-link" role="button" aria-expanded="false"
                                aria-controls="sidebarSignUp">Add Internal Inspection
                            </a>
                        </li> --}}
                        <li class="nav-item">
                            <a href="{{ route('superadmin.inspectionList') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">View Internal Inspection
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li @if (Request::routeIs('superadmin.usermanagement.*')) class="nav-item active" @else class="nav-item" @endif>
                <a class="nav-link menu-link" href="#sidebarInspector" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarInspector">
                    <i class="ri-account-circle-line"></i> <span data-key="t-authentication">Schedule Registration /
                        Inspector
                    </span>
                </a>
                <div class="collapse menu-dropdown" id="sidebarInspector">
                    <ul class="nav nav-sm flex-column">

                        {{-- @can('inspector_list_access') --}}
                        <li class="nav-item">
                            <a href="{{ route('superadmin.icsuser.inspectorList') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">Schedule For Registration
                            </a>
                        </li>
                        {{-- @endcan --}}

                        <li class="nav-item">
                            <a href="{{ route('superadmin.icsuser.inspectorSchList') }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">Schedule For
                               Internal Inspection
                            </a>
                        </li>

                    </ul>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link menu-link" href="#scopcer" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarFarmer">
                    <i class="ri-user-follow-line"></i> <span data-key="t-authentication">Scope Certificate</span>
                </a>
                <div class="collapse menu-dropdown" id="scopcer">
                    <ul class="nav nav-sm flex-column">
                        <li class="nav-item">
                            <a href="{{ route('superadmin.applyScopeCertificate') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">Apply For Scope Certificate
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.icsuser.scopeRenewal') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">Application For Renewal
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            {{-- <li class="nav-item">
    <a class="nav-link menu-link" href="#stock" data-bs-toggle="collapse" role="button" aria-expanded="false"
        aria-controls="sidebarFarmer">
        <i class="ri-team-fill"></i> <span data-key="t-authentication">Scope
            Certification</span>
    </a>
    <div class="collapse menu-dropdown" id="stock">
        <ul class="nav nav-sm flex-column">
            <li class="nav-item">
                <a href="javascript:void(0)" class="nav-link" role="button" aria-expanded="false"
                    aria-controls="sidebarSignUp">Application For
                    Amendment
                </a>
            </li>
            <li class="nav-item">
                <a href="javascript:void(0)" class="nav-link" role="button" aria-expanded="false"
                    aria-controls="sidebarSignUp">Application For
                    Renewal
                </a>
            </li>
            <li class="nav-item">
                <a href="javascript:void(0)" class="nav-link" role="button" aria-expanded="false"
                    aria-controls="sidebarSignUp">Apply For NOP
                    Certificate
                </a>
            </li>
            <li class="nav-item">
                <a href="javascript:void(0)" class="nav-link" role="button" aria-expanded="false"
                    aria-controls="sidebarSignUp">List Of Application
                    For NOP Certificate
                </a>
            </li>
        </ul>
    </div>
</li> --}}
            <li class="nav-item">
                <a class="nav-link menu-link" href="#batch" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarFarmer">
                    <i class="ri-team-fill"></i> <span data-key="t-authentication">Harvest Update</span>
                </a>
                <div class="collapse menu-dropdown" id="batch">
                    <ul class="nav nav-sm flex-column">
                        <li class="nav-item">
                            <a href="{{ route('superadmin.harvestUpdate.updateIcsActualYield') }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">Update Actual
                                Yield
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="javascript:void(0)" class="nav-link" role="button" aria-expanded="false"
                                aria-controls="sidebarSignUp">View Harvest Details
                            </a>
                        </li>

                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link menu-link" href="#noc" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarFarmer">
                    <i class="ri-team-fill"></i> <span data-key="t-authentication">Lot Creation</span>
                </a>
                <div class="collapse menu-dropdown" id="noc">
                    <ul class="nav nav-sm flex-column">
                        <li class="nav-item">
                            <a href="{{ route('superadmin.lotcreation') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">Lot Creation
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.ViewLotsDetail') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">View Lot Details
                            </a>
                        </li>
                        <!--  <li class="nav-item">
                            <a href="javascript:void(0)" class="nav-link" role="button" aria-expanded="false"
                                aria-controls="sidebarSignUp">View Batch Details
                                wise
                            </a>
                        </li>-->
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link menu-link" href="#Purchase" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarPurchase">
                    <i class="ri-team-fill"></i> <span data-key="t-authentication">Purchase Details</span>
                </a>
                <div class="collapse menu-dropdown" id="Purchase">
                    <ul class="nav nav-sm flex-column">
                        <li class="nav-item">
                            <a href="{{ route('superadmin.purchaseList') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarPurchase">Purchase Detail List
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.purchaseRequestList') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarPurchase">Purchase Request List
                            </a>
                        </li>
                    </ul>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link menu-link" href="#internalStock" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarFarmer">
                    <i class="ri-team-fill"></i> <span data-key="t-authentication"> NOC Application</span>
                </a>
                <div class="collapse menu-dropdown" id="internalStock">
                    <ul class="nav nav-sm flex-column">
                        <li class="nav-item">
                            <a href="{{ route('superadmin.applyNOC') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">Apply NOC
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.splitNOC') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">Split Farm
                            </a>
                        </li>
                        {{-- <li class="nav-item">
                            <a href="javascript:void(0)" class="nav-link" role="button" aria-expanded="false"
                                aria-controls="sidebarSignUp">List of NOC Status
                                wise
                            </a>
                        </li> --}}

                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link menu-link" href="#transcerti" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarFarmer">
                    <i class="ri-team-fill"></i> <span data-key="t-authentication">Transaction
                        Certificate</span>
                </a>
                <div class="collapse menu-dropdown" id="transcerti">
                    <ul class="nav nav-sm flex-column">
                        <li class="nav-item">
                            <a href="{{ route('superadmin.applyForDomesticTC') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">Apply For Domestic TC
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="" class="nav-link" role="button" aria-expanded="false"
                                aria-controls="sidebarSignUp">Pending TC
                                Applications
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.listOfTransCertificate') }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">List Of TC Issued
                            </a>
                        </li>

                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link menu-link" href="#impingre" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarFarmer">
                    <i class="ri-team-fill"></i> <span data-key="t-authentication">Stock Inventory</span>
                </a>
                <div class="collapse menu-dropdown" id="impingre">
                    <ul class="nav nav-sm flex-column">
                        <li class="nav-item">
                            <a href="{{ route('superadmin.BatchStock') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">TC Stock
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.LotStock') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">Lot Stock
                            </a>
                        </li>

                    </ul>
                </div>
            </li>

            {{-- <li class="nav-item">
                <a class="nav-link menu-link" href="#helpdesk" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarAuth">
                    <i class="ri-account-circle-line"></i> <span data-key="t-authentication">User Manual</span>
                </a>
                <div class="collapse menu-dropdown" id="helpdesk">
                    <ul class="nav nav-sm flex-column">
                        <li class="nav-item">
                            <a href="javascript:void(0)" class="nav-link" role="button" aria-expanded="false"
                                aria-controls="sidebarSignUp">Applications For Scope Certificate
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="javascript:void(0)" class="nav-link" role="button" aria-expanded="false"
                                aria-controls="sidebarSignUp">Amendment Process
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="javascript:void(0)" class="nav-link" role="button" aria-expanded="false"
                                aria-controls="sidebarSignUp">Harvest, Lot And Domestic TC
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="javascript:void(0)" class="nav-link" role="button" aria-expanded="false"
                                aria-controls="sidebarSignUp"> NOC Application
                            </a>
                        </li>

                    </ul>
                </div>
            </li> --}}

            <li class="nav-item">
                <a class="nav-link menu-link" href="#mis" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarAuth">
                    <i class="ri-account-circle-line"></i> <span data-key="t-authentication">MIS Report
                    </span>
                </a>
                <div class="collapse menu-dropdown" id="mis">
                    <ul class="nav nav-sm flex-column">
                        <li class="nav-item">
                            <a href="{{ route('superadmin.country-wise-exports') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">Country Wise Exports
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.scope-issued-mis') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">Scope Issued
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.list-of-register-operator') }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">List Of Registered
                                Operator
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.state-wise-area') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">State Wise Area
                                (Active)
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.total-farmer') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">Total Farmers (Active)
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.list-of-tc-issue') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">List Of TC Issued
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="{{ route('superadmin.list-of-ptctc-issue') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">List Of PTC Issued
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.view-operator-osp') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">View Operator OSP
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.scope-pending-for-renewal') }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">Scopes Pending For
                                Renewal
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.unit-pending-for-license-renewal') }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">Processing Unit
                                Pending For License Renewal
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.view-products-details') }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">View Products
                                Details(Trader/Processor)

                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.scope-nearby-for-discontinuation') }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">Scope Nearby For
                                Discontinuation
                            </a>
                        </li>

                    </ul>
                </div>
            </li>


            <li class="nav-item">
                <a class="nav-link menu-link" href="#help" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarAuth">
                    <i class="ri-account-circle-line"></i> <span data-key="t-authentication">Help
                        Desk</span>
                </a>
                <div class="collapse menu-dropdown" id="help">
                    <ul class="nav nav-sm flex-column">
                        <li class="nav-item">
                            <a href="{{ route('superadmin.help_desk') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">Help Desk Tickets
                            </a>
                        </li>




                              <li class="nav-item">
                                        <a href="{{route('ticketIP')}}" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">Tickets List
                                        </a>
                                    </li>

                    </ul>
                </div>
            </li>


            <!-- <li class="nav-item">
                <a class="nav-link menu-link" href="#" role="button">
                    <i class="ri-contacts-book-2-fill"></i> <span data-key="t-dashboards">Contact
                        Us</span>
                </a>
            </li> -->
            <li class="nav-item">
                <a class="nav-link menu-link"
                    href="https://apeda.gov.in/apedawebsite/HACCP/labs_Organic_09_January_2023.pdf" target="_blank"
                    role="button">
                    <i class="ri-file-list-fill"></i> <span data-key="t-dashboards">List Of Authorized
                        Lab</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link menu-link"
                    href="https://apeda.gov.in/apedawebsite/organic/ORGANIC_CONTENTS/National_Programme_for_Organic_Production.htm"
                    target="_blank" role="button">
                    <i class="ri-government-fill"></i> <span data-key="t-dashboards">Revised NPOP
                        Standards 2025</span>
                </a>
            </li>



        </ul>
    </div>

</div>
<!-- Sidebar end -->

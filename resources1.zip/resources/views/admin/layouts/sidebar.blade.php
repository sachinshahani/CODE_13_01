@php
    $currentUrl = \Route::currentRouteName();
    $module_name = !empty($module_name) ? $module_name : '';
    $module_title = !empty($module_title) ? $module_title : '';
     $user = Auth::guard('misadmin')->user();
    $user_id = $user ? $user->id : null; 
    $registration = getMenusubmenu($user_id);
  
@endphp

<!-- Sidebar start -->
<div id="scrollbar">
    <div class="container-fluid">

        <div id="two-column-menu">
        </div>
        <ul class="navbar-nav" id="navbar-nav">
            <!-- <li class="menu-title"><span data-key="t-menu">Menu</span></li> -->
            <li class="nav-item">
                <a class="nav-link menu-link" href="{{ route('superadmin.dashboard') }}" role="button">
                    <i class="ri-dashboard-2-line"></i> <span data-key="t-dashboards">Home</span>
                </a>
            </li> <!-- end Dashboard Menu -->
            <!-- <li class="nav-item">
                <a class="nav-link menu-link" href="" role="button">
                    <i class="ri-dashboard-2-line"></i> <span data-key="t-dashboards">Register Digital Signature</span>
                </a>
            </li> -->
            <li class="nav-item active">
                <a class="nav-link menu-link" href="#sidebarAuth21" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarAuth">
                    <i class="ri-account-circle-line"></i> <span data-key="t-authentication">About TraceNet</span>
                </a>
                <div class="collapse menu-dropdown" id="sidebarAuth21">
                    <ul class="nav nav-sm flex-column">
                        {{-- @can('slider_access')
                            <li class="nav-item">
                                <a class="nav-link menu-link" href="{{ route('slider.index') }}" role="button">
                                    <i class="ri-image-line"></i> <span data-key="t-dashboards">Slider</span>
                                </a>
                            </li>
                        @endcan --}}
                        {{-- <li class="nav-item">
                            <a class="nav-link menu-link" href="#" role="button">
                                <i class="ri-focus-2-line"></i> <span data-key="t-dashboards">About TraceNet</span>
                            </a>
                        </li> --}}
                        <li class="nav-item">
                            <a class="nav-link menu-link"
                                href="{{route('superadmin.Announcement')}}"
                                role="button">
                                {{-- <i class="ri-file-list-fill"></i>--}} <span data-key="t-dashboards">Announcements/ Notifications</span> 
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link menu-link"
                                href="https://apeda.gov.in/apedawebsite/organic/ORGANIC_CONTENTS/National_Programme_for_Organic_Production.htm"
                                target="_blank" role="button">
                                {{-- <i class="ri-government-fill"></i>--}} <span data-key="t-dashboards">Revised NPOP Standards 2025</span> 
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link menu-link"
                                href="https://itrack.apeda.gov.in/MasterReport/ModuleVsProductForWeb.aspx?RequestID=66355182&PageID=5&moduleid=161"
                                target="_blank" role="button">
                                {{-- <i class="ri-file-list-fill"></i>--}} <span data-key="t-dashboards">List of Authorized 
                                    Lab</span>
                            </a>
                        </li>
                     
                        <li class="nav-item">
                            <!-- <a class="nav-link menu-link" href="#Contact" data-bs-toggle="collapse"
                                role="button" aria-expanded="false" aria-controls="sidebarFarmer">
                                {{-- <i class="ri-contacts-book-2-fill"></i>--}} <span data-key="t-authentication">Contact 
                                    Us</span>
                            </a> -->
                            <div class="collapse menu-dropdown" id="Contact">
                                <ul class="nav nav-sm flex-column">
                                    <li class="nav-item">
                                        <a href="{{route('superadmin.OrganicDivision')}}" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">Organic Division
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{route('superadmin.TechnicalSupport')}}" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">Technical Support
                                            
                                        </a>
                                    </li>
                                
                                </ul>
                            </div>
                        </li>
                      
                       
                        
                        {{-- <li class="nav-item">
                            <a class="nav-link menu-link" href="#usermanual" data-bs-toggle="collapse"
                                role="button" aria-expanded="false" aria-controls="sidebarFarmer">
                                <i class="ri-team-fill"></i> <span data-key="t-authentication">User Manual</span>
                            </a>
                            <div class="collapse menu-dropdown" id="usermanual">
                                <ul class="nav nav-sm flex-column">
                                    <li class="nav-item">
                                        <a href="javascript:void(0)" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">New Operator
                                            Registration
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="javascript:void(0)" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">Generate Scope
                                            Certificate - NPOP
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="javascript:void(0)" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">Closing Stocks (ICS&
                                            Individual Producer)
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="javascript:void(0)" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">Transaction
                                            Certificate Issuance
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="javascript:void(0)" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">Generate Scope
                                            Certificate â€“ NPOP
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="javascript:void(0)" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">NOC Approval
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="javascript:void(0)" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">Internal Stock
                                            Transfer
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="javascript:void(0)" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">Suspend / Terminate /
                                            Revoke Operators
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="javascript:void(0)" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">High Risk Batch
                                            Process for CB
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="javascript:void(0)" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">List of High Risks
                                            Products
                                        </a>
                                    </li>

                                </ul>
                            </div>
                        </li> --}}
                    </ul>
                </div>

            </li>
            
            {{-- @dd(Gate::allows('user_management_access')); --}}

            <ul class="nav nav-pills flex-column">
                @foreach ($registration as $moduleId => $module)
                    <li class="nav-item active">
                        <a class="nav-link menu-link" href="#sidebar{{ $moduleId }}" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebar{{ $moduleId }}">
                            <i class="ri-account-circle-line"></i> 
                            <span data-key="t-authentication">{{ $module['module_name'] }}</span>
                        </a>

                        <div class="collapse menu-dropdown" id="sidebar{{ $moduleId }}">
                            <ul class="nav nav-sm flex-column">
                                @foreach ($module['submodules'] as $submenu)
                               
                                    <li class="nav-item">
                                        <a href="{{ URL($submenu['module_path']) }}" class="nav-link" role="button">
                                            {{ $submenu['submodule_name'] ?? 'N/A' }}  
                                        </a>
                                    </li>
                                @endforeach
                            </ul>
                        </div>
                    </li>
                @endforeach
            </ul>


            
            {{-- @can('user_management_access')

            <li class="nav-item active" class="nav-item">
                <a class="nav-link menu-link" href="#sidebarAuth" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarAuth">
                    <i class="ri-account-circle-line"></i> <span data-key="t-authentication">Operator
                        Registration</span>
                </a>
              
                <div class="collapse menu-dropdown" id="sidebarAuth">
                    <ul class="nav nav-sm flex-column">
                   
                 
         
            
<!--                         
                        <li class="nav-item">
                            <a href="{{route('superadmin.usermanagement.nocoperator')}}" role="button"
                                class="nav-link" role="button" aria-expanded="false"
                                aria-controls="sidebarSignUp">NOC Registration

                            </a>
                        </li>
                       
                        <li class="nav-item">
                            <a href="{{ route('superadmin.usermanagement.deptUser', 2) }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">Grower Group
                            </a>
                        </li>
                      
                        <li class="nav-item">
                            <a href="{{ route('superadmin.usermanagement.deptUser', 3) }}" class="nav-link" 
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">Individual
                                Producer
                            </a>
                        </li>
                      

                        <li class="nav-item">
                            <a href="{{ route('superadmin.usermanagement.deptUser', 4) }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">Wild Harvester
                            </a>
                        </li>
                     

                        <li class="nav-item">
                            <a href="{{ route('superadmin.usermanagement.deptUser', 5) }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">Trader
                            </a>
                        </li>
                       

                        <li class="nav-item">
                            <a href="{{ route('superadmin.usermanagement.deptUser', 6) }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">Processor
                            </a>
                        </li>
                      

                        <li class="nav-item">
                            <a href="{{ route('superadmin.mandatormanagement.mandatorlist') }}" role="button"
                                class="nav-link" role="button" aria-expanded="false" aria-controls="sidebarSignUp">Service Providers

                            </a>
                        </li>
                     

                        <li class="nav-item">
                            <a href="{{ route('superadmin.usermanagement.panalty') }}" role="button" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">List of
                                Registration(s)

                            </a>
                        </li>
                       

                        <li class="nav-item">
                            <a href="{{route('superadmin.usermanagement.discon')}}" role="button"
                                class="nav-link" role="button" aria-expanded="false" aria-controls="sidebarSignUpss">List of Discontinued Operators

                            </a>
                         </li> 
                        

                        <li class="nav-item">
                            <a href="{{ route('superadmin.usermanagement.discontinued') }}" role="button"
                                class="nav-link" role="button" aria-expanded="false" aria-controls="sidebarSignUp">List of Sanctioned Operators

                            </a>
                        </li>
                       -->
                        

                        
                 
        
                </ul>
                </div>
            </li>
            @endcan --}}

            
            {{-- @else
                        <li @if (Request::routeIs('superadmin.usermanagement.*')) class="nav-item active" @else class="nav-item" @endif>
                            <a class="nav-link menu-link" href="#sidebarAuth" data-bs-toggle="collapse" role="button"
                                aria-expanded="false" aria-controls="sidebarAuth">
                                <i class="ri-account-circle-line"></i> <span
                                    data-key="t-authentication">Registration</span>
                            </a>
                            <div class="collapse menu-dropdown" id="sidebarAuth">
                                <ul class="nav nav-sm flex-column">

                                    @if (auth()->user()->status == 0)
                                        <li class="nav-item">
                                            <a href="{{ route('superadmin.icsuser.step1', [auth()->user()->id]) }}"
                class="nav-link" role="button" aria-expanded="false"
                aria-controls="sidebarSignUp"> My Profile </a>
                </li>
                @else
                <li class="nav-item">
                    <a href="{{ route('superadmin.icsuser.preview', auth()->user()->id) }}" class="nav-link" role="button" aria-expanded="false" aria-controls="sidebarSignUp"> My Profile
                    </a>
                </li>
                @endif

        </ul>
    </div>
    </li> --}}



            @can('ics_user_access')
                @if (auth()->user()->ref_operator_type_id == 1)


                    {{-- <!-- <li class="nav-item">
            <a class="nav-link menu-link" href="{{ route('superadmin.mandatormanagement.mandatorlist') }}" role="button">
                <i class="ri-focus-2-line"></i> <span data-key="t-dashboards">Mandator List</span>
            </a>
        </li>  --}}

                @endif
            @endcan

            {{-- <li @if (Request::routeIs('superadmin.usermanagement.*')) class="nav-item active" @else class="nav-item" @endif>
                <a class="nav-link menu-link" href="#sidebarInspector" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarInspector">
                    <i class="ri-account-circle-line"></i> <span data-key="t-authentication">Schedule Registration /
                        Inspector
                    </span>
                </a>
                <div class="collapse menu-dropdown" id="sidebarInspector">
                    <ul class="nav nav-sm flex-column">

                       
                        <li class="nav-item">
                            <a href="{{route('superadmin.usermanagement.SurveyList')}}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">Schedule for Survey
                            </a>
                        </li>
                  
                        <li class="nav-item">
                            <a href="" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">Schedule for
                                Inspection
                            </a>
                        </li>

                    </ul>
                </div>
            </li> --}}


            <li @if (Request::routeIs('superadmin.external.*')) class="nav-item active" @else class="nav-item active" @endif>
                <a class="nav-link menu-link" href="#sidebarFarmer2" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarFarmer">
                    <i class="ri-user-follow-line"></i> <span data-key="t-authentication">Inspection</span>
                </a>
                <div class="collapse menu-dropdown" id="sidebarFarmer2">
                    <ul class="nav nav-sm flex-column">
                        @if (auth()->user()->ref_operator_type_id == 7)
                            <li class="nav-item active">
                                <a class="nav-link menu-link" href="{{ route('superadmin.inspectionList') }}"
                                    role="button">
                                    <i class="ri-dashboard-2-line"></i> <span data-key="t-dashboards">Inspection
                                        List</span>
                                </a>
                            </li>
                        @else
                            {{-- <li class="nav-item">
                                <a href="{{ route('superadmin.inspectionCompleteList') }}" class="nav-link"
                                    role="button" aria-expanded="false" aria-controls="sidebarSignUp">Internal
                                    inspection Details
                                </a>
                            </li> --}}

                            <li class="nav-item">
                                <a href="{{ route('superadmin.scheduleExternalInspection') }}" class="nav-link"
                                    role="button" aria-expanded="false" aria-controls="sidebarSignUp">Schedule For
                                    External Inspection
                                </a>
                            </li>

                            <li class="nav-item">
                                <a href="{{ route('superadmin.external.extRiskAssesmentList') }}" class="nav-link"
                                    role="button" aria-expanded="false" aria-controls="sidebarSignUp">Risk Assesment
                                </a>
                            </li>


                            <!-- <li class="nav-item">
                                <a href="{{ route('superadmin.external.inspectionList') }}" class="nav-link"
                                    role="button" aria-expanded="false" aria-controls="sidebarSignUp">External
                                    Inspection
                                </a>
                            </li> -->

                             <li class="nav-item">
                                <a href="{{ route('superadmin.externalinspectionListReports') }}" class="nav-link"
                                    role="button" aria-expanded="false" aria-controls="sidebarSignUp">External
                                    Inspection Reports
                                </a>
                            </li> 


                            {{-- <li class="nav-item">
                        <a href="javascript:void(0)" class="nav-link" role="button" aria-expanded="false" aria-controls="sidebarSignUp">External inspection
                            (unannounced)
                        </a>
                    </li>  --}}

                        @endif
                    </ul>
                </div>
            </li>
            <li class="nav-item active">
                <a class="nav-link menu-link" href="#scopcer" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarFarmer">
                    <i class="ri-user-follow-line"></i> <span data-key="t-authentication">Scope
                        Certification</span>
                </a>
                <div class="collapse menu-dropdown" id="scopcer">
                    <ul class="nav nav-sm flex-column">
                        <li class="nav-item">
                            <a href="{{ route('superadmin.scopeCertificateList') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">Generate scope
                                certificate (NPOP)
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="{{ route('superadmin.renewalScopeCertificateList') }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">Pending
                                applications
                                for amendment (NPOP)
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.issuedScopeCertificateList') }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">List of scope
                                certificate issued
                            </a>
                        </li>
                        {{-- <li class="nav-item">
                                        <a href="javascript:void(0)" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">Generate scope
                                            certificate (NOP)
                                        </a>
                                    </li> --}}

                        {{-- <li class="nav-item">
                                        <a href="javascript:void(0)" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">Pending applications
                                            for amendment (NOP)
                                        </a>
                                    </li> --}}

                        <!-- <li class="nav-item">
                    <a href="javascript:void(0)" class="nav-link" role="button" aria-expanded="false" aria-controls="sidebarSignUp">View suspended and
                        terminated operators
                    </a>
                </li> -->
                    
                    </ul>
                </div>
                
            </li>
            <li class="nav-item active">
                <a class="nav-link menu-link" href="#stock" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarFarmer">
                    <i class="ri-team-fill"></i> <span data-key="t-authentication">Closing stock</span>
                </a>
                <div class="collapse menu-dropdown" id="stock">
                    <ul class="nav nav-sm flex-column">
                        <li class="nav-item">
                            <a href="{{ route('superadmin.closingstocks.updateclosingestock') }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">Add closing stock
                            </a>
                        </li>
                       
                    </ul>
                </div>
            </li>
            <li class="nav-item active">
                <a class="nav-link menu-link" href="#batch" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarFarmer">
                    <i class="ri-team-fill"></i> <span data-key="t-authentication">Batch creation</span>
                </a>
                <div class="collapse menu-dropdown" id="batch">
                    <ul class="nav nav-sm flex-column">
                        <li class="nav-item">
                            <a href="{{ route('superadmin.usermanagement.editbatch') }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">Pending Batch for
                                Approval
                            </a>
                        </li>

                    </ul>
                </div>
            </li>
            <li class="nav-item active">
                <a class="nav-link menu-link" href="#noc" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarFarmer">
                    <i class="ri-team-fill"></i> <span data-key="t-authentication">NOC Application</span>
                </a>
                <div class="collapse menu-dropdown" id="noc">
                    <ul class="nav nav-sm flex-column">
                        <li class="nav-item">
                            <a href="{{ route('superadmin.icsuser.getNOCDetailList') }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">NOC pending
                            </a>
                        </li>
                        {{-- <li class="nav-item">
                            <a href="{{ route('superadmin.icsuser.nocRegister') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">NOC register
                            </a>
                        </li> --}}
                        <li class="nav-item">
                            <a href="{{ route('superadmin.icsuser.getNOCDetailListStatusWise') }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">List of NOC status
                                wise
                            </a>
                        </li>
                        <!-- <li class="nav-item">
                    <a href="javascript:void(0)" class="nav-link" role="button" aria-expanded="false" aria-controls="sidebarSignUp">List of NOC operator
                    </a>
                </li> -->

                    </ul>
                </div>
            </li>
            <li class="nav-item active">
                <a class="nav-link menu-link" href="#internalStock" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarFarmer">
                    <i class="ri-team-fill"></i> <span data-key="t-authentication">Internal stock
                        transfer</span>
                </a>
                <div class="collapse menu-dropdown" id="internalStock">
                    <ul class="nav nav-sm flex-column">
                        <li class="nav-item">
                            <a href="{{ route('superadmin.usermanagement.pendingApplicationStockTransfer') }}"
                                class="nav-link" role="button" aria-expanded="false"
                                aria-controls="sidebarSignUp">Pending applications
                                for stock transfer
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.usermanagement.listApplicationStockTransfer') }}"
                                class="nav-link" role="button" aria-expanded="false"
                                aria-controls="sidebarSignUp">List of internal stock
                                transfer applications
                            </a>
                        </li>

                    </ul>
                </div>
            </li>
            <li class="nav-item active">
                <a class="nav-link menu-link" href="#transcerti" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarFarmer">
                    <i class="ri-team-fill"></i> <span data-key="t-authentication">Transaction
                        certificate</span>
                </a>
                <div class="collapse menu-dropdown" id="transcerti">
                    <ul class="nav nav-sm flex-column">
                        <!-- <li class="nav-item">
                    <a href="javascript:void(0)" class="nav-link" role="button" aria-expanded="false" aria-controls="sidebarSignUp">Trace TC application
                    </a>
                </li> -->
                        <li class="nav-item">
                            <a href="{{ route('superadmin.tcrequestCbcertificate') }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">Pending TC
                                applications
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.ptcrequestCbcertificate') }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">Pending PTC
                                applications
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.cb.tsIssueList') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">List of TC issued
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item active">
                <a class="nav-link menu-link" href="#impingre" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarFarmer">
                    <i class="ri-team-fill"></i> <span data-key="t-authentication">Imported
                        ingredients</span>
                </a>
                <div class="collapse menu-dropdown" id="impingre">
                    <ul class="nav nav-sm flex-column">
                        <li class="nav-item">
                            <a href="{{ route('superadmin.importIngredientList') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">Pending applications
                                for approval
                            </a>
                        </li>
                        <!-- <li class="nav-item">
                    <a href="javascript:void(0)" class="nav-link" role="button" aria-expanded="false" aria-controls="sidebarSignUp">List of applications
                        approved
                    </a>
                </li> -->

                    </ul>
                </div>
            </li>
            <li class="nav-item active">
                <a class="nav-link menu-link" href="#stockinv" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarFarmer">
                    <i class="ri-team-fill"></i> <span data-key="t-authentication">Stock inventory</span>
                </a>
                <div class="collapse menu-dropdown" id="stockinv">
                    <ul class="nav nav-sm flex-column">
                        <li class="nav-item">
                            <a href="{{ route('superadmin.CbLotStock') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">Lot stock inventory
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.CbBatchStock') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">Batch stock inventory
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.CbTcStock') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">TC stock inventory
                            </a>
                        </li>

                    </ul>
                </div>
            </li>
            <li class="nav-item active">
                <a class="nav-link menu-link" href="#selfcons" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarFarmer">
                    <i class="ri-team-fill"></i> <span data-key="t-authentication">Self consumption</span>
                </a>
                <div class="collapse menu-dropdown" id="selfcons">
                    <ul class="nav nav-sm flex-column">
                        <li class="nav-item">
                            <a href="{{ route('superadmin.consumption-for-batch-details') }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">Consumption for
                                lot
                                /batch details
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.consumption-for-tc') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">Consumption for TC
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.view-lot-batch-list-self-consume') }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">View lot / batch
                                list
                                self-consumed
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.view-tc-list-self-consumed') }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">View TC list
                                self-consumed
                            </a>
                        </li>

                    </ul>
                </div>
            </li>
            <li
                class="nav-item active {{ $currentUrl == 'superadmin.registrationList' || $currentUrl == 'superadmin.applicationInspectionList' || $currentUrl == 'superadmin.productList' || $currentUrl == 'superadmin.applicationGenerateCertificateList' ? 'active' : '' }}">
                <a class="nav-link menu-link " href="#inputapp" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarFarmer">
                    <i class="ri-team-fill"></i> <span data-key="t-authentication">Input approval</span>
                </a>
                <div class="collapse menu-dropdown {{ $currentUrl == 'superadmin.registrationList' || $currentUrl == 'superadmin.applicationInspectionList' || $currentUrl == 'superadmin.productList' || $currentUrl == 'superadmin.applicationGenerateCertificateList' ? 'show' : '' }}"
                    id="inputapp">
                    <ul class="nav nav-sm flex-column">
                        <li class="nav-item">
                            <a href="{{ route('superadmin.registrationList') }}"
                                class="nav-link {{ $currentUrl == 'superadmin.registrationList' ? 'active' : '' }}"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">New Registrations
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="{{ route('superadmin.productList') }}"
                                class="nav-link {{ $currentUrl == 'superadmin.productList' ? 'active' : '' }}"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">List of Products Registered
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#"
                                class="nav-link {{ $currentUrl == 'superadmin.registrationList' ? 'active' : '' }}"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">Add ingredients
                                product wise
                            </a>
                        </li>
                        <!-- <li class="nav-item">
                    <a href="javascript:void(0)" class="nav-link" role="button" aria-expanded="false" aria-controls="sidebarSignUp">Add batch details
                    </a>
                </li> -->
                        <li class="nav-item">
                            <a href="{{ route('superadmin.applicationInspectionList') }}"
                                class="nav-link {{ $currentUrl == 'superadmin.applicationInspectionList' ? 'active' : '' }}"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">Inspection details
                            </a>
                        </li>

                        <!-- <li class="nav-item">
                    <a href="" class="nav-link" role="button" aria-expanded="false" aria-controls="sidebarSignUp">Generrate New Certificate
                    </a>
                </li> -->
                        {{-- <li class="nav-item">
                                        <a href="javascript:void(0)" class="nav-link {{ ($currentUrl == 'superadmin.applicationInspectionList') ? 'active' : '' }}" role="button"
                aria-expanded="false" aria-controls="sidebarSignUp">Generate a new
                certificate
                </a>
    </li> --}}
                        <li class="nav-item">
                            <a href="{{ route('superadmin.applicationGenerateCertificateList') }}"
                                class="nav-link {{ $currentUrl == 'superadmin.applicationGenerateCertificateList' ? 'active' : '' }}"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">List of issued
                                certificates
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.applicationRenewalList') }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">Applications for
                                renewal
                            </a>
                        </li>

                        <!-- <li class="nav-item">
        <a href="" class="nav-link" role="button" aria-expanded="false" aria-controls="sidebarSignUp">List of Registration
        </a>
    </li>

    <li class="nav-item">
        <a href="" class="nav-link" role="button" aria-expanded="false" aria-controls="sidebarSignUp">Application(s) for Amendment
        </a>
    </li>

    <li class="nav-item">
        <a href="" class="nav-link" role="button" aria-expanded="false" aria-controls="sidebarSignUp">List of Amendment Annexure
        </a>
    </li> -->


                    </ul>
                </div>
            </li>
            <li class="nav-item active">
                <a class="nav-link menu-link" href="#usercreation" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarFarmer">
                    <i class="ri-team-fill"></i> <span data-key="t-authentication">User Management </span>
                </a>
                <div class="collapse menu-dropdown" id="usercreation">
                    <ul class="nav nav-sm flex-column">
                        <li class="nav-item">
                            <a href="{{ route('superadmin.usermanagement.usercreatelist') }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">Add Employees
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.usermanagement.rolelist') }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">Add Role of
                                Employees
                            </a>
                        </li>

                    </ul>
                </div>
            </li>
            <li class="nav-item active">
                <a class="nav-link menu-link" href="#misreport" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarFarmer">
                    <i class="ri-team-fill"></i> <span data-key="t-authentication">MIS report</span>
                </a>
                <div class="collapse menu-dropdown" id="misreport">
                    <ul class="nav nav-sm flex-column">
                        {{-- <li class="nav-item">
                            <a href="{{ route('superadmin.ActivityHistory') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">Operator History
                            </a>
                        </li> --}}
                        <li class="nav-item">
                            <a href="{{ route('superadmin.country-wise-exports') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">Country Wise Exports
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.scope-issued-mis') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">Scope Issued
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.list-of-register-operator') }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">List of Registered
                                Operator
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.state-wise-area') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">State Wise Area
                                (Active)
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.total-farmer') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">State Wise Total Farmers (Active)
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.list-of-tc-issue') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">List of TC Issued
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="{{ route('superadmin.list-of-ptctc-issue') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">List of PTC Issued
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.view-operator-osp') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">View Operator OSP
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.scope-pending-for-renewal') }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">Scopes Pending for
                                Renewal
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.unit-pending-for-license-renewal') }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">Processing Unit
                                Pending for License Renewal
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.view-products-details') }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">View Products
                                Details(Trader/Processor)

                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('superadmin.scope-nearby-for-discontinuation') }}" class="nav-link"
                                role="button" aria-expanded="false" aria-controls="sidebarSignUp">Scope Nearby for
                                Discontinuation
                            </a>
                        </li>

                    </ul>
                </div>
            </li>

            <!-- <li class="nav-item">
    <a class="nav-link menu-link" href="#masterid" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarAuth">
        <i class="ri-team-fill"></i> <span data-key="t-authentication">Master</span>
    </a>
    <div class="collapse menu-dropdown" id="masterid">
        <ul class="nav nav-sm flex-column">
            <li class="nav-item">
                <a href="{{ route('superadmin.master.statelist') }}" class="nav-link" role="button" aria-expanded="false" aria-controls="sidebarSignUp">state
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('superadmin.master.districtlist') }}" class="nav-link" role="button" aria-expanded="false" aria-controls="sidebarSignUp">district
                </a>
            </li>


        </ul>
    </div>
</li> -->
            <li class="nav-item active">
                <a class="nav-link menu-link" href="#helpdesk" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarAuth">
                    <i class="ri-account-circle-line"></i> <span data-key="t-authentication">Help
                        Desk</span>
                </a>
                <div class="collapse menu-dropdown" id="helpdesk">
                    <ul class="nav nav-sm flex-column">
                        <li class="nav-item">
                            <a href="{{ route('superadmin.search') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">Help Desk Tickets
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="{{ route('superadmin.ticketlist') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">Help Desk Tickets List
                            </a>
                        </li>



                    </ul>
                </div>
            </li>
            {{-- @can('permission_access')
                <li @if (Request::routeIs('superadmin.usermanagement.*')) class="nav-item active" @else class="nav-item" @endif>
                    <a class="nav-link menu-link" href="#sidebarAuth2" data-bs-toggle="collapse" role="button"
                        aria-expanded="false" aria-controls="sidebarAuth">
                        <i class="ri-account-circle-line"></i> <span data-key="t-authentication">Application
                            Management</span>
                    </a>
                    <div class="collapse menu-dropdown" id="sidebarAuth2">
                        <ul class="nav nav-sm flex-column">
                            @can('permission_access')
                                <li class="nav-item">
                                    <a href="{{ route('superadmin.usermanagement.permission') }}" class="nav-link"
                                        role="button" aria-expanded="false"> Permission
                                    </a>
                                </li>
                            @endcan
                            @can('role_access')
                                <li class="nav-item">
                                    <a href="{{ route('superadmin.usermanagement.roles') }}" class="nav-link" role="button"
                                        aria-expanded="false" aria-controls="sidebarSignUp"> Roles
                                    </a>
                                </li>
                            @endcan

                        </ul>
                    </div>
                </li>
            @endcan --}}


            

        </ul>
    </div>

</div>
<!-- Sidebar end -->

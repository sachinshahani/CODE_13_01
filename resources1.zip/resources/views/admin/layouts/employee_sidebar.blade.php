@php
use App\Models\Employee\ModuleMapping;
$userId = Auth::id();

// Fetch module mappings for the user
$moduleMappings = ModuleMapping::with('module', 'subModule')
    ->where('emp_id', $userId)
    ->get();

// Organize data by module
$modules = [];
foreach ($moduleMappings as $mapping) {
    // Initialize the module if not already set
    if (!isset($modules[$mapping->module_id])) {
        $modules[$mapping->module_id] = [
            'module_name' => $mapping->module->module_name,
            'submodules' => [],
        ];
    }

    // Add the submodule under the corresponding module
    if ($mapping->subModule) {
        $modules[$mapping->module_id]['submodules'][] = $mapping->subModule;
    }
}
@endphp

<div id="scrollbar">
    <div class="container-fluid">
        <ul class="navbar-nav" id="navbar-nav">
            @if (!empty($modules)) <!-- Check if $modules is not empty -->
                @foreach ($modules as $moduleId => $module)
                    <li class="nav-item">
                        <a class="nav-link menu-link" href="#sidebar{{ $moduleId }}" data-bs-toggle="collapse"
                            role="button" aria-expanded="false" aria-controls="sidebar{{ $moduleId }}">
                            <i class="ri-account-circle-line"></i> <span>{{ $module['module_name'] }}</span>
                        </a>
                        <div class="collapse menu-dropdown" id="sidebar{{ $moduleId }}">
                        <ul class="nav nav-sm flex-column">
                            @if (!empty($module['submodules']))
                                @foreach ($module['submodules'] as $subModule)
                                    <li class="nav-item">
                                        <a href="{{ $subModule->module_path ? url($subModule->module_path) : '#' }}" 
                                        role="button" 
                                        class="nav-link" 
                                        aria-expanded="false">
                                        {{ $subModule->sub_module_name ?? 'Unnamed Submodule' }}
                                        </a>
                                    </li>
                                @endforeach
                            @else
                                <li class="nav-item">
                                    <span class="nav-link">No submodules available</span>
                                </li>
                            @endif
                        </ul>
                        </div>
                    </li>
                @endforeach
            @else
                <li class="nav-item"> <!-- Display a message if no modules are available -->
                    <span class="nav-link">No Roles available</span>
                </li>
            @endif
        </ul>
    </div>
</div>

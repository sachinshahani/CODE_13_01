            <!-- Sidebar start -->
            <div id="scrollbar">
                <div class="container-fluid">

                    <div id="two-column-menu">
                    </div>
                    <ul class="navbar-nav" id="navbar-nav">
                        <!-- <li class="menu-title"><span data-key="t-menu">Menu</span></li> -->
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="{{ route('superadmin.dashboard') }}" role="button">
                                <i class="ri-dashboard-2-line"></i> <span data-key="t-dashboards">Home</span>
                            </a>
                        </li> <!-- end Dashboard Menu -->

                        <li @if (Request::routeIs('superadmin.usermanagement.*')) class="nav-item active" @else class="nav-item" @endif>
                            <a class="nav-link menu-link" href="#sidebarAuth" data-bs-toggle="collapse" role="button"
                                aria-expanded="false" aria-controls="sidebarAuth">
                                <i class="ri-account-circle-line"></i> <span
                                    data-key="t-authentication">Registration</span>
                            </a>
                            <div class="collapse menu-dropdown" id="sidebarAuth">
                                <ul class="nav nav-sm flex-column">

                                    @if (auth()->user()->status == 0)
                                        <li class="nav-item">
                                            <a href="{{ route('superadmin.processorUseredit', [auth()->user()->id]) }}"
                                                class="nav-link" role="button" aria-expanded="false"
                                                aria-controls="sidebarSignUp"> My Application </a>
                                        </li>
                                    @else
                                        <li class="nav-item">
                                            <a href="{{ route('superadmin.usermanagement.deptUser.proview', auth()->user()->id) }}"
                                                class="nav-link" role="button" aria-expanded="false"
                                                aria-controls="sidebarSignUp"> My Application
                                            </a>
                                        </li>
                                    @endif
                                    <!-- <li class="nav-item">
                                        <a href="javascript:void(0)" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">View Processing Unit(s)</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="javascript:void(0)" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">Add / View OSP</a>
                                    </li> -->

                                </ul>
                            </div>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#scopcer" data-bs-toggle="collapse" role="button"
                                aria-expanded="false" aria-controls="sidebarFarmer">
                                <i class="ri-user-follow-line"></i> <span data-key="t-authentication">Scope Certificate</span>
                            </a>
                            <div class="collapse menu-dropdown" id="scopcer">
                                <ul class="nav nav-sm flex-column">
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.applyScopeCertificate') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">Apply for scope certificate
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.icsuser.scopeRenewal') }}" class="nav-link"
                                            role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Application for Renewal
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        {{-- <li class="nav-item">
                            <a class="nav-link menu-link" href="#scope" data-bs-toggle="collapse" role="button"
                                aria-expanded="false" aria-controls="sidebarFarmer">
                                <i class="ri-team-fill"></i> <span data-key="t-authentication">Scope
                                    Certification</span>
                            </a>
                            <div class="collapse menu-dropdown" id="scope">
                                <ul class="nav nav-sm flex-column">
                                    <li class="nav-item">
                                        <a href="javascript:void(0)" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">Application for
                                            Amendment
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="javascript:void(0)" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">Application for
                                            Renewal
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="javascript:void(0)" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">Apply for NOP
                                            Certificate
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="javascript:void(0)" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">List of Application
                                            for NOP Certificate
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </li> --}}
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#batch" data-bs-toggle="collapse" role="button"
                                aria-expanded="false" aria-controls="sidebarFarmer">
                                <i class="ri-team-fill"></i> <span data-key="t-authentication">Batch Creation</span>
                            </a>
                            <div class="collapse menu-dropdown" id="batch">
                                <ul class="nav nav-sm flex-column">
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.batchCreation', auth()->user()->id) }}"
                                            class="nav-link" role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Batch Creation
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.History') }}" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">Batch History
                                        </a>
                                    </li>

                                </ul>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#noc" data-bs-toggle="collapse" role="button"
                                aria-expanded="false" aria-controls="sidebarFarmer">
                                <i class="ri-team-fill"></i> <span data-key="t-authentication">NOC Application</span>
                            </a>
                            <div class="collapse menu-dropdown" id="noc">
                                <ul class="nav nav-sm flex-column">
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.applyNOC') }}" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">Apply NOC
                                        </a>
                                    </li>
                                    <!-- <li class="nav-item">
                                        <a href="javascript:void(0)" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">List(s) of NOC Status Wise
                                        </a>
                                    </li> -->

                                </ul>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#internalStock" data-bs-toggle="collapse"
                                role="button" aria-expanded="false" aria-controls="sidebarFarmer">
                                <i class="ri-team-fill"></i> <span data-key="t-authentication"> Internal Stock
                                    Transfer</span>
                            </a>
                            <div class="collapse menu-dropdown" id="internalStock">
                                <ul class="nav nav-sm flex-column">
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.applyforinternalstocktransfer') }}"
                                            class="nav-link" role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Apply for Internal Stock Transfer
                                        </a>
                                    </li>

                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.pendingforinternalstocktransfer') }}"
                                            class="nav-link" role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Pending Applications for Internal Stock
                                            Transfer

                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.listforinternalstocktransfer') }}"
                                            class="nav-link" role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">List of Internal Stock Transfer Applications

                                        </a>
                                    </li>

                                </ul>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#Purchase" data-bs-toggle="collapse" role="button"
                                aria-expanded="false" aria-controls="sidebarPurchase">
                                <i class="ri-team-fill"></i> <span data-key="t-authentication">Purchase Details</span>
                            </a>
                            <div class="collapse menu-dropdown" id="Purchase">
                                <ul class="nav nav-sm flex-column">
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.purchaseRequestList') }}" class="nav-link"
                                            role="button" aria-expanded="false"
                                            aria-controls="sidebarPurchase">Purchase Requests
                                        </a>
                                    </li>

                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.approvedPurchaseList') }}" class="nav-link"
                                            role="button" aria-expanded="false"
                                            aria-controls="sidebarPurchase">Approved Purchase
                                        </a>
                                    </li>

                                </ul>
                            </div>

                        </li>
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#transcerti" data-bs-toggle="collapse"
                                role="button" aria-expanded="false" aria-controls="sidebarFarmer">
                                <i class="ri-team-fill"></i> <span data-key="t-authentication">Transaction
                                    Certificate</span>
                            </a>
                            <div class="collapse menu-dropdown" id="transcerti">
                                <ul class="nav nav-sm flex-column">
                                    <li class="nav-item">
                                        <!--<a href="{{ route('superadmin.domestictc') }}" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">Apply for Domestic TC
                                        </a>-->
                                        <a href="{{ route('superadmin.P-trader.applyForDomesticTCT') }}"
                                            class="nav-link" role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Apply for Domestic TC
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.P-listOfTransCertificate') }}" class="nav-link"
                                            role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Pending TC
                                            Applications
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.applyForProvisionalTC') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">Apply
                                            for Provisional TC
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.P-listOfTransCertificate') }}" class="nav-link"
                                            role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Pending PTC Applications
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="javascript:void(0)" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">Apply for Export
                                            Applications
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="javascript:void(0)" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">List of TCs Procured
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.P.cb.tsIssueList') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">List
                                            of TC issued
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#impingre" data-bs-toggle="collapse" role="button"
                                aria-expanded="false" aria-controls="sidebarFarmer">
                                <i class="ri-team-fill"></i> <span data-key="t-authentication">Imported
                                    Ingredient</span>
                            </a>
                            <div class="collapse menu-dropdown" id="impingre">
                                <ul class="nav nav-sm flex-column">

                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.importIngredientList') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">Apply
                                            for Imported Ingredient(s) Approval
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="javascript:void(0)" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">Status of Imported
                                            Ingredient(s) Application
                                        </a>
                                    </li>

                                </ul>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#stock" data-bs-toggle="collapse" role="button"
                                aria-expanded="false" aria-controls="sidebarFarmer">
                                <i class="ri-team-fill"></i> <span data-key="t-authentication">Stock Inventory</span>
                            </a>
                            <div class="collapse menu-dropdown" id="stock">
                                <ul class="nav nav-sm flex-column">

                                    <li class="nav-item">
                                        <a href="{{route('superadmin.processorTcStock')}}" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">TC Stock
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{route('superadmin.processorbatchStock')}}" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">Batch Stock
                                        </a>
                                    </li>

                                </ul>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#rcac" data-bs-toggle="collapse" role="button"
                                aria-expanded="false" aria-controls="sidebarFarmer">
                                <i class="ri-team-fill"></i> <span data-key="t-authentication">Organic RCAC</span>
                            </a>
                            <div class="collapse menu-dropdown" id="rcac">
                                <ul class="nav nav-sm flex-column">

                                    <li class="nav-item">
                                        <a href="{{route('index')}}" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">LC/Contract Detail Entry
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{route('ApllyForRCACProcessor', auth()->user()->id)}}" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">Apply for RCAC
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{route('PendingPaymentProcessor')}}" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">Apply for RCAC(Pending for Payment)
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{route('ViewStatusProcessor')}}" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">View Status of RCAC
                                        </a>
                                    </li>
                                    {{-- <li class="nav-item">
                                        <a href="" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">Payment History
                                        </a>
                                    </li> --}}

                                </ul>
                            </div>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#User" data-bs-toggle="collapse" role="button"
                                aria-expanded="false" aria-controls="sidebarAuth">
                                <i class="ri-account-circle-line"></i> <span data-key="t-authentication">User
                                    Manual</span>
                            </a>
                            <div class="collapse menu-dropdown" id="User">
                                <ul class="nav nav-sm flex-column">

                                    <li class="nav-item">
                                        <a href="javascript:void(0)" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">NOC Application
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="javascript:void(0)" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">Apply for PTC & Export
                                            TC
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="javascript:void(0)" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp"> Batch Creation and TC
                                            Application
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="javascript:void(0)" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp"> Application for Scope
                                            Certificate- Processor
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="javascript:void(0)" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp"> Amendment Process-
                                            Processor
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="javascript:void(0)" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp"> Internal Stock
                                            Transfer- Processor
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="javascript:void(0)" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp"> High Risk Batch
                                            Process for Processor
                                        </a>
                                    </li>

                                </ul>
                            </div>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#mis" data-bs-toggle="collapse" role="button"
                                aria-expanded="false" aria-controls="sidebarAuth">
                                <i class="ri-account-circle-line"></i> <span data-key="t-authentication">Mis Report
                                </span>
                            </a>
                            <div class="collapse menu-dropdown" id="mis">
                                <ul class="nav nav-sm flex-column">
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.country-wise-exports') }}" class="nav-link"
                                            role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Country Wise Exports
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.scope-issued-mis') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">Scope
                                            Issued
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.list-of-register-operator') }}"
                                            class="nav-link" role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">List of Registered
                                            Operator
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.state-wise-area') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">State
                                            Wise Area
                                            (Active)
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.total-farmer') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">Total
                                            Farmers (Active)
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.list-of-tc-issue') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">List
                                            of TC Issued
                                        </a>
                                    </li>

                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.list-of-ptctc-issue') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">List
                                            of PTC Issued
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.view-operator-osp') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">View
                                            Operator OSP
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.scope-pending-for-renewal') }}"
                                            class="nav-link" role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Scopes Pending for
                                            Renewal
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.unit-pending-for-license-renewal') }}"
                                            class="nav-link" role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Processing Unit
                                            Pending for License Renewal
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.view-products-details') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">View
                                            Products
                                            Details(Trader/Processor)

                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.scope-nearby-for-discontinuation') }}"
                                            class="nav-link" role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Scope Nearby for
                                            Discontinuation
                                        </a>
                                    </li>

                                </ul>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#helpdesk" data-bs-toggle="collapse" role="button"
                                aria-expanded="false" aria-controls="sidebarAuth">
                                <i class="ri-account-circle-line"></i> <span data-key="t-authentication">Help
                                    Desk</span>
                            </a>
                            <div class="collapse menu-dropdown" id="helpdesk">
                                <ul class="nav nav-sm flex-column">
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.help_desk') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">Help
                                            Desk Tickets
                                        </a>
                                    </li>

                                    <li class="nav-item">
                                        <a href="{{route('ticketIP')}}" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">Tickets List
                                        </a>
                                    </li>

                                </ul>
                            </div>
                        </li>


                        <!-- <li class="nav-item">
                            <a class="nav-link menu-link" href="#" role="button">
                                <i class="ri-contacts-book-2-fill"></i> <span data-key="t-dashboards">Contact
                                    Us</span>
                            </a>
                        </li> -->
                        <li class="nav-item">
                            <a class="nav-link menu-link"
                                href="https://apeda.gov.in/apedawebsite/HACCP/labs_Organic_09_January_2023.pdf"
                                target="_blank" role="button">
                                <i class="ri-file-list-fill"></i> <span data-key="t-dashboards">List of Authorized
                                    Lab</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link menu-link"
                                href="https://apeda.gov.in/apedawebsite/organic/ORGANIC_CONTENTS/National_Programme_for_Organic_Production.htm"
                                target="_blank" role="button">
                                <i class="ri-government-fill"></i> <span data-key="t-dashboards">Revised NPOP
                                    Standards 2025</span>
                            </a>
                        </li>



                    </ul>
                </div>

            </div>
            <!-- Sidebar end -->

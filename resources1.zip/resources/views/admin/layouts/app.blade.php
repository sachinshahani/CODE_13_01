<!doctype html>
<html lang="en" data-layout="vertical" data-topbar="light" data-sidebar="dark" data-sidebar-size="lg"
    data-sidebar-image="none">

<head>
    <meta charset="utf-8" />
    <title>Welcome To TracNet</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="" name="TraceNet is an internet based electronic service offered by APEDA to the stakeholders for facilitating process certification for export of organic products from India which comply with the NPOP or NOP standards. " />
    <meta content="RGV" name="author" />
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <script src="{{ asset('public/backend/js/jquery-3.5.1.min.js') }}"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>


    <link href="{{ asset('public/assets/css/jquery.dataTables.min.css') }}" rel="stylesheet" />
    <link href="{{ asset('public/assets/css/dataTables.bootstrap4.min.css') }}" rel="stylesheet" />
    <link href="{{ asset('public/assets/css/buttons.dataTables.min.css') }}" rel="stylesheet" />
    <link href="{{ asset('public/assets/css/select.dataTables.min.css') }}" rel="stylesheet" />
    <!-- <link href="{{ asset('public/assets/libs/dropzone/dropzone.css') }}" rel="stylesheet" /> -->
    <link rel="stylesheet" href="https://unpkg.com/dropzone@5/dist/min/dropzone.min.css" type="text/css" />
    <link href="{{ asset('public/assets/libs/filepond/filepond.min.css') }}" rel="stylesheet" />
    <link href="{{ asset('public/assets/libs/filepond-plugin-image-preview/filepond-plugin-image-preview.min.css') }}"
        rel="stylesheet" />

    <!-- App favicon -->
    <link href="{{ asset('public/assets/images/favicon.png') }}" rel="stylesheet" />
    <!-- Layout config Js -->
    <link href="{{ asset('public/assets/js/layout.js') }}" rel="stylesheet" />
    <!-- Bootstrap Css -->
    <link href="{{ asset('public/assets/css/bootstrap.min.css') }}" rel="stylesheet" />
    <!-- Icons Css -->
    <link href="{{ asset('public/assets/css/icons.min.css') }}" rel="stylesheet" />
    <!-- App Css-->
    <link href="{{ asset('public/assets/css/app.min.css') }}" rel="stylesheet" />
    <!-- custom Css-->
    <link href="{{ asset('public/assets/css/custom.min.css') }}" rel="stylesheet" />

    <!-- custom Css-->
    <link href="{{ asset('public/assets/libs/@simonwep/pickr/themes/classic.min.css') }}" rel="stylesheet" />
    <!-- custom Css-->
    <link href="{{ asset('public/assets/libs/@simonwep/pickr/themes/monolith.min.css') }}" rel="stylesheet" />
    <!-- custom Css-->
    <link href="{{ asset('public/assets/libs/@simonwep/pickr/themes/nano.min.css') }}" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

    <style>
        .wrapper {
            max-width: 1240px;
            margin: 0 auto;
        }

        .white-bg {
            background-color: white;
            /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
            border-bottom: 5px solid #ff9800;
            margin-bottom: 15px;
        }

        .auth-one-bg .slide .carousel-indicators {
            bottom: 25px;
        }

        .auth-page-wrapper .auth-page-content {
            padding-bottom: 0px !important;
        }

        .auth-page-content .card {
            margin-bottom: 0rem;
        }

        .data-tabs .wrapper .nav-tabs button {
            font-size: 17px;
            color: black;
        }

        .data-tabs .wrapper .nav-tabs .active {
            background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
            */ color: white;
            background: orange;
            border-radius: 0px;
        }

        .carousel-caption.d-none.d-md-block {
            background-color: #000000bf;
            left: 0;
            width: 100%;
            bottom: 0;
        }

        .carousel-indicators {
            display: none;
        }

        .custom-banner-caption {
            color: white !important;
        }

        .announcement-heading {
            font-size: 1.2em;
            font-weight: 600;
        }

        .data-tabs .tab-pane ul li {
            font-size: 1em;
            padding: 5px 0;

        }

        .main-logo {
            padding: 10px;
        }

        .data-tabs .nav-item .nav-link {
            background-image: none;
        }

        /* .right-sec{
    box-shadow: 5px 10px 18px #888888;
} */
        .navbar-brand-box {
            background: #fff;
        }

        .btn-danger {
            /* background-color: #40895a;
    border: 1px solid #40895a; */
        }

        [data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
            color: white !important;
        }

        .header-buttons .btn-primary {
            margin-right: 10px;
            padding: 6px 15px;
            font-weight: 600;
            background-color: #207005;
            border: none;
            box-shadow: 0px 2px 7px #888888;
        }

        .header-buttons .btn-secondary {
            margin-right: 10px;
            padding: 6px 15px;
            font-weight: 600;
            background-color: #72a055;
            border: none;
            box-shadow: 0px 2px 7px #888888;
        }


        .right-sec {
            border-left: 5px solid #ede7e7;
        }

        .tabdiv {
            background: white;
            padding: 20px;
            margin-top: 10px;
            border: 10px solid #dfdbd5;
        }

        .nav-tabs {
            border-bottom: 0px;
        }

        div#myTabContent {
            border: 1px solid #cccccc;
        }

        .frontfooter footer {
            padding: 20px calc(1.5rem / 2);
            position: static;
            color: #000;
            height: 60px;
            background-color: #f9f9f9;
            margin-top: 30px;
            border-top: 1px solid #e1dfdf;
        }

        span.logo-sm img {
            width: 69px;
        }

        .seperatesec {
            margin-top: 20px;
        }

        .simplebar-content li.nav-item:hover {
            background: #4caf50;
        }

        .sectitle {
            font-size: 14px;
        }

        .required {
            color: red;
        }

        .customtextarea {
            height: 120px;
        }

        ul.boxsection {
            margin: 0;
            padding: 0;
        }

        ul.boxsection li {
            list-style-type: none;
            padding: 7px 0;
            border-bottom: 1px solid #efeded;
        }

        .boxcard .col:nth-child(1) {
            background: #effcfb;
        }

        .boxcard .col:nth-child(2) {
            background: #fdfdfd;
        }

        .boxcard .col:nth-child(3) {
            background: #effcfb;
        }

        .boxcard .col:nth-child(4) {
            background: #fdfdfd;
        }

        .boxcard .col:nth-child(5) {
            background: #effcfb;
        }

        /* --registration-form css  */
        .custom-tab-content {
            padding-top: 0 !important;
            padding-bottom: 0px !important;
        }

        .custom-tab-nav {
            background: white;

        }

        .custom-tab-nav .nav-link {
            border-radius: 0 !important;
            border-bottom: 1px solid #e9ebec;
            border-right: 1px solid #e9ebec;
            font-size: 14px;
            padding: 10px;
        }

        .custom-tab-nav .nav-link.active,
        .custom-tab-nav .show>.nav-link {
            color: rgb(255, 255, 255) !important;
            background-color: #2c8c6d;
            border-bottom: #2c8c6d !important;
            /* border-bottom: #207005 !important; */
            position: relative;
        }

        .custom-tab-nav .nav-link:hover,
        .custom-tab-nav .nav-link:focus {
            border-bottom: 1px solid #207005;
            border-radius: 0;
            font-size: 14px;
            transition: background-color 0.20s linear;
        }

        .custom-tab-nav .nav-link.active:after {
            content: "";
            position: absolute;
            bottom: -16px;
            left: 50%;
            border: 8px solid transparent;
            border-top-color: #2c8c6d;
            z-index: 999;
        }

        .reg-form-btns {
            margin-bottom: 15px;
        }

        .reg-form-btns .btn-secondary {
            color: #fff;
            background-color: #405189;
            border-color: #405189;
        }

        .btn-soft-success:active,
        .btn-soft-success:focus,
        .btn-soft-success:hover {
            border: none;
        }

        .custom-tab-nav ul {
            padding: 0px;
            margin: 0px;
        }

        .custom-tab-nav ul li {
            padding: 0px;
            margin: 0px;
            display: inline-block;
            list-style: none;
        }

        .whole-page-overlay {
            left: 0;
            right: 0;
            top: 0;
            bottom: 0;
            position: fixed;
            background: rgba(0, 0, 0, 0.6);
            width: 100%;
            height: 100% !important;
            z-index: 9999;
            display: none;
        }

        .whole-page-overlay .center-loader {
            top: 50%;
            left: 52%;
            position: absolute;
            color: white;
        }

        .table-bordered>:not(caption)>*>* {
            border-width: 1px 1px;
            border-color: #ddd;
        }
    </style>

    <script>
        $(document).ready(function() {
            $(document).ajaxStart(function() {
                // $('#whole_page_loader').show();
            });
            $(document).ajaxError(function() {
                //$('#whole_page_loader').hide();
                //alert("Something went wrong!");
            });
            $(document).ajaxSuccess(function() {
                //$('#whole_page_loader').hide();
            });
        });
    </script>
    @stack('style')
</head>

<body>
    <div class="whole-page-overlay" id="whole_page_loader">
        <img class="center-loader" style="height:100px;" src="{{ asset('public/cgwbspin.gif') }}" />
    </div>
    <!-- Begin page -->
    <div id="layout-wrapper">
        {{-- @if (auth()->user()->ref_operator_type_id == 1)
        @include('admin.layouts.cbheader')
        @else
        @include('admin.layouts.header')
        @endif --}}
        @if (auth()->user()->ref_operator_type_id == 1)
            @include('admin.layouts.cbheader')
        @elseif(auth()->user()->ref_operator_type_id == 101)
            @include('admin.layouts.SAheader')
        @else
            @include('admin.layouts.header')
        @endif



        <!-- ========== App Menu ========== -->
        <div class="app-menu navbar-menu">
            <!-- LOGO -->
            <div class="navbar-brand-box">
                <!-- Dark Logo-->
                {{-- @if (auth()->user()->ref_operator_type_id == 102)
                    <a href="{{ route('superadmin.dashboard') }}" class="logo logo-dark">
                    @else
                        <a href="{{ route('superadmin.dashboard') }}" class="logo logo-light">
                @endif
                <span class="logo-sm">
                <img src="{{ asset('public/assets/images/APEDA_logo.png') }}" alt="" style="width: 60px;">
                </span>
                <span class="logo-lg">
                 <img src="{{ asset('public/assets/images/APEDA_logo.png') }}assets/images/logo-without-txt.png"
                        alt="" height="17">
                </span>
                </a> --}}
                <!-- Light Logo-->
                @if (auth()->user()->ref_operator_type_id == 102)
                <a href="{{ route('superadmin.lab.dashboard') }}" class="logo logo-light">
                @elseif (auth()->user()->ref_operator_type_id == 101)
                    <a href="{{ route('superadmin.admin.dashboard') }}" class="logo logo-light">
                @else
                    <a href="{{ route('superadmin.dashboard') }}" class="logo logo-light">
                @endif
            
                <span class="logo-sm">
                    <img src="{{ asset('public/assets/images/APEDA_logo.png') }}" alt="" style="width: 60px;">
                </span>
                <span class="logo-lg ">
                    <img src="{{ asset('public/assets/images/APEDA_logo.png') }}" alt="" style="width: 92px;">

                    <!-- <div class="d-flex">
                        <span class="logo-text">APEDA</span>
                        <SPAN class="logo-text">एपीडा</SPAN>
                    </div> -->
                </span>
                </a>

                <button type="button" class="btn btn-sm p-0 fs-20 header-item float-end btn-vertical-sm-hover"
                    id="vertical-hover">
                    <i class="ri-record-circle-line"></i>
                </button>
            </div>
            {{-- {{ auth()->user()->ref_operator_type_id }} --}}
            <!-- sidebar -->


            @switch(auth()->user()->ref_operator_type_id)
                @case(2)
                    @include('admin.layouts.ics_sidebar')
                @break

                @case(3)
                    @include('admin.layouts.ip_sidebar')
                @break

                @case(4)
                    @include('admin.layouts.wh_sidebar')
                @break

                @case(5)
                    @include('admin.layouts.trader_sidebar')
                @break

                @case(6)
                    @include('admin.layouts.processor_sidebar')
                @break

                @case(101)
                    @include('admin.layouts.super_admin_sidebar')
                @break

                @case(102)
                    @include('admin.layouts.lab_admin_sidebar')
                @break
                @case(9)
                    @include('admin.layouts.employee_sidebar')

                @default
                    @include('admin.layouts.sidebar')
            @endswitch







            <div class="sidebar-background"></div>
        </div>
        <!-- Left Sidebar End -->
        <!-- Vertical Overlay-->
        <div class="vertical-overlay"></div>

        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">

            <div class="page-content">
                <div class="container-fluid">



                    @yield('content')
                </div>
                <!-- container-fluid -->
            </div>
            <!-- End Page-content -->

            <!-- footer  -->
            @include('admin.layouts.footer')
        </div>
        <!-- end main content-->

    </div>
    <!-- END layout-wrapper -->



    <!--start back-to-top-->
    <button onclick="topFunction()" class="btn btn-danger btn-icon" id="back-to-top">
        <i class="ri-arrow-up-line"></i>
    </button>
    <!--end back-to-top-->





    <script src="{{ asset('public/assets/libs/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
    <!-- JAVASCRIPT -->
    <script src="{{ asset('public/assets/libs/simplebar/simplebar.min.js') }}"></script>
    <script src="{{ asset('public/assets/libs/node-waves/waves.min.js') }}"></script>
    <script src="{{ asset('public/assets/libs/feather-icons/feather.min.js') }}"></script>
    <script src="{{ asset('public/assets/js/pages/plugins/lord-icon-2.1.0.js') }}"></script>
    <script src="{{ asset('public/assets/js/plugins.js') }}"></script>
    <script src="{{ asset('public/assets/libs/apexcharts/apexcharts.min.js') }}"></script>
    <script src="{{ asset('public/assets/js/pages/dashboard-crm.init.js') }}"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    


    <!-- <script src="{{ asset('public/assets/libs/dropzone/dropzone-min.js') }}"></script> -->
    <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
    <script src="https://unpkg.com/dropzone@5/dist/min/dropzone.min.js"></script>
    <script src="{{ asset('public/assets/libs/filepond/filepond.min.js') }}"></script>
    <script src="{{ asset('public/assets/libs/filepond-plugin-image-preview/filepond-plugin-image-preview.min.js') }}">
    </script>
    <script
        src="{{ asset('public/assets/libs/filepond-plugin-file-validate-size/filepond-plugin-file-validate-size.min.js') }}">
    </script>
    <script
        src="{{ asset('public/assets/libs/filepond-plugin-image-exif-orientation/filepond-plugin-image-exif-orientation.min.js') }}">
    </script>
    <script src="{{ asset('public/assets/libs/filepond-plugin-file-encode/filepond-plugin-file-encode.min.js') }}">
    </script>


    <!-- <script src="{{ asset('public/assets/js/pages/form-file-upload.init.js') }}"></script> -->

    <script src="{{ asset('/public/backend/datatable/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('/public/backend/datatable/js/dataTables.bootstrap.min.js') }}"></script>
    <script src="{{ asset('/public/backend/datatable/js/dataTables.fixedHeader.min.js') }}"></script>
    {{-- <script src="{{ asset('/public/backend/datatable/js/dataTables.responsive.min.js') }}"></script> --}}
    <script src="{{ asset('/public/backend/datatable/js/responsive.bootstrap.min.js') }}"></script>
    <script src="{{ asset('public/backend/datatable/js/dataTables.buttons.min.js') }}"></script>
    <script src="{{ asset('public/backend/datatable/js/buttons.flash.min.js') }}"></script>
    <script src="{{ asset('/public/backend/datatable/js/jszip.min.js') }}"></script>
    <script src="{{ asset('/public/backend/datatable/js/pdfmake.min.js') }}"></script>
    <script src="{{ asset('/public/backend/datatable/js/vfs_fonts.js') }}"></script>
    <script src="{{ asset('/public/backend/datatable/js/buttons.html5.min.js') }}"></script>
    <script src="{{ asset('/public/backend/datatable/js/buttons.print.min.js') }}"></script>

    <script src="{{ asset('public/assets/libs/@simonwep/pickr/pickr.min.js') }}"></script>

    <script src="{{ asset('public/assets/js/pages/form-pickers.init.js') }}"></script>

    <script src="{{ asset('public/assets/js/app.js') }}"></script>
    <script src="{{ asset('public/backend/js/sweetalert.js') }}"></script>



    <script src="{{ asset('public/backend/js/custom.js') }}"></script>



    <script>
        function get_district(state_id, selected_val = '') {
            // var zone_id = $(that).val();
            $.ajax({
                url: "{{ route('admin.master.ajax.statelist') }}",
                method: "POST",
                dataType: 'json',
                data: {
                    'state_id': state_id,
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(result) {
                    $('#state_id').html('');
                    var option = '';
                    var selected = '';
                    option += '<option value="">Select State</option>';
                    $.each(result.data, function(i, item) {
                        if (!empty(selected_val) && selected_val == item.id) {
                            selected = 'selected';
                        }
                        option += "<option " + selected + " value='" + item.id + "'>" + item
                            .state_name + "</option>";

                    });

                    $('#state_id').html(option);
                }
            });
        }

        function selectBlock(state_id) {
            var district_code = $('#district').val();
            $.ajax({
                url: '{{ route('admin.master.ajax.getBlock') }}',
                type: 'post',
                data: {
                    'state_code': state_id,
                    'district_code': district_code
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    $('#block').html(response);
                }
            });
        }

        function selectVillage(state_id) {
            var district_code = $('#district').val();
            $.ajax({
                url: '{{ route('admin.master.ajax.getVillage') }}',
                type: 'post',
                data: {
                    'state_code': state_id,
                    'district_code': district_code
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    $('#village').html(response);
                }
            });
        }

        $(function() {
            var current = location.pathname;
            $('.navbar-nav li').each(function() {
                var $this = $(this);
                // if the current path is like this link, make it active
                if ($this.find('a').attr('href').indexOf(current) !== -1) {
                    $this.parent('ul').parent('.menu-dropdown').addClass('show');
                    $this.find('a').addClass('active');
                }
            });
        });
    </script>
    @include('sweetalert::alert')

    @stack('script')

</body>


</html>

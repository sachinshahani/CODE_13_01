            <!-- Sidebar start -->
            <div id="scrollbar">
                <div class="container-fluid">

                    <div id="two-column-menu">
                    </div>
                    <ul class="navbar-nav" id="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="{{ route('superadmin.lab.dashboard') }}" role="button">
                                <i class="ri-dashboard-2-line"></i> <span data-key="t-dashboards">Home</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#sampling" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarFarmer">
                                <i class="ri-team-fill"></i> <span data-key="t-authentication">Sampling</span>
                            </a>
                            <div class="collapse menu-dropdown" id="sampling">
                                <ul class="nav nav-sm flex-column">
                                    <li class="nav-item">
                                        <a href="{{route('superadmin.lab.sampling_collection_lot_list')}}" class="nav-link" role="button" aria-expanded="false" aria-controls="sidebarSignUp1">Sampling Collection LOT/TC
                                        </a>
                                    </li>

                                    <li class="nav-item">
                                        <a href="{{route('superadmin.lab.sampling_receiplat_list')}}" class="nav-link" role="button" aria-expanded="false" aria-controls="sidebarSignUp1">Sampling Receipt Laboratory
                                        </a>
                                    </li>

                                </ul>

                            </div>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#residue" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarFarmer">
                                <i class="ri-team-fill"></i> <span data-key="t-authentication">Residue Analysis</span>
                            </a>
                            <div class="collapse menu-dropdown" id="residue">
                                <ul class="nav nav-sm flex-column">
                                    <li class="nav-item">
                                        <a href="{{route('superadmin.lab.test_rest_entry')}}" class="nav-link" role="button" aria-expanded="false" aria-controls="sidebarSignUp">Test Rest Entry(By Chemist)
                                        </a>
                                    </li>

                                    <li class="nav-item">
                                        <a href="{{route('superadmin.lab.genrate_test_report')}}" class="nav-link" role="button" aria-expanded="false" aria-controls="sidebarSignUp">Generated Test Report
                                        </a>
                                    </li>

                                </ul>

                            </div>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#mis" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarFarmer">
                                <i class="ri-team-fill"></i> <span data-key="t-authentication">MIS Reports</span>
                            </a>
                            <div class="collapse menu-dropdown" id="mis">
                                <ul class="nav nav-sm flex-column">
                                    <li class="nav-item">
                                        <a href="{{route('superadmin.lab.test_report_summary')}}" class="nav-link" role="button" aria-expanded="false" aria-controls="sidebarSignUp">Test Report summary
                                        </a>
                                    </li>

                                    

                                </ul>

                            </div>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#master" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarFarmer">
                                <i class="ri-team-fill"></i> <span data-key="t-authentication">Master Data</span>
                            </a>
                            <div class="collapse menu-dropdown" id="master">
                                <ul class="nav nav-sm flex-column">
                                    <li class="nav-item">
                                        <a href="{{route('superadmin.lab.manage_test_para')}}" class="nav-link" role="button" aria-expanded="false" aria-controls="sidebarSignUp">Manage Test Paramenter
                                        </a>
                                    </li>

                                    <li class="nav-item">
                                        <a href="{{route('superadmin.lab.manage_user_list')}}" class="nav-link" role="button" aria-expanded="false" aria-controls="sidebarSignUp">Manage User
                                        </a>
                                    </li>

                                    

                                </ul>

                            </div>
                        </li>
                        

                    </ul>

                </div>
                        </li> 

                     

                     



                    </ul>
                </div>

            </div>
            <!-- Sidebar end -->

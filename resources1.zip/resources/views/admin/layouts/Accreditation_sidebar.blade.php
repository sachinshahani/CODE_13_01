            <!-- Sidebar start -->
                <div id="two-column-menu">
                </div>
                <ul class="navbar-nav" id="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link menu-link" href="{{ route('superadmin.admin.Cbdashboard') }}" role="button">
                            <i class="ri-dashboard-2-line"></i> <span data-key="t-dashboards">Home</span>
                        </a>
                        <a class="nav-link menu-link" href="{{ route('superadmin.processApplication') }}" role="button">
                            <i class="ri-dashboard-2-line"></i> <span data-key="t-dashboards">Process
                                Application List</span>
                        </a>
                        <a class="nav-link menu-link" href="{{ route('superadmin.processApplicationForm') }}" role="button">
                            <i class="ri-dashboard-2-line"></i> <span data-key="t-dashboards">New
                                Registration</span>
                        </a>
                        <a class="nav-link menu-link" href="{{ route('superadmin.accrRenewal') }}" role="button">
                            <i class="ri-dashboard-2-line"></i> <span data-key="t-dashboards">Renewal</span>
                        </a>
                        <a class="nav-link menu-link" href="{{ route('superadmin.accrAmendment') }}" role="button">
                            <i class="ri-dashboard-2-line"></i> <span data-key="t-dashboards">Amendment</span>
                        </a>
                        <a class="nav-link menu-link" href="{{ route('superadmin.accrCertificateList') }}" role="button">
                            <i class="ri-dashboard-2-line"></i> <span data-key="t-dashboards">List of
                                issued Certificates</span>
                        </a>
                        <a class="nav-link menu-link" href="{{ route('superadmin.accrAnnualReport') }}" role="button">
                            <i class="ri-dashboard-2-line"></i> <span data-key="t-dashboards">CB Annual Report</span>
                        </a>

                    </li>

                </ul>



                <!-- Sidebar end -->

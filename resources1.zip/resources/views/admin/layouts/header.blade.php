<header id="page-topbar">
    <div class="layout-width">
        <div class="navbar-header">
            <div class="d-flex">
                <!-- LOGO -->
                <div class="navbar-brand-box horizontal-logo">
                    <a href="{{ route('superadmin.dashboard') }}" class="logo logo-dark">
                        <span class="logo-sm">
                            <img src="{{ asset('public/assets/images/logo-without-txt.png') }}" alt=""
                                height="22">
                        </span>
                        <span class="logo-lg">
                            <img src="{{ asset('public/assets/images/logo-without-txt.png') }}" alt="">
                        </span>
                    </a>
                </div>
                <button type="button" class="btn btn-sm px-3 fs-16 header-item vertical-menu-btn topnav-hamburger"
                    id="topnav-hamburger-icon">
                    <span class="hamburger-icon">
                        <span></span>
                        <span></span>
                        <span></span>
                    </span>
                </button>

                <!-- App Search-->
                <form class="app-search d-none d-md-block">
                    <div class="position-relative m-2">


                    </div>
                    <div class="dropdown-menu dropdown-menu-lg" id="search-dropdown">
                        <div data-simplebar style="max-height: 320px;">
                            <!-- item-->
                            <div class="dropdown-header">
                                <h6 class="text-overflow text-muted mb-0 text-uppercase">Recent Searches</h6>
                            </div>

                            <div class="dropdown-item bg-transparent text-wrap">
                                <a href="{{ route('superadmin.dashboard') }}"
                                    class="btn btn-soft-secondary btn-sm btn-rounded">how to setup <i
                                        class="mdi mdi-magnify ms-1"></i></a>
                                <a href="{{ route('superadmin.dashboard') }}"
                                    class="btn btn-soft-secondary btn-sm btn-rounded">buttons <i
                                        class="mdi mdi-magnify ms-1"></i></a>
                            </div>
                            <!-- item-->
                            <div class="dropdown-header mt-2">
                                <h6 class="text-overflow text-muted mb-1 text-uppercase">Pages</h6>
                            </div>

                            <!-- item-->
                            <a href="javascript:void(0);" class="dropdown-item notify-item">
                                <i class="ri-bubble-chart-line align-middle fs-18 text-muted me-2"></i>
                                <span>Analytics Dashboard</span>
                            </a>

                            <!-- item-->
                            <a href="javascript:void(0);" class="dropdown-item notify-item">
                                <i class="ri-lifebuoy-line align-middle fs-18 text-muted me-2"></i>
                                <span>Help Center</span>
                            </a>

                            <!-- item-->
                            <a href="javascript:void(0);" class="dropdown-item notify-item">
                                <i class="ri-user-settings-line align-middle fs-18 text-muted me-2"></i>
                                <span>My account settings</span>
                            </a>

                            <!-- item-->
                            <div class="dropdown-header mt-2">
                                <h6 class="text-overflow text-muted mb-2 text-uppercase">Members</h6>
                            </div>

                            <div class="notification-list">
                                <!-- item -->
                                <a href="javascript:void(0);" class="dropdown-item notify-item py-2">
                                    <div class="d-flex">
                                        <img src="{{ asset('public/assets/images/users/avatar-2.jpg') }}"
                                            class="me-3 rounded-circle avatar-xs" alt="user-pic">
                                        <div class="flex-1">
                                            <h6 class="m-0">Angela Bernier</h6>
                                            <span class="fs-11 mb-0 text-muted">Manager</span>
                                        </div>
                                    </div>
                                </a>
                                <!-- item -->
                                <a href="javascript:void(0);" class="dropdown-item notify-item py-2">
                                    <div class="d-flex">
                                        <img src="{{ asset('public/assets/images/users/avatar-3.jpg') }}"
                                            class="me-3 rounded-circle avatar-xs" alt="user-pic">
                                        <div class="flex-1">
                                            <h6 class="m-0">David Grasso</h6>
                                            <span class="fs-11 mb-0 text-muted">Web Designer</span>
                                        </div>
                                    </div>
                                </a>
                                <!-- item -->
                                <a href="javascript:void(0);" class="dropdown-item notify-item py-2">
                                    <div class="d-flex">
                                        <img src="{{ asset('public/assets/images/users/avatar-5.jpg') }}"
                                            class="me-3 rounded-circle avatar-xs" alt="user-pic">
                                        <div class="flex-1">
                                            <h6 class="m-0">Mike Bunch</h6>
                                            <span class="fs-11 mb-0 text-muted">React Developer</span>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <div class="text-center pt-3 pb-1">
                            <a href="#" class="btn btn-primary btn-sm">View All Results <i
                                    class="ri-arrow-right-line ms-1"></i></a>
                        </div>
                    </div>
                </form>
            </div>
            <div class="d-flex align-items-center">
                <div class="dropdown d-md-none topbar-head-dropdown header-item">
                    <button type="button" class="btn btn-icon btn-topbar btn-ghost-secondary rounded-circle"
                        id="page-header-search-dropdown" data-bs-toggle="dropdown" aria-haspopup="true"
                        aria-expanded="false">
                        <i class="bx bx-search fs-22"></i>
                    </button>
                    <div class="dropdown-menu dropdown-menu-lg dropdown-menu-end p-0"
                        aria-labelledby="page-header-search-dropdown">
                        <form class="p-3">
                            <div class="form-group m-0">
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search ..."
                                        aria-label="Recipient's username">
                                    <button class="btn btn-primary" type="submit"><i
                                            class="mdi mdi-magnify"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>


                <img src="{{ asset('public/assets/images/new_NPOP_logo.png') }}" alt="" width="70">
                <!-- <img src="{{ asset('public/assets/images/logoimageapeda.jpg') }}" alt="" width="70"> -->

                <div class="ms-1 header-item d-none d-sm-flex">
                    <button type="button" class="btn btn-icon btn-topbar btn-ghost-secondary rounded-circle"
                        data-toggle="fullscreen">
                        <i class='bx bx-fullscreen fs-22'></i>
                    </button>
                </div>

                <div class="ms-1 header-item d-none d-sm-flex">
                    <button type="button"
                        class="btn btn-icon btn-topbar btn-ghost-secondary rounded-circle light-dark-mode">
                        <i class='bx bx-moon fs-22'></i>
                    </button>
                </div>

                <div class="dropdown topbar-head-dropdown ms-1 header-item">
                    {{-- alert message --}}
                    <div class="dropdown topbar-head-dropdown ms-1 header-item">
                        <button type="button" class="btn btn-icon btn-topbar btn-ghost-secondary rounded-circle"
                            id="page-header-notifications-dropdown" data-bs-toggle="dropdown" aria-haspopup="true"
                            aria-expanded="false">
                            <i class='bx bx-bell fs-22'></i>
                            <span id="alert-count"
                                class="position-absolute topbar-badge fs-10 translate-middle badge rounded-pill bg-danger">
                                <span class="visually-hidden">unread messages</span>
                            </span>
                        </button>
                        <div class="dropdown-menu dropdown-menu-end"
                            aria-labelledby="page-header-notifications-dropdown">
                            <div id="alert-messages" class="scroll-notification"></div>
                        </div>
                    </div>

                    <div class="dropdown ms-sm-3 header-item topbar-user">
                        <button type="button" class="btn" id="page-header-user-dropdown"
                            data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="d-flex align-items-center">
                                <img class="rounded-circle header-profile-user"
                                    src="{{ asset('public/assets/images/users/avatar-1.jpg') }}" alt="Header Avatar">
                                <span class="text-start ms-xl-2">
                                    @if (auth()->user()->ref_operator_type_id == 102)
                                        <span class="d-none d-xl-inline-block ms-1 fw-medium user-name-text">
                                            {{ getLabNameById(Auth::guard('misadmin')->user()->lab_id) }}</span>
                                    @else
                                        <span class="d-none d-xl-inline-block ms-1 fw-medium user-name-text">
                                            {{ Auth::guard('misadmin')->user()->first_name }}
                                            {{ Auth::guard('misadmin')->user()->last_name }}</span>
                                    @endif

                                    @if (isset(auth()->user()->ref_operator_type_id) && auth()->user()->ref_operator_type_id == 1)
                                        <span class="d-none d-xl-block ms-1 fs-12 text-muted user-name-sub-text">Crop
                                            Production, Handling & Processing </span>
                                    @elseif(isset(auth()->user()->ref_operator_type_id) && auth()->user()->ref_operator_type_id == 2)
                                        <span class="d-none d-xl-block ms-1 fs-12 text-muted user-name-sub-text">Grower
                                            Group</span>
                                    @elseif(isset(auth()->user()->ref_operator_type_id) && auth()->user()->ref_operator_type_id == 3)
                                        <span
                                            class="d-none d-xl-block ms-1 fs-12 text-muted user-name-sub-text">Individual
                                            Producer</span>
                                    @elseif(isset(auth()->user()->ref_operator_type_id) && auth()->user()->ref_operator_type_id == 4)
                                        <span class="d-none d-xl-block ms-1 fs-12 text-muted user-name-sub-text">Wild
                                            Harvester</span>
                                    @elseif(isset(auth()->user()->ref_operator_type_id) && auth()->user()->ref_operator_type_id == 5)
                                        <span
                                            class="d-none d-xl-block ms-1 fs-12 text-muted user-name-sub-text">Trader</span>
                                    @elseif(isset(auth()->user()->ref_operator_type_id) && auth()->user()->ref_operator_type_id == 6)
                                        <span
                                            class="d-none d-xl-block ms-1 fs-12 text-muted user-name-sub-text">Processor</span>
                                    @elseif(isset(auth()->user()->ref_operator_type_id) && auth()->user()->ref_operator_type_id == 102)
                                        <!-- <span class="d-none d-xl-block ms-1 fs-12 text-muted user-name-sub-text">Lab</span> -->
                                    @endif
                                </span>
                            </span>
                        </button>
                        <div class="dropdown-menu dropdown-menu-end">
                            <!-- item-->
                            <h6 class="dropdown-header"> {{ Auth::guard('misadmin')->user()->first_name }}!</h6>
                            <a class="dropdown-item" href="{{ route('superadmin.profile') }}"><i
                                    class="mdi mdi-account-circle text-muted fs-16 align-middle me-1"></i> <span
                                    class="align-middle">Profile</span></a>
                            <a class="dropdown-item" href="{{ route('superadmin.changePassword') }}"><i
                                    class="mdi mdi-cog-outline text-muted fs-16 align-middle me-1"></i> <span
                                    class="align-middle">Change Password</span></a>

                            <a class="dropdown-item" href="{{ route('superadmin.logout') }}"><i
                                    class="mdi mdi-logout text-muted fs-16 align-middle me-1"></i> <span
                                    class="align-middle" data-key="t-logout">Logout</span></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script>
            $(document).ready(function() {
                fetchAlerts();

                function fetchAlerts() {
                    $.ajax({
                        url: '{{ route('alerts.get') }}',
                        method: 'GET',
                        success: function(data) {
                            $('#alert-count').text(data.alertCount);
                            let alertMessages = '';
                            data.alerts.forEach(alert => {
                                let selfQtyConsumed = alert.self_qty_consumed;
                                let remark = alert.remark;
                                let refOrganicStatusId = alert.ref_organic_status_master_id;
                                let createdAt = alert.created_at;

                                let dataAttributeString = `data-self-qty="${encodeURIComponent(selfQtyConsumed)}" 
                                       data-remark="${encodeURIComponent(remark)}" 
                                       data-org-status="${encodeURIComponent(refOrganicStatusId)}" 
                                       data-created-at="${encodeURIComponent(createdAt)}"`;

                                alertMessages += `<div class="dropdown-items d-flex align-items-center" data-alert-id="${alert.id}">
                                <div class="flex-grow-1">
                                    <h6 class="m-0" ${dataAttributeString}>CB Has Self Consumed  ${selfQtyConsumed}</h6>
                                </div>
                             </div>`;
                            });
                            $('#alert-messages').html(alertMessages);

                            $('.dropdown-items').click(function() {
                                let selfQtyConsumed = $(this).find('h6').data('self-qty');
                                let remark = $(this).find('h6').data('remark');
                                let refOrganicStatusId = $(this).find('h6').data('org-status');
                                let createdAt = $(this).find('h6').data('created-at');

                                openAlertDetail(selfQtyConsumed, remark, refOrganicStatusId,
                                    createdAt);
                            });
                        }
                    });


                    function openAlertDetail(selfQtyConsumed, remark, refOrganicStatusId, createdAt) {
                        let encodedRemark = encodeURIComponent(remark);
                        let encodedRefOrganicStatusId = encodeURIComponent(refOrganicStatusId);
                        let encodedCreatedAt = encodeURIComponent(createdAt);

                        let url =
                            '{{ route('alerts.show', [
                                'self_qty_consumed' => ':selfQtyConsumed',
                                'remark' => ':encodedRemark',
                                'org_status' => ':encodedRefOrganicStatusId',
                                'created_at' => ':encodedCreatedAt',
                            ]) }}';

                        url = url.replace(':selfQtyConsumed', selfQtyConsumed);
                        url = url.replace(':encodedRemark', encodedRemark);
                        url = url.replace(':encodedRefOrganicStatusId', encodedRefOrganicStatusId);
                        url = url.replace(':encodedCreatedAt', encodedCreatedAt);

                        window.open(url);
                    }


                }

                $(document).on('click', '#page-header-notifications-dropdown', function() {
                    fetchAlerts();
                });

                $(document).on('click', '.dropdown-items', function() {
                    const alertId = $(this).data('alert-id');
                    $.ajax({
                        url: '{{ route('superadmin.markAlertAsRead', ':id') }}'.replace(':id',
                            alertId),
                        method: 'POST',
                        data: {
                            _token: $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function(response) {
                            if (response.success) {
                                fetchAlerts();
                            }
                        }
                    });
                });
            });
        </script>
</header>

@php
    $currentUrl = \Route::currentRouteName();
    $module_name = !empty($module_name) ? $module_name : '';
    $module_title = !empty($module_title) ? $module_title : '';
@endphp

<!-- Sidebar start -->
<div id="scrollbar">
    <div class="container-fluid">

        <div id="two-column-menu">
        </div>
        <ul class="navbar-nav" id="navbar-nav">
            <!-- <li class="menu-title"><span data-key="t-menu">Menu</span></li> -->
            <li class="nav-item">
                <a class="nav-link menu-link" href="{{ route('superadmin.admin.dashboard') }}" role="button">
                    <i class="ri-dashboard-2-line"></i> <span data-key="t-dashboards">Dashboard</span>
                </a>
            </li>


            {{-- <li class="nav-item">
                <a class="nav-link menu-link" href="#batch" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarFarmer">
                    <i class="ri-team-fill"></i> <span data-key="t-authentication">Registration of Lab</span>
                </a>
                <div class="collapse menu-dropdown" id="batch">
                    <ul class="nav nav-sm flex-column">
                        <!-- <li class="nav-item">
                            <a href="{{route('superadmin.addLab')}}" class="nav-link" role="button" aria-expanded="false" aria-controls="sidebarSignUp">Add Lab
                            </a>
                        </li> -->

                        <li class="nav-item">
                            <a href="{{route('superadmin.registeredLab')}}" class="nav-link" role="button" aria-expanded="false" aria-controls="sidebarSignUp">Registered Lab
                            </a>
                        </li>

                    </ul>

                </div>
        </li> --}}

            <li class="nav-item">
                <a class="nav-link menu-link" href="#batch1" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarFarmer">
                    <i class="ri-team-fill"></i> <span data-key="t-authentication">Registration</span>
                </a>
                <div class="collapse menu-dropdown" id="batch1">
                    <ul class="nav nav-sm flex-column">


                        {{-- <li class="nav-item">
                            <a href="{{ route('superadmin.CbRegister') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">All CB List
                            </a>
                        </li> --}}
                        <!-- <li class="nav-item">
                            <a href="{{ route('superadmin.lab_register_list') }}" class="nav-link" role="button" aria-expanded="false" aria-controls="sidebarSignUp">Add LAB
                            </a>
                        </li> -->
                        <li class="nav-item">
                            <a href="{{ route('superadmin.registeredLab') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">Add Lab
                            </a>
                        </li>





                    </ul>

                </div>
            </li>



            <li class="nav-item">
                <a class="nav-link menu-link" href="#batch11" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarFarmer">
                    <i class="ri-team-fill"></i> <span data-key="t-authentication">CB List</span>
                </a>
                <div class="collapse menu-dropdown" id="batch11">
                    <ul class="nav nav-sm flex-column">

                        <li class="nav-item">
                            <a href="{{ route('superadmin.activecb') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">All CB List
                            </a>
                        </li>

                    </ul>

                </div>
            </li>


            





            
            {{-- <li class="nav-item">
                <a class="nav-link menu-link" href="#batch1" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarFarmer">
                    <i class="ri-team-fill"></i> <span data-key="t-authentication">CB List</span>
               
                </a>

                <!-- <a class="nav-link menu-link" href="{{ route('superadmin.registeredLab') }}" class="nav-link" role="button"
                        aria-expanded="false" aria-controls="sidebarSignUp">CB List
                    </a> -->
               
            </li> --}}




            <li class="nav-item">
                <a class="nav-link menu-link" href="#batch2" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarFarmer">
                    <i class="ri-team-fill"></i> <span data-key="t-authentication">Help Desk </span>
                </a>
                <div class="collapse menu-dropdown" id="batch2">
                    <ul class="nav nav-sm flex-column">


                        <li class="nav-item">
                            <a href="{{ route('superadmin.helpdesktickets') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp">Help Desk Tickets
                            </a>
                        </li>



                    </ul>

                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link menu-link" href="#batch5" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarFarmer">
                    <i class="ri-team-fill"></i> <span data-key="t-authentication">MIS Report</span>
                </a>
                <div class="collapse menu-dropdown" id="batch5">
                    <ul class="nav nav-sm flex-column">

                        
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#Export" data-bs-toggle="collapse" role="button"
                                aria-expanded="false" aria-controls="sidebarFarmer">
                                <i class="ri-team-fill"></i> <span data-key="t-authentication">Export Report</span>
                            </a>
                            <div class="collapse menu-dropdown" id="Export">
                                <ul class="nav nav-sm flex-column">

                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.StateWiseIncludingExporter') }}"
                                            class="nav-link" role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">State Wise including exporter, product and
                                            country details
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.StateWiseOnly') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">State
                                            Wise only
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.CountryWiseExportIncluding') }}"
                                            class="nav-link" role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Country wise export Including exporter
                                            details, product and category
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.CountryWiseOnly') }}" class="nav-link"
                                            role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Country Wise Only
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.ProductWise') }}" class="nav-link"
                                            role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Product wise
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.CategoryWise') }}" class="nav-link"
                                            role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Category wise
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.CBWise') }}" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">CB wise
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.MonthlyComparativeStatement') }}"
                                            class="nav-link" role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Monthly Comparative Statement
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.CategoryWiseComparative') }}" class="nav-link"
                                            role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Category Wise Comparative Statement (Based on
                                            TC/PTC)
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.CountryWiseComparative') }}" class="nav-link"
                                            role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Country Wise Comparative Statement (Based on
                                            TC/PTC)
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.ProductWiseComparative') }}" class="nav-link"
                                            role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Product Wise Comparative Statement (Based on
                                            TC/PTC)
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.OrganicTrade') }}" class="nav-link"
                                            role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Organic Trade
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.ListIssuedTC') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp"> list
                                            of issued TCs
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.ProductionAndExport') }}" class="nav-link"
                                            role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Production and Export(2,3 and 5 year)
                                        </a>
                                    </li>


                                </ul>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#usermanual" data-bs-toggle="collapse" role="button"
                                aria-expanded="false" aria-controls="sidebarFarmer">
                                <i class="ri-team-fill"></i> <span data-key="t-authentication">CB & Operator
                                    Report</span>
                            </a>
                            <div class="collapse menu-dropdown" id="usermanual">
                                <ul class="nav nav-sm flex-column">

                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.ActivCb') }}" class="nav-link" role="button"
                                            aria-expanded="false" aria-controls="sidebarSignUp">State wise Active
                                            Certification Bodies
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.ListofOperator') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">Report On
                                            List of Operator(s)
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.ListofMandatator') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">Report
                                            On List of Mandatator(s)
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.FarmerCount') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">Report
                                            on Farmer Count
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.WildCollectorsCount') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">Report
                                            on Wild Collectors Count
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.ScopeCertificateNPOP') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">Report
                                            on Scope Certificate NPOP
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.AmmendmentAnnexure') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">View
                                            Ammendment Annexure
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.Detailsofoperators') }}" class="nav-link"
                                            role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Details of ID-Proof of operators
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.OperatorNOCDetails') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">Report
                                            On Operator NOC Details
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.ApprovedInputs') }}" class="nav-link"
                                            role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Details of Approved Inputs
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.Suspended') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">Report
                                            on Suspended/Terminated operator
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.TCLotBatchSelfConsumption') }}"
                                            class="nav-link" role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Report On TC/Lot/Batch self consumption
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.CertificationBodyActivity') }}"
                                            class="nav-link" role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Certification Body Activity Details
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.FarmValueAddedProduct') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">On
                                            Farm Value Added Product (Added by the CB)
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.ProductWiseClosingStock') }}" class="nav-link"
                                            role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Product wise closing stock
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.SplitFarm') }}" class="nav-link"
                                            role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Reports on Split Farm (s)
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.InspectorsOfCertificationBody') }}"
                                            class="nav-link" role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Report on Inspectors of Certification Body
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.ApprovedInputsManufacturer') }}"
                                            class="nav-link" role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Details of Approved Inputs (Manufacturer)
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.TracenetProductMaster') }}" class="nav-link"
                                            role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">TraceNet Product Master
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.DetailsOfOperatorsStock') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">Stock
                                            Inventory of Individual Producer/ Grower Group/Wild/Processor/Trader
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.AddingINTC') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">List
                                            of Operator While Adding INTC
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.INTCReport') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">INTC
                                            Report After Added
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.TraderWarehouseDetails') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">Trader
                                            Warehouse Details
                                        </a>
                                    </li>



                                </ul>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#Area" data-bs-toggle="collapse" role="button"
                                aria-expanded="false" aria-controls="sidebarFarmer">
                                <i class="ri-team-fill"></i> <span data-key="t-authentication">Farm Wild Area
                                    Report</span>
                            </a>
                            <div class="collapse menu-dropdown" id="Area">
                                <ul class="nav nav-sm flex-column">

                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.OrganicArea') }}" class="nav-link"
                                            role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Organic Area
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.WildOrganicArea') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">Wild
                                            Organic Area
                                        </a>
                                    </li>

                                </ul>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#Production" data-bs-toggle="collapse" role="button"
                                aria-expanded="false" aria-controls="sidebarFarmer">
                                <i class="ri-team-fill"></i> <span data-key="t-authentication">Farm Wild Production
                                    Report</span>
                            </a>
                            <div class="collapse menu-dropdown" id="Production">
                                <ul class="nav nav-sm flex-column">

                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.Production') }}" class="nav-link"
                                            role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Production
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.WildOrganicProduction') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">Wild
                                            Organic Production
                                        </a>
                                    </li>

                                </ul>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#Comparative" data-bs-toggle="collapse"
                                role="button" aria-expanded="false" aria-controls="sidebarFarmer">
                                <i class="ri-team-fill"></i> <span data-key="t-authentication">Comparative last 5
                                    years Report</span>
                            </a>
                            <div class="collapse menu-dropdown" id="Comparative">
                                <ul class="nav nav-sm flex-column">

                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.CategoryWise5Years') }}" class="nav-link"
                                            role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Category Wise for last 5 Years
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.CountryWise5Years') }}" class="nav-link"
                                            role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Country Wise for last 5 Years
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.ProductWise5Years') }}" class="nav-link"
                                            role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">Product Wise for last 5 Years
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.StateWise5Years') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">State
                                            Wise for last 5 Years
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.CBWise5Years') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">CB
                                            Wise for last 5 Years
                                        </a>
                                    </li>



                                </ul>
                            </div>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#External" data-bs-toggle="collapse" role="button"
                                aria-expanded="false" aria-controls="sidebarFarmer">
                                <i class="ri-team-fill"></i> <span data-key="t-authentication">External Inspection
                                    Report</span>
                            </a>
                            <div class="collapse menu-dropdown" id="External">
                                <ul class="nav nav-sm flex-column">

                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.ExternalInspction') }}" class="nav-link"
                                            role="button" aria-expanded="false"
                                            aria-controls="sidebarSignUp">External Inspction Details
                                        </a>
                                    </li>



                                </ul>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#Assessment" data-bs-toggle="collapse"
                                role="button" aria-expanded="false" aria-controls="sidebarFarmer">
                                <i class="ri-team-fill"></i> <span data-key="t-authentication">Risk Assessment
                                    Report</span>
                            </a>
                            <div class="collapse menu-dropdown" id="Assessment">
                                <ul class="nav nav-sm flex-column">

                                    <li class="nav-item">
                                        <a href="{{ route('superadmin.RiskAssessment') }}" class="nav-link"
                                            role="button" aria-expanded="false" aria-controls="sidebarSignUp">Risk
                                            Assessment of operators Details
                                        </a>
                                    </li>



                                </ul>
                            </div>
                        </li>



                    </ul>

                </div>
            </li>


             <li class="nav-item active" class="nav-item">
                <a class="nav-link menu-link" href="#sidebarAuth2" data-bs-toggle="collapse" role="button"
                    aria-expanded="false" aria-controls="sidebarAuth">
                    <i class="ri-account-circle-line"></i> <span data-key="t-authentication">Application
                        Management</span>
                </a>
                <div class="collapse menu-dropdown" id="sidebarAuth2">
                    <ul class="nav nav-sm flex-column">

                        <li class="nav-item">
                            <a href="{{ route('superadmin.usermanagement.permission') }}" class="nav-link"
                                role="button" aria-expanded="false"> Permission
                            </a>
                        </li>


                        <li class="nav-item">
                            <a href="{{ route('superadmin.usermanagement.roles') }}" class="nav-link" role="button"
                                aria-expanded="false" aria-controls="sidebarSignUp"> Roles
                            </a>
                        </li>

                        <li class="nav-item">
                                <a class="nav-link menu-link" href="{{ route('slider.index') }}" role="button">
                                    Slider</span>
                                </a>
                            </li>


                    </ul>
                </div>
            </li> 





            <!-- end Dashboard Menu -->


        </ul>
    </div>

</div>
<!-- Sidebar end -->

@extends('admin.layouts.app')
@section('title', 'User Profile')
@section('content')
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Profile</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item active">Profile</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<div class="container-fluid p-0">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header align-items-center d-flex">

                    @if (session('error'))
                    <div class="alert alert-danger">
                        {{ session('error') }}
                    </div>
                    @endif
                    @if (session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                    @endif
                    @if ($errors)
                    @foreach ($errors->all() as $error)
                    <div class="alert alert-danger">{{ $error }}</div>
                    @endforeach
                    @endif
                </div>

                {{-- @if (Auth::guard('misadmin')->user()->roles[0]->id == '1') --}}
                @if (Auth::guard('misadmin')->check() && isset(Auth::guard('misadmin')->user()->roles[0]) &&
                Auth::guard('misadmin')->user()->roles[0]->id == '1')
                <div class="row">
                    <div class="col-xl-3 ">
                        <div class="card">
                            <div class="card-body p-5 white-inner">
                                <div class="text-center ">
                                    <!-- {{ asset('public/cb_logo/' . ($data->cb_logo_path ?? '')) }} -->
                                    <div class="profile-user position-relative d-inline-block mx-auto  mb-4 ">
                                        @if(Auth::guard('misadmin')->user()->cb_logo_path)
                                        <img src="{{ asset('public/cb_logo/' . (Auth::guard('misadmin')->user()->cb_logo_path)) }}" 
                                            style="width: 100%; height: auto;" 
                                            alt="user-profile-image">
                                        @else
                                       
                                         <img src="{{ asset('public/cb_logo/cb_logo_dammy.png') }}" 
                                            style="width: 100%; height: auto;" 
                                            alt="user-profile-image">
                                        @endif

                                    

                                        <!-- <img src="{{ asset('public/assets/images/logo-without-txt.png') }}"
                                            class="rounded-circle avatar-xl img-thumbnail user-profile-image"
                                            alt="user-profile-image"> -->

                                            

                                        <div class="avatar-xs p-0 rounded-circle profile-photo-edit">

                                            <label for="profile-img-file-input" class="profile-photo-edit  avatar-xs">
                                                <!-- <span class="avatar-title rounded-circle bg-light text-body ">
                                                    <i class="ri-camera-fill profile_photo_edit"></i>
                                                </span> -->
                                            </label>
                                        </div>
                                    </div>
                                    <h5 class="fs-16 mb-1"></h5>
                                    <p class="text-muted mb-0"></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-9">
                        <div class="card">
                            <div class="card-header">
                                <ul class="nav nav-tabs-custom rounded card-header-tabs border-bottom-0" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link active" data-bs-toggle="tab" href="#personalDetails"
                                            role="tab">
                                            <strong>CERTIFICATION BODY DETAILS</strong>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" data-bs-toggle="tab" href="#digitalSignature" role="tab">
                                            <strong>DIGITAL SIGNATURE KYC DETAILS</strong>
                                            @php
                                            $emStatus = Auth::guard('misadmin')->user()->emStatus;
                                            echo $emStatus == '1' 
                                                ? '<span class="badge bg-success">KYC Active</span>' 
                                                : ($emStatus == '2' 
                                                    ? '<span class="badge bg-danger">Reject KYC</span>' 
                                                    : ($emStatus == '3' 
                                                        ? '<span class="badge bg-warning">Verification Pending</span>' 
                                                        : ($emStatus == '4' 
                                                            ? '<span class="badge bg-info">Under Verification</span>' 
                                                            : '<span class="badge bg-secondary">InActive</span>'
                                                          )
                                                      )
                                                  );
                                        @endphp
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="card-body white-inner">
                                <div class="tab-content">
                                    <div class="tab-pane active" id="personalDetails" role="tabpanel">
                                        <form name="updateProfile" id="updateProfile" action="" method="POST">
                                            @csrf
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <div class="mb-3">
                                                        <label for="firstnameInput" class="form-label">Certification
                                                            Body Name</label>
                                                        <input type="text" class="form-control" id="firstnameInput"
                                                            value="{{ Auth::guard('misadmin')->user()->first_name }}"
                                                            disabled />
                                                    </div>
                                                </div>

                                                <div class="col-lg-6">
                                                    <div class="mb-3">
                                                        <label for="phonenumberInput" class="form-label">Accreditation
                                                            No.</label>
                                                        <input type="text" class="form-control" name="contact_number"
                                                            id="phonenumberInput"
                                                            value="{{ $data->accrediation_agency_no ?? '' }}"
                                                            disabled />
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="mb-3">
                                                        <label for="addressInput" class="form-label">Address</label>
                                                        <textarea class="form-control" id="addressInput"
                                                            disabled>{{ $data->cb_registered_office_address ?? '' }}</textarea>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="mb-3">
                                                        <label for="validityStartDate" class="form-label">Validity Start
                                                            Date</label>
                                                        <input type="text" class="form-control" name="contact_number"
                                                            id="validityStartDate"
                                                            value="{{ date('d-m-Y', strtotime($data->created_at ?? '')) }}"
                                                            disabled />
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="mb-3">
                                                        <label for="validityEndDate" class="form-label">Validity End
                                                            Date</label>
                                                        <input type="text" class="form-control" name="validity_end_date"
                                                            id="validityEndDate"
                                                            value="{{ \Carbon\Carbon::parse($data->created_at ?? '')->addYears(3)->subDay()->format('d-m-Y') }}"
                                                            disabled />
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="mb-3">
                                                        <label for="contactPersonName" class="form-label">Contact Person
                                                            Name</label>
                                                        <input type="text" class="form-control" name="contact_number"
                                                            id="contactPersonName"
                                                            value="{{ $data->contact_person_first_name ?? '' }}"
                                                            disabled />
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="mb-3">
                                                        <label for="mobileInput" class="form-label">Mobile No.</label>
                                                        <input type="text" class="form-control" name="contact_number"
                                                            id="mobileInput"
                                                            value="{{ $data->contact_person_mobile_number ?? '' }}"
                                                            disabled />
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="mb-3">
                                                        <label for="faxInput" class="form-label">Fax No.</label>
                                                        <input type="text" class="form-control" name="contact_number"
                                                            id="faxInput" value="{{ $data->fax ?? 'NOT AVAILABLE' }}"
                                                            disabled />
                                                    </div>
                                                </div>

                                                <div class="col-lg-6">
                                                    <div class="mb-3">
                                                        <label for="emailInput" class="form-label">Email Id</label>
                                                        <input type="email" class="form-control" id="emailInput"
                                                            value="{{ $data->cb_email_id ?? '' }}" disabled />
                                                    </div>
                                                </div>

                                                <div class="col-lg-6">
                                                    <div class="mb-3">
                                                        <label for="websiteInput" class="form-label">Website</label>
                                                        <input type="text" class="form-control" name="contact_number"
                                                            id="websiteInput" value="{{ $data->website_address ?? '' }}"
                                                            disabled />
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="tab-pane" id="digitalSignature" role="tabpanel">
                                        <div class="row mb-4">                                           
                                            <div class="col-md-4 mb-3">
                                                <label class="form-label" for="form3Example1">Select eSignType<span
                                                        class="required">*</span></label>
                                                <select name="eSignType" id="eSignType" class="form-select" {{ $emStatus == '1' ?  'disabled':''}}>
                                                    <option value="">--Select eSignType--</option>
                                                    <option value="V2" disabled>V2 (Aadhaar KYC)</option>
                                                    <option value="V3" {{ Auth::guard('misadmin')->user()->eSignType === 'V3' ? 'selected' : '' }} >V3 (PAN KYC)</option>
                                                </select>
                                            </div>
                                            <div class="col-md-4 mb-3">
                                                <label for="emUserId" class="form-label">emudhra User Id<span
                                                        class="required">*</span></label>
                                                <input type="text" class="form-control" id="emUserId" name="emUserId"
                                                    placeholder="Enter emudhra Register User Id" value="{{Auth::guard('misadmin')->user()->emUserId}}" {{ $emStatus == '1' ?  'disabled':''}}>
                                            </div>
                                            <div class="col-md-4">
                                                <label for="emUserName" class="form-label">User Full Name<span
                                                        class="required">*</span></label>
                                                <input type="text" class="form-control" id="emUserName"
                                                    name="emUserName" placeholder="Enter User Full Name" value="{{Auth::guard('misadmin')->user()->emName}}" {{ $emStatus == '1' ?  'disabled':''}}>
                                            </div>
                                            <div class="col-md-6">
                                                <button type="button" id="eSignKYCVerify" {{ $emStatus == '1' ?  'disabled':''}}
                                                    data-eSignUserId="{{Auth::guard('misadmin')->user()->id}}" data-eSignClient="1"
                                                    class="btn btn-primary">Update eSign KYC</button>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- @elseif ((Auth::guard('misadmin')->user()->roles[0]->id == '8')) --}}
                @elseif (Auth::guard('misadmin')->check() && isset(Auth::guard('misadmin')->user()->roles[0]) &&
                Auth::guard('misadmin')->user()->roles[0]->id == '9')

                <div class="row ">
                    <div class="col-xxl-3  ">
                        <div class="card mt-n5 ">
                            <div class="card-body p-5 white-inner">
                                <div class="text-center ">
                                    <div class="profile-user position-relative d-inline-block mx-auto  mb-4 ">
                                        <img src="{{ asset('public/assets/images/logo-without-txt.png') }}"
                                            class="rounded-circle avatar-xl img-thumbnail user-profile-image"
                                            alt="user-profile-image">

                                        <div class="avatar-xs p-0 rounded-circle profile-photo-edit">

                                            <label for="profile-img-file-input" class="profile-photo-edit  avatar-xs">
                                                <span class="avatar-title rounded-circle bg-light text-body ">
                                                    <i class="ri-camera-fill profile_photo_edit"></i>
                                                </span>
                                            </label>
                                        </div>
                                    </div>
                                    <h5 class="fs-16 mb-1"></h5>
                                    <p class="text-muted mb-0"></p>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="col-xxl-9">
                        <div class="card mt-xxl-n5">
                            <div class="card-header">
                                <ul class="nav nav-tabs-custom rounded card-header-tabs border-bottom-0" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link active" data-bs-toggle="tab" href="#personalDetails"
                                            role="tab">
                                            <i class="fas fa-home"></i> Employee Details
                                        </a>
                                    </li>


                                </ul>
                            </div>
                            <div class="card-body p-4  white-inner">
                                <div class="tab-content">
                                    <div class="tab-pane active" id="personalDetails" role="tabpanel">
                                        <form name="updateProfile" id="updateProfile" action="" method="POST">
                                            @csrf
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <div class="mb-3">
                                                        <label for="firstnameInput" class="form-label">CB
                                                            Name</label>
                                                        <input type="text" class="form-control" id="firstnameInput"
                                                            value="{{$cbname->first_name ?? ''}}" required readonly />

                                                    </div>
                                                </div>

                                                <div class="col-lg-6">
                                                    <div class="mb-3">
                                                        <label for="phonenumberInput" class="form-label">Employee
                                                            Name.</label>
                                                        <input type="text" class="form-control" name="contact_number"
                                                            id="phonenumberInput"
                                                            value="{{ $empdata->first_name ?? ''}}" required readonly />
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="mb-3">
                                                        <label for="phonenumberInput" class="form-label">Employee
                                                            Designation</label>
                                                        <input type="text" class="form-control" name="contact_number"
                                                            id="phonenumberInput"
                                                            value="{{ $empdata->designation ?? '' }}" required
                                                            readonly />
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="mb-3">
                                                        <label for="phonenumberInput" class="form-label">Employee
                                                            Code</label>
                                                        <input type="text" class="form-control" name="contact_number"
                                                            id="phonenumberInput"
                                                            value="{{ $empdata->employee_id ?? '' }}" required
                                                            readonly />
                                                    </div>
                                                </div>

                                            </div>

                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- @elseif ((Auth::guard('misadmin')->user()->roles[0]->id == '2')) --}}
                @elseif (Auth::guard('misadmin')->check() && isset(Auth::guard('misadmin')->user()->roles[0]) &&
                Auth::guard('misadmin')->user()->roles[0]->id == '2')

                <div class="card-body">
                    <div class="live-preview">
                        <form method="POST" action="{{ route('superadmin.changePasswordPost') }}" id="password_frm"
                            class="w-100" autocomplete="off">
                            {{ csrf_field() }}
                            <div class="row gy-6">


                                <!--end col-->
                                <div class="col-xxl-6 col-md-6">
                                    <div>
                                        <label for="placeholderInput" class="form-label">Grower Group Name</label>
                                        <input type="text" name="current_password" class="form-control"
                                            id="current_password" placeholder="First Name"
                                            value="{{Auth::guard('misadmin')->user()->first_name}}" readonly required>
                                    </div>
                                </div>
                                <!-- <div class="col-xxl-6 col-md-6">
                                        <div>
                                            <label for="placeholderInput" class="form-label">Middle Name</label>
                                            <input type="text" class="form-control" name="new_password" id="new_password"
                                                placeholder="Middle Name"
                                                value="{{Auth::guard('misadmin')->user()->middle_name}}" required>
                                        </div>
                                    </div> -->
                                <!-- <div class="col-xxl-6 col-md-6">
                                        <div>
                                            <label for="placeholderInput" class="form-label">Last Name</label>
                                            <input type="text" class="form-control" name="new_password_confirmation"
                                                id="new_password_confirmation" placeholder="Last Name"
                                                value="{{Auth::guard('misadmin')->user()->first_name}}" required>
                                        </div>
                                    </div> -->

                                <div class="col-xxl-6 col-md-6">
                                    <div>
                                        <label for="placeholderInput" class="form-label">Email ID</label>
                                        <input type="text" class="form-control" name="new_password_confirmation"
                                            id="new_password_confirmation"
                                            value="{{Auth::guard('misadmin')->user()->email}}" placeholder="Email ID"
                                            readonly required>
                                    </div>
                                </div>

                                <div class="col-xxl-6 col-md-6">
                                    <div>
                                        <label for="placeholderInput" class="form-label">Mobile Number</label>
                                        <input type="text" class="form-control" name="new_password_confirmation"
                                            id="new_password_confirmation" placeholder="Mobile Number"
                                            value="{{Auth::guard('misadmin')->user()->contact_person_mobile_number}}"
                                            readonly required>
                                    </div>
                                </div>

                                <div class="col-xxl-6 col-md-6">
                                    <div>
                                        <label for="placeholderInput" class="form-label">PAN Number.</label>
                                        <input type="text" class="form-control" name="new_password_confirmation"
                                            id="new_password_confirmation" placeholder="User Name"
                                            value="{{Auth::guard('misadmin')->user()->user_name}}" readonly required>
                                    </div>
                                </div>
                                <div class="col-xxl-6 col-md-6">
                                    <div>
                                        <label for="placeholderInput" class="form-label">Contact Person Name</label>
                                        <input type="text" class="form-control" name="new_password_confirmation"
                                            id="new_password_confirmation" placeholder="User Name"
                                            value="{{Auth::guard('misadmin')->user()->contact_person_first_name}}"
                                            readonly required>
                                    </div>
                                </div>
                                <div class="col-xxl-6 col-md-6">
                                    <div>
                                        <label for="placeholderInput" class="form-label">Contact Person Email</label>
                                        <input type="text" class="form-control" name="new_password_confirmation"
                                            id="new_password_confirmation" placeholder="User Name"
                                            value="{{Auth::guard('misadmin')->user()->contact_person_email}}" readonly
                                            required>
                                    </div>
                                </div>


                            </div>

                    </div>
                    <div class="d-none code-view">
                        <pre class="language-markup" style="height: 450px;"><code>
                            </div>
                        </div>
                        {{-- @elseif ((Auth::guard('misadmin')->user()->roles[0]->id == '3')) --}}
                @elseif (Auth::guard('misadmin')->check() && isset(Auth::guard('misadmin')->user()->roles[0]) && Auth::guard('misadmin')->user()->roles[0]->id == '3')

                    <div class="card-body">
                        <div class="live-preview">
                            <form method="POST" action="{{ route('superadmin.changePasswordPost') }}" id="password_frm" class="w-100" autocomplete="off">
                            {{ csrf_field() }}
                            <div class="row gy-6">


                                <!--end col-->
                                <div class="col-xxl-6 col-md-6">
                                    <div>
                                        <label for="placeholderInput" class="form-label">First Name</label>
                                        <input type="text" name="current_password" class="form-control" id="current_password" placeholder="First Name" value="{{Auth::guard('misadmin')->user()->first_name}}" required>
                                    </div>
                                </div>
                                <div class="col-xxl-6 col-md-6">
                                    <div>
                                        <label for="placeholderInput" class="form-label">Middle Name</label>
                                        <input type="text" class="form-control" name="new_password" id="new_password" placeholder="Middle Name" value="{{Auth::guard('misadmin')->user()->middle_name}}" required>
                                    </div>
                                </div>
                                <div class="col-xxl-6 col-md-6">
                                    <div>
                                        <label for="placeholderInput" class="form-label">Last Name</label>
                                        <input type="text" class="form-control" name="new_password_confirmation" id="new_password_confirmation" placeholder="Last Name" value="{{Auth::guard('misadmin')->user()->first_name}}" required>
                                    </div>
                                </div>

                                <div class="col-xxl-6 col-md-6">
                                    <div>
                                        <label for="placeholderInput" class="form-label">Email ID</label>
                                        <input type="text" class="form-control" name="new_password_confirmation" id="new_password_confirmation" value="{{Auth::guard('misadmin')->user()->email}}" placeholder="Email ID" required>
                                    </div>
                                </div>

                                <div class="col-xxl-6 col-md-6">
                                    <div>
                                        <label for="placeholderInput" class="form-label">Mobile Number</label>
                                        <input type="text" class="form-control" name="new_password_confirmation" id="new_password_confirmation" placeholder="Mobile Number" value="{{Auth::guard('misadmin')->user()->mobile_no}}" required>
                                    </div>
                                </div>

                                <div class="col-xxl-6 col-md-6">
                                    <div>
                                        <label for="placeholderInput" class="form-label">User Name</label>
                                        <input type="text" class="form-control" name="new_password_confirmation" id="new_password_confirmation" placeholder="User Name" value="{{Auth::guard('misadmin')->user()->user_name}}" required>
                                    </div>
                                </div>


                            </div>

                        </div>
                        <div class="d-none code-view">
                            <pre class="language-markup" style="height: 450px;"><code>
                        </div>
                    </div>
                    {{-- @elseif ((Auth::guard('misadmin')->user()->roles[0]->id == '4')) --}}
                @elseif (Auth::guard('misadmin')->check() && isset(Auth::guard('misadmin')->user()->roles[0]) && Auth::guard('misadmin')->user()->roles[0]->id == '4')

                    <div class="card-body">
                        <div class="live-preview">
                            <form method="POST" action="{{ route('superadmin.changePasswordPost') }}" id="password_frm" class="w-100" autocomplete="off">
                            {{ csrf_field() }}
                            <div class="row gy-6">


                                <!--end col-->
                                <div class="col-xxl-6 col-md-6">
                                    <div>
                                        <label for="placeholderInput" class="form-label">First Name</label>
                                        <input type="text" name="current_password" class="form-control" id="current_password" placeholder="First Name" value="{{Auth::guard('misadmin')->user()->first_name}}" required>
                                    </div>
                                </div>
                                <div class="col-xxl-6 col-md-6">
                                    <div>
                                        <label for="placeholderInput" class="form-label">Middle Name</label>
                                        <input type="text" class="form-control" name="new_password" id="new_password" placeholder="Middle Name" value="{{Auth::guard('misadmin')->user()->middle_name}}" required>
                                    </div>
                                </div>
                                <div class="col-xxl-6 col-md-6">
                                    <div>
                                        <label for="placeholderInput" class="form-label">Last Name</label>
                                        <input type="text" class="form-control" name="new_password_confirmation" id="new_password_confirmation" placeholder="Last Name" value="{{Auth::guard('misadmin')->user()->first_name}}" required>
                                    </div>
                                </div>

                                <div class="col-xxl-6 col-md-6">
                                    <div>
                                        <label for="placeholderInput" class="form-label">Email ID</label>
                                        <input type="text" class="form-control" name="new_password_confirmation" id="new_password_confirmation" value="{{Auth::guard('misadmin')->user()->email}}" placeholder="Email ID" required>
                                    </div>
                                </div>

                                <div class="col-xxl-6 col-md-6">
                                    <div>
                                        <label for="placeholderInput" class="form-label">Mobile Number</label>
                                        <input type="text" class="form-control" name="new_password_confirmation" id="new_password_confirmation" placeholder="Mobile Number" value="{{Auth::guard('misadmin')->user()->mobile_no}}" required>
                                    </div>
                                </div>

                                <div class="col-xxl-6 col-md-6">
                                    <div>
                                        <label for="placeholderInput" class="form-label">User Name</label>
                                        <input type="text" class="form-control" name="new_password_confirmation" id="new_password_confirmation" placeholder="User Name" value="{{Auth::guard('misadmin')->user()->user_name}}" required>
                                    </div>
                                </div>


                            </div>

                        </div>
                        <div class="d-none code-view">
                            <pre class="language-markup" style="height: 450px;"><code>
                        </div>
                    </div>
                    {{-- @elseif ((Auth::guard('misadmin')->user()->roles[0]->id == '5')) --}}
                @elseif (Auth::guard('misadmin')->check() && isset(Auth::guard('misadmin')->user()->roles[0]) && Auth::guard('misadmin')->user()->roles[0]->id == '5')

                                        <div class="card-body">
                                            <div class="live-preview">
                                                <form method="POST" action="{{ route('superadmin.changePasswordPost') }}" id="password_frm" class="w-100" autocomplete="off">
                                                {{ csrf_field() }}
                                                <div class="row gy-6">


                                                    <!--end col-->
                                                    <div class="col-xxl-6 col-md-6">
                                                        <div>
                                                            <label for="placeholderInput" class="form-label">First Name</label>
                                                            <input type="text" name="current_password" class="form-control" id="current_password" placeholder="First Name" value="{{Auth::guard('misadmin')->user()->first_name}}" required>
                                                        </div>
                                                    </div>
                                                    <div class="col-xxl-6 col-md-6">
                                                        <div>
                                                            <label for="placeholderInput" class="form-label">Middle Name</label>
                                                            <input type="text" class="form-control" name="new_password" id="new_password" placeholder="Middle Name" value="{{Auth::guard('misadmin')->user()->middle_name}}" required>
                                                        </div>
                                                    </div>
                                                    <div class="col-xxl-6 col-md-6">
                                                        <div>
                                                            <label for="placeholderInput" class="form-label">Last Name</label>
                                                            <input type="text" class="form-control" name="new_password_confirmation" id="new_password_confirmation" placeholder="Last Name" value="{{Auth::guard('misadmin')->user()->first_name}}" required>
                                                        </div>
                                                    </div>

                                                    <div class="col-xxl-6 col-md-6">
                                                        <div>
                                                            <label for="placeholderInput" class="form-label">Email ID</label>
                                                            <input type="text" class="form-control" name="new_password_confirmation" id="new_password_confirmation" value="{{Auth::guard('misadmin')->user()->email}}" placeholder="Email ID" required>
                                                        </div>
                                                    </div>

                                                    <div class="col-xxl-6 col-md-6">
                                                        <div>
                                                            <label for="placeholderInput" class="form-label">Mobile Number</label>
                                                            <input type="text" class="form-control" name="new_password_confirmation" id="new_password_confirmation" placeholder="Mobile Number" value="{{Auth::guard('misadmin')->user()->mobile_no}}" required>
                                                        </div>
                                                    </div>

                                                    <div class="col-xxl-6 col-md-6">
                                                        <div>
                                                            <label for="placeholderInput" class="form-label">User Name</label>
                                                            <input type="text" class="form-control" name="new_password_confirmation" id="new_password_confirmation" placeholder="User Name" value="{{Auth::guard('misadmin')->user()->user_name}}" required>
                                                        </div>
                                                    </div>


                                                </div>

                                            </div>
                                            <div class="d-none code-view">
                                                <pre class="language-markup" style="height: 450px;"><code>
                                            </div>
                                        </div>
                    {{-- 
                                        @elseif ((Auth::guard('misadmin')->user()->roles[0]->id == '6')) --}}
                @elseif (Auth::guard('misadmin')->check() && isset(Auth::guard('misadmin')->user()->roles[0]) && Auth::guard('misadmin')->user()->roles[0]->id == '6')

                    <div class="card-body">
                        <div class="live-preview">
                            <form method="POST" action="{{ route('superadmin.changePasswordPost') }}" id="password_frm" class="w-100" autocomplete="off">
                            {{ csrf_field() }}
                            <div class="row gy-6">


                                <!--end col-->
                                <div class="col-xxl-6 col-md-6">
                                    <div>
                                        <label for="placeholderInput" class="form-label">First Name</label>
                                        <input type="text" name="current_password" class="form-control" id="current_password" placeholder="First Name" value="{{Auth::guard('misadmin')->user()->first_name}}" required>
                                    </div>
                                </div>
                                <div class="col-xxl-6 col-md-6">
                                    <div>
                                        <label for="placeholderInput" class="form-label">Middle Name</label>
                                        <input type="text" class="form-control" name="new_password" id="new_password" placeholder="Middle Name" value="{{Auth::guard('misadmin')->user()->middle_name}}" required>
                                    </div>
                                </div>
                                <div class="col-xxl-6 col-md-6">
                                    <div>
                                        <label for="placeholderInput" class="form-label">Last Name</label>
                                        <input type="text" class="form-control" name="new_password_confirmation" id="new_password_confirmation" placeholder="Last Name" value="{{Auth::guard('misadmin')->user()->first_name}}" required>
                                    </div>
                                </div>

                                <div class="col-xxl-6 col-md-6">
                                    <div>
                                        <label for="placeholderInput" class="form-label">Email ID</label>
                                        <input type="text" class="form-control" name="new_password_confirmation" id="new_password_confirmation" value="{{Auth::guard('misadmin')->user()->email}}" placeholder="Email ID" required>
                                    </div>
                                </div>

                                <div class="col-xxl-6 col-md-6">
                                    <div>
                                        <label for="placeholderInput" class="form-label">Mobile Number</label>
                                        <input type="text" class="form-control" name="new_password_confirmation" id="new_password_confirmation" placeholder="Mobile Number" value="{{Auth::guard('misadmin')->user()->mobile_no}}" required>
                                    </div>
                                </div>

                                <div class="col-xxl-6 col-md-6">
                                    <div>
                                        <label for="placeholderInput" class="form-label">User Name</label>
                                        <input type="text" class="form-control" name="new_password_confirmation" id="new_password_confirmation" placeholder="User Name" value="{{Auth::guard('misadmin')->user()->user_name}}" required>
                                    </div>
                                </div>


                            </div>

                        </div>
                        <div class="d-none code-view">
                            <pre class="language-markup" style="height: 450px;"><code>
                        </div>
                    </div>
                @endif
                    <div class="d-none code-view">
                        <pre class="language-markup" style="height: 450px;"><code>
                    </div>
                </div>
            </div>
        </div>

    </div>


@endsection
@push('script')
<script type="text/javascript">
      $(document).on('click', '#eSignKYCVerify', function (e) {
        e.preventDefault(); // Prevent form submission or default action
        const $this = $(this);
        const originalButtonText = $this.html();
        let isValid = true; // Flag to track overall form validity

        // Function to add/remove validation classes and feedback
        const validateField = ($field, condition, errorMessage) => {
            if (condition) {
                $field.addClass('is-valid').removeClass('is-invalid');
                $field.next('.invalid-feedback').remove();
            } else {
                $field.addClass('is-invalid').removeClass('is-valid');
                if (!$field.next('.invalid-feedback').length) {
                    $field.after(`<div class="invalid-feedback">${errorMessage}</div>`);
                }
                isValid = false;
            }
        };

        // Validate fields
      
        const $eSignType = $('#eSignType');
        validateField($eSignType, $eSignType.val(), 'Please select an eSign Type.');

        const $emUserId = $('#emUserId');
        validateField($emUserId, $emUserId.val().trim(), 'Please enter a valid emudhra User ID.');

        const $emUserName = $('#emUserName');
        validateField($emUserName, $emUserName.val().trim(), 'Please enter the User Full Name.');

        // Collect form data
        const eSignUserId = $this.data('esignuserid');
        const eSignClient = $this.data('esignclient');
        const eSignType = $eSignType.val();
        const emUserId = $emUserId.val().trim();
        const emUserName = $emUserName.val().trim();
        if (isValid) {
            $this.prop('disabled', true).html('<strong>Processing...</strong>');
            $.ajax({
                url: "{{ route('superadmin.cbemSign-kyc-update') }}",
                method: "POST",
                dataType: 'json',
                data: {
                    eSignUserId,
                    eSignClient,
                    eSignType,
                    emUserId,
                    emUserName,
                    _token: '{{ csrf_token() }}',
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function () {
                    Swal.fire('Success!', 'eSign KYC updated successfully.', 'success').then(() => {
                        window.location.reload();
                    });
                },
                error: function () {
                    Swal.fire('Error!', 'Something went wrong. Please try again.', 'error');
                },
                complete: function () {
                    $this.prop('disabled', false).html(originalButtonText);
                }
            });
        }
    });
</script>
@endpush
@extends('admin.layouts.app')
@section('content')

    <style>
        body {
            margin: 0px;
            padding: 0px;
            font-family: "Segoe UI";
        }

        .maindiv {
            width: 80%;
            margin: 0 auto;
        }

        .pdf_maindiv {
            border: 1px solid #cccccc;
            width: 100%;
            float: left;
            padding: 3%;
        }

        .pdf_heading {
            font-size: 20px;
            color: #000;
            padding: 26px 0 12px 0px;
            position: relative;
            width: 100%;
            float: left;
        }

        .brd_heading {
            border-bottom: 2px solid #ee5e24;
            padding-bottom: 8px;
            padding-right: 8px;
            width: 60px;
        }

        .pdf_input1 {
            background: #eeeeee;
        }

        .pdf_txt1 {
            color: #000;
            font-size: 14px;
            width: 45%;
            float: left;
            padding-bottom: 10px;
            font-weight: bold;
        }

        .pdf_box {
            color: #000;
            font-size: 14px;
            width: 55%;
            float: left;
            padding-bottom: 10px;
        }

        .table_pdf {
            width: 100%;
        }
    </style>
    <!-- start page title -->
    <div class="overlay">
        <div class="loader"></div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Imported Ingredient</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Imported Ingredient(s)</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">
            <form method="post" enctype="multipart/form-data" id="registration"
                action="{{ route('superadmin.applyImportIngredientUpdate',$importDetail->id) }}">
                @csrf
                <nav>

                </nav>
                <div class="tab-content py-4 custom-tab-content">
                    <div class="tab-pane fade show active" id="step1">
                        <div class="card">
                            <div class="card-header align-items-center d-flex">
                                <h4 class="card-title mb-0 flex-grow-1">
                                    Apply For Imported Ingredient(s) Approval
                                </h4>
                                <div class="flex-shrink-0">
                                    @if (session('error'))
                                        <div class="alert alert-danger">
                                            {{ session('error') }}
                                        </div>
                                    @endif
                                    @if (session('success'))
                                        <div class="alert alert-success">
                                            {{ session('success') }}
                                        </div>
                                    @endif
                                    @if ($errors)
                                        @foreach ($errors->all() as $error)
                                            <div class="alert alert-danger">{{ $error }}</div>
                                        @endforeach
                                    @endif
                                </div>

                            </div>
                            <!-- end card header -->
                            <div class="card-body">


                                <div class="pdf_heading">Operator Details</div>
                                <div class="pdf_maindiv">
                                    <!--form1 section starts here-->
                                    <div class="container-fluid">
                                        <div class="row">
                                            <div class="col-6">
                                                <!--form1 tab starts here-->
                                                <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                    <tr>
                                                        <td class="pdf_txt1">Scope Certification No. : </td>
                                                        <td class="pdf_box"> ORG/SC/1505/001061</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="pdf_txt1">Operator Name : </td>
                                                        <td class="pdf_box">{{ ucwords(Auth::user()->first_name) ?? '' }}
                                                            {{ ucwords(Auth::user()->middle_name) ?? '' }}
                                                            {{ ucwords(Auth::user()->last_name) ?? '' }} </td>
                                                    </tr>


                                                </table>
                                                <!--form1 tab end here-->
                                            </div>
                                            <div class="col-6">
                                                <!--form1 tab starts here-->
                                                <table style="padding: 10px; border: 0px;" class="table_pdf">

                                                    <tr>
                                                        <td class="pdf_txt1">Operator Type : </td>
                                                        <td class="pdf_box">
                                                            Processor
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="pdf_txt1">Acitivity : </td>
                                                        <td class="pdf_box"> Processing

                                                        </td>
                                                    </tr>

                                                </table>
                                                <!--form1 tab end here-->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                         
                                <div class="row seperatesec white-inner">

                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label blue-ht">IMPORT
                                            DETAILS</label>
                                    </div>

                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">Bill of Entry Number : <span class="required">*
                                                </span></label>
                                            <input type="text" class="form-control" name="bill_of_entry_no" value="{{ $importDetail->bill_of_entry_no ??'' }}">
                                            
                                        </div>
                                    </div>
                                    {{-- {{ date("d-m-Y", strtotime($importDetail->bill_of_entry_date)) ??'' }} --}}
                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">Bill of Entry Date :<span class="required">*
                                                </span></label>
                                                <input type="date" class="form-control" name="bill_of_entry_date" value="{{ date('Y-m-d', strtotime($importDetail->bill_of_entry_date))}}">
                                        </div>
                                    </div>
                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">Country of Origin : <span class="required">*
                                                </span></label>
                                              
                                                <select class="form-select" name="ref_country_master_id" >
                                                    <option value="">Select Country</option>
                                                    @foreach(getRefCountryMaster() as $country)
                                                    <option value="{{ $country->id }}" @selected($country->id==$importDetail->ref_country_master_id)>{{ $country->country_name }}</option>
                                                    @endforeach
                                                </select>
                                        </div>
                                    </div>
                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">Name of Expoter of Importing Country:<span class="required">*
                                                </span></label>
                                                <input type="text" class="form-control" name="exporter_name" value="{{ $importDetail->exporter_name ??'' }}">
                                        </div>
                                    </div>
                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">NOP Certificate Number of Exporter of Importing Country : <span class="required">*
                                                </span></label>
                                                <input type="text" class="form-control" name="nop_certificate_no" value="{{ $importDetail->nop_certificate_no ??'' }}">
                                        </div>
                                    </div>
                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">NOP Certificate Issused By:<span class="required">*
                                                </span></label>
                                                <input type="text" class="form-control" name="nop_certified_by" value="{{ $importDetail->nop_certified_by ??'' }}">
                                        </div>
                                    </div>


                                </div>
                                <div class="row seperatesec white-inner">

                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label blue-ht">INGREDIENT
                                            DETAILS</label>
                                            <i style="float: right;" data-type="wm" class="mdi mdi-plus btn btn-soft-success add-more"
                                                        data-toggle="tooltip" title="Add Row"></i>
                                    </div>

                                    <div class=" p-2 odd-bd mb-3">
                                        <div class="row m-0 mt-2" >
                                          <table class="table" id="TextBoxContainer" >
                                            <thead>
                                                <th>Sr.No.</th>
                                                <th>HS Code</th>
                                                <th>Ingredient Name</th>
                                                <th>Quantity Imported(in MT)</th>
                                                <th>Action</th>
                                            </thead>
                                            <tbody >

                                                @if(isset($importDetail->importProductDetails) && !empty($importDetail->importProductDetails))
                                                    @foreach ($importDetail->importProductDetails as $key =>$val)
                                                    <tr>
                                                        <input type="hidden" value="{{ $val->id }}" name="row_id[]">
                                                        <td>{{ $key+1 }}</td>
                                                        <td>
                                                            <select class="form-select hscode" name="ref_product_id[]" >
                                                                <option value="">Select HS Code</option>
                                                                @foreach(getRefProduct() as $hscode)
                                                                <option value="{{ $hscode->id }}" @selected($hscode->id==$val->ref_product_id) data-value = "{{ $hscode->product_name }}" data-id = "{{ $hscode->product_name }}">{{ $hscode->hs_code }}</option>
                                                                @endforeach
                                                            </select>
                                                        
                                                        </td>
                                                        <td><input type="text"  class="form-control product_type" name="product_name[]" value="{{ getHscodeProductName($val->ref_product_id) }}"></td>
                                                        <td><input type="text"  class="form-control numbersonly" name="import_qty_in_mt[]" value="{{ $val->import_qty_in_mt ??''}}"></td>
                                                        <td><i data-type="wm" class="mdi mdi-minus btn btn-soft-danger "
                                                            data-toggle="tooltip" title="Remove Row"></i></td>
                                                    </tr> 
                                                        
                                                    @endforeach
                                                @else
                                                <tr>
                                                    <td>1</td>
                                                    <td>
                                                        <select class="form-select hscode" name="ref_product_id[]" >
                                                            <option value="">Select HS Code</option>
                                                            @foreach(getRefProduct() as $hscode)
                                                            <option value="{{ $hscode->id }}" data-id = "{{ $hscode->product_name }}">{{ $hscode->hs_code }}</option>
                                                            @endforeach
                                                        </select>
                                                    
                                                    </td>
                                                    <td><input type="text"  class="form-control product_type" name="product_name[]" value=""></td>
                                                    <td><input type="text"  class="form-control numbersonly" name="import_qty_in_mt[]" value=""></td>
                                                    <td><i data-type="wm" class="mdi mdi-plus btn btn-soft-success add-more"
                                                        data-toggle="tooltip" title="Add Row"></i></td>
                                                </tr> 
                                                @endif
                                            </tbody>
                                          </table>
                                        </div>
                                    </div>
                                   
                                </div>
                                <div class="row seperatesec white-inner">

                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label blue-ht">ATTACH DOCUMENT(S)
                                            </label>
                                    </div>
                                    <div class="col-xxl-3 col-md-4 gy-3">
										<div>
											<label class="form-label">Bill of Entry : <span class="required"> </span></label>
											<input type="file" class="form-control" id="" name="bill_of_entry_file">
											  @if(!empty($importDetail->bill_of_entry_file))
												<input type="hidden" name="bill_of_entry_file_edit" value="{{ ($importDetail->bill_of_entry_file) ?? ''}}">
												<a target="_BLANK" href="{{asset('public/importIngredient/'.$importDetail->bill_of_entry_file)}}" class="text-decoration-underline">See Doc</a>
											@endif  
										</div>
									</div>
                                    <div class="col-xxl-3 col-md-4 gy-3">
										<div>
											<label class="form-label">Certification Details (Scope) of Exporter of Importing Country : <span class="required"> </span></label>
											<input type="file" class="form-control" id="" name="exporter_certification_details_issued_by_exporting_country">
											  @if(!empty($importDetail->exporter_certification_details_issued_by_exporting_country))
												<input type="hidden" name="exporter_certification_details_issued_by_exporting_country_edit" value="{{ ($importDetail->exporter_certification_details_issued_by_exporting_country) ?? ''}}">
												<a target="_BLANK" href="{{asset('public/importIngredient/'.$importDetail->exporter_certification_details_issued_by_exporting_country)}}" class="text-decoration-underline">See Doc</a>
											@endif  
										</div>
									</div>
                                    <div class="col-xxl-3 col-md-4 gy-3">
										<div>
											<label class="form-label">Contract / Invoice of operator with Exporter : <span class="required"> </span></label>
											<input type="file" class="form-control" id="" name="contract_invoice_of_operator_with_exporter">
											  @if(!empty($importDetail->contract_invoice_of_operator_with_exporter))
												<input type="hidden" name="contract_invoice_of_operator_with_exporter_edit" value="{{ ($importDetail->contract_invoice_of_operator_with_exporter) ?? ''}}">
												<a target="_BLANK" href="{{asset('public/importIngredient/'.$importDetail->contract_invoice_of_operator_with_exporter)}}" class="text-decoration-underline">See Doc</a>
											@endif  
										</div>
									</div>
                                </div>

                                <!--address sec end-->
                                @if($importDetail->is_approved==NULL || $importDetail->is_rejected!=NULL)
                                <div class="row">
                                    <div class="col-lg-12 gy-4">
                                        <div class="hstack gap-2">
                                            <button type="submit" class="btn btn-primary">
                                                Submit Application
                                            </button>
                                           

                                        </div>
                                    </div>

                                </div>
                                @else
                                <div class="row seperatesec white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label blue-ht">Inspection Detail
                                            </label>
                                    </div>
                                    <div class="col-xxl-3 col-md-4 gy-3">
                                        <div>
                                            <label class="form-label">Status :</label>
                                            <span class="badge badge-soft-success">{{($importDetail->is_approved==1?'Approved':'')}}
                                                {{($importDetail->is_rejected==1?'Rejected':'')}}</span>
                                        </div>
                                    </div>
                                    <div class="col-xxl-3 col-md-4 gy-3">
                                        <div>
                                            <label class="form-label">Inspection Date : </label>
                                            <span class="badge badge-soft-secondary">{{ date('Y-m-d',strtotime($importDetail->approved_on))}}</span>
                                        </div>
                                    </div>
                                    <div class="col-xxl-3 col-md-4 gy-3">
                                        <div>
                                            <label class="form-label">Inspected By :</label>
                                            <span class="badge badge-soft-secondary">
                                                {{$importDetail->approved_by}}</span>
                                        </div>
                                    </div>
                                    <div class="col-xxl-3 col-md-4 gy-3">
                                        <div>
                                            <label class="form-label">Remark :</label>
                                            {{($importDetail->remarks)}}
                                        </div>
                                    </div>
                                </div>
                                @endif
                            </div>

                        </div>
                    </div>
            </form>
        </div>
    </div>



@endsection
@push('script')
    <script>
       
        /// check pan number
        $(document).ready(function() {
            var i=2;
            $("body").on("click", ".add-more", function() {
               
               $('#TextBoxContainer').append('<tr> <td>'+i+'</td><td><select class="form-select hscode" name="ref_product_id[]"><option value="">Select HS Code</option>@foreach(getRefProduct() as $hscode)<option value="{{ $hscode->id }}" data-id="{{ $hscode->product_name }}">{{ $hscode->hs_code }}</option>@endforeach</select> </td><td><input type="text"  class="form-control product_type" name="product_name[]" value=""></td><td><input type="text"  class="form-control numbersonly" name="import_qty_in_mt[]" value=""></td><td><i data-type="" class="mdi mdi-minus btn btn-soft-danger remove"data-toggle="tooltip" title="Remove Row"></i></td></tr>');
               i++;

               $('.hscode').on('change', function() {
                    var element = $(this).find('option:selected').attr("data-id"); 
                    $(this).closest('tr').find('[name="product_name[]"]').val(element);
                    //alert(element);
                });

            });

            $("body").on("click", ".remove", function() {
                $(this).closest('tr').remove();
                i--;
            });
        });


        $('.hscode').on('change', function() {
            var element = $(this).find('option:selected').attr("data-id"); 
           // alert(element);
           
            $(this).closest('tr').find('[name="product_name[]"]').val(element);
        });

        $(".verifiEmail_otp").click(function(e) {
            e.preventDefault();
            var email_otp = $('#email_otp1').val();
            $(".overlay").show();
            if (email_otp != "") {

                $.ajax({
                    type: 'POST',
                    url: "{{ route('superadmin.usermanagement.email_mobile_OTP_check') }}",
                    data: {
                        'email_otp': email_otp
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(html) {
                        if (html == 0) {
                            Swal.fire("", "Please enter Valid OTP", "error");
                        } else {
                            $('#email_otp').prop('readonly', true);
                            $('.otp-email1').hide(500);
                            $('.btn-email').hide(500);
                            $('.btn-verify').show(500);
                            $('.visitorCat').hide(500);
                            $('.visitorCat1').hide(500);
                            $('.user_detail_page').show(500);
                            $('#email_id').prop('readonly', true);
                            $('.btn-mailsend').hide();
                            $('.login-pass').hide();
                        }
                        $(".overlay").hide();
                    }
                });
            } else {
                Swal.fire("", "Please enter OTP", "error");
            }
        });

       
    </script>
@endpush

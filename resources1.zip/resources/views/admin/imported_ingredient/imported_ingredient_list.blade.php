@extends('admin.layouts.app')
@section('content')
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Pending applications for approval</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="{{ route('superadmin.dashboard') }}">Dashboard</a></li>
                        <li class="breadcrumb-item active">Import Ingredients</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">

            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0" style="float: left">Imported Ingredient List</h5>
                            <div class="row justify-content-end mb-2">
                                <div class="col-md-3 text-right">
                                </div>
                                {{-- @can('imported_create')    
                        <div class="col-3">
                            <a href="{{route('superadmin.applyImportIngredient')}}" class="btn btn-primary" style="float: right">Apply for Imported Ingredient</a>
                        </div>
                        @endcan --}}

                                @if ($user->ref_operator_type_id == 6)
                                
                                    <div class="col-3">
                                        <a href="{{ route('superadmin.applyImportIngredient') }}" class="btn btn-primary"
                                            style="float: right">Apply for Imported Ingredient</a>
                                    </div>
                                @endif



                            </div>

                        </div>
                        <!-- end card header -->
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="farmerTable"
                                    class="table table-bordered dt-responsive nowrap table-striped align-middle"
                                    style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>S.No.</th>
                                            <!-- <th>Application No.</th> -->
                                            <th>Application Date</th>
                                            <th>Bill No.</th>
                                            <th>Bill of End Date</th>
                                            <th>Origin Country</th>
                                            <th>Exporter Name</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
@endsection
@push('script')
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        var table = $('#farmerTable').DataTable({
            //dom: 'l<"clear">Bfrtip',
            //dom:'Bfrtip',
            //dom:'Blfrtip',
            processing: true,
            serverSide: true,
            ajax: {
                url: '{{ route('superadmin.importIngredientList') }}',
                type: 'GET',
                data: function(d) {

                }
            },
            columns: [{
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex',
                    orderable: true
                },
                // { data: 'application_no',name:'application_no',orderable: true },
                {
                    data: 'application_date',
                    name: 'application_date',
                    orderable: true
                },
                {
                    data: 'bill_of_entry_no',
                    name: 'bill_of_entry_no',
                    orderable: true
                },
                {
                    data: 'bill_of_entry_date',
                    name: 'bill_of_entry_date',
                    orderable: true
                },
                {
                    data: 'ref_country_master_id',
                    name: 'ref_country_master_id',
                    orderable: true
                },
                {
                    data: 'exporter_name',
                    name: 'exporter_name',
                    orderable: true
                },
                {
                    data: 'status',
                    name: 'status',
                    orderable: true
                },
                {
                    data: 'action',
                    name: 'action',
                    orderable: false
                }
            ],


        });



        // function confirmDelete_(id) {

        //     Swal.fire({
        //         title: 'Are you sure?',
        //         text: "You won't be able to revert this!",
        //         icon: 'warning',
        //         showCancelButton: true,
        //         confirmButtonColor: '#3085d6',
        //         cancelButtonColor: '#d33',
        //         confirmButtonText: 'Yes, delete it!'
        //     }).then((result) => {
        //         if (result.value) {
        //             $.ajax({
        //                 url: "{{ route('superadmin.icsuser.deleteinspector') }}",
        //                 method: "POST",
        //                 dataType: 'json',
        //                 data: {
        //                     'id': id,
        //                 },
        //                 headers: {
        //                     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        //                 },
        //                 success: function(result) {

        //                     Swal.fire(
        //                         'Deleted!',
        //                         'Record Deleted Successfully..',
        //                         'success'
        //                     );
        //                     location.reload();

        //                 }
        //             });

        //         }
        //     })
        // }
    </script>
@endpush

@extends('admin.layouts.app')
@section('content')

    <style>
        body {
            margin: 0px;
            padding: 0px;
            font-family: "Segoe UI";
        }

        .maindiv {
            width: 80%;
            margin: 0 auto;
        }

        .pdf_maindiv {
            border: 1px solid #cccccc;
            width: 100%;
            float: left;
            padding: 3%;
        }

        .pdf_heading {
            font-size: 20px;
            color: #000;
            padding: 26px 0 12px 0px;
            position: relative;
            width: 100%;
            float: left;
        }

        .brd_heading {
            border-bottom: 2px solid #ee5e24;
            padding-bottom: 8px;
            padding-right: 8px;
            width: 60px;
        }

        .pdf_input1 {
            background: #eeeeee;
        }

        .pdf_txt1 {
            color: #000;
            font-size: 14px;
            width: 45%;
            float: left;
            padding-bottom: 10px;
            font-weight: bold;
        }

        .pdf_box {
            color: #000;
            font-size: 14px;
            width: 55%;
            float: left;
            padding-bottom: 10px;
        }

        .table_pdf {
            width: 100%;
        }
    </style>
    <!-- start page title -->
    <div class="overlay">
        <div class="loader"></div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Imported Ingredient</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Imported Ingredient(s)</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">
            
                <nav>

                </nav>
                <div class="tab-content py-4 custom-tab-content">
                    <div class="tab-pane fade show active" id="step1">
                        <div class="card">
                            <div class="card-header align-items-center d-flex">
                                <h4 class="card-title mb-0 flex-grow-1">
                                    Imported Ingredient(s) for Approval
                                </h4>
                                <div class="flex-shrink-0">
                                    @if (session('error'))
                                        <div class="alert alert-danger">
                                            {{ session('error') }}
                                        </div>
                                    @endif
                                    @if (session('success'))
                                        <div class="alert alert-success">
                                            {{ session('success') }}
                                        </div>
                                    @endif
                                    @if ($errors)
                                        @foreach ($errors->all() as $error)
                                            <div class="alert alert-danger">{{ $error }}</div>
                                        @endforeach
                                    @endif
                                </div>

                            </div>
                            <!-- end card header -->
                            <div class="card-body">


                                <div class="pdf_heading">Operator Details</div>
                                <div class="pdf_maindiv">
                                    <!--form1 section starts here-->
                                    <div class="container-fluid">
                                        <div class="row">
                                            <div class="col-6">
                                                <!--form1 tab starts here-->
                                                <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                    <tr>
                                                        <td class="pdf_txt1">Scope Certification No. : </td>
                                                        <td class="pdf_box"> {{getRegno($importDetail->created_by,6)}}</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="pdf_txt1">Operator Name : </td>
                                                        <td class="pdf_box">{{ ucwords(user_name($importDetail->created_by))}} </td>
                                                    </tr>


                                                </table>
                                                <!--form1 tab end here-->
                                            </div>
                                            <div class="col-6">
                                                <!--form1 tab starts here-->
                                                <table style="padding: 10px; border: 0px;" class="table_pdf">

                                                    <tr>
                                                        <td class="pdf_txt1">Operator Type : </td>
                                                        <td class="pdf_box">
                                                            CB
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="pdf_txt1">Acitivity : </td>
                                                        <td class="pdf_box"> Approval

                                                        </td>
                                                    </tr>

                                                </table>
                                                <!--form1 tab end here-->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                         
                                <div class="row seperatesec white-inner">

                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label blue-ht">IMPORT
                                            DETAILS</label>
                                    </div>

                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">Bill of Entry Number :</label><span class="form-label ms-1">{{ ucwords($importDetail->bill_of_entry_no) ??'' }}</span>    
                                        </div>
                                    </div>
                                     
                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">Bill of Entry Date : </label>
                                            <span class="form-label ms-1">{{ date('Y-m-d', strtotime($importDetail->bill_of_entry_date))}}</span>
                                        </div>
                                    </div>
                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">Country of Origin : </label>
                                            <span class="form-label ms-1">{{ getCountryName($importDetail->ref_country_master_id) }}</span>
                                        </div>
                                    </div>
                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div>
                                            <label class="form-label">Name of Exporter of Importing Country: </label>
                                            <span class="form-label ms-1">{{ $importDetail->exporter_name ??'' }}</span>    
                                        </div>
                                    </div>
                                    <div class="col-xxl-6 col-md-6 gy-3">
                                        <div>
                                            <label class="form-label">NOP Certificate Number of Exporter of Importing Country : </label>
                                            
                                            <span class="form-label ms-1">{{ $importDetail->nop_certificate_no ??'' }}</span>
                                        </div>
                                    </div>
                                    <div class="col-xxl-6 col-md-6 gy-3">
                                        <div>
                                            <label class="form-label">NOP Certificate Issused By: </label>
                                            <span class="form-label ms-1">{{ $importDetail->nop_certified_by ??'' }}</span>


                                        </div>
                                    </div>


                                </div>
                                <div class="row seperatesec white-inner">

                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label blue-ht">INGREDIENT
                                            DETAILS</label>
                                            <!-- <i style="float: right;" data-type="wm" class="mdi mdi-plus btn btn-soft-success add-more"
                                                        data-toggle="tooltip" title="Add Row"></i> -->
                                    </div>

                                    <div class=" p-2 odd-bd mb-3">
                                        <div class="row m-0 mt-2" >
                                          <table class="table" id="TextBoxContainer" >
                                            <thead>
                                                <th width="10%">Sr.No.</th>
                                                <th width="25%">HS Code</th>
                                                <th width="25%">Ingredient Name</th>
                                                <th width="25%">Quantity Imported(in MT)</th>
                                                 
                                            </thead>
                                            <tbody >

                                                @if(isset($importDetail->importProductDetails) && !empty($importDetail->importProductDetails))
                                                @foreach ($importDetail->importProductDetails as $key =>$val)
                                                    <tr>
                                                        <input type="hidden" value="{{ $val->id }}" name="row_id[]">
                                                        <td>{{ $key+1 }}</td>
                                                        <td>
                                                        <span class="form-label ms-1">{{ getHscodeById($val->ref_product_id) ??'' }}</span>
                                                        </td>
                                                        <td> 
                                                        <span class="form-label ms-1">{{ getHscodeProductName($val->ref_product_id) }}</span>    
                                                        </td>
                                                        <td> 
                                                        <span class="form-label ms-1">{{ $val->import_qty_in_mt ??''}}</span>
                                                        </td>
                                                         
                                                    </tr> 
                                                        
                                                    @endforeach
                                                @else
                                                  
                                                @endif
                                            </tbody>
                                          </table>
                                        </div>
                                    </div>
                                   
                                </div>
                                <div class="row seperatesec white-inner">

                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label blue-ht">ATTACH DOCUMENT(S)
                                            </label>
                                    </div>
                                    <div class="col-xxl-3 col-md-4 gy-3">
										<div>
											<label class="form-label">Bill of Entry : <span class="required"> </span></label>
											  @if(!empty($importDetail->bill_of_entry_file))
												<a target="_BLANK" href="{{asset('public/importIngredient/'.$importDetail->bill_of_entry_file)}}" class="text-decoration-underline">See Doc</a>
											@endif  
										</div>
									</div>
                                    <div class="col-xxl-3 col-md-4 gy-3">
										<div>
											<label class="form-label">Certification Details (Scope) of Exporter of Importing Country : <span class="required"> </span></label>
											  @if(!empty($importDetail->exporter_certification_details_issued_by_exporting_country))
												<a target="_BLANK" href="{{asset('public/importIngredient/'.$importDetail->exporter_certification_details_issued_by_exporting_country)}}" class="text-decoration-underline">See Doc</a>
											@endif  
										</div>
									</div>
                                    <div class="col-xxl-3 col-md-4 gy-3">
										<div>
											<label class="form-label">Contract / Invoice of operator with Exporter : <span class="required"> </span></label>
											@if(!empty($importDetail->contract_invoice_of_operator_with_exporter))
											<a target="_BLANK" href="{{asset('public/importIngredient/'.$importDetail->contract_invoice_of_operator_with_exporter)}}" class="text-decoration-underline">See Doc</a>
											@endif  
										</div>
									</div>
                                </div>

                                <!--address sec end-->
                                @if($importDetail->is_approved==NULL || $importDetail->is_rejected==1)
                                @can('imported_approve')
                                <div class="card mt-2">
                                    <div class="card-header align-items-center d-flex">
                                        <h4 class="card-title mb-0 flex-grow-1 blue-ht">
                                            Enter Inspection Detail:

                                        </h4>
                                    </div>
                                    <!-- end card header -->
                                    <div class="card-body bg-white">
                                        <div class="live-preview">
                                            <form method="post" action="{{ route('superadmin.ImportIngredientStatusUpdate',$importDetail->id) }}">
                                                @csrf
                                                <div class="row">
												<input type="hidden" name="status" value="1" />
                                                    <div class="col-xxl-5 col-md-5">
                                                         
                                                        <div class="mt-4">
                                                            <label for="basiInput" class="form-label">Inspection Date<span class="required">*</span>
                                                            </label>
                                                            
                                                            <input type="date" name="inspection_date" id="duedate-field" class="form-control" data-provider="flatpickr" data-date-format="d M, Y" placeholder="Inspection Date" readonly value="{{date('Y-m-d')}}" required />    

                                                        </div>
                                                        <div class="mt-4">
                                                            <label for="basiInput" class="form-label">Inspected By<span class="required">*</span>
                                                            </label>

                                                            <input type="text" name="inspected_by" class="form-control">

                                                        </div>
                                                    </div>
                                                    <div class="col-xxl-7 col-md-7" >
                                                        <div>
                                                            <label class="form-label">Submit Your
                                                                Remarks:</label>
                                                            <textarea placeholder="Submit Your Remarks" class="form-control customtextarea" name="cb_remarks" style="height: 215px;"></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="row">
                                                    <div class="col-xxl-12 col-md-12 gy-4 ">
                                                        <div class="hstack gap-2" style="float: right">

                                                            <button type="submit" id="submitbtn" class="btn btn-primary submit-button" >Submit</button>

                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                        </div>
                        @endcan
                        @endif

                                @if($importDetail->is_approved!=NULL || $importDetail->is_rejected!=NULL)
                                <div class="row seperatesec white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label blue-ht">Inspection Detail
                                            </label>
                                    </div>
                                    <div class="col-xxl-3 col-md-4 gy-3">
                                        <div>
                                            <label class="form-label">Status :</label>
                                            <span class="badge badge-soft-success">{{($importDetail->is_approved==1?'Approved':'')}}
                                                {{($importDetail->is_rejected==1?'Rejected':'')}}</span>
                                        </div>
                                    </div>
                                    <div class="col-xxl-3 col-md-4 gy-3">
                                        <div>
                                            <label class="form-label">Inspection Date : </label>
                                            <span class="badge badge-soft-secondary">{{ date('Y-m-d',strtotime($importDetail->approved_on))}}</span>
                                        </div>
                                    </div>
                                    <div class="col-xxl-3 col-md-4 gy-3">
                                        <div>
                                            <label class="form-label">Inspected By :</label>
                                            <span class="badge badge-soft-secondary">
                                                {{$importDetail->approved_by}}</span>
                                        </div>
                                    </div>
                                    <div class="col-xxl-3 col-md-4 gy-3">
                                        <div>
                                            <label class="form-label">Remark :</label>
                                            {{($importDetail->remarks)}}
                                        </div>
                                    </div>
                                </div>
                                @endif





                        </div>
                       </div>
                    </div>
            
        </div>
    </div>



@endsection
@push('script')
    <script>
       
        /// check pan number
        $(document).ready(function() {
            var i=2;
            $("body").on("click", ".add-more", function() {
               
               $('#TextBoxContainer').append('<tr> <td>'+i+'</td><td><select class="form-select hscode" name="ref_product_id[]"><option value="">Select HS Code</option>@foreach(getRefProduct() as $hscode)<option value="{{ $hscode->id }}" data-id="{{ $hscode->product_name }}">{{ $hscode->hs_code }}</option>@endforeach</select> </td><td><input type="text"  class="form-control product_type" name="product_name[]" value=""></td><td><input type="text"  class="form-control numbersonly" name="import_qty_in_mt[]" value=""></td><td><i data-type="" class="mdi mdi-minus btn btn-soft-danger remove"data-toggle="tooltip" title="Remove Row"></i></td></tr>');
               i++;

               $('.hscode').on('change', function() {
                    var element = $(this).find('option:selected').attr("data-id"); 
                    $(this).closest('tr').find('[name="product_name[]"]').val(element);
                    //alert(element);
                });

            });

            $("body").on("click", ".remove", function() {
                $(this).closest('tr').remove();
                i--;
            });
        });


        $('.hscode').on('change', function() {
            var element = $(this).find('option:selected').attr("data-id"); 
           // alert(element);
           
            $(this).closest('tr').find('[name="product_name[]"]').val(element);
        });

        $(".verifiEmail_otp").click(function(e) {
            e.preventDefault();
            var email_otp = $('#email_otp1').val();
            $(".overlay").show();
            if (email_otp != "") {

                $.ajax({
                    type: 'POST',
                    url: "{{ route('superadmin.usermanagement.email_mobile_OTP_check') }}",
                    data: {
                        'email_otp': email_otp
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(html) {
                        if (html == 0) {
                            Swal.fire("", "Please enter Valid OTP", "error");
                        } else {
                            $('#email_otp').prop('readonly', true);
                            $('.otp-email1').hide(500);
                            $('.btn-email').hide(500);
                            $('.btn-verify').show(500);
                            $('.visitorCat').hide(500);
                            $('.visitorCat1').hide(500);
                            $('.user_detail_page').show(500);
                            $('#email_id').prop('readonly', true);
                            $('.btn-mailsend').hide();
                            $('.login-pass').hide();
                        }
                        $(".overlay").hide();
                    }
                });
            } else {
                Swal.fire("", "Please enter OTP", "error");
            }
        });

       
    </script>
@endpush

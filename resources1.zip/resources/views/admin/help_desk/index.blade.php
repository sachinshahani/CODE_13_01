@extends('admin.layouts.app')
@section('content')
<style>
    .pdf_box {
        color: #000;
        font-size: 14px;
        float: left;
        padding-bottom: 10px;
    }

    .table_pdf {
        width: 100%;
    }
</style>

<style>
    .customtextarea {
        height: 80px;
    }
	
	ol.progtrckr {
    margin: 0;
    padding: 0;
    list-style-type none;
}

ol.progtrckr li {
    display: inline-block;
    text-align: center;
    line-height: 3.5em;
}

ol.progtrckr[data-progtrckr-steps="2"] li { width: 49%; }
ol.progtrckr[data-progtrckr-steps="3"] li { width: 33%; }
ol.progtrckr[data-progtrckr-steps="4"] li { width: 24%; }
ol.progtrckr[data-progtrckr-steps="5"] li { width: 19%; }
ol.progtrckr[data-progtrckr-steps="6"] li { width: 16%; }
ol.progtrckr[data-progtrckr-steps="7"] li { width: 14%; }
ol.progtrckr[data-progtrckr-steps="8"] li { width: 12%; }
ol.progtrckr[data-progtrckr-steps="9"] li { width: 11%; }

ol.progtrckr li.progtrckr-done {
    color: black;
    border-bottom: 4px solid yellowgreen;
}
ol.progtrckr li.progtrckr-todo {
    color: silver; 
    border-bottom: 4px solid silver;
}

ol.progtrckr li:after {
    content: "\00a0\00a0";
}
ol.progtrckr li:before {
    position: relative;
    bottom: -2.5em;
    float: left;
    left: 50%;
    line-height: 1em;
}
ol.progtrckr li.progtrckr-done:before {
    content: "\2713";
    color: white;
    background-color: yellowgreen;
    height: 2.2em;
    width: 2.2em;
    line-height: 2.2em;
    border: none;
    border-radius: 2.2em;
}
ol.progtrckr li.progtrckr-todo:before {
    content: "\039F";
    color: silver;
    background-color: white;
    font-size: 2.2em;
    bottom: -1.2em;
}


</style>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Help Desk</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Help Desk Tickets</li>
                </ol>
            </div>
        </div>
    </div>
</div>
<div id="cbForm" style="display: block">

    <!-- For operator type = 1(CB) -->
    @if(Auth::user()->ref_operator_type_id == 1)
    <form method="post" enctype="multipart/form-data" id="registration"
        action="{{ route('superadmin.help_desk.cbhelpdesksave') }}" novalidate>
        @csrf

        <div class="tab-content py-2 custom-tab-content">

            <div class="tab-pane fade show active" id="step1">
                <div class="card">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1 ">
                            Help Desk Service
                        </h4>
                        <div class="flex-shrink-0">
                            @if (session('error'))
                            <div class="alert alert-danger">
                                {{ session('error') }}
                            </div>
                            @endif
                            @if (session('success'))
                            <div class="alert alert-success">
                                {{ session('success') }}
                            </div>
                            @endif
                            @if ($errors)
                            @foreach ($errors->all() as $error)
                            <div class="alert alert-danger">{{ $error }}</div>
                            @endforeach
                            @endif
                        </div>
                    </div>

                    {{-- <div class="card-body">
                        <div class="col-12">

                            <table style="padding: 5px; border: 0px;"
                                class="table_pdf table_contact_person ope-reg d-none">


                                <tbody>

                                    @if($user)

                                    <tr>

                                        <th class="pdf_txt1">Operator Name:</th>
                                        <td class="pdf_box">{{ $user->contact_person_first_name }}</td>
                                    </tr>
                                    <tr>
                                        <th class="pdf_txt1">Email Id:</th>
                                        <td class="pdf_box">{{ $user->email }}</td>
                                    </tr>

                                    <tr>
                                        <th class="pdf_txt1">Operator Status</th>
                                        <td class="pdf_box">{{ $user->status }}</td>
                                    </tr>

                                    <tr>
                                        <th class="pdf_txt1">Address:</th>
                                        <td class="pdf_box">{{ $user->address }}</td>
                                    </tr>
                                    <tr>
                                        <th class="pdf_txt1">Mobile Number:</th>
                                        <td class="pdf_box">{{ old('email', $user->contact_person_mobile_number) }}</td>
                                    </tr>

                                    @endif
                                </tbody>
                            </table>

                        </div>
                    </div>                --}}
                    <div class="card-body">

                        <div class="col-12">

                            <table style="padding: 5px; border: 0px;" class="table_pdf table_contact_person">

                            <h4 class="card-title mb-0 flex-grow-1 ">CB Details</h4>
                                <tbody>
                                    @if($user)
                                    <tr>
                                        <th class="pdf_txt1">Certification Body Name:</th>
                                        <td class="pdf_box">{{ $user->first_name }}</td>
                                    </tr>
                                    <tr>
                                        <th class="pdf_txt1">Email Id:</th>
                                        <td class="pdf_box">{{ $user->email }}</td>
                                    </tr>

                                    <tr>
                                        <th class="pdf_txt1">Address:</th>
                                        <td class="pdf_box">{{ $user->address }}</td>
                                    </tr>
                                    <tr>
                                        <th class="pdf_txt1">Mobile Number:</th>
                                        <td class="pdf_box">{{ old('email', $user->mobile_no) }}</td>
										 <th class=""></th>
                                        <!-- <td class=""><input type="button" id="Check_Status" class="btn btn-info" value="Check Status" onclick="CheckStatus()"></td> -->
										
                                    </tr>  

                                    @endif
                                </tbody>
                            </table>

                        </div>

                    </div>

                </div>




                <div class="row white-inner justify-content-end">   
                    <div class="col-10 col-xxl-6 col-md-4">
                        <div>
                            <label class="form-label">Issue Related : <span class="required">*</span></label>
                            <input type="radio" id="cb" name="issue_related_to" value="cb" checked>
                            <label for="cb">CB</label>
                            <input type="radio" id="operator" name="issue_related_to" value="operator">
                            <label for="operator">Operator</label>
                        </div>


                    </div>
                    <div class="col-2 col-xxl-6 col-md-4">

                        <a href="{{route('superadmin.search')}}" class="btn btn-primary" style="float: right">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                class="bi bi-search" viewBox="0 0 16 16">
                                <path
                                    d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
                            </svg>


                        </a>

                    </div>

                </div>


                <div class="row white-inner">
                    <div class="col-xxl-3 col-md-4 gy-3 ope-reg d-none">
                        <div>
                            <label class="form-label">Enter Operator Registration No: <span
                                    class="required">*</span></label>
                            <input type="text" class="form-control" name="registration_number" value="" required>

                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-4 gy-3 ope-reg d-none">
                        <div>
                            <label class="form-label">Issue Type : <span class="required">*</span></label>
                            <select class="form-select issue_type" name="ope_ref_issue_type_id" id="" required>
                                <option value="">-Select- </option>
                                @foreach (getIssueTypeByOpe() as $val)
                                <option value="{{ $val->id }}">{{ $val->issue_name }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-4 gy-3 cb-reg">
                        <div>
                            <label class="form-label">Issue Type: <span class="required">*</span></label>
                            <select class="form-select issue_type" name="ref_issue_type_id" id="change_dive" required>
                                <option value="">-Select- </option>
                                @foreach (getIssueType() as $val)
                                <option value="{{ $val->id }}">{{ $val->issue_name }}</option>
                                @endforeach

                            </select>
                        </div>
                    </div>


                    <div class="col-xxl-3 col-md-4 gy-3">
                        <div>
                            <label class="form-label">Sub Issue Type : <span class="required">*</span></label>
                            <select class="form-select sub_issue_type" name="ref_sub_issue_type_id" id="" required>
                                <option value="">-Select- </option>
                                {{-- @foreach (getSubIssueType() as $val)
                                <option value="{{ $val->id }}">{{ $val->sub_issue_name }}</option>
                                @endforeach --}}
                            </select>
                        </div>
                    </div>

                    <div class="col-xxl-3 col-md-4 gy-3 ">
                        <label class="form-label">Description/Justification: <span class="required">*</span></label>

                        <textarea placeholder="Remark Here" class="form-control " name="description" rows="1"
                            cols="50" required></textarea>
                        <!-- <textarea placeholder="Remark Here" class="form-control customtextarea" name="description" maxlength="50 "></textarea> -->

                    </div>

                   {{-- <div class="col-xxl-3 col-md-4 gy-3 ">
                        <div>
                            <label class="form-label">Required Document: </label><br>
                            <!-- <label class="form-label"> Document Name <span class="required">*</span></label> -->

                            <select class="form-select" name="ref_document_id" id="">
                                <option value="">Select </option>

                                <option value="7">FSSAI License</option>
                                <option value="3">PAN</option>
                                <option value="9">New FSSAI License</option>
                                <option value="8">Other</option>
                            </select>

                        </div>
                    </div>--}}

                    <div class="col-xxl-3 col-md-4 gy-3 ">
                        <label class="form-label"> Upload <span class="required"></span></label>

                        <input type="file" class="form-control upload_document" id="" placeholder="" name="document_upload" value="" />
                        <span class="form-text">Supported formats:PDF, PNG, JPG, JPEG Upto 1MB</span>
                    </div>
                    <div class="row">


                        <div class="text-center">
                            <button type="submit" class="btn btn-primary" style="margin: 16px;">Submit</button>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <!-- For operator(2,3,4,5,6) -->
    @else
    <form method="post" enctype="multipart/form-data" id="registration" action="{{ route('superadmin.help_desk.cbhelpdesksave') }}" novalidate>
        @csrf

        <div class="tab-content py-2 custom-tab-content">
            <div class="tab-pane fade show active" id="step1">
                <div class="card">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1 ">Help Desk Service</h4>
                        <div class="flex-shrink-0">
                            @if (session('error'))
                            <div class="alert alert-danger">
                                {{ session('error') }}
                            </div>
                            @endif
                            @if (session('success'))
                            <div class="alert alert-success">
                                {{ session('success') }}
                            </div>
                            @endif
                            @if ($errors)
                            @foreach ($errors->all() as $error)
                            <div class="alert alert-danger">{{ $error }}</div>
                            @endforeach
                            @endif
                        </div>
                    </div>

                    {{-- <div class="card-body">
                        <div class="col-12">
                            <table style="padding: 5px; border: 0px;" class="table_pdf table_contact_person ope-reg d-none">
                                <tbody>
                                    @if($user)
                                    <tr>
                                        <th class="pdf_txt1">Operator Name:</th>
                                        <td class="pdf_box">{{ $user->contact_person_first_name }}</td>
                                    </tr>
                                    <tr>
                                        <th class="pdf_txt1">Email Id:</th>
                                        <td class="pdf_box">{{ $user->email }}</td>
                                    </tr>
                                    <tr>
                                        <th class="pdf_txt1">Operator Status</th>
                                        <td class="pdf_box">{{ $user->status }}</td>
                                    </tr>
                                    <tr>
                                        <th class="pdf_txt1">Address:</th>
                                        <td class="pdf_box">{{ $user->address }}</td>
                                    </tr>
                                    <tr>
                                        <th class="pdf_txt1">Mobile Number:</th>
                                        <td class="pdf_box">{{ old('email', $user->contact_person_mobile_number) }}</td>
                                    </tr>
                                    @endif
                                </tbody>
                            </table>
                        </div>
                    </div>                --}}
                    <div class="card-body">
                        <div class="col-12">
                            <table style="padding: 5px; border: 0px;" class="table_pdf table_contact_person">
                            <h4 class="card-title mb-0 flex-grow-1 ">CB Details</h4>
                                <tbody>
                                    @if($user)
                                    <tr>
                                        <th class="pdf_txt1">Certification Body Name:</th>
                                        <td class="pdf_box">{{ $user->first_name }}</td>
                                    </tr>
                                    <tr>
                                        <th class="pdf_txt1">Email Id:</th>
                                        <td class="pdf_box">{{ $user->email }}</td>
                                    </tr>
                                    <tr>
                                        <th class="pdf_txt1">Address:</th>
                                        <td class="pdf_box">{{ $user->address }}</td>
                                    </tr>
                                    <tr>
                                        <th class="pdf_txt1">Mobile Number:</th>
                                        <td class="pdf_box">{{ old('email', $user->mobile_no) }}</td>
                                        <th class=""></th>
                                        <!-- <td class=""><input type="button" id="Check_Status" class="btn btn-info" value="Check Status" onclick="CheckStatus()"></td> -->
                                    </tr>  
                                    @endif
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- <div class="row white-inner">
                    <div class="col-xxl-6 col-md-4 gy-3">
                        <div>
                            <label class="form-label">Issue Related : <span class="required">*</span></label>

                            <input type="radio" id="cb" name="issue_related_to" value="cb" checked>
                            <label for="cb">CB</label>
                            <input type="radio" id="operator" name="issue_related_to" value="operator">
                            <label for="operator">Operator</label>
                        </div>
                    </div>
                    <div class="col-6">
                        <a href="{{route('superadmin.search')}}" class="btn btn-primary" style="float: right">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                class="bi bi-search" viewBox="0 0 16 16">
                                <path
                                    d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
                            </svg>
                        </a>
                    </div>
                </div> -->

                <div class="row white-inner">
                    <input type="hidden" id="operator" name="issue_related_to" value="operator">
                    <div class="col-xxl-3 col-md-4 gy-3 ope-reg">
                        <div>
                            <label class="form-label">Enter Operator Registration No: <span class="required">*</span></label>
                            @if(!empty(Auth::user()->registration_no))
                            <input type="text" class="form-control" name="registration_number" value="{{Auth::user()->registration_no}}" required readonly>
                            @else
                            <input type="text" class="form-control" name="registration_number" value="">
                            @endif
                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-4 gy-3 ope-reg">
                        <div>
                            <label class="form-label">Issue Type : <span class="required">*</span></label>
                            <select class="form-select issue_type" name="ope_ref_issue_type_id" id="" required>
                                <option value="">-Select- </option>
                                @foreach (getIssueTypeByOpe() as $val)
                                <option value="{{ $val->id }}">{{ $val->issue_name }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-4 gy-3">
                        <div>
                            <label class="form-label">Sub Issue Type : <span class="required">*</span></label>
                            <select class="form-select sub_issue_type" name="ref_sub_issue_type_id" id="" required>
                                <option value="">-Select- </option>
                                {{-- @foreach (getSubIssueType() as $val)
                                <option value="{{ $val->id }}">{{ $val->sub_issue_name }}</option>
                                @endforeach --}}
                            </select>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-4 gy-3 ">
                        <label class="form-label">Description/Justification: <span class="required">*</span></label>
                        <textarea placeholder="Remark Here" class="form-control " name="description" rows="1"
                            cols="50" required></textarea>
                        <!-- <textarea placeholder="Remark Here" class="form-control customtextarea" name="description" maxlength="50 "></textarea> -->
                    </div>

                   {{-- <div class="col-xxl-3 col-md-4 gy-3 ">
                        <div>
                            <label class="form-label">Required Document: </label><br>
                            <!-- <label class="form-label"> Document Name <span class="required">*</span></label> -->
                            <select class="form-select" name="ref_document_id" id="">
                                <option value="">Select </option>
                                <option value="7">FSSAI License</option>
                                <option value="3">PAN</option>
                                <option value="9">New FSSAI License</option>
                                <option value="8">Other</option>
                            </select>
                        </div>
                    </div>--}}

                    <div class="col-xxl-3 col-md-4 gy-3 ">
                        <label class="form-label"> Upload <span class="required"></span></label>
                        <input type="file" class="form-control upload_document" id="" placeholder="" name="document_upload" value="" />
                        <span class="form-text">Supported formats:PDF Upto 1MB</span>
                    </div>
                    <div class="row">
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary" style="margin: 16px;">Submit</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
    @endif

<!-- Modal -->
<div class="modal fade" id="checkStatustickets" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Tickets Status</h5>
        {{--<button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>--}}
      </div>
      <div class="modal-body">
     <div class="row">
          <ol class="progtrckr" data-progtrckr-steps="5">
            <li class="progtrckr-done">Ticket Raised</li>
            <li class="progtrckr-done">Pending</li>
            <li class="progtrckr-done">Waiting</li>
            <li class="progtrckr-todo">Resolve Issue</li>
          </ol>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

    <script>

        $("input:radio[name='issue_related_to']").change(function () {
            var issue_rel = $(this).val();
            //  console.log(issue_rel);
            if (issue_rel === 'operator') {
			
                $('.ope-reg').removeClass('d-none');
                $('.cb-reg').addClass('d-none');
            } else {
				
                $('.ope-reg').addClass('d-none');
                $('.cb-reg').removeClass('d-none');
            }
        });

        $('.issue_type').on('change', function () {
            var th = $(this);
            var id = this.value;

            $.ajax({
                url: '{{ route("superadmin.help_desk.getSubIssueType") }}',
                type: "POST",
                data: {
                    id: id,
                },
                dataType: 'json',
                success: function (result) {
                    console.log(result);
                    if (result) {
                        th.closest('.row').find('.sub_issue_type').html(result);
                    }
                }
            });
        });


        $('.upload_document').on('change', function() {
            var $this = $(this);
            var file = $this[0].files[0];
            var fileType = file.type;
            var fileSize = file.size;
            var allowedTypes = ['application/pdf','image/jpeg', 'image/jpg', 'image/png'];

            // Check for file type
            if (!allowedTypes.includes(fileType)) {
                Swal.fire({
                    icon: 'error',
                    title: 'Invalid File Extension',
                    text: 'Please upload PDF,JPEG, JPG, PNG  only.',
                });
                $this.val("");
                return false;
            }

            // Check for file size
            if (fileSize > 1000000) { // 2 MB in bytes
                Swal.fire({
                    icon: 'error',
                    title: 'File Size Too Large',
                    text: 'Please upload files of size 1 MB or less only.',
                });
                $this.val("");
                return false;
            }
        });
		
		function CheckStatus(){
			$('#checkStatustickets').modal('show');
		}
    </script>

    @endsection
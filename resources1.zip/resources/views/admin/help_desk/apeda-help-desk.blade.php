@extends('admin.layouts.app')
@section('content')
<style>
   

</style>
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Help Desk Tickets</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Help Desk Tickets</li>
                </ol>
            </div>

        </div>
    </div>
</div>


<div class="row white-inner">
    <div class="col-lg-12 ">
        <div class="card">
            <div class="row justify-content-end ">
                <div class="col-12 col-md-5 col-lg-3 col-xl-3 text-right mb-2">
                    <select class="form-select" name="status" id="search" data-label-msg="Status" required>
                        <option value="">Select status</option>
                        <option value="all">All</option>
                        @foreach(statusdata() as $val)
                        <option value="{{$val->id ?? ''}}">{{$val->status ?? ''}}</option>
                        @endforeach
                    </select>
                </div>
                <div class="card-body table-responsive">

                    <table id="online" class="table table-bordered table-striped align-middle white-inner"
                        style="width:100%">
                        <thead>
                            <tr>
                                <th>S.NO.</th>
                                <th>Registration No</th>
                                <th>Issue Related</th>
                                <th>User Name</th>
                                <th>Issue Type</th>
                                <th>Sub Issue Type</th>
                                <th>Ticket No</th>
                                <th>Status</th>
                                <th>Ticket Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>


                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!--end col-->
    </div>
    @endsection
    @push('script')
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        var table = $('#online').DataTable({
            dom: 'Bfrtip',
            pageLength: 10,
            lengthMenu: [
                [5, 5, 5, -1],
                [5, 5, 5, "All"]
            ],
            processing: true,
            serverSide: true,
            ajax: {
                url: '{{ route("getSuperadmin.helpdesktickets") }}',
                type: 'GET',
                data: function(d) {
                    d._token = "{{ csrf_token() }}";
                    d.operator_status = $("#search").val();
                    d.operator_date = $("#date").val();
                    // Send operator_status parameter
                }
            },
            columns: [{
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex',
                    orderable: true
                },
                {
                    data: 'registration_number',
                    name: 'registration_number',
                    orderable: true
                },

                {
                    data: 'issue_related_to',
                    name: 'issue_related_to',
                    orderable: true
                },

                {
                    data: 'at_user_id',
                    name: 'at_user_id',
                    orderable: true
                },
                {
                    data: 'ref_issue_type_id',
                    name: 'ref_issue_type_id',
                    orderable: true
                },

                {
                    data: 'ref_sub_issue_type_id',
                    name: 'ref_sub_issue_type_id',
                    orderable: true
                },
                {
                    data: 'issue_id',
                    name: 'issue_id',
                    orderable: true
                },
                {
                    data: 'status',
                    name: 'status',
                    orderable: true
                },
                {
                    data: 'from_date',
                    name: 'from_date',
                    orderable: true
                },

                {
                    data: 'action',
                    name: 'name',
                    orderable: true
                },
            ],
            buttons: [
                // {
                //     extend: 'excelHtml5 ',
                //     title: function() {
                //         return "Online Applications List";
                //     },
                //     titleAttr: 'CSV REPORTS'
                // },
                {
                    extend: 'pdfHtml5',
                    title: function() {
                        return "Ticket list";
                    },
                    orientation: 'landscape',
                    pageSize: 'A4',
                    titleAttr: 'Ticket list'
                }
            ]
        });
        $("#search").on('change', function(e) {
            table.draw();
            e.preventDefault();
        });
    </script>


    @endpush
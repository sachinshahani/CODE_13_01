@extends('admin.layouts.app')
@section('content')

<form method="POST" action="{{ route('superadmin.sendRequest') }}">
    @csrf

    <div class="form-group row">
        <label for="pan_no" class="col-md-1 col-form-label text-md-right">{{ __('Pan') }}</label>

        <div class="col-md-2">
            <input id="pan_no" type="text" class="form-control @error('pan_no') is-invalid @enderror" name="pan_no" required autocomplete="off" autofocus>

            @error('pan_no')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $error }}</strong>
            </span>
            @enderror
        </div>
    </div>

    <!-- Add more form fields following the same pattern -->

    <div class="form-group row mt-3">
        <div class="col-md-2 offset-md-2">
            <button type="submit" class="btn btn-primary">
                {{ __('Send Request') }}
            </button>
        </div>
    </div>
</form>

@if(isset($error))
<div class="alert alert-danger" role="alert">
    {{ $error }}
</div>
@endif

@endsection

@extends('admin.layouts.app')
@section('content')
<style>
    .pdf_box {
        color: #000;
        font-size: 14px;
        width: 55%;
        float: left;
        padding-bottom: 10px;
    }

    .table_pdf {
        width: 100%;
    }
</style>
<style>
    .customtextarea {
        height: 80px;
    }
</style>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Help Desk</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Help Desk Tickets</li>
                </ol>
            </div>
        </div>
    </div>
</div>
@if(Auth::user()->ref_operator_type_id == 1)
<form method="post" enctype="multipart/form-data" id="registration" action="{{ route('superadmin.help_desk.cbhelpdesksave') }}" novalidate>
    @csrf
    <div class="tab-content py-2 custom-tab-content">
        <div class="tab-pane fade show active" id="step1">
            <div class="card">
                <div class="card-header align-items-center d-flex">
                    <h4 class="card-title mb-0 flex-grow-1 ">
                        Help Desk Service
                    </h4>
                    <a href="" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#exampleModal">Add Ticket</a>
                    <div class="flex-shrink-0">
                        @if (session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                        @endif
                        @if (session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                        @endif
                        @if ($errors)
                        @foreach ($errors->all() as $error)
                        <div class="alert alert-danger">{{ $error }}</div>
                        @endforeach
                        @endif
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="col-md-6">
                                <div class="row">
                                    <label for="" class="fw-bold">CB Details :</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-2">
                            <label for="" class="fw-bold">Certification Body Name:</label>
                        </div>
                        <div class="col-md-3">
                            <label for="">{{ $user->first_name }}</label>
                        </div>
                        <div class="col-md-2">
                            <label for="" class="fw-bold">Email Id:</label>
                        </div>
                        <div class="col-md-3">
                            <label for="">{{ $user->email }}</label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-2">
                            <label for="" class="fw-bold">Address:</label>
                        </div>
                        <div class="col-md-3">
                            <label for="">{{ $user->address }}</label>
                        </div>
                        <div class="col-md-2">
                            <label for="" class="fw-bold">Mobile Number:</label>
                        </div>
                        <div class="col-md-3">
                            <label for="">{{ old('email', $user->mobile_no) }}</label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<div class="row white-inner">
    <div class="col-lg-12 ">
        <div class="card">
            <div class="card-body table-responsive">
                <table id="online" class="table table-bordered table-striped align-middle white-inner"
                    style="width:100%">
                    <thead>
                        <tr>
                            <th>S.NO.</th>
                            <th>Ticket No</th>
                            <!-- <th>Registration No</th> -->
                            <th>Issue Related</th>
                            <!-- <th>User Name</th> -->
                            <th>Issue Type</th>
                            <th>Sub Issue Type</th>
                            
                            <th>Status</th>
                            <th>Date & Time</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                       
                       
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!--end col-->
</div>




<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Help Desk Service</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <div id="cbForm" style="display: block">

<!-- For operator type = 1(CB) -->
@if(Auth::user()->ref_operator_type_id == 1)
<form method="post" enctype="multipart/form-data" id="registration"
    action="{{ route('superadmin.help_desk.cbhelpdesksave') }}" novalidate>
    @csrf

    <div class="tab-content py-2 custom-tab-content">
        <div class="tab-pane fade show active" id="step1">
            <div class="card">
                <div class="card-header align-items-center d-flex">
                    <div class="flex-shrink-0">
                        @if (session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                        @endif
                        @if (session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                        @endif
                        @if ($errors)
                        @foreach ($errors->all() as $error)
                        <div class="alert alert-danger">{{ $error }}</div>
                        @endforeach
                        @endif
                    </div>
                </div>
            </div>
            <div class="row white-inner justify-content-start">   
                <div class="col-10 col-xxl-6 col-md-4">
                    <div>
                        <label class="form-label">Issue Related : <span class="required">*</span></label>
                        <input type="radio" id="cb" name="issue_related_to" value="cb" checked>
                        <label for="cb">CB</label>
                        <input type="radio" id="operator" name="issue_related_to" value="operator">
                        <label for="operator">Operator</label>
                    </div>
                </div>
            </div>
            <div class="row white-inner">
                <div class="col-xxl-3 col-md-4 gy-3 ope-reg d-none">
                    <div>
                        <label class="form-label">Enter Operator Registration No: <span class="required">*</span></label>
                        <input type="text" class="form-control" name="registration_number" value="" required>
                    </div>
                </div>
                <div class="col-xxl-4 col-md-4 gy-3 ope-reg d-none">
                    <div>
                        <label class="form-label">Issue Type : <span class="required">*</span></label>
                        <select class="form-select issue_type" name="ope_ref_issue_type_id" id="" required>
                            <option value="">-Select- </option>
                            @foreach (getIssueTypeByOpe() as $val)
                            <option value="{{ $val->id }}">{{ $val->issue_name }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="col-xxl-4 col-md-4 gy-3 cb-reg">
                    <div>
                        <label class="form-label">Issue Type: <span class="required">*</span></label>
                        <select class="form-select issue_type" name="ref_issue_type_id" id="change_dive" required>
                            <option value="">-Select- </option>
                            @foreach (getIssueTypeByOpe() as $val)
                            @if($val->id==3)
                            @else
                            <option value="{{ $val->id }}">{{ $val->issue_name }}</option>
                            @endif
                            @endforeach

                        </select>
                    </div>
                </div>


                <div class="col-xxl-4 col-md-4 gy-3">
                    <div>
                        <label class="form-label">Sub Issue Type : <span class="required">*</span></label>
                        <select class="form-select sub_issue_type" name="ref_sub_issue_type_id" id="" required>
                            <option value="">-Select- </option>
                            {{-- @foreach (getSubIssueType() as $val)
                            <option value="{{ $val->id }}">{{ $val->sub_issue_name }}</option>
                            @endforeach --}}
                        </select>
                    </div>
                </div>

                <div class="col-xxl-4 col-md-4 gy-3 ">
                    <label class="form-label">Description/Justification: <span class="required">*</span></label>
                    <textarea placeholder="Remark Here" class="form-control " name="description" rows="1" cols="50" required></textarea>
                </div>

                <div class="col-xxl-4 col-md-4 gy-3 ">
                    <label class="form-label"> Upload <span class="required"></span></label>
                    <input type="file" class="form-control upload_document" id="" placeholder="" name="document_upload" value="" />
                    <span class="form-text">Supported formats:PDF, PNG, JPG, JPEG Upto 1MB</span>
                </div>
                <div class="row">
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary" style="margin: 16px;">Submit</button>

                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
<!-- For operator(2,3,4,5,6) -->
@else
<form method="post" enctype="multipart/form-data" id="registration" action="{{ route('superadmin.help_desk.cbhelpdesksave') }}" novalidate>
    @csrf

    <div class="tab-content py-2 custom-tab-content">
        <div class="tab-pane fade show active" id="step1">
            <div class="card">
                <div class="card-header align-items-center d-flex">
                    <div class="flex-shrink-0">
                        @if (session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                        @endif
                        @if (session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                        @endif
                        @if ($errors)
                        @foreach ($errors->all() as $error)
                        <div class="alert alert-danger">{{ $error }}</div>
                        @endforeach
                        @endif
                    </div>
                </div>
            </div>
            <div class="row white-inner">
                <input type="hidden" id="operator" name="issue_related_to" value="operator">
                <div class="col-xxl-4 col-md-4 gy-3 ope-reg">
                    <div>
                        <label class="form-label">Enter Operator Registration No: <span class="required">*</span></label>
                        @if(!empty(Auth::user()->registration_no))
                        <input type="text" class="form-control" name="registration_number" value="{{Auth::user()->registration_no}}" required readonly>
                        @else
                        <input type="text" class="form-control" name="registration_number" value="">
                        @endif
                    </div>
                </div>
                <div class="col-xxl-4 col-md-4 gy-3 ope-reg">
                    <div>
                        <label class="form-label">Issue Type : <span class="required">*</span></label>
                        <select class="form-select issue_type" name="ope_ref_issue_type_id" id="" required>
                            <option value="">-Select- </option>
                            @foreach (getIssueTypeByOpe() as $val)
                            <option value="{{ $val->id }}">{{ $val->issue_name }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="col-xxl-4 col-md-4 gy-3">
                    <div>
                        <label class="form-label">Sub Issue Type : <span class="required">*</span></label>
                        <select class="form-select sub_issue_type" name="ref_sub_issue_type_id" id="" required>
                            <option value="">-Select- </option>
                            {{-- @foreach (getSubIssueType() as $val)
                            <option value="{{ $val->id }}">{{ $val->sub_issue_name }}</option>
                            @endforeach --}}
                        </select>
                    </div>
                </div>
                <div class="col-xxl-4 col-md-4 gy-3 ">
                    <label class="form-label">Description/Justification: <span class="required">*</span></label>
                    <textarea placeholder="Remark Here" class="form-control " name="description" rows="1" cols="50" required></textarea>
                </div>

                <div class="col-xxl-4 col-md-4 gy-3 ">
                    <label class="form-label"> Upload <span class="required"></span></label>
                    <input type="file" class="form-control upload_document" id="" placeholder="" name="document_upload" value="" />
                    <span class="form-text">Supported formats:PDF Upto 1MB</span>
                </div>
                <div class="row">
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary" style="margin: 16px;">Submit</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
@endif
</div>
      </div>
    </div>
  </div>
</div>





        <!-- <div class="row white-inner justify-content-end">   
                    <div class="col-10 col-xxl-6 col-md-4">
                        <div>
                            <label class="form-label">Issue Related : <span class="required">*</span></label>
                            <input type="radio" id="cb" name="issue_related_to" value="cb" checked>
                            <label for="cb">CB</label>
                            <input type="radio" id="operator" name="issue_related_to" value="operator">
                            <label for="operator">Operator</label>
                        </div>


                    </div>
                    <div class="col-2 col-xxl-6 col-md-4">

                        <a href="{{route('superadmin.search')}}" class="btn btn-primary" style="float: right">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                class="bi bi-search" viewBox="0 0 16 16">
                                <path
                                    d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
                            </svg>


                        </a>

                    </div>

                </div> -->


        <!-- <div class="row white-inner">
                    <div class="col-xxl-3 col-md-4 gy-3 ope-reg d-none">
                        <div>
                            <label class="form-label">Enter Operator Registration No: <span
                                    class="required">*</span></label>
                            <input type="text" class="form-control" name="registration_number" value="" required>

                        </div>
                    </div> -->
        <!-- <div class="col-xxl-3 col-md-4 gy-3 ope-reg d-none">
                        <div>
                            <label class="form-label">Issue Type : <span class="required">*</span></label>
                            <select class="form-select issue_type" name="ope_ref_issue_type_id" id="" required>
                                <option value="">-Select- </option>
                                @foreach (getIssueTypeByOpe() as $val)
                                <option value="{{ $val->id }}">{{ $val->issue_name }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div> -->
        <!-- <div class="col-xxl-3 col-md-4 gy-3 cb-reg">
                        <div>
                            <label class="form-label">Issue Type: <span class="required">*</span></label>
                            <select class="form-select issue_type" name="ref_issue_type_id" id="change_dive" required>
                                <option value="">-Select- </option>
                                @foreach (getIssueType() as $val)
                                <option value="{{ $val->id }}">{{ $val->issue_name }}</option>
                                @endforeach

                            </select>
                        </div>
                    </div> -->


        <!-- <div class="col-xxl-3 col-md-4 gy-3">
                        <div>
                            <label class="form-label">Sub Issue Type : <span class="required">*</span></label>
                            <select class="form-select sub_issue_type" name="ref_sub_issue_type_id" id="" required>
                                <option value="">-Select- </option>
                                {{-- @foreach (getSubIssueType() as $val)
                                <option value="{{ $val->id }}">{{ $val->sub_issue_name }}</option>
                                @endforeach --}}
                            </select>
                        </div>
                    </div> -->

        <!-- <div class="col-xxl-3 col-md-4 gy-3 ">
                        <label class="form-label">Description/Justification: <span class="required">*</span></label>

                        <textarea placeholder="Remark Here" class="form-control " name="description" rows="1"
                            cols="50" required></textarea> -->
        <!-- <textarea placeholder="Remark Here" class="form-control customtextarea" name="description" maxlength="50 "></textarea> -->

        <!-- </div> -->

        {{-- <div class="col-xxl-3 col-md-4 gy-3 ">
                        <div>
                            <label class="form-label">Required Document: </label><br>
                            <!-- <label class="form-label"> Document Name <span class="required">*</span></label> -->

                            <select class="form-select" name="ref_document_id" id="">
                                <option value="">Select </option>

                                <option value="7">FSSAI License</option>
                                <option value="3">PAN</option>
                                <option value="9">New FSSAI License</option>
                                <option value="8">Other</option>
                            </select>

                        </div>
                    </div>--}}

        <!-- <div class="col-xxl-3 col-md-4 gy-3 ">
                        <label class="form-label"> Upload <span class="required"></span></label>

                        <input type="file" class="form-control upload_document" id="" placeholder="" name="document_upload" value="" />
                        <span class="form-text">Supported formats:PDF, PNG, JPG, JPEG Upto 1MB</span>
                    </div>
                    <div class="row">


                        <div class="text-center">
                            <button type="submit" class="btn btn-primary" style="margin: 16px;">Submit</button>

                        </div>
                    </div>
                </div> -->
    </div>
    </div>
</form>
<!-- For operator(2,3,4,5,6) -->
@else
<form method="post" enctype="multipart/form-data" id="registration" action="{{ route('superadmin.help_desk.cbhelpdesksave') }}" novalidate>
    @csrf

    <div class="tab-content py-2 custom-tab-content">
        <div class="tab-pane fade show active" id="step1">
            <div class="card">
                <div class="card-header align-items-center d-flex">
                    <h4 class="card-title mb-0 flex-grow-1 ">Help Desk Service</h4>
                    <div class="flex-shrink-0">
                        @if (session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                        @endif
                        @if (session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                        @endif
                        @if ($errors)
                        @foreach ($errors->all() as $error)
                        <div class="alert alert-danger">{{ $error }}</div>
                        @endforeach
                        @endif
                    </div>
                </div>

                {{-- <div class="card-body">
                        <div class="col-12">
                            <table style="padding: 5px; border: 0px;" class="table_pdf table_contact_person ope-reg d-none">
                                <tbody>
                                    @if($user)
                                    <tr>
                                        <th class="pdf_txt1">Operator Name:</th>
                                        <td class="pdf_box">{{ $user->contact_person_first_name }}</td>
                </tr>
                <tr>
                    <th class="pdf_txt1">Email Id:</th>
                    <td class="pdf_box">{{ $user->email }}</td>
                </tr>
                <tr>
                    <th class="pdf_txt1">Operator Status</th>
                    <td class="pdf_box">{{ $user->status }}</td>
                </tr>
                <tr>
                    <th class="pdf_txt1">Address:</th>
                    <td class="pdf_box">{{ $user->address }}</td>
                </tr>
                <tr>
                    <th class="pdf_txt1">Mobile Number:</th>
                    <td class="pdf_box">{{ old('email', $user->contact_person_mobile_number) }}</td>
                </tr>
                @endif
                </tbody>
                </table>
            </div>
        </div> --}}
        <div class="card-body">
            <div class="col-12">
                <table style="padding: 5px; border: 0px;" class="table_pdf table_contact_person">
                    <h4 class="card-title mb-0 flex-grow-1 ">CB Details</h4>
                    <tbody>
                        @if($user)
                        <tr>
                            <th class="pdf_txt1">Certification Body Name:</th>
                            <td class="pdf_box">{{ $user->first_name }}</td>
                        </tr>
                        <tr>
                            <th class="pdf_txt1">Email Id:</th>
                            <td class="pdf_box">{{ $user->email ?? '' }}</td>
                        </tr>
                        <tr>
                            <th class="pdf_txt1">Address:</th>
                            <td class="pdf_box">{{ $user->address }}</td>
                        </tr>
                        <tr>
                            <th class="pdf_txt1">Mobile Number:</th>
                            <td class="pdf_box">{{ old('email', $user->mobile_no) }}</td>
                            <th class=""></th>
                            <!-- <td class=""><input type="button" id="Check_Status" class="btn btn-info" value="Check Status" onclick="CheckStatus()"></td> -->
                        </tr>
                        @endif
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- <div class="row white-inner">
                    <div class="col-xxl-6 col-md-4 gy-3">
                        <div>
                            <label class="form-label">Issue Related : <span class="required">*</span></label>

                            <input type="radio" id="cb" name="issue_related_to" value="cb" checked>
                            <label for="cb">CB</label>
                            <input type="radio" id="operator" name="issue_related_to" value="operator">
                            <label for="operator">Operator</label>
                        </div>
                    </div>
                    <div class="col-6">
                        <a href="{{route('superadmin.search')}}" class="btn btn-primary" style="float: right">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                class="bi bi-search" viewBox="0 0 16 16">
                                <path
                                    d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
                            </svg>
                        </a>
                    </div>
                </div> -->

    <div class="row white-inner">
        <input type="hidden" id="operator" name="issue_related_to" value="operator">
        <div class="col-xxl-3 col-md-4 gy-3 ope-reg">
            <div>
                <label class="form-label">Enter Operator Registration No: <span class="required">*</span></label>
                @if(!empty(Auth::user()->registration_no))
                <input type="text" class="form-control" name="registration_number" value="{{Auth::user()->registration_no}}" required readonly>
                @else
                <input type="text" class="form-control" name="registration_number" value="">
                @endif
            </div>
        </div>
        <div class="col-xxl-3 col-md-4 gy-3 ope-reg">
            <div>
                <label class="form-label">Issue Type : <span class="required">*</span></label>
                <select class="form-select issue_type" name="ope_ref_issue_type_id" id="" required>
                    <option value="">-Select- </option>
                    @foreach (getIssueTypeByOpe() as $val)
                    <option value="{{ $val->id }}">{{ $val->issue_name }}</option>
                    @endforeach
                </select>
            </div>
        </div>
        <div class="col-xxl-3 col-md-4 gy-3">
            <div>
                <label class="form-label">Sub Issue Type : <span class="required">*</span></label>
                <select class="form-select sub_issue_type" name="ref_sub_issue_type_id" id="" required>
                    <option value="">-Select- </option>
                    {{-- @foreach (getSubIssueType() as $val)
                                <option value="{{ $val->id }}">{{ $val->sub_issue_name }}</option>
                    @endforeach --}}
                </select>
            </div>
        </div>
        <div class="col-xxl-3 col-md-4 gy-3 ">
            <label class="form-label">Description/Justification: <span class="required">*</span></label>
            <textarea placeholder="Remark Here" class="form-control " name="description" rows="1"
                cols="50" required></textarea>
            <!-- <textarea placeholder="Remark Here" class="form-control customtextarea" name="description" maxlength="50 "></textarea> -->
        </div>

        {{-- <div class="col-xxl-3 col-md-4 gy-3 ">
                        <div>
                            <label class="form-label">Required Document: </label><br>
                            <!-- <label class="form-label"> Document Name <span class="required">*</span></label> -->
                            <select class="form-select" name="ref_document_id" id="">
                                <option value="">Select </option>
                                <option value="7">FSSAI License</option>
                                <option value="3">PAN</option>
                                <option value="9">New FSSAI License</option>
                                <option value="8">Other</option>
                            </select>
                        </div>
                    </div>--}}

        <div class="col-xxl-3 col-md-4 gy-3 ">
            <label class="form-label"> Upload <span class="required"></span></label>
            <input type="file" class="form-control upload_document" id="" placeholder="" name="document_upload" value="" />
            <span class="form-text">Supported formats:PDF Upto 1MB</span>
        </div>
        <div class="row">
            <div class="text-center">
                <button type="submit" class="btn btn-primary" style="margin: 16px;">Submit</button>
            </div>
        </div>
    </div>
    </div>
    </div>
</form>
@endif
<div class="tab-content py-4 custom-tab-content">
    <div class="tab-pane fade show active" id="step1">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1 text-center">
                    Help Desk Service
                </h4>
                <div class="flex-shrink-0">
                    @if (session('error'))
                    <div class="alert alert-danger">
                        {{ session('error') }}
                    </div>
                    @endif
                    @if (session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                    @endif
                    @if ($errors)
                    @foreach ($errors->all() as $error)
                    <div class="alert alert-danger">{{ $error }}</div>
                    @endforeach
                    @endif
                </div>
            </div>
            <!-- end card header -->


        </div>

        <!-- <div class="row white-inner">
            <div class="col-xxl-3 col-md-3 gy-3">
                <div>
                    <label class="form-label">Issue No/Regitration No: </label>
                    <input type="text" class="form-control" name="registration_no" id="registration_no"
                        value="">

                </div>
            </div>
            <div class="col-xxl-3 col-md-3 gy-3 ">
                <div>
                    <label class="form-label">Status: </label>
                    <select class="form-select status" name="status" id="" required>
                        <option value="">-Select- </option>

                        <option value="open">Open</option>


                    </select>
                </div>
            </div>

            <div class="col-xxl-3 col-md-3 gy-3 ">
                <label class="form-label">From Date </label>

                <input type="date" class="form-control" name="from_date" value="" id="from_date" required>


            </div>
            <div class="col-xxl-3 col-md-3 gy-3 ">
                <label class="form-label">To Date </label>

                <input type="date" class="form-control" name="to_date" value="" id="to_date" required>


            </div>

            <div class="row">
                <div class="text-center">
                    <button type="submit" id="searchBtn" class="btn btn-primary"
                        style="margin: 16px;">Search</button>
                </div>
            </div>

        </div> -->
    </div>
</div>
{{-- </form> --}}
<!-- <table id="searchResultsTable" class="table table-bordered dt-responsive nowrap table-striped align-middle"
    style="width:100%">
    <thead>
        <tr>
            <th>S.No.</th>
            <th>Registration No</th>
            <th>Issue Related To</th>
            <th>Description</th>
            <th>Status</th>

        </tr>
    </thead>
    <tbody>

        <tr>
            <td colspan="5">No Record found.</td>

        </tr>
    </tbody>
</table> -->
@push('script')
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    var table = $('#online').DataTable({
        dom: 'Bfrtip',
        pageLength: 10,
        lengthMenu: [
            [5, 5, 5, -1],
            [5, 5, 5, "All"]
        ],
        processing: true,
        serverSide: true,
        ajax: {
            url: '{{ route("mySuperadmin.helpdesktickets") }}',
            type: 'GET',
            data: function(d) {
                d._token = "{{ csrf_token() }}";
                d.operator_status = $("#search").val();
                // Send operator_status parameter
            }
        },

        columns: [{
                data: 'DT_RowIndex',
                name: 'DT_RowIndex',
                orderable: true
            },
            {
                data: 'issue_id',
                name: 'issue_id',
                orderable: true
            },
            // {
            //     data: 'registration_number',
            //     name: 'registration_number',
            //     orderable: true
            // },

            {
                data: 'issue_related_to',
                name: 'issue_related_to',
                orderable: true
            },

            // {
            //     data: 'at_user_id',
            //     name: 'at_user_id',
            //     orderable: true
            // },
            {
                data: 'ref_issue_type_id',
                name: 'ref_issue_type_id',
                orderable: true
            },

            {
                data: 'ref_sub_issue_type_id',
                name: 'ref_sub_issue_type_id',
                orderable: true
            },
            
            {
                data: 'status',
                name: 'status',
                orderable: true
            },
            {
                data: 'from_date',
                name: 'from_date',
                orderable: true
            },

            {
                data: 'action',
                name: 'name',
                orderable: true
            },
        ],
        buttons: [

            // {
            //     extend: 'excelHtml5 ',
            //     title: function() {
            //         return "Online Applications List";
            //     },
            //     titleAttr: 'CSV REPORTS'
            // },
            {
                extend: 'pdfHtml5',
                title: function() {
                    return "Ticket list";
                },
                orientation: 'landscape',
                pageSize: 'A4',
                titleAttr: 'Ticket list'
            }
        ]
    });
</script>


@endpush

<script>
    $(document).ready(function() {


    });

    $('#searchBtn').click(function() {
        // alert('aaa');
        $.ajax({

            url: "{{ route('superadmin.searchstore') }}",
            method: 'POST',
            data: {
                registration_no: $('#registration_no').val(),
                from_date: $('#from_date').val(),
                to_date: $('#to_date').val(),
                status: $('.status').val(),

            },

            success: function(response) {
                console.log(response);
                // return false;
                $('#searchResultsTable tbody').empty();
                if (response.msg == 'success') {
                    // $.each(response.data, function(index, result) {

                    //     $('#searchResultsTable tbody').append('<tr><td>' + result.data[i]['registration_no'] + '</td> <td>Registration No</td> <td>Issue Related To</td> <td>Description</td> <td>Status</td></tr>');
                    // });

                    var tbody = '';
                    for (var i = 0, j = 1; i < response.data.length; i++) {
                        //   console.log(response.data[i]['registration_number']);
                        tbody += '<tr><td>' + j++ + '</td><td>' + response.data[i]['registration_no'] + '</td><td>' + response.data[i]['issue_related_to'] + '</td><td>' + response.data[i]['description'] + '</td><td>' + response.data[i]['status'] + '</td></tr>';
                    }
                    $('#searchResultsTable tbody').append(tbody);
                }
                if (response.msg == 'error') {
                    $('#searchResultsTable tbody').append('<tr><td colspan="5">No Data found.</td></tr>');
                }

            },

            error: function(xhr, status, error) {

                consele.error(xhr.responseText);
            }
        });
    });
</script>
<script>

        $("input:radio[name='issue_related_to']").change(function () {
            var issue_rel = $(this).val();
            //  console.log(issue_rel);
            if (issue_rel === 'operator') {
			
                $('.ope-reg').removeClass('d-none');
                $('.cb-reg').addClass('d-none');
            } else {
				
                $('.ope-reg').addClass('d-none');
                $('.cb-reg').removeClass('d-none');
            }
        });

        $('.issue_type').on('change', function () {
            var th = $(this);
            var id = this.value;

            $.ajax({
                url: '{{ route("superadmin.help_desk.getSubIssueType") }}',
                type: "POST",
                data: {
                    id: id,
                },
                dataType: 'json',
                success: function (result) {
                    console.log(result);
                    if (result) {
                        th.closest('.row').find('.sub_issue_type').html(result);
                    }
                }
            });
        });


        $('.upload_document').on('change', function() {
            var $this = $(this);
            var file = $this[0].files[0];
            var fileType = file.type;
            var fileSize = file.size;
            var allowedTypes = ['application/pdf','image/jpeg', 'image/jpg', 'image/png'];

            // Check for file type
            if (!allowedTypes.includes(fileType)) {
                Swal.fire({
                    icon: 'error',
                    title: 'Invalid File Extension',
                    text: 'Please upload PDF,JPEG, JPG, PNG  only.',
                });
                $this.val("");
                return false;
            }

            // Check for file size
            if (fileSize > 1000000) { // 2 MB in bytes
                Swal.fire({
                    icon: 'error',
                    title: 'File Size Too Large',
                    text: 'Please upload files of size 1 MB or less only.',
                });
                $this.val("");
                return false;
            }
        });
		
		function CheckStatus(){
			$('#checkStatustickets').modal('show');
		}
    </script>


@endsection
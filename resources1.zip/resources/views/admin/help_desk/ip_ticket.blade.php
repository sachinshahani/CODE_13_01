@extends('admin.layouts.app')
@section('content')

@php
$all_user = App\Models\User::where('id',Auth::id())->first();

$opr = getOperatorTypeById($all_user->ref_operator_type_id) . ' ' . ' Tickets';

@endphp
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">{{$opr}} </h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">{{$opr}} </li>
                </ol>
            </div>

        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0" style="float: left">

                    {{$opr}}

                </h5>


            </div>
            <div class="card-body table-responsive">
                <table id="online" class="table table-bordered table-striped align-middle" style="width:100%">
                    <thead>
                        <tr>
                            <th>S.No.</th>
                            <th>Ticket No</th>
                            <th>Issue Type</th>
                            <th>Sub Issue Type</th>
                            <th>Status</th>
                            <th>Ticket Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!--end col-->
</div>

@endsection


@push('script')
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    var table = $('#online').DataTable({
        dom: 'Bfrtip',
        pageLength: 10,
        lengthMenu: [
            [5, 5, 5, -1],
            [5, 5, 5, "All"]
        ],
        processing: true,
        serverSide: true,
        ajax: {
            url: '{{ route("ticketIP") }}',
            type: 'GET',
            data: function(d) {
                d._token = "{{ csrf_token() }}";
                d.operator_status = $("#search").val();
                // Send operator_status parameter
            }
        },

        columns: [{
                data: 'DT_RowIndex',
                name: 'DT_RowIndex',
                orderable: true
            },
            {
                data: 'ticket_no',
                name: 'ticket_no',
                orderable: true
            },

            {
                data: 'issue_type',
                name: 'issue_type',
                orderable: true
            },

            {
                data: 'sub_issue',
                name: 'sub_issue',
                orderable: true
            },
            {
                data: 'status',
                name: 'status',
                orderable: true
            },

            {
                data: 'ticket_date',
                name: 'ticket_date',
                orderable: true
            },

            {
                data: 'action',
                name: 'name',
                orderable: false
            },
        ],
        buttons: [

            // {
            //     extend: 'excelHtml5 ',
            //     title: function() {
            //         return "Online Applications List";
            //     },
            //     titleAttr: 'CSV REPORTS'
            // },
            {
                extend: 'pdfHtml5',
                title: function() {
                    return "Ticket list";
                },
                orientation: 'landscape',
                pageSize: 'A4',
                titleAttr: 'Ticket list'
            }
        ]
    });
</script>


@endpush
@extends('admin.layouts.app')

@section('content')
<style> .customtextarea { height: 80px; } </style> <!-- start page title --> <div class="row"> <div class="col-12"> <div
    class="page-title-box d-sm-flex align-items-center justify-content-between"> <h4 class="mb-sm-0">Help Desk</h4> <div
    class="page-title-right"> <ol class="breadcrumb m-0"> <li class="breadcrumb-item"><a
        href="javascript: void(0);">Dashboard</a></li>
    <li class="breadcrumb-item active">Help Desk Tickets</li>
    </ol>
    </div>
    </div> </div> </div>
    <div id="cbForm" style="display: block">
        <form method="post" enctype="multipart/form-data" id="registration" action="{{route('superadmin.help_desk.cbhelpdesksave')}}">
             @csrf 
             <div class="tab-content py-4
            custom-tab-content"> <div class="tab-pane fade show active" id="step1">
            <div class="card"> <div class="card-header align-items-center d-flex"> <h4
                class="card-title mb-0 flex-grow-1 text-center">
                Help Desk Service
                </h4>
                <div class="flex-shrink-0">
                    @if (session('error'))
                    <div class="alert alert-danger">
                    {{ session('error') }}
                    </div>
                    @endif
                    @if (session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                    @endif
                    @if ($errors)
                    @foreach ($errors->all() as $error)
                    <div class="alert alert-danger">{{ $error }}</div>
                    @endforeach
                    @endif
                </div>
            </div>



            <!-- end card header -->
            <div class="card-body">

                <div class="col-12">

                    <table style="padding: 10px; border: 0px;" class="table_pdf table_contact_person">

                        <tbody>
                            <tr>
                                <th class="pdf_txt1">Certification Body:</th>
                                <td class="pdf_box">demo name</td>
                            </tr>
                            <tr>
                                <th class="pdf_txt1">Email Id:</th>
                                <td class="pdf_box">demo@gmail.com</td>
                            </tr>

                            <tr>
                                <th class="pdf_txt1">Address:</th>
                                <td class="pdf_box">demo address</td>
                            </tr>
                            <tr>
                                <th class="pdf_txt1">Mobile Number:</th>
                                <td class="pdf_box">9999999999</td>
                            </tr>


                        </tbody>
                    </table>

                </div>




            </div>

    </div>
    <div class="row white-inner">
        <div class="col-xxl-6 col-md-4 gy-3">
            <div>
                <label class="form-label">Issue Related : <span class="required">*</span></label>


            </div>
        </div>
        <div class="col-xxl-6 col-md-4 gy-3">
            <div>
                <input type="radio" id="cb" name="add_type" value="yes" checked>
                <label for="cb">CB</label>
                <input type="radio" id="operator" name="add_type" value="no">
                <label for="operator">Operator</label>
            </div>
        </div>
        <div class="col-xxl-6 col-md-4 gy-3">
            <div>
                <label class="form-label">Issue Type : <span class="required">*</span></label>
            </div>
        </div>
        <div class="col-xxl-3 col-md-2 gy-3">
            <div>

                <select class="form-select state" name="ref_issue_type_id" id="change_dive" required>
                    <option value="">Select </option>
                    <option value="TechnicalIssue">Technical Issue</option>
                    <option value="Query">Query</option>
                </select>
            </div>
        </div>
        <div class="col-xxl-6 col-md-4 gy-3">
            <div>
                <label class="form-label">Sub Issue Type : <span class="required">*</span></label>
            </div>
        </div>

        <div class="col-xxl-2 col-md-2 gy-3  name-change">
            <div>

                <select class="form-select state" name="ref_sub_issue_type_id" id="" >
                    <option value="">Select </option>
                    <option value="PDF not opening">PDF not opening</option>
                    <option value="Technical Error">Technical Error</option>
                    <option value="District/Taluka/Village not found">District/Taluka/Village not found
                    </option>
                </select>
            </div>
        </div>

        <div class="col-xxl-2 col-md-2 gy-3 address-change d-none">
            <div>

                <select class="form-select state" name="ref_sub_issue_type_id" id="" >
                    <option value="">Select </option>
                    <option value="NPOP/NOP">NPOP/NOP</option>
                    <option value="Tracenet">Tracenet</option>
                    <option value="HSCODE">HSCODE</option>
                </select>
            </div>
        </div>

        <div class="col-xxl-6 col-md-4 gy-3">
            <div>
                <label class="form-label">Description/Justification: <span class="required">*</span></label>
            </div>
        </div>

        <div class="col-xxl-6 col-md-2 gy-3">

            <textarea placeholder="Remark Here" class="form-control customtextarea" name="description"
                maxlength="100"></textarea>

        </div>

        <div class="col-xxl-6 col-md-4 gy-3">
            <div>
                <label class="form-label">Required Document: <span class="required">*</span></label>
            </div>
        </div>
        <div class="col-xxl-6 col-md-2 gy-3">

            <table>
                <tr>
                    <th>Document Name</th>
                    <th>Upload</th>
                    <!-- <th>Action</th> -->
                </tr>
                <tr>
                    <td>
                        <select class="form-select state" name="" id="" >
                            <option value="">Select </option>

                            <option value="Supporting Documents required">Supporting Documents required
                            </option>
                        </select>

                    </td>
                    <td class="col-xxl-5">
                        <input type="file" class="form-control" id="" placeholder="" name="document_upload" value="" />

                    </td>
                    <!-- <td>
                                                <a href="" id="uploadButton">Upload</a>

                                                </td> -->
                </tr>

            </table>

        </div>

    </div>

    <div class="row">
        <div class="col-lg-12 gy-4 text-center">

            <button type="submit" class="btn btn-primary" id="submitbtn">Submit</button>

        </div>

    </div>


    </div>
    </div>
    </form>

    <form>
        <div class="row white-inner">
            <div class="col-xxl-2 col-md-4 gy-3">
                <div>
                    <label class="form-label">Issue ID/Registration No : <span class="required">*</span></label>


                </div>
            </div>
            <div class="col-xxl-1 col-md-4 gy-3">
                <div>

                    <input type="text" class="form-control" id="" name="" value="">


                </div>
            </div>
            <div class="col-xxl-1 col-md-4 gy-3">
                <div>
                    <label class="form-label">Status: <span class="required">*</span></label>
                </div>
            </div>
            <div class="col-xxl-2 col-md-2 gy-3">
                <div>

                    <select class="form-select state" name="" id="change_dive">
                        <option value="">Select </option>
                        <option value="open">Open</option>

                    </select>
                </div>
            </div>
            <div class="col-xxl-1 col-md-4 gy-3">
                <div>
                    <label class="form-label">From Date: <span class="required">*</span></label>
                </div>
            </div>

            <div class="col-xxl-1 col-md-2 gy-3  name-change">
                <div>

                    <input type="text" class="form-control" id="" name="" value="">
                </div>
            </div>

            <div class="col-xxl-1 col-md-4 gy-3">
                <div>
                    <label class="form-label">To Date: <span class="required">*</span></label>
                </div>
            </div>

            <div class="col-xxl-1 col-md-2 gy-3  name-change">
                <div>

                    <input type="text" class="form-control" id="" name="" value="">
                </div>
            </div>


        </div>
        <div class="text-center">
            <button type="submit" class="btn btn-primary" id="submitbtn">Search</button>
        </div>
    </form>

    </div>


    <!---------operator form ----------->
    <form>

        <div id="operatorForm" style="display: none">
            <div class="card-body">

                <div class="col-12">

                    <table style="padding: 10px; border: 0px;" class="table_pdf table_contact_person">

                        <tbody>
                            <tr>
                                <th class="pdf_txt1">Certification Body:</th>
                                <td class="pdf_box">demo name</td>
                            </tr>
                            <tr>
                                <th class="pdf_txt1">Email Id:</th>
                                <td class="pdf_box">demo@gmail.com</td>
                            </tr>

                            <tr>
                                <th class="pdf_txt1">Address:</th>
                                <td class="pdf_box">demo address</td>
                            </tr>
                            <tr>
                                <th class="pdf_txt1">Mobile Number:</th>
                                <td class="pdf_box">9999999999</td>
                            </tr>


                        </tbody>
                    </table>

                </div>




            </div>


            <div class="row white-inner">
                <div class="col-xxl-6 col-md-4 gy-3">
                    <div>
                        <label class="form-label">Enter Operator Regitration No: <span class="required">*</span></label>


                    </div>
                </div>
                <div class="col-xxl-3 col-md-4 gy-3">
                    <div>
                        <input type="text" class="form-control" name="" value="">

                    </div>
                </div>
                <div class="col-xxl-6 col-md-4 gy-3">
                    <div>
                        <label class="form-label">Issue Type : <span class="required">*</span></label>
                    </div>
                </div>
                <div class="col-xxl-3 col-md-2 gy-3">
                    <div>

                        <select class="form-select state" name="issue_name" id="oper" >
                            <option value="">Select </option>
                            <option value="TechnicalIssueop">Technical Issue</option>
                            <option value="Correctionop">Change/correction Request</option>
                            <option value="Queryop">Query</option>
                        </select>
                    </div>
                </div>
                <div class="col-xxl-6 col-md-4 gy-3">
                    <div>
                        <label class="form-label">Sub Issue Type : <span class="required">*</span></label>
                    </div>
                </div>

                <div class="col-xxl-2 col-md-2 gy-3  technical">
                    <div>

                        <select class="form-select state" name="sub_issue_name" id="">
                            <option value="">Select </option>
                            <option value="PDF not opening">PDF not opening</option>
                            <option value="Technical Error">Technical Error</option>
                            <option value="District/Taluka/Village not found">District/Taluka/Village not found
                            </option>
                        </select>
                    </div>
                </div>

                <div class="col-xxl-2 col-md-2 gy-3 query d-none">
                    <div>

                        <select class="form-select state" name="sub_issue_name" id="" >
                            <option value="">Select </option>
                            <option value="NPOP/NOP">NPOP/NOP</option>
                            <option value="Tracenet">Tracenet</option>
                            <option value="HSCODE">HSCODE</option>
                        </select>
                    </div>
                </div>
                <!---select doc req---->
                <div class="col-xxl-2 col-md-2 gy-3 correction d-none ">
                    <div>   

                        <select class="form-select state" name="sub_issue_name" id="doc" >
                            <option value="">Select </option>
                            <option value="Processing">Processing Unit License Update</option>
                            <option value="Tracenet">Request for Extension of Discontinued Scope</option>
                            <option value="HSCODE">Revert Renewal Process</option>
                            <option value="Correction">Name/Address Change/Correction</option>
                            <option value="BatchUpdation">Batch Updation</option>
                        </select>
                    </div>
                </div>
                <!---select doc req end---->
                <div class="col-xxl-6 col-md-4 gy-3">
                    <div>
                        <label class="form-label">Description/Justification: <span class="required">*</span></label>
                    </div>
                </div>

                <div class="col-xxl-6 col-md-2 gy-3">

                    <textarea placeholder="Remark Here" class="form-control customtextarea" name="remarks"
                        maxlength="100"></textarea>

                </div>

                <div class="col-xxl-6 col-md-4 gy-3">
                    <div>
                        <label class="form-label">Required Document: <span class="required">*</span></label>
                    </div>
                </div>
                 
                <!---1st Document requ --->
                <div class="col-xxl-6 col-md-2 gy-3 NPOPNOP-change ">

                    <table>
                        <tr>
                            <th>Document Name</th>
                            <th>Upload</th>
                            <!-- <th>Action</th> -->
                        </tr>
                        <tr>
                            <td>
                                <select class="form-select state" name="" id="">
                                    <option value="">Select </option>

                                    <option value="Supporting Documents required">FSSAI License
                                    </option>
                                    <option value="Supporting Documents required">PAN
                                    </option>
                                    <option value="Supporting Documents required">New FSSAI License
                                    </option>
                                    <option value="Supporting Documents required">Other
                                    </option>
                                </select>

                            </td>
                            <td class="col-xxl-5">
                                <input type="file" class="form-control" id="" placeholder="" name="c" value="" />

                            </td>
                            <!-- <td>
                                                <a href="" id="uploadButton">Upload</a>

                                                </td> -->
                        </tr>

                    </table>

                </div>

                <!---1st end--->

                <!--2nd-->
                <div class="col-xxl-6 col-md-2 gy-3 Tracenet-change ">

                    <table>
                        <tr>
                            <th>Document Name</th>
                            <th>Upload</th>
                            <!-- <th>Action</th> -->
                        </tr>
                        <tr>
                            <td>
                                <select class="form-select state" name="" id="" >
                                    <option value="">Select </option>

                                    <option value="Supporting Documents required">Other
                                    </option>

                                </select>

                            </td>
                            <td class="col-xxl-5">
                                <input type="file" class="form-control" id="" placeholder="" name="c" value="" />

                            </td>
                            <!-- <td>
                                                <a href="" id="uploadButton">Upload</a>

                                                </td> -->
                        </tr>

                    </table>

                </div>

                <!---2nd end--->

                <!---3rd---->
                <div class="col-xxl-6 col-md-2 gy-3 HSCODE-change ">

                    <table>
                        <tr>
                            <th>Document Name</th>
                            <th>Upload</th>
                            <!-- <th>Action</th> -->
                        </tr>
                        <tr>
                            <td>
                                <select class="form-select state" name="" id="">
                                    <option value="">Select </option>

                                    <option value="Supporting Documents required">a.Other
                                    </option>

                                </select>

                            </td>
                            <td class="col-xxl-5">
                                <input type="file" class="form-control" id="" placeholder="" name="c" value="" />

                            </td>
                            <!-- <td>
                            <a href="" id="uploadButton">Upload</a>

                            </td> -->
                        </tr>

                    </table>

                </div>
                <!---3rd end--->

                <!---4th---->
                <div class="col-xxl-6 col-md-2 gy-3 Correction-status">

                    <table>
                        <tr>
                            <th>Document Name</th>
                            <th>Upload</th>
                            <!-- <th>Action</th> -->
                        </tr>
                        <tr>
                            <td>
                                <select class="form-select state" name="" id="">
                                    <option value="">Select </option>

                                    <option value="Supporting Documents required">FSSAI License
                                    </option>
                                    <option value="Supporting Documents required">PAN
                                    </option>

                                    <option value="Supporting Documents required">Other
                                    </option>
                                </select>

                            </td>
                            <td class="col-xxl-5">
                                <input type="file" class="form-control" id="" placeholder="" name="c" value="" />

                            </td>
                            <!-- <td>
                            <a href="" id="uploadButton">Upload</a>

                            </td> -->
                        </tr>

                    </table>

                </div>
                <!-----4th end--->

                <!----5th---->
                <div class="col-xxl-6 col-md-2 gy-3 BatchUpdation-addition ">

                    <table>
                        <tr>
                            <th>Document Name</th>
                            <th>Upload</th>
                            <!-- <th>Action</th> -->
                        </tr>
                        <tr>
                            <td>
                                <select class="form-select state" name="" id="">
                                    <option value="">Select </option>

                                    <option value="Supporting Documents required">b.Other
                                    </option>

                                </select>

                            </td>
                            <td class="col-xxl-5">
                                <input type="file" class="form-control" id="" placeholder="" name="c" value="" />

                            </td>
                            <!-- <td>
                            <a href="" id="uploadButton">Upload</a>

                            </td> -->
                        </tr>

                    </table>

                </div>
                <!----5th end--->



            </div>



            <div class="text-center">
                <button type="submit" class="btn btn-primary" id="submitbtn">
                    Submit
                </button>
            </div>


        </div>
    </form>
    <!---------operator form end ----------->

    <script>

$(document).ready(function() {
    // $(".name-change, .address-change").addClass("d-none");  

    $("#change_dive").change(function() {
        var selectedOption = $(this).val();
        
        $(".name-change, .address-change").addClass("d-none");  

        if (selectedOption === "TechnicalIssue") {
            $(".name-change").removeClass("d-none");  
        } else if (selectedOption === "Query") {
            $(".address-change").removeClass("d-none");  
        }
    });
});

//-------for operator------//
$(document).ready(function() {
    // $(".name-change, .address-change").addClass("d-none");  

    $("#oper").change(function() {
        var selectedOption = $(this).val();
        
        $(".technical, .query, .correction").addClass("d-none");  

        if (selectedOption === "TechnicalIssueop") {
            $(".technical").removeClass("d-none");  
    
        } else if (selectedOption === "Queryop") {
            $(".query").removeClass("d-none");  
        }
         
        else if (selectedOption === "Correctionop") {
            $(".correction").removeClass("d-none");
        }
        
    });
});

//-------for operator end------//

//----------for operator document require------
$(document).ready(function() {
    
    $(".NPOPNOP-change, .Tracenet-change, .HSCODE-change, .Correction-status, .BatchUpdation-addition").hide();


    $("#doc").change(function() {
        var selectedOption = $(this).val();
        // alert(selectedOption);
        
        $(".NPOPNOP-change, .Tracenet-change, .HSCODE-change, .Correction-status, .BatchUpdation-addition").hide();

        if (selectedOption === "Processing") {
            $(".NPOPNOP-change").show();
        } else {
            $(".NPOPNOP-change").hide();
        }
        
        if (selectedOption === "Tracenet") {
            $(".Tracenet-change").show();
        } else {
            $(".Tracenet-change").hide();
        } 
        if (selectedOption === "HSCODE") {
            $(".HSCODE-change").show();
        } else{
            $(".HSCODE-change").hide();
        }
        if (selectedOption === "Correction") {
            $(".Correction-status").show();
        } else {
            $(".Correction-status").hide();
        }
        if (selectedOption === "BatchUpdation") {
            $(".BatchUpdation-addition").show();
        } else{
            $(".BatchUpdation-addition").hide();
        }
       
    });

});


//-----for operator document require end-------//


//--- for cb and operator radio button--------//
$(document).ready(function() {
   
    $('#cbForm').show();
    $('#operatorForm').hide();

   
    $('#cb').change(function() {
        if ($(this).is(':checked')) {
            $('#cbForm').show();
            $('#operatorForm').hide();
        }
    });

   
    $('#operator').change(function() {
        if ($(this).is(':checked')) {
            $('#cbForm').hide();
            $('#operatorForm').show();
        }
    });
});





</script>












    @endsection
@extends('admin.layouts.app')
@section('content')
<style>
    body {
        margin: 0px;
        padding: 0px;
        font-family: "Segoe UI";
    }

    .maindiv {
        width: 80%;
        margin: 0 auto;
    }

    .pdf_maindiv {
        border: 1px solid #cccccc;
        width: 100%;
        float: left;
        padding: 3%;
    }

    .pdf_heading {
        font-size: 20px;
        color: #000;
        padding: 26px 0 12px 0px;
        position: relative;
        width: 100%;
        float: left;
    }

    .brd_heading {
        border-bottom: 2px solid #ee5e24;
        padding-bottom: 8px;
        padding-right: 8px;
        width: 60px;
    }

    .pdf_input1 {
        background: #eeeeee;
    }

    .pdf_txt1 {
        color: #000;
        font-size: 14px;
        width: 45%;
        float: left;
        padding-bottom: 10px;
        font-weight: bold;
    }

    .pdf_box {
        color: #000;
        font-size: 14px;
        width: 55%;
        float: left;
        padding-bottom: 10px;
    }

    .table_pdf {
        width: 100%;
    }

    @media print {
        /*
                   .pdf_heading {
                    font-size: 20px;
                    color: #000;
                    padding: 26px 0 12px 0px;
                    position: relative;
                    width: 100%;
                    float: left;
                    -webkit-print-color-adjust: exact !important;
                    Chrome,
                    Safari color-adjust: exact !important;
                   } */

        /* .pdf_heading:before{content: ""; position: absolute; width:20px; height: 4px; background-color:#ee5e24; bottom:10px; display: block;-webkit-print-color-adjust: exact !important;    Chrome, Safari
                    color-adjust: exact !important;  } */


    }
</style>
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">View Ticket</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">View Ticket</li>
                </ol>
            </div>
        </div>
    </div>
</div>


<div class="card-body white-inner">
    <div class="row text-end">
        <div class="col-md-12">
            <div class="col-md-12"><a href="{{url()->previous()}}" class="btn btn-soft-success">Back</a></div>
        </div>
    </div>
    <div class="pdf_heading">Operator Details</div>
    <div class="pdf_maindiv white-inner">
        <!--form1 section starts here-->
        <div class="container-fluid">
            <div class="row">
                <div class="col-6">
                    <!--form1 tab starts here-->
                    <table style="padding: 10px; border: 0px;" class="table_pdf">
                        <tr>
                            <td class="pdf_txt1">Name</td>
                            <td class="pdf_box">{{$user->first_name}}</td>
                        </tr>
                        <tr>
                            <td class="pdf_txt1">Email</td>
                            <td class="pdf_box">{{$user->email}}</td>
                        </tr>
                    </table>
                    <!--form1 tab end here-->
                </div>

                <div class="col-6">

                    <!--form1 tab starts here-->
                    <table style="padding: 10px; border: 0px;" class="table_pdf">
                        <tr>
                            <td class="pdf_txt1">Mobile</td>
                            <td class="pdf_box">{{$user->mobile_no}}</td>
                        </tr>
                        <tr>
                            <td class="pdf_txt1">Address</td>
                            <td class="pdf_box">{{$user->address}}</td>
                        </tr>
                    </table>
                    <!--form1 tab end here-->
                </div>


            </div>
        </div>
    </div>
    <div class="pdf_heading">Tickets Detail(s)</div>
    <div class="pdf_maindiv white-inner">
        <!--form1 section starts here-->
        <div class="container-fluid">
            <div class="row">
                <div class="col-6">
                    <!--form1 tab starts here-->
                    <table style="padding: 10px; border: 0px;" class="table_pdf">
                        <tr>
                            <td class="pdf_txt1">Issue Type</td>
                            <td class="pdf_box">
                                {{getIssueTypeByID($res->ref_issue_type_id)}}
                            </td>
                        </tr>
                        <tr>
                            <td class="pdf_txt1">Issue Id</td>
                            <td class="pdf_box">
                                {{$res->issue_id}}
                            </td>
                        </tr>
                        <tr>
                            <td class="pdf_txt1">Forwarded By</td>
                            <td class="pdf_box">CB</td>
                        </tr>
                        <tr>
                            <td class="pdf_txt1">Forwarded On</td>
                            <td class="pdf_box">
                                {{$res->from_date}}
                            </td>
                        </tr>
                    </table>
                    <!--form1 tab end here-->
                </div>
                <div class="col-6">
                    <!--form1 tab starts here-->
                    <table style="padding: 10px; border: 0px;" class="table_pdf">
                        <tr>
                            <td class="pdf_txt1">Sub Issue Type</td>
                            <td class="pdf_box">
                                {{getSubIssueTypeByID($res->ref_sub_issue_type_id)}}
                            </td>
                        </tr>
                        <!-- <tr>
                            <td class="pdf_txt1">User Message</td>
                            <td class="pdf_box">
                                <textarea name="" id="" class="form-controler" readonly>{{$res->description}}</textarea>
                            </td>
                        </tr> -->

                        <tr>
                            <td class="pdf_txt1">Forwarded To</td>
                            <td class="pdf_box">
                                Query Team
                            </td>
                        </tr>
                        <tr>
                            <td class="pdf_txt1">Attachments</td>
                            <td class="pdf_box">
                                @if(!empty($res->document_upload)) <a target="_BLANK" href="{{ asset('public/helpDesk/' . $res->document_upload) }}" class="text-decoration-underline">See Doc</a> @else <span>No Attachment </span> @endif
                            </td>
                        </tr>
                        <tr>
                            <td class="pdf_txt1">Status </td>
                            <td class="pdf_box">
                                @if($res->status == '1')
                                Open
                                @else
                                Closed
                                @endif
                            </td>
                            </td>
                        </tr>

                        </form>
                    </table>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-1 fw-bold">
                            <th>User Message</th>
                        </div>
                        <div class="col-md-11">{{$res->description}}</div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="pdf_heading">Close Remark</div>
    <div class="pdf_maindiv white-inner">
        <!--form1 section starts here-->
        <div class="container-fluid">
            <div class="row">
                <div class="col-6">
                    <form method="post" enctype="multipart/form-data" id="query" action="{{ route('superadmin.ticketClose') }}" novalidate>
                        @csrf
                        <input type="hidden" name="query_id" value="{{$res->id}}">
                        <table style="padding: 10px; border: 0px;" class="table_pdf">
                            <tr>
                                <td>
                                    <div class="col-mf-4">
                                        <label for="">Status:</label>
                                        <select name="status" id="" class="form-select" @if($res->status == 2) disabled @endif>
                                            <option value="">Select Status</option>
                                            @foreach(statusdata() as $val)
                                            <option value="{{$val->id ?? ''}}">{{$val->status ?? ''}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </td>

                            </tr><br>
                            <tr>
                                <td class="pdf_txt1"></td><br>
                                <label for=""> Remark:</label><textarea name="close_remark" class="form-control" id="close_remark" @if(!empty($res->status == 2)) disabled @endif> {{$res->remarks}}</textarea>
                            </tr>
                </div>
                <div class="col-6">
                    <tr>
                        <td class="pdf_box"> <button class="btn btn-success" @if($res->status == 2) disabled @endif>Submit</button></td>
                    </tr>
                    </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
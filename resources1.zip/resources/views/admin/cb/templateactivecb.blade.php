<form action="{{ route('superadmin.menupermissionupdateStore') }}" method="POST" onsubmit="return validateCheckboxSelection()">
    @csrf
    <div class="modal-body">
        <div class="row">
            <div class="card">
                <div class="row">
                    <!-- Grouping results by module_name -->
                    @php
                        $groupedResults = $results->groupBy('module_name');
                    @endphp
                    
                    @foreach ($groupedResults as $moduleName => $subModules)
                        <div class="col-12 mt-3">
                           <label class="form-check-label" style="color:red">
                                {{ $moduleName }}
                            </label>
                            
                            <div class="row">
                                @foreach ($subModules as $index => $user)
                                    @if ($index > 0 && $index % 3 == 0)
                                        </div><div class="row">
                                    @endif

                                    <div class="col-4 mt-2">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="{{ $user->cb_main_id }}" id="flexCheck{{ $user->cb_main_id }}" name="cb_prm_id[]">
                                            <label class="form-check-label" for="flexCheck{{ $user->cb_main_id }}">
                                                {{ $user->sub_module_name }}
                                            </label>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
    <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Delete Permission</button>
    </div>
</form>

<script>
    function validateCheckboxSelection() {
        const checkboxes = document.querySelectorAll('input[name="cb_prm_id[]"]:checked');
        if (checkboxes.length === 0) {
            alert("Please select at least one menu item.");
            return false;  
        }
        return true; 
    }
</script>

<div class="modal-body">
  <form action="{{route('superadmin.getCbByidcategorypermissionstore')}}" method="POST">
    @csrf 
    <input type="hidden" value="{{$cbId?? ''}}" name="cb_id">
    
    <div class="row mb-4">
      <div class="col">
        <label class="form-label select-label" for="exampleSelect">Categories</label>
        <select id="exampleSelect" class="form-select" name="eligible_category_id[]" required multiple>
       
        @forelse($eligiblecategory as $val)
        @if(in_array($val->id,$cbcatresult)) 
            @continue
         @endif
            <option value="{{ $val->id }}">{{ $val->category }}</option>
           @empty 
            <p>Not available</p>
          @endforelse
        </select>
      </div>
    </div>
    <div class="row">
      <div class="col">
        <button type="submit" class="btn btn-primary">Submit</button>
      </div>
    </div>
  </form>
</div>



<div class="modal-body" style="max-height: 400px; overflow-y: auto;">
    <div class="card" style="overflow: scroll;">
        <hr>
        <div class="row">
            @foreach($cbcatresult1 as $index => $val)
                @if($index > 0 && $index % 3 == 0)
                    </div><div class="row">
                @endif
                <div class="col-4 mt-2">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="{{ $val->id }}" onclick="eligiblecategoryupdate()" id="eligiblecategoryupdate{{ $val->id }}" name="eligible_category_update_id[]">
                        <label class="form-check-label" for="eligiblecategoryupdate{{ $val->id }}">
                            {{ $val->category }}
                        </label>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</div>

<div class="modal-footer">
    <input type="button" id="btneligiblecategoryupdate" class="btn btn-primary" value="Delete Category" style="display:none">
</div>

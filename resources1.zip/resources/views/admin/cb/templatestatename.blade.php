<style>
.stateassing .form-check-label {
    font-size: 16px;
    font-weight: 600;
}

.stateassing .btn-primary {
    width: 100%; /* Make the button full width if necessary */
}

</style>
<form action="{{route('superadmin.getstatIdByallowstore_id')}}" method="POST">
            @csrf
            <div class="row removestatepermid">
                <div class="card">
                    <div class="col-12 mt-3">
                     <input type="hidden" value="{{$cb_id ?? ''}}" name="cb_id">
                     <select id="stateSelect" name="state_id[]" class="js-states form-control" multiple>
                        
                        @php
                            $takenStateIds = $cbstate->pluck('ref_state_id')->toArray();
                        @endphp
                    
                        @forelse ($state as $name)
                            @if (!in_array($name->id, $takenStateIds))
                                <option value="{{ $name->id }}">{{ $name->state_name }}</option>
                            @endif
                        @empty
                            <option value="">No states available</option>
                        @endforelse
                    </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer removestatepermid">
                <input type="button" onclick="removestateperm({{$cb_id ?? ''}})" class="btn btn-success" style="margin-right: auto;" value="Remove States Permission">
                <button type="button" id="selectAll" class="btn btn-info">Select All</button>

                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>
		
		
<div class="row stateassing" style="display:none">
    <div class="card">
        <div class="row">
            @forelse ($CBstateAssign as $state)
                <div class="col-md-4 col-sm-6 col-12 mt-3">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="{{$state->id}}" id="flexCheck{{$state->id}}" name="statename_id[]">
                        <label class="form-check-label" for="flexCheck{{$state->id}}">
                            {{$state->state_name}}
                        </label>
                    </div>
                </div>
            @empty
                <div class="col-12">
                    <p>No State Assign</p>
                </div>
            @endforelse
        </div>

        @if($CBstateAssign->isNotEmpty())
            <div class="row" style="justify-content: flex-end; margin: 25px">
                <div class="col-2">
                    <input type="button" class="btn btn-primary" value="Update" onclick="updateStates()" id="updateButton">
                </div>
            </div>
        @endif
    </div>
</div>

		
		
		

 <script>
$(document).ready(function() {
    $('#stateSelect').select2();
    var isAllSelected = false;
    $('#selectAll').on('click', function() {
        if (isAllSelected) {
            $('#stateSelect').val([]).trigger('change');
            isAllSelected = false;   
        } else {
            var allValues = $('#stateSelect option').map(function() {
                return $(this).val();
            }).get();
            $('#stateSelect').val(allValues).trigger('change');
            isAllSelected = true; 
        }
    });

    $('#stateSelect').on('select2:select', function(e) {
        var data = e.params.data;
        console.log(data);
    });
});

  function updateStates() {
      const selectedStates = [];

      document.querySelectorAll('input[name="statename_id[]"]:checked').forEach(function(checkbox) {
          selectedStates.push(checkbox.value);
      });
      if (selectedStates.length === 0) {
          alert('Please select at least one state.');
          return;
      }

      $('#whole_page_loader').show();
      fetch("{{route('superadmin.getstatIdByUpdate')}}", {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json',
              'X-CSRF-TOKEN': '{{ csrf_token() }}', 
          },
          body: JSON.stringify({ selectedStates: selectedStates })
      })
      .then(response => {
          if (!response.ok) {
              throw new Error('Network response was not ok');
          }
          return response.json();
      })
      .then(data => {
          $('#whole_page_loader').hide();
          if (data.success) {
              alert('Update successful!');
			  $('#Statesallow').modal('hide');
          } else {
              alert('Error occurred. Please try again.');
          }
      })
      .catch(error => {
          console.error('Error:', error);

          $('#whole_page_loader').hide();
          alert('An error occurred. Please try again.');
      });
  }
</script>
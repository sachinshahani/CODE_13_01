  <div class="row">
    <form action="{{route('superadmin.getCbByidRefproductpermissionStore')}}" method="POST">
    @csrf

      <div class="modal-body">
        <!-- Email input -->
        <input type="hidden" value="{{$cbId ?? 'N/A'}}" name="cb_id" id="CDid">
        @php
       
          $productID = getProductBYCBName($procbID->id);
          $refProductIDs = $productID->pluck('ref_product_id')->toArray();
          
       @endphp
        <div data-mdb-input-init="" class="form-outline mb-4">
          <label class="form-label" for="form3Example3">Products<span class="required">*</span></label>
          <select class="js-states form-control" multiple id="RefProduct_id" name="product_id[]" required>
          @forelse($productdata as $val)
          @if(in_array($val->id, $refProductIDs)) 
                @continue
          @endif
          <option value="{{$val->id}}">{{$val->product_name ?? ''}}</option>
          @empty
          @endforelse
          </select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        
        <!-- <input type="button" class="btn btn-info" value='Select All'  id="refallselectedpro"> -->
        <button type="submit" class="btn btn-success">Submit</button>
      </div>
    </form>
  </div>
    


 
  <div class="modal-body" style="max-height: 400px; overflow-y: auto;">
          <div class="card" style="overflow: scroll;">
          <hr>
              <div class="row">  
                  @foreach($getproduct as $index => $val)
                
                      @if($index > 0 && $index % 3 == 0)
                          </div><div class="row">  
                      @endif
                  
                      <div class="col-4 mt-2">  
                          <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="{{ $val->cbres_id }}" id="flexCheck{{ $val->cbres_id }}" name="product_permission[]">
                              <label class="form-check-label" for="flexCheck{{ $val->cbres_id }}">
                                  {{ $val->product_name }}
                              </label>
                          </div>
                      </div>
                  @endforeach
              </div>  
          </div>
      </div>
      <div class="modal-footer">
          <input type="button" id="btnupdatedata" class="btn btn-primary" value="Delete Product">
      </div>
   



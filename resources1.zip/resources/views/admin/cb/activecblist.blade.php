@extends('admin.layouts.app')
@section('content')
<style>.is-invalid-label {color: #dc3545;font-weight: bold;}.invalid-feedback {display: block;color: #dc3545;font-size: 0.875em;}</style>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0" style="float: left">
                    @if (isset(auth()->user()->ref_operator_type_id) && auth()->user()->ref_operator_type_id != 1)
                    Active CB List
                    @else
                    {{ $tit }} List
                    @endif
                </h5>

                <div class="row justify-content-end mb-2">
                </div>

            </div>
            <div class="card-body table-responsive">
                <table id="deptUser" class="table table-bordered table-striped align-middle" style="width:100%">
                    <thead>
                        <tr>
                            <th>S.No.</th>
                            <th>CB Details</th>
                            <th>CB PAN</th>
                            <th>Created On</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!--end col-->
</div>
<!--end row-->
<!-- Modal -->
<div class="modal fade" id="Statesallow" data-bs-backdrop="static" data-bs-keyboard="true" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">States Allow</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="Statesallowssss"></div>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<div class="modal fade" id="AccountTerminated" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">CB Activity</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div id="templatecbterminate"></div>
        </div>
    </div>
</div>
<!-- Modal -->
<div class="modal fade" id="menuassign" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Menu Assign</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="fomrIddata">
                    <div class="row mb-4">
                        <div class="col">
                            <div data-mdb-input-init class="form-outline">
                                <label class="form-label" for="form3Example1">Select Menu<span class="required">*</span></label>
                                <select name="Menu_id" id="Menu_id" class="form-select" onchange="getMenuId(this.value)">
                                    <option value="">--Select Menu--</option>
                                    @forelse ($menu as $val)
                                    <option value="{{$val->id}}">{{$val->module_name}}</option>
                                    @empty
                                    @endforelse

                                </select>

                            </div>
                            <div class="mb-3 mt-4">
                                <label for="exampleFormControlTextarea1" class="form-label">Remarks<span class="required">*</span></label>
                                <textarea class="form-control" id="exampleFormControlTextarea1" name="remark" rows="3"></textarea>
                            </div>
                        </div>
                        <div class="col">
                            <div data-mdb-input-init class="form-outline">
                                <label class="form-label" for="form3Example1">Select Sub Menu<span class="required">*</span></label>
                                <select name="sub_module_name[]" id="submodule" class="js-states form-control" multiple required>
                                </select>
                            </div>
                        </div>

                        <!-- <div class="col">
            <div data-mdb-input-init class="form-outline">
            <label class="form-label" for="form3Example1">Country Name</label>
            <input type="hide" id="hidden_menu_id" name="Country_id">
            </div>
            </div> -->
                    </div>
                    <input type="hidden" id="hidden_menu_id" name="cb_user_id">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" onclick="refreshForm()">Close</button>
                <input type="button" class="btn btn-primary" onClick="menupermissionupdate()" value="Update Permission">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
            </form>
        </div>
    </div>
</div>
{{-- Digital Signature --}}
<div class="modal fade" id="digitalSignatureAssign" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">eMudhra Digital Signtaure Permission</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row mb-4">
                    <div class="col-md-4 mb-3">
                        <label class="form-label" for="form3Example1">Select Signtaure Status<span class="required">*</span></label>
                        <select name="digitaSign_Status" id="digitaSign_Status" class="form-select">
                            <option value="">--Select Digital Signtaure Status--</option>
                            <option value="0">InActive</option>
                            <option value="1">Active</option>
                            <option value="2">Exprire</option>
                            <option value="3">Pending</option>
                            <option value="4">Under Verification</option>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label" for="form3Example1">Select eSignType<span class="required">*</span></label>
                        <select name="eSignType" id="eSignType" class="form-select">
                            <option value="">--Select eSignType--</option>
                            <option value="V2" disabled>V2 (Aadhaar KYC)</option>
                            <option value="V3">V3 (PAN KYC)</option>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="emUserId" class="form-label">emudhra User Id<span class="required">*</span></label>
                        <input type="text" class="form-control" id="emUserId" name="emUserId" placeholder="Enter emudhra Register User Id">
                    </div>
                    <div class="col-md-4">
                        <label for="emUserName" class="form-label">User Full Name<span class="required">*</span></label>
                        <input type="text" class="form-control" id="emUserName" name="emUserName" placeholder="Enter User Full Name">
                    </div>
                    <div class="col-md-4">
                        <label for="emUserReason" class="form-label">Reason eSign<span class="required">*</span></label>
                        <input type="text" class="form-control" id="emUserReason" name="emUserReason" placeholder="Enter Reason eSign">
                    </div>
                    <div class="col-md-4">
                        <label for="eSignLocation" class="form-label">eSign Location<span class="required">*</span></label>
                        <div class="form-check">
                            <input id="eSignStLocation" name="eSignLocation" type="radio" class="form-check-input" value="SL" required="">
                            <label class="form-check-label" for="eSignStLocation">Static Location</label>
                        </div>
                        <div class="form-check">
                            <input id="eSignDlLocation" name="eSignLocation" type="radio" class="form-check-input" value="DL" required="">
                            <label class="form-check-label" for="eSignDlLocation">Dynamic Allocation</label>
                        </div>
                        <div class="form-check">
                            <input id="eSignNoLocation" name="eSignLocation" type="radio" class="form-check-input" value="NO" required="">
                            <label class="form-check-label" for="eSignNoLocation">No</label>
                        </div>
                    </div>
                    <div id="staticLocationInput" class="col-md-4 form-group mb-3" style="display: none;">
                        <label for="staticLocationDetails" class="form-label">Static Location Details</label>
                        <input type="text" id="staticLocationDetails" name="staticLocationDetails" class="form-control" placeholder="Enter static location details">
                    </div>
                    <div class="col-md-12">
                        <label for="moduleName" class="form-label">Module Name Allow<span class="required">*</span></label>
                        <div class="d-flex align-items-center">
                            <div class="form-check me-3">
                                <input id="selectAllModules" type="checkbox" class="form-check-input">
                                <label class="form-check-label" for="selectAllModules">Select All</label>
                            </div>
                            <div class="form-check me-3">
                                <input id="moduleNameSC" name="moduleName" type="checkbox" class="form-check-input" value="SC">
                                <label class="form-check-label" for="moduleNameSC">Scope Certification</label>
                            </div>
                            <div class="form-check me-3">
                                <input id="moduleNameRC" name="moduleName" type="checkbox" class="form-check-input" value="RC">
                                <label class="form-check-label" for="moduleNameRC">Registration Certification</label>
                            </div>
                            <div class="form-check me-3">
                                <input id="moduleNameTC" name="moduleName" type="checkbox" class="form-check-input" value="TC">
                                <label class="form-check-label" for="moduleNameTC">Transfer Certification</label>
                            </div>
                            <div class="form-check">
                                <input id="moduleNameIST" name="moduleName" type="checkbox" class="form-check-input" value="IST">
                                <label class="form-check-label" for="moduleNameIST">Internal Stock Transfer</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer border-top flex-nowrap p-0">
                <button type="button" id="eSignKYCVerify" data-esignuserid="" data-esignclient="0" class="btn btn-lg btn-link text-success fs-6 text-decoration-none col-6 py-3 m-0 rounded-0 border-end"><strong>Yes, Allow Digital Signtaure</strong></button>
                <button type="button" class="btn btn-lg btn-link fs-6 text-decoration-none col-6 py-3 m-0 rounded-0" data-bs-dismiss="modal">No thanks</button>
              </div>
        </div>
    </div>
</div>



<!-- Modal  update menu permission -->
<div class="modal fade" id="UpdateMenuPermission" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Update Menu Permission</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div id="htmlupdatepermission"></div>
        </div>
    </div>
</div>




<!-- Modal  Ref-Product permission-->
<div id="RefProductpermission" class="modal fade flip show" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true" role="dialog">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel" style="color: red;">Product Permission</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div id="RefProductpermissionHtml"></div>
        </div>
    </div>
</div>



<!-- Modal  categoryByidshow permission-->
<div id="categoryByidshows" class="modal fade flip show" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true" role="dialog">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel" style="color: red;">Category Permission</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div id="categoryByidshowhtml"></div>
        </div>
    </div>
</div>


@endsection



@push('script')
<link rel="stylesheet" href="https://code.jquery.com/ui/1.14.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.14.1/jquery-ui.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
<script>
    
    $(document).ready(function () {
        const $selectAll = $('#selectAllModules');
        const $individualCheckboxes = $('input[name="moduleName"]');
        $selectAll.on('change', function () {
            const isChecked = $(this).is(':checked');
            $individualCheckboxes.prop('checked', isChecked);
        });
        $individualCheckboxes.on('change', function () {
            if (!$individualCheckboxes.not(':checked').length) {
                $selectAll.prop('checked', true); 
            } else {
                $selectAll.prop('checked', false);
            }
        });
    });

    $(document).ready(function () {
        const $eSignLocation = $('input[name="eSignLocation"]'); 
        const $staticLocationInput = $('#staticLocationInput');
        function toggleInputBox() {
            if ($('#eSignStLocation').is(':checked')) { 
                $staticLocationInput.show();
            } else {
                $staticLocationInput.hide();
            }
        }
        $eSignLocation.on('change', toggleInputBox);
        toggleInputBox();
    });
    
    $(document).on('click', '#eSignKYCVerify', function (e) {
        e.preventDefault(); // Prevent form submission or default action
        const $this = $(this);
        const originalButtonText = $this.html();
        let isValid = true; // Flag to track overall form validity

        // Function to add/remove validation classes and feedback
        const validateField = ($field, condition, errorMessage) => {
            if (condition) {
                $field.addClass('is-valid').removeClass('is-invalid');
                $field.next('.invalid-feedback').remove();
            } else {
                $field.addClass('is-invalid').removeClass('is-valid');
                if (!$field.next('.invalid-feedback').length) {
                    $field.after(`<div class="invalid-feedback">${errorMessage}</div>`);
                }
                isValid = false;
            }
        };

        // Validate fields
        const $digitaSignStatus = $('#digitaSign_Status');
        validateField($digitaSignStatus, $digitaSignStatus.val(), 'Please select a Digital Signature Status.');

        const $eSignType = $('#eSignType');
        validateField($eSignType, $eSignType.val(), 'Please select an eSign Type.');

        const $emUserId = $('#emUserId');
        validateField($emUserId, $emUserId.val().trim(), 'Please enter a valid emudhra User ID.');

        const $emUserName = $('#emUserName');
        validateField($emUserName, $emUserName.val().trim(), 'Please enter the User Full Name.');

        const $emUserReason = $('#emUserReason');
        validateField($emUserReason, $emUserReason.val().trim(), 'Please provide a reason for eSign.');

        // Validate Static Location Input
        const $eSignLocation = $('input[name="eSignLocation"]');
        if (!$eSignLocation.is(':checked')) {
            $eSignLocation.closest('.col-md-4').find('.form-label').addClass('is-invalid-label');
            $eSignLocation.addClass('is-invalid');
            if (!$eSignLocation.closest('.col-md-4').find('.invalid-feedback').length) {
                $eSignLocation.closest('.col-md-4').append('<div class="invalid-feedback">Please select an eSign Location.</div>');
            }
            isValid = false;
        } else {
            const selectedLocation = $('input[name="eSignLocation"]:checked').val();
            if (selectedLocation === "SL") {
                const $staticLocationDetails = $('#staticLocationDetails');
                $('#staticLocationInput').show();
                validateField($staticLocationDetails, $staticLocationDetails.val().trim(), 'Please enter Static Location Details.');
            } else {
                $('#staticLocationInput').hide();
                $eSignLocation.removeClass('is-invalid');
                $eSignLocation.closest('.col-md-4').find('.form-label').removeClass('is-invalid-label');
                $eSignLocation.closest('.col-md-4').find('.invalid-feedback').remove();
            }
        }

        // Validate Module Name
        const $moduleName = $('input[name="moduleName"]');
        if (!$moduleName.is(':checked')) {
            $moduleName.closest('.col-md-4').find('.form-label').addClass('is-invalid-label');
            if (!$moduleName.closest('.col-md-4').find('.invalid-feedback').length) {
                $moduleName.closest('.col-md-4').append('<div class="invalid-feedback">Please select a Module Name Allow to CB.</div>');
            }
            isValid = false;
        } else {
            $moduleName.removeClass('is-invalid');
            $moduleName.closest('.col-md-4').find('.form-label').removeClass('is-invalid-label');
            $moduleName.closest('.col-md-4').find('.invalid-feedback').remove();
        }

        // Collect form data
        const eSignUserId = $this.data('esignuserid');
        const eSignClient = $this.data('esignclient');
        const digitaSignStatus = $digitaSignStatus.val();
        const eSignType = $eSignType.val();
        const emUserId = $emUserId.val().trim();
        const emUserName = $emUserName.val().trim();
        const emUserReason = $emUserReason.val().trim();
        const eSignLocation = $('input[name="eSignLocation"]:checked').val();
        const staticLocationDetails = $('#staticLocationDetails').val().trim();
        const moduleName = $('input[name="moduleName"]:checked')
            .map(function () {
                return $(this).val();
            })
            .get();
        // Submit form if valid
        if (isValid) {
            $this.prop('disabled', true).html('<strong>Processing...</strong>');
            $.ajax({
                url: "{{ route('superadmin.cbemSign-kyc-update') }}",
                method: "POST",
                dataType: 'json',
                data: {
                    eSignUserId,
                    digitaSignStatus,
                    eSignType,
                    eSignClient,
                    emUserId,
                    emUserName,
                    emUserReason,
                    eSignLocation,
                    staticLocationDetails,
                    moduleName,
                    _token: '{{ csrf_token() }}',
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function () {
                    Swal.fire('Success!', 'eSign KYC updated successfully.', 'success').then(() => {
                        window.location.reload();
                    });
                },
                error: function () {
                    Swal.fire('Error!', 'Something went wrong. Please try again.', 'error');
                },
                complete: function () {
                    $('#digitalSignatureAssign').modal('hide');
                    $this.prop('disabled', false).html(originalButtonText);
                }
            });
        }
    });
   

   
</script>
<script>
    
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    var table = $('#deptUser').DataTable({
        //dom: 'l<"clear">Bfrtip',
        dom: 'Bfrtip',

        //dom:'Blfrtip',
        lengthMenu: [
            [10, 25, 50, -1]
            , [10, 25, 50, "All"]
        ]
        , processing: true
        , serverSide: true
        , ajax: {
            url: '{{ route('superadmin.activecb') }}'
            , type: 'GET'
            , data: function(d) {
                d._token = "{{ csrf_token() }}";
                d.status = $("#search").val();
            }

        }
        , columns: [{
                data: 'DT_RowIndex'
                , name: 'DT_RowIndex'
                , orderable: true
            }
            , {
                data: 'first_name'
                , name: 'first_name'
                , orderable: true
            }
            , {
                data: 'user_name'
                , name: 'user_name'
                , orderable: true
            }
            , {
                data: 'created_on'
                , name: 'created_on'
                , orderable: true
            }
            , {
                data: 'action'
                , name: 'action'
                , orderable: true
            }
        , ],
        // initComplete: function () {
        //     var btns = $('.dt-button');
        //     //btns.addClass('btn btn-success btn-success');
        //     btns.removeClass('dt-button');

        // },

        paging: false
        , dom: 'Bfrtip'
        , buttons: [
            'excelHtml5'
            , {
                extend: 'csvHtml5'
                , title: function() {
                    return "REPORTS";
                },


                titleAttr: 'CSV REPORTS'
            }
            , {
                extend: 'pdfHtml5'
                , title: function() {
                    return "PDF REPORTS";
                }
                , orientation: 'landscape'
                , pageSize: 'A4',

                titleAttr: 'PDF REPORTS'
            },


        ]



    });

    $("#search").on('change', function(e) {
        table.draw();
        e.preventDefault();
    });


    $(document).on('click', '.deletedata', function() {
        var id = $(this).attr('data-value');

        Swal.fire({
            title: 'Are you sure?'
            , html: '<input type="text" id="deletionReason" class="swal2-input" placeholder="Enter reason for deletion...">'
            , text: "You won't be able to revert this!"
            , icon: 'warning'
            , showCancelButton: true
            , confirmButtonColor: '#3085d6'
            , cancelButtonColor: '#d33'
            , confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.value) {
                var deletionReason = $('#deletionReason').val();
                $.ajax({
                    url: "{{ route('superadmin.usermanagement.deptUser.delete') }}"
                    , method: "POST"
                    , dataType: 'json'
                    , data: {
                        'id': id
                        , 'deletionReason': deletionReason
                        , '_token': '{{ csrf_token() }}'
                    , }
                    , headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                    , success: function(result) {
                        Swal.fire('Deleted!', 'Record Deleted Successfully..', 'success')
                            .then((result) => {
                                window.location.href =
                                    '';
                            });
                    }

                });
            }
        });
    });

    $(document).on('click', '.viewdata', function() {
        var id = $(this).attr('data-id');
        $('#whole_page_loader').show();
        $.ajax({
            url: "{{ route('superadmin.usermanagement.deptUser.view') }}"
            , method: "POST"
            , dataType: 'json'
            , data: {
                'id': id
            , }
            , headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
            , success: function(result) {
                $('#whole_page_loader').hide();
                if (result.status == "success") {
                    $('#viewDataModal').modal('show');
                    $('#viewDataModal #htmlData').html(result.html);
                    return true;
                } else {
                    Swal.fire('', result.msg, 'warning');
                }
            }
            , error: function(result) {
                $('#whole_page_loader').hide();
            }
        });
    });


    function AccountTerminated(id) {
        $('#whole_page_loader').show();
        var csrfToken = $('meta[name="csrf-token"]').attr('content');
        $.ajax({
            url: '{{route("superadmin.AccountTerminated")}}'
            , method: 'POST'
            , data: {
                cb_id: id
            }
            , headers: {
                'X-CSRF-TOKEN': csrfToken
            }
            , success: function(response) {
                $('#whole_page_loader').hide();
                $('#templatecbterminate').html(response);
                $('#AccountTerminated').modal('show');

            }
            , error: function(xhr, status, error) {
                $('#whole_page_loader').hide();
                alert("An error occurred: " + error);
            }
        });
    }



    function menuassign(id) {
        $('#hidden_menu_id').val(id);
        $('#menuassign').modal('show');
    }




    $(document).ready(function() {
        $('#fomrIddata').on('submit', function(e) {
            var submodule = $('#submodule').val();
            var Menu_id = $('#Menu_id').val();
            e.preventDefault();
            if (submodule === null || submodule === '' || Menu_id === null || Menu_id === '') {
                alert('Menu & sub Menu required');
                return false;
                e.preventDefault();
            }


            var formData = new FormData(this);
            console.log(formData);
            $('#whole_page_loader').show();
            $.ajax({
                url: "{{ route('superadmin.storepermissionmenu') }}"
                , method: "POST"
                , dataType: 'json'
                , data: formData
                , processData: false
                , contentType: false
                , headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
                , success: function(result) {
                    $('#whole_page_loader').hide();
                    if (result.status === "success") {
                        Swal.fire('', result.msg, 'success');
                        $('#menuassign').modal('hide');
                        $('#fomrIddata').reset();
                    } else {
                        Swal.fire('', result.msg, 'warning');
                        $('#fomrIddata').reset();
                    }
                }
                , error: function(xhr, status, error) {
                    $('#whole_page_loader').hide();
                    console.error('AJAX Error: ', error);
                    Swal.fire('Error', 'An error occurred while processing your request.', 'error');
                }
            });
        });
    });

    function userDigitalSignatureData(id) {
        var csrfToken = $('meta[name="csrf-token"]').attr('content');
        $('#whole_page_loader').show();  // Show loading spinner

        $.ajax({
            url: '{{route("superadmin.cbemSign-kyc-data")}}',
            method: 'POST',
            data: {
                id: id
            },
            headers: {
                'X-CSRF-TOKEN': csrfToken
            },
            success: function(response) {
                $('#whole_page_loader').hide();  // Hide loading spinner

                if (response.status === 'success') {
                    // Populate modal with user data from response
                    var data = response.data;  // Assuming response contains the user data
                    const eSignLocation = $('input[name="eSignLocation"]');
                    // Set modal fields with data
                    $('#digitaSign_Status').val(data.emStatus);
                    $('#eSignType').val(data.eSignType);
                    $('#emUserId').val(data.emUserId);
                    $('#emUserName').val(data.emUserName);
                    $('#emUserReason').val(data.emUserReason);

                    $('input[name="eSignLocation"]').filter('[value="' + data.eSignLocation + '"]').prop('checked', true);

                    if (data.eSignLocation === 'SL') {
                        $('#staticLocationDetails').val(data.eSignLocation);
                        $('#staticLocationInput').show();
                    } else {
                        $('#staticLocationInput').hide();
                    }
                   
                    $('#staticLocationDetails').val(data.eSignStaticLocation);


                    // Set module checkboxes based on allowed modules
                    var moduleName = data.eSignModuleAllow;  // This is an array like ["SC", "RC", "TC", "IST"]
                    if (moduleName && moduleName.length > 0) {
                        moduleName.forEach(function(module) {
                            $('#moduleName' + module).prop('checked', true);
                        });
                    }
                    $('#eSignKYCVerify').attr('data-eSignUserId', id);
                    $('#digitalSignatureAssign').modal('show');
                } else {
                    alert(response.msg);  // Show error message if any
                }
            },
            error: function(xhr, status, error) {
                $('#whole_page_loader').hide();  // Hide loading spinner
                alert("An error occurred: " + error);  // Show error alert
            }
        });
    }




    function getMenuId(id) {
        var csrfToken = $('meta[name="csrf-token"]').attr('content');
        $('#whole_page_loader').show();
        var cbID = $('#hidden_menu_id').val();
        $.ajax({
            url: '{{route("superadmin.menu_id_get")}}'
            , method: 'POST'
            , data: {
                menu_id: id
                , cbID: cbID
            }
            , headers: {
                'X-CSRF-TOKEN': csrfToken
            }
            , success: function(response) {
                $('#whole_page_loader').hide();
                if (response.data && Array.isArray(response.data)) {
                    var html = '';
                    var disabledSubmodules = new Set();
                    response.cbid.forEach(function(item) {
                        disabledSubmodules.add(item.sub_module_id);
                    });
                    response.data.forEach(function(item) {
                        var disableAttribute = disabledSubmodules.has(item.id) ? 'disabled' : '';
                        html += '<option value="' + item.id + '" ' + disableAttribute + '>' + item.sub_module_name + '</option>';
                    });
                    $('#submodule').html(html);
                } else {
                    alert("Unexpected response data format.");
                }
            }
            , error: function(xhr, status, error) {
                $('#whole_page_loader').hide();
                alert("An error occurred: " + error);
            }
        });
    }




    function menupermissionupdate() {
        var cb_id = $('#hidden_menu_id').val();
        var csrfToken = $('meta[name="csrf-token"]').attr('content');
        $('#whole_page_loader').show();
        $.ajax({
            url: '{{route("superadmin.menupermissionupdate")}}'
            , method: 'POST'
            , data: {
                cb_id: cb_id
            }
            , headers: {
                'X-CSRF-TOKEN': csrfToken
            }
            , success: function(response) {

                $('#whole_page_loader').hide();
                $('#htmlupdatepermission').html(response);
                $('#UpdateMenuPermission').modal('show');

            }
            , error: function(xhr, status, error) {
                $('#whole_page_loader').hide();
                alert("An error occurred: " + error);
            }
        });
    }


    function refreshForm() {

        document.getElementById('fomrIddata').reset();
    }




    function submitForm() {
        if (!confirm('Are you sure you want to do this?')) {
            return false;
        }
        var AccountTerminated = $('#Account_Terminated').val();
        if (AccountTerminated === null || AccountTerminated === '') {
            alert('Field is required');
            return false;
        }

        var formData = new FormData($('#templatecbterminatesus')[0]);
        $('#whole_page_loader').show();

        $.ajax({
            url: "{{ route('superadmin.templatecbterminatesus') }}"
            , method: "POST"
            , dataType: 'json'
            , data: formData
            , processData: false
            , contentType: false
            , headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
            , success: function(result) {
                $('#whole_page_loader').hide();
                if (result.status === "success") {
                    Swal.fire('', result.msg, 'success');
                    $('#AccountTerminated').modal('hide');
                } else {
                    Swal.fire('', result.msg, 'warning');
                }
            }
            , error: function(xhr, status, error) {
                $('#whole_page_loader').hide();
                console.error('AJAX Error: ', error);
                Swal.fire('Error', 'An error occurred while processing your request.', 'error');
            }
        });
    }


    
    function StateAllow(cb_id) {


        var csrfToken = $('meta[name="csrf-token"]').attr('content');
        $('#whole_page_loader').show();
        $.ajax({
            url: '{{route("superadmin.getstatIdByallow")}}'
            , method: 'POST'
            , data: {
                cb_id: cb_id
            }
            , headers: {
                'X-CSRF-TOKEN': csrfToken
            }
            , success: function(response) {
                $('#Statesallow').on('shown.bs.modal', function() {
                    $('#stateSelect').select2({
                        tags: false
                        , dropdownParent: $('#Statesallow')
                    });
                });

                $('#whole_page_loader').hide();
                $('#Statesallowssss').html(response);
                $('#Statesallow').modal('show');


            }
            , error: function(xhr, status, error) {
                $('#whole_page_loader').hide();
                alert("An error occurred: " + error);
            }
        });
    }


    function removestateperm(id) {

        $('.stateassing').show();
        $('.removestatepermid').hide();

    }


    

function getRefProductpermission(id) {
        var csrfToken = $('meta[name="csrf-token"]').attr('content');
        $('#whole_page_loader').show();
        $.ajax({
            url: '{{route("superadmin.getCbByidRefproductpermission")}}', 
            method: 'POST', 
            data: {
                cb_id: id
            }, 
            headers: {
                'X-CSRF-TOKEN': csrfToken
            } , 
            success: function(response) {
                $('#whole_page_loader').hide();
               
                $('#RefProductpermission').on('shown.bs.modal', function() {
                $('#RefProduct_id').select2({
                    tags: false,          
                    dropdownParent: $('#RefProductpermission'),  
                    width: '100%',           
                    // placeholder: "Search or select", 
                    allowClear: true            
                });
            });
                $('#RefProductpermission').modal('show');
                $('#RefProductpermissionHtml').html(response);

            },
             error: function(xhr, status, error) {
                $('#whole_page_loader').hide();
                alert("An error occurred: " + error);
            }
        });
}




$(document).on('click', '#btnupdatedata', function() {
 
    var selectedIds = [];
    $("input[name='product_permission[]']:checked").each(function() {
        selectedIds.push($(this).val());
    });
    if (selectedIds.length === 0) {
        alert("Please select at least one product.");
        return;
    }
    var cbresID = { cbresID: selectedIds };
    $('#whole_page_loader').show();
    $.ajax({
        url: '{{ route("superadmin.getCbByidRefproductpermissionUpdate") }}',
        method: 'POST',
        data: cbresID,
        headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' },
        success: function(response) {
            $('#whole_page_loader').hide();
            alert(response.message || "Products deleted successfully.");
            setTimeout(function() {
        window.location.reload(); 
      }, 1000); 
        },
        error: function(xhr, status, error) {
            $('#whole_page_loader').hide();
            alert("An error occurred: " + error);
        }
    });
});


 



function categoryByidshow(id) {
    
        var csrfToken = $('meta[name="csrf-token"]').attr('content');
        $('#whole_page_loader').show();
        $.ajax({
            url: '{{route("superadmin.getCbByidcategorypermission")}}', 
            method: 'POST', 
            data: {
                cb_id: id
            }, 
            headers: {
                'X-CSRF-TOKEN': csrfToken
            } , 
            success: function(response) {
                $('#whole_page_loader').hide();
                $('#categoryByidshows').modal('show');
                $('#categoryByidshowhtml').html(response);

            },
             error: function(xhr, status, error) {
                $('#whole_page_loader').hide();
                alert("An error occurred: " + error);
            }
        });
}


function eligiblecategoryupdate() {
    const checkboxes = document.querySelectorAll('input[type="checkbox"][name="eligible_category_update_id[]"]');
    const deleteButton = document.getElementById('btneligiblecategoryupdate');
    let isChecked = false;
    checkboxes.forEach(function(checkbox) {
        if (checkbox.checked) {
            isChecked = true;
        }
    });

    if (isChecked) {
        deleteButton.style.display = 'block'; 
    } else {
        deleteButton.style.display = 'none';
    }
}

document.addEventListener('DOMContentLoaded', function() {
    const deleteButton = document.getElementById('btneligiblecategoryupdate');
    deleteButton.style.display = 'none'; 
});





$(document).on('click', '#btneligiblecategoryupdate', function() {

 var selectedIds = [];
 $("input[name='eligible_category_update_id[]']:checked").each(function() {
     selectedIds.push($(this).val());
 });
 if (selectedIds.length === 0) {
     alert("Please select at least one cat.");
     return;
 }
 var eligiblecategory_id = { eligiblecategory_id: selectedIds };
 $('#whole_page_loader').show();
 $.ajax({
     url: '{{ route("superadmin.getCbByidcategorypermissionupdate") }}',
     method: 'POST',
     data: eligiblecategory_id,
     headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' },
     success: function(response) {
         $('#whole_page_loader').hide();
         alert(response.message || "Products deleted successfully.");
         setTimeout(function() {
     window.location.reload(); 
   }, 1000); 
     },
     error: function(xhr, status, error) {
         $('#whole_page_loader').hide();
         alert("An error occurred: " + error);
     }
 });
});


</script>
@endpush

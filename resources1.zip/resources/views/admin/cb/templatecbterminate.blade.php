<div class="row">
  <form id="templatecbterminatesus">
    <div class="modal-body">
      <!-- 2 column grid layout with text inputs for the first and last names -->
      <div class="row mb-4">
        <div class="col">
          <div data-mdb-input-init class="form-outline">
            <label class="form-label" for="form3Example1">CB Name</label>
            <input type="text" id="form3Example1" class="form-control" value="{{$results->first_name ?? ''}} {{$results->last_name ?? ''}}" readonly/>
          </div>
        </div>
        <div class="col">
          <div data-mdb-input-init class="form-outline">
            <label class="form-label" for="form3Example2">PAN No.</label>
            <input type="text" id="form3Example2" class="form-control" value="{{$results->user_name ?? ''}}" readonly/>
            <input type="hidden" id="cb_user_id" class="form-control" value="{{$cbId ?? ''}}" name="cb_user_id" readonly/>
          </div>
        </div>
      </div>
      
      <!-- Email input -->
      <div data-mdb-input-init class="form-outline mb-4">
        <label class="form-label" for="form3Example3">CB Account<span class="required">*</span></label>
        <select class="form-select" id="Account_Terminated" name="account_terminated" onchange="getdate(this.value)">
        <option value="">-Select Option--</option>
        <option value="6" 
                {{ $results->operator_status == 6 ? 'selected' : '' }} 
                style="{{ $results->operator_status == 6 ? 'color: red;' : '' }}">
            Terminate
        </option>
        <option value="7" 
                {{ $results->operator_status == 7 ? 'selected' : '' }} 
                style="{{ $results->operator_status == 7 ? 'color: red;' : '' }}">
            Suspend
        </option>
        <option value="8" 
                {{ $results->operator_status == 8 ? 'selected' : '' }} 
                style="{{ $results->operator_status == 8 ? 'color: red;' : '' }}">
            Block
        </option>

        </select>
      </div>
      
      <div class="row mb-4 getdatesuspend">
        <div class="col">
          <div data-mdb-input-init class="form-outline">
          @php
           $currentDate = date('d/m/Y');
          @endphp
            <label class="form-label" for="form3Example1">To Date<span class="required">*</span></label>
            <input type="text" id="form3Example1" name="to_date" class="form-control" value="{{ $results->to_date ? $results->to_date : $currentDate }}" readonly />
          </div>
        </div>
        <div class="col">
          <div data-mdb-input-init class="form-outline">
            <label class="form-label" for="form3Example2">From Date<span class="required">*</span></label>
            <input type="text" id="my_date_picker"  name="form_date" class="form-control my_date_picker" value="{{$results->from_date ?? ''}}" required/>
          </div>
        </div>
      </div>

        <div class="row mb-4">
        <div class="col">
          <div data-mdb-input-init class="form-outline">
            <label class="form-label" for="form3Example1">Remarks<span class="required">*</span></label>
            
            <textarea type="text" id="form3Example1" class="form-control" name="remarks" value="" required>{{$results->remark ?? ''}}</textarea>
          </div>
        </div>
      </div>

    </div>
    
    
    <div class="modal-footer">
      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      <input type="button" id="dddtemplatecbterminatesusIDbtn" class="btn btn-primary" value="Submit" onclick="submitForm()"/>
    </div>
  </form>
</div>
 <script>
$(document).ready(function() {
    var initialStatus = '{{ $results->operator_status ?? '' }}'; 
    getdate(initialStatus, initialStatus);
    $('select').on('change', function() {
        var selectedStatus = $(this).val();  
        getdate(selectedStatus, initialStatus); 
    });
});

function getdate(selectedStatus, initialStatus) {
    if (selectedStatus == 7 || selectedStatus == 8) {
        $('.getdatesuspend').show();
    } else {
        $('.getdatesuspend').hide();
    }
    if (initialStatus == 7 || initialStatus == 8) {
        $('.getdatesuspend').show(); 
    }
}

       $(document).ready(function () {
            $(function () {
                $(".my_date_picker").
                datepicker();
            });
        })
</script>

@extends('admin.layouts.app')
@section('content')
    <style>
        .page-content {
            background: #F2FBF9;

        }

        .c-h {
            min-height: 452px !important;
            background: #fff
        }

        .c-h .card-body {
            background: #fff
        }
        .marquee-bg{background: #f3f3f3;
        padding: 8px;}
.marquee-container {
  width: 930px;
  overflow: hidden;
  white-space: nowrap;

}

.marquee-content {
  display: inline-block;
  padding-left: 100%;
  animation: scroll-left 10s linear infinite;
  animation-play-state: running; /* Default state is running */
}

/* Stop animation on hover */
.marquee-container:hover .marquee-content {
  animation-play-state: paused;
}

.marquee-title {
margin-right: 30px; 
font-size: 18px;  
color: #333;  
text-decoration: none;
padding: 5px 10px;
transition: color 0.3s ease;
}

.marquee-title:hover {
color: #007BFF;  /* Change color when hovered */
}


@keyframes scroll-left {
  from {
    transform: translateX(0%);
  }
  to {
    transform: translateX(-100%);
  }
}
    </style>
    {{-- <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Home</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Home</a></li>

                    </ol>
                </div>

            </div>
        </div>
    </div> --}}
    <!-- end page title -->
    @if (isset(auth()->user()->ref_operator_type_id) &&
            (auth()->user()->ref_operator_type_id == 1 || auth()->user()->ref_operator_type_id == 101))
        <div class="container-fluid cus-dash-div">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <h4 class="mb-sm-0">Dashboard</h4>

                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">As on :</a></li>
                                <li class="breadcrumb-item">
                                    <form class="form-inline">
                                        <div class="form-group">
                                            <input type="date" class="form-control cu-form-control" id="inputPassword2">
                                        </div>
                                    </form>
                                </li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <!-- end page title -->
            <div class="row">
                <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                    <div class="card dashb-box gradient-colr">
                        <div class="card-body p-0">
                            <div class="img-part">
                                <img src="{{ asset('public/assets/images/micon-1.png') }}" alt="">
                            </div>
                            <div class="txt-part">
                                <p>Total Registered Users</p>
                                <h3 id="user_id"></h3>
                                <p id="user_date"></p>
                                <div class="digital-clock">00:00:00</div>
                            </div>
                        </div><!-- end card body -->
                    </div><!-- end card -->
                </div><!-- end col -->
                <div class="col-12 col-sm-12 col-md-9 col-lg-9 col-xl-9 ps-2">
                    <div class="more-cards-inner">
                        <div class="card dashb-box blue-bx">
                            <a href="{{route('superadmin.GrowerGroup')}}">
                                <div class="card-body p-0">
                                    <div class="img-part">
                                        <img src="{{ asset('public/assets/images/micon-2.png') }}" alt="">
                                    </div>
                                    <div class="txt-part">
                                        <p>Grower Group</p>
                                        <p class="colr-txt" id="ics_id"></p>

                                    </div>
                                </div>
                            </a>
                            <!-- end card body -->
                        </div><!-- end card -->
                        <div class="card dashb-box purple-bx">
                            <a href="{{route('superadmin.IP')}}">
                                <div class="card-body p-0">
                                    <div class="img-part">
                                        <img src="{{ asset('public/assets/images/micon-3.png') }}" alt="">
                                    </div>
                                    <div class="txt-part">
                                        <p>Individual Producers</p>
                                        <p class="colr-txt" id="individual_id"></p>
                                    </div>
                                </div>
                            </a>
                            <!-- end card body -->
                        </div><!-- end card -->
                        <div class="card dashb-box drk-brown-bx">
                            <a href="{{route('superadmin.Processor')}}">
                                <div class="card-body p-0">

                                    <div class="img-part">
                                        <img src="{{ asset('public/assets/images/micon-4.png') }}" alt="">
                                    </div>
                                    <div class="txt-part">
                                        <p>Processors</p>
                                        <p class="colr-txt" id="processor_id"></p>
                                    </div>

                                </div>
                            </a>
                            <!-- end card body -->
                        </div><!-- end card -->
                        <div class="card dashb-box drk-blue-bx">
                            <a href="{{route('superadmin.Wh')}}">
                                <div class="card-body p-0">
                                    <div class="img-part">
                                        <img src="{{ asset('public/assets/images/micon-6.png') }}" alt="">
                                    </div>
                                    <div class="txt-part">
                                        <p>Wild Harvestor</p>
                                        <p class="colr-txt" id="harvester_id"></p>
                                    </div>
                                </div>
                            </a><!-- end card body -->
                        </div><!-- end card -->
                        <div class="card dashb-box yellow-bx">
                            <a href="{{route('superadmin.Trader')}}">
                                <div class="card-body p-0">
                                    <div class="img-part">
                                        <img src="{{ asset('public/assets/images/micon-7.png') }}" alt="">
                                    </div>
                                    <div class="txt-part">
                                        <p>Traders</p>
                                        <p class="colr-txt" id="trader_id"></p>
                                    </div>
                                </div>
                            </a><!-- end card body -->
                        </div>

                        <!-- end card -->
                        <div class="card dashb-box green-bx">
                            <a href="{{route('superadmin.Farmer')}}">
                                <div class="card-body p-0">
                                    <div class="img-part">
                                        <img src="{{ asset('public/assets/images/micon-5.png') }}" alt="">
                                    </div>
                                    <div class="txt-part">
                                        <p>Farmers</p>
                                        <p class="colr-txt" id="farmer_id"></p>
                                    </div>
                                </div>
                            </a> <!-- end card body -->
                        </div><!-- end card -->
                        <div class="card dashb-box pink-bx">
                            <a href="{{route('superadmin.Farm')}}">
                                <div class="card-body p-0">
                                    <div class="img-part">
                                        <img src="{{ asset('public/assets/images/micon-9.png') }}" alt="">
                                    </div>
                                    <div class="txt-part">
                                        <p>Farms</p>
                                        <p class="colr-txt" id="farm_id"></p>
                                    </div>
                                    <div class="txt-part total-txt">
                                        <p class="colr-txt" id=""></p>
                                    </div>
                                </div>
                            </a><!-- end card body -->
                        </div><!-- end card -->
                        <div class="card dashb-box orng-bx">
                            <a href="{{route('superadmin.Products')}}">
                                <div class="card-body p-0">
                                    <div class="img-part">
                                        <img src="{{ asset('public/assets/images/micon-8.png') }}" alt="">
                                    </div>
                                    <div class="txt-part">
                                        <p>Products</p>
                                        <p class="colr-txt" id="product_id"></p>
                                    </div>
                                </div>
                            </a>
                            <!-- end card body -->
                        </div><!-- end card -->
                    </div>
                </div><!-- end col -->
            </div><!-- end row -->
        </div>
        <div class="row mt-4">
            <div class="col-lg-4 col-md-6">
                <div class="card c-h">
                    <div class="data-details">
                        <div class="banner-heading">
                            <h4>State Wise Registered office of CBs</h4>
                            <span class="underline"></span>
                        </div>
                        <a href="#">
                            <i class="fas fa-bars"></i>
                        </a>
                    </div>
                    <div id="map" ></div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="card c-h">
                    <div class="mt-md-0 py-3 px-3">
                        <div class="d-flex align-items-center">
                            <p>
                            <h4>Year Wise Scope Certificate</h4>
                            </p>
                        </div>
                    </div>
                    <div id="chart"></div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="card c-h">
                    <div class="card-header">
                        <h4 class="card-title mb-0">Year Wise Transaction Certificate</h4>
                    </div>
                    <div class="card-body">
                        <div id="chartsplinearea"></div>
                    </div><!-- end card-body -->
                </div>
            </div>

            <div class="col-lg-4 col-md-6">
                <div class="card c-h">
                    <div class="card-header">
                        <h4 class="card-title mb-0">No-Objection Certificate</h4>
                    </div>

                    <div class="card-body">
                        <div id="multi_chart"></div>
                    </div><!-- end card-body -->
                </div><!-- end card -->
            </div>

            <div class="col-lg-4 col-md-6">
                <div class="card c-h">
                    <div class="mt-md-0 py-3 px-3">
                        <div class="d-flex align-items-center">
                            <h4>Top 5 Exporting States</h4>
                        </div>
                    </div>
                    <div id="exportState"></div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="card c-h">
                    <div class="mt-md-0 py-3 px-3">
                        <div class="d-flex align-items-center">
                            <h4>Top 5 Export Product Categories</h4>
                        </div>
                    </div>
                    <div id="exportProduct"></div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="card c-h">
                    <div class="mt-md-0 py-3 px-3">
                        <div class="d-flex align-items-center">
                            <h4>Top 5 Importing Countries</h4>
                        </div>
                    </div>
                    <div id="ImportingCountry"></div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6">
                <div class="card c-h">
                    <div class="mt-md-0 py-3 px-3">
                        <div class="d-flex align-items-center">
                            <h4>Top 5 Exported products</h4>
                        </div>
                    </div>
                    <div id="exportedProduct"></div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="card c-h">
                    <div class="mt-md-0 py-3 px-3">
                        <div class="d-flex align-items-center">
                            <h4>Top 5 products for domestic TCs issued</h4>
                        </div>
                    </div>
                    <div id="domesticTcIssue"></div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="card c-h">
                    <div class="mt-md-0 py-3 px-3">
                        <div class="d-flex align-items-center">
                            <p>
                            <h4>Year Wise Domestic TC, PTC and Export TC.</h4>
                            </p>
                        </div>
                    </div>
                    <div id="TcPtc"></div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6">
                <div class="card c-h">
                    <div class="mt-md-0 py-3 px-3">
                        <div class="d-flex align-items-center">
                            <h4>No. Of Operators CB Wise</h4>
                        </div>
                    </div>
                    <div id="noofoperatorcbwise"></div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="card c-h">
                    <div class="mt-md-0 py-3 px-3">
                        <div class="d-flex align-items-center">
                            <h4>No. of operators State wise</h4>
                        </div>
                    </div>
                    <div id="noOfOperatorStateWise"></div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="card c-h">
                    <div class="mt-md-0 py-3 px-3">
                        <div class="d-flex align-items-center">
                            <h4>CB wise area, production and export</h4>
                        </div>
                    </div>
                    <div id="CbWiseAreaProExport"></div>
                </div>
            </div>


            <div class="col-lg-4 col-md-6">
                <div class="card c-h">
                    <div class="mt-md-0 py-3 px-3">
                        <div class="d-flex align-items-center">
                            <h4>Year wise Area v/s Production v/s Export</h4>
                        </div>
                    </div>
                    <div id="fyearcyear"></div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="card c-h">
                    <div class="mt-md-0 py-3 px-3">
                        <div class="d-flex align-items-center">
                            <h4>CB wise highest export and domestic TCs</h4>
                        </div>
                    </div>
                    <div id="highestexportCbTc"></div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6">
                <div class="card c-h">
                    <div class="mt-md-0 py-3 px-3">
                        <div class="d-flex align-items-center">
                            <h4>CB wise area in State and outside</h4>
                        </div>
                    </div>
                    <div id="cbwiseareaiostate"></div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="card c-h">
                    <div class="mt-md-0 py-3 px-3">
                        <div class="d-flex align-items-center">
                            <h4>Operator movement through NOC from suspended CB to other accredited CB</h4>
                        </div>
                    </div>
                    <div id="movement"></div>
                </div>
            </div>
        </div>
  
        {{-- <div class="row">chartsplinearea
            <div class="col-xl-12">
                <div class="card crm-widget ">
                    <div class="card-body p-0 white-inner">
                        <div class="row row-cols-xxl-5 row-cols-md-4 row-cols-1 g-0">

                            <div class="col-xxl-12 col-md-12">
                                <div class="mt-2 mt-md-0 py-3 px-3">

                                    <div class="d-flex align-items-center">

                                        Super Admin Dashboard

                                    </div>
                                </div>
                            </div><!-- end col -->


                            <!-- end col -->
                        </div><!-- end row -->
                    </div><!-- end card body -->
                </div><!-- end card -->
            </div><!-- end col -->
        </div><!-- end row --> --}}
    @endif
@endsection
@push('script')
{{-- <script src="{{asset('public/landing/js/mapdata.js') }}"></script> --}}
@php
     require(public_path('/landing/js/mapdata.php'));
@endphp
<script src="{{asset('public/landing/js/countrymap.js') }}"></script>

@push('script')
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script>
        $(document).ready(function() {

            $('#user_id, #product_id, #farmer_id, #farm_id, #ics_id, #individual_id, #harvester_id, #trader_id, #processor_id, #mandators_id')
                .html(
                    '<div id="loading"><img id="loading-image" src="{{ asset('public/assets/images/preloader.gif') }}" alt="Loading..." /></div>'
                );
            $.ajax({
                url: "{{ route('superadmin.dashboardajaxcall') }}",
                method: 'POST',
                type: "script",
                success: function(response) {
                    try {
                        $('#user_date').html('Till Today: ' + response.user_date);
                        $('#user_id').html(response.user);
                        $('#ics_id').html(response.ics);
                        $('#individual_id').html(response.individual);
                        $('#harvester_id').html(response.harvester);
                        $('#trader_id').html(response.trader);
                        $('#processor_id').html(response.processor);
                        $('#farmer_id').html(response.farmer);
                        $('#farm_id').html('Total Land (Ha): ' + response.farm);
                        $('#product_id').html('Total Products: ' + response.product);
                        $('#mandators_id').html(response.mandators);
                    } catch (error) {
                        console.error('Error parsing JSON: ' + error);
                    }
                },
                complete: function(jqXHR, textStatus) {
                    // alert("request complete "+textStatus);
                },
                error: function(xhr, textStatus, errorThrown) {

                    console.log('request failed->' + xhr);

                }
            });
        });

        /*Scope Certificate*/
        var currentYear = new Date().getFullYear();
        var years = [];
        for (var i = 2019; i <= currentYear; i++) {
            years.push(i);
        }
        var options = {
            series: [{
                name: 'Total',
                data: [44, 55, 57, 56, 40]
            }, {
                name: 'Approved',
                data: [76, 85, 101, 98, 87]
            }, {
                name: 'Pending',
                data: [35, 41, 36, 26, 45]
            }],
            chart: {
                type: 'bar',
                height: 350
            },
            plotOptions: {
                bar: {
                    horizontal: false,
                    columnWidth: '55%',
                    endingShape: 'rounded'
                },
            },
            dataLabels: {
                enabled: false
            },

            stroke: {
                show: true,
                width: 2,
                colors: ['transparent']
            },
            xaxis: {
                categories: years,
            },
            yaxis: {
                logBase: 40,
                tickAmount: 9,
                min: 0,
                max: 120,
                title: {
                    text: 'Scope Certificate',
                }
            },
            fill: {
                opacity: 1
            },
            tooltip: {
                y: {
                    formatter: function(val) {
                        return  + val + ' ' + "Certificate"
                    }
                }
            }
        };

        var chart = new ApexCharts(document.querySelector("#chart"), options);
        chart.render();


        /*Spline Area Chart*/

        var options = {
            series: [{
                name: 'Total',
                data: [31, 40, 28, 51, 42]
            }, {
                name: 'Approved',
                data: [11, 32, 45, 32, 34]
            }, {
                name: 'Pending',
                data: [23, 4, 4, 4, 34]
            }],
            chart: {
                height: 350,
                type: 'area'
            },
            dataLabels: {
                enabled: false
            },
            stroke: {
                curve: 'smooth'
            },
            xaxis: {
                categories: years,
            },
            tooltip: {
                x: {
                    format: 'dd/MM/yy HH:mm'
                },
            },
            yaxis: {
                logBase: 40,
                tickAmount: 9,
                min: 0,
                max: 87,
                title: {
                    text: 'Transaction Certificate'
                }
            },
            fill: {
                opacity: 1
            },
            tooltip: {
                y: {
                    formatter: function(val) {
                        return  + val + ' ' + "TC"
                    }
                }
            }
        };


        var chart = new ApexCharts(document.querySelector("#chartsplinearea"), options);
        chart.render();



        /* Multiple Y-Axis Charts */
        var options = {
            series: [44, 444],
            labels: ["Pending", "Approved"],
            chart: {
                width: 380,
                type: 'donut',
            },
            dataLabels: {
                enabled: false
            },

            responsive: [{
                breakpoint: 480,
                options: {
                    chart: {
                        width: 200
                    },
                    legend: {
                        show: false
                    }
                }
            }],
            legend: {
                position: 'bottom',
                offsetY: 10,
                height: 30,
            },
            plotOptions: {
                pie: {
                    donut: {
                        labels: {
                            show: true,
                            total: {
                                label: 'Received',
                                showAlways: true,
                                show: true
                            }
                        }
                    }
                }
            },

        };

        var chart = new ApexCharts(document.querySelector("#multi_chart"), options);
        chart.render();


        function appendData() {
            var arr = chart.w.globals.series.slice()
            arr.push(Math.floor(Math.random() * (100 - 1 + 1)) + 1)
            return arr;
        }

        function removeData() {
            var arr = chart.w.globals.series.slice()
            arr.pop()
            return arr;
        }

        function randomize() {
            return chart.w.globals.series.map(function() {
                return Math.floor(Math.random() * (100 - 1 + 1)) + 1
            })
        }

        function reset() {
            return options.series
        }



        $('#inputPassword2').on('change', function() {
            alert(this.value);
        });

        //--------------clock js by gaurav--------------
        $(document).ready(function() {
            clockUpdate();
            setInterval(clockUpdate, 1000);
        })

        function clockUpdate() {
            var date = new Date();
            $('.digital-clock').css({
                'color': '#fff',
                'text-shadow': '0 0 6px #ff0'
            });

            function addZero(x) {
                if (x < 10) {
                    return x = '0' + x;
                } else {
                    return x;
                }
            }

            function twelveHour(x) {
                if (x > 12) {
                    return x = x - 12;
                } else if (x == 0) {
                    return x = 12;
                } else {
                    return x;
                }
            }

            var h = addZero(twelveHour(date.getHours()));
            var m = addZero(date.getMinutes());
            var s = addZero(date.getSeconds());

            $('.digital-clock').text(h + ':' + m + ':' + s)
        }

        var options = {
          series: [{
          data: [10, 15, 12, 14, 23, ]
        }],
          chart: {
          type: 'bar',
          height: 380
        },
        plotOptions: {
          bar: {
            barHeight: '100%',
            distributed: true,
            horizontal: true,
            dataLabels: {
              position: 'bottom'
            },
          }
        },
        colors: ['#FF5733', '#C70039', '#900C3F', '#581845', '#DAF7A6', '#FFC300', '#FF5733', '#C70039',
          '#900C3F', '#581845'
        ],
        dataLabels: {
          enabled: true,
          textAnchor: 'start',
          style: {
            colors: ['#fff']
          },
          formatter: function (val, opt) {
            return opt.w.globals.labels[opt.dataPointIndex] + ":  " + val
          },
          offsetX: 0,
          dropShadow: {
            enabled: true
          }
        },
        stroke: {
          width: 1,
          colors: ['#fff']
        },
        xaxis: {
          categories: ['Bihar', 'Punjab', 'Goa',
            'Punjab', 'Kerala'
          ],
        },
        yaxis: {
          labels: {
            show: false
          }
        },
        title: {
            text: 'Exporting States',
            align: 'center',
            floating: true
        },
        // subtitle: {
        //     text: 'Category Names as DataLabels inside bars',
        //     align: 'center',
        // },
        tooltip: {
          theme: 'dark',
          x: {
            show: false
          },
          y: {
            title: {
              formatter: function () {
                return ''
              }
            }
          }
        }
        };

        var chart = new ApexCharts(document.querySelector("#exportState"), options);
        chart.render();


        google.charts.load('current', {
            'packages': ['corechart']
        });
        google.charts.load('current', {
            'packages': ['corechart']
        });
        google.charts.setOnLoadCallback(drawChartProduct);

        function drawChartProduct() {
            var data = google.visualization.arrayToDataTable([
                ['State', 'Products'],
                ['Cereals & Millets', 100],
                ['Essential oil', 55],
                ['Bajra', 69],
                ['Oils & Oleoresins', 64],
                ['Plantation Crops', 33]
            ]);

            var options = {
                title: '',
                bars: 'vertical',
                vAxis: {
                    title: 'Products',
                    format: '0'
                },
                hAxis: {
                    title: 'Product Category'
                },
                height: 350,
                width: 392,
                colors: ['#33b2df']
            };

            var chart = new google.visualization.ColumnChart(document.getElementById('exportProduct'));
            chart.draw(data, options);
        }

        // google.charts.load('current', {
        //     'packages': ['geochart']
        // });
        // google.charts.setOnLoadCallback(ImportingCountry);

        // function ImportingCountry() {
        //     var data = google.visualization.arrayToDataTable([
        //         ['Country', 'Products'],
        //         ['Germany', 100],
        //         ['United States', 200],
        //         ['Brazil', 100],
        //         ['Canada', 200],
        //         ['Africa', 100],
        //         ['India', 200],


        //     ]);
        //     var options = {
        //         title: '',
        //         // bars: 'vertical',
        //         vAxis: {
        //             title: 'Count',
        //             format: '0'
        //         },
        //         hAxis: {
        //             title: 'Country Name'
        //         },
        //         height: 350,
        //         width: 445,
        //         colors: ['#1b9e77']
        //     };

        //     var chart = new google.visualization.GeoChart(document.getElementById('ImportingCountry'));
        //     chart.draw(data, options);
        // }

        var options = {
          series: [{
          data: [100, 150, 123, 147, 231, ]
        }],
          chart: {
          type: 'bar',
          height: 380
        },
        plotOptions: {
          bar: {
            barHeight: '100%',
            distributed: true,
            horizontal: true,
            dataLabels: {
              position: 'bottom'
            },
          }
        },
        colors: ['#33b2df', '#546E7A', '#d4526e', '#13d8aa', '#A5978B', '#2b908f', '#f9a3a4', '#90ee7e',
          '#f48024', '#69d2e7'
        ],
        dataLabels: {
          enabled: true,
          textAnchor: 'start',
          style: {
            colors: ['#fff']
          },
          formatter: function (val, opt) {
            return opt.w.globals.labels[opt.dataPointIndex] + ":  " + val
          },
          offsetX: 0,
          dropShadow: {
            enabled: true
          }
        },
        stroke: {
          width: 1,
          colors: ['#fff']
        },
        xaxis: {
          categories: ['United Kingdom', 'Italy', 'France',
            'United States', 'India'
          ],
        },
        yaxis: {
          labels: {
            show: false
          }
        },
        title: {
            text: 'Importing Countries',
            align: 'center',
            floating: true
        },
        // subtitle: {
        //     text: 'Category Names as DataLabels inside bars',
        //     align: 'center',
        // },
        tooltip: {
          theme: 'dark',
          x: {
            show: false
          },
          y: {
            title: {
              formatter: function () {
                return ''
              }
            }
          }
        }
        };

        var chart = new ApexCharts(document.querySelector("#ImportingCountry"), options);
        chart.render();


        google.charts.load('current', {
            'packages': ['corechart']
        });
        google.charts.setOnLoadCallback(ExportProduct);

        function ExportProduct() {
            var data = google.visualization.arrayToDataTable([
                ['Product Name', 'Count'],
                ['Apple', 80],
                ['Maze', 21],
                ['Rice', 33],
                ['Wheat', 67],
                ['Pulse', 39]
            ]);

            var options = {
                title: '',
                bars: 'vertical',
                vAxis: {
                    title: 'Count',
                    format: '0'
                },
                hAxis: {
                    title: 'Product Name'
                },
                height: 350,
                width: 391,
                colors: ['#1b9e77']
            };

            var chart = new google.visualization.ColumnChart(document.getElementById('exportedProduct'));
            chart.draw(data, options);
        }
        google.charts.load('current', {
            'packages': ['corechart']
        });
        google.charts.setOnLoadCallback(DomesticTc);

        function DomesticTc() {
            var data = google.visualization.arrayToDataTable([
                ['Product Name', 'TC'],
                ['1st Bite Rice and Dal', 40],
                ['Barley Flakes', 26],
                ['Basmati rice', 33],
                ['Broken rice', 70],
                ['Brown rice flakes', 34]
            ]);

            var options = {
                title: '',
                bars: 'vertical',
                vAxis: {
                    title: 'TC',
                    format: '0'
                },
                hAxis: {
                    title: 'Product Name'
                },
                height: 350,
                width: 395,
                colors: ['#1b9e77']
            };

            var chart = new google.visualization.ScatterChart(document.getElementById('domesticTcIssue'));
            chart.draw(data, options);
        }
        var currentYear = new Date().getFullYear();

        var years = [];
        for (var i = 2019; i <= currentYear; i++) {
            years.push(i);
        }
        var options = {
            series: [{
                name: 'Domestic TC',
                data: [44, 55, 57, 56, 40]
            }, {
                name: 'Domestic PTC',
                data: [76, 85, 101, 98, 87]
            }, {
                name: 'TC Issued',
                data: [35, 41, 36, 26, 45]
            }],
            chart: {
                type: 'bar',
                height: 350
            },
            plotOptions: {
                bar: {
                    horizontal: false,
                    columnWidth: '55%',
                    endingShape: 'rounded'
                },
            },
            dataLabels: {
                enabled: false
            },

            stroke: {
                show: true,
                width: 2,
                colors: ['transparent']
            },
            xaxis: {
                categories: years,
            },
            yaxis: {
                logBase: 40,
                tickAmount: 9,
                min: 0,
                max: 100,
                title: {
                    text: 'Certificate Count',
                }
            },
            fill: {
                opacity: 1
            },
            tooltip: {
                y: {
                    formatter: function(val) {
                        return   val
                    }
                }
            }
        };
        var chart = new ApexCharts(document.querySelector("#TcPtc"), options);
        chart.render();
        // No of operator CB wise
        google.charts.load('current', {
            'packages': ['corechart']
        });
        google.charts.setOnLoadCallback(CbwiseOperator);

        function CbwiseOperator() {
            var data = google.visualization.arrayToDataTable([
                ['CB Name', 'Operator'],
                ['CB NEW', 320],
                ['test1 cb', 70],
                ['new CB', 92],
                ['cb name test', 122],
                ['Gram Seva Samiti', 305]
            ]);

            var options = {
                title: '',
                bars: 'vertical',
                vAxis: {
                    title: 'CB Name',
                    format: '0'
                },
                hAxis: {
                    title: 'No. of Operator'
                },
                height: 350,
                width: 390,
                colors: ['#FF5733']
            };

            var chart = new google.visualization.BarChart(document.getElementById('noofoperatorcbwise'));
            chart.draw(data, options);
        }

        var currentYear = new Date().getFullYear();

        var years = ['Bihar', 'Haryana', 'Uttar Pradesh', 'Madhya Pradesh', 'Chandigarh', 'Punjab'];
        /* for (var i = 2019; i <= currentYear; i++) {
             years.push(i);
         }*/
        var options = {
            series: [{
                name: 'Grower Group',
                data: [44, 55, 57, 56, 40, 34]
            }, {
                name: 'INDIVIDUAL PRODUCER',
                data: [76, 85, 101, 98, 87, 98]
            }, {
                name: 'WILD',
                data: [44, 23, 45, 67, 23, 33]
            }, {
                name: 'TRADER',
                data: [23, 54, 54, 30, 88, 99]
            }, {
                name: 'PROCESSOR',
                data: [07, 56, 11, 87, 54, 25]
            }],
            chart: {
                type: 'bar',
                height: 350
            },
            plotOptions: {
                bar: {
                    horizontal: false,
                    columnWidth: '55%',
                    endingShape: 'rounded'
                },
            },
            dataLabels: {
                enabled: false
            },

            stroke: {
                show: true,
                width: 2,
                colors: ['transparent']
            },
            xaxis: {
                categories: years,
            },
            yaxis: {
                logBase: 40,
                tickAmount: 9,
                min: 0,
                max: 100,
                title: {
                    text: 'Operators',
                }
            },
            fill: {
                opacity: 1
            },
            tooltip: {
                y: {
                    formatter: function(val) {
                        return  + val + ' ' + "Operator"
                    }
                }
            }
        };

        var chart = new ApexCharts(document.querySelector("#noOfOperatorStateWise"), options);
        chart.render();
        // CB wise area, production and export
        var currentYear = new Date().getFullYear();

        var cb_name = ['CB NEW', 'test1 cb', 'Demo CB new', 'new CB', 'test demo cb', 'CB name'];
        /* for (var i = 2019; i <= currentYear; i++) {
            years.push(i);
        }*/
        var options = {
            series: [{
                name: 'Area',
                data: [10, 55, 57, 56, 00, 34]
            }, {
                name: 'Production',
                data: [76, 43, 15, 201, 87, 98]
            }, {
                name: 'Export',
                data: [10, 23, 22, 67, 67, 45]
            }],
            chart: {
                type: 'bar',
                height: 350
            },
            plotOptions: {
                bar: {
                    horizontal: false,
                    columnWidth: '55%',
                    endingShape: 'rounded'
                },
            },
            dataLabels: {
                enabled: false
            },

            stroke: {
                show: true,
                width: 2,
                colors: ['transparent']
            },
            xaxis: {
                categories: cb_name,
                title: 'CB Name'
            },
            yaxis: {
                logBase: 40,
                tickAmount: 9,
                min: 0,
                max: 100,
                title: {
                    text: 'Count',
                }
            },
            fill: {
                opacity: 1
            },
            tooltip: {
                y: {
                    formatter: function(val) {
                        return  + val + ' ' + "Count"
                    }
                }
            }
        };
        var chart = new ApexCharts(document.querySelector("#CbWiseAreaProExport"), options);
        chart.render();
        // CB wise highest export and domestic TCs (Monthly and yearly)
        var cb_name = ['CB NEW', 'test1 cb', 'Demo CB new', 'new CB', 'test demo cb', 'CB name'];

        var options = {
            series: [{
                name: 'Highest Export',
                data: [32, 100, 89, 00, 56, 200]
            }, {
                name: 'Domestic TC',
                data: [56, 80, 488, 300, 78, 84]
            }],
            chart: {
                type: 'bar',
                height: 350
            },
            plotOptions: {
                bar: {
                    horizontal: false,
                    columnWidth: '55%',
                    endingShape: 'rounded'
                },
            },
            dataLabels: {
                enabled: false
            },

            stroke: {
                show: true,
                width: 2,
                colors: ['transparent']
            },
            xaxis: {
                categories: cb_name,
                title: 'CB Name'
            },
            yaxis: {
                logBase: 40,
                tickAmount: 9,
                min: 0,
                max: 150,
                title: {
                    text: 'Count',
                }
            },
            fill: {
                opacity: 1
            },
            tooltip: {
                y: {
                    formatter: function(val) {
                        return  + val + ' ' + "Count"
                    }
                }
            }
        };

        var chart = new ApexCharts(document.querySelector("#highestexportCbTc"), options);
        chart.render();

        // CB wise area in State and outside the State may be show in graph
        var cb_name = ['CB NEW', 'test1 cb', 'Demo CB new', 'new CB', 'test demo cb', 'CB name'];

        var options = {
            series: [{
                name: 'In State',
                data: [10, 100, 89, 88, 33, 54]
            }, {
                name: 'Outside State',
                data: [77, 70, 20, 100, 76, 98]
            }],
            chart: {
                type: 'bar',
                height: 350
            },
            plotOptions: {
                bar: {
                    horizontal: false,
                    columnWidth: '55%',
                    endingShape: 'rounded'
                },
            },
            dataLabels: {
                enabled: false
            },

            stroke: {
                show: true,
                width: 2,
                colors: ['transparent']
            },
            xaxis: {
                categories: cb_name,
            },
            yaxis: {
                logBase: 40,
                tickAmount: 9,
                min: 0,
                max: 150,
                title: {
                    text: 'Count',
                }
            },
            fill: {
                opacity: 1
            },
            tooltip: {
                y: {
                    formatter: function(val) {
                        return  + val + ' ' + "Count"
                    }
                }
            }
        };
        var chart = new ApexCharts(document.querySelector("#cbwiseareaiostate"), options);
        chart.render();



        // Graphs on financial year and calendar year wise Area v/s Production v/s Export
        var currentYear = new Date().getFullYear();

        var years = [];
        for (var i = 2019; i <= currentYear; i++) {
            years.push(i);
        }

        var options = {
            series: [{
                name: 'Suspended CB',
                data: [10, 100, 89, 88, 33, 54]
            }, {
                name: 'Accredited CB',
                data: [77, 70, 200, 100, 76, 98]
            }],
            chart: {
                type: 'bar',
                height: 320
            },
            plotOptions: {
                bar: {
                    horizontal: false,
                    columnWidth: '55%',
                    endingShape: 'rounded'
                },
            },
            dataLabels: {
                enabled: false
            },

            stroke: {
                show: true,
                width: 2,
                colors: ['transparent']
            },
            xaxis: {
                categories: years,
            },
            yaxis: {
                logBase: 40,
                tickAmount: 9,
                min: 0,
                max: 120,
                title: {
                    text: 'Count',
                }
            },
            fill: {
                opacity: 1
            },
            tooltip: {
                y: {
                    formatter: function(val) {
                        return  + val + ' ' + "Count"
                    }
                }
            }
        };

        var chart = new ApexCharts(document.querySelector("#movement"), options);
        chart.render();

        google.charts.load("current", {
            packages: ["corechart", "bar"]
        });
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {
            var data = google.visualization.arrayToDataTable([
                ['Year', 'Area', 'Production', 'Export'],
                ['2012', 1000, 400, 200],
                ['2013', 1170, 460, 250],
                ['2014', 660, 1120, 300],
                ['2015', 1030, 540, 350],
                // Add more data as needed
            ]);

            var options = {
                chart: {
                    title: 'Area vs Production vs Export',
                    subtitle: 'Financial Year and Calendar Year Comparison',
                },
                vAxis: {
                    title: 'Values'
                },
                hAxis: {
                    title: 'Year'
                },
                seriesType: 'bars',
                series: {
                    2: {
                        type: 'line'
                    }
                },
                height: 300,
                width: 400
            };

            var chart = new google.visualization.ComboChart(document.getElementById('fyearcyear'));
            chart.draw(data, options);
        }
        google.charts.load('current', {
            'packages': ['geochart'],
            'mapsApiKey': 'AIzaSyD-9tSrke72PouQMnMX-a7eZSW0jkFMBWY' // Replace with your Google Maps API Key
        });
        google.charts.setOnLoadCallback(drawRegionsMap);

        function drawRegionsMap() {
            var data = google.visualization.arrayToDataTable([
                ['State', 'CB', ],
                ['Uttar Pradesh', 50, ],
                ['Maharashtra', 60, ],
                ['Bihar', 10, ],
                ['West Bengal', 16, ],
                ['Jammu and Kashmir', 16, ],
                // Add more states as needed
            ]);

            var options = {
                region: 'IN',
                displayMode: 'regions',
                resolution: 'provinces',
                colorAxis: {
                    colors: ['#e7f0fa', '#084594']
                },
                backgroundColor: '#81d4fa',
                datalessRegionColor: '#f8bbd0',
                defaultColor: '#f5f5f5',
                height: 400,
                width: 400
            };

            var chart = new google.visualization.GeoChart(document.getElementById('regions_div'));

            chart.draw(data, options);
        }

        simplemaps_countrymap.hooks.ready = function (){
            simplemaps_countrymap.load();
        }

        function getStateStatMap(id){
           // alert(id);
            let url = "{{route('superadmin.reports')}}"+'?uid='+id;
            window.open(
                url,
                '_blank'
            );
        }
    </script>

@endpush

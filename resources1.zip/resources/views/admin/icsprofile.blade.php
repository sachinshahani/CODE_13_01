@extends('admin.layouts.app')

@section('content')
    <style>
        .wrapper {
            max-width: 1240px;
            margin: 0 auto;
        }

        .white-bg {
            background-color: white;
            /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
            border-bottom: 5px solid #ff9800;
            margin-bottom: 15px;
        }

        .auth-one-bg .slide .carousel-indicators {
            bottom: 25px;
        }

        .auth-page-wrapper .auth-page-content {
            padding-bottom: 0px !important;
        }

        .auth-page-content .card {
            margin-bottom: 0rem;
        }

        .data-tabs .wrapper .nav-tabs button {
            font-size: 17px;
            color: black;
        }

        .data-tabs .wrapper .nav-tabs .active {
            background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
            */ color: white;
            background: orange;
            border-radius: 0px;
        }

        .carousel-caption.d-none.d-md-block {
            background-color: #000000bf;
            left: 0;
            width: 100%;
            bottom: 0;
        }

        .carousel-indicators {
            display: none;
        }

        .custom-banner-caption {
            color: white !important;
        }

        .announcement-heading {
            font-size: 1.2em;
            font-weight: 600;
        }

        .data-tabs .tab-pane ul li {
            font-size: 1em;
            padding: 5px 0;

        }

        .main-logo {
            padding: 10px;
        }

        .data-tabs .nav-item .nav-link {
            background-image: none;
        }

        /* .right-sec{
        box-shadow: 5px 10px 18px #888888;
    } */
        .navbar-brand-box {
            background: #fff;
        }

        .btn-danger {
            background-color: #40895a;
            border: 1px solid #40895a;
        }

        [data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
            color: white !important;
        }

        .header-buttons .btn-primary {
            margin-right: 10px;
            padding: 6px 15px;
            font-weight: 600;
            background-color: #207005;
            border: none;
            box-shadow: 0px 2px 7px #888888;
        }

        .header-buttons .btn-secondary {
            margin-right: 10px;
            padding: 6px 15px;
            font-weight: 600;
            background-color: #72a055;
            border: none;
            box-shadow: 0px 2px 7px #888888;
        }


        .right-sec {
            border-left: 5px solid #ede7e7;
        }

        .tabdiv {
            background: white;
            padding: 20px;
            margin-top: 10px;
            border: 10px solid #dfdbd5;
        }

        .nav-tabs {
            border-bottom: 0px;
        }

        div#myTabContent {
            border: 1px solid #cccccc;
        }

        .frontfooter footer {
            padding: 20px calc(1.5rem / 2);
            position: static;
            color: #000;
            height: 60px;
            background-color: #f9f9f9;
            margin-top: 30px;
            border-top: 1px solid #e1dfdf;
        }

        span.logo-sm img {
            width: 69px;
        }

        .seperatesec {
            margin-top: 20px;
        }

        .simplebar-content li.nav-item:hover {
            background: #4caf50;
        }

        .sectitle {
            font-size: 14px;
        }

        .required {
            color: red;
        }

        .customtextarea {
            height: 120px;
        }

        ul.boxsection {
            margin: 0;
            padding: 0;
        }

        ul.boxsection li {
            list-style-type: none;
            padding: 7px 0;
            border-bottom: 1px solid #efeded;
        }

        .boxcard .col:nth-child(1) {
            background: #effcfb;
        }

        .boxcard .col:nth-child(2) {
            background: #fdfdfd;
        }

        .boxcard .col:nth-child(3) {
            background: #effcfb;
        }

        .boxcard .col:nth-child(4) {
            background: #fdfdfd;
        }

        .boxcard .col:nth-child(5) {
            background: #effcfb;
        }

        /* --registration-form css  */
        .custom-tab-content {
            padding-top: 0 !important;
            padding-bottom: 0px !important;
        }

        .custom-tab-nav {
            background: white;

        }

        .custom-tab-nav .nav-link {
            border-radius: 0 !important;
            border-bottom: 1px solid #e9ebec;
            border-right: 1px solid #e9ebec;
            font-size: 14px;
            padding: 10px;
        }

        .custom-tab-nav .nav-link.active,
        .custom-tab-nav .show>.nav-link {
            color: rgb(255, 255, 255) !important;
            background-color: #2c8c6d;
            border-bottom: #2c8c6d !important;
            /* border-bottom: #207005 !important; */
            position: relative;
        }

        .custom-tab-nav .nav-link:hover,
        .custom-tab-nav .nav-link:focus {
            border-bottom: 1px solid #207005;
            border-radius: 0;
            font-size: 14px;
            transition: background-color 0.20s linear;
        }

        .custom-tab-nav .nav-link.active:after {
            content: "";
            position: absolute;
            bottom: -16px;
            left: 50%;
            border: 8px solid transparent;
            border-top-color: #2c8c6d;
            z-index: 999;
        }

        .reg-form-btns {
            margin-bottom: 15px;
        }

        .reg-form-btns .btn-secondary {
            color: #fff;
            background-color: #405189;
            border-color: #405189;
        }

        .btn-soft-success:active,
        .btn-soft-success:focus,
        .btn-soft-success:hover {
            border: none;
        }

        .custom-tab-nav ul {
            padding: 0px;
            margin: 0px;
        }

        .custom-tab-nav ul li {
            padding: 0px;
            margin: 0px;
            display: inline-block;
            list-style: none;
        }
    </style>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">ICS Profile</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">ICS Profile</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">
            <form method="post" enctype="multipart/form-data" id="registration"
                action="{{ route('superadmin.icsuser.step1post', $userdetails->id) }}">
                @csrf
                <nav>
                    <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                        <a class="nav-link active" id="step1-tab" data-bs-toggle="tab" href="#step1">General
                            Information</a>
                        <a class="nav-link" id="step2-tab" data-bs-toggle="tab" href="#step2">Self/Mandator Details</a>
                        <a class="nav-link" id="step3-tab" data-bs-toggle="tab" href="#step3">Inspector Details</a>
                        <a class="nav-link" id="step4-tab" data-bs-toggle="tab" href="#step4">Warehouse Details</a>
                    </div>
                </nav>
                <div class="tab-content py-4 custom-tab-content">
                    <div class="tab-pane fade show active" id="step1">
                        <div class="card">
                            <div class="card-header align-items-center d-flex">
                                <h4 class="card-title mb-0 flex-grow-1">
                                    Contact Person Details
                                </h4>

                            </div>
                            <!-- end card header -->
                            <div class="card-body">
                                <div class="live-preview">

                                    <div class="row seperatesec">
                                        <div class="col-xxl-4 col-md-6">
                                            <div>
                                                <label class="form-label">First Name</label>
                                                <input type="text" class="form-control" id="placeholderInput"
                                                    placeholder="First Name" name="first_name"
                                                    value="{{ $userdetails->first_name }}" />
                                                <input type="hidden" name="roleid"
                                                    value="{{ $userdetails->roles[0]->id }}">
                                            </div>
                                        </div>

                                        <div class="col-xxl-4 col-md-6">
                                            <div>
                                                <label class="form-label">Middle Name</label>
                                                <input type="text" class="form-control" id="placeholderInput"
                                                    placeholder="Middle Name" name="middle_name"
                                                    value="{{ $userdetails->middle_name }}" />
                                            </div>
                                        </div>

                                        <div class="col-xxl-4 col-md-6">
                                            <div>
                                                <label class="form-label">Last Name</label>
                                                <input type="text" class="form-control" id="placeholderInput"
                                                    placeholder="Last Name" name="last_name"
                                                    value="{{ $userdetails->last_name }}" />
                                            </div>
                                        </div>

                                        <div class="col-xxl-4 col-md-6">
                                            <div>
                                                <label for="labelInput" class="form-label">Email Id<span
                                                        class="required">*</span></label>
                                                <input type="email" class="form-control" name="email"
                                                    placeholder="Email Id*" value="{{ $userdetails->email }}" />
                                            </div>
                                        </div>

                                        <div class="gy-3">
                                            <label for="labelInput" class="form-label">Address <span
                                                    class="required">*</span></label>
                                            <textarea placeholder="Address" class="form-control customtextarea" name="address">{{ $userdetails->address }}</textarea>
                                        </div>
                                    </div>
                                    
                                    <div class="row seperatesec">
                                        <div class="col-xxl-6 col-md-4 gy-3">
                                            <div>
                                                <label for="labelInput" class="form-label">State <span
                                                        class="required">*</span></label>
                                                <select class="form-select" name="state">
                                                    <option value="">Select State</option>
                                                    @forelse($states as $state)
                                                        <option value="{{ $state->id }}"
                                                            @if (isset($userdetails->state) && $userdetails->state == $state->id) selected @endif>
                                                            {{ $state->state_name }}</option>
                                                    @empty
                                                    @endforelse
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-xxl-6 col-md-4 gy-3">
                                            <div>
                                                <label for="labelInput" class="form-label">District <span
                                                        class="required">*</span></label>
                                                <select class="form-select" name="district">
                                                    <option value="">Select District</option>
                                                    @forelse($districts as $district)
                                                        <option value="{{ $district->id }}"
                                                            @if (isset($userdetails->district) && $userdetails->district == $district->id) selected @endif>
                                                            {{ $district->district_name }}</option>
                                                    @empty
                                                    @endforelse
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-xxl-6 col-md-4 gy-3">
                                            <div>
                                                <label for="labelInput" class="form-label">Taluka/Mandal
                                                    <span class="required">*</span></label>
                                                <select class="form-select" name="taluka">
                                                    <option value="">Select Taluka/Mandal</option>
                                                    @forelse($regions as $region)
                                                        <option value="{{ $region->id }}"
                                                            @if (isset($userdetails->taluka) && $userdetails->taluka == $region->id) selected @endif>
                                                            {{ $region->region_name }}</option>
                                                    @empty
                                                    @endforelse
                                                </select>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="row seperatesec">
                                        <div class="col-xxl-6 col-md-4 gy-3">
                                            <div>
                                                <label class="form-label">Village </label>
                                                <select class="form-select" name="village">
                                                    <option value="">Select Village</option>
                                                    @forelse($villages as $village)
                                                        <option value="{{ $village->id }}"
                                                            @if (isset($userdetails->village) && $userdetails->village == $village->id) selected @endif>
                                                            {{ $village->village_name }}</option>
                                                    @empty
                                                    @endforelse
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-xxl-6 col-md-4 gy-3">
                                            <div>
                                                <label for="labelInput" class="form-label">Pin Code<span
                                                        class="required">*</span></label>
                                                <input type="number" class="form-control" id="placeholderInput"
                                                    placeholder="Pin Code" name="pincode"
                                                    value="{{ $userdetails->pin_code }}" />
                                            </div>
                                        </div>

                                        <div class="col-xxl-6 col-md-4 gy-3 ">
                                            <div>
                                                <label for="basiInput" class="form-label">Legal Document
                                                </label>
                                                <div class="input-group">
                                                    <select class="form-select" name="document_type">
                                                        <option value="pan"
                                                            {{ isset($userdetails->document_type) && $userdetails->document_type == 'pan' ? 'selected' : '' }}>
                                                            PAN</option>
                                                        <option value="company_registration_number"
                                                            {{ isset($userdetails->document_type) && $userdetails->document_type == 'company_registration_number' ? 'selected' : '' }}>
                                                            Company Registration Number</option>
                                                        <option value="society_registration_number"
                                                            {{ isset($userdetails->document_type) && $userdetails->document_type == 'society_registration_number' ? 'selected' : '' }}>
                                                            Society Registration Number</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="row seperatesec ">
                                        <div class="col-xxl-4 col-md-6  gy-3">
                                            <div class="card">
                                                <div class="card-header">
                                                    <h4 class="card-title mb-0">Appointment Letter</h4>
                                                </div><!-- end card header -->

                                                <div class="dropzone">
                                                    <div class="fallback">
                                                        <input name="file" type="file">
                                                    </div>
                                                    <div class="dz-message needsclick">
                                                        <div class="mb-3">
                                                            <i class="display-4 text-muted ri-upload-cloud-2-fill"></i>
                                                        </div>

                                                        <h4>Drop files here or click to upload.</h4>
                                                    </div>
                                                    <div class="hidden_images_area"><input type="hidden"
                                                            name="_hidden_legal_doc_upload"
                                                            value="{{ isset($userdetails) && $userdetails->legal_doc_upload != '' ? $userdetails->legal_doc_upload : '' }}"
                                                            required /></div>
                                                </div>
                                                <!-- end card body -->
                                            </div>

                                        </div>

                                        <div class="row seperatesec ">
                                            <div class="col-xxl-6 col-md-4  gy-3 ">
                                                <div>
                                                    <label for="labelInput" class="form-label">Number of Farmers<span
                                                            class="required">*</span></label>
                                                    <input type="text" class="form-control" id="placeholderInput"
                                                        placeholder="Number of Farmers*" name="no_of_farmers"
                                                        value="{{ $userdetails->no_of_farmers }}" />
                                                </div>
                                            </div>
                                            <div class="col-xxl-6 col-md-4 gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">Number of
                                                        Inspector<span class="required">*</span></label>
                                                    <input type="text" class="form-control" id="placeholderInput"
                                                        placeholder="Number of Inspector" name="no_of_inspector"
                                                        value="{{ $userdetails->no_of_inspector }}" />
                                                </div>
                                            </div>

                                            <div class="col-xxl-6 col-md-4 gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">Managed by<span
                                                            class="required">*</span></label>
                                                    <br>
                                                    <input type="radio" id="html" name="managed_by"
                                                        value="self"
                                                        {{ $userdetails->managed_by == 'self' ? 'checked' : '' }}>
                                                    <label for="self">Self</label>
                                                    <input type="radio" id="css" name="managed_by"
                                                        value="mandator"
                                                        {{ $userdetails->managed_by == 'mandator' ? 'checked' : '' }}>
                                                    <label for="Mandator">Mandator</label><br>
                                                </div>
                                            </div>

                                        </div>



                                        <!--address sec end-->

                                        <div class="row">
                                            <div class="col-lg-12 gy-4">
                                                <div class="hstack gap-2">
                                                    <button type="submit" class="btn btn-primary" id="submitbtn">
                                                        Submit
                                                    </button>
                                                    <a href="{{ route('superadmin.icsuser.step2', $userdetails->id) }}"
                                                        class="btn btn-soft-success">
                                                        Next
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </form>
        </div>
    </div>
@endsection
@push('script')
<script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
    <script>
        $(document).on('click', '#submitbtn', function() {

            if (checkValidation("registration")) {
                $('#registration').submit();
                return true;
            } else {
                return false;
            }
        });

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        // Dropzone has been added as a global variable.
        const dropzone = new Dropzone("div.dropzone", {
            url: "{{ route('storeMedia') }}",
            paramName: "file",
            maxFilesize: 2,
            maxFiles: 1,
            acceptedFiles: ".jpeg,.jpg,.png,.mp4,.webm,.html5",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            init: function() {
                var drop = this; // Closure
                this.on('error', function(file, errorMessage) {
                    if (errorMessage.indexOf('Error 404') !== -1) {
                        var errorDisplay = document.querySelectorAll('[data-dz-errormessage]');
                        errorDisplay[errorDisplay.length - 1].innerHTML =
                            'Error 404: The upload page was not found on the server';
                    }
                    if (errorMessage.indexOf('File is too big') !== -1) {
                        alert('Unable to upload image size is greated than 2 MB');
                        // i remove current file
                        drop.removeFile(file);
                    }
                });
                this.on("maxfilesexceeded", function(file) {
                        this.removeAllFiles();
                        this.addFile(file);
                    }),
                    this.on("success", function(file, response) {
                        console.log(response);
                        var hiddenImage = $('<input type="hidden" name="_hidden_legal_doc_upload" value="' +
                            response.name + '"/>');
                        $('.hidden_images_area').html(hiddenImage);
                    })
            }
        });
    </script>
@endpush

@extends('admin.layouts.app')

@section('content')
<style>
    .wrapper{
    max-width: 1240px; margin:0 auto;
}
.white-bg{
    background-color: white;
    /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
    border-bottom:5px solid #ff9800;
    margin-bottom:15px;
}
.auth-one-bg .slide .carousel-indicators {
    bottom: 25px;
}
.auth-page-wrapper .auth-page-content{
    padding-bottom: 0px !important;
}
.auth-page-content  .card {
     margin-bottom: 0rem;
}
.data-tabs .wrapper .nav-tabs button {
    font-size: 17px;
    color: black;
}
.data-tabs .wrapper .nav-tabs .active{
    background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f); */
    color: white;
    background: orange;
    border-radius: 0px;
}
.carousel-caption.d-none.d-md-block {
    background-color: #000000bf;
    left: 0;
    width: 100%;
    bottom: 0;
}
.carousel-indicators {
    display: none;
}
.custom-banner-caption {
    color: white !important;
} 
.announcement-heading{
    font-size: 1.2em;
    font-weight: 600;
}
.data-tabs .tab-pane ul li{
font-size: 1em;
padding: 5px 0;

}
.main-logo{
    padding: 10px;
}
.data-tabs .nav-item .nav-link {
    background-image:none ;
}
/* .right-sec{
    box-shadow: 5px 10px 18px #888888;
} */
.navbar-brand-box {
    background: #fff;
}
.btn-danger {
    background-color: #40895a;
    border: 1px solid #40895a;
}
[data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
    color: white !important;
}
.header-buttons .btn-primary {
    margin-right: 10px;
    padding: 6px 15px;
    font-weight: 600;
    background-color: #207005;
    border: none;
    box-shadow: 0px 2px 7px #888888;
}
.header-buttons .btn-secondary {
    margin-right: 10px;
    padding: 6px 15px;
    font-weight: 600;
    background-color: #72a055;
    border: none;
    box-shadow: 0px 2px 7px #888888;
}


.right-sec { border-left: 5px solid #ede7e7; }
.tabdiv { background: white;  padding: 20px;  margin-top: 10px;  border: 10px solid #dfdbd5; }

.nav-tabs {border-bottom:0px; }
div#myTabContent { border: 1px solid #cccccc;}
.frontfooter footer { padding: 20px calc(1.5rem / 2); position: static; color: #000; height: 60px; background-color: #f9f9f9;
    margin-top: 30px; border-top: 1px solid #e1dfdf; }
span.logo-sm img { width: 69px;}

.seperatesec{margin-top:20px;}
.simplebar-content li.nav-item:hover {  background: #4caf50;}
.sectitle{font-size: 14px;}
.required { color: red; }
.customtextarea{height: 120px;}

ul.boxsection { margin: 0; padding: 0;}
ul.boxsection li { list-style-type: none; padding: 7px 0; border-bottom: 1px solid #efeded;}
.boxcard .col:nth-child(1) { background: #effcfb;}
.boxcard .col:nth-child(2) { background: #fdfdfd;}
.boxcard .col:nth-child(3) { background: #effcfb;}
.boxcard .col:nth-child(4) { background: #fdfdfd;}
.boxcard .col:nth-child(5) { background: #effcfb;}

/* --registration-form css  */
.custom-tab-content {
    padding-top: 0 !important;
    padding-bottom: 0px !important;
}
.custom-tab-nav {
    background: white;
    
}
.custom-tab-nav .nav-link {
    border-radius: 0 !important;
    border-bottom: 1px solid #e9ebec;
    border-right: 1px solid #e9ebec;
    font-size: 14px;
    padding: 10px;
}
.custom-tab-nav .nav-link.active, .custom-tab-nav .show>.nav-link{
    color: rgb(255, 255, 255) !important;
    background-color: #2c8c6d;
    border-bottom: #2c8c6d !important;
    /* border-bottom: #207005 !important; */
    position:relative;
}
.custom-tab-nav .nav-link:hover, .custom-tab-nav .nav-link:focus {
    border-bottom: 1px solid #207005;
    border-radius: 0;
    font-size: 14px;
    transition: background-color 0.20s linear;
}
.custom-tab-nav .nav-link.active:after {
    content: "";
    position: absolute;
    bottom: -16px;
    left: 50%;
    border: 8px solid transparent;
    border-top-color: #2c8c6d;
    z-index: 999;
}
.reg-form-btns {
    margin-bottom: 15px;
}
.reg-form-btns .btn-secondary {
    color: #fff;
    background-color: #405189;
    border-color: #405189;
}
.btn-soft-success:active, .btn-soft-success:focus, .btn-soft-success:hover{
    border: none;
}
.custom-tab-nav ul{padding:0px; margin:0px;}
.custom-tab-nav ul li{padding:0px; margin:0px; display: inline-block; list-style: none;}
</style> 
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0">ICS Profile</h4>

                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                            <li class="breadcrumb-item active">ICS Profile</li>
                        </ol>
                    </div>

                </div>
            </div>
        </div>
        <!-- end page title -->

        <div class="row">
            <div class="col-lg-12">
                <form method="post" id="registration"  action="{{route('superadmin.icsuser.step2post',$userdetails->id)}}">
                @csrf 
                <input type="hidden" name="roleid" value="{{$userdetails->roles[0]->id}}">
                    <nav>
                        <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                            <a class="nav-link" id="step1-tab" data-bs-toggle="tab"
                                href="#step1">General Information</a>
                            <a class="nav-link active" id="step2-tab" data-bs-toggle="tab"
                                href="#step2">Self/Mandator Details</a>
                            <a class="nav-link" id="step3-tab" data-bs-toggle="tab"
                                href="#step3">Inspector Details</a>
                            <a class="nav-link" id="step4-tab" data-bs-toggle="tab"
                                href="#step4">Warehouse Details</a>   
                        </div>
                    </nav>
                    <div class="tab-content py-4 custom-tab-content">
                        <div class="tab-pane fade show active" id="step2">
                            <!-- include self details -->
                            @if($userdetails->managed_by==='self')
                            @include('admin/ics/self')
                            @else
                            @include('admin/ics/mandator')
                            @endif
                            <!-- include mandator details -->
                        </div>
                        
                        
                    </div>
                   
                </form>
            </div>
        </div>
 


@endsection



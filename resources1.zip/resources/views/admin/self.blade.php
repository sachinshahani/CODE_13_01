<div class="card">
    <div class="card-header align-items-center d-flex">
        <h4 class="card-title mb-0 flex-grow-1">
            Self-Details
        </h4>
        <div class="flex-shrink-0">
            @if (session('error'))
            <div class="alert alert-danger">
                {{ session('error') }}
            </div>
        @endif
        @if (session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif
        @if($errors)
            @foreach ($errors->all() as $error)
                <div class="alert alert-danger">{{ $error }}</div>
            @endforeach
        @endif 
    </div>
            
    </div>
    <!-- end card header -->
    <div class="card-body">
        <div class="live-preview">
            <div class="row seperatesec">
                <div class="col-xxl-4 col-md-6">
                    <div>
                        <label class="form-label">First Name</label>
                        <input type="text" class="form-control" id="placeholderInput"
                            placeholder="First Name" name="first_name" value="{{ $userselfdetail->first_name ??''}}"/>
                    </div>
                </div>

                <div class="col-xxl-4 col-md-6">
                    <div>
                        <label class="form-label">Middle Name</label>
                        <input type="text" class="form-control" id="placeholderInput"
                            placeholder="Middle Name" name="middle_name" value="{{ $userselfdetail->middle_name ??''}}"/>
                    </div>
                </div>

                <div class="col-xxl-4 col-md-6">
                    <div>
                        <label class="form-label">Last Name</label>
                        <input type="text" class="form-control" id="placeholderInput"
                            placeholder="Last Name"  name="last_name" value="{{ $userselfdetail->last_name ??''}}"/>
                    </div>
                </div>
                <div class="col-xxl-4 col-md-6">
                    <div>
                        <label for="labelInput" class="form-label">Email Id<span
                                class="required">*</span></label>
                        <input type="text" class="form-control" id="placeholderInput"
                            placeholder="Email Id*" name="email" value="{{ $userselfdetail->email ??''}}"/>
                    </div>
                </div>

                <div class="gy-3">
                    <label for="labelInput" class="form-label">Office Address <span
                            class="required">*</span></label>
                    <textarea placeholder="Address" class="form-control customtextarea" name="address">{{ $userselfdetail->address ??''}}</textarea>
                </div>
            </div>
            
            
                                        <div class="row seperatesec">
                                            <div class="col-xxl-6 col-md-4 gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">State <span
                                                            class="required">*</span></label>
                                                        <select class="form-select" name="state">
                                                        <option value="">Select State</option>
                                                        @forelse($states as $state)
                                                        
                                                            <option value="{{$state->id}}" {{(isset($userselfdetail) && $userselfdetail->state==$state->id ? 'selected':'' )}}>{{$state->state_name}}</option>
                                                            @empty
                                                        @endforelse
                                                        </select>
                                                </div>
                                            </div>
                                            <div class="col-xxl-6 col-md-4 gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">District <span
                                                            class="required">*</span></label>
                                                            <select class="form-select" name="district">
                                                                <option value="">Select District</option> 
                                                                @forelse($districts as $district)
                                                                    <option value="{{$district->id}}" {{(isset($userselfdetail) && $userselfdetail->district==$district->id ? 'selected':'')}}>{{$district->district_name}}</option>
                                                                @empty
                                                                @endforelse                              
                                                            </select>
                                                </div>
                                            </div>
                                            <div class="col-xxl-6 col-md-4 gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">Taluka/Mandal
                                                        <span class="required">*</span></label>
                                                        <select class="form-select" name="taluka">
                                                            <option value="">Select Taluka/Mandal</option>
                                                            @forelse($regions as $region)
                                                            <option value="{{$region->id}}" {{(isset($userselfdetail->taluka) && $userselfdetail->taluka==$region->id ? 'selected':'' )}}>{{$region->region_name}}</option>
                                                            @empty
                                                        @endforelse                                                                
                                                        </select>
                                                </div>
                                            </div>
                                          
                                        </div>
                                        <div class="row seperatesec">
                                            <div class="col-xxl-6 col-md-4 gy-3">
                                                <div>
                                                    <label class="form-label">Village </label>
                                                    <select class="form-select" name="village">
                                                        <option value="">Select Village</option> 
                                                        @forelse($villages as $village)
                                                            <option value="{{$village->id}}" {{(isset($userselfdetail) && $userselfdetail->village==$village->id ? 'selected' :'')}}>{{$village->village_name}}</option>
                                                        @empty
                                                        @endforelse                              
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-xxl-6 col-md-4 gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">Pin Code<span
                                                            class="required">*</span></label>
                                                    <input type="number" class="form-control" id="placeholderInput"
                                                        placeholder="Pin Code" name="pincode" value="{{ $userselfdetail->pin_code ??''}}"/>
                                                </div>
                                            </div>
                                            <div class="col-xxl-6 col-md-4  gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">Mobile Number<span
                                                            class="required">*</span></label>
                                                    <input type="text" class="form-control" id="placeholderInput"
                                                        placeholder="Mobile Number" name="mobile_no" value="{{ $userselfdetail->mobile_no ??''}}"/>
                                                </div>
                                            </div>
                                        </div>

            


            <div class="row seperatesec">
                
                
                
                <div class="col-xxl-6 col-md-6 gy-3 ">
                    <div>
                        <label for="basiInput" class="form-label">Id Proof
                        </label>
                        <div class="input-group">
                            <select class="form-select" name="id_proof">
                                <option value="pan" {{ (isset($userselfdetail) && $userselfdetail->address_proof_of_office=='pan'  ? selected:'')}}>PAN</option>
                                <option value="aadhar" {{ (isset($userselfdetail) && $userselfdetail->address_proof_of_office=='aadhar' ? selected:'')}}>Aadhar</option>
                            </select>
                        </div>
                    </div>
                </div>
               



            </div>

            <div class="row seperatesec">
                
                
                
                <div class="col-xxl-6 col-md-4  gy-3">
                    <div>
                        <label for="basiInput" class="form-label">Address Proof of Office
                        </label>
                        <div class="input-group">
                            <select class="form-select" name="address_proof_of_office">
                                <option value="electricity_bill" {{ (isset($userselfdetail) && $userselfdetail->address_proof_of_office=='electricity_bill'  ? 'selected':'')}}>Electricity Bill</option>
                                <option value="rent_agreement" {{ (isset($userselfdetail) && $userselfdetail->address_proof_of_office=='rent_agreement' ? 'selected':'')}}>Rent Agreement</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>



            <div class="row seperatesec ">

                
            </div>


            <div class="row seperatesec">
            <div class="col-xxl-4 col-md-6  gy-3">
                                                <div class="card">
                                                    <div class="card-header">
                                                        <h4 class="card-title mb-0">Profile Picture Selection</h4>
                                                    </div><!-- end card header -->

                                                    <div class="card-body">
                                                        <p class="text-muted">FilePond is a JavaScript library with profile picture-shaped file upload variation.</p>
                                                        <div class="avatar-xl mx-auto">
                                                            <input type="file" class="filepond filepond-input-circle" name="filepond" accept="image/png, image/jpeg, image/gif" />
                                                        </div>

                                                    </div>
                                                    <!-- end card body -->
                                                </div>
                                                <!-- end card -->
                                            </div>

                <div class="col-xxl-4 col-md-6  gy-3">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title mb-0">Photo of Office building:</h4>
                        </div><!-- end card header -->
                        <div class="card-body">
                            <input type="file" class="filepond filepond-input-multiple" multiple name="filepond" data-allow-reorder="true" data-max-file-size="3MB" data-max-files="3">
                        </div>
                        <!-- end card body -->
                    </div>
                    <!-- end card -->
                </div>


                <div class="col-xxl-4 col-md-6  gy-3">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title mb-0">Appointment Letter</h4>
                        </div><!-- end card header -->

                        <div class="dropzone">
                        <div class="fallback">
                            <input name="file" type="file" multiple="multiple">
                        </div>
                        <div class="dz-message needsclick">
                            <div class="mb-3">
                                <i class="display-4 text-muted ri-upload-cloud-2-fill"></i>
                            </div>

                            <h4>Drop files here or click to upload.</h4>
                        </div>
                    </div>
                    <!-- end card body -->
                </div>
                <!-- end card -->
        </div>


            <div class="row">
                <div class="col-lg-12 gy-4">
                    <div class="hstack gap-2">
                    <a href="{{route('superadmin.userprofile')}}" class="btn btn-soft-success">
                                                        Back
                                                    </a>    
                        <button type="submit" class="btn btn-primary">
                            Submit
                        </button>
                        <a href="{{route('superadmin.icsuser.step3',$userdetails->id)}}" class="btn btn-soft-success">
                                                        Next
                                                    </a>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@push('script')

<script>
                    
                    $.ajaxSetup({
                    headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                    });
                    // Dropzone has been added as a global variable.
                    const dropzone = new Dropzone("div.dropzone", {
                        url: "{{ route('storeMedia') }}",
                        paramName: "file",
                        maxFilesize: 2,
                        maxFiles: 1,
                        acceptedFiles: ".jpeg,.jpg,.png,.mp4,.webm,.html5",
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        init: function() {
                            var drop = this; // Closure
                            this.on('error', function(file, errorMessage) {
                                if (errorMessage.indexOf('Error 404') !== -1) {
                                    var errorDisplay = document.querySelectorAll('[data-dz-errormessage]');
                                    errorDisplay[errorDisplay.length - 1].innerHTML =
                                    'Error 404: The upload page was not found on the server';
                                }
                                if (errorMessage.indexOf('File is too big') !== -1) {
                                    alert('Unable to upload image size is greated than 2 MB');
                                    // i remove current file
                                    drop.removeFile(file);
                                }
                            });
                            this.on("maxfilesexceeded", function(file) {
                                this.removeAllFiles();
                                this.addFile(file);
                            }),
                            this.on("success", function(file, response) {
                                console.log(response);
                                var hiddenImage = $('<input type="hidden" name="_hidden_images[]" value="' +
                                response.name + '"/>');
                                $('.hidden_images_area').html(hiddenImage);
                            })
                        }
                    });
                    </script>

@endpush

@extends('admin.layouts.app')
@section('content')
    <!-- start page title -->

    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Apply for NOC-Split</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Apply for NOC - Split</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">
                        <div class="card-body">
                           
                                <div class="live-preview">


                                    <!--form3 tab end here-->

                                    <!--form4 tab end here-->
                                    <div class="row seperatesec white-inner">
                                        <div class="sectitle">
                                            <label for="labelInput" class="form-label blue-ht">Apply For NOC : Split Farm</label>
                                        </div>
                                      
                                        <div class="col-xxl-12 col-md-12">
                                            <div class="row pdf_maindiv ">
                                                <div class="col-xxl-4 col-md-3 ">
                                                    <label class="form-label">Farmer Registration Number :</label>
                                                </div>
                                                <div class="col-xxl-4 col-md-4 ">
                                                    <input type="text" class="form-control" value="" name="reg_no" required>
                                                    <span id="farmer_error" style="color:red;"></span>
                                                </div>
                                                @if($scopeValidity>=7)
                                                <div class="col-xxl-4 col-md-5">
                                                    <div>
                                                        <button type="button" id="" class="btn btn-primary search-button">Search</button>
                                                    </div>
                                                </div>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row seperatesec white-inner farmer-div d-none">
                                        
                                        <div class="table-responsive">

                                            <table
                                                class="table table-bordered table-striped align-middle dataTable no-footer"
                                                width="100%" id="farm-tbl">
                                                <thead>
                                                    <tr>
                                                        <th>Farm Registration No.</th>
                                                        <th>Farm Name</th>
                                                        <th>Address</th>
                                                        <th>Area (in Ha)</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody id="farm-tbody">
                                                    <tr>
                                                        <th>Farm Registration No.</th>
                                                        <th>Farm Name</th>
                                                        <th>Address</th>
                                                        <th>Area (in Ha)</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tbody>

                                            </table>
                                        </div>


                                    </div>
                                    <div class="row seperatesec white-inner farm-div d-none">
                                        <form action="{{ route('superadmin.nocSpltFarmStore') }}" method="post">
                                            @csrf
                                            <input type="hidden" name="noc_type" value="split">
                                            <input type="hidden" name="at_farmer_reg_details_id" value="">
                                            
                                            <div class="sectitle">
                                                <label for="labelInput" class="form-label blue-ht">Farm Details</label>
                                            </div>
                                        
                                            <div class="col-xxl-12 col-md-12">
                                                <div class="row pdf_maindiv ">
                                                    <div class="col-xxl-4 col-md-4 ">
                                                        <label class="form-label">Farm Registration Number :</label>
                                                        <span id="reg_val"></span>
                                                    </div>
                                                    <div class="col-xxl-4 col-md-4 ">
                                                        <label class="form-label">Farm Name : </label>
                                                        <span id="fname_val"></span>
                                                    </div>
                                                    <div class="col-xxl-4 col-md-4">
                                                        <label class="form-label">Area (in Ha) : </label>
                                                        <span id="area_val">500</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="table-responsive">
                                                <span style="color:red;">Farm area can not be exceed from the total farm area.</span>
                                        
                                                <table
                                                    class="table table-bordered table-striped align-middle dataTable no-footer"
                                                    width="100%" id="split-farm-tbl">
                                                    <thead>
                                                        <tr>
                                                            <th>New Farm Name</th>
                                                            <th>Area (in Ha)</th>
                                                            <th>Remarks</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <input type="hidden" value="" name="at_farm_details_id" id="at_farm_details_id">
                                                        <tr>
                                                            <td><input class="form-control" type="text" value="" name="split_farmer_name[]" ></td>
                                                            <td><input class="form-control numbersonly area" type="text" value="" name="split_farmer_area[]" ></td>
                                                            <td><input class="form-control" type="text" value="" name="split_remark[]" ></td>
                                                            <td><a class="add-more-tr"> Add </a></td>
                                                        </tr>
                                                    </tbody>

                                                </table>
                                            </div>
                                            <div class="col-xxl-12 col-md-12 gy-4">
                                                <div class="hstack gap-2" style="display: flex; justify-content: center; align-items: center;">
                                                    <button type="submit" id="submitbtn" class="btn btn-primary submit-button" >Submit</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>

                                {{-- <div class="row">
                            <div class="col-xxl-12 col-md-12 gy-4">
                                <div class="hstack gap-2" style="display: flex; justify-content: center; align-items: center;">
                                    <button type="submit" id="submitbtn" class="btn btn-primary submit-button">Save And Preview TC</button>
                                </div>
                            </div>
                        </div> --}}
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endsection
    @push('script')
        <script>
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            
            $("input[name=noc_type]").change(function() {
                var value = $(this).val();
                //alert(value);
                if(value == 'whole'){
                    $('.whole_div').removeClass("d-none");
                    $('.farmer_div').addClass("d-none");
                }
                if(value == 'farmer_wise'){
                    $('.whole_div').addClass("d-none");
                    $('.farmer_div').removeClass("d-none");
                }
            });
            // $('#datatable').DataTable();

            $('.search-button').on('click',function(event){
                var regno = $('input[name="reg_no"]').val();

                if(regno==''){
                    $('#farmer_error').html("This field id required.");
                    return false;
                }else{

                    if($('#farm-tbl tr').length>1) {
                        $('#farm-tbody').html("");
                    }

                    $.ajax({
                        url: "{{ route('superadmin.nocSpltFarmer') }}",
                        type: "POST",
                        data: {
                            regno: regno,
                        _token: '{{csrf_token()}}'
                        },
                        dataType : 'json',
                        success: function(result){
                        //console.log(result.data.length);
                        $('.farmer-div').removeClass('d-none');
                            if(result.status==true){
                                var tbody = '';
                                for(var i = 0; i < result.data.length; i++) {
                                    tbody += '<tr><td>' + result.data[i]['registration_no'] + '</td><td>' + result.data[i]['farm_name']+'</td><td>'+result.data[i]['address'] +'</td><td>' + result.data[i]['area'] + '</td><td><a href="javascript: void(0);" class="farm-process" data-regno="' + result.data[i]['registration_no'] + '" data-farmname="' + result.data[i]['farm_name'] + '" data-area="' + result.data[i]['area'] + '" data-row-id="'+result.data[i]['id'] +'">Process</a></td></tr>';
                            
                                }
                                $('#farm-tbody').append(tbody);
                                $("input[name='at_farmer_reg_details_id']").val( result.data[0]['farmer_id']);
                            }else{

                                tbody += '<tr colspan="5"><td>' + result.data + '</td></tr>';
                                $('#farm-tbody').append(tbody);
                            
                            }
                        }
                    });

                }
            });

            $(document).on("click", ".farm-process", function(e) {
                //console.log($(this).data('regno'));
                $('.farm-div').removeClass("d-none");
                $('#reg_val').html($(this).data('regno'));
                $('#fname_val').html($(this).data('farmname'));
                $('#area_val').html($(this).data('area'));
                $('#at_farm_details_id').val($(this).data('row-id'));
                
            });

            $(document).on("click", ".add-more-tr", function() {
                $("#split-farm-tbl tbody").append(
                    '<tr> <td><input class="form-control" type="text" value="" name="split_farmer_name[]" ></td> <td><input class="form-control numbersonly area" type="text" value="" name="split_farmer_area[]" ></td> <td><input class="form-control" type="text" value="" name="split_remark[]" ></td> <td><a class="remove-btn"> Remove </a></td> </tr>'
                );
            });

            $(document).on("click", ".remove-btn", function() {
                $(this).closest('tr').remove();
               
            });

            $(document).on("change", ".area", function(evt) {
               
                evt.preventDefault();
                var tot_area = $('#area_val').html();
                var total = 0;
                $( ".area" ).each( function(){
                  total += parseFloat( $( this ).val() ) || 0;
                 
                });
                if(tot_area < total){
                    Swal.fire('', 'Farm area can not be exceed from the total farm area.', '');
                    $('.submit-button').attr('disabled',true);
                    return false;
                }else{
                    $('.submit-button').attr('disabled',false);
                    return true;
                }
               
            });
        </script>
    @endpush

@extends('admin.layouts.app')
@section('content')
    <!-- start page title -->

    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Apply for NOC</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Apply for NOC</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">
                        @if (!empty($checkApply))
                            <div class="pdf_maindiv">
                                <!--form1 section starts here-->
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-xxl-12 col-md-12 ">
                                            <div class="hstack">
                                                <div class="btn btn-soft-success" style="width: 100%">Your application for NOC has been submitted successfully.</div>
                                            </div>
                                        </div>
                                    </div>
                                    </div>
                            </div>
                        @else
                            <div class="card-body">
                                <form action="{{ route('superadmin.saveApplyNOC') }}" method="post">
                                    @csrf

                                    <div class="live-preview">


                                        <!--form3 tab end here-->

                                        <!--form4 tab end here-->
                                        <div class="row seperatesec white-inner">
                                            <div class="sectitle">
                                                <label for="labelInput" class="form-label blue-ht">Apply For NOC</label>
                                            </div>
                                            <span style="color:red;">Note : NOC can only be applied within the validity of
                                                scope certification.</span>
                                            <div>
                                                <label for="labelInput" class="form-label"></label>
                                                <br>
                                                <input type="radio" id="html" name="noc_type" value="Whole" checked>
                                                <label for="Whole">Whole</label>
                                                <input type="radio" id="css" name="noc_type" value="Farmer Wise">
                                                <label for="Farmer Wise">Farmer Wise</label><br>
                                            </div>
                                            <div class="col-xxl-12 col-md-12">
                                                <label for="labelInput" class="form-label blue-ht">Operator Details</label>
                                            </div>
                                            <div class="col-xxl-12 col-md-12 whole_div ">
                                                <div class="row pdf_maindiv ">
                                                    <input type="hidden" name="at_ics_mandator_registration_details_id"
                                                        value="">
                                                    <input type="hidden" name="at_ip_farmer_reg_details_id" value="">
                                                    <input type="hidden" name="at_ip_farm_details_id" value="">
                                                    <div class="col-xxl-4 col-md-6">
                                                        <div>
                                                            <label class="form-label">Accreditation Agency Name :</label>
                                                            {{ user_name(getSingleTableRecordById('at_user', 'id', $userId)->created_by) ?? '' }}
                                                        </div>
                                                    </div>

                                                    <div class="col-xxl-4 col-md-6">
                                                        <div>
                                                            <label class="form-label">Company Name :</label>
                                                            {{ user_name($userId) ?? '' }}
                                                        </div>
                                                    </div>
                                                    <div class="col-xxl-4 col-md-6 ">
                                                        <div>
                                                            <label class="form-label">Scope For :</label>
                                                            {{ $scopeData->scope_for ?? '' }}
                                                        </div>
                                                    </div>

                                                    <div class="col-xxl-4 col-md-6 ">
                                                        <div>
                                                            <label class="form-label">Date Of Registration :</label>
                                                            {{ date('d-m-Y', strtotime($scopeData->validity_start_date ?? '')) ?? '' }}
                                                        </div>
                                                    </div>
                                                    <div class="col-xxl-4 col-md-6 ">
                                                        <div>
                                                            <label class="form-label">Reason :</label>
                                                            <input type="text" class="form-control" value=""
                                                                name="reason" required>
                                                        </div>
                                                    </div>
                                                    <div class="col-xxl-4 col-md-6">
                                                        <div>
                                                            <label class="form-label">Certification Body :</label>
                                                            <select name="ref_operator_type_id" class="form-select"
                                                                required>
                                                                <option value="">-Select CB-</option>
                                                                @forelse (getCBListForNOC() as $cb)
                                                                    <option value="{{ $cb->id }}"
                                                                        {{ $currentCB == $cb->id ? 'selected' : '' }}>
                                                                        {{ user_name($cb->id) }}</option>
                                                                @empty
                                                                    {{-- <option value=""> No Record Found</option> 
                                                            --}}
                                                                @endforelse


                                                            </select>
                                                        </div>
                                                    </div>



                                                </div>
                                            </div>
                                            <div class="table-responsive farmer_div d-none">

                                                <table
                                                    class="table table-bordered table-striped align-middle dataTable no-footer"
                                                    width="100%" id="datatable_">
                                                    <thead>
                                                        <tr>
                                                            <th>Select</th>
                                                            <th>Farmer Registration No.</th>
                                                            <th>Farmer Name</th>
                                                            <th>Address</th>
                                                            <th>Area (in Ha)</th>
                                                            <th>Remarks</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @forelse ($farmerDetails as $key=>$far)
                                                            <tr>
                                                                <input type="hidden"
                                                                    name="at_ip_farmer_reg_details_id[{{ $key }}]"
                                                                    value="{{ $far->id }}">
                                                                <td><input name="lots[{{ $key }}]" type="checkbox"
                                                                        class="lots"
                                                                        onclick="addRequired({{ $key }},$(this));">
                                                                </td>
                                                                <td>{{ $far->registration_no ?? '' }}</td>
                                                                <td>{{ $far->farmer_first_name ?? '' }}
                                                                    {{ $far->farmer_last_name ?? '' }}</td>
                                                                <td>{{ $far->farmer_address ?? '' }}</td>
                                                                <td>{{ getFarmArea($far->id) ?? 0.0 }}</td>
                                                                <td><input type="text" value=""
                                                                        name="remarks[{{ $key }}]"></td>
                                                            </tr>
                                                        @empty
                                                            <tr>
                                                                <td colspan="6">No Record Found.</td>
                                                            </tr>
                                                        @endforelse

                                                    </tbody>

                                                </table>
                                            </div>
                                            @if ($scopeValidity >= 7)
                                                <div class="col-xxl-12 col-md-12 gy-4">
                                                    <div class="hstack gap-2"
                                                        style="display: flex; justify-content: center; align-items: center;">
                                                        <button type="submit" id="submitbtn"
                                                            class="btn btn-primary submit-button">Submit</button>
                                                    </div>
                                                </div>
                                            @endif
                                        </div>
                                    </div>

                                </form>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    @endsection
    @push('script')
        <script>
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });


            $("input[name=noc_type]").change(function() {
                var value = $(this).val();
                //alert(value);
                if (value == 'Whole') {
                    $('.whole_div').removeClass("d-none");
                    $('.farmer_div').addClass("d-none");
                    $("input[name='reason']").attr('required', true);
                    $("select[name='ref_operator_type_id']").attr('required', true);
                }

                if (value == 'Farmer Wise') {
                    $('.whole_div').addClass("d-none");
                    $('.farmer_div').removeClass("d-none");
                    $("input[name='reason']").removeAttr('required', false);
                    $("select[name='ref_operator_type_id']").removeAttr('required', false);
                }


            });

            function addRequired(k, t) {

                if (t.is(':checked')) {
                    $(t).closest('tr').find("input[name='remarks[" + k + "]']").attr('required', true);
                } else {
                    $(t).closest('tr').find("input[name='remarks[" + k + "]']").attr('required', false);
                }
            }
            // $('#datatable').DataTable();
        </script>
    @endpush

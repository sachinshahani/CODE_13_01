@extends('admin.layouts.app')

@section('content')
<style>
    @media print{
        @page{size:auto!important;margin:0mm!important}
    }
</style>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">INSPECTION REPORT – {{ $opertype_label  }}</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Inspection Reports</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="card col-lg-12">
       
     
	<!-- INSPECTION REPORT – INDIVIDUAL PRODUCER Section Start -->
    <table border="0" cellspacing="0" cellpadding="0" style="width:100%;max-width:800px;margin:0 auto 150px;border-collapse:collapse">
        <tbody>
            <tr>
                <td style="vertical-align:baseline;text-align:center">
                    <p style="font-family:'Arial';padding:3px 0;margin:0;font-weight:bold;font-size:22px;line-height:28px">INSPECTION REPORT –  {{ $opertype_label  }}</p>
                </td>
            </tr>
			<tr>
                <td style="vertical-align:baseline">
                    <table border="1" cellspacing="0" cellpadding="0" style="width:100%;max-width:800px;margin:10px auto 0;border-collapse:collapse">
						<tbody>
							<tr>
								<td style="padding:0 80px">
									<table border="0" cellspacing="0" cellpadding="0" style="width:100%;margin:0 auto;border-collapse:collapse">                        
										<tbody>
											<tr>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px;width:50%">Name of the Individual</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px;width:50%">: {{$atInspectionCheck->farmer_name ?? '' }}</td>
											</tr>
											<tr>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px;width:50%">Farmer with full Address (with GPS coordinates)</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px;width:50%">: {{$atInspectionCheck->farmer_address ?? ''}} ({{$atInspectionCheck->latitude ?? ''}} {{$atInspectionCheck->longitude ?? ''}})</td>
											</tr>
											<tr>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px;width:50%">Contact details Mobile no.; email</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px;width:50%">: {{$famrmar_detail->mobile_no ?? ' '}} , {{$famrmar_detail->email ?? ''}}</td>
											</tr>
											<tr>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px;width:50%">TraceNet Registration No.</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px;width:50%">:</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
							<tr>
								<td style="padding:0 80px">
									<table border="0" cellspacing="0" cellpadding="0" style="width:100%;margin:0 auto;border-collapse:collapse">                        
										<tbody>
											<tr>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px;width:50%">Name of the Inspector</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px;width:50%">: {{$atInspectionCheck->inspector_name ?? ''}}</td>
											</tr>
											<tr>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px;width:50%">Date of inspection</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px;width:50%">:{{$atInspectionCheck->inspection_date ?? ''}}</td>
											</tr>
											<tr>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px;width:50%">Time of inspection</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px;width:50%">:{{date('H:m:s',strtotime($atInspectionCheck->created_at ?? ''))}}</td>
											</tr>
											<tr>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px;width:50%">Type of inspection</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px;width:50%">: Main</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
						</tbody>
					</table>
                </td>
            </tr>
			<tr>
                <td style="vertical-align:baseline">
                    <table border="0" cellspacing="0" cellpadding="0" style="width:100%;max-width:800px;margin:15px auto 0;border-collapse:collapse">                        
						<tbody>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px 5px 30px ">Farm details</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px 5px 30px">Total Land owned</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px 5px 30px">Area under organic cultivation</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px 5px 30px">Crops under organic cultivation (with area and status)</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;padding:15px 0 0;font-family:'Arial'">
									<p style="padding:5px 0;margin:0;font-size:18px;font-weight:600">Observations on the farm operations: {{$atInspectionCheck->overall_observation ?? ' '}}</p>
									<ol style="list-style:none;font-family:'Arial';margin:0;padding:0;font-size:16px">
										<li style="padding:10px 0">1. Local geo-graphical conditions and farm activities:</li>
										<li style="padding:10px 0">2. Choice of crops/ Planting material and Fertility Management</li>
										<li style="padding:10px 0">3. Cropping pattern</li>
										<li style="padding:10px 0">4. Buffer Zone Maintenance; chances of pesticide drift from neighboring farms</li>
										<li style="padding:10px 0">5. Farmers’ understanding of organic practices</li>
										<li style="padding:10px 0">6. Conversion requirements</li>
										<li style="padding:10px 0">7. Soil management</li>
										<li style="padding:10px 0">8. Irrigation sources</li>
										<li style="padding:10px 0">9. Livestock</li>
										<li style="padding:10px 0">10. Pest, Disease and Weed Management practices</li>
										<li style="padding:10px 0">11. Harvest, Yield and sold Quantities with time of harvest including product reconciliation and mass balance.</li>
										<li style="padding:10px 0">12. Post Harvest Handling, including packing, storage and transport</li>
										<li style="padding:10px 0">13. Audit trail and Record Keeping</li>
									</ol>
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;padding:5px 0 0;font-family:'Arial'">
									<p style="padding:5px 0 16px;margin:0;font-size:18px;font-weight:600">14. Summary of non- compliances</p>
									<table border="1" cellspacing="0" cellpadding="0" style="width:100%;border-collapse:collapse">
										<tbody>
											<tr>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">S.No.</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">NPOP clause</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">Non – compliance</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">Category (Major/Minor/OFI)</td>
											</tr>
											<tr>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
											</tr>
											<tr>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
											</tr>
											<tr>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
											</tr>
										</tbody>
									</table>					
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;padding:0px 0 0;font-family:'Arial'">
									<p style="padding:15px 0 25px;margin:0;font-size:16px">15. Has sample been collected : Yes or No (Specify reason for both)…..</p>
									<p style="padding:5px 30px 30px;margin:0;font-size:18px;font-weight:600">Any other additional information or remarks</p>
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;padding:0px 0 0;font-family:'Arial';text-align:right">
									<p style="padding:0px 0 30px;margin:0 0 0 auto;font-size:16px;width:185px;text-align:left;line-height:20px">Signature of the Inspector Name of the Inspector Date:</p>
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;padding:25px 0 10px;font-family:'Arial';border-top:3px solid #000">
									<p style="padding:0px 0 3px;margin:0;font-size:16px">Date of inspection report received by the reviewer</p>
									<p style="padding:0px 0 3px;margin:0;font-size:16px">Name of reviewer</p>
									<p style="padding:0px 0 3px;margin:0;font-size:16px">Signature of reviewer</p>
								</td>
							</tr>
						</tbody>
					</table>
                </td>
            </tr>
        </tbody>
	</table>
	<!-- INSPECTION REPORT – INDIVIDUAL PRODUCER Section End -->

</div>
</div>



@endsection
@push('script')
<script>
 
</script>
@endpush

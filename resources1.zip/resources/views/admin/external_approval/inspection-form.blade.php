@extends('admin.layouts.app')

@section('content')
<style type="text/css">
   .odd-bd{
    background: #78cd721f;
    border: 1px solid #f4eded;
    border-radius: 7px;
    } 
    .table {
    border: 1px solid #e9ebec;
    background: #fff;
}
.table thead th {
    background: -webkit-linear-gradient(90deg, hsl(148deg 50% 42%) 0%, hsl(210deg 81% 27%) 100%);
    color: #fff;
}
div#addmore {
    text-align: center;
    padding-top: 22px;
    font-size: 30px;
}
div#addmore:hover {
    color: #0c7316;
}
i.ri-delete-bin-2-fill.remove {
    color: #f06548;
    border: 1px solid #e0e0e0;
    padding: 5px;
}
i.ri-delete-bin-2-fill.remove:hover {
    background: #f06548;
    color: #fff;
}
</style>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">External Inspection</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">External Inspection</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
       
    <div class="tab-content py-4 custom-tab-content">
        <div class="tab-pane fade show active" id="step1">
            <div class="card">
                <div class="card-header align-items-center d-flex">
                    <h4 class="card-title mb-0 flex-grow-1">
                        External Inspection
                    </h4>
                </div>
                 
        <div class="card-body">
            <!-- {{ route('superadmin.icsuser.step2post',2) }} -->
            <form method="post" id="" action="{{ route('superadmin.external.extInspectionPost') }}"
                enctype="multipart/form-data">
                @csrf
                <input type="hidden" name="hid" value="{{$regDetail->id}}">
                
                <!-- reg no -->  
                <div class="view-details p-2 odd-bd mb-3">
                    <div class="row">
                        <div class="sectitle gy-3">
                            <label for="labelInput" class="form-label">Operator Detail</label>
                        </div>    
                        <div class="col-xxl-2 col-md-2">
                            <label class="form-label">Registraton Number </label>
                        </div>
                        <div class="col-xxl-4 col-md-4">
                                <input type="hidden" name="at_user_id" value="{{$regDetail->id}}" required />
                                <input type="text" class="form-control" id="reg_no" placeholder="Registraton Number" name="reg_no" value="{{$regDetail->id}}" required />
                        </div>
                        
                        <div class="col-xxl-2 col-md-2">
                            <label class="form-label">Operator Type </label>
                        </div>
                        <div class="col-xxl-4 col-md-4">
                                <input type="text" class="form-control" id="operator_type" placeholder="Operator Type" name="operator_type" value="{{getRolesTitle($regDetail->ref_operator_type_id)}}" required />
                        </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-xxl-2 col-md-2">
                            <label class="form-label">Operator Name </label>
                        </div>
                        <div class="col-xxl-4 col-md-4">
                            <input type="text" class="form-control" id="operator_name" placeholder="Operator Name" name="operator_name" value="{{$regDetail->first_name}} {{$regDetail->last_name}}" required />
                        </div>
                        
                        <div class="col-xxl-2 col-md-2">
                            <label class="form-label">Address </label>
                        </div>
                        <div class="col-xxl-4 col-md-4">
                                <textarea  class="form-control" id="address" placeholder="Address" name="address" >{{$regDetail->address}}</textarea>
                        </div>
                    </div>
                </div>

                <div class="view-details p-2 odd-bd mb-3">
                    <div class="sectitle gy-3 mt-4">
                        <label for="labelInput" class="form-label">Inspector Detail</label>
                    </div>
                    <div class="row mt-2">
                    <div class="col-xxl-4 col-md-4">
                        <label class="form-label">Date of Submission of Inspection Report <span class="required">*</span></label>
                    </div>
                    <div class="col-xxl-4 col-md-4">
                            <input type="date" class="form-control" id="submission_of_inspection" placeholder="Date of Submission of Inspection Report" name="submission_of_inspection" value="" required />
                    </div>
                    </div>
                    <div class="row mt-2">
                    <div class="col-xxl-4 col-md-4">
                        <label class="form-label">Date of Inspection <span class="required">*</span></label>
                    </div>
                    <div class="col-xxl-4 col-md-4">
                            <input type="date" class="form-control" id="inspection_date" placeholder="Date of Inspection" name="inspection_date" value="" required />
                    </div>
                    </div>

                    <div class="row mt-2">
                    <div class="col-xxl-2 col-md-2">
                        <label class="form-label">Inspector Name <span class="required">*</span></label>
                    </div>
                    <div class="col-xxl-4 col-md-4">
                            <select name="ins_name" id="ins_name" class="form-select">
								<option value="">Choose</option>
								@forelse($authsign as $vals)
								<option value="{{$vals->id}}">{{$vals->first_name}}</option>
								@empty

								@endforelse

							</select>
							{{-- <input type="text" class="form-control" id="ins_name" placeholder="Inspector Name" name="ins_name" value="" required /> --}}
                    </div>
                    
                    <div class="col-xxl-2 col-md-2">
                        <label class="form-label">Contact Details <span class="required">*</span></label>
                    </div>
                    <div class="col-xxl-4 col-md-4">
                            <input type="text" class="form-control numbersonly" placeholder="Contact Details" name="ins_contact" value="" maxlength="10" required />
                    </div>
                    </div>
                </div>

                <div class="view-details p-2 odd-bd mb-3">
                    <div class="row mt-2">
                    <div class="sectitle gy-3">
                        <label for="labelInput" class="form-label">Inspection Details</label>
                    </div>    
                    <div class="col-xxl-4 col-md-4">
                        <label class="form-label">Description of Observation <span class="required">*</span></label>
                        <textarea class="form-control" id="des_observation" placeholder="Description of Observation" name="des_observation2" ></textarea> 
                    </div>
                    <div class="col-xxl-4 col-md-4">
                        <label class="form-label">Grades <span class="required">*</span></label>
                            <select class="form-control" name="grade2" id="grade">
                                <option value="">Select Grades</option>
                                <option value="major">Major</option>
                                <option value="minor">Minor</option>
                                <option value="ofi">OFI</option>
                                
                            </select>

                    </div>
                    <div class="col-xxl-3 col-md-3">
                            <label class="form-label">Date of Corrective Action <span class="required">*</span></label>
                            <input type="date" class="form-control" placeholder="Date of Corrective Action" id="date_corrective_action" name="date_corrective_action2" value=""  />
                    </div>
                    <div class="col-xxl-1 col-md-1">
                            <div id="addmore"><i class="ri-add-circle-fill fa-4x"></i></div>
                    </div>
                    </div>
                </div>

                <div class=" p-2 odd-bd mb-3">
                    <div class="row m-0 mt-2" >
                        <table class="table" id="TextBoxContainer">
                        <thead>
                            <th>Sr.No.</th>
                            <th>Description of Observation</th>
                            <th>Grade</th>
                            <th>Date of Corrective Action</th>
                            <th>Action</th>
                        </thead>
                        <tbody >
                            
                        </tbody>
                        </table>
                    </div>
                </div>
                <div class="view-details p-2 odd-bd mb-3">
                    <div class="row mt-2">
                        <div class="sectitle gy-3">
                            <label for="labelInput" class="form-label">Remark of Inspector <span class="required">*</span></label>
                        </div>    
                        <div class="col-xxl-12 col-md-12">
                            <textarea class="form-control" id="remark" placeholder="Remark" name="remark" required></textarea> 
                        </div>
                    </div>
                </div>

                <div class="row mt-2">
                    <div class="col-xxl-12 col-md-12">
                        <input type="submit" name="submit" class="btn btn-primary" style="float: right" value="Submit">
                    </div>
                </div>
            </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>



@endsection
@push('script')
<script>

$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});


$(function () {
    $("#addmore").bind("click", function () {
        // var div = '<tr/>';
        
        if($("#des_observation").val()!='' && $("#grade").val()!='' && $("#date_corrective_action").val()!=''){
            var div = GetDynamicTextBox($("#des_observation").val(),$("#grade").val(),$("#date_corrective_action").val());
            $('#TextBoxContainer tr:last').after(div);
        }else{
            Swal.fire('', 'Please enter fields value.', 'warning');
        }
        
    });
    
    $("body").on("click", ".remove", function () {
        $(this).closest("tr").remove();
    });
});
function GetDynamicTextBox(val1,val2,val3) {
    var rowCount = $('#TextBoxContainer tr').length;
    $("#des_observation").val('');
    $("#grade").val('');
    $("#date_corrective_action").val('');
    return '<tr><td>'+rowCount+'</td><td><input type="text" name="des_observation[]" value="'+val1+'"> </td><td><input type="text" name="grade[]" value="'+val2+'"></td><td><input type="text" name="date_corrective_action[]" value="'+val3+'"></td><td><i class="ri-delete-bin-2-fill remove"></i></td></tr>';


}

// 

</script>
@endpush

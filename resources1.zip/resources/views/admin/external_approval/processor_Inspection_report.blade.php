@extends('admin.layouts.app')

@section('content')
<style>
    @media print{
        @page{size:auto!important;margin:0mm!important}
    }
</style>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">INSPECTION REPORT FOR PROCESSOR</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Inspection Reports</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="card col-lg-12">
       
      
	<!-- INSPECTION REPORT FOR PROCESSOR Section Start -->
	<div style="page-break-before:always">&nbsp;</div> 
	<table border="0" cellspacing="0" cellpadding="0" style="width:100%;max-width:800px;margin:0 auto 150px;border-collapse:collapse">
        <tbody>
            <tr>
                <td style="vertical-align:baseline;text-align:center">
                    <p style="font-family:'Arial';padding:3px 0;margin:0;font-weight:bold;font-size:22px;line-height:28px">INSPECTION REPORT FOR PROCESSOR</p>
                </td>
            </tr>
			<tr>
                <td style="vertical-align:baseline;padding:10px 0 0;font-family:'Arial'">
					<p style="padding:5px 0;margin:0;font-size:18px;font-weight:600">General Information</p>
					<ol style="list-style:none;font-family:'Arial';margin:0;padding:0;font-size:16px">
						<li style="padding:10px 0">a) Name of the Processor :</li>
						<li style="padding:10px 0">b) Registered Address:</li>
						<li style="padding:10px 0">c) Name of the Authorized Person</li>
						<li style="padding:10px 0">d) Contact details (mobile no and email) :</li>
						<li style="padding:10px 0">e) Legal status of the operator:</li>
						<li style="padding:10px 0">f) FSSAI and or AYUSH License number and validity:</li>
						<li style="padding:10px 0">g) Number of sites audited and respective addresses:</li>
						<li style="padding:10px 0">h) Type of Inspection (Initial/Annual/Additional/Unannounced/Investigation etc)</li>
						<li style="padding:10px 0">i) If type of inspection other than initial and annual, what is specific reason for audit:</li>
					</ol>                    
                </td>
            </tr>
			<tr>
                <td style="vertical-align:baseline;padding:25px 0 0;font-family:'Arial'">
					<p style="padding:5px 0;margin:0;font-size:18px;font-weight:600">1. Details of the Processing unit and products</p>
					<table border="0" cellspacing="0" cellpadding="0" style="width:100%;border-collapse:collapse">
						<tbody>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 0"><b>a.</b></td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 0;width:96%">
									<p style="margin:0">Confirmation of the legal entity, scope of certification as per the contract, compliance to the national legal requirement like FSSAI /Ayush License number and validity , Manufacturing capacity etc</p>									
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 0"><b>a.b.</b></td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 0;width:96%">
									<p style="margin:0">Number of products to be certified : ………… (Total Single Ingredient-........, Total Multi ingredient…….)</p>									
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 0"><b>a.c.</b></td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 0;width:96%">
									<p style="margin:0">Product details</p>									
								</td>
							</tr>
						</tbody>
					</table>                  
                </td>
            </tr>
			<tr>
                <td style="vertical-align:baseline;padding:10px 0 0">
                    <table border="1" cellspacing="0" cellpadding="0" style="width:100%;border-collapse:collapse">
						<tbody>
							<tr>
								<td colspan="5" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">
									<p style="margin:0;font-size:18px;font-weight:600;text-align:center">Give the following details of each product?</p>
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">S.No.</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">Product Name</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">Trade Name</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">List of Ingredients</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">Source of ingredients</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
							</tr>
						</tbody>
					</table>
                </td>
            </tr>
			<tr>
                <td style="vertical-align:baseline;padding:15px 0;font-family:'Arial';font-size:16px">
					<p style="margin:0;text-indent:40px;line-height:24px">Imported ingredients to be mentioned separately with name of the imported ingredient, quantity imported, Country of origin, Certification details, percentage in composition of each product, process flow, test reports ( if any), reasons for use of imported ingredient ( to be recorded in writing, any other relevant observation)</p>
                </td>
            </tr>
			<tr>
                <td style="vertical-align:baseline;padding:15px 0">
					<table border="0" cellspacing="0" cellpadding="0" style="width:100%;border-collapse:collapse">
						<tbody>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 0"><b>2.</b></td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 0;width:97%">
									<p style="margin:0">Are there any contracted units. If so please indicate the details)</p>
									<ol style="list-style:none;font-family:'Arial';margin:0;padding:0 15px;font-size:16px">
										<li style="padding:10px 0 0px">A.</li>
										<li style="padding:10px 0 5px">B.</li>
									</ol>
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0"><b>3.</b></td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
									<p style="margin:0">Description of processing of each product (Processing flowchart of each product) and formulation of each product (separate sheet shall be attached for formulation/recipe/product profile)</p>									
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0"><b>4.</b></td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
									<p style="margin:0">Observations on Pest Management including methods, products used, fumigation applied on the products/ containers (before or after loading) if any etc</p>									
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0"><b>5.</b></td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
									<p style="margin:0">Observations on cleaning methods used for processing units and storage area</p>									
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0"><b>6.</b></td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
									<p style="margin:0">Separation methods used for processing organic and conventional products</p>
									<ol style="list-style:none;font-family:'Arial';margin:0;padding:0 15px;font-size:16px">
										<li style="padding:10px 0">a) Contamination control and co mingling</li>
										<li style="padding:10px 0">b) Processing separation</li>
										<li style="padding:10px 0">c) Storage including raw material, ingredients and finished products</li>
										<li style="padding:10px 0">d) Any other relevant observation</li>
									</ol>
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0 0"><b>7.</b></td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0 0;width:97%">
									<p style="margin:0">Brief on Packing methods used for processed products</p>									
								</td>
							</tr>							
						</tbody>
					</table>					
                </td>
            </tr>
			<tr>
                <td style="vertical-align:baseline;padding:0px 0">
					<table border="1" cellspacing="0" cellpadding="0" style="width:100%;border-collapse:collapse">
						<tbody>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">Product Name</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">Packing Method used</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px;width:40%">Is the packing material used is of food grade quality (Y/N)</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px;width:40%">&nbsp;</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px;width:40%">&nbsp;</td>
							</tr>
						</tbody>
					</table>
                </td>
            </tr>
			<tr>
                <td style="vertical-align:baseline;padding:15px 0">
					<table border="0" cellspacing="0" cellpadding="0" style="width:100%;border-collapse:collapse">
						<tbody>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 0"><b>8.</b></td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 0;width:97%">
									<p style="margin:0">Details of records maintained from raw materials till final products</p>
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0"><b>9.</b></td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
									<p style="margin:0">Verification of records during inspection like Bills / Invoices of raw materials, details of suppliers of raw materials, Purchase and sales records, relevant certificates from suppliers, etc.,(Attach details/copy of the same), records pertaining to imported ingredients</p>
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0"><b>10.</b></td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
									<p style="margin:0">Traceability and Mass balance System:</p>									
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0"><b>11.</b></td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
									<p style="margin:0">Products Labeling (including products with imported ingredients)</p>									
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0 0"><b>12.</b></td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0 0;width:97%">
									<p style="margin:0">Summary of non-compliances</p>
								</td>
							</tr>							
						</tbody>
					</table>					
                </td>
            </tr>
			<tr>
                <td style="vertical-align:baseline;padding:0px 0">
					<table border="1" cellspacing="0" cellpadding="0" style="width:100%;border-collapse:collapse">
						<tbody>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">S.No.</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">NPOP clause</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px;width:40%">Non – compliance</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">Category (Major/Minor/OFI)</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px;width:40%">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px;width:40%">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
							</tr>
						</tbody>
					</table>
                </td>
            </tr>			
			<tr>
                <td style="vertical-align:baseline">
                    <table border="0" cellspacing="0" cellpadding="0" style="width:100%;max-width:800px;margin:15px auto 0;border-collapse:collapse">                        
						<tbody>
							<tr>
								<td style="vertical-align:baseline;padding:15px 0 0;font-family:'Arial'">
									<p style="padding:5px 30px 5px;margin:0;font-size:18px;font-weight:600">13. Sampling and residue analysis</p>
									<p style="padding:5px 30px 5px;margin:0;font-size:16px">Has sample been collected: Yes/ No (Specify reason for both)…..</p>
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;padding:15px 0 0;font-family:'Arial'">
									<p style="padding:5px 30px 30px;margin:0;font-size:18px;font-weight:600">14. Any other additional information or remarks</p>
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;padding:0px 0 0;font-family:'Arial';text-align:right">
									<p style="padding:0px 0 30px;margin:0 0 0 auto;font-size:16px;width:185px;text-align:left;line-height:20px">Signature of the Inspector Name of the Inspector Date:</p>
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;padding:25px 0 10px;font-family:'Arial';border-top:3px solid #000">
									<p style="padding:0px 0 3px;margin:0;font-size:16px">Date of inspection report received by the reviewer</p>
									<p style="padding:0px 0 3px;margin:0;font-size:16px">Name of reviewer</p>
									<p style="padding:0px 0 3px;margin:0;font-size:16px">Signature of reviewer</p>
								</td>
							</tr>
						</tbody>
					</table>
                </td>
            </tr>
        </tbody>
	</table>
	<!-- INSPECTION REPORT FOR PROCESSOR Section End -->

</div>
</div>



@endsection
@push('script')
<script>
 
</script>
@endpush

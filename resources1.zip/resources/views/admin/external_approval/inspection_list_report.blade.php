@extends('admin.layouts.app')

@section('content')

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">External Inspection Reports</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">External Inspection</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

            <div class="row">
                <div class="col-lg-12">
                <div class="tab-content py-4 custom-tab-content">
                    <div class="tab-pane fade show active" id="step1">
                        <div class="card">
                        <div class="card-header">
                        <div class="jumbotron">
                    <div class="col-md-3">
                    <label>Operator Types</label>
                    <select id="single" class="js-states form-control">
                        <option value="">Choose...</option>
                        <option value="2">Grower Group</option>
                        <option value="3">Individual Producer</option>
                        <option value="4">Wild Harvester</option>
                        <option value="5">Trader</option>
                        <option value="6">Processor</option>
                    </select>
                </div>
                </div>
                    <!-- <h5 class="card-title mb-0" style="float: left">External Inspection Reports</h5>             -->
                </div>
                <!-- end card header -->
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="farmerTable" class="table table-bordered table-striped align-middle" style="width:100%">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Registration No.</th>
                                    <!-- <th>Operator Name</th> -->
                                    <th>Operator Type</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</div>



@endsection
@push('script')
<script>

$.ajaxSetup({
      headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      }
});

$(document).ready(function() {
    var table = $('#farmerTable').DataTable({
        lengthMenu: [[10, 25, 50, -1], [10, 25, 50, "All"]],
        processing: true,
        serverSide: true,
        ajax: {
            url: '{{ route("superadmin.externalinspectionListReports") }}',
            type: 'GET',
            data: function(d) {
                d._token = "{{ csrf_token() }}";  
                d.status = $('#single').val();  
            }
        },
        columns: [
            { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: true },
            { data: 'reg_no', name: 'reg_no', orderable: true },
            // { data: 'name', name: 'name', orderable: true },
            { data: 'operator_type', name: 'operator_type', orderable: true },
            { data: 'action', name: 'action', orderable: false }
        ]
    });

    $('#single').on('change', function() {
        table.ajax.reload();
    });

    $('#single').on('click', function() {
        table.ajax.reload();
    });
});

 
    
    $("#single").select2({
          placeholder: "Select a Operator Types",
          allowClear: true
      });


      
 

</script>
 
@endpush

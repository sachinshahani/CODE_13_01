@extends('admin.layouts.app')

@section('content')

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Farmer List</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Farmer List</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
       
    <div class="tab-content py-4 custom-tab-content">
        <div class="tab-pane fade show active" id="step1">
            <div class="card">
                <div class="card-header align-items-center d-flex">
                    <h4 class="card-title mb-0 flex-grow-1">
                        Farmer List

                    </h4>
                  </div>
                <!-- end card header -->
                <div class="card-body">
                    <table id="farmerTable" class="table table-bordered dt-responsive nowrap table-striped align-middle" style="width:100%">
                        <thead>
                            <tr>
                                <th>S.No.</th>
                                <th>Farmer Name</th>
                                <th>Farmer Email</th>
                                <th>Farmer Mobile</th>
                                <th>Address</th>
                                <th>Inspector Name</th>
                                <th>Created On</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div>
</div>



@endsection
@push('script')
<script>

$.ajaxSetup({
      headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      }
});
//alert({{$_GET['fid']}});
var table =$('#farmerTable').DataTable({
        //dom: 'l<"clear">Bfrtip',
        //dom:'Bfrtip',
       //dom:'Blfrtip',
        lengthMenu : [[10, 25, 50, -1], [10, 25, 50, "All"]],
        processing: true,
        serverSide: true,
        ajax: {
            url: '{{ route("superadmin.external.viewInspectionList") }}'+'?fid='+"{{$_GET['fid']}}",
            type: 'GET',
           data: function (d) {
                  
            }
          },
        columns: [
            { data: 'DT_RowIndex', name: 'DT_RowIndex',orderable: true  },
            { data: 'name',name:'name',orderable: true },
            { data: 'email',name:'email',orderable: true },
            { data: 'mobile',name:'mobile',orderable: true },
            { data: 'address',name:'address',orderable: true },
            { data: 'insp_name',name:'insp_name',orderable: true },
            { data: 'created_on',name:'created_on',orderable: true },
            { data: 'status',name:'status',orderable: true },
            { data: 'action', name: 'name',orderable: false },
        ],
        // initComplete: function () {
        //     var btns = $('.dt-button');
        //     //btns.addClass('btn btn-success btn-success');
        //     btns.removeClass('dt-button');

        // },

    });



    function confirmDelete_(id) {

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.value) {
                $.ajax({
                    url: "{{ route('superadmin.icsuser.deleteinspector') }}",
                    method: "POST",
                    dataType: 'json',
                    data: {
                        'id': id,
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(result) {
                     
                        Swal.fire(
                            'Deleted!',
                            'Record Deleted Successfully..',
                            'success'
                        );
                        location.reload();

                    }
                });

            }
        })
    }
</script>
@endpush

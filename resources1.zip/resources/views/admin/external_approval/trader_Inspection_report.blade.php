@extends('admin.layouts.app')

@section('content')
<style>
    @media print{
        @page{size:auto!important;margin:0mm!important}
    }
</style>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">INSPECTION REPORT FOR {{ $opertype_label  }}</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Inspection Reports</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="card col-lg-12">
       
      
<!-- INSPECTION REPORT FOR TRADER Section Start -->
<div style="page-break-before:always">&nbsp;</div> 
<table border="0" cellspacing="0" cellpadding="0" style="width:100%;max-width:800px;margin:0 auto 150px;border-collapse:collapse">
	<tbody>
		<tr>
			<td style="vertical-align:baseline;text-align:center">
				<p style="font-family:'Arial';padding:3px 0;margin:0;font-weight:bold;font-size:22px;line-height:28px">INSPECTION REPORT FOR {{ $opertype_label  }}</p>
			</td>
		</tr>
		<tr>
			<td style="vertical-align:baseline;padding:10px 0 0;font-family:'Arial'">
				<p style="padding:5px 0;margin:0;font-size:18px;font-weight:600">1. General Information</p>
				<ol style="list-style:none;font-family:'Arial';margin:0;padding:0;font-size:16px">
					<li style="padding:10px 0">a. Name of the Trading Unit</li>
					<li style="padding:10px 0">b. Tracenet Registration no.</li>
					<li style="padding:10px 0">c. Address of the unit:</li>
					<li style="padding:10px 0">d. Name of the authorized person:</li>
					<li style="padding:10px 0">e. Mobile No.____________ - Email address- ____________</li>
					<li style="padding:10px 0">f. PAN/TAN No ____________</li>
					<li style="padding:10px 0">g. FSSAI number/ Ayush License number (if applicable)</li>
					<li style="padding:10px 0">h. Whether the unit has previously been registered for organic certification under any certification body: Yes / No</li>
					<li style="padding:10px 0">i. If yes, please give following details: (Enclose NOC)</li>
					<li style="padding:10px 0">a. Name of the certification body ____________</li>
					<li style="padding:10px 0">b. Certification license no. and date ____________</li>
					<li style="padding:10px 0">c. Reasons for change of Certification body ____________</li>
				</ol>                    
			</td>
		</tr>
		<tr>
			<td style="vertical-align:baseline;padding:25px 0 0;font-family:'Arial'">
				<table border="0" cellspacing="0" cellpadding="0" style="width:100%;border-collapse:collapse">
					<tbody>
						<tr>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0"><b>2.</b></td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
								<p style="margin:0">Type of Inspection (Initial/Annual/Additional/Unannounced/Investigation etc)</p>									
							</td>
						</tr>
						<tr>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0"><b>3.</b></td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
								<p style="margin:0">Brief on last three years procurement details, current year annual plan for procurement. and suppliers of their products</p>									
							</td>
						</tr>
						<tr>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0"><b>4.</b></td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
								<p style="margin:0">Brief of Organic Products Traded/ Exported: -</p>									
							</td>
						</tr>
					</tbody>
				</table>                  
			</td>
		</tr>
		<tr>
			<td style="vertical-align:baseline;padding:10px 0 0">
				<table border="1" cellspacing="0" cellpadding="0" style="width:100%;border-collapse:collapse">
					<tbody>
						<tr>
							<td rowspan="2" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">Name of the product</td>
							<td colspan="2" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">Details of Transaction Certificates (TC no. & date) attach copy of TC.</td>
							<td rowspan="2" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">Total Quantity of the traded/ exported Product</td>
							<td rowspan="2" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">Status of the traded/ exported Product (Certified Organic. /In- conversion)</td>
						</tr>
						<tr>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">TC no.</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">Date</td>
						</tr>
						<tr>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
						</tr>
						<tr>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
						</tr>
					</tbody>
				</table>
			</td>
		</tr>
		<tr>
			<td style="vertical-align:baseline;padding:15px 0 10px;font-family:'Arial';font-size:16px">
				<p style="margin:0;text-indent:40px;line-height:24px">(Please attach separate sheet if required)</p>
			</td>
		</tr>
		<tr>
			<td style="vertical-align:baseline;padding:0 0 15px">
				<table border="0" cellspacing="0" cellpadding="0" style="width:100%;border-collapse:collapse">
					<tbody>							
						<tr>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0 0"><b>5.</b></td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0 0;width:97%">
								<p style="margin:0">Supplier details and quantity procured along with their traceability record.</p>									
							</td>
						</tr>							
					</tbody>
				</table>					
			</td>
		</tr>
		<tr>
			<td style="vertical-align:baseline;padding:0px 0">
				<table border="1" cellspacing="0" cellpadding="0" style="width:100%;border-collapse:collapse">
					<tbody>
						<tr>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">Name of the Supplier</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">Address of the Supplier</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">Name of Certificati on Body of Supplier</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">NPOP scope certificate number</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">Transaction Certificates number of the Supplier</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">Status of the traded/ exported Product (Certified Organic./In-conversion) <b>Attach copy of scope certificate</b></td>
						</tr>
						<tr>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
						</tr>
						<tr>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
						</tr>
					</tbody>
				</table>
			</td>
		</tr>
		<tr>
			<td style="vertical-align:baseline;padding:15px 0 0">
				<table border="0" cellspacing="0" cellpadding="0" style="width:100%;border-collapse:collapse">
					<tbody>							
						<tr>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0"><b>6.</b></td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
								<p style="margin:0"><b>Whether both certified organic and conventional products being traded/ exported by the operator:</b></p>
							</td>
						</tr>
						<tr>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:0px 0 30px"><b></b></td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:0px 0 30px;width:97%">
								<p style="margin:0">□ Yes □ No</p>									
							</td>
						</tr>
						<tr>
							<td colspan="2" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0 30px;width:100%">
								<p style="margin:0">If yes, separation measures followed at all stages</p>									
							</td>
						</tr>
						<tr>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0"><b>7.</b></td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
								<p style="margin:0"><b>Details of storage godowns:-</b></p>									
							</td>
						</tr>
					</tbody>
				</table>					
			</td>
		</tr>
		<tr>
			<td style="vertical-align:baseline;padding:0px 0">
				<table border="1" cellspacing="0" cellpadding="0" style="width:100%;border-collapse:collapse">
					<tbody>
						<tr>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 25px">On-site</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 25px">On-siter</td>
						</tr>
						<tr>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 25px">&nbsp;</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 25px">&nbsp;</td>
						</tr>
					</tbody>
				</table>
			</td>
		</tr>
		<tr>
			<td style="vertical-align:baseline;padding:15px 0">
				<table border="0" cellspacing="0" cellpadding="0" style="width:100%;border-collapse:collapse">
					<tbody>
						<tr>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0"><b>8.</b></td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
								<p style="margin:0">Observations on Pests & insect management and control</p>
							</td>
						</tr>
						<tr>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0"><b>9.</b></td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
								<p style="margin:0">Observations on storage area including separation of conventional and organic products. Cleaning methods used at storage unit?</p>
							</td>
						</tr>
						<tr>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:0px 0 10px"><b>10.</b></td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:0px 0 10px;width:97%">
								<p style="margin:0;padding:10px 0">Brief on product reconciliation, Mass balance and traceability system and sale of the end Product</p>
								<ol style="list-style:none;font-family:'Arial';margin:0;padding:0 15px;font-size:16px">
									<li style="padding:7px 0">a) Domestic selling</li>
									<li style="padding:7px 0">b) Direct to consumer</li>
									<li style="padding:7px 0">c) To retailer</li>
									<li style="padding:7px 0">d) To wholesaler</li>
									<li style="padding:7px 0">e) Contracted</li>
									<li style="padding:7px 0">f) Export</li>
								</ol>
							</td>
						</tr>
						<tr>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0"><b>11.</b></td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
								<p style="margin:0">Are products with imported products traded? If yes, observations on the compliance and documentation as per NPOP, quantity imported, Country of origin, Certification details, percentage in composition of each product, test reports ( if any) etc</p>
							</td>
						</tr>
						<tr>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0 0"><b>12.</b></td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0 0;width:97%">
								<p style="margin:0">Summary of non- compliances</p>
							</td>
						</tr>							
					</tbody>
				</table>					
			</td>
		</tr>
		<tr>
			<td style="vertical-align:baseline;padding:0px 0">
				<table border="1" cellspacing="0" cellpadding="0" style="width:100%;border-collapse:collapse">
					<tbody>
						<tr>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">S.No.</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">NPOP clause</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px;width:40%">Non – compliance</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">Category (Major/Minor/OFI)</td>
						</tr>
						<tr>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px;width:40%">&nbsp;</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
						</tr>
						<tr>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px;width:40%">&nbsp;</td>
							<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
						</tr>
					</tbody>
				</table>
			</td>
		</tr>			
		<tr>
			<td style="vertical-align:baseline">
				<table border="0" cellspacing="0" cellpadding="0" style="width:100%;max-width:800px;margin:15px auto 0;border-collapse:collapse">                        
					<tbody>
						<tr>
							<td style="vertical-align:baseline;padding:15px 0 0;font-family:'Arial'">
								<p style="padding:5px 30px 5px;margin:0;font-size:18px;font-weight:600">13. Sampling and residue analysis</p>
								<p style="padding:5px 30px 5px;margin:0;font-size:16px">Has sample been collected: Yes/ No (Specify reason for both)…..</p>
							</td>
						</tr>
						<tr>
							<td style="vertical-align:baseline;padding:15px 0 0;font-family:'Arial'">
								<p style="padding:5px 30px 30px;margin:0;font-size:18px;font-weight:600">14. Any other additional information or remarks</p>
							</td>
						</tr>
						<tr>
							<td style="vertical-align:baseline;padding:0px 0 0;font-family:'Arial';text-align:right">
								<p style="padding:0px 0 30px;margin:0 0 0 auto;font-size:16px;width:185px;text-align:left;line-height:20px">Signature of the Inspector Name of the Inspector Date:</p>
							</td>
						</tr>
						<tr>
							<td style="vertical-align:baseline;padding:25px 0 10px;font-family:'Arial';border-top:3px solid #000">
								<p style="padding:0px 0 3px;margin:0;font-size:16px">Date of inspection report received by the reviewer</p>
								<p style="padding:0px 0 3px;margin:0;font-size:16px">Name of reviewer</p>
								<p style="padding:0px 0 3px;margin:0;font-size:16px">Signature of reviewer</p>
							</td>
						</tr>
					</tbody>
				</table>
			</td>
		</tr>
	</tbody>
</table>
<!-- INSPECTION REPORT FOR TRADER Section End -->

</div>
</div>



@endsection
@push('script')
<script>
 
</script>
@endpush

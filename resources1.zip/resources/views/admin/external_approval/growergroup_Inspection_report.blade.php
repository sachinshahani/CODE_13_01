@extends('admin.layouts.app')

@section('content')
<style>
    @media print{
        @page{size:auto!important;margin:0mm!important}
    }
</style>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">INSPECTION REPORT –GROWER GROUP</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Inspection Reports</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="card col-lg-12">
       
      
	<!-- INSPECTION REPORT –GROWER GROUP Section Start -->
	<div style="page-break-before:always">&nbsp;</div> 
	<table border="0" cellspacing="0" cellpadding="0" style="width:100%;max-width:800px;margin:0 auto 150px;border-collapse:collapse">
        <tbody>
            <tr>
                <td style="vertical-align:baseline;text-align:center">
                    <p style="font-family:'Arial';padding:3px 0;margin:0;font-weight:bold;font-size:22px;line-height:28px">INSPECTION REPORT –GROWER GROUP</p>
                </td>
            </tr>
			<tr>
                <td style="vertical-align:baseline">
                    <table border="0" cellspacing="0" cellpadding="0" style="width:100%;max-width:800px;margin:15px auto 0;border-collapse:collapse">                        
						<tbody>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 0px 5px ">Name of the Grower Group:</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 0px 5px">Full Address with GPS Coordinates:</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 0px 5px">Name of the ICS Manager:</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 0px 5px">Contact details:</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 0px 5px">Mobile no.; email:</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 0px 5px">ICS Managed by (Self/ Service provider):</td>
							</tr>
					</table>
                </td>
            </tr>
			<tr>
                <td style="vertical-align:baseline">
                    <table border="1" cellspacing="0" cellpadding="0" style="width:100%;max-width:800px;margin:10px auto 0;border-collapse:collapse">
						<tbody>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px;width:50%">Trace-net Registration Number:</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px;width:50%">Trace-net Registration Date:</td>								
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px;width:50%">Scope no. (If Renewal or NOC):</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px;width:50%">Certificate Expiry Date (If Renewal or NOC):</td>								
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px;width:50%">Standards Applied:</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px;width:50%">Date of Initial Application/Annual Update:</td>								
							</tr>
						</tbody>
					</table>
					<table border="1" cellspacing="0" cellpadding="0" style="width:100%;max-width:800px;margin:20px auto 0;border-collapse:collapse">
						<tbody>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px;width:50%">Name of the Inspector:</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px;width:50%">Date of Inspection:</td>								
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px;width:50%">
									<p style="margin:0 0 5px">Type of Inspection</p>
									<p style="margin:0 0 5px">Initial Audit</p>
									<p style="margin:0 0 5px">Renewal Audit</p>
									<p style="margin:0 0 5px">Additional Audit</p>
									<p style="margin:0 0 5px">Unannounced Audit</p>
									<p style="margin:0">NOC Verification Audit</p>
								</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px;width:50%">
									<p style="margin:0 0 5px">Certification Status: Registered</p>
									<p style="margin:0 0 5px">C-1</p>
									<p style="margin:0 0 5px">C-2</p>
									<p style="margin:0 0 5px">C-3</p>
									<p style="margin:0 0 5px">Organic</p>
									<p style="margin:0;"></p>
								</td>								
							</tr>
						</tbody>
					</table>
					<table border="1" cellspacing="0" cellpadding="0" style="width:100%;max-width:800px;margin:30px auto 0;border-collapse:collapse">
						<tbody>
							<tr>
								<td colspan="10" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">
									<p style="margin:0 0 5px">If NOC Project: Previous CB Name:</p>
									<p style="margin:0 0 5px">NOC Approval Number:</p>
									<p style="margin:0 0 5px">NOC Approval Date:</p>
									<p style="margin:0 0 5px">Previous non-compliance status /details</p>
								</td>							
							</tr>
							<tr>
								<td colspan="10" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">
									<p style="margin:0;font-size:18px;font-weight:600;text-align:center">Summary of Operation</p>
								</td>							
							</tr>
							<tr>
								<td colspan="10" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">
									<p style="margin:0;font-size:18px;font-weight:600;text-align:center">Last year Certification Status</p>
								</td>							
							</tr>
							<tr>
								<td colspan="5" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">Total no. of farmers in last year:</td>
								<td colspan="5" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">Total Area (Ha) under certification last year:</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">No. of New Reg. Farmer</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">Area (Ha)</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">No. of C1 Farmers</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">Area (Ha)</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">No. of C2 Farmers</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">Area (Ha)</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">No. of C3 Farmers</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">Area (Ha)</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">No. of Organic Farmers</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">Area (Ha)</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:1px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">&nbsp;</td>
							</tr>
							<tr>
								<td colspan="10" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:15px 5px 5px">
									<p style="margin:0;font-size:18px;font-weight:600">Current year Certification status</p>
								</td>							
							</tr>
							<tr>
								<td colspan="3" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:1px 5px">Total no. of farmers in Current year</td>
								<td colspan="1" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">&nbsp;</td>
								<td colspan="4" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">Total Area (ha) under certification current year</td>
								<td colspan="2" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">&nbsp;</td>
							</tr>
							<tr>
								<td colspan="3" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:1px 5px">Farmers sanctioned this year if any</td>
								<td colspan="1" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">&nbsp;</td>
								<td colspan="4" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">Area sanctioned this year if any</td>
								<td colspan="2" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">&nbsp;</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">No. of New Registered Farmer</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">Area (Ha)</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">No. of C1 Farmers</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">Area (Ha)</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">No. of C2 Farmers</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">Area (Ha)</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">No. of C3 Farmers</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">Area (Ha)</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">No. of Organic Farmers</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">Area (Ha)</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:1px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">&nbsp;</td>
							</tr>
							<tr>
								<td colspan="4" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px 5px">
									<p style="margin:0;font-size:18px;font-weight:600">Farmers More than 4 Hectare land</p>
								</td>
								<td colspan="6" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px 5px">
									<p style="margin:0;font-size:18px;font-weight:600">Inspection Details of farmers</p>
								</td>
							</tr>
							<tr>
								<td colspan="2" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:1px 5px">No. of farmers more than 4 ha of land</td>
								<td colspan="1" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">Area of farmer</td>
								<td colspan="1" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">% of 4 &>4 Ha</td>
								<td colspan="2" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">Total Number of farmers Inspected</td>
								<td colspan="2" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">Number of less than 4 Ha farmers inspected</td>
								<td colspan="2" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">Number of more than 4 Ha farmers inspected</td>
							</tr>
							<tr>
								<td colspan="2" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:1px 5px">&nbsp;</td>
								<td colspan="1" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">&nbsp;</td>
								<td colspan="1" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">&nbsp;</td>
								<td colspan="2" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">&nbsp;</td>
								<td colspan="2" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">&nbsp;</td>
								<td colspan="2" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">&nbsp;</td>
							</tr>
							<tr>
								<td colspan="2" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">Risk Status:</td>
								<td colspan="8" style="vertical-align:baseline">
									<table border="0" cellspacing="0" cellpadding="0" style="width:100%;max-width:800px;margin:0px auto 0;border-collapse:collapse">                        
										<tbody>
											<tr>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">High</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">Medium</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-weight:400;font-size:16px;padding:5px 5px">Low</td>
											</tr>
										</tbody>
									</table>
								</td>								
							</tr>
						</tbody>
					</table>
                </td>
            </tr>
			<tr>
                <td style="vertical-align:baseline">
                    <table border="0" cellspacing="0" cellpadding="0" style="width:100%;max-width:800px;margin:15px auto 0;border-collapse:collapse">                        
						<tbody>
							<tr>
								<td style="vertical-align:baseline;padding:0px 0 0;font-family:'Arial'">
									<p style="padding:5px 0;margin:0;font-size:18px;font-weight:600">Observations</p>
									<p style="padding:5px 0;margin:0;font-size:18px;font-weight:600">General observations</p>
									<ol style="list-style:none;font-family:'Arial';margin:0;padding:0;font-size:16px">
										<li style="padding:10px 0">i. Legal status of the grower group</li>
										<li style="padding:10px 0">ii. Functioning of the ICS</li>
										<li style="padding:10px 0">iii. Accuracy of information</li>
										<li style="padding:10px 0">iv. Knowledge of the ICS personnel</li>
										<li style="padding:10px 0">v. Competence of the Internal Inspectors</li>
										<li style="padding:10px 0">vi. Farmers’ understanding of organic practices</li>
										<li style="padding:10px 0">vii. Training of ICS personnel and farmers</li>
										<li style="padding:10px 0">viii. Observations on internal inspections conducted by the ICS</li>
										<li style="padding:10px 0">ix. Sanctions imposed by the ICS on farmers (adequate or deficient)</li>
										<li style="padding:10px 0">x. Verification of implementation of corrective action of last inspection (internal and external)</li>
										<li style="padding:10px 0">xi. Status of Complaints/issues notified since last 5 years</li>
									</ol>
								</td>								
							</tr>
							<tr>
								<td style="vertical-align:baseline;padding:15px 0 0;font-family:'Arial'">
									<p style="padding:5px 0 10px;margin:0;font-size:18px;font-weight:600">Organic System plan (OSP)</p>
									<p style="padding:3px 0;margin:0;font-size:16px">Description of verification of the organic system plan (OSP).</p>
									<p style="padding:3px 0;margin:0;font-size:16px">Bring out the differences clearly in deviations observed from the OSP submitted</p>
									<p style="padding:30px 0 5px;margin:0;font-size:18px;font-weight:600">Observations on farm operations:</p>
									<ol style="list-style:none;font-family:'Arial';margin:0;padding:0;font-size:16px">
										<li style="padding:10px 0">i. Location of farms and geographical proximity</li>
										<li style="padding:10px 0">ii. Production system</li>
										<li style="padding:10px 0">iii. Choice of crops/ Planting material and Fertility Management</li>
										<li style="padding:10px 0">iv. Cropping pattern</li>
										<li style="padding:10px 0">v. Buffer Zone Maintenance; chances of pesticide drift from neighboring farms</li>
										<li style="padding:10px 0">vi. Conversion requirements</li>
										<li style="padding:10px 0">vii. Soil management</li>
										<li style="padding:10px 0">viii. Irrigation sources</li>
										<li style="padding:10px 0">ix. Livestock</li>
										<li style="padding:10px 0">x. Pest, Disease and Weed Management practices</li>
										<li style="padding:10px 0">xi. Harvest, Yield and sold Quantities with time of harvest including product reconciliation and mass balance.</li>
										<li style="padding:10px 0">xii. Post Harvest Handling, including packing, storage and transport</li>
										<li style="padding:10px 0">xiii. Audit trail Record Keeping</li>
									</ol>
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;padding:15px 0 0;font-family:'Arial'">
									<p style="padding:5px 0 16px;margin:0;font-size:18px;font-weight:600">Summary of non- compliances</p>
									<table border="1" cellspacing="0" cellpadding="0" style="width:100%;border-collapse:collapse">
										<tbody>
											<tr>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">S.No.</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">NPOP clause</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">Non – compliance</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">Category (Major/Minor/OFI)</td>
											</tr>
											<tr>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
											</tr>
											<tr>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
											</tr>
											<tr>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
												<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
											</tr>
										</tbody>
									</table>					
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;padding:15px 0 0;font-family:'Arial'">
									<p style="padding:5px 30px 5px;margin:0;font-size:18px;font-weight:600">Sampling and residue analysis</p>
									<p style="padding:5px 30px 5px;margin:0;font-size:16px">Has sample been collected: Yes or No (Specify reason for both)…..</p>
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;padding:15px 0 0;font-family:'Arial'">
									<p style="padding:5px 30px 30px;margin:0;font-size:18px;font-weight:600">Any other additional information or remarks</p>
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;padding:0px 0 0;font-family:'Arial';text-align:right">
									<p style="padding:0px 0 30px;margin:0 0 0 auto;font-size:16px;width:185px;text-align:left;line-height:20px">Signature of the Inspector Name of the Inspector Date:</p>
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;padding:25px 0 10px;font-family:'Arial';border-top:3px solid #000">
									<p style="padding:0px 0 3px;margin:0;font-size:16px">Date of inspection report received by the reviewer</p>
									<p style="padding:0px 0 3px;margin:0;font-size:16px">Name of reviewer</p>
									<p style="padding:0px 0 3px;margin:0;font-size:16px">Signature of reviewer</p>
								</td>
							</tr>
						</tbody>
					</table>
                </td>
            </tr>
        </tbody>
	</table>
	<!-- INSPECTION REPORT –GROWER GROUP Section End -->

</div>
</div>



@endsection
@push('script')
<script>
 
</script>
@endpush

@extends('admin.layouts.app')

@section('content')

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Risk Assessment</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Risk Assessment</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
       
    <div class="tab-content py-4 custom-tab-content">
        <div class="tab-pane fade show active" id="step1">
            <div class="card">
                <div class="card-header align-items-center d-flex">
                    <h4 class="card-title mb-0 flex-grow-1">
                        Risk Assessment
                    </h4>
                  </div>
                 
                <div class="card-body">
                    <div class="row">
        <div class="col-lg-2">
            </div>
        <div class="col-lg-10">

            <!-- {{ route('superadmin.icsuser.step2post',2) }} -->
            <form method="post" id="" action="{{ route('superadmin.external.extRiskFormPost') }}"
                enctype="multipart/form-data">
                @csrf
                <input type="hidden" name="hid" value="{{$regDetail->id}}">
                <div class="sectitle gy-3">
                    <label for="labelInput" class="form-label">Operator Detail</label>
                </div>
                <div class="col-xxl-12 col-md-12">
                    <!-- reg no -->
                    <div class="live-preview">
                        <div class="row seperatesec">
                            
                            <div class="col-xxl-4 col-md-4">
                                <div>
                                <label class="form-label">Registraton Number </label>
                                </div>
                            </div>
                            <div class="col-xxl-6 col-md-6">
                                <div>
                                    <input type="hidden" name="at_user_id" value="{{$regDetail->id}}" required />
                                    <input type="text" class="form-control" id="reg_no" placeholder="Registraton Number" name="reg_no" value="ORG/0323/{{$regDetail->id}}" maxlength="25" required />
                                </div>
                            </div>
                        </div>
                        <div class="row seperatesec">
                            <div class="col-xxl-4 col-md-4">
                                <div>
                                <label class="form-label">Grower Group Name </label>
                                </div>
                            </div>
                            <div class="col-xxl-6 col-md-6">
                                <div>
                                    <input type="text" class="form-control" id="placeholderInput" placeholder="ICS Name" name="ics_name" value="{{$regDetail->first_name}} {{$regDetail->last_name}}" maxlength="25" required />
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ics name -->

                </div> 
                 
                 

                <div class="sectitle gy-3">
                    <label for="labelInput" class="form-label">Enter Risk Assessment Details </label>
                </div>
                <div class="col-xxl-12 col-md-12">
                    <!-- reg no -->
                    <div class="live-preview">
                        <div class="row seperatesec">
                            
                            <div class="col-xxl-4 col-md-4">
                                <div>
                                <label class="form-label">Size of Holding <span class="required">*</span></label>
                                </div>
                            </div>
                            <div class="col-xxl-6 col-md-6">
                                <div>
                                    <input type="text" class="form-control" id="placeholderInput" placeholder="Size of Holding" name="size_of_holding" value="" maxlength="25" required />
                                </div>
                            </div>
                            </div>
                            <div class="row seperatesec">
                            <div class="col-xxl-4 col-md-4">
                                <div>
                                <label class="form-label">Number of the members in the group <span class="required">*</span></label>
                                </div>
                            </div>
                            <div class="col-xxl-6 col-md-6">
                                <div>
                                    <input type="text" class="form-control" id="placeholderInput" placeholder="Number of the members in the group" name="no_of_member" value="{{$regDetail->no_of_farmers}}" maxlength="25" required />
                                </div>
                            </div>
                            </div>
                        <div class="row seperatesec">
                            <div class="col-xxl-4 col-md-4">
                                <div>
                                <label class="form-label">Degree of similarity between the production system and crop system <span class="required">*</span> </label>
                                </div>
                            </div>
                            <div class="col-xxl-6 col-md-6">
                                <div>
                                    <input type="text" class="form-control" id="placeholderInput" placeholder="Degree of similarity between the production system and crop system" name="similarity_between_prod_vs_crop" value="" maxlength="25" required />
                                </div>
                            </div>
                        </div>
                        <div class="row seperatesec">
                            <div class="col-xxl-4 col-md-4">
                                <div>
                                <label class="form-label">Inter-mingling/Condamination <span class="required">*</span></label>
                                </div>
                            </div>
                            <div class="col-xxl-6 col-md-6">
                                <div>
                                    <input type="text" class="form-control" id="placeholderInput" placeholder="Inter-mingling/Condamination" name="inter_mingling" value="" maxlength="25" required />
                                </div>
                            </div>
                            </div>
                        <div class="row seperatesec">    
                            <div class="col-xxl-4 col-md-4">
                                <div>
                                <label class="form-label">Parallel production <span class="required">*</span></label>
                                </div>
                            </div>
                            <div class="col-xxl-6 col-md-6">
                                <div>
                                    <input type="text" class="form-control" id="placeholderInput" placeholder="Parallel production" name="parallel_production" value="" maxlength="25" required />
                                </div>
                            </div>
                            </div>
                        <div class="row seperatesec">
                            <div class="col-xxl-4 col-md-4">
                                <div>
                                <label class="form-label">Split production <span class="required">*</span></label>
                                </div>
                            </div>
                            <div class="col-xxl-6 col-md-6">
                                <div>
                                    <input type="text" class="form-control" id="placeholderInput" placeholder="Split production" name="split_production" value="" maxlength="25" required />
                                </div>
                            </div>
                            </div>
                        <div class="row seperatesec">
                            <div class="col-xxl-4 col-md-4">
                                <div>
                                <label class="form-label">Local hazards <span class="required">*</span></label>
                                </div>
                            </div>
                            <div class="col-xxl-6 col-md-6">
                                <div>
                                    <input type="text" class="form-control" id="placeholderInput" placeholder="Local hazards" name="local_hazards" value="" maxlength="25" required />
                                </div>
                            </div>
                            </div>
                        <div class="row seperatesec">
                            <div class="col-xxl-4 col-md-4">
                                <div>
                                <label class="form-label">Change in the production plan <span class="required">*</span></label>
                                </div>
                            </div>
                            <div class="col-xxl-6 col-md-6">
                                <div>
                                    <input type="text" class="form-control" id="placeholderInput" placeholder="Change in the production plan" name="change_production_plan" value="" maxlength="25" required />
                                </div>
                            </div>
                            </div>
                        <div class="row seperatesec">
                            <div class="col-xxl-4 col-md-4">
                                <div>
                                <label class="form-label">Joining of new members in the group <span class="required">*</span></label>
                                </div>
                            </div>
                            <div class="col-xxl-6 col-md-6">
                                <div>
                                    <input type="text" class="form-control" id="placeholderInput" placeholder="Joining of new members in the group" name="joining_member" value="" maxlength="25" required />
                                </div>
                            </div>
                        </div>
                        <div class="row seperatesec">
                            <div class="col-xxl-4 col-md-4">
                                <div>
                                <label class="form-label">Risk Type <span class="required">*</span></label>
                                </div>
                            </div>
                            <div class="col-xxl-6 col-md-6">
                                <div>
                                    <select class="form-control" name="risk_type">
                                        <option value="">Select Risk Type</option>
                                        <option value="high">High</option>
                                        <option value="medium">Medium</option>
                                        <option value="low">Low</option>
                                        
                                    </select>

                                </div>
                            </div>

                        </div>
                        <button type="submit" class="btn btn-primary mt-3">
                            Submit
                        </button>
                    </div>
                    <!-- ics name -->

                </div> 
            </form>
        </div>
    </div>
                     
                    
                </div>
            </div>
        </div>
    </div>

</div>
</div>



@endsection
@push('script')
<script>

$.ajaxSetup({
      headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      }
});
</script>
@endpush

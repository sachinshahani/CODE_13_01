@extends('admin.layouts.app')

@section('content')

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">External Inspection</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">External Inspection</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
       
    <div class="tab-content py-4 custom-tab-content">
        <div class="tab-pane fade show active" id="step1">
            <div class="card">
                <div class="card-header align-items-center d-flex">
                    <h4 class="card-title mb-0 flex-grow-1">
                        List of External Inspection
                    </h4>
                  </div>
                <!-- end card header -->
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="farmerTable" class="table table-bordered table-striped align-middle" style="width:100%">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Registration Number</th>
                                    <th>Operator Name</th>
                                    <th>Operator Type</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
</div>



@endsection
@push('script')
<script>

$.ajaxSetup({
      headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      }
});

var table =$('#farmerTable').DataTable({
        //dom: 'l<"clear">Bfrtip',
        //dom:'Bfrtip',
       //dom:'Blfrtip',
        lengthMenu : [[10, 25, 50, -1], [10, 25, 50, "All"]],
        processing: true,
        serverSide: true,
        ajax: {
            url: '{{ route("superadmin.external.inspectionList") }}',
            type: 'GET',
           data: function (d) {

            }
          },
        columns: [
            { data: 'DT_RowIndex', name: 'DT_RowIndex',orderable: true  },
            { data: 'reg_no',name:'reg_no',orderable: true },
            { data: 'name',name:'name',orderable: true },
            { data: 'operator_type',name:'operator_type',orderable: true },
            { data: 'action', name: 'name',orderable: false },
        ],
        // initComplete: function () {
        //     var btns = $('.dt-button');
        //     //btns.addClass('btn btn-success btn-success');
        //     btns.removeClass('dt-button');

        // },

    });



    function ConfirmInspection() {
        alert('Please Fill External Inspection Details before trying this..');
    }

   
</script>
@endpush

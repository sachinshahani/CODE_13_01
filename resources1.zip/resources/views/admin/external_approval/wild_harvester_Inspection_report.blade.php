@extends('admin.layouts.app')

@section('content')
<style>
    @media print{
        @page{size:auto!important;margin:0mm!important}
    }
</style>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">INSPECTION REPORT FOR ORGANIC WILD COLLECTION</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Inspection Reports</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="card col-lg-12">
       
      
	<!-- INSPECTION REPORT FOR ORGANIC WILD COLLECTION Section Start -->
	<div style="page-break-before:always">&nbsp;</div> 
	<table border="0" cellspacing="0" cellpadding="0" style="width:100%;max-width:800px;margin:0 auto 150px;border-collapse:collapse">
        <tbody>
            <tr>
                <td style="vertical-align:baseline;text-align:center">
                    <p style="font-family:'Arial';padding:3px 0;margin:0;font-weight:bold;font-size:22px;line-height:28px">INSPECTION REPORT FOR ORGANIC WILD COLLECTION</p>
                </td>
            </tr>
			<tr>
                <td style="vertical-align:baseline;padding:15px 0 0;font-family:'Arial'">
					<table border="0" cellspacing="0" cellpadding="0" style="width:100%;border-collapse:collapse">
						<tbody>
							<tr>
								<td colspan="2" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:0px 0;width:100%">
									<p style="padding:5px 0;margin:0;font-size:18px;font-weight:600">1. General Information</p>									
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0">a.</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
									<p style="margin:0">Name of wild Collector/ company/ Business entity</p>									
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0">b.</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
									<p style="margin:0">No. of Collectors</p>									
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0">c.</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
									<p style="margin:0">Tracenet Registration no,</p>									
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0">d.</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
									<p style="margin:0">Name of the authorized person for wild collection</p>									
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0">e.</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
									<p style="margin:0">Full address of the wild collector with GPS Coordinates</p>									
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0">f.</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
									<p style="margin:0">Contact details (mobile and email)</p>									
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0">g.</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
									<p style="margin:0">Collection area’s forest division (full description of division with allotted GPS)</p>									
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0">h.</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
									<p style="margin:0">Whether the unit has previously been registered for organic certification under any certification body: Yes / No</p>									
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0">i.</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
									<p style="margin:0;padding:0 0 5px">If yes, please give following details: (Enclose NOC)</p>
									<ol style="list-style:none;font-family:'Arial';margin:0;padding:0 0px;font-size:16px">
										<li style="padding:5px 0">• Name of the certification body ____________</li>
										<li style="padding:5px 0">• Certification license no. and date ____________</li>
										<li style="padding:5px 0">• Reasons for change of Certification body ____________</li>
									</ol>
								</td>
							</tr>
						</tbody>
					</table>                  
                </td>
            </tr>		
			<tr>
                <td style="vertical-align:baseline;padding:15px 0 0">
					<table border="0" cellspacing="0" cellpadding="0" style="width:100%;border-collapse:collapse">
						<tbody>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0"><b>2.</b></td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
									<p style="margin:0">Type of Inspection (Initial/Annual/Additional/Unannounced/Investigation etc)</p>									
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0"><b>3.</b></td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
									<p style="margin:0">Permission letter from Forest Department, map of collection area and products permitted</p>									
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0"><b>4.</b></td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
									<p style="margin:0">Documentation concerning use of pesticides/agrochemicals in the forest region</p>									
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0"><b>5.</b></td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
									<p style="margin:0">Brief on the process of wild collection carried ou</p>									
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0"><b>6.</b></td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
									<p style="margin:0">Observations on the geolocation of the collection site, distance to the storage area, accessibility to roads, transportation, proximity to industries, other sources of pollution conventional agricultural areas, sanitation etc</p>
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0"><b>7.</b></td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
									<p style="margin:0">Brief on last year’s procurement details, current year annual plan for procurement and frequency of collection</p>									
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0"><b>8.</b></td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
									<p style="margin:0">Details of Organic Products traded vis a- vis collected, stock available, collection and sale records, mass balance and traceability of records, Transaction certificates etc</p>
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0"><b>9.</b></td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
									<p style="margin:0">Brief on Pests & insect management and control, cleaning methods of storage unit?</p>
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0"><b>10.</b></td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
									<p style="margin:0">Do sustainable collection practices establish other restrictions for this species (like e.g. no branch cutting, no damage to root, collect only part of each plant, etc.)?</p>
								</td>
							</tr>
							<tr>
								<td colspan="2" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
									<p style="margin:0">Are these restrictions put in practice? Yes No Partly Not relevant</p>
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0"><b>11.</b></td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
									<p style="margin:0">Do collectors leave behind inorganic litter? Yes No Partly</p>
									<p style="margin:0;padding:5px 0 0">Do collectors disturb birds or other animals? Yes No Partly Don't know</p>
								</td>
							</tr>
							<tr>
								<td colspan="2" style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
									<p style="margin:0">Other environmental problems caused by collectors:</p>
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0"><b>12.</b></td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:10px 0;width:97%">
									<p style="margin:0">Summary of non- compliances</p>
								</td>
							</tr>
						</tbody>
					</table>					
                </td>
            </tr>
			<tr>
                <td style="vertical-align:baseline;padding:0px 0">
					<table border="1" cellspacing="0" cellpadding="0" style="width:100%;border-collapse:collapse">
						<tbody>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">S.No.</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">NPOP clause</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px;width:40%">Non – compliance</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">Category (Major/Minor/OFI)</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px;width:40%">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px;width:40%">&nbsp;</td>
								<td style="vertical-align:baseline;text-align:left;font-family:'Arial';font-size:16px;padding:5px 5px">&nbsp;</td>
							</tr>
						</tbody>
					</table>
                </td>
            </tr>			
			<tr>
                <td style="vertical-align:baseline">
                    <table border="0" cellspacing="0" cellpadding="0" style="width:100%;max-width:800px;margin:15px auto 0;border-collapse:collapse">                        
						<tbody>
							<tr>
								<td style="vertical-align:baseline;padding:15px 0 0;font-family:'Arial'">
									<p style="padding:5px 30px 5px;margin:0;font-size:18px;font-weight:600">13. Sampling and residue analysis</p>
									<p style="padding:5px 30px 5px;margin:0;font-size:16px">Has sample been collected: Yes/ No (Specify reason for both)…..</p>
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;padding:15px 0 0;font-family:'Arial'">
									<p style="padding:5px 30px 30px;margin:0;font-size:18px;font-weight:600">14. Any other additional information or remarks</p>
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;padding:0px 0 0;font-family:'Arial';text-align:right">
									<p style="padding:0px 0 30px;margin:0 0 0 auto;font-size:16px;width:185px;text-align:left;line-height:20px">Signature of the Inspector Name of the Inspector Date:</p>
								</td>
							</tr>
							<tr>
								<td style="vertical-align:baseline;padding:25px 0 10px;font-family:'Arial';border-top:3px solid #000">
									<p style="padding:0px 0 3px;margin:0;font-size:16px">Date of inspection report received by the reviewer</p>
									<p style="padding:0px 0 3px;margin:0;font-size:16px">Name of reviewer</p>
									<p style="padding:0px 0 3px;margin:0;font-size:16px">Signature of reviewer</p>
								</td>
							</tr>
						</tbody>
					</table>
                </td>
            </tr>
        </tbody>
	</table>
	<!-- INSPECTION REPORT FOR ORGANIC WILD COLLECTION Section End -->

</div>
</div>



@endsection
@push('script')
<script>
 
</script>
@endpush

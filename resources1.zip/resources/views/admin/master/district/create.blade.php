@extends('admin.layouts.app')
@section('content')

<div class="overlay">
    <div class="loader"></div>
</div>
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Add district</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">User Creation</a></li>
                    <li class="breadcrumb-item active">Add district</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1">district Creation</h4>
                {{-- <div class="flex-shrink-0">
                    @if (session('error'))
                    <div class="alert alert-danger">
                        {{ session('error') }}
                    </div>
                    @endif
                    @if (session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                    @endif
                    @if($errors)
                    @foreach ($errors->all() as $error)
                    <div class="alert alert-danger">{{ $error }}</div>
                    @endforeach
                    @endif
                </div> --}}
            </div>

            <div class="card-body">
                <div class="live-preview">
                    <form action="{{route('superadmin.master.districtstore')}}" class="commonform1"
                        method="POST" enctype="multipart/form-data" id="commonform1" autocomplete="off">
                        @csrf
                        <div class="row gy-4">
                            <div class="row seperatesec">
                                <div class="col-xxl-3 col-md-3">
                                </div>

                            </div>
                            <div class="row seperatesec">

                                <div class="col-xxl-6 col-md-3">
                                    <div>
                                        <label class="form-label">district Code<span class="required">*</span></label>
                                        <input type="number" min="0" max="99" class="form-control {{ $errors->has('district_code') ? ' is-invalid' : '' }}" id="district_code" name="district_code"
                                            placeholder="district Code" value="">
                                    </div>
                                </div>
                                <div class="col-xxl-6 col-md-3">
                                    <div>
                                        <label for="labelInput" class="form-label">State Name</label>
                                        <select class="form-select" name="ref_state_id" aria-label="Default select example">
                                            @foreach($state as $value)
                                            <option value="{{$value->id}}">{{$value->state_name}}</option>
                                            @endforeach

                                        </select>
                                    </div>
                                </div>
                                <div class="col-xxl-6 col-md-3">
                                    <div>
                                        <label class="form-label">district Name<span class="required">*</span></label>
                                        <input type="text" class="form-control {{ $errors->has('district_name') ? ' is-invalid' : '' }}" id="district_name" name="state_name"
                                            placeholder="district Name" required value="">
                                    </div>
                                </div>
                                <div class="col-xxl-8 col-md-3">
                                    <div class="row">
                                        <div class="col-lg-12 gy-4">
                                            <div class="hstack">
                                                <button type="submit" class="btn btn-primary">Create district</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@push('script')
<script type="text/javascript">

</script>
@endpush


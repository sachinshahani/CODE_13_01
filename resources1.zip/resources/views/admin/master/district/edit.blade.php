@extends('admin.layouts.app')
@section('content')

<div class="overlay">
    <div class="loader"></div>
</div>
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Update State</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">User Creation</a></li>
                    <li class="breadcrumb-item active">Update State</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1">State Update</h4>
                {{-- <div class="flex-shrink-0">
                    @if (session('error'))
                    <div class="alert alert-danger">
                        {{ session('error') }}
                    </div>
                    @endif
                    @if (session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                    @endif
                    @if($errors)
                    @foreach ($errors->all() as $error)
                    <div class="alert alert-danger">{{ $error }}</div>
                    @endforeach
                    @endif
                </div> --}}
            </div>

            <div class="card-body">
                <div class="live-preview">
                    <form action="{{route('superadmin.master.districtupdate',[$district->id])}}" class="commonform1"
                        method="POST" enctype="multipart/form-data" id="commonform1" autocomplete="off">
                        @csrf
                        <div class="row gy-4">
                            <div class="row seperatesec">
                                <div class="col-xxl-3 col-md-3">
                                </div>

                            </div>
                            <div class="row seperatesec">

                                <div class="col-xxl-6 col-md-3">
                                    <div>
                                        <label class="form-label">district Code<span class="required">*</span></label>
                                        <input type="number" min="0" max="99" class="form-control {{ $errors->has('district_code') ? ' is-invalid' : '' }}" id="district_code" name="district_code"
                                            placeholder="district Code" value="@if(isset($district) && isset($district->district_code)){{$district->district_code}}@endif">
                                    </div>
                                </div>
                                <div class="col-xxl-6 col-md-3">
                                    <label class="form-label">State Name<span class="required">*</span></label>
                                    <select class="form-select" name="ref_state_id">
                                    @forelse($states as $state)
                                        <option value="{{ $state->id }}"
                                            @if (isset($district->ref_state_id) && $district->ref_state_id == $state->id) selected @endif>
                                            {{ $state->state_name }}</option>
                                    @empty
                                    @endforelse
                                    </select>
                                </div>
                                <div class="col-xxl-6 col-md-3">
                                    <div>
                                        <label class="form-label">district Name<span class="required">*</span></label>
                                        <input type="text" class="form-control {{ $errors->has('district_name') ? ' is-invalid' : '' }}" id="district_name" name="district_name"
                                            placeholder="district Name" required value="@if(isset($district) && isset($district->district_name)){{$district->district_name}}@endif">
                                    </div>
                                </div>
                                <div class="col-xxl-8 col-md-3">
                                    <div class="row">
                                        <div class="col-lg-12 gy-4">
                                            <div class="hstack">
                                                <button type="submit" class="btn btn-primary">Update District</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@push('script')
<script type="text/javascript">

</script>
@endpush


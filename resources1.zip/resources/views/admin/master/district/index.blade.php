@extends('admin.layouts.app')

@section('content')

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">district</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">district</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">

        <div class="tab-content py-4 custom-tab-content">
            <div class="tab-pane fade show active" id="step1">
                <div class="card">

                    <div class="card-header">
                        <h5 class="card-title mb-0" style="float: left">
                            District List
                        </h5>

                        <div class="row justify-content-end mb-2">
                            <div class="col-2">
                                <a href="{{route('superadmin.master.districtcreate')}}"
                                    class="btn btn-primary" style="float: right">Add district</a>
                            </div>
                        </div>
                    </div>
                    <!-- end card header -->
                    <div class="card-body table-responsive">
                        <table id="state_id" class="table table-bordered nowrap table-striped align-middle"
                            style="width:100%">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>district Code</th>
                                    <th>State Name</th>
                                    <th>district Name</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

@endsection
@push('script')
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    var table = $('#state_id').DataTable({
        lengthMenu: [
            [10, 25, 50, -1],
            [10, 25, 50, "All"]
        ],
        processing: true,
        serverSide: true,
        ajax: {
            url: '{{ route("superadmin.master.districtlist") }}',
            type: 'GET',
            data: function(d) {}
        },
        columns: [{
                data: 'DT_RowIndex',
                name: 'DT_RowIndex',
                orderable: true
            },
            {
                data: 'district_code',
                name: 'district_code',
                orderable: true
            },
            {
                data: 'ref_state_id',
                name: 'ref_state_id',
                orderable: true
            },
            {
                data: 'district_name',
                name: 'district_name',
                orderable: true
            },
            {
                data: 'action',
                name: 'name',
                orderable: false
            },
        ],
    });

    function ConfirmInspection() {
        alert('Please Fill External Inspection Details before trying this..');
    }


    //DELETE FUNCTION-------;;;;;;;

$(document).on('click', '.deletedata', function() {
	 var id=$(this).attr('data-value');
Swal.fire({
  title: 'Are you sure?',
  text: "You won't be able to revert this!",
  icon: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Yes, delete it!'
}).then((result) => {
  if (result.value) {
	   $.ajax({
        url: $(this).attr('data-href'),
        method: "POST",
        dataType: 'json',
        data: {
            'id': id,
        },
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        success: function(result) {
            table_schedule.draw();
				Swal.fire(
				'Deleted!',
				'Record Deleted Successfully..',
				'success'
				)

        }
    });

  } else{

    console.log('cancel');
  }
})

});
</script>
@endpush

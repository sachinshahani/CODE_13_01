@extends('admin.layouts.app')
@section('content')

<div class="overlay">
    <div class="loader"></div>
</div>
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Update State</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">User Creation</a></li>
                    <li class="breadcrumb-item active">Update State</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1">State Update</h4>
                {{-- <div class="flex-shrink-0">
                    @if (session('error'))
                    <div class="alert alert-danger">
                        {{ session('error') }}
                    </div>
                    @endif
                    @if (session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                    @endif
                    @if($errors)
                    @foreach ($errors->all() as $error)
                    <div class="alert alert-danger">{{ $error }}</div>
                    @endforeach
                    @endif
                </div> --}}
            </div>

            <div class="card-body">
                <div class="live-preview">
                    <form action="{{route('superadmin.master.stateupdate',[$data->id])}}" class="commonform1"
                        method="POST" enctype="multipart/form-data" id="commonform1" autocomplete="off">
                        @csrf
                        <div class="row gy-4">
                            <div class="row seperatesec">
                                <div class="col-xxl-3 col-md-3">
                                </div>

                            </div>
                            <div class="row seperatesec">

                                <div class="col-xxl-6 col-md-3">
                                    <div>
                                        <label class="form-label">State Code<span class="required">*</span></label>
                                        <input type="number" min="0" max="99" class="form-control {{ $errors->has('state_code') ? ' is-invalid' : '' }}" id="state_code" name="state_code"
                                            placeholder="State Code" value="@if(isset($data) && isset($data->state_code)){{$data->state_code}}@endif">
                                    </div>
                                </div>
                                <div class="col-xxl-6 col-md-3">
                                    <div>
                                        <label for="labelInput" class="form-label">State Short Name</label>
                                        <input type="text" class="form-control {{ $errors->has('state_short_name') ? ' is-invalid' : '' }}" id="state_short_name" name="state_short_name"
                                            placeholder="State Short Name" value="@if(isset($data) && isset($data->state_short_name)){{$data->state_short_name}}@endif" pattern="[A-Za-z]{2}">
                                    </div>
                                </div>
                                <div class="col-xxl-6 col-md-3">
                                    <div>
                                        <label class="form-label">State Name<span class="required">*</span></label>
                                        <input type="text" class="form-control {{ $errors->has('state_name') ? ' is-invalid' : '' }}" id="state_name" name="state_name"
                                            placeholder="State Name" required value="@if(isset($data) && isset($data->state_name)){{$data->state_name}}@endif">
                                    </div>
                                </div>
                                <div class="col-xxl-8 col-md-3">
                                    <div class="row">
                                        <div class="col-lg-12 gy-4">
                                            <div class="hstack">
                                                <button type="submit" class="btn btn-primary">Update State</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@push('script')
<script type="text/javascript">

</script>
@endpush


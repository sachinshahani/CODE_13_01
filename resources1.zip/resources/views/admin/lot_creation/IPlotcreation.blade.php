@extends('admin.layouts.app')

@section('content')

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Lot Creation</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Lot Creation</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->
<form method="GET" action="{{route('superadmin.IPLotCreationYieldScope')}}" >
<div class="row">

	<div class="col-lg-4">&nbsp;</div>
	<div class="col-lg-4 text-center">

		 <label class="form-label">Choose scope for Lot Creation    <span class="required">*</span></label>
		<div class="mt-4 mt-lg-0">
			<div class="form-check form-check-inline">
				<input class="form-check-input" type="radio" name="option" id="inlineRadio1" value="current" @required(true)>
				<label class="form-check-label" for="inlineRadio1">Current</label>
			</div>
			<div class="form-check form-check-inline">
				<input class="form-check-input" type="radio" name="option" id="inlineRadio2" value="previous" @required(true)>
				<label class="form-check-label" for="inlineRadio2">Previous</label>
			</div>

		</div>

	</div>
	<div class="col-lg-4">&nbsp;</div>
	<div class="col-lg-12 gy-4 text-center">
		<div class="gap-2 ">
			<input type="submit" class="btn btn-primary" value="Proceed">

		</div>
	</div>
</div>
</form>

@endsection
@push('script')

<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
$("#registration").validate({
    rules: {

    },
    messages: {

    }

});
// Dropzone has been added as a global variable.
const dropzone = new Dropzone("div.dropzone", {
    url: "{{ route('storeMedia') }}",
    paramName: "file",
    maxFilesize: 2,
    maxFiles: 1,
    acceptedFiles: ".jpeg,.jpg,.png,.mp4,.webm,.html5",
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    init: function() {
        var drop = this; // Closure
        this.on('error', function(file, errorMessage) {
            if (errorMessage.indexOf('Error 404') !== -1) {
                var errorDisplay = document.querySelectorAll('[data-dz-errormessage]');
                errorDisplay[errorDisplay.length - 1].innerHTML =
                    'Error 404: The upload page was not found on the server';
            }
            if (errorMessage.indexOf('File is too big') !== -1) {
                alert('Unable to upload image size is greated than 2 MB');
                // i remove current file
                drop.removeFile(file);
            }
        });
        this.on("maxfilesexceeded", function(file) {
                this.removeAllFiles();
                this.addFile(file);
            }),
            this.on("success", function(file, response) {
                console.log(response);
                var hiddenImage = $('<input type="hidden" name="_hidden_legal_doc_upload" value="' +
                    response.name + '"/>');
                $('.hidden_images_area').html(hiddenImage);
            })
    }
});
</script>

@endpush

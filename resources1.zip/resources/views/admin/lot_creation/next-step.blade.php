@extends('admin.layouts.app')
@section('content')

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Lot Creation</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Lot Creation</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <nav>
            <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">
                <a class="nav-link active" id="step1-tab" href="javascript:void(0);">Product Selection</a>
                <a class="nav-link" id="step2-tab" href="javascript:void(0);">Procurement Entry</a>
                <a class="nav-link" id="step3-tab" href="javascript:void(0);">Lot Details</a>
            </div>
        </nav>
        <div class="tab-content py-4 custom-tab-content">
            <div class="tab-pane fade show active" id="step1">
                <div class="card">
                    <div class="card-body">
                        <div class="live-preview">
                            <div class="row seperatesec white-inner">
                                <div class="sectitle">
                                    <label for="labelInput" class="form-label blue-ht">Product List</label>
                                </div>
                                <div class="table-responsive">
                                    <table id="searchResultsTable" class="table table-bordered table-striped align-middle dataTable no-footer" width="100%">
                                        <thead>
                                            <tr>
                                			    <th>S.No.</th>
												<th>Product Name</th>
												<th>HS Code</th>
												<th>Organic Status</th>
												<th>Source From</th>
												<th>Harvest Year</th>
                                                <th>Total Quantity(MT)</th>
                                                <th>Closing Stock(MT)</th>
                                                <th>Remaining Quantity(MT)</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                           
											  
                                        @foreach($products as $product)
                                            <tr>
                                                <td>{{ $loop->iteration }}</td>
                                                <td>{{ $product->crop_name ?? '' }}</td>
                                                <td>{{getRefHscodeByID ($product->ref_product_id ?? '') }}</td>
                                                <td>{{ $product->organic_status ?? '' }}</td>
                                                <td>Main</td>
                                                @foreach($stocks as $stock)
                                                   @if($stock->ref_product_id == $product->ref_product_id)
                                                        <td>{{ $stock->harvest_year }}</td>
                                                        <td>{{ $product->actual_yield }}</td>
                                                        <td>{{ $stock->closing_stock }}</td>
                                                        <td>{{ $product->actual_yield }}</td>
                                                        
                                                        <td>
                                                        <a href="{{ route('superadmin.Step2', $product->id) }}">Proceed</a>
                                                        </td>
                                                        @endif
                                                @endforeach
                                            </tr>
                                        @endforeach                              
                                            </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


@endsection
@push('script')
        <script>
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $('#datatable').DataTable();
        </script>
    @endpush


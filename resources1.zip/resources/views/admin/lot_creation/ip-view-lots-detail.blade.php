@extends('admin.layouts.app')

@section('content')
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Lot Creation</h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Lot Creation</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">
            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">
                   <!-- <a class="nav-link" id="step1-tab" href="javascript:void(0);">Product Selection</a>
                    <a class="nav-link" id="step2-tab" href="javascript:void(0);">Procurement Enty</a>-->
                    <a class="nav-link active" id="step3-tab" href="javascript:void(0);">Lot Details</a>
                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">
                        <!-- <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1">
                                Contact Person Details
                            </h4>
                        </div> -->
                        <!-- end card header -->
                        <div class="card-body">
                            <div class="live-preview">
                                <form action="{{ route('superadmin.Step3Save') }}" method="get">
                                    <div class="row seperatesec  white-inner">
                                        <div class="sectitle">
                                            <label for="labelInput" class="form-label  blue-ht">Lot Details</label>
                                        </div>
                                        <div class="table-responsive">
                                            <table class="table table-bordered table-striped align-middle dataTable no-footer" width="100%" id="datatable">
                                                <thead>
                                                    <tr>
                                                        <th>S.No.</th>
                                                        <th>Lot ID</th>
                                                        <th>Product Code</th>
                                                        <th>Product Name</th>
                                                        <th>Lot Quantity (MT)</th>
                                                        <th>Creation On</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
    @if($entry->isNotEmpty())
        @foreach($entry as $index => $product)
            <tr>
                <td>{{ $index + 1 }}</td>
                <td>{{ $product->lot_number }}</td>
                
                @php
                    $matchedProduct = $products->firstWhere('id', $product->ref_product_id);
                @endphp
                <td>{{($product->ref_product_id)}}</td>
                <td>{{ $matchedProduct ? $matchedProduct->name_of_corp : 'N/A' }}</td>
                <td>{{ $product->quantity_source }}</td>
                <td>{{ $product->created_at->format('d-m-Y') }}</td>
            </tr>
        @endforeach
    @else
        <tr>
            <td colspan="6">No Record Found...</td>
        </tr>
    @endif
</tbody>


                                            </table>
                                        </div>
                                        <div class="col-lg-7">
                                            <div class="hstack gap-2 justify-content-end">
                                                <!-- <button type="submit" id="formSubmit" class="btn btn-primary">Generate Lot</button> -->
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection



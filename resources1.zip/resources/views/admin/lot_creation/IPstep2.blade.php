@extends('admin.layouts.app')

@section('content')
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Lot Creation</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Lot Creation</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">
            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">
                    <a class="nav-link" id="step1-tab" href="javascript:void(0);">Product Selection</a>
                    <a class="nav-link active" id="step2-tab" href="javascript:void(0);">Procurement Entry</a>
                    <a class="nav-link" id="step3-tab" href="javascript:void(0);">Lot Details</a>
                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">
                        <div class="card-body">
                            <div class="live-preview">
                                <div class="row seperatesec white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label blue-ht">Product Details</label>
                                    </div>
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped align-middle" width="50%" id="datatable_">
                                            <thead>
                                                <tr>
                                                    <th>Product Name:</th>
                                                    <td>{{ $data->name_of_corp ?? '' }}</td>
                                                    <th>HS Code</th>
                                                    <td>{{ getRefHscodeByID($data->id ?? '') }}</td>
                                                    <th>Organic Status</th>
                                                    <td>{{ $data->organic_status ?? ''}}</td>
                                                </tr>
                                                <tr>
                                                    <th>Closing Stock:</th>
                                                    <td>{{ $data->closing_stock ?? ''}}</td>
                                                    <th>Remaining Quantity</th>
                                                    <td>{{ $data->actual ?? ''}}</td>
                                                    <th>Total Quantity Procured (in MT)</th>
                                                    <td>{{ $procuredata->quantity_source ?? ''}}</td>
                                                </tr>
                                            </thead>
                                        </table>
                                    </div>
                                </div>

                                <div class="row seperatesec white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label blue-ht">Lot Details</label>
                                    </div>
                                    <div class="table-responsive">
                                        <form id="lotForm">
                                            <table class="table table-bordered table-striped align-middle dataTable no-footer" width="100%" id="datatable">
                                                <thead>
                                                    <tr>
                                                        <th>S.No.</th>
                                                        <th>Farm No</th>
                                                        <th>Farmer Name</th>
                                                        <th>Farm Name</th>
                                                        <th>Harvest Date</th>
                                                        <th>Harvest Year</th>
                                                        <th>Total Quantity (in MT)</th>
                                                        <th>Remaining Quantity (in MT)</th>
                                                        <th>Quantity Source (in MT)</th>
                                                        <th>Receipt No</th>
                                                        <th>Receipt Date</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>1.</td>
                                                        <td>{{ $farmdetail->farm_no ?? ''}}</td>
                                                        <td>{{ $farmerdetail->farmer_first_name ?? ''. ' ' . $farmerdetail->farmer_middle_name ?? '' . ' ' . $farmerdetail->farmer_last_name ?? ''}}</td>
                                                        <td>{{ $farmdetail->farm_name ?? ''}}</td>
                                                        <td>{{ isset($data->harvest_date) ? date('d-m-Y',strtotime($data->harvest_date)) : '-' }}</td>
                                                       {{------- <td>{{ \Carbon\Carbon::parse($data->harvest_date)->format('Y') }}</td>---}}
                                                        <td>{{isset($data->harvest_date) ? date('Y', strtotime($data->harvest_date)) : '-'}}</td>
                                                        <td>{{ $data->actual ?? ''}}</td>
                                                        <td>{{ $data->closing_stock ?? ''}}</td>
                                                        <td><input name="quantity_source" type="text" value="" class="form-control" id="quantity_source"></td>
                                                        <td><input name="receipt_no" type="number" value="" class="form-control" id="receipt_no"></td>
                                                        <td><input name="receipt_date" type="date" value="" class="form-control" id="receipt_date">
                                                        <input name="id" type="hidden" value="{{ $data->id ?? '' }}" id="id">
                                                        <input name="at_farm_details_id" type="hidden" value="{{ $farmdetail->farm_no ?? '' }}" id="at_farm_details_id">
                                                        <input name="at_farmer_details_id" type="hidden" value="{{ $farmerdetail->id ?? '' }}" id="at_farmer_details_id"></td>
                                                        <td><button type="button" id="saveButton" class="btn btn-primary">Save</button></td>
                                                    </tr>
                                                </tbody>
                                            </table>                                        
                                        </form>
                                    </div>
                                     <!-- Centered Generate Lot Button -->
                                     <div class="d-flex justify-content-center mt-3">
                                        <button type="button" id="addButton" class="btn btn-primary">Generate Lot</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endsection
    @push('script')
        <script>
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $(document).ready(function() {
                $('#datatable').DataTable();

                $('#saveButton').click(function() {
                    var formData = {
                        id: $('#id').val(),
                        quantity_source: $('#quantity_source').val(),
                        receipt_no: $('#receipt_no').val(),
                        receipt_date: $('#receipt_date').val(),
                        at_farmer_details_id: $('#at_farmer_details_id').val(),
                        at_farm_details_id: $('#at_farm_details_id').val()                        
                    };

                    $.ajax({
                        type: 'POST',
                        url: '{{ route("superadmin.saveIPLotDetails") }}',
                        data: formData,
                        dataType: 'json',
                        success: function(response) {
                            alert('Data saved successfully!');
                            location.reload(); // This will refresh the page
                        },
                        error: function(response) {
                            alert('Data with Existing ID already exist in Table');
                        }
                    });
                });

                $('#addButton').click(function() {
                    var refProductId = $('#id').val();

                    $.ajax({
                        type: 'POST',
                        url: '{{ route("superadmin.generateIPLotNumber") }}',
                        data: { ref_product_id: refProductId },
                        dataType: 'json',
                        success: function(response) {
                            if (response.success) {
                                alert('Lot number generated successfully!');
                                //location.reload(); // This will refresh the page
                                window.location.href = '{{ route("superadmin.IPLotDetails", ["id" => ":id"]) }}'.replace(':id', refProductId);

                            } else {
                                alert('Error generating lot number: ' + response.message);
                            }
                        },
                        error: function(response) {
                            alert('lot number already generated');
                        }
                    });
                });
            });
        </script>
    @endpush

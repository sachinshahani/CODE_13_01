@extends('admin.layouts.app')

@section('content')
    <style>
        .wrapper {
            max-width: 1240px;
            margin: 0 auto;
        }

        .white-bg {
            background-color: white;
            /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
            border-bottom: 5px solid #ff9800;
            margin-bottom: 15px;
        }

        .auth-one-bg .slide .carousel-indicators {
            bottom: 25px;
        }

        .auth-page-wrapper .auth-page-content {
            padding-bottom: 0px !important;
        }

        .auth-page-content .card {
            margin-bottom: 0rem;
        }

        .data-tabs .wrapper .nav-tabs button {
            font-size: 17px;
            color: black;
        }

        .data-tabs .wrapper .nav-tabs .active {
            background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
            */ color: white;
            background: orange;
            border-radius: 0px;
        }

        .carousel-caption.d-none.d-md-block {
            background-color: #000000bf;
            left: 0;
            width: 100%;
            bottom: 0;
        }

        .carousel-indicators {
            display: none;
        }

        .custom-banner-caption {
            color: white !important;
        }

        .announcement-heading {
            font-size: 1.2em;
            font-weight: 600;
        }

        .data-tabs .tab-pane ul li {
            font-size: 1em;
            padding: 5px 0;

        }

        .main-logo {
            padding: 10px;
        }

        .data-tabs .nav-item .nav-link {
            background-image: none;
        }

        /* .right-sec{
            box-shadow: 5px 10px 18px #888888;
        } */
        .navbar-brand-box {
            background: #fff;
        }

        .btn-danger {
            background-color: #40895a;
            border: 1px solid #40895a;
        }

        [data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
            color: white !important;
        }

        .header-buttons .btn-primary {
            margin-right: 10px;
            padding: 6px 15px;
            font-weight: 600;
            background-color: #207005;
            border: none;
            box-shadow: 0px 2px 7px #888888;
        }

        .header-buttons .btn-secondary {
            margin-right: 10px;
            padding: 6px 15px;
            font-weight: 600;
            background-color: #72a055;
            border: none;
            box-shadow: 0px 2px 7px #888888;
        }


        .right-sec {
            border-left: 5px solid #ede7e7;
        }

        .tabdiv {
            background: white;
            padding: 20px;
            margin-top: 10px;
            border: 10px solid #dfdbd5;
        }

        .nav-tabs {
            border-bottom: 0px;
        }

        div#myTabContent {
            border: 1px solid #cccccc;
        }

        .frontfooter footer {
            padding: 20px calc(1.5rem / 2);
            position: static;
            color: #000;
            height: 60px;
            background-color: #f9f9f9;
            margin-top: 30px;
            border-top: 1px solid #e1dfdf;
        }

        span.logo-sm img {
            width: 69px;
        }

        .seperatesec {
            margin-top: 20px;
        }

        .simplebar-content li.nav-item:hover {
            background: #4caf50;
        }

        .sectitle {
            font-size: 14px;
        }

        .required {
            color: red;
        }

        .customtextarea {
            height: 120px;
        }

        ul.boxsection {
            margin: 0;
            padding: 0;
        }

        ul.boxsection li {
            list-style-type: none;
            padding: 7px 0;
            border-bottom: 1px solid #efeded;
        }

        .boxcard .col:nth-child(1) {
            background: #effcfb;
        }

        .boxcard .col:nth-child(2) {
            background: #fdfdfd;
        }

        .boxcard .col:nth-child(3) {
            background: #effcfb;
        }

        .boxcard .col:nth-child(4) {
            background: #fdfdfd;
        }

        .boxcard .col:nth-child(5) {
            background: #effcfb;
        }

        /* --registration-form css  */
        .custom-tab-content {
            padding-top: 0 !important;
            padding-bottom: 0px !important;
        }

        .custom-tab-nav {
            background: white;

        }

        .custom-tab-nav .nav-link {
            border-radius: 0 !important;
            border-bottom: 1px solid #e9ebec;
            border-right: 1px solid #e9ebec;
            font-size: 14px;
            padding: 10px;
        }

        .custom-tab-nav .nav-link.active,
        .custom-tab-nav .show>.nav-link {
            color: rgb(255, 255, 255) !important;
            background-color: #2c8c6d;
            border-bottom: #2c8c6d !important;
            /* border-bottom: #207005 !important; */
            position: relative;
        }

        .custom-tab-nav .nav-link:hover,
        .custom-tab-nav .nav-link:focus {
            border-bottom: 1px solid #207005;
            border-radius: 0;
            font-size: 14px;
            transition: background-color 0.20s linear;
        }

        .custom-tab-nav .nav-link.active:after {
            content: "";
            position: absolute;
            bottom: -16px;
            left: 50%;
            border: 8px solid transparent;
            border-top-color: #2c8c6d;
            z-index: 999;
        }

        .reg-form-btns {
            margin-bottom: 15px;
        }

        .reg-form-btns .btn-secondary {
            color: #fff;
            background-color: #405189;
            border-color: #405189;
        }

        .btn-soft-success:active,
        .btn-soft-success:focus,
        .btn-soft-success:hover {
            border: none;
        }

        .custom-tab-nav ul {
            padding: 0px;
            margin: 0px;
        }

        .custom-tab-nav ul li {
            padding: 0px;
            margin: 0px;
            display: inline-block;
            list-style: none;
        }

        .has-error {
            border: 1px solid red;
        }

        .errormsg {
            color: red;
            font-size: 14px !important;
        }
    </style>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">उत्पादक समूह प्रोफ़ाइल/ Grower Group Profile</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Grower Group Profile</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">

            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                    <a class="nav-link" href="{{ route('superadmin.icsuser.step1', $userdetails->id) }}">General
                        Information</a>
                    <a class="nav-link" href="{{ route('superadmin.icsuser.step2', $userdetails->id) }}">Self/Service Provider
                        Details</a>

                    <a class="nav-link" href="{{ route('superadmin.icsuser.step4', $userdetails->id) }}">Internal Inspector
                        Details</a>
                    <a class="nav-link" href="{{ route('superadmin.icsuser.step5', $userdetails->id) }}">Warehouse/Godown
                        </a>
                    <a class="nav-link" href="{{ route('superadmin.icsuser.step6', $userdetails->id) }}">Grower Group Official
                        Details</a>
                    <a class="nav-link active" id="step3-tab" data-bs-toggle="tab"
                        href="{{ route('superadmin.icsuser.step3', $userdetails->id) }}">Farmer Details</a>
                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">


                <div class="tab-pane fade show active" id="step3">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1"> किसान का विवरण जोड़ें/Add Details of Farmer
                            </h4>
                            <div class="flex-shrink-0">
                                @if (session('error'))
                                    <div class="alert alert-danger">
                                        {{ session('error') }}
                                    </div>
                                @endif
                                @if (session('success'))
                                    <div class="alert alert-success">
                                        {{ session('success') }}
                                    </div>
                                @endif
                                @if ($errors)
                                    @foreach ($errors->all() as $error)
                                        <div class="alert alert-danger">{{ $error }}</div>
                                    @endforeach
                                @endif
                            </div>
                        </div>
                        <!-- end card header -->
                        <div class="card-body" id="regform">

                            <div class="row align-items-end">                                   
                                <div class="col-xxl-2 col-md-3 ">
                                    <div>
                                        <label class="form-label">Total Farmers<span
                                                class="required"></span></label>
                                        <input type="text" class="form-control numbersonly "id="totalfarmers" name="" value="{{$userdetails->no_of_farmers ?? ''}}" required  readonly/>
                                    </div>
                                </div>
                                <div class="col-xxl-10 col-md-9 ">
                                    <div class="form-group change">
                                        <div class="btn btn-primary" id="" onclick="AddDetailsFarmer('{{ $userdetails->no_of_farmers ?? '' }}', '{{ count($userfardetails) }}', '{{ $userdetails->id }}', '1')"
                                        style="float: right;">Add More+</div>
                                    </div>
                                </div>
                            
                            @php $i=0; @endphp    

                            
                            @forelse($userfardetails as  $ii=>$val)
                                
                           
                                
                                <form method="post" id="frm{{ $i }}" action="" enctype="multipart/form-data">
                                    @csrf

                                     <!-- at_farmer_reg_details table  Id -->
                                    <input type="hidden" name="at_farmer_reg_details_id[]" value="{{ $val->id }}">
                                    <!-- user auth id -->
                                    <input type="hidden" name="userid" value="{{ $userdetails->id }}">
                                    <!-- inspector Id -->
                                    <input type="hidden" id="userinspectorId" name="user_inspector_id" value="{{ $val->at_ics_inspector_id }}">
                                    
                                    <div class="live-preview">
                                        <div class="row after-add-more mt-3">
                                            <div id="error{{ $i }}"></div>
                                            <div class="sectitle gy-3">
                                                <label for="labelInput" class="form-label blue-ht">किसान का विवरण/Farmer Details</label>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 ">
                                                <label for="basiInput" class="form-label">भूमि स्वामित्व का प्रकार/Select Land Holding Type<span
                                                        class="required">*</span></label>
                                                <select class="form-select whType" name="land_holding_type[]" required>
                                                    <option value="">-select-</option>
                                                   
                                                        <option value="owned"
                                                            {{ isset($userfardetails[$ii]) && $userfardetails[$ii]->land_holding_type == 'owned' ? 'selected' : '' }}>
                                                            Owned
                                                        </option>
                                                        <option value="leased"
                                                            {{ isset($userfardetails[$ii]) && $userfardetails[$ii]->land_holding_type == 'leased' ? 'selected' : '' }}>
                                                            Leased
                                                        </option>
                                                        <option value="ancestor"
                                                            {{ isset($userfardetails[$ii]) && $userfardetails[$ii]->land_holding_type == 'ancestor' ? 'selected' : '' }}>
                                                            Ancestor
                                                        </option>
                                                            
                                                        
                                                </select>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 ">
                                                <div>
                                                    <label class="form-label">आधार/Aadhaar No.<span
                                                            class="required">*</span></label>
                                                    <input type="text" class="form-control numbersonly" maxlength="12" id="aadhar_number{{$i}}"
                                                        placeholder="Aadhaar No." name="aadhar_number[]"
                                                        value="{{ isset($userfardetails[$ii]) && $userfardetails[$ii]->aadhar_number != '' ? $userfardetails[$ii]->aadhar_number : '' }}"
                                                        required />
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3">
                                                <div>
                                                    <label class="form-label">किसान का नाम/Name of Farmer<span
                                                            class="required">*</span></label>
                                                    <input type="text" class="form-control" id="farmer_name{{$i}}"
                                                        placeholder="Name of Farmer" name="farmer_name[]"
                                                        value="{{ isset($userfardetails[$ii]) && $userfardetails[$ii]->farmer_first_name != '' ? $userfardetails[$ii]->farmer_first_name : '' }}"
                                                        required />
                                                </div>
                                            </div>

                                            <div class="col-xxl-2 col-md-2 ">
                                                <div>
                                                    <label class="form-label">लिंग/Gender<span class="required">*</span></label>
                                                    <select name="gender[]" id="gender{{$i}}" class="form-select" required>
                                                        <option value="">Select Gender</option>
                                                        <option value="M"
                                                            {{ isset($userfardetails[$ii]) && $userfardetails[$ii]->gender == 'M' ? 'selected' : '' }}>
                                                            Male</option>
                                                        <option value="F"
                                                            {{ isset($userfardetails[$ii]) && $userfardetails[$ii]->gender == 'F' ? 'selected' : '' }}>
                                                            Female</option>
                                                        <option value="O"
                                                            {{ isset($userfardetails[$ii]) && $userfardetails[$ii]->gender == 'O' ? 'selected' : '' }}>
                                                            Other</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3 ">
                                                <div>
                                                    <label class="form-label">पिता/पति/Father/Husband<span
                                                            class="required">*</span></label>
                                                    <select name="father_flag[]" id="father_flag{{$i}}" class="form-select" required>
                                                        <option value="">Select</option>
                                                        <option value="F"
                                                            {{ isset($userfardetails[$ii]) && trim($userfardetails[$ii]->father_husband_flag) == 'F' ? 'selected' : '' }}>
                                                            Father</option>
                                                        <option value="H"
                                                            {{ isset($userfardetails[$ii]) && trim($userfardetails[$ii]->father_husband_flag) == 'H' ? 'selected' : '' }}>
                                                            Husband</option>
                                                    </select>
                                                </div>
                                            </div>
                                           
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">पिता/पति का नाम/Father/Husband Name<span
                                                            class="required">*</span></label>
                                                    <input type="text" id="father_name{{$i}}" name="father_name[]" class="form-control" placeholder="Father/Husband Name" value="{{ isset($userfardetails[$ii]) && $userfardetails[$ii]->father_husband_first_name != '' ? $userfardetails[$ii]->father_husband_first_name : '' }}"
                                                        required>
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">मोबाइल नंबर/Mobile No.<span
                                                            class="required">*</span></label>
                                                    <input type="text" maxlength="10" class="form-control numbersonly"
                                                        id="mobile_no{{$i}}" onblur="phonenumber(this)"
                                                        placeholder="Mobile Number*" name="mobile_no[]"
                                                        value="{{ isset($userfardetails[$ii]) && $userfardetails[$ii]->mobile_no != '' ? $userfardetails[$ii]->mobile_no : '' }}"
                                                        required />
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3 ">
                                                <div>
                                                    <label for="labelInput" class="form-label">ईमेल आईडी/Email Id<span
                                                    class="required">*</span></label>
                                                    <input type="email" class="form-control" id="email{{$i}}"
                                                        placeholder="Email Id*" name="email[]" onblur="checkEmailValidity(this)"
                                                        value="{{ isset($userfardetails[$ii]) && $userfardetails[$ii]->email_id != '' ? $userfardetails[$ii]->email_id : '' }}" />
                                                </div>
                                            </div>

                                            <div class="sectitle gy-3">
                                                <label for="labelInput" class="form-label blue-ht">संपर्क विवरण/Communication Details
                                                </label>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div class="row">
                                                    <div class="col-xx-12 col-md-12">
                                                        <label for="labelInput" class="form-label">पता/Address<span
                                                                class="required">*</span></label>
                                                        <textarea placeholder="Address of The Farmer" class="form-control customtextarea" id="address{{$i}}" name="address[]">{{ isset($userfardetails[$ii]) && $userfardetails[$ii]->farmer_address != '' ? $userfardetails[$ii]->farmer_address : '' }}</textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-xxl-9 col-md-9  ">
                                                <div class="row  ">
                                                    <div class="col-xxl-4 col-md-4 gy-3">
                                                        <div>
                                                            <label for="labelInput" class="form-label">राज्य/State<span
                                                                    class="required">*</span></label>
                                                            <select class="form-select state" id="state{{$i}}" name="state[]">
                                                                <option value="">Select State</option>
    
                                                                @forelse(CBstateAssign($cbstate->id) as $state)
                                                                    <option value="{{ $state->ref_state_id }}"
                                                                        @selected(isset($userfardetails[$ii]->ref_state_id) && $userfardetails[$ii]->ref_state_id == $state->ref_state_id)>
                                                                        {{ $state->state_name }}</option>
                                                                @empty
                                                                @endforelse
                                                            </select>
                                                        </div>
                                                    </div>

                                                    <div class="col-xxl-4 col-md-4 gy-3">
                                                        <div>
                                                            <label for="labelInput" class="form-label">जिला/District<span
                                                                    class="required">*</span></label>
                                                            <select id="district{{$i}}" class="form-select district" name="district[]">
                                                                <option value="">Select District</option>
                                                                @if (isset($userfardetails[$ii]->ref_state_id))
                                                                    @forelse(getDistrictByStateID($userfardetails[$ii]->ref_state_id) as $district)
                                                                        <option value="{{ $district->id }}"
                                                                            @selected($userfardetails[$ii]->ref_district_id == $district->id)>
                                                                            {{ $district->district_name }}</option>
                                                                    @empty
                                                                    @endforelse
                                                                @endif
                                                            </select>
                                                        </div>
                                                    </div>

                                                    <div class="col-xxl-4 col-md-4 gy-3">
                                                        <div>
                                                            <label for="labelInput" class="form-label">तहसील/मंडल/Taluka/Mandal
                                                                <span class="required">*</span></label>
                                                            <select class="form-select block_tehsil" name="taluka[]" id="taluka{{$i}}">
                                                                <option value="">Select Taluka/Mandal</option>
                                                                @if (isset($userfardetails[$ii]->ref_district_id))
                                                                    @forelse(getBlockTehsilByDistrictID($userfardetails[$ii]->ref_district_id) as $block)
                                                                        <option value="{{ $block->id }}"
                                                                            @selected($userfardetails[$ii]->ref_block_tehsil_id == $block->id)>
                                                                            {{ $block->block_tehsil_name }}</option>
                                                                    @empty
                                                                    @endforelse
                                                                @endif
                                                            </select>
                                                        </div>
                                                    </div>

                                                    <div class="col-xxl-6 col-md-6 gy-3">
                                                        <div>
                                                            <label class="form-label">गांव/Village</label>
                                                            <select class="form-select village" name="village[]" id="village{{$i}}">
                                                                <option value="">Select Village</option>
                                                                @if (isset($userfardetails[$ii]->ref_block_tehsil_id))
                                                                    @forelse(getVillageByBlock($userfardetails[$ii]->ref_block_tehsil_id) as $village)
                                                                        <option value="{{ $village->id }}"
                                                                            @selected($userfardetails[$ii]->ref_village_id == $village->id)>
                                                                            {{ $village->village_name }}</option>
                                                                    @empty
                                                                    @endforelse
                                                                @endif
                                                            </select>
                                                        </div>
                                                    </div>

                                                    <div class="col-xxl-6 col-md-6 gy-3">
                                                        <div>
                                                            <label for="labelInput" class="form-label">
                                                                पिन कोड/Pin Code<span
                                                                    class="required">*</span></label>
                                                            <input type="text" maxlength="6"
                                                                class="form-control numbersonly" id="pincode{{$i}}"
                                                                placeholder="Pin Code" name="pincode[]"
                                                                value="{{ isset($userfardetails[$ii]) && $userfardetails[$ii]->pin != '' ? $userfardetails[$ii]->pin : '' }}"
                                                                maxlength="6" />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-xxl-12 col-md-12 gy-3">
                                                <div class="row">
                                                    <div class="col-xx-12 col-md-12">
                                                        <label for="labelInput" class="form-label">खेत/फार्मों का पता/Land Address/ <span
                                                                class="required">*</span></label>
                                                        <textarea placeholder="Address of The Land" class="form-control customtextarea" name="land_address[]" id="land_address{{$i}}" required>{{ isset($userfardetails[$ii]) && $userfardetails[$ii]->landmark != '' ? $userfardetails[$ii]->landmark : '' }}</textarea>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="sectitle gy-3">
                                                <label for="labelInput" class="form-label blue-ht">खेत/फार्मों का विवरण/Farm Details</label>
                                            </div>

                                            <div class="col-xxl-3 gy-3">
                                                <div class="row">
                                                    <div class="col-xx-12 col-md-12">
                                                        <label for="labelInput" class="form-label">फार्मों की संख्या/No. of Farms<span
                                                                class="required">*</span></label>
                                                        <input type="number" class="form-control numbersonly" id="number_of_farm{{$i}}" name="number_of_farm[]"
                                                            value="{{ isset($userfardetails[$ii]) && $userfardetails[$ii]->no_of_farm != '' ? $userfardetails[$ii]->no_of_farm : '' }}" @if(isset($userfardetails[$ii]) && $userfardetails[$ii]->no_of_farm != '') readonly @else  onblur="farmadd(this,{{ $ii }})" @endif>
                                                    </div>
                                                </div>
                                            </div>




                                            <!-- खेत/फार्मों का विवरण/ Farm Details -->

                                            @if (isset($userfardetails[$ii]) && $userfardetails[$ii]->no_of_farm != '')
                                                    @php $farmno=1; @endphp
                                                    @forelse($userfardetails[$ii]->farmerLandDetail as $key1=>$land)
                                            <div id="addnewrow{{ $key1 }}">
                                               
                                                  
                                                    <div class="row my-3">
                                                        <div class="col-xx-2 col-md-2">
                                                            <label for="labelInput" class="form-label" style="color:red">फार्म नंबर/Farm No.{{$farmno++}}
                                                            </label>
                                                        </div>
                                                        <div class="col-xx-5 col-md-5">
                                                            <label for="labelInput" class="form-label">कुल क्षेत्रफल/Total Area (in
                                                                Hectare) <span class="required">*</span></label>
                                                            <input type="text"
                                                                placeholder="Total Area (in Hectare)"
                                                                class="form-control" id="total_Area{{$i}}" name="total_Area[]"
                                                                required="" value="{{$land->total_area}}">
                                                        </div>
                                                        <div class="col-xx-5 col-md-5">
                                                            <label for="labelInput" class="form-label">खाता/खसरा नंबर/सर्वे नंबर/Khata/khasra
                                                                No./Survey No. <span class="required">*</span></label>
                                                            <input type="text" placeholder="Khata/khasra No./Survey No." class="form-control" id="survey{{$i}}" name="survey[]" required value="{{$land->survay_no}}">
                                                        </div>
                                                    </div>
                                                    <div class="row my-3">
                                                        <div class="col-xxl-2 col-md-2"></div>
                                                        <div class="col-xxl-10 col-md-10">
                                                            <div class="row">
                                                                <div class="col-xxl-4 col-md-4 gy-3">
                                                                    <div>
                                                                        <label for="labelInput" class="form-label">State<span class="required">*</span></label>
                                                                        <select class="form-select state" name="ref_state_id[]" required>
                                                                            <option value="">Select State</option>
                                                                            @forelse(getAllState() as $state)
                                                                            <option value="{{ $state->id }}"  @selected($land->ref_state_id == $state->id)>{{ $state->state_name }}</option>
                                                                            @empty @endforelse
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="col-xxl-4 col-md-4 gy-3">
                                                                    <div>
                                                                        <label for="labelInput" class="form-label">District<span class="required">*</span></label>
                                                                        <select class="form-select district" name="ref_district_id[]" required>
                                                                            <option value="">Select District</option>
                                                                            @if (isset($land->ref_state_id))
                                                                        @forelse(getDistrictByStateID($land->ref_state_id) as $district)
                                                                            <option value="{{ $district->id }}"
                                                                            @selected($land->ref_district_id == $district->id)>
                                                                                {{ $district->district_name }}</option>
                                                                        @empty
                                                                        @endforelse
                                                                        @endif
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="col-xxl-4 col-md-4 gy-3">
                                                                    <div>
                                                                        <label for="labelInput" class="form-label">Taluka/Mandal<span class="required">*</span></label>
                                                                        <select class="form-select block_tehsil" name="ref_block_tehsil_id[]" required>
                                                                            <option value="">Select Taluka/Mandal</option>
                                                                            @if (isset($land->ref_district_id))
                                                                            @forelse(getBlockTehsilByDistrictID($land->ref_district_id) as $block)
                                                                                <option value="{{ $block->id }}"
                                                                                    @selected($land->ref_block_tehsil_id == $block->id)>
                                                                                    {{ $block->block_tehsil_name }}</option>
                                                                            @empty
                                                                            @endforelse
                                                                            @endif
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="col-xxl-6 col-md-6 gy-3">
                                                                    <div>
                                                                        <label class="form-label">Village</label>
                                                                        <select class="form-select village" name="ref_village_id[]" required>
                                                                            <option value="">Select Village</option>
                                                                            @if (isset($land->ref_block_tehsil_id))
                                                                                @forelse(getVillageByBlock($land->ref_block_tehsil_id) as $village)
                                                                                    <option value="{{ $village->id }}"@selected($land->ref_village_id == $village->id)>{{ $village->village_name }}</option>
                                                                            @empty
                                                                            @endforelse
                                                                            @endif
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="col-xxl-6 col-md-6 gy-3">
                                                                    <div>
                                                                        <label for="labelInput" class="form-label">Pin Code<span class="required">*</span></label>
                                                                        <input type="text" class="form-control numbersonly" id="placeholderInput" placeholder="Pin Code" name="pin[]" value="{{$land->pin ?? ''}}" maxlength="6" required>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        </div>
                                                    </div>
                                                    @empty
                                                   
                                                    @endforelse
                                                @endif

                                            </div>

                                            <!-- <div class="form-group change">
                                                <div class="btn btn-primary" id="submitbutton{{ $i }}"
                                                    onclick="formsubmit({{ $i }})" style="float: right;">
                                                    Save
                                                </div>
                                            </div> -->
                                            
                                        </div>
                                     
                                    </div>
                                </form>
                               
                                @php $i++; @endphp

                     @empty
                       <!-- scond case for new data insert  -->

                           


                            @php $i=0; @endphp
                            <form method="post" id="frm{{ $i }}" action="" enctype="multipart/form-data">
                                @csrf
                                <!-- user_id hidden -->
                                <input type="hidden" name="userid" value="{{ $userdetails->id }}">
                                <input type="hidden" name="at_farmer_reg_details_id[]" value="">
                                
                                 <!-- user_inspector_id hidden -->
                                <input type="hidden" id="userinspectorId" name="user_inspector_id" value="{{ isset($inspectorsForGroups[0]) && isset($inspectorsForGroups[0]['inspector_id']) ? $inspectorsForGroups[0]['inspector_id'] : '' }}"> 
                              
                                <div class="live-preview">
                                    <div class="row after-add-more">
                                        <div id="error{{ $i }}"></div>
                                        <div class="sectitle gy-3">
                                            <label for="labelInput" class="form-label blue-ht">किसान का विवरण/Farmer Details</label>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 ">
                                            <label for="basiInput" class="form-label">भूमि स्वामित्व का प्रकार/Select Land Holding Type<span
                                                    class="required">*</span></label>
                                            <select class="form-select whType" name="land_holding_type[]" required>
                                                <option value="">-select-</option>
                                               
                                                    <option value="owned">Owned</option>
                                                    <option value="leased">Leased </option>
                                                    <option value="ancestor">
                                                        Ancestor
                                                    </option>
                                                        
                                                    
                                            </select>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 ">
                                            <div>
                                                <label class="form-label">आधार/Aadhaar No.<span
                                                        class="required">*</span></label>
                                                <input type="text" class="form-control numbersonly" maxlength="12" id="aadhar_number{{$i}}"
                                                    placeholder="Aadhaar No." name="aadhar_number[]"
                                                    value=""
                                                    required />
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3">
                                            <div>
                                                <label class="form-label">किसान का नाम/Name of Farmer<span
                                                        class="required">*</span></label>
                                                <input type="text" class="form-control" id="farmer_name{{$i}}"
                                                    placeholder="Name of Farmer" name="farmer_name[]"
                                                    value=""
                                                    required />
                                            </div>
                                        </div>

                                        <div class="col-xxl-2 col-md-2 ">
                                            <div>
                                                <label class="form-label">लिंग/Gender<span class="required">*</span></label>
                                                <select name="gender[]" id="gender{{$i}}" class="form-select" required>
                                                    <option value="">Select Gender</option>
                                                    <option value="M">
                                                        Male</option>
                                                    <option value="F">
                                                        Female</option>
                                                    <option value="O">
                                                        Other</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3 ">
                                            <div>
                                                <label class="form-label">पिता/पति/Father/Husband<span
                                                        class="required">*</span></label>
                                                <select name="father_flag[]" id="father_flag{{$i}}" class="form-select" required>

                                                    <option value="">Select</option>
                                                    <option value="F">
                                                        Father</option>
                                                    <option value="H">
                                                        Husband</option>
                                                </select>
                                            </div>
                                        </div>
                                       
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">पिता/पति का नाम/Father/Husband Name<span
                                                        class="required">*</span></label>
                                                <input type="text" id="father_name{{$i}}" name="father_name[]" class="form-control" placeholder="Father/Husband Name" value=""
                                                    required>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label for="labelInput" class="form-label">मोबाइल नंबर/Mobile No.<span
                                                        class="required">*</span></label>
                                                <input type="text" maxlength="10" class="form-control numbersonly"
                                                    id="mobile_no{{$i}}" onblur="phonenumber(this)"
                                                    placeholder="Mobile Number*" name="mobile_no[]"
                                                    value=""
                                                    required />
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3 ">
                                            <div>
                                                <label for="labelInput" class="form-label">ईमेल आईडी/Email Id <span
                                                class="required">*</span></label>
                                                <input type="email" class="form-control" id="email{{$i}}"
                                                    placeholder="Email Id*" name="email[]" onblur="checkEmailValidity(this)"
                                                    value="" />
                                            </div>
                                        </div>

                                        <div class="sectitle gy-3">
                                            <label for="labelInput" class="form-label blue-ht">संपर्क विवरण/Communication Details
                                            </label>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div class="row">
                                                <div class="col-xx-12 col-md-12">
                                                    <label for="labelInput" class="form-label">पता/Address<span
                                                            class="required">*</span></label>
                                                    <textarea placeholder="Address of The Farmer" class="form-control customtextarea" id="address{{$i}}" name="address[]"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xxl-9 col-md-9  ">
                                            <div class="row  ">
                                                <div class="col-xxl-4 col-md-4 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">राज्य/State<span
                                                                class="required">*</span></label>
                                                        <select class="form-select state" id="state{{$i}}" name="state[]">
                                                            <option value="">Select State</option>
                                                            @forelse(CBstateAssign($cbstate->id) as $state)
                                                                <option value="{{ $state->ref_state_id }}">
                                                                    {{ $state->state_name }}</option>
                                                            @empty
                                                            @endforelse
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-xxl-4 col-md-4 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">जिला/District<span
                                                                class="required">*</span></label>
                                                        <select id="district{{$i}}" class="form-select district" name="district[]">
                                                            <option value="">Select District</option>
                                                          
                                                              
                                                        
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-xxl-4 col-md-4 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">तहसील/मंडल/Taluka/Mandal
                                                            <span class="required">*</span></label>
                                                        <select class="form-select block_tehsil" name="taluka[]" id="taluka{{$i}}">
                                                            <option value="">Select Taluka/Mandal</option>
                                                            
                                                      
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-xxl-6 col-md-6 gy-3">
                                                    <div>
                                                        <label class="form-label">गांव/Village</label>
                                                        <select class="form-select village" name="village[]" id="village{{$i}}">
                                                            <option value="">Select Village</option>
                                                            
                                                             
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-xxl-6 col-md-6 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">
                                                            पिन कोड/Pin Code<span
                                                                class="required">*</span></label>
                                                        <input type="text" maxlength="6"
                                                            class="form-control numbersonly" id="pincode{{$i}}"
                                                            placeholder="Pin Code" name="pincode[]"
                                                            value=""
                                                            maxlength="6" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xxl-12 col-md-12 gy-3">
                                            <div class="row">
                                                <div class="col-xx-12 col-md-12">
                                                    <label for="labelInput" class="form-label">खेत/फार्मों का पता/Land Address/ <span
                                                            class="required">*</span></label>
                                                    <textarea placeholder="Address of The Land" class="form-control customtextarea" name="land_address[]" id="land_address{{$i}}" required></textarea>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="sectitle gy-3">
                                            <label for="labelInput" class="form-label blue-ht">खेत/फार्मों का विवरण/Farm Details</label>
                                        </div>

                                        <div class="col-xxl-3 gy-3">
                                            <div class="row">
                                                <div class="col-xx-12 col-md-12">
                                                    <label for="labelInput" class="form-label">फार्मों की संख्या/No. of Farms<span
                                                            class="required">*</span></label>
                                                    <input type="number" class="form-control numbersonly" id="number_of_farm" name="number_of_farm[]"
                                                        value="" onblur="farmadd(this,'{{$i}}')">
                                                </div>
                                            </div>
                                        </div>

                                        <!-- खेत/फार्मों का विवरण/ Farm Details -->
                                         <div id="addnewrow{{ $i }}"></div>
                                

                                         <div class="form-group change">
                                            <div class="btn btn-primary" id="submitbutton{{ $i }}"
                                                onclick="formsubmit({{ $i }})" style="float: right;">
                                                Save
                                            </div>
                                        </div>
                                

                                    </div>
                                   
                                </div>
                            </form>
                            @php $i++; @endphp
                            @endforelse

                            <div class="card-body">
                                <div class="row">
                                    <div id="icsaddmore"></div>
                                <!-- </div> -->
                            <!-- </div> -->
                          
                          



                        
                          


                            <div class="card-body">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="hstack justify-content-center gap-2">
                                            <a href="{{ route('superadmin.icsuser.step2', $userdetails->id) }}"
                                                class="btn btn-soft-success">
                                                Back
                                            </a>
                                            <div class="btn btn-primary" id="submitbtn">
                                                Preview Form
                                            </button>

                                            <!-- <a href="{{ route('superadmin.icsuser.step4', $userdetails->id) }}"
                                                            class="btn btn-soft-success">
                                                            Next
                                                        </a> -->
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </div>


    </div>
    </div>



@endsection
@push('script')
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $(document).on('click', '#submitbtn', function() {
        	var err = 0;
            $('#regform').find("input,select,textarea").each(function() {
                if(this.value == "") {
                    err = 1;
                    console.log(this);
                    $('#'+this.id).parent().append('<label id="name-error" class="error" for="name">This field is required.</label>');
                    //window.location.href = "{{ route('superadmin.icsuser.preview',$userdetails->id)}}";
                }
            });
            if(err==0){
                	window.location.href = "{{ route('superadmin.icsuser.preview',$userdetails->id)}}";
                }

        });



        function phonenumber(inputtxt) {
            var phoneno = /^\d{10}$/;
            if (inputtxt.value.match(phoneno)) {
                return true;
            } else {
                Swal.fire('', 'Please enter a valid mobile number.', 'warning');
                $("#mobile").val('');
                return false;
            }
        }

        function farmadd(farmno, i) {
            var farmno = farmno.value;
            if (farmno > 0) {
                var html = '';
                for (let i = 0; i < farmno; i++) {
                    var ii = i + 1;
                    html += '<div class="row my-3">';
                    html += '<div class="col-xx-2 col-md-2">';
                    html += '<label for="labelInput" class="form-label">Farm No ' + ii + '</label></div>';

                    html += '<div class="col-xx-5 col-md-5">';
                    html +=
                        '<label for="labelInput" class="form-label">Total Area (in Hectare) <span class="required">*</span></label>';
                    html +=
                        '<input type="text" placeholder="Total Area (in Hectare)" class="form-control" name="total_Area[]" required=""></div>';
                    html += '<div class="col-xx-5 col-md-5">';
                    html +=
                        '<label for="labelInput" class="form-label">Khata/khasra No./Survey No. <span class="required">*</span></label>';
                    html +=
                        '<input type="text" placeholder="Khata/khasra No./Survey No." class="form-control" name="survey[] " =""></div></div>';



                    html += '<div class="row my-3">';
                    html += '<div class="col-xx-2 col-md-2">';
                    html += '<label for="labelInput" class="form-label"></label></div>';
                    html +=
                    '<div class="col-xxl-10 col-md-10"><div class="row"><div class="col-xxl-4 col-md-4 gy-3"><div><label for="labelInput" class="form-label">State<span class="required">*</span></label><select class="form-select state" name="ref_state_id[]" required><option value="">Select State</option>@forelse(getAllState() as $state)<option value="{{ $state->id }}">{{ $state->state_name }}</option>@empty @endforelse</select></div></div><div class="col-xxl-4 col-md-4 gy-3"><div><label for="labelInput" class="form-label">District<span class="required">*</span></label><select class="form-select district" name="ref_district_id[]" required><option value="">Select District</option>@forelse(getDistrictByStateID(old("state")) as $district)<option value="{{ $district->id }}">{{ $district->district_name }}</option>@empty @endforelse</select></div></div><div class="col-xxl-4 col-md-4 gy-3"><div><label for="labelInput" class="form-label">Taluka/Mandal<span class="required">*</span></label><select class="form-select block_tehsil" name="ref_block_tehsil_id[]" required><option value="">Select Taluka/Mandal</option>@forelse(getBlockTehsilByDistrictID(old("district")) as $block)<option value="{{ $block->id }}">{{ $block->block_tehsil_name }}</option>@empty @endforelse</select></div></div><div class="col-xxl-6 col-md-6 gy-3"><div><label class="form-label">Village</label><select class="form-select village" name="ref_village_id[]" required><option value="">Select Village</option>@forelse(getVillageByBlock(old("taluka")) as $village)<option value="{{ $village->id }}">{{ $village->village_name }}</option>@empty @endforelse</select></div></div><div class="col-xxl-6 col-md-6 gy-3"><div><label for="labelInput" class="form-label">Pin Code<span class="required">*</span></label><input type="text" class="form-control numbersonly" id="placeholderInput" placeholder="Pin Code" name="pin[]" value="" maxlength="6" required></div></div></div></div></div>';


                }


                $("#addnewrow" + i).html(html);

                $('.state').on('change', function() {
                    var th = $(this);
                    var state_id = this.value;
                    $.ajax({
                        url: districtUrl,
                        type: "POST",
                        data: {
                            state_id: state_id,
                        },
                        dataType: 'json',
                        success: function(result) {
                            if (result) {
                                th.closest('.row').find('.district').html(result);
                            }
                        }
                    });
                });

                $('.district').on('change', function() {
                    var th = $(this);
                    var district_id = this.value;

                    $.ajax({
                        url: blockTehsilUrl,
                        type: "POST",
                        data: {
                            district_id: district_id,
                        },
                        dataType: 'json',
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function(result) {
                            if (result) {
                                th.closest('.row').find('.block_tehsil').html(result);
                            }
                        }
                    });
                });

                $('.block_tehsil').on('change', function() {
                    var th = $(this);
                    var block_tehsil_id = this.value;

                    $.ajax({
                        url: villageUrl,
                        type: "POST",
                        data: {
                            block_tehsil_id: block_tehsil_id,
                        },
                        dataType: 'json',
                        success: function(result) {
                            if (result) {
                                th.closest('.row').find('.village').html(result);
                            }
                        }
                    });
                });


            }

        }

        function formsubmit(i) {
            // var formData = new formData('#frm'+i);
            // alert(i);
            var formData = new FormData($('#frm'+i)[0]); 
            

            // alert(formData);
            console.log(formData);
            $.ajax({
                url: "{{ route('superadmin.icsuser.step3postajax') }}",
                type: "POST",
                data: formData,
                processData: false,
                contentType: false,
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(result) {
                    $('#error' + i).html('');
                    $('#submitbutton' + i).hide();
                    Swal.fire('', 'Farmer Added successfully.', 'success');
                },
                error: function(xhr, status, error) {
                    if (xhr.status == 400) {

                        var response = JSON.parse(xhr.responseText);
                        console.log(response.errors);
                        let text = "";
                        $.each(response.errors, function(key, value) {
                            console.log(value[0]);

                            text += '<div class="alert alert-danger mb-xl-0" role="alert">';
                            text += '<strong>' + value[0] + ' </strong></div>';
                        });
                        $('#error' + i).html(text);

                    } else {
                        //console.error('Request failed with status:', xhr.status);
                    }
                }
            });

        }

        // Dropzone has been added as a global variable.

        $(document).ready(function() {
            $("body").on("click", ".add-more", function() {
                var html =
                    '<div class="row after-add-more seperatesec p-3 mt-1 white-inner"><div class="sectitle gy-3"><label for="labelInput" class="form-label blue-ht">Farmer Details</label></div><div class="col-xxl-3 col-md-3"><div><label class="form-label">Aadhaar Number<span class="required">*</span></label><input type="text" class="form-control numbersonly" id="placeholderInput2" placeholder="Aadhaar Number" name="aadhar_number[]" value="" maxlength="12" required></div></div><div class="col-xxl-3 col-md-3"><div><label class="form-label">Name of Farmer/किसान का नाम<span class="required">*</span></label><input type="text" class="form-control" id="placeholderInput" placeholder="Name of Farmer" name="farmer_name[]" value="" required></div></div><div class="col-xxl-2 col-md-2"><div><label class="form-label">Gender<span class="required">*</span></label><select name="gender[]" class="form-select" required><option value="">Select Gender</option><option value="Male">Male</option><option value="Female">Female</option><option value="Other">Other</option></select></div></div><div class="col-xxl-4 col-md-4"><div><label class="form-label">Father/Husband Flag<span class="required">*</span></label><select name="father_flag[]" class="form-select" required><option value="">Select Father/Husband Flag</option><option value="Father">Father</option><option value="Husband">Husband</option></select></div></div><div class="col-xxl-3 col-md-3 gy-3"><div><label class="form-label">Father/Husband Name<span class="required">*</span></label><input type="text" name="father_name[]" class="form-control" placeholder="Father/Husband Name" value="" required></div></div><div class="col-xxl-3 col-md-3 gy-3"><div><label for="labelInput" class="form-label">Mobile Number<span class="required">*</span></label><input type="text" maxlength="10" class="form-control numbersonly" id="mobile" onblur="phonenumber(this)" placeholder="Mobile Number*" name="mobile_no[]" value="" required></div></div><div class="col-xxl-3 col-md-3 gy-3"><div><label for="labelInput" class="form-label">Email Id</label><input type="email" class="form-control" id="" placeholder="Email Id*" name="email[]" value=""></div></div><div class="sectitle gy-3"><label for="labelInput" class="form-label blue-ht">Communication Details</label></div><div class="col-xxl-3 col-md-3 gy-3"><div class="row"><div class="col-xx-12 col-md-12"><label for="labelInput" class="form-label">Farmer Address<span class="required">*</span></label><textarea placeholder="Address of The Farmer" class="form-control customtextarea" name="address[]" required></textarea></div></div></div><div class="col-xxl-9 col-md-9"><div class="row"><div class="col-xxl-4 col-md-4 gy-3"><div><label for="labelInput" class="form-label">State<span class="required">*</span></label><select class="form-select state" name="state[]" required><option value="">Select State</option>@forelse(getAllState() as $state)<option value="{{ $state->id }}">{{ $state->state_name }}</option>@empty @endforelse</select></div></div><div class="col-xxl-4 col-md-4 gy-3"><div><label for="labelInput" class="form-label">District<span class="required">*</span></label><select class="form-select district" name="district[]" required><option value="">Select District</option>@forelse(getDistrictByStateID(old("state")) as $district)<option value="{{ $district->id }}">{{ $district->district_name }}</option>@empty @endforelse</select></div></div><div class="col-xxl-4 col-md-4 gy-3"><div><label for="labelInput" class="form-label">Taluka/Mandal<span class="required">*</span></label><select class="form-select block_tehsil" name="taluka[]" required><option value="">Select Taluka/Mandal</option>@forelse(getBlockTehsilByDistrictID(old("district")) as $block)<option value="{{ $block->id }}">{{ $block->block_tehsil_name }}</option>@empty @endforelse</select></div></div><div class="col-xxl-6 col-md-6 gy-3"><div><label class="form-label">Village</label><select class="form-select village" name="village[]" required><option value="">Select Village</option>@forelse(getVillageByBlock(old("taluka")) as $village)<option value="{{ $village->id }}">{{ $village->village_name }}</option>@empty @endforelse</select></div></div><div class="col-xxl-6 col-md-6 gy-3"><div><label for="labelInput" class="form-label">Pin Code<span class="required">*</span></label><input type="text" class="form-control numbersonly" id="placeholderInput" placeholder="Pin Code" name="pincode[]" value="" maxlength="6" required></div></div></div></div><div class="sectitle gy-3"><label for="labelInput" class="form-label">Land Address Detail</label></div><div class="col-xxl-12 col-md-12 gy-3_"><div class="row"><div class="col-xx-12 col-md-12"><label for="labelInput" class="form-label">Land Address<span class="required">*</span></label><textarea placeholder="Address of The Land" class="form-control customtextarea" name="land_address[]" required></textarea></div></div></div><div class="form-group change"><label for="">&nbsp;</label><br/><a class="btn btn-danger remove"><i class="ri-close-line"></i></a></div></div>';

                $(".live-preview > .after-add-more").last().after(html);


            });

            $("body").on("click", ".remove", function() {
                $(this).parents(".after-add-more").remove();
            });
        });

        $('.state').on('change', function() {
            var th = $(this);
            var state_id = this.value;

            $.ajax({
                url: districtUrl,
                type: "POST",
                data: {
                    state_id: state_id,
                },
                dataType: 'json',
                success: function(result) {
                    if (result) {
                        th.closest('.row').find('.district').html(result);
                    }
                }
            });
        });

        $('.district').on('change', function() {
            var th = $(this);
            var district_id = this.value;

            $.ajax({
                url: blockTehsilUrl,
                type: "POST",
                data: {
                    district_id: district_id,
                },
                dataType: 'json',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(result) {
                    if (result) {
                        th.closest('.row').find('.block_tehsil').html(result);
                    }
                }
            });
        });
        $('.block_tehsil').on('change', function() {
            var th = $(this);
            var block_tehsil_id = this.value;
            $.ajax({
                url: villageUrl,
                type: "POST",
                data: {
                    block_tehsil_id: block_tehsil_id,
                },
                dataType: 'json',
                success: function(result) {
                    if (result) {
                        th.closest('.row').find('.village').html(result);
                    }
                }
            });
        });



function checkEmailValidity(element) {
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;  
    if (element.value && !emailPattern.test(element.value)) {
        alert("The email format is invalid! Please enter a valid email address.");
        element.value = '';  
    }
}


function AddDetailsFarmer(totalfrm, totalinsertfrm, UserID, Insp_id, useridget) {
   
   var forms = $('#icsaddmore form');  
   var InspId = $('#userinspectorId').val();
   var frmcounts = parseInt(totalinsertfrm) +1 ;
   forms.each(function(index) {
       frmcounts++; 
   });
    
  // alert("Total Inserted Forms: " + frmcounts); 
   
   if (totalinsertfrm == totalfrm) {

    Swal.fire({
        title: 'Limit Reached',
        text: 'You cannot add more than ' + totalfrm + ' forms.',  
        icon: 'info',  
        confirmButtonText: 'OK'  
    });
    return false;
}

if (frmcounts >= totalfrm) {
    Swal.fire({
        title: 'Limit Reached',    
        text: 'You have reached the maximum limit of ' + totalfrm + ' forms.',
        icon: 'info', 
        confirmButtonText: 'OK'
    });
    return false;
}

   $('#whole_page_loader').show();
   $.ajax({
       url: "{{route('superadmin.icsuser.Addmorefrm')}}",
       method: "POST",
       data: {
           formcounts: frmcounts,
           totalNofrm: totalfrm, 
           totalInsertfrm: totalinsertfrm,
           UserID: UserID,  
           InspId: InspId,  
       },
       headers: {
           'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
       },
       success: function(result) {
           $('#whole_page_loader').hide();
           $('#icsaddmore').append(result);  
       },
       error: function(xhr, status, error) {
           $('#whole_page_loader').hide();
           Swal.fire("info", "Some Field Requird record: " + error, 'info');
       }
   });
}







    </script>
@endpush

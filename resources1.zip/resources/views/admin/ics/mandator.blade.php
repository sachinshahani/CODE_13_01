<style>
    /* email verification css */
    .overlay {
        background: rgb(0 0 0 / 50%);
        position: fixed;
        top: 0;
        z-index: 11111;
        left: 0;
        right: 0;
        bottom: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        display: none;
    }

    .loader {
        position: fixed !important;
        left: 50% !important;
        margin-left: -4em !important;
        top: 20em !important;
    }

    .wrapper {
        max-width: 1240px;
        margin: 0 auto;
    }

    .white-bg {
        background-color: white;
        /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
        border-bottom: 5px solid #ff9800;
        margin-bottom: 15px;
    }

    .auth-one-bg .slide .carousel-indicators {
        bottom: 25px;
    }

    .auth-page-wrapper .auth-page-content {
        padding-bottom: 0px !important;
    }

    .auth-page-content .card {
        margin-bottom: 0rem;
    }

    .data-tabs .wrapper .nav-tabs button {
        font-size: 17px;
        color: black;
    }

    .data-tabs .wrapper .nav-tabs .active {
        background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
        */ color: white;
        background: orange;
        border-radius: 0px;
    }

    .carousel-caption.d-none.d-md-block {
        background-color: #000000bf;
        left: 0;
        width: 100%;
        bottom: 0;
    }

    .carousel-indicators {
        display: none;
    }

    .custom-banner-caption {
        color: white !important;
    }

    .announcement-heading {
        font-size: 1.2em;
        font-weight: 600;
    }

    .data-tabs .tab-pane ul li {
        font-size: 1em;
        padding: 5px 0;

    }

    .main-logo {
        padding: 10px;
    }

    .data-tabs .nav-item .nav-link {
        background-image: none;
    }

    /* .right-sec{
        box-shadow: 5px 10px 18px #888888;
    } */
    .navbar-brand-box {
        background: #fff;
    }

    [data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
        color: white !important;
    }

    .header-buttons .btn-primary {
        margin-right: 10px;
        padding: 6px 15px;
        font-weight: 600;
        background-color: #207005;
        border: none;
        box-shadow: 0px 2px 7px #888888;
    }

    .header-buttons .btn-secondary {
        margin-right: 10px;
        padding: 6px 15px;
        font-weight: 600;
        background-color: #72a055;
        border: none;
        box-shadow: 0px 2px 7px #888888;
    }


    .right-sec {
        border-left: 5px solid #ede7e7;
    }

    .tabdiv {
        background: white;
        padding: 20px;
        margin-top: 10px;
        border: 10px solid #dfdbd5;
    }

    .nav-tabs {
        border-bottom: 0px;
    }

    div#myTabContent {
        border: 1px solid #cccccc;
    }

    .frontfooter footer {
        padding: 20px calc(1.5rem / 2);
        position: static;
        color: #000;
        height: 60px;
        background-color: #f9f9f9;
        margin-top: 30px;
        border-top: 1px solid #e1dfdf;
    }

    span.logo-sm img {
        width: 69px;
    }

    .seperatesec {
        margin-top: 20px;
    }

    .simplebar-content li.nav-item:hover {
        background: #4caf50;
    }

    .sectitle {
        font-size: 14px;
    }

    .required {
        color: red;
    }

    .customtextarea {
        height: 120px;
    }

    ul.boxsection {
        margin: 0;
        padding: 0;
    }

    ul.boxsection li {
        list-style-type: none;
        padding: 7px 0;
        border-bottom: 1px solid #efeded;
    }

    .boxcard .col:nth-child(1) {
        background: #effcfb;
    }

    .boxcard .col:nth-child(2) {
        background: #fdfdfd;
    }

    .boxcard .col:nth-child(3) {
        background: #effcfb;
    }

    .boxcard .col:nth-child(4) {
        background: #fdfdfd;
    }

    .boxcard .col:nth-child(5) {
        background: #effcfb;
    }

    /* --registration-form css  */
    .custom-tab-content {
        padding-top: 0 !important;
        padding-bottom: 0px !important;
    }

    .custom-tab-nav {
        background: white;

    }

    .custom-tab-nav .nav-link {
        border-radius: 0 !important;
        border-bottom: 1px solid #e9ebec;
        border-right: 1px solid #e9ebec;
        font-size: 14px;
        padding: 10px;
    }

    .custom-tab-nav .nav-link.active,
    .custom-tab-nav .show>.nav-link {
        color: rgb(255, 255, 255) !important;
        background-color: #2c8c6d;
        border-bottom: #2c8c6d !important;
        /* border-bottom: #207005 !important; */
        position: relative;
    }

    .custom-tab-nav .nav-link:hover,
    .custom-tab-nav .nav-link:focus {
        border-bottom: 1px solid #207005;
        border-radius: 0;
        font-size: 14px;
        transition: background-color 0.20s linear;
    }

    .custom-tab-nav .nav-link.active:after {
        content: "";
        position: absolute;
        bottom: -16px;
        left: 50%;
        border: 8px solid transparent;
        border-top-color: #2c8c6d;
        z-index: 999;
    }

    .reg-form-btns {
        margin-bottom: 15px;
    }

    .reg-form-btns .btn-secondary {
        color: #fff;
        background-color: #405189;
        border-color: #405189;
    }

    .btn-soft-success:active,
    .btn-soft-success:focus,
    .btn-soft-success:hover {
        border: none;
    }

    .custom-tab-nav ul {
        padding: 0px;
        margin: 0px;
    }

    .custom-tab-nav ul li {
        padding: 0px;
        margin: 0px;
        display: inline-block;
        list-style: none;
    }

    /* -------  */
    .btn-email {
        font-size: 13px;
        padding: 1px 7px;
        line-height: 17px;

    }

    .btn-mailsend {
        font-size: 13px;
        padding: 1px 7px;
        line-height: 17px;
    }

    .btn-verify {
        font-size: 13px;
        padding: 1px 7px;
        line-height: 34px;
    }

    .inputEmail .input-group-append {
        display: flex;
        align-items: end;
    }

    .inputEmail .validateEmailId {
        border-radius: 4px 0 0 4px;
    }

    .input-group-append .verifiEmail_otp,
    .input-group-append .resendEmail_otp {
        margin-left: 10px;
    }

    .login-pass.otp-email {
        margin-top: 5px
    }

    .login-pass.otp-email .inp-b {
        border-radius: 0 4px 4px 0
    }


    /* ----End---- */
</style>





<div class="overlay">
    <div class="loader"></div>
</div>

<div class="card">
    <div class="card-header align-items-center d-flex">
        <h4 class="card-title mb-0 flex-grow-1">
            सेवा प्रदाता विवरण/Service Provider Details
        </h4>
        <div class="flex-shrink-0">
            @if (session('error'))
                <div class="alert alert-danger">
                    {{ session('error') }}
                </div>
            @endif
            @if (session('success'))
                <div class="alert alert-success">
                    {{ session('success') }}
                </div>
            @endif
            @if ($errors)
                @foreach ($errors->all() as $error)
                    <div class="alert alert-danger">{{ $error }}</div>
                @endforeach
            @endif
        </div>
    </div>

    <div class="card-body">
        <div class="live-preview">
           
           
            <div class="row seperatesec white-inner" >
                <div class="col-xxl-3 col-md-4">
                    <div>
                        <label class="form-label">सेवा प्रदाता पैन/Service Provider PAN<span class="required">*</span></label>
                        <input type="text" class="form-control pan" placeholder="Enter PAN Number" required
                            name="pan" value="{{ $userselfdetail->pan_card ??''}}" />
                    </div>
                </div>
            </div>
          
            <div class="mandatorDiv" >
                <div class="row seperatesec white-inner">

                    <div class="col-xxl-3 col-md-4">
                        <div>
                            <label class="form-label">सेवा प्रदाता कंपनी का नाम/Service Provider Company Name<span class="required">*</span></label>
                            <input type="text" class="form-control" id="placeholderInput" placeholder="Comapny Name"
                                required name="company_mandator_name"
                                value="{{ $userselfdetail->company_mandator_name ?? '' }}" readonly />
                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-4">
                        <div>
                            <label class="form-label">जीएसटी नंबर/GST No.</label>
                            <input type="text" class="form-control" id="gstnum" maxlength="15" placeholder="GST Number"
                                name="gst_number" value="{{ $userselfdetail->gst_number ?? '' }}" readonly /><span
                                id="gsterrormsg" class=""></span>
                        </div>
                    </div>
                </div>
                <div class="row seperatesec white-inner">
                   
                        {{-- <h4 class="card-title mb-0 flex-grow-1">
                            <label for="labelInput" class="form-label">Contact Person Details</label>
                        </h4> --}}
                        
                        <div class="sectitle">
                            <label for="labelInput" class="form-label blue-ht">संपर्क व्यक्ति विवरण/Contact Person Details</label>
                        </div>
                    
                    <div class="col-xxl-2 col-md-4">
                        <div>
                            <label class="form-label">
                                पहला नाम/First Name <span class="required">*</span></label>
                            <input type="text" class="form-control" id="placeholderInput" placeholder="First Name"
                                required name="first_name" value="{{ $userselfdetail->first_name ??'' }}" maxlength="25" readonly />
                        </div>
                    </div>
                    <div class="col-xxl-2 col-md-4">
                        <div>
                            <label class="form-label">मध्य नाम/Middle Name</label>
                            <input type="text" class="form-control" id="placeholderInput" placeholder="Middle Name"
                                name="middle_name" value="{{ $userselfdetail->middle_name ??'' }}" maxlength="25"  readonly/>
                        </div>
                    </div>

                    <div class="col-xxl-2 col-md-4">
                        <div>
                            <label class="form-label">अंतिम नाम/Last Name<span class="required">*</span></label>
                            <input type="text" class="form-control" id="placeholderInput" placeholder="Last Name"
                                required name="last_name" value="{{ $userselfdetail->last_name ??'' }}" maxlength="25" readonly />
                        </div>
                    </div>
                    <div class="col-xxl-4 col-md-4 ">
                        

                        
                        <div class="inputEmail  col-12 col-sm-12 col-md-12 col-lg-12">
                            <div class="form-group d-flex justify-content-center ge-otp-form">
                                <div class="col-12 col-sm-12 col-md-10 col-lg-10">
                                    <label>ईमेल आईडी/Email ID<span class="text-danger">*</span></label>
                                    <input class="form-control validateEmailId col-12 col-sm-12 col-md-12 col-lg-12"
                                        type="text" value="{{ $userselfdetail->email_id ??'' }}" placeholder="Email Id" id="email_id1"
                                        name="email_id" required readonly />
                                </div>
                                <div class="input-group-append col-12 col-sm-12 col-md-2 col-lg-2">
                                    <button type="button"
                                        class="btn-email btn btn-outline-success waves-effect waves-light visitorCat2">OTP प्राप्त करें/Get
                                        OTP</button>
                                    <button type="button"
                                        class="btn btn-ghost-success waves-effect waves-light btn-mailsend"
                                        style="display:none">मेल भेजा गया/Mail Send</button>
                                    <button type="button"
                                        class="btn btn-ghost-success waves-effect waves-light btn-verify"
                                        style="display:none">सत्यापित/Verified</button>
                                </div>
                            </div>
                            <div class="verify-email justify-content-center">
                                <div class="login-pass mb-4 otp-email col-12 col-sm-12 col-md-5 col-lg-12 pl-2"
                                    style="display:none">
                                    <div class="input-group">
                                        <span class="input-group-text mdi mdi-key"
                                            id="inputGroup-sizing-default"></span>
                                        <input type="text" class="form-control inp-b  numbersonly"
                                            aria-label="Sizing example input"
                                            aria-describedby="inputGroup-sizing-default" id="email_otp1" maxlength="4">
                                        <div class="input-group-append">
                                            <a href="javascript:void(0)"
                                                class="verifiEmail_otp btn btn-outline-success waves-effect waves-light">सत्यापित करें/Verify</a>
                                            <a href="javascript:void(0)"
                                                class="resendEmail_otp btn btn-outline-danger waves-effect waves-light">
                                                फिर से भेजें/Resend</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-2 col-md-4 ">
                        <div>
                            <label for="labelInput" class="form-label">मोबाइल नंबर/Mobile No.<span class="required">
                                    *</span></label>
                            <input type="text" class="form-control numbersonly" maxlength="10" id="mobile"
                                onblur="phonenumber(this)" placeholder="Mobile Number" required name="mobile_no"
                                value="{{ $userselfdetail->mobile_no ??'' }}" readonly />
                        </div>
                    </div>

                    <div class="sectitle gy-4">
                        <label for="labelInput" class="form-label blue-ht">कार्यालय का पता/Office Address</label>
                    </div>
                    <div class="col-xxl-3 col-md-3">
                        <div class="row">
                            <div class="col-xx-12 col-md-12">
                                <label for="labelInput" class="form-label">पता/Address<span
                                        class="required">*</span></label>
                                <textarea placeholder="Address" class="form-control customtextarea" name="address" required readonly>{{ $userselfdetail->address1 ?? '' }}</textarea>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-9 col-md-9">
                        <div class="row">
                            <div class="col-xxl-4 col-md-4 ">
                                <div>
                                    <label for="labelInput" class="form-label">राज्य/State<span class="required">*</span></label>
                                            <input type="text" class="form-control numbersonly"  id="mobile"
                                          placeholder="" required name="state"
                                            value="{{ getStateName(isset($userselfdetail->ref_state_id) ? $userselfdetail->ref_state_id : 0) }}" readonly />

                                    {{-- <select class="form-select state" name="state" required >
                                        <option value="">Select State</option>
                                        @forelse(CBstateAssign($cbstate->id) as $state)
                                            <option value="{{ $state->refStateId ?? '' }}"
                                                {{ isset($userselfdetail) && $userselfdetail->ref_state_id == $state->id ? 'selected' : '' }}>
                                                {{ $state->state_name }}</option>
                                        @empty
                                        @endforelse
                                    </select> --}}
                                </div>
                            </div>

                            <div class="col-xxl-4 col-md-4">
                                <div>
                                    <label for="labelInput" class="form-label">राज्य चुनें/District<span
                                            class="required">*</span></label>

                                            <input type="text" class="form-control numbersonly"  id="district"
                                            placeholder="" required name="district"
                                              value="{{ isset($userselfdetail->ref_district_id) ? getDisName($userselfdetail->ref_district_id) : 0 }}" readonly />

                                    {{-- <select class="form-select district" name="district" required>
                                        <option value="">Select District</option>
                                        @forelse($districts as $district)
                                            <option value="{{ $district->id }}"
                                                {{ isset($userselfdetail) && $userselfdetail->ref_district_id == $district->id ? 'selected' : '' }}>
                                                {{ $district->district_name }}</option>
                                        @empty
                                        @endforelse
                                    </select> --}}
                                </div>
                            </div>

                            <div class="col-xxl-4 col-md-4">
                                <div>
                                    <label for="labelInput" class="form-label">तहसील/मंडल/Taluka/Mandal<span
                                            class="required">*</span></label>

                                            <input type="text" class="form-control "  id="taluka"
                                            placeholder="" required name="taluka"
                                              value="{{ isset($userselfdetail->ref_block_tehsil_id) ? getTalukName($userselfdetail->ref_block_tehsil_id) : 0 }}"  readonly/>


                                    {{-- <select class="form-select block_tehsil" name="taluka" required>
                                        <option value="">Select Taluka/Mandal</option>
                                        @forelse($regions as $region)
                                            <option value="{{ $region->id }}"
                                                {{ isset($userselfdetail->ref_block_tehsil_id) && $userselfdetail->ref_block_tehsil_id == $region->id ? 'selected' : '' }}>
                                                {{ $region->block_tehsil_name }}</option>
                                        @empty
                                        @endforelse
                                    </select> --}}
                                </div>
                            </div>
                            <div class="col-xxl-6 col-md-6 gy-3">
                                <div>
                                    <label class="form-label">गांव/Village </label>

                                    <input type="text" class="form-control "  id="village"
                                    placeholder="" required name="village"
                                      value="{{ isset($userselfdetail->ref_village_id) ? getVillName($userselfdetail->ref_village_id) : 0 }}" readonly/>

                                    {{-- <select class="form-select village" name="village" required >
                                        <option value="">Select Village</option>
                                        @forelse($villages as $village)
                                            <option value="{{ $village->id }}"
                                                {{ isset($userselfdetail->ref_village_id) && $userselfdetail->ref_village_id == $village->id ? 'selected' : '' }}>
                                                {{ $village->village_name }}</option>
                                        @empty
                                        @endforelse
                                    </select> --}}
                                </div>
                            </div>

                            <div class="col-xxl-6 col-md-6 gy-3">
                                <div>
                                    <label for="labelInput" class="form-label">पिन कोड/Pin Code<span
                                            class="required">*</span></label>
                                    <input type="text" class="form-control numbersonly" maxlength="6"
                                        id="placeholderInput" placeholder="Pin Code" name="pincode"
                                        value="{{ $userselfdetail->pin_code ?? 0 }}" maxlength="6" required readonly />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                            

                <div class="row seperatesec white-inner">

                    <div class="col-xxl-3 col-md-4 gy-3">
                        <div>
                            <label for="basiInput" class="form-label">
                                पहचान प्रमाण/ID Proof<span class="required">*</span>
                            </label>

                            <select class="form-select" name="id_proof" id="id_proof" required>
                                <option value="">-Select-</option>
                                {{-- <option value="pan"
                                {{ isset($userselfdetail) && $userselfdetail->id_proof == 'pan' ? 'selected' : '' }}>Pan
                            </option> --}}
                                <option value="aadhar"
                                    {{ isset($userselfdetail) && $userselfdetail->id_proof == 'aadhar' ? 'selected' : '' }}>
                                    आधार Aadhaar</option>
                            </select>

                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-4 gy-3 legal_doc_div"
                        {{ empty($userselfdetail->id_proof_doc) ? 'style=display:none' : '' }}>
                        <div>
                            <label class="form-label">पहचान प्रमाण दस्तावेज/ID Proof Doc<span class="required">*</span></label>
                            <input type="text" class="form-control numbersonly" id="" placeholder="ID Proof Doc" required
                                name="id_proof_doc" required value="{{ maskAadhaarNumber($userselfdetail->id_proof_doc ?? '') }}"
                                maxlength="12">

                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-4 gy-3">
                        <div>
                            <label class="form-label">सेवा प्रदाता की फोटो/Photo of Service Provider<span class="required">*</span></label>
                            <input type="file" class="form-control profile_photo_allow" name="profile_photo" id="profile_photo"
                                {{ $userselfdetail->profile_photo ?? 'required' }} accept="image/png, application/pdf, image/jpeg" >
                            <span class="form-text">Supported formats:JPG, PNG, PDF. Upto 2MB</span>
                            @if (!empty($userselfdetail->profile_photo))
                                <input type="hidden"id="profile_photo_edit" name="profile_photo_edit"
                                    value="{{ $userselfdetail->profile_photo ?? '' }}">
                                <a target="_BLANK"
                                    href="{{ asset('public/ics/profile_photo/' . $userselfdetail->profile_photo) }}"
                                    class="text-decoration-underline">See Doc</a>
                            @endif
                        </div>
                    </div>

                    <div class="col-xxl-3 col-md-4 gy-3">
                        <div>
                            <label class="form-label">
                                सेवा प्रदाता कार्यालय भवन की फोटो/Photo of Service Provider  Office Building<span class="required">*</span></label>
                            <input type="file" class="form-control profile_photo_allow" name="office_building_photo"
                                id="office_building_photo" {{ $userselfdetail->office_building_photo ?? 'required' }} accept="image/png, application/pdf, image/jpeg" >
                            <span class="form-text">Supported formats:JPG, PNG, PDF. Upto 2MB</span>
                            @if (!empty($userselfdetail->office_building_photo))
                                <input type="hidden" name="office_building_photo"
                                    value="{{ $userselfdetail->office_building_photo ?? '' }}">
                                <a target="_BLANK"
                                    href="{{ asset('public/ics/office_building_photo/' . $userselfdetail->office_building_photo) }}"
                                    class="text-decoration-underline">See Doc</a>
                            @endif
                        </div>
                    </div>


                    <div class="col-xxl-3 col-md-4 gy-3">
                        <div>
                            <label class="form-label">उत्पादक समूह और सेवा प्रदाता के बीच अनुबंध समझौता/Contract Agreement Between Grower Group & Service Provider<span class="required">*</span></label>
                            <input type="file" class="form-control profile_photo_allow" name="appointment_doc" id="appointment_doc"
                                {{ $userselfdetail->appointment_doc ?? 'required' }} accept="image/png, application/pdf, image/jpeg" >
                            <span class="form-text">Supported formats:JPG, PNG, PDF. Upto 2MB</span>
                            @if (!empty($userselfdetail->appointment_doc))
                                <input type="hidden" name="appointment_doc_edit"
                                    value="{{ $userselfdetail->appointment_doc ?? '' }}">
                                <a target="_BLANK"
                                    href="{{ asset('public/ics/appointment_doc/' . $userselfdetail->appointment_doc) }}"
                                    class="text-decoration-underline">See Doc</a>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 gy-4">
                    <div class="hstack gap-2">
                        <a href="{{ route('superadmin.icsuser.step1', $userdetails->id) }}"
                            class="btn btn-soft-success">Back</a>
                        <button type="submit" class="btn btn-primary" id="submitbtn">
                            Save & Next 
                        </button>
                        {{-- <a href="{{ route('superadmin.icsuser.step4', $userdetails->id) }}"
                            class="btn btn-soft-success">Next</a> --}}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@push('script')
    <script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
    <script>
        // $('input[name=is_reg]').change(function() {
        //     //console.log(this.value);
        //     if (this.value == 1) {
        //         $('.pandiv').show();
        //         $('.mandatorDiv').hide();
        //     } else if (this.value == 0) {
        //         $('.pandiv').hide();
        //         $('.mandatorDiv').show();
        //     }
        // });
        $(document).ready(function() {
            $('.profile_photo_allow').on('blur', function() {
                var fileInput = $(this);
                var file = fileInput[0].files[0];
                var fileType = file ? file.type : '';
                var validTypes = ['image/jpeg', 'image/png', 'image/gif', 'application/pdf'];
                var maxSize = 2 * 1024 * 1024;
                if (file) {
                    if (validTypes.indexOf(fileType) === -1) {
                        alert('Please select a valid image file (JPG, PNG, GIF) or PDF file.');
                        fileInput.val('');
                    } else if (file.size > maxSize) {
                        alert('The file size exceeds the 2MB limit. Please upload a smaller file.');
                        fileInput.val('');
                    }
                }
            });
        });
        $(document).on('change', '.pan', function() {

            var inputvalues = $(this).val();
            var regex = /[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
            if (!regex.test(inputvalues)) {
                //console.log(inputvalues);
                $(".pan").val("");
                alert("invalid PAN no");
                return regex.test(inputvalues);
            } else {
                //console.log(inputvalues);
                $.ajax({
                    type: 'POST',
                    url: "{{ route('superadmin.usermanagement.getMandatorDetail') }}",
                    data: {
                        'pan': inputvalues
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(resp) {
                      
                       //console.log(resp);
                     
                       //var resp = JSON.parse(resp);
                       if(resp==0) {
                           //Swal.fire("", "Pan Card does not exists", "error");
                        }
                        else {
                            $('.mandatorDiv').show();
                            $('input[name=company_mandator_name]').val(resp.mandator_name);
                            $('input[name=first_name]').val(resp.contact_first_name);
                            $('input[name=middle_name]').val(resp.contact_middle_name);
                            $('input[name=last_name]').val(resp.contact_last_name);
                            $('input[name=email_id]').val(resp.email);
                            $('input[name=mobile_no]').val(resp.mobile);
                            $('input[name=state]').val(resp.state); 
                            $('input[name=district]').val(resp.district);
                            $('input[name=taluka]').val(resp.taluka);
                            $('input[name=village]').val(resp.village);
                            $('input[name=pincode]').val(resp.pin_code);
                            $('textarea[name=address]').val(resp.address);
                            $('input[name=gst_number]').val(resp.gst_number);
                            $('input[name=id_proof_doc]').val(resp.aadhar_no);
                            if(resp.aadhar_no == ''){

                            }else{
                                $('#id_proof').eq(1).prop('selected', true);
                            } 
                        }
                    }
                });
            }
        });

        $(".btn-email").click(function(e) {
            e.preventDefault();
            var user_email = $('#email_id1').val();
            $(".overlay").show();

            if (user_email != "") {
                $.ajax({
                    type: 'POST',
                    url: "{{ route('superadmin.usermanagement.email_mobile_OTP') }}",
                    data: {
                        'user_email': user_email
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(resp) {
                        if (resp == 1) {

                            Swal.fire({
                                text: "Please verify OTP send on Email id",
                                icon: 'success',
                                confirmButtonText: 'OK'
                            }).then((result) => {
                                $('.otp-email').show(500);
                                $('#email_id1').val(user_email);
                                $('#email_id1').prop('readonly', true);
                                $('.btn-email').hide(500);
                                $('.btn-mailsend').show(100);
                            });

                        }
                        $(".overlay").hide();
                    }
                });
            } else {
                Swal.fire("", "Please enter Email ID", "error");
            }
        });


        $(".verifiEmail_otp").click(function(e) {
            e.preventDefault();
            var email_otp = $('#email_otp1').val();
            $(".overlay").show();
            if (email_otp != "") {

                $.ajax({
                    type: 'POST',
                    url: "{{ route('superadmin.usermanagement.email_mobile_OTP_check') }}",
                    data: {
                        'email_otp': email_otp
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(html) {
                        if (html == 0) {
                            Swal.fire("", "Please enter Valid OTP", "error");
                        } else {
                            $('#email_otp').prop('readonly', true);
                            $('.otp-email1').hide(500);
                            $('.btn-email').hide(500);
                            $('.btn-verify').show(500);
                            $('.visitorCat').hide(500);
                            $('.visitorCat1').hide(500);
                            $('.user_detail_page').show(500);
                            $('#email_id').prop('readonly', true);
                            $('.btn-mailsend').hide();
                            $('.login-pass').hide();
                        }
                        $(".overlay").hide();
                    }
                });
            } else {
                Swal.fire("", "Please enter OTP", "error");
            }
        });

        $(".resendEmail_otp").click(function(e) {
            e.preventDefault();
            var user_email = $('#email_id1').val();

            $.ajax({
                type: 'POST',
                url: "{{ route('superadmin.usermanagement.email_mobile_OTP') }}",
                data: {
                    'user_email': user_email
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(html) {
                    Swal.fire("", "Re OTP Send!!", "success");
                }
            });
        });
    </script>


    <script>
        $(document).on('click', '#submitbtn', function() {

            if (checkValidation("self_mandator")) {
                $('#self_mandator').submit();
                return true;
            } else {
                return false;
            }
        });

        function phonenumber(inputtxt) {
            var phoneno = /^\d{10}$/;
            if (inputtxt.value.match(phoneno)) {
                return true;
            } else {
                Swal.fire('', 'Please enter a valid mobile number.', 'warning');
                $("#mobile").val('');
                return false;
            }
        }

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('#id_proof').change(function() {
            if ($('#id_proof').val() != '') {
                if ($('#document_type').val() == 'pan') {
                    $('[name=id_proof_doc]').addClass('pan');
                } else {
                    $('[name=id_proof_doc]').removeClass('pan');
                }
                $('.legal_doc_div').show();
                $('[name=id_proof_doc]').attr('required', 'required');

            } else {
                $('.legal_doc_div').hide();
                $('[name=legal_document_number]').removeAttr('required');
            }
        });



        $(document).ready(function() {
            $("#gstnum").on("blur", function() {
                var str = $(this).val();
                let regex = new RegExp(/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/);
                if (str == null) {
                    return "false";
                }
                if (regex.test(str) == true) {
                    $("#gsterrormsg").removeClass('text-danger');
                    $("#gsterrormsg").addClass('text-success');
                    $("#gsterrormsg").html('GST Number is Valid');
                } else {
                    $("#gsterrormsg").removeClass('text-success');
                    $("#gsterrormsg").addClass('text-danger');
                    $("#gsterrormsg").html('GST Number is not Valid');
                }
            });
        });

        $('.dropzone').each(function() {
            var options = $(this).attr('id');
            $(this).dropzone({
                url: "{{ route('storeMedia') }}",
                paramName: "file",
                maxFilesize: 2,
                maxFiles: 1,
                acceptedFiles: ".jpeg,.jpg,.png,.mp4,.webm,.html5",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                init: function() {
                    var drop = this; // Closure
                    this.on('error', function(file, errorMessage) {
                        if (errorMessage.indexOf('Error 404') !== -1) {
                            var errorDisplay = document.querySelectorAll(
                                '[data-dz-errormessage]');
                            errorDisplay[errorDisplay.length - 1].innerHTML =
                                'Error 404: The upload page was not found on the server';
                        }
                        if (errorMessage.indexOf('File is too big') !== -1) {
                            alert('Unable to upload image size is greated than 2 MB');
                            // i remove current file
                            drop.removeFile(file);
                        }
                    });
                    this.on("maxfilesexceeded", function(file) {
                            this.removeAllFiles();
                            this.addFile(file);
                        }),
                        this.on("success", function(file, response) {
                            console.log(response);
                            var hiddenImage = $('<input type="hidden" name="_hidden_' + options +
                                '" value="' +
                                response.name + '"/>');
                            $('#hidden_' + options).html(hiddenImage);
                        })
                }
            });
        });
        const dropzone = new Dropzone("div.dropzone", {});



      

    </script>
@endpush

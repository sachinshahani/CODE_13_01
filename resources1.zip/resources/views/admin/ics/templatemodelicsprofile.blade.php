 
         <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="formDate" class="form-label">Operator name:</label>
                            <input type="text" class="form-control" name="contact_person_pan_number" value="{{user_name($users->id) ?? ''}}" readonly>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="toDate" class="form-label">PAN No:</label>
                            <input type="text" class="form-control" name="" value="{{$users->pen ?? 'NULL'}}" readonly>
                        </div>
                    </div>
                </div> 
                <div class="mb-3 statusdata">
                    <label for="search" id="search" class="form-label">STATUS:</label>
                    <div class="input-group mt-2 statusdata" id="selectedStatusSection">
                        <select class="form-select" name="selectedStatusInput" id="selectedStatusInput"
                            data-label-msg="Status" required>
                            <option value="0">Select status</option>
                            <option value="1">Suspend</option>
                            <option value="2">Terminate</option>
                            <option value="3">Withdrawal By CB</option>
                            <option value="4">Withdrawal By Operator</option>
                            <option value="5">De Register</option>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="formDate" class="form-label">From Date:</label>
                            <input type="date" class="form-control" name="from_date" id="formDate" value="">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="toDate" class="form-label">To Date:</label>
                            <input type="date" class="form-control" name="to_date" id="toDate"  value="">
                        </div>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="toDate" class="form-label">Till Date:</label>
                    <input type="date" class="form-control" value="" name="to_years" id="years"
                        placeholder="Enter Years and Month" readonly>
                </div>
                <div class="mb-3">
                    <label for="suspendReason" class="form-label">Report Non-Compliance:</label>
                    <textarea class="form-control" id="suspendRemark" name="remark" rows="3"></textarea>
                </div>
                <div class="mb-3">
                    <label for="declaration_consent" style="color: blue; display: none;">
                        <input type="checkbox" id="declaration_consent" name="declaration_consent">
                        We hereby declare that <span style="color: black; font-weight: bold;">{{(Auth::guard('misadmin')->user()->id ?? '')}}</span>, as the certifying body, has identified <span style="color: black; font-weight: bold;">{{ ($operator->id ?? '')}}</span> to be
                        in violation of organic integrity standards and non-compliance with regulations, significantly
                        impacting organic integrity. Pursuant to the norms and guidelines outlined under the National
                        Programme for Organic Production (NPOP), appropriate disciplinary action has been imposed on the
                        said operator. This action is undertaken to uphold the sanctity of organic practices and
                        maintain the credibility of organic certification processes.
                    </label>
                </div>
                <div class="text-center">
                    <button type="button" class="btn btn-primary suspendBtn" id='suspendBtn'>Submit</button>
                </div>
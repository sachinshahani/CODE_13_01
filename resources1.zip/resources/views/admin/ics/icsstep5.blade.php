@extends('admin.layouts.app')
@section('content')
    <style>
        .wrapper {
            max-width: 1240px;
            margin: 0 auto;
        }

        .white-bg {
            background-color: white;
            /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
            border-bottom: 5px solid #ff9800;
            margin-bottom: 15px;
        }

        .auth-one-bg .slide .carousel-indicators {
            bottom: 25px;
        }

        .auth-page-wrapper .auth-page-content {
            padding-bottom: 0px !important;
        }

        .auth-page-content .card {
            margin-bottom: 0rem;
        }

        .data-tabs .wrapper .nav-tabs button {
            font-size: 17px;
            color: black;
        }

        .data-tabs .wrapper .nav-tabs .active {
            background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
            */ color: white;
            background: orange;
            border-radius: 0px;
        }

        .carousel-caption.d-none.d-md-block {
            background-color: #000000bf;
            left: 0;
            width: 100%;
            bottom: 0;
        }

        .carousel-indicators {
            display: none;
        }

        .custom-banner-caption {
            color: white !important;
        }

        .announcement-heading {
            font-size: 1.2em;
            font-weight: 600;
        }

        .data-tabs .tab-pane ul li {
            font-size: 1em;
            padding: 5px 0;
        }

        .main-logo {
            padding: 10px;
        }

        .data-tabs .nav-item .nav-link {
            background-image: none;
        }

        /* .right-sec{
                        box-shadow: 5px 10px 18px #888888;
                    } */
        .navbar-brand-box {
            background: #fff;
        }

        .btn-danger {
            background-color: #40895a;
            border: 1px solid #40895a;
        }

        [data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
            color: white !important;
        }

        .header-buttons .btn-primary {
            margin-right: 10px;
            padding: 6px 15px;
            font-weight: 600;
            background-color: #207005;
            border: none;
            box-shadow: 0px 2px 7px #888888;
        }

        .header-buttons .btn-secondary {
            margin-right: 10px;
            padding: 6px 15px;
            font-weight: 600;
            background-color: #72a055;
            border: none;
            box-shadow: 0px 2px 7px #888888;
        }

        .right-sec {
            border-left: 5px solid #ede7e7;
        }

        .tabdiv {
            background: white;
            padding: 20px;
            margin-top: 10px;
            border: 10px solid #dfdbd5;
        }

        .nav-tabs {
            border-bottom: 0px;
        }

        div#myTabContent {
            border: 1px solid #cccccc;
        }

        .frontfooter footer {
            padding: 20px calc(1.5rem / 2);
            position: static;
            color: #000;
            height: 60px;
            background-color: #f9f9f9;
            margin-top: 30px;
            border-top: 1px solid #e1dfdf;
        }

        span.logo-sm img {
            width: 69px;
        }

        .seperatesec {
            margin-top: 20px;
        }

        .simplebar-content li.nav-item:hover {
            background: #4caf50;
        }

        .sectitle {
            font-size: 14px;
        }

        .required {
            color: red;
        }

        .customtextarea {
            height: 120px;
        }

        ul.boxsection {
            margin: 0;
            padding: 0;
        }

        ul.boxsection li {
            list-style-type: none;
            padding: 7px 0;
            border-bottom: 1px solid #efeded;
        }

        .boxcard .col:nth-child(1) {
            background: #effcfb;
        }

        .boxcard .col:nth-child(2) {
            background: #fdfdfd;
        }

        .boxcard .col:nth-child(3) {
            background: #effcfb;
        }

        .boxcard .col:nth-child(4) {
            background: #fdfdfd;
        }

        .boxcard .col:nth-child(5) {
            background: #effcfb;
        }

        /* --registration-form css  */
        .custom-tab-content {
            padding-top: 0 !important;
            padding-bottom: 0px !important;
        }

        .custom-tab-nav {
            background: white;

        }

        .custom-tab-nav .nav-link {
            border-radius: 0 !important;
            border-bottom: 1px solid #e9ebec;
            border-right: 1px solid #e9ebec;
            font-size: 14px;
            padding: 10px;
        }

        .custom-tab-nav .nav-link.active,
        .custom-tab-nav .show>.nav-link {
            color: rgb(255, 255, 255) !important;
            background-color: #2c8c6d;
            border-bottom: #2c8c6d !important;
            /* border-bottom: #207005 !important; */
            position: relative;
        }

        .custom-tab-nav .nav-link:hover,
        .custom-tab-nav .nav-link:focus {
            border-bottom: 1px solid #207005;
            border-radius: 0;
            font-size: 14px;
            transition: background-color 0.20s linear;
        }

        .custom-tab-nav .nav-link.active:after {
            content: "";
            position: absolute;
            bottom: -16px;
            left: 50%;
            border: 8px solid transparent;
            border-top-color: #2c8c6d;
            z-index: 999;
        }

        .reg-form-btns {
            margin-bottom: 15px;
        }

        .reg-form-btns .btn-secondary {
            color: #fff;
            background-color: #405189;
            border-color: #405189;
        }

        .btn-soft-success:active,
        .btn-soft-success:focus,
        .btn-soft-success:hover {
            border: none;
        }

        .custom-tab-nav ul {
            padding: 0px;
            margin: 0px;
        }

        .custom-tab-nav ul li {
            padding: 0px;
            margin: 0px;
            display: inline-block;
            list-style: none;
        }
        .has-error {
            border: 1px solid red;
        }

        .errormsg {
            color: red;
            font-size: 14px !important;
        }
    </style>

    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">उत्पादक समूह प्रोफ़ाइल/Grower Group Profile</h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Grower Group Profile</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <form method="post" id="warehousefrm" action="{{ route('superadmin.icsuser.step5post', $userdetails->id) }}"
                enctype="multipart/form-data">
                @csrf
                <input type="hidden" name="roleid" value="{{ $userdetails->ref_operator_type_id??'' }}">
                <nav>
                    <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">
                        <a class="nav-link" href="{{ route('superadmin.icsuser.step1', $userdetails->id) }}">General
                            Information</a>
                        <a class="nav-link" href="{{ route('superadmin.icsuser.step2', $userdetails->id) }}">Self/Service Provider
                            Details</a>
                        <a class="nav-link" href="{{ route('superadmin.icsuser.step4', $userdetails->id) }}">Internal Inspector
                            Details</a>
                        <a class="nav-link active" id="step4-tab" data-bs-toggle="tab"
                            href="{{ route('superadmin.icsuser.step5', $userdetails->id) }}">Warehouse/Godown</a>
                        <a class="nav-link" href="{{ route('superadmin.icsuser.step6', $userdetails->id) }}">Grower Group Official Details</a>
                        <a class="nav-link" href="{{ route('superadmin.icsuser.step3', $userdetails->id) }}">Farmer Details</a>
                    </div>
                </nav>
                <div class="tab-content py-4 custom-tab-content">
                    <div class="tab-pane fade show active" id="step4">
                        <div class="card">
                            <div class="card-header align-items-center d-flex">
                                <h4 class="card-title mb-0 flex-grow-1"> Warehouse/Godown
                                </h4>
                                <div class="flex-shrink-0">
                                    @if (session('error'))
                                        <div class="alert alert-danger">
                                            {{ session('error') }}
                                        </div>
                                    @endif
                                    @if (session('success'))
                                        <div class="alert alert-success">
                                            {{ session('success') }}
                                        </div>
                                    @endif
                                    @if ($errors)
                                        @foreach ($errors->all() as $error)
                                            <div class="alert alert-danger">{{ $error }}</div>
                                        @endforeach
                                    @endif
                                </div>
                            </div>
                            <div class="card-body">

                                <div class="live-preview">
                                    <div class="row seperatesec white-inner">
                                        <input type="hidden" name="at_user_id" value="{{ $warehs->at_user_id ?? '' }}">
                                        <div class="col-xxl-4 col-md-3 ">
                                            <label for="basiInput" class="form-label">वेयरहाउस/गोदाम द्वारा संचालित/Warehouse/Godown Operated by<span
                                                    class="required">*</span></label>
                                            <select class="form-select" name="warehouse_available" required>
                                                <option value="">-select-</option>
                                                <option value="Grower Group" @if (isset($warehs) && $warehs->warehouse_available == 'Grower Group') selected @endif>Grower Group
                                                </option>
                                                <!-- <option value="mandator" @if (isset($warehs) && $warehs->warehouse_available == 'mandator') selected @endif>
                                                    Mandator</option> -->
                                                <!-- <option value="both" @if (isset($warehs) && $warehs->warehouse_available == 'both') selected @endif>
                                                    Both</option>
                                                <option value="none" @if (isset($warehs) && $warehs->warehouse_available == 'none') selected @endif>
                                                    None</option> -->
                                            </select>
                                        </div>
                                        <div class="col-xxl-4 col-md-3 ">
                                            <label for="basiInput" class="form-label">वेयरहाउस/गोदाम का प्रकार/Warehouse/Godown Type<span
                                                    class="required">*</span></label>
                                            <select class="form-select whType" name="warehouse_type" required onChange="getname(this.value)">
                                                <option value="">-select-</option>
                                                <option value="owned" @if (isset($warehs) && $warehs->warehouse_type == 'owned') selected @endif>Owned
                                                </option>
                                                <option value="lease" @if (isset($warehs) && $warehs->warehouse_type == 'lease') selected @endif>
                                                    Lease</option>
                                            </select>
                                        </div>

                                        <!-- <div class="col-xxl-3 col-md-3  ">
                                            <label for="basiInput" class="form-label">Number of Warehouse/Godown/वेयरहाउस/गोदाम की संख्या <span
                                                    class="required">*</span></label>
                                            <input type="number" class="form-control" id="placeholderInput"
                                                placeholder="Number Warehouse" required name="no_warehouse"
                                                value="{{ isset($warehs) ? $warehs->number_of_warehouse : '' }}" />
                                        </div> -->

                                        <div class="col-xxl-4 col-md-3   ">
                                            <div>
                                                <label for="labelInput" class="form-label">वेयरहाउस/गोदाम लाइसेंस नंबर/Warehouse/Godown Licence Number</label>
                                                <input type="text" class="form-control" id="placeholderInput"
                                                    placeholder="Licence Number" name="warehouse_lic_no"
                                                    value="{{ isset($warehs) ? $warehs->licence_number : '' }}" />
                                            </div>
                                        </div>
                                        <div class="col-xxl-4 col-md-3  gy-3">
                                            <div>
                                                <label for="labelInput" class="form-label">क्षेत्रफल(वर्ग/मीटर)/Area(Sq/Mtr)/<span
                                                        class="required">*</span></label>
                                                <input type="text" class="form-control numbersonly" id="placeholderInput"
                                                    placeholder="Area" required name="area_warehouse"
                                                    value="{{ isset($warehs) ? $warehs->warehouse_area : '' }}" />
                                            </div>
                                        </div>

                                        <div class="col-xxl-4 col-md-3 gy-3">
                                            <div>
                                                <label for="labelInput" class="form-label"> क्षमता(मीट्रिक/टन)/Capacity (MT)<span
                                                        class="required">*</span></label>
                                                <input type="text" class="form-control numbersonly" id="placeholderInput"
                                                    placeholder="Capacity" required name="capacity"
                                                    value="{{ isset($warehs) ? $warehs->capacity : '' }}" />
                                            </div>
                                        </div>

                                        <div class="col-xxl-4 col-md-3 gy-3 ">
                                            <div>
                                                <label for="basiInput" class="form-label">वेयरहाउस/गोदाम का प्रमाणिक पता/Address Proof of Warehouse/Godown 
                                                </label>
                                                  <select class="form-select ownedAndlease" name="address_proof_of_office">
                                                    <option value="">-select-</option>
                                                    <option value="owned" @if (isset($warehs) && $warehs->warehouse_type == 'owned') selected @endif>Electricity Bill</option>
                                                    <option value="lease" @if (isset($warehs) && $warehs->warehouse_type == 'lease') selected @endif>Rent Agreement</option>
                                                </select>

                                            </div>
                                        </div>

                                        <div class="col-xxl-6 col-md-3 gy-3 mt-4">
                                            <div>
                                                <label class="form-label">वेयरहाउस/गोदाम कार्यालय दस्तावेज़ का प्रमाण/Warehouse/Godown Proof Of Office Doc<span
                                                        class="required">*</span></label>
                                                <input type="file" class="form-control proof_of_office_doc"
                                                    name="address_proof_of_office_doc" id="address_proof_of_office_doc"
                                                    {{ $warehs->address_proof_of_office_doc ?? 'required' }} accept="image/png, application/pdf, image/jpeg">
                                                    <span class="form-text">Supported formats:JPG, PNG, PDF. Upto 2MB</span>
                                                @if (!empty($warehs->address_proof_of_office_doc))
                                                    <input type="hidden" name="address_proof_of_office_doc_edit"
                                                        value="{{ $warehs->address_proof_of_office_doc ?? '' }}">
                                                    <a target="_BLANK"
                                                        href="{{ asset('public/warehouse/address_proof_of_office_doc/' . $warehs->address_proof_of_office_doc) }}"
                                                        class="text-decoration-underline">See Doc</a>
                                                @endif
                                            </div>
                                        </div>

                                        <div class="col-xxl-6 col-md-3 gy-3 mt-4">
                                            <div>
                                                <label class="form-label">वेयरहाउस/गोदाम की फोटो/Photo of Warehouse/Godown<span
                                                        class="required">*</span></label>
                                                <input type="file" class="form-control proof_of_office_doc" name="office_building_photo"
                                                    id="office_building_photo"
                                                    {{ $warehs->office_building_photo ?? 'required' }} accept="image/png, application/pdf, image/jpeg">
                                                    <span class="form-text">Supported formats:JPG, PNG, PDF. Upto 1MB</span>
                                                @if (!empty($warehs->office_building_photo))
                                                    <input type="hidden" name="office_building_photo_edit"
                                                        value="{{ $warehs->office_building_photo ?? '' }}">
                                                    <a target="_BLANK"
                                                        href="{{ asset('public/warehouse/office_building_photo/' . $warehs->office_building_photo) }}"
                                                        class="text-decoration-underline">See Doc</a>
                                                @endif
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row white-inner">
                                        <div class="col-xxl-12 col-md-12 ">
                                            <label for="labelInput" class="form-label blue-ht">गोदाम/गोदाम का पता/Address of Warehouse/Godown</label>

                                        </div>

                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div class="row">
                                                <div class="col-xx-12 col-md-12">
                                                    <label for="labelInput" class="form-label">पता/Address<span
                                                            class="required">*</span></label>
                                                    <input type="address" placeholder="Address"
                                                        class="form-control customtextarea" required name="address"
                                                        value="{{ isset($warehs) ? $warehs->address : '' }}">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xxl-9 col-md-9">
                                            <div class="row  ">
                                                <div class="col-xxl-4 col-md-4 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">राज्य/State<span
                                                                class="required">*</span></label>
                                                        <select class="form-select state" name="state" required>
                                                            <option value="">Select State</option>
                                                            @forelse(CBstateAssign($cbstate->id) as $state)
                                                                <option value="{{ $state->ref_state_id }}"
                                                                    @if (isset($warehs) && $warehs->ref_state_id == $state->ref_state_id) selected @endif>
                                                                    {{ $state->state_name }}</option>
                                                                    @empty
                                                                    @endforelse
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-xxl-4 col-md-4 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">जिलाDistrict<span
                                                                class="required">*</span></label>
                                                        <select class="form-select district" name="district" required>
                                                            <option value="">Select District</option>
                                                            @forelse($districts as $district)
                                                                <option value="{{ $district->id }}"
                                                                    @if (isset($warehs) && $warehs->ref_district_id == $district->id) selected @endif>
                                                                    {{ $district->district_name }}</option>
                                                            @empty
                                                            @endforelse
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-xxl-4 col-md-4 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">तालुका/मंडल /Taluka/Mandal
                                                            <span class="required">*</span></label>
                                                        <select class="form-select block_tehsil" name="taluka" required>
                                                            <option value="">Select Taluka/Mandal</option>
                                                            @forelse($regions as $region)
                                                                <option value="{{ $region->id }}"
                                                                    @if (isset($warehs) && $warehs->ref_block_tehsil_id == $region->id) selected @endif>
                                                                    {{ $region->block_tehsil_name }}</option>
                                                            @empty
                                                            @endforelse
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-xxl-6 col-md-6 gy-3">
                                                    <div>
                                                        <label class="form-label">गाँव/Village</label>
                                                        <select class="form-select village" name="village" required>
                                                            <option value="">Select Village</option>
                                                            @forelse($villages as $village)
                                                                <option value="{{ $village->id }}"
                                                                    @if (isset($warehs) && $warehs->ref_village_id == $village->id) selected @endif>
                                                                    {{ $village->village_name }}</option>
                                                            @empty
                                                            @endforelse
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-xxl-6 col-md-6 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">पिन कोड/Pin Code<span
                                                                class="required">*</span></label>
                                                        <input type="text" class="form-control numbersonly"
                                                            maxlength="6" id="placeholderInput" placeholder="Pin Code"
                                                            name="pincode" required
                                                            value="{{ isset($warehs) ? $warehs->pin_code : '' }}"
                                                            maxlength="6" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
{{--
                                    <br>
                                    <h2 class="card-title mb-0 flex-grow-1 blue-ht">
                                        Details Of Warehouse Manager/गोदाम प्रबंधक का विवरण
                                    </h2> --}}
                                    <div class="row seperatesec white-inner p-2 " id="wmmanager">



                                        @php $i=0; @endphp
                                        @forelse($wmanager as $wm)
                                            <div class='row white-inner p-2' id="maindiv_{{ $wm->id }}" >
                                                @if($i==0)
                                                <label for="labelInput" class="form-label blue-ht">गोदाम/गोदाम प्रबंधक का विवरण/Details Of Warehouse/Godown Manager</label>
                                                <div class="row">
                                                    <div class="col-xxl-3 col-md-4  gy-3"></div>
                                                    <div class="col-xxl-3 col-md-4  gy-3"></div>
                                                    <div class="col-xxl-3 col-md-3  gy-3"></div>
                                                    <div class="col-xxl-3 col-md-1">
                                                        <i data-type="wm" class="mdi mdi-plus btn btn-soft-success rowAdder4"
                                                            data-toggle="tooltip" title="Add Row" style="float:right"></i>
                                                    </div>
                                                </div>
                                               @endif

                                                <div class="col-xxl-4 col-md-2  gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">
                                                            पहला नाम/First Name <span class="required">*</span> </label>
                                                        <input type="hidden" name="wm_id[]"
                                                            value="{{ $wm->id }}" />
                                                        <input type="text" class="form-control" id="placeholderInput"
                                                            placeholder="First Name" name="wm_first_name[]"
                                                            value="{{ $wm->first_name }}" required />
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-2  gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">मध्य नाम/Middle Name</label>

                                                        <input type="text" class="form-control" id="placeholderInput"
                                                            placeholder="Middle Name" name="wm_middle_name[]"
                                                            value="{{ $wm->middle_name }}" />
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-2  gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">अंतिम नाम/Last Name<span
                                                            class="required">*</span> </label>

                                                        <input type="text" class="form-control" id="placeholderInput"
                                                            placeholder="Last Name" name="wm_last_name[]"
                                                            value="{{ $wm->last_name }}" required />
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-2  gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">आधार/Aadhaar No.<span class="required">*</span> </label>
                                                        @php
                                                            // Decrypt the Aadhar number if it's encrypted
                                                            $decryptedAadhar = \Crypt::decrypt($wm->aadhar_card_number);
                                                    
                                                            // Mask the Aadhar number
                                                            $maskedAadhar = '******' . substr($decryptedAadhar, -4);
                                                        @endphp
                                                        
                                                        @if(!empty($wm->aadhar_card_number) )
                                                        <!-- only get aadhaar value  -->
                                                        <input type="hidden" class="form-control numbersonly" maxlength="10" id="placeholderInput" 
                                                         placeholder="Aadhar Number" name="wm_aadhar[]" value="{{ Crypt::decrypt($wm->aadhar_card_number) ?? '' }}" required />
                                                         <!-- only display aadhaar  -->
                                                         <input type="text" class="form-control numbersonly"  maxlength="10" id="placeholderInput" 
                                                         placeholder="Aadhar Number" value="{{ $maskedAadhar }}" required readonly/>
                                                        @else
                                                        <!-- aagr aadhaar pheli baar fill karega  tab chale ga  -->
                                                        <input type="text" class="form-control numbersonly"  name="wm_aadhar[]"  id="placeholderInput" 
                                                        placeholder="Aadhar Number" value="{{ $maskedAadhar }}" required onblur="checkAadhaarNo(this.value, this)"/>
                                                        @endif       
                                                    
                                                    </div>
                                                    
                                                </div>
                                                <div class="col-xxl-3 col-md-3  gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">संपर्क नंबर/Contact No.<span
                                                            class="required">*</span></label>
                                                        <input type="text" class="form-control numbersonly"
                                                            maxlength="10" id="mobile"  onblur="phonenumber(this)"
                                                            placeholder="Contact Number" name="wm_mobile_no[]"
                                                            value="{{ $wm->contact_number }}" required/>
                                                    </div>
                                                </div>
                                                <div class="col-xxl-1 col-md-1" style="margin-top: 4.5% !important">
                                                    <i data-type="wm" data-id="{{ $wm->id }}"
                                                        class="mdi mdi-delete btn btn-soft-danger dngr"
                                                        data-toggle="tooltip" title="Add Row"></i>
                                                </div>

                                            </div>

                                            @php $i++; @endphp

                                        @empty
                                            <div class="row seperatesec p-2 white-inner" >
                                                <label for="labelInput" class="form-label blue-ht">Details Of Warehouse/Godown Manager</label>

                                                <div class="col-xxl-4 col-md-2  gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">First Name <span
                                                            class="required">*</span> </label>

                                                        <input type="text" class="form-control" id="placeholderInput"
                                                            placeholder="First Name" name="wm_first_name[]" value="" required/>
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-2  gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">Middle Name </label>

                                                        <input type="text" class="form-control" id="placeholderInput"
                                                            placeholder="Middle Name" name="wm_middle_name[]" value="" />
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-2  gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">Last Name<span
                                                            class="required">*</span> </label>

                                                        <input type="text" class="form-control" id="placeholderInput"
                                                            placeholder="Last Name" name="wm_last_name[]" value="" required/>
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-2  gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">Aadhar Number <span
                                                            class="required">*</span></label>
                                                        <input type="text" class="form-control numbersonly"
                                                            maxlength="12" id="placeholderInput" placeholder="Aadhar Number"
                                                            name="wm_aadhar[]" required onblur="checkAadhaarNo(this.value, this)"/>
                                                    </div>
                                                </div>
                                                <div class="col-xxl-3 col-md-3  gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">Contact Number <span
                                                            class="required">*</span></label>
                                                        <input type="text" class="form-control numbersonly" maxlength="10" id="mobile"  onblur="phonenumber(this)" placeholder="Contact Number" name="wm_mobile_no[]" required/>
                                                    </div>
                                                </div>
                                                <div class="col-xxl-1 col-md-1" style="margin-top: 4.5% !important">
                                                    <i data-type="wm" class="mdi mdi-plus btn btn-soft-success rowAdder4" data-toggle="tooltip" title="Add Row"></i>

                                                </div>
                                            </div>
                                        @endforelse
                                        {{-- <div class="row">
                                            <div class="col-xxl-3 col-md-4  gy-3"></div>
                                            <div class="col-xxl-3 col-md-4  gy-3"></div>
                                            <div class="col-xxl-3 col-md-3  gy-3"></div>
                                            <div class="col-xxl-3 col-md-1">
                                                <i data-type="wm" class="mdi mdi-plus btn btn-soft-success rowAdder4"
                                                    data-toggle="tooltip" title="Add Row"></i>
                                            </div>
                                        </div> --}}
                                    </div>
                                    <br>
                                    <div class="row">
                                        <div class="col-lg-12 gy-4">
                                            <div class="hstack gap-2">

                                                <a href="{{ route('superadmin.icsuser.step4', $userdetails->id) }}"
                                                    class="btn btn-soft-success">Back</a>
                                                <button type="submit" id="submitbtn"
                                                    class="btn btn-primary submit-button">Save & Next</button>
                                                {{-- <a
                                                    href="{{ route('superadmin.icsuser.step6', $userdetails->id) }}"class="btn btn-soft-success">Next</a> --}}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection
@push('script')
    <script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
    <script>
        
function getname(id) {
    $('.ownedAndlease option').prop('disabled', true);
    if (id === 'owned') {
        $('.ownedAndlease option[value="owned"]').prop('disabled', false);
    } else if (id === 'lease') {
        $('.ownedAndlease option[value="lease"]').prop('disabled', false);
    }
}
$(document).ready(function() {
    getname($('.ownedAndlease').val());
    $('.ownedAndlease').change(function() {
        var selectedValue = $(this).val();
        getname(selectedValue);
    });
});




        $('.own, .lease').change(function() {
            var th = $(this);
            var wh_type = this.value;
            $("input[name='address_proof_of_office']").val(wh_type);

        });

       function phonenumber(inputtxt) {
                        var phoneno = /^\d{10}$/;
                        if (inputtxt.value.match(phoneno)) {
                            return true;
                        } else {
                            Swal.fire('', 'Please enter a valid mobile number.', 'warning');
                            $(inputtxt).val('');
                            return false;
                        }
                    }
        $(document).on('click', '#submitbtn', function() {

            if (checkValidation("warehousefrm")) {
                $('#warehousefrm').submit();
                return true;
            } else {
                return false;
            }
        });
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });


        // Dropzone has been added as a global variable.

        $('.dropzone').each(function() {
            var options = $(this).attr('id');
            $(this).dropzone({
                url: "{{ route('storeMedia') }}",
                paramName: "file",
                maxFilesize: 2,
                maxFiles: 1,
                acceptedFiles: ".jpeg,.jpg,.png,.mp4,.webm,.html5",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                init: function() {
                    var drop = this; // Closure
                    this.on('error', function(file, errorMessage) {
                        if (errorMessage.indexOf('Error 404') !== -1) {
                            var errorDisplay = document.querySelectorAll(
                                '[data-dz-errormessage]');
                            errorDisplay[errorDisplay.length - 1].innerHTML =
                                'Error 404: The upload page was not found on the server';
                        }
                        if (errorMessage.indexOf('File is too big') !== -1) {
                            alert('Unable to upload image size is greated than 2 MB');
                            // i remove current file
                            drop.removeFile(file);
                        }
                    });
                    this.on("maxfilesexceeded", function(file) {
                            this.removeAllFiles();
                            this.addFile(file);
                        }),
                        this.on("success", function(file, response) {
                            console.log(response);
                            var hiddenImage = $('<input type="hidden" name="_hidden_' + options +
                                '" value="' +
                                response.name + '"/>');
                            $('#hidden_' + options).html(hiddenImage);
                        })
                }
            });
        });


        $(".rowAdder4").click(function() {
            var tp = $(this).attr("data-type");
            //console.log(tp );
            newRowAdd =
                '<div class="row white-inner spc4"><div class="col-xxl-4 col-md-2 gy-3"><div><label for="labelInput" class="form-label">First Name </label> <span class="required">*</span><input type="text" class="form-control" id="placeholderInput" placeholder="First Name" name="wm_first_name[]" required></div></div><div class="col-xxl-4 col-md-2  gy-3"><div><label for="labelInput" class="form-label">Middle Name </label><input type="text" class="form-control" id="placeholderInput" placeholder="Middle Name" name="wm_middle_name[]" value="" /></div></div><div class="col-xxl-4 col-md-2  gy-3"><div><label for="labelInput" class="form-label">Last Name </label><span class="required">*</span><input type="text" class="form-control" id="placeholderInput" placeholder="Last Name" name="wm_last_name[]" value="" required/></div></div><div class="col-xxl-4 col-md-2 gy-3"><div><label for="labelInput" class="form-label">Aadhar Number</label><span class="required">*</span><input type="text" class="form-control numbersonly" maxlength="12" id="placeholderInput" placeholder="Aadhar Number" onblure="checkAadhaarNo(val, classname)" onblur="checkAadhaarNo(this.value, this)" name="wm_aadhar[]" required></div></div><div class="col-xxl-3 col-md-3 gy-3"><div><label for="labelInput" class="form-label">Contact Number</label><span class="required">*</span><input type="text" class="form-control numbersonly" maxlength="10"  id="mobile"  onblur="phonenumber(this)" placeholder="Contact Number" name="wm_mobile_no[]" required></div></div><div class="col-xxl-1 col-md-1" style="margin-top:4.5%!important"><i class="mdi mdi-delete btn btn-soft-danger remove-corp4" data-toggle="tooltip" title="delete Row"></i></div></div>';
            $('#' + tp + 'manager').append(newRowAdd);
        });



        $(document).on('click', '.dngr', function() {
            var id = $(this).attr('data-id');

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.value) {
                    $.ajax({
                        url: "{{ route('deletewarehousebyid') }}",
                        method: "POST",
                        dataType: 'json',
                        data: {
                            'id': id,
                        },
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function(result) {
                            $("#maindiv_" + id).remove();

                        }

                    });
                }
            });
        });
        $(document).ready(function() {
            $("body").on("click", ".remove-corp4", function() {
                $(this).parents(".spc4").remove();
            });
        });




            
$('.proof_of_office_doc').on('change', function() {
    var $this = $(this);
    var file = $this[0].files[0];
    var fileType = file.type;
    var fileSize = file.size;
    var allowedTypes = ['application/pdf', 'image/jpeg', 'image/png'];
    if (!allowedTypes.includes(fileType)) {
        Swal.fire({
            icon: 'error',
            title: 'Invalid File Type',
            text: 'Please upload PDF, JPG, or PNG only.',
        });
        $this.val("");
        return false;
    }
    if (fileSize > 1048576) { // 1 MB in bytes
        Swal.fire({
            icon: 'error',
            title: 'File Size Too Large',
            text: 'Please upload files of size 1 MB or less only.',
        });
        $this.val("");
        return false;
    }
});




function checkAadhaarNo(val, inputElement) {
    var numericValue = val.replace(/[^0-9]/g, '');
    if (numericValue.length !== 12) {
        Swal.fire({
            icon: 'info',
            title: 'Aadhaar',
            text: 'Please enter a 12-digit Aadhaar number.',
        });
        inputElement.value = ''; 
    } else {
        inputElement.value = numericValue;
    }
}

    </script>
@endpush

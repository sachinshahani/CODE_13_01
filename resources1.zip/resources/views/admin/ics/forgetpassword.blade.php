<!doctype html>
<html lang="en" data-layout="vertical" data-topbar="light" data-sidebar="dark" data-sidebar-size="lg"
    data-sidebar-image="none">

<head>
    <meta charset="utf-8" />
    <title> APEDA </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="{{ asset('public/assets/images/favicon.png') }}">
    <!-- Layout config Js -->
    <script src="{{ asset('public/assets/js/layout.js') }}"></script>
    <!-- Bootstrap Css -->
    <link href="{{ asset('public/assets/css/bootstrap.min.css') }}" rel="stylesheet" />
    <!-- Icons Css -->
    <link href="{{ asset('public/assets/css/icons.min.css') }}" rel="stylesheet" />
    <!-- App Css-->
    <link href="{{ asset('public/assets/css/app.min.css') }}" rel="stylesheet" />
    <!-- custom Css-->
    <link href="{{ asset('public/assets/css/custom.min.css') }}" rel="stylesheet" />
    <link href="{{ asset('public/assets/css/font-awesome.min.css') }}" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans&display=swap" rel="stylesheet">
    <style>
        .right-sec .reload i.ri-refresh-line {
            font-size: 18px;
        }

        .right-sec .captchareload.btn-refresh {
            margin-top: 30px;
        }


        .main-logo {
            display: flex;
        }

        .logo-des {
            margin: auto;
            padding: 0 0 0 5px;
            text-transform: capitalize;
        }

        .logo-des h1 {
            display: flex;
            flex-direction: column;
            font-size: 20px;
            margin: 0;
            border-left: 1px solid #7272727a;
            padding-left: 15px;
            color: #02600c;
        }

        .header-buttons img {
            max-width: 52%;
            float: left;
        }

        .header-buttons {
            display: flex;
            justify-content: end;
        }

        .auth-one-bg .carousel-item img {
            max-height: 522px;
            min-height: 522px;
        }
    </style>
</head>

<body>
    <!-- auth-page wrapper -->
    <div class="auth-page-wrapper auth-bg-cover d-flex justify-content-center align-items-center">
        <div class="bg-overlay"></div>
        <!-- auth-page content -->
        <div class="auth-page-content overflow-hidden">
            <div class="wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="white-bg d-flex justify-content-between align-items-center pe-lg-5">
                            <div class="main-logo">
                                <a href="index-2.html" class="d-block">
                                    <img class="img-fluid" src="{{ asset('public/assets/images/APEDA-Logo.png') }}"
                                        alt="">
                                </a>
                                <div class="logo-des">
                                    <h1>A Traceability system <span> for organic products</span></h1>
                                </div>
                            </div>

                            <div class="header-buttons">
                                <!-- <button type="button" class="btn btn-primary btn-sm">Log In</button> -->
                                <img src="{{ asset('public/assets/images/india-org.jpg') }}" alt="">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card overflow-hidden">
                            <div class="row g-0">
                                <div class="col-12 col-sm-12 col-md-9 col-lg-9">
                                    <div class="auth-one-bg h-100">
                                        <div class="bg-overlay"></div>
                                        <div class="position-relative h-100 d-flex flex-column">
                                            <!-- <div class="mt-auto"> -->
                                            <!-- <div class="mb-3">
                                       <i class="ri-double-quotes-l display-4 text-success"></i>
                                       </div> -->
                                            <!-- --- banner image  -->
                                            <div id="carouselExampleCaptions" class="carousel slide"
                                                data-bs-ride="carousel">
                                                <div class="carousel-indicators">
                                                    @for ($i = 0; $i < 30; $i++)
                                                        <button type="button" data-bs-target="#carouselExampleCaptions"
                                                            data-bs-slide-to="{{ $i }}" class="active"
                                                            aria-current="true" aria-label="Slide 1"></button>
                                                    @endfor


                                                </div>
                                                <div class="carousel-inner">
                                                    <div class="carousel-item active">
                                                        <img src="{{ asset('public/assets/images/agril_crop.jpg') }}"
                                                            class="d-block w-100" alt="...">
                                                        <div
                                                            class="carousel-caption d-none d-md-block custom-banner-caption">
                                                            <p>ALWAYS EAT GOOD FOOD</p>
                                                        </div>
                                                    </div>
                                                    <div class="carousel-item">
                                                        <img src="{{ asset('public/assets/images/agril_farm.jpg') }}"
                                                            class="d-block w-100" alt="...">
                                                        <div class="carousel-caption d-none d-md-block">
                                                            <p>Some representative placeholder content for the second
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="carousel-item">
                                                        <img src="{{ asset('public/assets/images/cereals.jpg') }}"
                                                            class="d-block w-100" alt="...">
                                                        <div class="carousel-caption d-none d-md-block">
                                                            <p>Some representative placeholder content for the third
                                                                slide</p>
                                                        </div>
                                                    </div>
                                                    <div class="carousel-item">
                                                        <img src="{{ asset('public/assets/images/coffee_farm.jpg') }}"
                                                            class="d-block w-100" alt="...">
                                                        <div class="carousel-caption d-none d-md-block">
                                                            <p>Some representative placeholder content for the third
                                                                slide.
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="carousel-item">
                                                        <img src="{{ asset('public/assets/images/coffee.jpg') }}"
                                                            class="d-block w-100" alt="...">
                                                        <div class="carousel-caption d-none d-md-block">
                                                            <p>Some representative placeholder content for the third
                                                                slide.
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="carousel-item">
                                                        <img src="{{ asset('public/assets/images/dry_fruits_2.jpg') }}"
                                                            class="d-block w-100" alt="...">
                                                        <div class="carousel-caption d-none d-md-block">
                                                            <p>Some representative placeholder content for the third
                                                                slide.
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="carousel-item">
                                                        <img src="{{ asset('public/assets/images/dryfruits.jpg') }}"
                                                            class="d-block w-100" alt="...">
                                                        <div class="carousel-caption d-none d-md-block">
                                                            <p>Some representative placeholder content for the third
                                                                slide.
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="carousel-item">
                                                        <img src="{{ asset('public/assets/images/image_1.jpeg') }}"
                                                            class="d-block w-100" alt="...">
                                                        <div class="carousel-caption d-none d-md-block">
                                                            <p>Some representative placeholder content for the third
                                                                slide.
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="carousel-item">
                                                        <img src="{{ asset('public/assets/images/mango_farm.jpg') }}"
                                                            class="d-block w-100" alt="...">
                                                        <div class="carousel-caption d-none d-md-block">
                                                            <p>Some representative placeholder content for the third
                                                                slide.
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="carousel-item">
                                                        <img src="{{ asset('public/assets/images/medicinal_plants_products.jpg') }}"
                                                            class="d-block w-100" alt="...">
                                                        <div class="carousel-caption d-none d-md-block">
                                                            <p>Some representative placeholder content for the third
                                                                slide.
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="carousel-item">
                                                        <img src="{{ asset('public/assets/images/millets.jpg') }}"
                                                            class="d-block w-100" alt="...">
                                                        <div class="carousel-caption d-none d-md-block">
                                                            <p>Some representative placeholder content for the third
                                                                slide.
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="carousel-item">
                                                        <img src="{{ asset('public/assets/images/orchads.jpg') }}"
                                                            class="d-block w-100" alt="...">
                                                        <div class="carousel-caption d-none d-md-block">
                                                            <p>Some representative placeholder content for the third
                                                                slide.
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="carousel-item">
                                                        <img src="{{ asset('public/assets/images/pulses_2.jpg') }}"
                                                            class="d-block w-100" alt="...">
                                                        <div class="carousel-caption d-none d-md-block">
                                                            <p>Some representative placeholder content for the third
                                                                slide.
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="carousel-item">
                                                        <img src="{{ asset('public/assets/images/pulses.jpg') }}"
                                                            class="d-block w-100" alt="...">
                                                        <div class="carousel-caption d-none d-md-block">
                                                            <p>Some representative placeholder content for the third
                                                                slide.
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="carousel-item">
                                                        <img src="{{ asset('public/assets/images/soybean.jpg') }}"
                                                            class="d-block w-100" alt="...">
                                                        <div class="carousel-caption d-none d-md-block">
                                                            <p>Some representative placeholder content for the third
                                                                slide.
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="carousel-item">
                                                        <img src="{{ asset('public/assets/images/spices&condiments.jpg') }}"
                                                            class="d-block w-100" alt="...">
                                                        <div class="carousel-caption d-none d-md-block">
                                                            <p>Some representative placeholder content for the third
                                                                slide.
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="carousel-item">
                                                        <img src="{{ asset('public/assets/images/sugar.jpg') }}"
                                                            class="d-block w-100" alt="...">
                                                        <div class="carousel-caption d-none d-md-block">
                                                            <p>Some representative placeholder content for the third
                                                                slide.
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="carousel-item">
                                                        <img src="{{ asset('public/assets/images/tea_farm.jpg') }}"
                                                            class="d-block w-100" alt="...">
                                                        <div class="carousel-caption d-none d-md-block">
                                                            <p>Some representative placeholder content for the third
                                                                slide.
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="carousel-item">
                                                        <img src="{{ asset('public/assets/images/tea.jpg') }}"
                                                            class="d-block w-100" alt="...">
                                                        <div class="carousel-caption d-none d-md-block">
                                                            <p>Some representative placeholder content for the third
                                                                slide.
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="carousel-item">
                                                        <img src="{{ asset('public/assets/images/vege.jpg') }}"
                                                            class="d-block w-100" alt="...">
                                                        <div class="carousel-caption d-none d-md-block">
                                                            <p>Some representative placeholder content for the third
                                                                slide.
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="carousel-item">
                                                        <img src="{{ asset('public/assets/images/vegetables.jpg') }}"
                                                            class="d-block w-100" alt="...">
                                                        <div class="carousel-caption d-none d-md-block">
                                                            <p>Some representative placeholder content for the third
                                                                slide.
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <button class="carousel-control-prev" type="button"
                                                    data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
                                                    <span class="carousel-control-prev-icon"
                                                        aria-hidden="true"></span>
                                                    <span class="visually-hidden">Previous</span>
                                                </button>
                                                <button class="carousel-control-next" type="button"
                                                    data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
                                                    <span class="carousel-control-next-icon"
                                                        aria-hidden="true"></span>
                                                    <span class="visually-hidden">Next</span>
                                                </button>
                                            </div>
                                            <!-- banner IMAGE ENDS HERE   -->
                                        </div>
                                    </div>
                                </div>
                                <!-- end col -->
                                <div class="col-12 col-sm-12 col-md-3 col-lg-3 right-sec">
                                    <div class="p-lg-5 p-4">
                                        <div>
                                            <h5 class="text-primary">Change Password</h5>
                                            <!-- <p class="text-muted">Sign in to continue to APEDA</p> -->
                                        </div>
                                        {{-- @dd(session()->all()); --}}
                                        <div class="mt-4">
                                            <form method="POST" action="{{ route('submitRePassInsp') }}"
                                                class="w-100" id="login_frm" autocomplete="off">
                                                @csrf


                                                {{-- @if($errors->any())
                                                <h4>{{$errors->first()}}</h4>
                                                @endif --}}
                                                <div class="flex-shrink-0">
                                                   @if (session('error'))
                                                       <div class="alert alert-danger">
                                                           {{ session('error') }}
                                                       </div>
                                                   @endif
                                                   @if (session('success'))
                                                       <div class="alert alert-success">
                                                           {{ session('success') }}
                                                       </div>
                                                   @endif
                                                   @if ($errors)
                                                       @foreach ($errors->all() as $error)
                                                           <div class="alert alert-danger">{{ $error }}</div>
                                                       @endforeach
                                                   @endif
                                               </div>

                                                <div class="mb-3">
                                                    <label for="username" class="form-label">Email ID</label>
                                                    <input type="email" name="email"
                                                        placeholder="Enter Your Email" class="form-control "
                                                        value="{{ $updatePassword->email }}" autocomplete="off"
                                                        readonly>

                                                </div>
                                                <div class="mb-3">

                                                    <label for="username" class="form-label">New Password</label>
                                                    <input type="password" name="passwords" id="password"
                                                        placeholder="Enter Your Password" class="form-control "
                                                        value="{{ old('passwords') }}" autocomplete="off" required>

                                                </div>
                                                <div class="mb-3">
                                                    <label for="username" class="form-label">Confirm Password</label>
                                                    <input type="password" name="confirm_password"
                                                        id="confirm_password" placeholder="Confirm Password"
                                                        class="form-control" value="{{ old('confirm_password') }}"
                                                        autocomplete="off" required>

                                                </div>

                                                <div class="mt-4">
                                                    <input type="submit" value="Submit"
                                                        class="btn btn-success w-100" />
                                                </div>
                                            </form>
                                        </div>

                                    </div>
                                </div>
                                <!-- end col -->
                            </div>
                            <!-- end row -->
                        </div>
                        <!-- end card -->
                    </div>
                    <!-- end col -->
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </div>
        <!-- end auth page content -->
    </div>
    <!-- end auth-page-wrapper -->
    <!----------------------------------------------------- DATA TABS- -->

    <!-- footer -->
    <div class="frontfooter">
        <footer class="footer ">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="text-center">
                            <p class="mb-0">
                                &copy;
                                <script>
                                    document.write(new Date().getFullYear())
                                </script> APEDA
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>
    <!-- end Footer -->
    <!------------------------------------------------- DATA TABS ENDS  -->
    <!-- JAVASCRIPT -->
    <script src="{{ asset('public/js/jquery-3.3.1.min.js') }}"></script>
    <script src="{{ asset('public/js/bootstrap-4.2.1.js') }}"></script>
    <script type="text/javascript" src="{{ asset('public/backend/js/sha.js') }}"></script>
    <script src="{{ asset('public/assets/libs/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
    <script src="{{ asset('public/assets/libs/simplebar/simplebar.min.js') }}"></script>
    <script src="{{ asset('public/assets/libs/node-waves/waves.min.js') }}"></script>
    <script src="{{ asset('public/assets/libs/feather-icons/feather.min.js') }}"></script>
    <script src="{{ asset('public/assets/js/pages/plugins/lord-icon-2.1.0.js') }}"></script>
    <script src="{{ asset('public/assets/js/plugins.js') }}"></script>
    <script src="{{ asset('public/assets/js/pages/password-addon.init.js') }}"></script>
    @include('sweetalert::alert')
    <script>
        function handlePreloader() {
            if ($('.preloader').length) {
                $('body').removeClass('active-preloader-ovh');
                $('.preloader').fadeOut();
            }
        }


        jQuery(window).on('load', function() {
            (function($) {
                handlePreloader()

                // thmScrollAnim();

            })(jQuery);
        });

        @php$salt = rand('1000', '9999');
            session(['salt' => $salt]);
        @endphp

        $(document).ready(function() {
            $('.changelogin').click(function() {
                var checkedval = $(this).val();
                if (checkedval == 'Login') {
                    $('#login_frm').show();
                    $('#registerform').hide();
                } else {
                    $('#login_frm').hide();
                    $('#registerform').show();
                }
            });
        });

        $(".btn-refresh").click(function() {
            $.ajax({
                type: 'GET',
                url: '{{ route('refresh_captcha') }}',
                success: function(data) {
                    $(".captcha span").html(data);
                }
            });
        });


      //   
    </script>
</body>

</html>

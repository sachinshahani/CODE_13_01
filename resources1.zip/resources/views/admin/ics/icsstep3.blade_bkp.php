@extends('admin.layouts.app')

@section('content')
<style>
.wrapper {
    max-width: 1240px;
    margin: 0 auto;
}

.white-bg {
    background-color: white;
    /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
    border-bottom: 5px solid #ff9800;
    margin-bottom: 15px;
}

.auth-one-bg .slide .carousel-indicators {
    bottom: 25px;
}

.auth-page-wrapper .auth-page-content {
    padding-bottom: 0px !important;
}

.auth-page-content .card {
    margin-bottom: 0rem;
}

.data-tabs .wrapper .nav-tabs button {
    font-size: 17px;
    color: black;
}

.data-tabs .wrapper .nav-tabs .active {
    background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
    */ color: white;
    background: orange;
    border-radius: 0px;
}

.carousel-caption.d-none.d-md-block {
    background-color: #000000bf;
    left: 0;
    width: 100%;
    bottom: 0;
}

.carousel-indicators {
    display: none;
}

.custom-banner-caption {
    color: white !important;
}

.announcement-heading {
    font-size: 1.2em;
    font-weight: 600;
}

.data-tabs .tab-pane ul li {
    font-size: 1em;
    padding: 5px 0;

}

.main-logo {
    padding: 10px;
}

.data-tabs .nav-item .nav-link {
    background-image: none;
}

/* .right-sec{
    box-shadow: 5px 10px 18px #888888;
} */
.navbar-brand-box {
    background: #fff;
}

.btn-danger {
    background-color: #40895a;
    border: 1px solid #40895a;
}

[data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
    color: white !important;
}

.header-buttons .btn-primary {
    margin-right: 10px;
    padding: 6px 15px;
    font-weight: 600;
    background-color: #207005;
    border: none;
    box-shadow: 0px 2px 7px #888888;
}

.header-buttons .btn-secondary {
    margin-right: 10px;
    padding: 6px 15px;
    font-weight: 600;
    background-color: #72a055;
    border: none;
    box-shadow: 0px 2px 7px #888888;
}


.right-sec {
    border-left: 5px solid #ede7e7;
}

.tabdiv {
    background: white;
    padding: 20px;
    margin-top: 10px;
    border: 10px solid #dfdbd5;
}

.nav-tabs {
    border-bottom: 0px;
}

div#myTabContent {
    border: 1px solid #cccccc;
}

.frontfooter footer {
    padding: 20px calc(1.5rem / 2);
    position: static;
    color: #000;
    height: 60px;
    background-color: #f9f9f9;
    margin-top: 30px;
    border-top: 1px solid #e1dfdf;
}

span.logo-sm img {
    width: 69px;
}

.seperatesec {
    margin-top: 20px;
}

.simplebar-content li.nav-item:hover {
    background: #4caf50;
}

.sectitle {
    font-size: 14px;
}

.required {
    color: red;
}

.customtextarea {
    height: 120px;
}

ul.boxsection {
    margin: 0;
    padding: 0;
}

ul.boxsection li {
    list-style-type: none;
    padding: 7px 0;
    border-bottom: 1px solid #efeded;
}

.boxcard .col:nth-child(1) {
    background: #effcfb;
}

.boxcard .col:nth-child(2) {
    background: #fdfdfd;
}

.boxcard .col:nth-child(3) {
    background: #effcfb;
}

.boxcard .col:nth-child(4) {
    background: #fdfdfd;
}

.boxcard .col:nth-child(5) {
    background: #effcfb;
}

/* --registration-form css  */
.custom-tab-content {
    padding-top: 0 !important;
    padding-bottom: 0px !important;
}

.custom-tab-nav {
    background: white;

}

.custom-tab-nav .nav-link {
    border-radius: 0 !important;
    border-bottom: 1px solid #e9ebec;
    border-right: 1px solid #e9ebec;
    font-size: 14px;
    padding: 10px;
}

.custom-tab-nav .nav-link.active,
.custom-tab-nav .show>.nav-link {
    color: rgb(255, 255, 255) !important;
    background-color: #2c8c6d;
    border-bottom: #2c8c6d !important;
    /* border-bottom: #207005 !important; */
    position: relative;
}

.custom-tab-nav .nav-link:hover,
.custom-tab-nav .nav-link:focus {
    border-bottom: 1px solid #207005;
    border-radius: 0;
    font-size: 14px;
    transition: background-color 0.20s linear;
}

.custom-tab-nav .nav-link.active:after {
    content: "";
    position: absolute;
    bottom: -16px;
    left: 50%;
    border: 8px solid transparent;
    border-top-color: #2c8c6d;
    z-index: 999;
}

.reg-form-btns {
    margin-bottom: 15px;
}

.reg-form-btns .btn-secondary {
    color: #fff;
    background-color: #405189;
    border-color: #405189;
}

.btn-soft-success:active,
.btn-soft-success:focus,
.btn-soft-success:hover {
    border: none;
}

.custom-tab-nav ul {
    padding: 0px;
    margin: 0px;
}

.custom-tab-nav ul li {
    padding: 0px;
    margin: 0px;
    display: inline-block;
    list-style: none;
}
</style>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">ICS Profile</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">ICS Profile</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <form method="post" id="registration" action="{{route('superadmin.icsuser.step3post',$userdetails->id)}}"
            enctype="multipart/form-data">
            @csrf
            <input type="hidden" name="roleid" value="{{$userdetails->roles[0]->id}}">
            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                    <a class="nav-link" href="{{route('superadmin.icsuser.step1',$userdetails->id)}}">General
                        Information</a>
                    <a class="nav-link" href="{{route('superadmin.icsuser.step2',$userdetails->id)}}">Self/Mandator
                        Details</a>
                    <a class="nav-link active" id="step3-tab" data-bs-toggle="tab"
                        href="{{route('superadmin.icsuser.step3',$userdetails->id)}}">Farmer Details</a>
                    <a class="nav-link" href="{{route('superadmin.icsuser.step4',$userdetails->id)}}">Inspector
                        Details</a>
                    <a class="nav-link" href="{{route('superadmin.icsuser.step5',$userdetails->id)}}">Warehouse
                        Details</a>
                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">


                <div class="tab-pane fade show active" id="step3">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1"> Add Details of Farmer
                            </h4>
                            <div class="flex-shrink-0">
                                @if (session('error'))
                                <div class="alert alert-danger">
                                    {{ session('error') }}
                                </div>
                                @endif
                                @if (session('success'))
                                <div class="alert alert-success">
                                    {{ session('success') }}
                                </div>
                                @endif
                                @if($errors)
                                @foreach ($errors->all() as $error)
                                <div class="alert alert-danger">{{ $error }}</div>
                                @endforeach
                                @endif
                            </div>
                        </div>
                        <!-- end card header -->
                        <div class="card-body">
                            <div class="live-preview">
                                <div class="row seperatesec">
                                    <div class="col-xxl-4 col-md-4 ">
                                        <div>
                                            <label class="form-label">Name of Farmer</label>
                                            <input type="text" class="form-control" id="placeholderInput"
                                                placeholder="Name of Farmer" name="farmer_name"
                                                value="{{ (isset($userfardetail) && $userfardetail->name!='' ?  $userfardetail->name:'')}}" />
                                        </div>
                                    </div>
                                    <div class="col-xxl-4 col-md-4">
                                        <div>
                                            <label for="labelInput" class="form-label">Mobile Number<span
                                                    class="required">*</span></label>
                                            <input type="text" maxlength="10" class="form-control numbersonly"
                                                id="mobile" onblur="phonenumber(this)" placeholder="Mobile Number*"
                                                name="mobile_no"
                                                value="{{ (isset($userfardetail) && $userfardetail->mobile_no!='' ?  $userfardetail->mobile_no:'')}}" />
                                        </div>
                                    </div>
                                    <div class="col-xxl-4 col-md-4 ">
                                        <div>
                                            <label for="labelInput" class="form-label">Email Id<span
                                                    class="required">*</span></label>
                                            <input type="email" class="form-control" id="placeholderInput"
                                                placeholder="Email Id*" name="email"
                                                value="{{ (isset($userfardetail) && $userfardetail->email!='' ? $userfardetail->email:'')}}" />
                                        </div>
                                    </div>
                                </div>
                                <div class="row seperatesec">
                                </div>
                                <div class="row  ">
                                    <div class="sectitle gy-3">
                                        <label for="labelInput" class="form-label">Address</label>
                                    </div>
                                    <div class="col-xxl-9 col-md-9  ">
                                        <div class="row  ">
                                            <div class="col-xxl-4 col-md-4 gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">State <span
                                                            class="required">*</span></label>
                                                    <select class="form-select" name="state">
                                                        <option value="">Select State</option>
                                                        @forelse($states as $state)
                                                        <option value="{{$state->id}}"
                                                            {{(isset($userfardetail) && $userfardetail->state==$state->id ? 'selected':'')}}>
                                                            {{$state->state_name}}</option>
                                                        @empty
                                                        @endforelse
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-xxl-4 col-md-4 gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">District <span
                                                            class="required">*</span></label>
                                                    <select class="form-select" name="district">
                                                        <option value="">Select District</option>
                                                        @forelse($districts as $district)
                                                        <option value="{{$district->id}}"
                                                            {{(isset($userfardetail) && $userfardetail->district==$district->id ? 'selected':'')}}>
                                                            {{$district->district_name}}</option>
                                                        @empty
                                                        @endforelse
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-xxl-4 col-md-4 gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">Taluka/Mandal
                                                        <span class="required">*</span></label>
                                                    <select class="form-select" name="taluka">
                                                        <option value="">Select Taluka/Mandal</option>
                                                        @forelse($regions as $region)
                                                        <option value="{{$region->id}}"
                                                            {{(isset($userfardetail) && $userfardetail->taluka==$region->id ? 'selected':'')}}>
                                                            {{$region->region_name}}</option>
                                                        @empty
                                                        @endforelse
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-xxl-6 col-md-6 gy-3">
                                                <div>
                                                    <label class="form-label">Village </label>
                                                    <select class="form-select" name="village">
                                                        <option value="">Select Village</option>
                                                        @forelse($villages as $village)
                                                        <option value="{{$village->id}}"
                                                            {{(isset($userfardetail) && $userfardetail->village==$village->id ? 'selected':'')}}>
                                                            {{$village->village_name}}</option>
                                                        @empty
                                                        @endforelse
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-xxl-6 col-md-6 gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">Pin Code<span
                                                            class="required">*</span></label>
                                                    <input type="text" maxlength="6" class="form-control numbersonly"
                                                        id="placeholderInput" placeholder="Pin Code" name="pincode"
                                                        value="{{ (isset($userfardetail) && $userfardetail->pin_code!='' ? $userfardetail->pin_code:'')}}"
                                                        maxlength="6" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xxl-3 col-md-3 gy-3">
                                        <div class="row">
                                            <div class="col-xx-12 col-md-12">
                                                <label for="labelInput" class="form-label">Address <span
                                                        class="required">*</span></label>
                                                <textarea placeholder="Address of The Farmer"
                                                    class="form-control customtextarea"
                                                    name="address">{{ (isset($userfardetail) && $userfardetail->address!='' ? $userfardetail->address:'')}}</textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row seperatesec ">
                                    <div class="sectitle gy-3">
                                        <label for="labelInput" class="form-label">Land Address Detail</label>
                                    </div>
                                    <div class="col-xxl-12 col-md-12 gy-3_">
                                        <div class="row">
                                            <div class="col-xx-12 col-md-12">
                                                <label for="labelInput" class="form-label">Land Address <span
                                                        class="required">*</span></label>
                                                <textarea placeholder="Address of The Land"
                                                    class="form-control customtextarea"
                                                    name="land_address">{{ (isset($userfardetail) && $userfardetail->land_address!='' ? $userfardetail->land_address:'')}}</textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row seperatesec ">
                                    <div class="col-xxl-4 col-md-4 gy-3">
                                        <div>
                                            <label class="form-label">Aadhar Card<span class="required">*</span></label>
                                            <input type="file" class="form-control" id="aadhar_card" name="aadhar_card">
                                            @if(!empty($userfardetail->aadhar_card))
                                            <input type="hidden" name="aadhar_card_edit"
                                                value="{{ ($userfardetail->aadhar_card) ?? ''}}">
                                            <a target="_BLANK"
                                                href="{{asset('public/farmer/aadhar_card/'.$userfardetail->aadhar_card)}}"
                                                class="text-decoration-underline">See Doc</a>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="col-xxl-4 col-md-4 gy-3">
                                        <div>
                                            <label class="form-label">PAN Card<span class="required">*</span></label>
                                            <input type="file" class="form-control" name="pan_card" id="pan_card">
                                            @if(!empty($userfardetail->pan_card))
                                            <input type="hidden" name="pan_card_edit"
                                                value="{{ ($userfardetail->pan_card) ?? ''}}">
                                            <a target="_BLANK"
                                                href="{{asset('public/farmer/pan_card/'.$userfardetail->pan_card)}}"
                                                class="text-decoration-underline">See Doc</a>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="col-xxl-4 col-md-4 gy-3">
                                        <div>
                                            <label for="basiInput" class="form-label">Address Proof of Office
                                            </label>
                                            <div class="input-group">
                                                <select class="form-select" name="address_proof_of_office">
                                                    <option value="electricity_bill"
                                                        {{ (isset($userfardetail) && $userfardetail->address_proof_of_office=='electricity_bill'  ? 'selected':'')}}>
                                                        Electricity Bill</option>
                                                    <option value="rent_agreement"
                                                        {{ (isset($userfardetail) && $userfardetail->address_proof_of_office=='rent_agreement' ? 'selected':'')}}>
                                                        Rent Agreement</option>
                                                    <option value="driving_licence"
                                                        {{ (isset($userfardetail) && $userfardetail->address_proof_of_office=='driving_licence' ? 'selected':'')}}>
                                                        Driving Licence</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xxl-4 col-md-4 gy-3">
                                        <div>
                                            <label class="form-label">Address Proof of Office Doc<span
                                                    class="required">*</span></label>
                                            <input type="file" class="form-control" name="address_proof_of_office_doc"
                                                id="address_proof_of_office_doc">
                                            @if(!empty($userfardetail->address_proof_of_office_doc))
                                            <input type="hidden" name="address_proof_of_office_doc_edit"
                                                value="{{ ($userfardetail->address_proof_of_office_doc) ?? ''}}">
                                            <a target="_BLANK"
                                                href="{{asset('public/farmer/address_proof_of_office_doc/'.$userfardetail->address_proof_of_office_doc)}}"
                                                class="text-decoration-underline">See Doc</a>
                                            @endif
                                        </div>
                                    </div>

                                    <div class="col-xxl-4 col-md-4 gy-3">
                                        <div>
                                            <label class="form-label">Photo of Farmer<span
                                                    class="required">*</span></label>
                                            <input type="file" class="form-control" name="profile_photo"
                                                id="profile_photo">
                                            @if(!empty($userfardetail->profile_photo))
                                            <input type="hidden" name="profile_photo_edit"
                                                value="{{ ($userfardetail->profile_photo) ?? ''}}">
                                            <a target="_BLANK"
                                                href="{{asset('public/farmer/profile_photo/'.$userfardetail->profile_photo)}}"
                                                class="text-decoration-underline">See Doc</a>
                                            @endif
                                        </div>
                                    </div>



                                    <div class="col-xxl-4 col-md-4 gy-3">
                                        <div>
                                            <label class="form-label">Appointment Letter<span
                                                    class="required">*</span></label>
                                            <input type="file" class="form-control" name="appointment_doc"
                                                id="appointment_doc">
                                            @if(!empty($userfardetail->appointment_doc))
                                            <input type="hidden" name="appointment_doc_edit"
                                                value="{{ ($userfardetail->appointment_doc) ?? ''}}">
                                            <a target="_BLANK"
                                                href="{{asset('public/farmer/appointment_doc/'.$userfardetail->appointment_doc)}}"
                                                class="text-decoration-underline">See Doc</a>
                                            @endif
                                        </div>
                                    </div>
                                </div>


                                <!--address sec end-->

                                <div class="row">
                                    <div class="col-lg-12 gy-4">
                                        <div class="hstack gap-2">
                                            <a href="{{route('superadmin.icsuser.step2',$userdetails->id)}}"
                                                class="btn btn-soft-success">
                                                Back
                                            </a>
                                            <button type="submit" class="btn btn-primary">
                                                Submit
                                            </button>
                                            <a href="{{route('superadmin.icsuser.step4',$userdetails->id)}}"
                                                class="btn btn-soft-success">
                                                Next
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

    </div>

    </form>
</div>
</div>



@endsection
@push('script')

<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

function phonenumber(inputtxt) {
    var phoneno = /^\d{10}$/;
    if (inputtxt.value.match(phoneno)) {
        return true;
    } else {
        Swal.fire('', 'Please enter a valid mobile number.', 'warning');
        $("#mobile").val('');
        return false;
    }
}
// Dropzone has been added as a global variable.

$('.dropzone').each(function() {
    var options = $(this).attr('id');
    $(this).dropzone({
        url: "{{ route('storeMedia') }}",
        paramName: "file",
        maxFilesize: 2,
        maxFiles: 1,
        acceptedFiles: ".jpeg,.jpg,.png,.mp4,.webm,.html5",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        init: function() {
            var drop = this; // Closure
            this.on('error', function(file, errorMessage) {
                if (errorMessage.indexOf('Error 404') !== -1) {
                    var errorDisplay = document.querySelectorAll('[data-dz-errormessage]');
                    errorDisplay[errorDisplay.length - 1].innerHTML =
                        'Error 404: The upload page was not found on the server';
                }
                if (errorMessage.indexOf('File is too big') !== -1) {
                    alert('Unable to upload image size is greated than 2 MB');
                    // i remove current file
                    drop.removeFile(file);
                }
            });
            this.on("maxfilesexceeded", function(file) {
                    this.removeAllFiles();
                    this.addFile(file);
                }),
                this.on("success", function(file, response) {
                    console.log(response);
                    var hiddenImage = $('<input type="hidden" name="_hidden_' + options +
                        '" value="' +
                        response.name + '"/>');
                    $('#hidden_' + options).html(hiddenImage);
                })
        }
    });

});
const dropzone = new Dropzone("div.dropzone", {

});
</script>

@endpush
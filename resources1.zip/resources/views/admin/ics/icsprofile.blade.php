@extends('admin.layouts.app')
@section('content')
    <style>
        .wrapper {
            max-width: 1240px;
            margin: 0 auto;
        }

        .white-bg {
            background-color: white;
            border-bottom: 5px solid #ff9800;
            margin-bottom: 15px;
        }

        .auth-one-bg .slide .carousel-indicators {
            bottom: 25px;
        }

        .auth-page-wrapper .auth-page-content {
            padding-bottom: 0px !important;
        }

        .auth-page-content .card {
            margin-bottom: 0rem;
        }

        .data-tabs .wrapper .nav-tabs button {
            font-size: 17px;
            color: black;
        }

        .data-tabs .wrapper .nav-tabs .active {
            background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
            */ color: white;
            background: orange;
            border-radius: 0px;
        }

        .carousel-caption.d-none.d-md-block {
            background-color: #000000bf;
            left: 0;
            width: 100%;
            bottom: 0;
        }

        .carousel-indicators {
            display: none;
        }

        .custom-banner-caption {
            color: white !important;
        }

        .announcement-heading {
            font-size: 1.2em;
            font-weight: 600;
        }

        .data-tabs .tab-pane ul li {
            font-size: 1em;
            padding: 5px 0;
        }

        .main-logo {
            padding: 10px;
        }

        .data-tabs .nav-item .nav-link {
            background-image: none;
        }

        .navbar-brand-box {
            background: #fff;
        }

        .btn-danger {
            background-color: #40895a;
            border: 1px solid #40895a;
        }

        [data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
            color: white !important;
        }

        .header-buttons .btn-primary {
            margin-right: 10px;
            padding: 6px 15px;
            font-weight: 600;
            background-color: #207005;
            border: none;
            box-shadow: 0px 2px 7px #888888;
        }

        .header-buttons .btn-secondary {
            margin-right: 10px;
            padding: 6px 15px;
            font-weight: 600;
            background-color: #72a055;
            border: none;
            box-shadow: 0px 2px 7px #888888;
        }


        .right-sec {
            border-left: 5px solid #ede7e7;
        }

        .tabdiv {
            background: white;
            padding: 20px;
            margin-top: 10px;
            border: 10px solid #dfdbd5;
        }

        .nav-tabs {
            border-bottom: 0px;
        }

        div#myTabContent {
            border: 1px solid #cccccc;
        }

        .frontfooter footer {
            padding: 20px calc(1.5rem / 2);
            position: static;
            color: #000;
            height: 60px;
            background-color: #f9f9f9;
            margin-top: 30px;
            border-top: 1px solid #e1dfdf;
        }

        span.logo-sm img {
            width: 69px;
        }

        .seperatesec {
            margin-top: 20px;
        }

        .simplebar-content li.nav-item:hover {
            background: #4caf50;
        }

        .sectitle {
            font-size: 14px;
        }

        .required {
            color: red;
        }

        .customtextarea {
            height: 120px;
        }

        ul.boxsection {
            margin: 0;
            padding: 0;
        }

        ul.boxsection li {
            list-style-type: none;
            padding: 7px 0;
            border-bottom: 1px solid #efeded;
        }

        .boxcard .col:nth-child(1) {
            background: #effcfb;
        }

        .boxcard .col:nth-child(2) {
            background: #fdfdfd;
        }

        .boxcard .col:nth-child(3) {
            background: #effcfb;
        }

        .boxcard .col:nth-child(4) {
            background: #fdfdfd;
        }

        .boxcard .col:nth-child(5) {
            background: #effcfb;
        }

        .custom-tab-content {
            padding-top: 0 !important;
            padding-bottom: 0px !important;
        }

        .custom-tab-nav {
            background: white;
        }

        .custom-tab-nav .nav-link {
            border-radius: 0 !important;
            border-bottom: 1px solid #e9ebec;
            border-right: 1px solid #e9ebec;
            font-size: 14px;
            padding: 10px;
        }

        .custom-tab-nav .nav-link.active,
        .custom-tab-nav .show>.nav-link {
            color: rgb(255, 255, 255) !important;
            background-color: #2c8c6d;
            border-bottom: #2c8c6d !important;
            /* border-bottom: #207005 !important; */
            position: relative;
        }

        .custom-tab-nav .nav-link:hover,
        .custom-tab-nav .nav-link:focus {
            border-bottom: 1px solid #207005;
            border-radius: 0;
            font-size: 14px;
            transition: background-color 0.20s linear;
        }

        .custom-tab-nav .nav-link.active:after {
            content: "";
            position: absolute;
            bottom: -16px;
            left: 50%;
            border: 8px solid transparent;
            border-top-color: #2c8c6d;
            z-index: 999;
        }

        .reg-form-btns {
            margin-bottom: 15px;
        }

        .reg-form-btns .btn-secondary {
            color: #fff;
            background-color: #405189;
            border-color: #405189;
        }

        .btn-soft-success:active,
        .btn-soft-success:focus,
        .btn-soft-success:hover {
            border: none;
        }

        .custom-tab-nav ul {
            padding: 0px;
            margin: 0px;
        }

        .custom-tab-nav ul li {
            padding: 0px;
            margin: 0px;
            display: inline-block;
            list-style: none;
        }

        .has-error {
            border: 1px solid red;
        }

        .errormsg {
            color: red;
            font-size: 14px !important;
        }
    </style>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">उत्पादक समूह प्रोफ़ाइल/Grower Group Profile</h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Grower Group Profile</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <form method="post" enctype="multipart/form-data" id=""
                action="{{ route('superadmin.icsuser.step1post', $userdetails->id) }}">
                @csrf
                <nav>
                    <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">

                        <a class="nav-link active" id="step1-tab" data-bs-toggle="tab"
                            href="{{ route('superadmin.icsuser.step1', $userdetails->id) }}">General Information</a>
                        <a class="nav-link" href="{{ route('superadmin.icsuser.step2', $userdetails->id) }}">Self/Service
                            Provider Details</a>
                        <a class="nav-link" href="{{ route('superadmin.icsuser.step4', $userdetails->id) }}">Internal
                            Inspector
                            Details</a>
                        <a class="nav-link"
                            href="{{ route('superadmin.icsuser.step5', $userdetails->id) }}">Warehouse/Godown
                        </a>
                        <a class="nav-link" href="{{ route('superadmin.icsuser.step6', $userdetails->id) }}">Grower Group
                            Official
                            Details</a>
                        <a class="nav-link" href="{{ route('superadmin.icsuser.step3', $userdetails->id) }}">Farmer
                            Details</a>
                    </div>
                </nav>
                <div class="tab-content py-4 custom-tab-content">
                    <div class="tab-pane fade show active" id="step1">
                        <div class="card">
                            <div class="card-header align-items-center d-flex">
                                <h4 class="card-title mb-0 flex-grow-1">
                                    संचालक का नाम/Name of the Operator
                                </h4>
                                <div class="flex-shrink-0">
                                    @if (session('error'))
                                        <div class="alert alert-danger">
                                            {{ session('error') }}
                                        </div>
                                    @endif
                                    @if (session('success'))
                                        <div class="alert alert-success">
                                            {{ session('success') }}
                                        </div>
                                    @endif
                                    @if ($errors)
                                        @foreach ($errors->all() as $error)
                                            <div class="alert alert-danger">{{ $error }}</div>
                                        @endforeach
                                    @endif
                                </div>
                            </div>

                            <!-- end card header -->
                            <div class="card-body">
                                <div class="live-preview">
                                    <div class="row white-inner">

                                        <div class="col-xxl-3 col-md-4">
                                            <div>
                                                <label class="form-label">पैन नंबर/PAN No.<span class="required">*</span></label>
                                                <input type="text" class="form-control" id="name"
                                                    placeholder="First Name" name="first_name" readonly
                                                    value="{{ $userdetails->user_name }}">
                                            </div>
                                        </div>

                                        <div class="col-xxl-3 col-md-4">
                                            <div>
                                                <label class="form-label">उत्पादक समूह का नाम/Name Of Grower Group<span
                                                        class="required">*</span></label>
                                                <input type="text" class="form-control" id="name"
                                                    placeholder="First Name" name="first_name" readonly
                                                    value="{{ $userdetails->first_name }}">
                                            </div>
                                        </div>

                                        <div class="col-xxl-3 col-md-6">
                                            <div>
                                                <label for="labelInput" class="form-label">कानूनी
                                                    प्रतिष्ठान प्रकार/Legal Entity Type </label>


                                                <input type="text" class="form-control" id="name"
                                                    placeholder="" name="entity_firm" readonly
                                                    value="{{ $userdetails->entity_firm ?? '' }}">


                                              
                                            </div>
                                        </div>




                                        <div class="col-xxl-3 col-md-4 legal_doc_div "
                                            {{ empty($userdetails->legal_document_number ?? '') }}>
                                            <div>
                                                <label class="form-label">कानूनी प्रतिष्ठान
                                                    दस्तावेज़ संख्या/Entity Legal Document No.</label>
                                                <input type="text" class="form-control only-number" id=""
                                                    placeholder="Enter Entity Legal Document No."
                                                    name="legal_document_number"
                                                    value="{{ $userdetails->legal_document_number }}" maxlength="20">
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-4 mt-3">
                                            <div>
                                                <label class="form-label">कानूनी प्रतिष्ठान
                                                    दस्तावेज़ अपलोड करें/Upload Legal Entity Document</label>
                                                <input type="file" class="form-control upload_document" name=""
                                                    id="office_building_photo"
                                                    accept="image/png, application/pdf, image/jpeg">
                                                <span class="form-text">Supported formats:JPG, PNG, PDF. Upto 1MB</span>
                                                @if (!empty($userdetails->office_building_photo))
                                                    <input type="hidden" name="office_building_photo_edit"
                                                        value="{{ $userdetails->office_building_photo ?? '' }}">
                                                    <a target="_BLANK"
                                                        href="{{ asset('public/ics/office_building_photo/' . $userdetails->office_building_photo) }}"
                                                        class="text-decoration-underline">See Doc</a>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-4 mt-3">
                                            <div>
                                                <label class="form-label">Photo of Grower Group Office building/उत्पादक
                                                    कार्यालय का फोटो</label>
                                                <input type="file" class="form-control upload_document"
                                                    name="office_building_photo" id="office_building_photo"
                                                    accept="image/png, application/pdf, image/jpeg">
                                                <span class="form-text">Supported formats:JPG, PNG, PDF. Upto 1MB</span>
                                                @if (!empty($userdetails->office_building_photo))
                                                    <input type="hidden" name="office_building_photo_edit"
                                                        value="{{ $userdetails->office_building_photo ?? '' }}">
                                                    <a target="_BLANK"
                                                        href="{{ asset('public/ics/office_building_photo/' . $userdetails->office_building_photo) }}"
                                                        class="text-decoration-underline">See Doc</a>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-4 gy-3">
                                            <div>
                                                <label for="basiInput" class="form-label">उत्पादक प्रबंधक का प्रमाणिकता पता/Address proof of Grower Group
                                                    <span class="required">*</span>
                                                </label>

                                                <select class="form-select" name="address_proof_of_office"
                                                    id="address_proof_of_office" required>
                                                    <option value="">-Select-</option>
                                                    <option value="electricity_bill"
                                                        {{ isset($userdetails) && $userdetails->address_proof_of_office == 'electricity_bill' ? 'selected' : '' }}>
                                                        Electricity Bill</option>
                                                    <!-- <option value="water_bill"
                                                                {{ isset($userdetails) && $userdetails->address_proof_of_office == 'water_bill' ? 'selected' : '' }}>
                                                                Water Bill</option> -->
                                                    <!-- <option value="rent_agreement"
                                                                {{ isset($userdetails) && $userdetails->address_proof_of_office == 'rent_agreement' ? 'selected' : '' }}>
                                                                Rent Agreement</option> -->
                                                </select>

                                            </div>
                                        </div>

                                        <div class="col-xxl-3 col-md-4  address_proof_doc mt-5">
                                            <div>
                                                <label class="form-label">प्रमाणिकता पता का दस्तावेज/Address Proof Doc
                                                    <span class="required">*</span></label>
                                                <input type="file" class="form-control upload_document"
                                                    name="address_proof_of_office_doc" id="address_proof_of_office_doc"
                                                    {{ $userdetails->address_proof_of_office_doc ?? 'required' }}
                                                    accept="image/png, application/pdf, image/jpeg" />
                                                <span class="form-text">Supported formats: JPG, PNG, PDF. Up to 1MB</span>
                                                @if (!empty($userdetails->address_proof_of_office_doc))
                                                    <input type="hidden" name="address_proof_of_office_doc_edit"
                                                        value="{{ $userdetails->address_proof_of_office_doc ?? '' }}">
                                                    <a target="_BLANK"
                                                        href="{{ asset('public/ics/address_proof_of_office_doc/' . $userdetails->address_proof_of_office_doc) }}"
                                                        class="text-decoration-underline">See Doc</a>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-4 mt-3">
                                            <div>
                                                <label for="labelInput" class="form-label">किसानों की
                                                    संख्या/Number of Farmers<span class="required">*</span></label>
                                                <input type="number" class="form-control" id=""
                                                    placeholder="Number of Farmers*" name="no_of_farmers"
                                                    value="{{ $userdetails->no_of_farmers }}"
                                                    onchange="checkValue(this);" required />
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-4 mt-3">
                                            <div>
                                                <label for="labelInput" class="form-label">निरीक्षकों
                                                    की संख्या/ No. of Inspector<span class="required">*</span></label>
                                                <input type="type" class="form-control numbersonly" id=""
                                                    placeholder="Number of Inspector" name="no_of_inspector"
                                                    maxlength="2" value="{{ $userdetails->no_of_inspector }}"
                                                    onchange="checkInsp(this);" required readonly />
                                            </div>
                                        </div>
                                        <div class="seperatesec inner-sub-sec mt-4">
                                            <div class="sectitle">
                                                <label for="labelInput" class="form-label blue-ht">उत्पादक का पता/Address of Grower
                                                    Group</label>
                                            </div>
                                            <div class="row">
                                                <div class="col-xxl-3 col-md-3">
                                                    <div class="row">
                                                        <div class="col-xx-12 col-md-12">
                                                            <label for="labelInput" class="form-label">पता/Address<span
                                                                    class="required">*</span></label>
                                                            <textarea placeholder="Address" class="form-control customtextarea" name="address" required readonly>{{ $userdetails->address }}</textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-xxl-9 col-md-9  ">
                                                    <div class="row">
                                                        <div class="col-xxl-4 col-md-4">
                                                            <div>
                                                                <label for="labelInput"
                                                                    class="form-label">राज्य/State<span
                                                                        class="required">*</span></label>
                                                                <input type="hidden" name="ref_state_id"
                                                                    value="{{ $userdetails->ref_state_id }}">
                                                                <input type="text" class="form-control" id=""
                                                                    placeholder="" name="state"
                                                                    value="{{ getStateName($userdetails->ref_state_id) }}"
                                                                    readonly />
                                                                {{-- <select class="form-select state" name="state" readonly>
                                                            <option value="">Select State</option>
                                                            @forelse($states as $state)
                                                                <option value="{{ $state->id }}"
                                                                    @if (isset($userdetails->ref_state_id) && $userdetails->ref_state_id == $state->id) selected @endif>
                                                                    {{ $state->state_name }}</option>
                                                            @empty
                                                            @endforelse
                                                        </select> --}}
                                                            </div>
                                                        </div>

                                                        <div class="col-xxl-4 col-md-4">
                                                            <div>
                                                                <label for="labelInput"
                                                                    class="form-label">जिला/District<span
                                                                        class="required">*</span></label>
                                                                <input type="hidden" name="ref_district_id"
                                                                    value="{{ $userdetails->ref_district_id }}">
                                                                <input type="text" class="form-control" id=""
                                                                    placeholder="" name="state"
                                                                    value="{{ getDisName($userdetails->ref_district_id) }}"
                                                                    readonly />
                                                                {{-- <select class="form-select district" name="district" readonly>
                                                            <option value="">Select District</option>
                                                            @forelse(getDistrictByStateID($userdetails->ref_state_id) as $district)
                                                                <option value="{{ $district->id }}"
                                                                    @if (isset($userdetails->ref_district_id) && $userdetails->ref_district_id == $district->id) selected @endif>
                                                                    {{ $district->district_name }}</option>
                                                            @empty
                                                            @endforelse
                                                        </select> --}}
                                                            </div>
                                                        </div>
                                                        <div class="col-xxl-4 col-md-4">
                                                            <div>
                                                                <label for="labelInput"
                                                                    class="form-label">तालुका/मंडल/Taluka/Mandal
                                                                    <span class="required">*</span></label>
                                                                <input type="hidden" name="ref_block_tehsil_id"
                                                                    value="{{ $userdetails->ref_block_tehsil_id }}">
                                                                <input type="text" class="form-control" id=""
                                                                    placeholder="" name="state"
                                                                    value="{{ getTalukName($userdetails->ref_block_tehsil_id) }}"
                                                                    readonly />
                                                                {{-- <select class="form-select block_tehsil" name="taluka" readonly>
                                                            <option value="">Select Taluka/Mandal</option>
                                                            @forelse(getBlockTehsilByDistrictID($userdetails->ref_district_id) as $region)
                                                                <option value="{{ $region->id }}"
                                                                    @if (isset($userdetails->ref_block_tehsil_id) && $userdetails->ref_block_tehsil_id == $region->id) selected @endif>
                                                                    {{ $region->block_tehsil_name }}</option>
                                                            @empty
                                                            @endforelse
                                                        </select> --}}
                                                            </div>
                                                        </div>
                                                        <div class="col-xxl-6 col-md-6 gy-3">
                                                            <div>
                                                                <label class="form-label">गाँव/Village<span
                                                                        class="required">*</span></label>
                                                                <input type="hidden" name="ref_village_id"
                                                                    value="{{ $userdetails->ref_village_id }}">
                                                                <input type="text" class="form-control" id=""
                                                                    placeholder="" name="state"
                                                                    value="{{ getVillName($userdetails->ref_village_id) }}"
                                                                    readonly />
                                                                {{-- <select class="form-select village" name="village" readonly>
                                                            <option value="">Select Village</option>
                                                            @forelse(getVillageByBlock($userdetails->ref_block_tehsil_id) as $vill)
                                                                <option value="{{ $vill->id }}"
                                                                    @if (isset($userdetails) && $userdetails->ref_village_id == $vill->id) selected @endif>
                                                                    {{ $vill->village_name }}</option>
                                                            @empty
                                                            @endforelse
                                                        </select> --}}
                                                            </div>
                                                        </div>

                                                        <div class="col-xxl-6 col-md-6 gy-3">
                                                            <div>
                                                                <label for="labelInput" class="form-label">पिन कोड/Pin Code
                                                                    <span class="required">*</span></label>
                                                                <input type="text" class="form-control numbersonly"
                                                                    id="placeholderInput" placeholder="Pin Code"
                                                                    name="pincode" value="{{ $userdetails->pin }}"
                                                                    maxlength="6" required readonly />
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        {{-- <div class="col-xxl-4 col-md-4">
                                        <div>
                                        <label class="form-label">Middle Name</label>
                                         <input type="text" class="form-control" id="m_name" placeholder="Middle Name" name="middle_name" value="{{$userdetails->middle_name}}">
                                        </div>
                                    </div>

                                    <div class="col-xxl-4 col-md-4 ">
                                        <div>
                                            <label class="form-label">Last Name <span class="required">*</span></label>
                                            <input type="text" class="form-control" id="last_name" name="last_name" placeholder="Last Name" value="{{$userdetails->last_name}}" required>
                                        </div>
                                    </div> --}}
                                    </div>
                                    <div class="seperatesec ">
                                        {{-- <div class="sectitle gy-3">
                                            <label for="labelInput" class="form-label blue-ht">Address of ICS</label>
                                        </div> --}}

                                    </div>
                                    {{-- ----------  --}}
                                    <div class="seperatesec white-inner">
                                        <div class="sectitle white-inner-p">
                                            <label for="labelInput" class="form-label blue-ht">उत्पादक से संपर्ककर्ता/Contact Person From Grower
                                                Group</label>
                                        </div>
                                        <div class="row white-inner-p">
                                            <div class="col-xxl-3 col-md-4 mt-3">
                                                <div>
                                                    <label class="form-label">संपर्ककर्ता का
                                                        नाम/Contact Person First Name<span class="required">*</span></label>
                                                    <input type="text" class="form-control textonly"
                                                        id="placeholderInput" placeholder="First Name"
                                                        name="contact_first_name"
                                                        value="{{ $userdetails->contact_person_first_name }}" required
                                                        maxlength="25" readonly />
                                                    <input type="hidden" name="roleid"
                                                        value="{{ $userdetails->ref_operator_type_id }}">
                                                </div>
                                            </div>

                                            <div class="col-xxl-3 col-md-4">
                                                <div>
                                                    <label class="form-label">संपर्ककर्ता का
                                                        मध्य नाम/Contact Person Middle Name</label>
                                                    <input type="text" class="form-control textonly"
                                                        id="placeholderInput" placeholder="Middle Name"
                                                        name="contact_middle_name"
                                                        value="{{ $userdetails->contact_person_middle_name }}"
                                                        maxlength="25" />
                                                </div>
                                            </div>

                                            <div class="col-xxl-3 col-md-4 ">
                                                <div>
                                                    <label class="form-label">संपर्ककर्ता का
                                                        उपनाम/Contact Person Last Name<span class="required">*</span></label>
                                                    <input type="text" class="form-control textonly"
                                                        id="placeholderInput" placeholder="Last Name"
                                                        name="contact_last_name"
                                                        value="{{ $userdetails->contact_person_last_name }}" required
                                                        maxlength="25" readonly />
                                                </div>
                                            </div>

                                            <div class="col-xxl-3 col-md-4 mt-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">संपर्ककर्ता का मोबाइल नंबर/Contact Person Mobile
                                                        Number<span
                                                            class="required">*</span></label>
                                                    <input type="text" maxlength="10" class="form-control numbersonly"
                                                        name="mobile_no" placeholder="Mobile No*" id="mobile"
                                                        value="{{ $userdetails->contact_person_mobile_number }}"
                                                        onblur="phonenumber(this)" required readonly />
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-4  gy-3">
                                                <div>
                                                    <label for="labelInput" class="form-label">संपर्ककर्ता की ईमेल आईडी/Contact Person Email
                                                        Id<span class="required">*</span></label>
                                                    <input type="email" class="form-control" name="email"
                                                        placeholder="Email Id*"
                                                        value="{{ $userdetails->contact_person_email }}" required
                                                        readonly />
                                                </div>
                                            </div>



                                            <div class="col-xxl-3 col-md-4  gy-3">
                                                <div>
                                                    @php
                                                        $maskedAadhar = '';
                                                        try {
                                                            if ($userdetails->contact_person_aadhar_number) {
                                                                $decryptedAadhar = Crypt::decrypt(
                                                                    $userdetails->contact_person_aadhar_number,
                                                                );
                                                                $maskedAadhar = maskAadhaarNumber($decryptedAadhar);
                                                            }
                                                        } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
                                                            $maskedAadhar = 'Invalid Aadhaar Number';
                                                        }
                                                    @endphp
                                                    <label for="labelInput" class="form-label">संपर्ककर्ता का आधार नंबर/Contact Person Aadhaar
                                                        Number<span
                                                            class=""></span></label>
                                                    <input type="text" class="form-control"
                                                        name="contact_person_aadhar_number" placeholder=""
                                                        value="{{$maskedAadhar}}" required maxlength="12" readonly />
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-6 gy-3 mt-4">
                                                <div>
                                                    <label for="labelInput" class="form-label">संपर्ककर्ता का पदनाम/Designation of Contact Person</label>
                                                    <input type="text" class="form-control" name="contact_designation"
                                                        placeholder="Aadhaar number*"
                                                        value="{{ $userdetails->contact_designation }}" required
                                                        readonly />

                                                    <!-- <select name="contact_designation" class="form-control" disabled>
                                                <option value="">Select Designation</option>
                                                <option value="ICS Manager" {{ $userdetails->contact_designation == 'ICS Manager' ? 'selected' : '' }}>ICS Manager</option>
                                           <option value="MD" {{ $userdetails->contact_designation == 'MD' ? 'selected' : '' }}>MD</option>
                                                <option value="Director" {{ $userdetails->contact_designation == 'Director' ? 'selected' : '' }}>Director</option>
                                                <option value="Partner" {{ $userdetails->contact_designation == 'Partner' ? 'selected' : '' }}>Partner</option>
                                                <option value="Proprietor" {{ $userdetails->contact_designation == 'Proprietor' ? 'selected' : '' }}>Proprietor</option>
                                            </select> -->

                                                </div>
                                            </div>




                                        </div>
                                    </div>
                                    {{-- --------  --}}
                                    <div class="row seperatesec " style="display:none;">
                                        <div class="col-xxl-12 col-md-12  gy-3">
                                            <div class="card">
                                                <div class="card-header">
                                                    <h4 class="card-title mb-0">Appointment Letter</h4>
                                                </div>

                                                {{-- <div class="dropzone">
                                                    <div class="fallback">
                                                        <input name="file" type="file">
                                                    </div>
                                                    <div class="dz-message needsclick">
                                                        <div class="mb-3">
                                                            <i class="display-4 text-muted ri-upload-cloud-2-fill"></i>
                                                        </div>
                                                        <h4>Drop files here or click to upload.</h4>
                                                    </div>
                                                    <div class="hidden_images_area">
                                                        <input type="hidden" name="_hidden_legal_doc_upload"
                                                            value="{{ isset($userdetails) && $userdetails->legal_doc_upload != '' ? $userdetails->legal_doc_upload : '' }}"
                                                            required />
                                                    </div>
                                                </div> --}}
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row seperatesec white-inner">
                                      

                                        <div class="col-xxl-3 col-md-4">
                                            <div>
                                                <label for="labelInput" class="form-label">के द्वारा
                                                    प्रबंधित/Managed by:<span class="required">*</span></label>
                                                <br>
                                                <input type="radio" id="html" name="managed_by" value="self"
                                                    {{ $userdetails->managed_by == 'self' ? 'checked' : '' }} required>
                                                <label for="self">स्वयं/self</label>
                                                <input type="radio" id="css" name="managed_by"
                                                    value="Service Provider"
                                                    {{ $userdetails->managed_by == 'Service Provider' ? 'checked' : '' }}>
                                                <label for="Service Provider">सेवा प्रदाता/Service Provider</label><br>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-12 gy-4">
                                            <div class="hstack gap-2">
                                                <button type="submit" class="btn btn-primary" id="submitbtn">
                                                    Save & Next
                                                </button>
                                                {{-- <a href="{{ route('superadmin.icsuser.step2', $userdetails->id) }}"
                                                    class="btn btn-soft-success">
                                                    Next
                                                </a> --}}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection

@push('script')
    <script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
    <script>
        $('.upload_document').on('change', function() {
            var $this = $(this);
            var file = $this[0].files[0];
            var fileType = file.type;
            var fileSize = file.size;
            var allowedTypes = ['application/pdf', 'image/jpeg', 'image/png'];

            // Check for file type
            if (!allowedTypes.includes(fileType)) {
                Swal.fire({
                    icon: 'error',
                    title: 'Invalid File Extension',
                    text: 'Please upload PDF, JPG, or PNG only.',
                });
                $this.val("");
                return false;
            }

            // Check for file size
            if (fileSize > 1000000) { // 2 MB in bytes
                Swal.fire({
                    icon: 'error',
                    title: 'File Size Too Large',
                    text: 'Please upload files of size 1 MB or less only.',
                });
                $this.val("");
                return false;
            }
        });




        $(document).on('click', '#submitbtn', function() {

            if (checkValidation("registration")) {
                $('#registration').submit();
                return true;
            } else {
                return false;
            }
        });

        function phonenumber(inputtxt) {
            var phoneno = /^\d{10}$/;
            if (inputtxt.value.match(phoneno)) {
                return true;
            } else {
                Swal.fire('', 'Please enter a valid mobile number.', 'error');
                $("#mobile").val('');
                return false;
            }
        }

        function checkValue(input) {
            var no_of_farmers = parseInt(input.value);

            if (no_of_farmers < 25) {
                Swal.fire('', 'No Of Farmers should be 25 to 500', 'error');
                $('input[name="no_of_farmers"]').val('');
                $('input[name="no_of_inspector"]').val('');
                return false;
            } else if (no_of_farmers > 500) {
                Swal.fire('', 'No Of Farmers should be 25 to 500', 'error');
                $('input[name="no_of_farmers"]').val('');
                $('input[name="no_of_inspector"]').val('s');
                return false;
            } else {
                var insmod = no_of_farmers % 60;
                var insdev = no_of_farmers / 60;
                if (insmod > 0) {
                    insdev = insdev + 1;
                }
                $('input[name="no_of_inspector"]').val(Math.floor(insdev));
            }
        }

        function checkInsp(input) {
            var no_of_insp = parseInt(input.value);
            var regInsp = '{{ $userinsCount }}';

            if (regInsp > no_of_insp) {
                Swal.fire('', 'Sorry! You have already registered ' + regInsp + ' Inspector.', 'error');
                $('input[name="no_of_inspector"]').val(regInsp);
                return false;
            }
        }



        $('#document_type').change(function() {
            if ($('#document_type').val() != '') {

                if ($('#document_type').val() == 'PAN') {
                    $('[name=legal_document_number]').addClass('pan');
                } else {
                    $('[name=legal_document_number]').removeClass('pan');
                }
                $('.legal_doc_div').show();
                $('[name=legal_document_number]').attr('required', 'required');

            } else {
                $('.legal_doc_div').hide();
                $('[name=legal_document_number]').removeAttr('required');
            }
        });
        $(document).on('change', '.pan', function() {

            var inputvalues = $(this).val();
            var regex = /[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
            if (!regex.test(inputvalues)) {
                console.log(inputvalues);
                $(".pan").val("");
                alert("invalid PAN no");
                return regex.test(inputvalues);
            }
        });

        $("#registration").validate({
            rules: {
                first_name: "required",
                contact_first_name: "required",
                contact_last_name: "required",
                mobile_no: "required",
                email: "required",
                state: "required",
                district: "required",
                taluka: "required",
                village: "required",
                pincode: "required",
                address: "required",
                no_of_farmers: "required",
                no_of_inspector: "required",
                managed_by: "required"
            },
            messages: {

            }

        });

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        // const dropzone = new Dropzone("div.dropzone", {
        //     url: "{{ route('storeMedia') }}",
        //     paramName: "file",
        //     maxFilesize: 2,
        //     maxFiles: 1,
        //     acceptedFiles: ".jpeg,.jpg,.png,.mp4,.webm,.html5",
        //     headers: {
        //         'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        //     },
        //     init: function() {
        //         var drop = this; // Closure
        //         this.on('error', function(file, errorMessage) {
        //             if (errorMessage.indexOf('Error 404') !== -1) {
        //                 var errorDisplay = document.querySelectorAll('[data-dz-errormessage]');
        //                 errorDisplay[errorDisplay.length - 1].innerHTML =
        //                     'Error 404: The upload page was not found on the server';
        //             }
        //             if (errorMessage.indexOf('File is too big') !== -1) {
        //                 alert('Unable to upload image size is greated than 2 MB');
        //                 // i remove current file
        //                 drop.removeFile(file);
        //             }
        //         });
        //         this.on("maxfilesexceeded", function(file) {
        //                 this.removeAllFiles();
        //                 this.addFile(file);
        //             }),
        //             this.on("success", function(file, response) {
        //                 console.log(response);
        //                 var hiddenImage = $('<input type="hidden" name="_hidden_legal_doc_upload" value="' +
        //                     response.name + '"/>');
        //                 $('.hidden_images_area').html(hiddenImage);
        //             })
        //     }
        // });


        $(document).on('change', '#address_proof_of_office', function() {

            if ($('#address_proof_of_office').val() != '') {
                $('.address_proof_doc').show();
            } else {
                $('.address_proof_doc').hide();
            }
        });


    $(document).ready(function() {
            $('.only-number').on('keypress', function(event) {
                var keyCode = event.which || event.keyCode;
                if (!(keyCode >= 48 && keyCode <= 57 || keyCode == 8 || keyCode == 46)) {
                    event.preventDefault(); 
                }
            });
            $('.only-number').on('input', function() {
                var value = $(this).val();
                $(this).val(value.replace(/[^0-9]/g, ''));
            });
        });
    </script>
@endpush

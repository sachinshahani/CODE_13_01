@extends('admin.layouts.app')
@section('content')
<style>
    .wrapper {
        max-width: 1240px;
        margin: 0 auto;
    }

    .white-bg {
        background-color: white;
        /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
        border-bottom: 5px solid #ff9800;
        margin-bottom: 15px;
    }

    .auth-one-bg .slide .carousel-indicators {
        bottom: 25px;
    }

    .auth-page-wrapper .auth-page-content {
        padding-bottom: 0px !important;
    }

    .auth-page-content .card {
        margin-bottom: 0rem;
    }

    .data-tabs .wrapper .nav-tabs button {
        font-size: 17px;
        color: black;
    }

    .data-tabs .wrapper .nav-tabs .active {
        background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
        */ color: white;
        background: orange;
        border-radius: 0px;
    }

    .carousel-caption.d-none.d-md-block {
        background-color: #000000bf;
        left: 0;
        width: 100%;
        bottom: 0;
    }

    .carousel-indicators {
        display: none;
    }

    .custom-banner-caption {
        color: white !important;
    }

    .announcement-heading {
        font-size: 1.2em;
        font-weight: 600;
    }

    .data-tabs .tab-pane ul li {
        font-size: 1em;
        padding: 5px 0;
    }

    .main-logo {
        padding: 10px;
    }

    .data-tabs .nav-item .nav-link {
        background-image: none;
    }

    /* .right-sec{
                            box-shadow: 5px 10px 18px #888888;
                        } */
    .navbar-brand-box {
        background: #fff;
    }

    .btn-danger {
        background-color: #40895a;
        border: 1px solid #40895a;
    }

    [data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
        color: white !important;
    }

    .header-buttons .btn-primary {
        margin-right: 10px;
        padding: 6px 15px;
        font-weight: 600;
        background-color: #207005;
        border: none;
        box-shadow: 0px 2px 7px #888888;
    }

    .header-buttons .btn-secondary {
        margin-right: 10px;
        padding: 6px 15px;
        font-weight: 600;
        background-color: #72a055;
        border: none;
        box-shadow: 0px 2px 7px #888888;
    }

    .right-sec {
        border-left: 5px solid #ede7e7;
    }

    .tabdiv {
        background: white;
        padding: 20px;
        margin-top: 10px;
        border: 10px solid #dfdbd5;
    }

    .nav-tabs {
        border-bottom: 0px;
    }

    div#myTabContent {
        border: 1px solid #cccccc;
    }

    .frontfooter footer {
        padding: 20px calc(1.5rem / 2);
        position: static;
        color: #000;
        height: 60px;
        background-color: #f9f9f9;
        margin-top: 30px;
        border-top: 1px solid #e1dfdf;
    }

    span.logo-sm img {
        width: 69px;
    }

    .seperatesec {
        margin-top: 20px;
    }

    .simplebar-content li.nav-item:hover {
        background: #4caf50;
    }

    .sectitle {
        font-size: 14px;
    }

    .required {
        color: red;
    }

    .customtextarea {
        height: 120px;
    }

    ul.boxsection {
        margin: 0;
        padding: 0;
    }

    ul.boxsection li {
        list-style-type: none;
        padding: 7px 0;
        border-bottom: 1px solid #efeded;
    }

    .boxcard .col:nth-child(1) {
        background: #effcfb;
    }

    .boxcard .col:nth-child(2) {
        background: #fdfdfd;
    }

    .boxcard .col:nth-child(3) {
        background: #effcfb;
    }

    .boxcard .col:nth-child(4) {
        background: #fdfdfd;
    }

    .boxcard .col:nth-child(5) {
        background: #effcfb;
    }

    /* --registration-form css  */
    .custom-tab-content {
        padding-top: 0 !important;
        padding-bottom: 0px !important;
    }

    .custom-tab-nav {
        background: white;

    }

    .custom-tab-nav .nav-link {
        border-radius: 0 !important;
        border-bottom: 1px solid #e9ebec;
        border-right: 1px solid #e9ebec;
        font-size: 14px;
        padding: 10px;
    }

    .custom-tab-nav .nav-link.active,
    .custom-tab-nav .show>.nav-link {
        color: rgb(255, 255, 255) !important;
        background-color: #2c8c6d;
        border-bottom: #2c8c6d !important;
        /* border-bottom: #207005 !important; */
        position: relative;
    }

    .custom-tab-nav .nav-link:hover,
    .custom-tab-nav .nav-link:focus {
        border-bottom: 1px solid #207005;
        border-radius: 0;
        font-size: 14px;
        transition: background-color 0.20s linear;
    }

    .custom-tab-nav .nav-link.active:after {
        content: "";
        position: absolute;
        bottom: -16px;
        left: 50%;
        border: 8px solid transparent;
        border-top-color: #2c8c6d;
        z-index: 999;
    }

    .reg-form-btns {
        margin-bottom: 15px;
    }

    .reg-form-btns .btn-secondary {
        color: #fff;
        background-color: #405189;
        border-color: #405189;
    }

    .btn-soft-success:active,
    .btn-soft-success:focus,
    .btn-soft-success:hover {
        border: none;
    }

    .custom-tab-nav ul {
        padding: 0px;
        margin: 0px;
    }

    .custom-tab-nav ul li {
        padding: 0px;
        margin: 0px;
        display: inline-block;
        list-style: none;
    }

    .has-error {
        border: 1px solid red;
    }

    .errormsg {
        color: red;
        font-size: 14px !important;
    }

    /* .row {
                --vz-gutter-x: 1.5rem;
                --vz-gutter-y: 0;
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                -ms-flex-wrap: wrap;
                flex-wrap: nowrap !important;
                margin-top: calc(-1 * var(--vz-gutter-y));
                margin-right: calc(-.5 * var(--vz-gutter-x));
                margin-left: calc(-.5 * var(--vz-gutter-x));
            } */




    /* email verification css */



    .overlay {
        background: rgb(0 0 0 / 50%);
        position: fixed;
        top: 0;
        z-index: 11111;
        left: 0;
        right: 0;
        bottom: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        display: none;
    }

    .loader {
        position: fixed !important;
        left: 50% !important;
        margin-left: -4em !important;
        top: 20em !important;
    }

    .wrapper {
        max-width: 1240px;
        margin: 0 auto;
    }

    .white-bg {
        background-color: white;
        /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
        border-bottom: 5px solid #ff9800;
        margin-bottom: 15px;
    }

    .auth-one-bg .slide .carousel-indicators {
        bottom: 25px;
    }

    .auth-page-wrapper .auth-page-content {
        padding-bottom: 0px !important;
    }

    .auth-page-content .card {
        margin-bottom: 0rem;
    }

    .data-tabs .wrapper .nav-tabs button {
        font-size: 17px;
        color: black;
    }

    .data-tabs .wrapper .nav-tabs .active {
        background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
        */ color: white;
        background: orange;
        border-radius: 0px;
    }

    .carousel-caption.d-none.d-md-block {
        background-color: #000000bf;
        left: 0;
        width: 100%;
        bottom: 0;
    }

    .carousel-indicators {
        display: none;
    }

    .custom-banner-caption {
        color: white !important;
    }

    .announcement-heading {
        font-size: 1.2em;
        font-weight: 600;
    }

    .data-tabs .tab-pane ul li {
        font-size: 1em;
        padding: 5px 0;

    }

    .main-logo {
        padding: 10px;
    }

    .data-tabs .nav-item .nav-link {
        background-image: none;
    }

    /* .right-sec{
            box-shadow: 5px 10px 18px #888888;
        } */
    .navbar-brand-box {
        background: #fff;
    }

    [data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
        color: white !important;
    }

    .header-buttons .btn-primary {
        margin-right: 10px;
        padding: 6px 15px;
        font-weight: 600;
        background-color: #207005;
        border: none;
        box-shadow: 0px 2px 7px #888888;
    }

    .header-buttons .btn-secondary {
        margin-right: 10px;
        padding: 6px 15px;
        font-weight: 600;
        background-color: #72a055;
        border: none;
        box-shadow: 0px 2px 7px #888888;
    }


    .right-sec {
        border-left: 5px solid #ede7e7;
    }

    .tabdiv {
        background: white;
        padding: 20px;
        margin-top: 10px;
        border: 10px solid #dfdbd5;
    }

    .nav-tabs {
        border-bottom: 0px;
    }

    div#myTabContent {
        border: 1px solid #cccccc;
    }

    .frontfooter footer {
        padding: 20px calc(1.5rem / 2);
        position: static;
        color: #000;
        height: 60px;
        background-color: #f9f9f9;
        margin-top: 30px;
        border-top: 1px solid #e1dfdf;
    }

    span.logo-sm img {
        width: 69px;
    }

    .seperatesec {
        margin-top: 20px;
    }

    .simplebar-content li.nav-item:hover {
        background: #4caf50;
    }

    .sectitle {
        font-size: 14px;
    }

    .required {
        color: red;
    }

    .customtextarea {
        height: 120px;
    }

    ul.boxsection {
        margin: 0;
        padding: 0;
    }

    ul.boxsection li {
        list-style-type: none;
        padding: 7px 0;
        border-bottom: 1px solid #efeded;
    }

    .boxcard .col:nth-child(1) {
        background: #effcfb;
    }

    .boxcard .col:nth-child(2) {
        background: #fdfdfd;
    }

    .boxcard .col:nth-child(3) {
        background: #effcfb;
    }

    .boxcard .col:nth-child(4) {
        background: #fdfdfd;
    }

    .boxcard .col:nth-child(5) {
        background: #effcfb;
    }

    /* --registration-form css  */
    .custom-tab-content {
        padding-top: 0 !important;
        padding-bottom: 0px !important;
    }

    .custom-tab-nav {
        background: white;

    }

    .custom-tab-nav .nav-link {
        border-radius: 0 !important;
        border-bottom: 1px solid #e9ebec;
        border-right: 1px solid #e9ebec;
        font-size: 14px;
        padding: 10px;
    }

    .custom-tab-nav .nav-link.active,
    .custom-tab-nav .show>.nav-link {
        color: rgb(255, 255, 255) !important;
        background-color: #2c8c6d;
        border-bottom: #2c8c6d !important;
        /* border-bottom: #207005 !important; */
        position: relative;
    }

    .custom-tab-nav .nav-link:hover,
    .custom-tab-nav .nav-link:focus {
        border-bottom: 1px solid #207005;
        border-radius: 0;
        font-size: 14px;
        transition: background-color 0.20s linear;
    }

    .custom-tab-nav .nav-link.active:after {
        content: "";
        position: absolute;
        bottom: -16px;
        left: 50%;
        border: 8px solid transparent;
        border-top-color: #2c8c6d;
        z-index: 999;
    }

    .reg-form-btns {
        margin-bottom: 15px;
    }

    .reg-form-btns .btn-secondary {
        color: #fff;
        background-color: #405189;
        border-color: #405189;
    }

    .btn-soft-success:active,
    .btn-soft-success:focus,
    .btn-soft-success:hover {
        border: none;
    }

    .custom-tab-nav ul {
        padding: 0px;
        margin: 0px;
    }

    .custom-tab-nav ul li {
        padding: 0px;
        margin: 0px;
        display: inline-block;
        list-style: none;
    }

    /* -------  */
    .btn-email {
        font-size: 13px;
        padding: 1px 7px;
        line-height: 17px;

    }

    .btn-mailsend {
        font-size: 13px;
        padding: 1px 7px;
        line-height: 17px;
    }

    .btn-verify {
        font-size: 13px;
        padding: 1px 7px;
        line-height: 34px;
    }

    .inputEmail .input-group-append {
        display: flex;
        align-items: end;
    }

    .inputEmail .validateEmailId {
        border-radius: 4px 0 0 4px;
    }

    .input-group-append .verifiEmail_otp,
    .input-group-append .resendEmail_otp {
        margin-left: 10px;
    }

    .login-pass.otp-email {
        margin-top: 5px
    }

    .login-pass.otp-email .inp-b {
        border-radius: 0 4px 4px 0
    }

    /* end */
</style>
<div class="overlay">
    <div class="loader"></div>
</div>
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">उत्पादक समूह प्रोफ़ाइल/Grower GroupProfile </h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Grower Group Profile</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <form method="post" id="warehousefrm" action="{{ route('superadmin.icsuser.step6post', $userdetails->id) }}" enctype="multipart/form-data">
            @csrf
            <input type="hidden" name="roleid" value="{{ $userdetails->ref_operator_type_id }}">
            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">
                    <a class="nav-link" href="{{ route('superadmin.icsuser.step1', $userdetails->id) }}">General
                        Information</a>
                    <a class="nav-link" href="{{ route('superadmin.icsuser.step2', $userdetails->id) }}">Self/Service Provider
                        Details</a>

                    <a class="nav-link" href="{{ route('superadmin.icsuser.step4', $userdetails->id) }}">Internal Inspector
                        Details</a>
                    <a class="nav-link" href="{{ route('superadmin.icsuser.step5', $userdetails->id) }}">Warehouse/Godown
                    </a>
                    <a class="nav-link active" id="step6-tab" data-bs-toggle="tab" href="{{ route('superadmin.icsuser.step6', $userdetails->id) }}">Grower Group Official Details</a>
                    <a class="nav-link" href="{{ route('superadmin.icsuser.step3', $userdetails->id) }}">Farmer
                        Details</a>
                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step6">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            {{-- <h4 class="card-title mb-0 flex-grow-1"> Official Details
                                </h4> --}}
                            <div class="flex-shrink-0">
                                @if (session('error'))
                                <div class="alert alert-danger">
                                    {{ session('error') }}
                                </div>
                                @endif
                                @if (session('success'))
                                <div class="alert alert-success">
                                    {{ session('success') }}
                                </div>
                                @endif

                            </div>
                        </div>

                       <div class="card-body">
                               <!---Details of ICS Manager-->
                               <div class="row seperatesec white-inner">
                                        <label for="labelInput" class="form-label blue-ht">
                                            उत्पादक समूह प्रबंधक का विवरण/Details of Grower Group Manager
                                        </label>
                                        <div class="col-xxl-2 col-md-2  ">
                                            <div>
                                                <label for="labelInput" class="form-label">पहला नाम/First Name <span></span></label>
                                                <input type="text" class="form-control" id="placeholderInput" placeholder="First name" value="{{ $userdetails->contact_person_first_name }}" readonly />
                                                <!-- <input type="text" class="form-control" id="placeholderInput" placeholder="First name" name="pm_name[]" value="{{ $userdetails->contact_person_first_name }}" readonly /> -->
                                            </div>
                                        </div>
                                        <div class="col-xxl-2 col-md-2  ">
                                            <div>
                                                <label for="labelInput" class="form-label">मध्य नाम/Middle Name </label>

                                                <input type="text" class="form-control" id="placeholderInput" placeholder="Middle name" value="{{ $userdetails->contact_person_middle_name }}" readonly />
                                                <!-- <input type="text" class="form-control" id="placeholderInput" placeholder="Middle name" name="pm_middle_name[]" value="{{ $userdetails->contact_person_middle_name }}" readonly /> -->
                                            </div>
                                        </div>
                                        <div class="col-xxl-2 col-md-2  ">
                                            <div>
                                                <label for="labelInput" class="form-label">अंतिम नाम/Last Name<span></span></label>

                                                <input type="text" class="form-control" id="placeholderInput" placeholder="Last name" value="{{ $userdetails->contact_person_last_name }}" readonly />
                                                <!-- <input type="text" class="form-control" id="placeholderInput" placeholder="Last name" name="pm_last_name[]" value="{{ $userdetails->contact_person_last_name }}" readonly /> -->
                                            </div>
                                        </div>


                                        <div class="col-xxl-2 col-md-3  ">
                                            <div>
                                                <label for="labelInput" class="form-label">संपर्क नंबर/Contact No. <span></span> </label>
                                                <input type="text" class="form-control numbersonly" maxlength="10" id="placeholderInput" placeholder="Contact Number"  onblur="phonenumber(this)" readonly value="{{ $userdetails->contact_person_mobile_number }}" />
                                                <!-- <input type="text" class="form-control numbersonly" maxlength="10" id="placeholderInput" placeholder="Contact Number" name="pm_mobile_no[]" onblur="phonenumber(this)" readonly value="{{ $userdetails->contact_person_mobile_number }}" /> -->
                                            </div>
                                        </div>

                                        <div class="col-xxl-2 col-md-3  ">
                                            <div>
                                                <label for="labelInput" class="form-label">ईमेल आईडी/Email<span></span></label>
                                                <input type="text" class="form-control " maxlength="12" id="placeholderInput" placeholder="Email" value="{{ $userdetails->contact_person_email }}"  readonly />
                                                <!-- <input type="text" class="form-control " maxlength="12" id="placeholderInput" placeholder="Email" value="{{ $userdetails->contact_person_email }}" name="contact_person_email[]" readonly /> -->
                                            </div>
                                        </div>

                                        <div class="col-xxl-2 col-md-3  ">
                                                   @php
                                                        $maskedAadhar = '';
                                                        try {
                                                            if ($userdetails->contact_person_aadhar_number) {
                                                                $decryptedAadhar = Crypt::decrypt(
                                                                    $userdetails->contact_person_aadhar_number,
                                                                );
                                                                $maskedAadhar = maskAadhaarNumber($decryptedAadhar);
                                                            }
                                                        } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
                                                            $maskedAadhar = 'Invalid Aadhaar Number';
                                                        }

                                                        
                                                    @endphp

                                            <div>
                                                <label for="labelInput" class="form-label">आधार/Aadhaar No.<span></span></label>
                                                <input type="hidden" class="form-control numbersonly" maxlength="12" id="placeholderInput" value=" @if($userdetails->contact_person_aadhar_number) {{Crypt::decrypt($userdetails->contact_person_aadhar_number ?? '' ) }} @else @endif" placeholder="Aadhaar Number"/>
                                                <!-- <input type="hidden" class="form-control numbersonly" maxlength="12" id="placeholderInput" value="{{Crypt::decrypt($userdetails->contact_person_aadhar_number) ?? ''}}" placeholder="Aadhaar Number" name="pm_aadhar[]"  /> -->
                                                <!-- only show aadhaar  -->
                                                <input type="text" class="form-control numbersonly" maxlength="12" id="placeholderInput" value="{{$maskedAadhar}}" placeholder="Aadhaar Number"  readonly />
                                            </div>
                                        </div>
                                        <div class="col-xxl-2 col-md-3 gy-3 ">
                                            <div>
                                                <label for="labelInput" class="form-label">पद/Designation</label>

                                                <select name="contact_designation" class="form-control" disabled readonly>
                                                    <!-- <option value="">Select Designation</option> -->
                                                    <option value="ICS Manager" {{($userdetails->contact_designation=='ICS Manager' ? 'selected':'')}}>ICS Manager </option>

                                                </select>

                                            </div>
                                        </div>

                                        <div class="col-xxl-2 col-md-3 gy-3">
                                            <div>
                                                <label for="basiInput" class="form-label"> पता प्रमाण/Address proof <span></span></label>
                                                        <input type="hidden" value="{{$userdetails->address_proof_of_office ?? ''}}" name="address_proof_of_office">
                                                <select class="form-select" name="address_proof_of_office" id="address_proof_of_office" disabled readonly>

                                                    <option value="rent_agreement" {{ isset($userdetails) && $userdetails->address_proof_of_office == 'rent_agreement' ? 'selected' : '' }}>
                                                        Rent Agreement</option>
                                                </select>

                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-4 gy-3 address_proof_doc">
                                            <div>
                                                <label class="form-label">पता प्रमाण दस्तावेज/Address Proof Document</label>
                                                <div>
                                                    @if (!empty($userdetails->address_proof_of_office_doc))
                                                    <a target="_BLANK" href="{{ asset('public/ics/address_proof_of_office_doc/' . $userdetails->address_proof_of_office_doc) }}" class="text-decoration-underline">See Document</a>
                                                    @endif
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xxl-1 col-md-1  " style="margin-top:0.7%!important">
                                            <div>

                                                {{-- <label for="labelInput" class="form-label">Contact Number  <span
                                                            class="required">*</span> </label> --}}
                                                <!-- <i data-type="pm"
                                                            class="mdi mdi-plus btn btn-soft-success rowAdder3"
                                                            data-toggle="tooltip" title="Add Row"></i> -->
                                            </div>
                                        </div>

                                    </div>
                                    <!---Details of ICS Manager End-->
                       </div>
                        <div class="card-body">
                            <div class="live-preview">


                                <input type="hidden" name="at_ics_warehouse_details_id" value="{{ $warehs->id ?? '' }}">
                              
                             
                                    @forelse($pmanager as $key=> $pm)
                                  
                                    <!-- upm ---use table ID most import  modal name UserWarehouseManagerOfficers -->
                                    <input type="hidden" name="pm_id[]" value="{{ $pm->id }}" />
                                    <!-- end -->
                                   
                                    <div class="row white-inner" id="maindiv_{{ $pm->id }}">
                                        @if ($key == 0)
                                        <label for="labelInput" class="form-label blue-ht">
                                            खरीद प्रबंधक का विवरण/Details Of Purchase Manager
                                        </label>
                                        <div class="row">
                                            <div class="col-xxl-12 col-md-12">
                                                <i data-type="pm" class="mdi mdi-plus btn btn-soft-success rowAdder2" data-toggle="tooltip" title="Add Row" style="float:right"></i>
                                            </div>
                                        </div>
                                        @endif
                                        <div class="col-xxl-2 col-md-2  ">
                                            <div>
                                                <label for="labelInput" class="form-label">पहला नाम/First Name<span class="required">*</span> </label>
                                                <input type="text" class="form-control" id="placeholderInput" placeholder="First name" name="pm_name[]" value="{{ $pm->first_name ?? '' }}" required />
                                            </div>
                                        </div>
                                        <div class="col-xxl-2 col-md-2  ">
                                            <div>
                                                <label for="labelInput" class="form-label">मध्य नाम/Middle Name </label>

                                                <input type="text" class="form-control" id="placeholderInput" placeholder="Middle name" name="pm_middle_name[]" value="{{ $pm->middle_name ?? '' }}" />
                                            </div>
                                        </div>
                                        <div class="col-xxl-2 col-md-2  ">
                                            <div>
                                                <label for="labelInput" class="form-label">अंतिम नाम/Last Name<span class="required">*</span></label>

                                                <input type="text" class="form-control" id="placeholderInput" placeholder="Last name" name="pm_last_name[]" value="{{ $pm->last_name ?? '' }}" required />
                                            </div>
                                        </div>
                                       
                                        <div class="col-xxl-3 col-md-2 ">
                                           @php
                                            $maskedAadhar1= '';
                                            try {
                                                if (!empty($pm->aadhar_card_number)  || preg_match('/^eyJpdiI6.*$/',$pm->aadhar_card_number)) {
                                                    $decryptedssAadhar = Crypt::decrypt($pm->aadhar_card_number);
                                                    $maskedAadhar1 = maskAadhaarNumber($decryptedssAadhar);
                                                }
                                            } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
                                                $maskedAadhar1 = 'Invalid Aadhaar Number';
                                            }
                                            @endphp
                                            <div>
                                                 
                                                <label for="labelInput" class="form-label">आधार/Aadhaar No.<span class="required">*</span></label>
                                                @if(!empty($pm->aadhar_card_number))
                                                 <!-- on store aadhar card  aaddhar card -->
                                                <input type="hidden" class="form-control numbersonly" maxlength="12" id="placeholderInput" placeholder="Aadhaar Number" name="pm_aadhar[]" value="{{Crypt::decrypt($pm->aadhar_card_number)}}" readonly/>
                                                <!-- on show  aaddhar card -->
                                                <input type="text" class="form-control numbersonly" maxlength="12" id="placeholderInput" placeholder="Aadhaar Number"  value="{{ $maskedAadhar1 }}" readonly/>
                                                @else
                                                <input type="text" class="form-control numbersonly" maxlength="12" id="placeholderInput" placeholder="Aadhaar Number"  value=" " onblur="checkAadhaarNo(this.value, this)" required />
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-xxl-2 col-md-3">
                                            <div>
                                                <label for="labelInput" class="form-label">Contacts Number <span class="required">*</span></label>
                                                <input type="text" class="form-control numbersonly" maxlength="10" id="placeholderInput" placeholder="Contact Number" onblur="phonenumber(this)" name="pm_mobile_no[]" value="{{ $pm->contact_number }}" required />
                                            </div>
                                        </div>
                                        <div class="col-xxl-1 col-md-1" style="margin-top: 2.3% !important">
                                            <i data-type="pm" data-id="{{ $pm->id }}" class="mdi mdi-delete btn btn-soft-danger dngr" data-toggle="tooltip" title="Add Row"></i>
                                        </div>
                                    </div>
                                    @empty
                                  
                                    <div class="row seperatesec white-inner">
                                        <label for="labelInput" class="form-label blue-ht">
                                            खरीद प्रबंधक का विवरण/ Details of Purchase Manager
                                        </label>
                                        <div class="col-xxl-2 col-md-2  ">
                                            <div>
                                                <label for="labelInput" class="form-label">पहला नाम/First Name <span class="required">*</span></label>
                                                <input type="text" class="form-control" id="placeholderInput" placeholder="First name" name="pm_name[]" required />
                                            </div>
                                        </div>
                                        <div class="col-xxl-2 col-md-2  ">
                                            <div>
                                                <label for="labelInput" class="form-label">मध्य नाम/Middle Name </label>

                                                <input type="text" class="form-control" id="placeholderInput" placeholder="Middle name" name="pm_middle_name[]" value="" />
                                            </div>
                                        </div>
                                        <div class="col-xxl-2 col-md-2  ">
                                            <div>
                                                <label for="labelInput" class="form-label">अंतिम नाम/Last Name<span class="required">*</span></label>

                                                <input type="text" class="form-control" id="placeholderInput" placeholder="Last name" name="pm_last_name[]" value="" required />
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-2  ">
                                            <div>
                                                <label for="labelInput" class="form-label">आधार/Aadhaar No.<span class="required">*</span></label>
                                                <input type="text" class="form-control numbersonly" maxlength="12" id="placeholderInput" placeholder="Aadhaar Number" name="pm_aadhar[]" onblur="checkAadhaarNo(this.value, this)" required />
                                            </div>
                                        </div>
                                        <div class="col-xxl-2 col-md-3  ">
                                            <div>
                                                <label for="labelInput" class="form-label">संपर्क नंबर/Contact No. <span class="required">*</span> </label>
                                                <input type="text" class="form-control numbersonly" maxlength="10" id="placeholderInput" placeholder="Contact Number" name="pm_mobile_no[]" onblur="phonenumber(this)" required />
                                            </div>
                                        </div>
                                        <div class="col-xxl-1 col-md-1  " style="margin-top:0.7%!important">
                                            <div>
                                                <br>
                                                {{-- <label for="labelInput" class="form-label">Contact Number  <span
                                                            class="required">*</span> </label> --}}
                                                <i data-type="pm" class="mdi mdi-plus btn btn-soft-success rowAdder3" data-toggle="tooltip" title="Add Row"></i>
                                            </div>
                                        </div>

                                       </div>
                                    @endforelse
                                    <div id="pmmanager"> </div>

                                  


                    <div id="fomanager">
                        @forelse($foanager as $key=> $fo)
                     <!-- hidden case  update by ID    modal name [UserWarehouseManagerOfficers]-->           
                        <input type="hidden" value="{{$fo->id}}" name="fo_id[]">
                        <!-- hidden case -->
                           
                        <div class="row {{ $key==0 ?'seperatesec':''}} white-inner" id="maindiv_{{ $fo->id }}">
                            @if ($key == 0)
                            <label for="labelInput" class="form-label blue-ht">
                                फील्ड अधिकारी का विवरण/Details of Field Officers
                            </label>

                            <div class="row">

                                <div class="col-xxl-12 col-md-12">
                                    <i data-type="fo" class="mdi mdi-plus btn btn-soft-success rowAdder2" data-toggle="tooltip" title="Add Row" style="float:right"></i>
                                </div>
                            </div>
                            @endif
                            <div class="col-xxl-2 col-md-2  ">
                                <div>
                                    <label for="labelInput" class="form-label">पहला नाम/First Name <span class="required">*</span></label>
                                    <input type="hidden" name="fo_id[]" value="{{ $fo->id }}" />
                                    <input type="text" class="form-control" id="placeholderInput" placeholder="First name" name="fo_name[]" value="{{ $fo->first_name }}" required />
                                </div>
                            </div>
                            <div class="col-xxl-2 col-md-2  ">
                                <div>
                                    <label for="labelInput" class="form-label">मध्य नाम/Middle Name
                                    </label>

                                    <input type="text" class="form-control" id="placeholderInput" placeholder="Middle name" name="fo_middle_name[]" value="{{ $fo->middle_name }}" />
                                </div>
                            </div>
                            <div class="col-xxl-2 col-md-2  ">
                                <div>
                                    <label for="labelInput" class="form-label">अंतिम नाम/Last Name<span class="required">*</span></label>

                                    <input type="text" class="form-control" id="placeholderInput" placeholder="Last name" name="fo_last_name[]" value="{{ $fo->last_name }}" required />
                                </div>
                            </div>

                            <div class="col-xxl-3 col-md-2  ">
                                <div>
                                @php
                                    $maskedAadhar2 = '';
                                    try {
                                        if (!empty($fo->aadhar_card_number) || preg_match('/^eyJpdiI6.*$/',$userdetails->aadhar_card_number)) {
                                            $decryptedssAadhar = Crypt::decrypt($fo->aadhar_card_number);
                                            $maskedAadhar2 = maskAadhaarNumber($decryptedssAadhar);
                                        }
                                    } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
                                        $maskedAadhar2 = 'Invalid Aadhaar Number';
                                    }
                                    @endphp
                                    <label for="labelInput" class="form-label">आधार/Aadhaar No.<span class="required">*</span>
                                    </label>
                                    @if(!empty($fo->aadhar_card_number))
                                    <input type="hidden" class="form-control numbersonly" maxlength="12" id="placeholderInput" placeholder="Aadhaar Number" name="fo_aadhar[]" value="@php try { $aadhar = Crypt::decrypt($fo->aadhar_card_number); } catch (\Illuminate\Contracts\Encryption\DecryptException $e) { $aadhar = '123456789123';  echo $aadhar; } @endphp"/>
                                    <input type="text" class="form-control numbersonly" value="{{ $maskedAadhar2 }}"  readonly/>
                                    @else
                                    @endif
                                </div>
                            </div>
                            <div class="col-xxl-2 col-md-3  ">
                                <div>
                                    <label for="labelInput" class="form-label">संपर्क नंबर/Contact No.<span class="required">*</span>
                                    </label>
                                    <input type="text" class="form-control numbersonly" maxlength="10" id="placeholderInput" placeholder="Contact Number" name="fo_mobile_no[]" value="{{ $fo->contact_number }}" onblur="phonenumber(this)" required />
                                </div>
                            </div>
                            <div class="col-xxl-1 col-md-1" style="margin-top: 2.3% !important">
                                <i data-type="fo" data-id="{{ $fo->id }}" class="mdi mdi-delete btn btn-soft-danger dngr" data-toggle="tooltip" title="Add Row"></i>
                            </div>
                        </div>
                        @empty
                    
                        <div class="row seperatesec white-inner">
                            <label for="labelInput" class="form-label blue-ht">
                                फील्ड अधिकारी का विवरण/Details of Field Officers
                            </label>
                            <div class="col-xxl-2 col-md-2  ">
                                <div>
                                    <label for="labelInput" class="form-label">पहला नाम/First Name <span class="required">*</span></label>
                                    <input type="text" class="form-control" id="placeholderInput" placeholder="First Name " name="fo_name[]" required />
                                </div>
                            </div>
                            <div class="col-xxl-2 col-md-2  ">
                                <div>
                                    <label for="labelInput" class="form-label">मध्य नाम/Middle Name
                                    </label>

                                    <input type="text" class="form-control" id="placeholderInput" placeholder="Middle name" name="fo_middle_name[]" value="" />
                                </div>
                            </div>
                            <div class="col-xxl-2 col-md-2  ">
                                <div>
                                    <label for="labelInput" class="form-label">अंतिम नाम/Last Name<span class="required">*</span></label>

                                    <input type="text" class="form-control" id="placeholderInput" placeholder="Last name" name="fo_last_name[]" value="" required />
                                </div>
                            </div>
                            <div class="col-xxl-3 col-md-2  ">
                                <div>
                                    <label for="labelInput" class="form-label">आधार/Aadhaar No.
                                    </label><span class="required">*</span>
                                    <input type="text" class="form-control numbersonly" maxlength="12" id="placeholderInput" placeholder="Aadhaar Number" name="fo_aadhar[]" required />
                                </div>
                            </div>
                            <div class="col-xxl-2 col-md-3  ">
                                <div>
                                    <label for="labelInput" class="form-label">संपर्क नंबर/Contact No.
                                    </label><span class="required">*</span>
                                    <input type="text" class="form-control numbersonly" maxlength="10" id="placeholderInput" placeholder="Contact Number" name="fo_mobile_no[]" onblur="phonenumber(this)" required />
                                </div>
                            </div>
                            <div class="col-xxl-1 col-md-1" style="margin-top: 2.5% !important">
                                <i data-type="fo" class="mdi mdi-plus btn btn-soft-success rowAdder2" data-toggle="tooltip" title="Add Row"></i>
                                <!-- <i data-type="fo" class="mdi mdi-delete btn btn-soft-danger" data-toggle="tooltip" title="Add Row"></i> -->
                            </div>
                        </div>
                        @endforelse
                        <div class="row ">
                            {{-- <div class="col-xxl-2 col-md-2  "></div>
                                                <div class="col-xxl-2 col-md-2  "></div>
                                                <div class="col-xxl-3 col-md-3  "></div>
                                                <div class="col-xxl-1 col-md-1">
                                                    <i data-type="fo" class="mdi mdi-plus btn btn-soft-success rowAdder2"
                                                        data-toggle="tooltip" title="Add Row"></i>
                                                </div> --}}
                        </div>
                    </div>

                    <br>
                    @if ($errors)
                    @foreach ($errors->all() as $error)
                    <div class="alert alert-danger">{{ $error }}</div>
                    @endforeach
                    @endif


                    <div id="ammanager">


                        <input type="hidden" name="am_id" value="{{ $amanager->id ?? '' }}" />

                        <div class="row seperatesec white-inner">
                            <label for="labelInput" class="form-label blue-ht">
                                अनुमोदन प्रबंधक/समिति का विवर/ Details of Approval Manager/Committee
                            </label>
                            <div class="col-xxl-3 col-md-3 ">
                                <div>
                                    <label for="labelInput" class="form-label">पहला नाम/First Name <span class="required">*</span></label>
                                    <input type="text" class="form-control" id="placeholderInput" placeholder="First Name" name="am_name" value="{{ $amanager->first_name ?? '' }}" required />
                                </div>
                            </div>
                            <div class="col-xxl-3 col-md-2  ">
                                <div>
                                    <label for="labelInput" class="form-label">मध्य नाम/Middle Name </label>

                                    <input type="text" class="form-control" id="placeholderInput" placeholder="Middle Name" name="am_middle_name" value="{{ $amanager->middle_name ?? '' }}" />
                                </div>
                            </div>
                            <div class="col-xxl-3 col-md-3  ">
                                <div>
                                    <label for="labelInput" class="form-label">अंतिम नाम/Last Name<span class="required">*</span></label>

                                    <input type="text" class="form-control" id="placeholderInput" placeholder="Last Name" name="am_last_name" value="{{ $amanager->last_name ?? '' }}" required />
                                </div>
                            </div>
                            <!-- <div class="col-xxl-2 col-md-2 ">
                                                            <div>
                                                                <label for="labelInput" class="form-label">Email ID<span
                                                                    class="required">*</span></label>
                                                                <input type="email" class="form-control" id="placeholderInput" placeholder="Email Id" name="email" value="{{ $amanager->email_id ?? '' }}" required {{ isset($amanager->email_id) ? 'readonly' : '' }}/>
                                                            </div>
                                                        </div> -->

                            <!-- code by sandeep -->

                            <div class="col-xxl-3 col-md-4 ">
                                <div class="inputEmail  col-12 col-sm-12 col-md-12 col-lg-12">
                                    <div class="form-group d-flex justify-content-center ge-otp-form">
                                        <div class="col-12 col-sm-12 col-md-10 col-lg-10">
                                            <label>ईमेल आईडी/Email ID<span class="text-danger">*</span></label>
                                            <input class="form-control validateEmailId col-12 col-sm-12 col-md-12 col-lg-12" type="text" required name="email_id" value="{{ $amanager->email_id ?? '' }}" id="email_id1" placeholder="Email Id" {{ isset($amanager->email_id) ? 'readonly' : '' }} />
                                        </div>
                                        <div class="input-group-append col-12 col-sm-12 col-md-2 col-lg-2">
                                            @if (!isset($amanager->email_id))
                                            <button type="button" class="btn-email btn btn-outline-success waves-effect waves-light visitorCat2">OTP प्राप्त करें/Get
                                                OTP</button>
                                            @endif
                                            <button type="button" class="btn btn-ghost-success waves-effect waves-light btn-mailsend" style="display:none">Mail Send</button>
                                            <button type="button" class="btn btn-ghost-success waves-effect waves-light btn-verify" style="display:none">Verified</button>
                                        </div>
                                    </div>
                                    <div class="verify-email justify-content-center">
                                        <div class="login-pass mb-4 otp-email col-12 col-sm-12 col-md-5 col-lg-12 pl-2" style="display:none">
                                            <div class="input-group">
                                                <span class="input-group-text mdi mdi-key" id="inputGroup-sizing-default"></span>
                                                <input type="text" class="form-control inp-b" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" id="email_otp1">
                                                <div class="input-group-append">
                                                    <a href="javascript:void(0)" class="verifiEmail_otp btn btn-outline-success waves-effect waves-light">Verify</a>
                                                    <a href="javascript:void(0)" class="resendEmail_otp btn btn-outline-danger waves-effect waves-light">Resend</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <!-- end -->
                            <div class="col-xxl-3 col-md-3 mt-2">
                                <div>
                                @php

                                    $maskedAadhar1 = '';
                                    if(isset($amanager)){
                                    try {
                                     
                                        if (!empty($amanager->aadhar_card_number) || preg_match('/^eyJpdiI6.*$/', $amanager->aadhar_card_number)) {
                                            $decryptedssAadhar = Crypt::decrypt($amanager->aadhar_card_number);
                                            $maskedAadhar1 = maskAadhaarNumber($decryptedssAadhar);
                                        } else {
                                            $maskedAadhar1 = 'Aadhaar not available';
                                        }
                                    } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
                                        $maskedAadhar1 = 'Invalid Aadhaar Number';
                                    }
                                  }
                                  @endphp

                                    <label for="labelInput" class="form-label">आधार/Aadhaar No.<span class="required">*</span></label>
                                    @if(!empty($amanager->aadhar_card_number))
                                    <input type="hidden" class="form-control numbersonly" maxlength="12" id="placeholderInput" placeholder="Aadhaar Number" name="am_aadhar" value="@php try { $aadhar = Crypt::decrypt($amanager->aadhar_card_number); } catch (\Illuminate\Contracts\Encryption\DecryptException $e) { $aadhar = '123456789123';  echo $aadhar;} @endphp"   onblur="checkAadhaarNo(this.value, this)"/>
                                    <input type="text" class="form-control numbersonly" maxlength="12" id="placeholderInput" placeholder="Aadhaar Number"  value="{{ $maskedAadhar1 }}" readonly/>
                                  @else
                                    <input type="text" class="form-control numbersonly" maxlength="12" id="placeholderInput" placeholder="Aadhaar Number"  name="am_aadhar" value="" required  onblur="checkAadhaarNo(this.value, this)"/>
                                    @endif
                                </div>
                            </div>
                            <div class="col-xxl-3 col-md-3 mt-2">
                                <div>
                                    <label for="labelInput" class="form-label">संपर्क नंबर/Contact No.<span class="required">*</span>
                                    </label>
                                    <input type="text" class="form-control numbersonly" maxlength="10" id="placeholderInput" placeholder="Contact number" onblur="phonenumber(this)" name="am_mobile_no" value="{{ $amanager->contact_number ?? '' }}" required />
                                </div>
                            </div>
                            <div class="col-xxl-1 col-md-2" style="margin-top: 4.5% !important">
                                <!-- <i data-type="am" class="mdi mdi-delete btn btn-soft-danger" data-toggle="tooltip" title="Add Row"></i> -->
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12 gy-4">
                            <div class="hstack gap-2">
                                <a href="{{ route('superadmin.icsuser.step5', $userdetails->id) }}" class="btn btn-soft-success">Back</a>
                                <button type="submit" class="btn btn-primary" id="submitbtn">Save & Next</button>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
    </div>
</div>
</form>
</div>
</div>
@endsection
@push('script')
<script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>

<script>
    $(".btn-email").click(function(e) {
        e.preventDefault();
        var user_email = $('#email_id1').val();
        $(".overlay").show();

        if (user_email != "") {
            $.ajax({
                type: 'POST',
                url: "{{ route('superadmin.usermanagement.email_mobile_OTP') }}",
                data: {
                    'user_email': user_email
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(resp) {
                    if (resp == 1) {

                        Swal.fire({
                            text: "Please verify OTP send on Email id",
                            icon: 'success',
                            confirmButtonText: 'OK'
                        }).then((result) => {
                            $('.otp-email').show(500);
                            $('#email_id1').val(user_email);
                            $('#email_id1').prop('readonly', true);
                            $('.btn-email').hide(500);
                            $('.btn-mailsend').show(100);
                        });

                    }
                    $(".overlay").hide();
                }
            });
        } else {
            Swal.fire("", "Please enter Email ID", "error");
        }
    });


    $(".verifiEmail_otp").click(function(e) {
        e.preventDefault();
        var email_otp = $('#email_otp1').val();
        $(".overlay").show();
        if (email_otp != "") {

            $.ajax({
                type: 'POST',
                url: "{{ route('superadmin.usermanagement.email_mobile_OTP_check') }}",
                data: {
                    'email_otp': email_otp
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(html) {
                    if (html == 0) {
                        Swal.fire("", "Please enter Valid OTP", "error");
                    } else {
                        $('#email_otp').prop('readonly', true);
                        $('.otp-email1').hide(500);
                        $('.btn-email').hide(500);
                        $('.btn-verify').show(500);
                        $('.visitorCat').hide(500);
                        $('.visitorCat1').hide(500);
                        $('.user_detail_page').show(500);
                        $('#email_id').prop('readonly', true);
                        $('.btn-mailsend').hide();
                        $('.login-pass').hide();
                    }
                    $(".overlay").hide();
                }
            });
        } else {
            Swal.fire("", "Please enter OTP", "error");
        }
    });

    $(".resendEmail_otp").click(function(e) {
        e.preventDefault();
        var user_email = $('#email_id1').val();

        $.ajax({
            type: 'POST',
            url: "{{ route('superadmin.usermanagement.email_mobile_OTP') }}",
            data: {
                'user_email': user_email
            },
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(html) {
                Swal.fire("", "Re OTP Send!!", "success");
            }
        });
    });
</script>
<script>
    function phonenumber(inputtxt) {
        var phoneno = /^\d{10}$/;
        if (inputtxt.value.match(phoneno)) {
            return true;
        } else {
            Swal.fire('', 'Please enter a valid mobile number.', 'warning');
            // $("#mobile").val('');
            $(inputtxt).val('');

            return false;
        }
    }

    $(document).on('click', '#submitbtn', function() {
        if (checkValidation("warehousefrm")) {
            $('#warehousefrm').submit();
            return true;
        } else {
            return false;
        }
    });
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    // Dropzone has been added as a global variable.

    $('.dropzone').each(function() {
        var options = $(this).attr('id');
        $(this).dropzone({
            url: "{{ route('storeMedia') }}",
            paramName: "file",
            maxFilesize: 2,
            maxFiles: 1,
            acceptedFiles: ".jpeg,.jpg,.png,.mp4,.webm,.html5",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            init: function() {
                var drop = this; // Closure
                this.on('error', function(file, errorMessage) {
                    if (errorMessage.indexOf('Error 404') !== -1) {
                        var errorDisplay = document.querySelectorAll(
                            '[data-dz-errormessage]');
                        errorDisplay[errorDisplay.length - 1].innerHTML =
                            'Error 404: The upload page was not found on the server';
                    }
                    if (errorMessage.indexOf('File is too big') !== -1) {
                        alert('Unable to upload image size is greated than 2 MB');
                        // i remove current file
                        drop.removeFile(file);
                    }
                });
                this.on("maxfilesexceeded", function(file) {
                        this.removeAllFiles();
                        this.addFile(file);
                    }),
                    this.on("success", function(file, response) {
                        console.log(response);
                        var hiddenImage = $('<input type="hidden" name="_hidden_' + options +
                            '" value="' +
                            response.name + '"/>');
                        $('#hidden_' + options).html(hiddenImage);
                    })
            }
        });
    });

    $(".rowAdder").click(function() {
        var tp = $(this).attr("data-type");
        newRowAdd =
            '<div class="row white-inner spc1"><div class="col-xxl-2 col-md-2 "><div><label for="labelInput" class="form-label">Name</label><input type="text" class="form-control" id="placeholderInput" placeholder="name" name="am_name[]"></div></div><div class="col-xxl-3 col-md-2 "><div><label for="labelInput" class="form-label">Aadhaar Number</label><input type="text" class="form-control numbersonly" maxlength="12" id="placeholderInput" placeholder="Aadhaar Number" name="am_aadhar[]"></div></div><div class="col-xxl-2 col-md-3 "><div><label for="labelInput" class="form-label">Contact Number</label><input type="text" class="form-control numbersonly" maxlength="10" id="placeholderInput" placeholder="Contact number" onblur="phonenumber(this)" name="am_mobile_no[]"></div></div><div class="col-xxl-1 col-md-1" style="margin-top:4.5%!important"><i class="mdi mdi-delete btn btn-soft-danger remove-corp" title="delete Row"></i></div></div>';
        $('#' + tp + 'manager').append(newRowAdd);
    });
    $(document).ready(function() {
        $("body").on("click", ".remove-corp", function() {
            $(this).parents(".spc1").remove();
        });
    });

    $(".rowAdder2").click(function() {
        var tp = $(this).attr("data-type");
        newRowAdd =
            '<div class="row white-inner spc2"><div class="col-xxl-2 col-md-2 "><div><label for="labelInput" class="form-label">First Name<span class="required">*</span></label><input type="text" class="form-control" id="placeholderInput" placeholder="First Name" name="fo_name[]" required></div></div><div class="col-xxl-2 col-md-2  "><div> <label for="labelInput" class="form-label">Middle Name </label><input type="text" class="form-control" id="placeholderInput" placeholder="Middle Name" name="fo_middle_name[]" value="" /></div></div><div class="col-xxl-2 col-md-2  "><div><label for="labelInput" class="form-label">Last Name<span class="required">*</span></label><input type="text" class="form-control" id="placeholderInput" placeholder="Last Name" name="fo_last_name[]" value="" required/></div></div><div class="col-xxl-3 col-md-2 "><div><label for="labelInput" class="form-label">Aadhaar Number<span class="required">*</span></label><input type="text" class="form-control numbersonly" maxlength="12" id="placeholderInput" placeholder="Aadhaar Number" name="fo_aadhar[]" onblur="checkAadhaarNo(this.value, this)" required></div></div><div class="col-xxl-2 col-md-3 "><div><label for="labelInput" class="form-label">Contact Number<span  class="required">*</span></label><input type="text" class="form-control numbersonly" maxlength="10" id="placeholderInput" placeholder="Contact Number" onblur="phonenumber(this)" name="fo_mobile_no[]" required></div></div><div class="col-xxl-1 col-md-1" style="margin-top:2.5%!important"><i class="mdi mdi-delete btn btn-soft-danger remove-corp2" data-toggle="tooltip" title="delete Row"></i></div></div>';
        $('#' + tp + 'manager').append(newRowAdd);
    });
    $(document).ready(function() {
        $("body").on("click", ".remove-corp2", function() {
            $(this).parents(".spc2").remove();
        });
    });

    $(".rowAdder3").click(function() {
        var tp = $(this).attr("data-type");
       
        newRowAdd =
            '<div class="row white-inner spc3"><div class="col-xxl-2 col-md-2"><div><label for="labelInput" class="form-label">First Name <span class="required">*</span><input type="text" class="form-control" id="placeholderInput" placeholder="First Name" name="pm_name[]" required></div></div><div class="col-xxl-2 col-md-2 "><div> <label for="labelInput" class="form-label">Middle Name </label><input type="text" class="form-control" id="placeholderInput" placeholder="Middle Name" name="pm_middle_name[]" value="" /></div></div><div class="col-xxl-2 col-md-2 "><div><label for="labelInput" class="form-label">Last Name<span class="required">*</span></label><input type="text" class="form-control" id="placeholderInput" placeholder="Last Name" name="pm_last_name[]" value="" required/></div></div><div class="col-xxl-3 col-md-2 "><div><label for="labelInput" class="form-label">Aadhaar Number<span class="required">*</span></label><input type="text" class="form-control numbersonly" maxlength="12" id="placeholderInput" placeholder="Aadhaar Number" name="pm_aadhar[]" onblur="checkAadhaarNo(this.value, this)" required></div></div><div class="col-xxl-2 col-md-3 "><div><label for="labelInput" class="form-label">Contact Number<span class="required">*</span></label><input type="text" class="form-control numbersonly" maxlength="10" id="placeholderInput" placeholder="Contact Number" onblur="phonenumber(this)" name="pm_mobile_no[]" required></div></div><div class="col-xxl-1 col-md-1" style="margin-top:2.3%!important"><i class="mdi mdi-delete btn btn-soft-danger remove-corp3" data-toggle="tooltip" title="delete Row"></i></div></div>';
        $('#' + tp + 'manager').append(newRowAdd);
    });
    $(document).ready(function() {
        $("body").on("click", ".remove-corp3", function() {
            $(this).parents(".spc3").remove();
        });
    });

    // $(".dngr").click(function() {
    //     var id = $(this).attr("data-id");
    //     $.ajax({
    //         type: "POST",
    //         url: "{{ route('deletewarehousebyid') }}",
    //         data: "id=" + id,
    //         success: function(data) {
    //             // $(this).parents('').parents(".seperatesec").remove();
    //             // $(this).closest(".seperatesec").remove();
    //             // $(this).parent().parent().remove();
    //             $("#maindiv_" + id).remove();
    //         }
    //     });
    // });
    $(document).on('click', '.dngr', function() {
        var id = $(this).attr('data-id');

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.value) {
                $.ajax({
                    url: "{{ route('deletewarehousebyid') }}",
                    method: "POST",
                    dataType: 'json',
                    data: {
                        'id': id,
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(result) {
                        $("#maindiv_" + id).remove();

                    }

                });
            }
        });
    });
    $(document).ready(function() {
        $("body").on("click", ".remove-corp4", function() {
            $(this).parents(".spc4").remove();
        });
    });


    function checkAadhaarNo(val, inputElement) {
    var numericValue = val.replace(/[^0-9]/g, '');
    if (numericValue.length !== 12) {
        Swal.fire({
            icon: 'info',
            title: 'Aadhaar',
            text: 'Please enter a 12-digit Aadhaar number.',
        });
        inputElement.value = ''; 
    } else {
        inputElement.value = numericValue;
    }
}  
</script>
@endpush
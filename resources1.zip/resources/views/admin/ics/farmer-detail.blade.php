@extends('admin.layouts.app')

@section('content')
    <style>
        .view-details {
            margin-top: 15px;
            border: 1px solid lightgrey;
            padding: 5px 15px;
            border-radius: 0.25rem
        }

        .view-details td {
            padding: 10px 0
        }

        .view-details td:nth-child(1),
        .view-details td:nth-child(3) {
            width: 35%;
            padding-right: 15px
        }

        .table-width td:nth-child(1) {
            width: 46%;
            padding-right: 15px
        }

        .view-details td:nth-child(3) {
            padding-left: 15px
        }

        .view-details table {
            width: 100%
        }

        .sectitle .borderbottom {
            display: block;
            background: #30956b;
            width: 50px;
            height: 4px
        }

        .repeat-sec {
            border: 1px solid lightgrey;
            padding: 15px 15px;
            border-radius: 0.25rem;
            margin: 15px
        }

        .repeat-sec:nth-child(odd) {
            background: #f5f5f5
        }

        .repeat-sec:nth-child(even) {
            background: #fcfcfc
        }

        .odd-bd {
            background: #78cd721f
        }

        .even-bd {
            background: #f8664c1a
        }
    </style>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Farmer Detail</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Farmer Detail</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->
    <div class="row">
        <div class="col-lg-12">

            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1">
                                Farmer Details

                            </h4>
                        </div>
                        <!-- end card header -->
                        <div class="card-body">
                            <div class="live-preview">

                                <div class="row seperatesec">
                                    <div class="col-xxl-12 col-md-12">
                                        <div class="sectitle">
                                            <label for="labelInput" class="form-label">Farmer Person Details</label>
                                            <div class="borderbottom"></div>
                                        </div>
                                        <div class="sectitle">
                                            <label for="labelInput" class="form-label">Farmer Photo :  
                                                @if (isset($result->farmerPhoto)  && !empty($result->farmerPhoto))
                                                <a target="_BLANK"
                                                        href="{{ asset('public/farmers/' . $result->farmerPhoto) }}"
                                                        class="text-decoration-underline">See Doc</a>
                                                        @else
                                                        N/A
                                                @endif</label>
                                            
                                        </div>
                                        <div class="table-responsive view-details mb-4">
                                            <table>
                                                <tbody>
                                                    <tr>
                                                        <td><b>Registration No :</b></td>
                                                        <td>{{ $result->registration_no ?? 'N/A' }}</td>
                                                        <td><b>Registration Date :</b></td>
                                                        <td>{{ \Carbon\Carbon::parse($result->registration_date)->format('d-m-Y') ?? '' }}
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Farmer First Name :</b></td>
                                                        <td>{{ $result->farmer_first_name ?? '' }}</td>
                                                        <td><b>Farmer Middle Name :</b></td>
                                                        <td>{{ $result->farmer_middle_name ?? '' }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Farmer Last Name :</b></td>
                                                        <td>{{ $result->farmer_last_name ?? '' }}</td>
                                                        <td><b>Email ID :</b></td>
                                                        <td>{{ $result->email_id ?? '' }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Gender :</b></td>
                                                        <td>{{ $result->email_id == 'M' ? 'Male' : 'Female' }}</td>
                                                        <td><b>Pan Card :</b></td>
                                                        <td> @if (isset($result->farmerDocs->pan_card_image_path)  && !empty($result->farmerDocs->pan_card_image_path))
                                                            <a target="_BLANK"
                                                                    href="{{ asset('public/farmers/' . $result->farmerDocs->pan_card_image_path) }}"
                                                                    class="text-decoration-underline">See Doc</a>
                                                                    @else
                                                                    N/A
                                                            @endif</td>
                                                        {{-- <td><b>Father Husband Flag :</b></td>
                                                    <td>{{ $result->father_husband_flag??'' }}</td> --}}
                                                    </tr>
                                                    {{-- <tr>
                                                    <td><b>Father/Husband First Name :</b></td>
                                                    <td>{{ $result->father_husband_first_name??'' }}</td>
                                                    <td><b>Father/Husband Middle Name :</b></td>
                                                    <td>{{ $result->father_husband_first_name??'' }}</td>
                                                </tr> --}}
                                                    <tr>
                                                        {{-- <td><b>Father/Husband Last Name :</b></td>
                                                    <td>zbbzbz</td> --}}

                                                    </tr>
                                                    <tr>
                                                        <td><b>Aadhar Card :</b></td>
                                                        <td>
                                                            @if (isset($result->farmerDocs->aadhar_card_image_path)  && !empty($result->farmerDocs->aadhar_card_image_path))
                                                            <a target="_BLANK"
                                                                    href="{{ asset('public/farmers/' . $result->farmerDocs->aadhar_card_image_path) }}"
                                                                    class="text-decoration-underline">See Doc</a>
                                                                    @else
                                                                    N/A
                                                            @endif
                                                        </td>
                                                        <td><b>Mobile Number :</b></td>
                                                        <td>{{ $result->mobile_no ?? '' }}</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="col-xxl-6 col-md-6">
                                        <div class="sectitle">
                                            <label for="labelInput" class="form-label">Address</label>
                                            <div class="borderbottom"></div>
                                        </div>
                                        <div class="table-responsive view-details  mb-4">
                                            <table>
                                                <tbody>
                                                    <tr>
                                                        <td><b>State :</b></td>
                                                        <td>{{ get_state_name($result->ref_state_id) ?? '' }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>District :</b></td>
                                                        <td>{{ get_district_name_by_id($result->ref_district_id) ?? '' }}
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Taluka/Mandal :</b></td>
                                                        <td>{{ getBlockTehsilByID($result->ref_block_tehsil_id) ?? '' }}
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Village :</b></td>
                                                        <td>{{ get_village_name_by_id($result->ref_village_id) ?? '' }}
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Pin Code :</b></td>
                                                        <td>{{ $result->pin ?? '' }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>landmark :</b></td>
                                                        <td>{{ $result->landmark ?? '' }}</td>
                                                        <td><b>Address :</b></td>
                                                        <td>{{ $result->farmer_address ?? '' }}</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="col-xxl-6 col-md-6">
                                        <div class="sectitle">
                                            <label for="labelInput" class="form-label">Bank Detail</label>
                                            <div class="borderbottom"></div>
                                        </div>
                                        <div class="table-responsive view-details  mb-4">
                                            <table>
                                                <tbody>
                                                    <tr>
                                                        <td><b>Bank Name :</b></td>
                                                        <td>{{ $result->farmerBankDetail->bank_name ?? '' }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Account Number :</b></td>
                                                        <td>{{ $result->farmerBankDetail->account_number ?? '' }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>IFSC Code :</b></td>
                                                        <td>{{ $result->farmerBankDetail->branch_name ?? '' }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Branch Name :</b></td>
                                                        <td>{{ $result->farmerBankDetail->branch_name ?? '' }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Address :</b></td>
                                                        <td>{{ $result->farmerBankDetail->bank_address ?? '' }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Pin Code :</b></td>
                                                        <td>{{ $result->farmerBankDetail->pincode ?? '' }}</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    @if (isset($result->farmerLandDetail) && $result->farmerLandDetail->count() > 0)
                                        @forelse ($result->farmerLandDetail as $key=> $farmdetail)
                                            <div class="col-xxl-12 col-md-12">
                                                <div class="repeat-sec">
                                                    <div class="row">
                                                        <div class="col-xxl-6 col-md-6">
                                                            <div class="sectitle">
                                                                <label for="labelInput" class="form-label">Farm Details
                                                                    {{ $key + 1 }}</label>
                                                                <div class="borderbottom"></div>
                                                            </div>
                                                            <div class="table-responsive view-details  mb-4">
                                                                <table>
                                                                    <tbody>
                                                                        <tr>
                                                                            <td><b>Registration No :</b></td>
                                                                            <td>{{ $farmdetail->registration_no ?? 'N/A' }}
                                                                            </td>
                                                                        
                                                                        </tr>
                                                                        <tr>
                                                                        <td><b>Owner Farmer ID :</b></td>
                                                                        <td>{{ $farmdetail->owner_farmerid ?? '' }}</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Farm Name :</b></td>
                                                                            <td>{{ $farmdetail->farm_name ?? '' }}</td>
                                                                        </tr>
                                                                        {{-- <tr>
                                                                       
                                                                        <td><b>Landmark :</b></td>
                                                                        <td>0</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Pin :</b></td>
                                                                            <td>0</td>
                                                                        </tr>
                                                                        <tr>
                                                                        <td><b>Farm No :</b></td>
                                                                        <td>0</td>
                                                                        </tr> --}}
                                                                        <tr>
                                                                            <td><b>Area In Ha :</b></td>
                                                                            <td>{{ $farmdetail->area_in_ha ?? '' }}</td>
                                                                        </tr>
                                                                        <tr>
                                                                        <td><b>Total Area :</b></td>
                                                                        <td>{{ $farmdetail->total_area ?? '' }}</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Survay No :</b></td>
                                                                            <td>{{ $farmdetail->survay_no ?? '' }}</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Farm Processing :</b></td>
                                                                            <td>{{$farmdetail->farm_processing ?? ''}}</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Completed Three Years Pgs
                                                                                    :</b></td>
                                                                            <td>{{ $farmdetail->completed_three_years_pgs == 'Y' ? 'Yes' : 'No' }}</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Pgs Certificate :</b></td>
                                                                            <td>{{ $farmdetail->pgs_certificate ?? '' }}</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Organic Status :</b></td>
                                                                            <td>{{ getRefOrganicStatusMasterByID($farmdetail->ref_organic_status_master_id) }}</td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                        <div class="col-xxl-6 col-md-6">
                                                            <div class="sectitle">
                                                                <label for="labelInput" class="form-label">Address</label>
                                                                <div class="borderbottom"></div>
                                                            </div>
                                                            <div class="table-responsive view-details table-width  mb-4">
                                                                <table>
                                                                    <tbody>
                                                                        <tr>
                                                                            <td><b>State :</b></td>
                                                                            <td>{{ get_state_name($farmdetail->ref_state_id) }}</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>District :</b></td>
                                                                            <td>{{ get_district_name_by_id($farmdetail->ref_district_id) }}</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Taluka/Mandal :</b></td>
                                                                            <td>{{ getBlockTehsilByID($farmdetail->ref_block_tehsil_id) }}</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Village :</b></td>
                                                                            <td>{{ get_village_name_by_id($farmdetail->ref_village_id) }}</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><b>Pin Code :</b></td>
                                                                            <td>{{ $farmdetail->pin ?? '' }}</td>
                                                                        </tr>
                                                                       
                                                                        <tr>
                                                                            <td><b>Address :</b></td>
                                                                            <td>{{ $result->farmer_address ?? '' }}</td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                        <div class="col-xxl-12 col-md-12">
                                                            <div class="repeat-sec">
                                                                <div class="row">
                                                                    <div class="col-xxl-12 col-md-12">

                                                                        <div class="sectitle">
                                                                            <label for="labelInput"
                                                                                class="form-label">Farmer
                                                                                Standing Crop Details : </label>
                                                                            <div class="borderbottom"></div>
                                                                        </div>
                                                                        @forelse (farmerStandingCorpDetail(['at_farmer_details_id'=>$result->id,'at_farm_details_id'=>$farmdetail->id]) as  $key=>  $farmstandetail)
                                                                        <div
                                                                            class="table-responsive view-details mb-4 {{ ($key % 2==0) ?'odd-bd' : 'even-bd' }}">
                                                                            <table>
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <td><b>HS code :</b>
                                                                                        </td>
                                                                                        <td>{{ getRefHscodeByID($farmstandetail->ref_hscode_id) ?? '' }}</td>
                                                                                        <td><b>Season Name :</b>
                                                                                        </td>
                                                                                        <td>{{ $farmstandetail->season_name ?? '' }}</td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td><b>Crop Area :</b>
                                                                                        </td>
                                                                                        <td>{{ $farmstandetail->crop_area ?? '' }}</td>
                                                                                        <td><b>Organic Status
                                                                                                :</b></td>
                                                                                        <td>{{ getRefOrganicStatusMasterByID($farmstandetail->organic_status) }}
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td><b>Crop Image :</b>
                                                                                        </td>
                                                                                        <td>@if (isset($farmstandetail->crop_photo)  && !empty($farmstandetail->crop_photo))
                                                                                            <a target="_BLANK"
                                                                                                    href="{{ asset('public/farmers/' . $farmstandetail->crop_photo) }}"
                                                                                                    class="text-decoration-underline">See Doc</a>
                                                                                                    @else
                                                                                                    N/A
                                                                                            @endif</td>
                                                                                            <td><b>GeoTag Image :</b>
                                                                                            </td>
                                                                                            <td>@if (isset($farmstandetail->geotag_photo)  && !empty($farmstandetail->geotag_photo))
                                                                                                <a target="_BLANK"
                                                                                                        href="{{ asset('public/farmers/' . $farmstandetail->geotag_photo) }}"
                                                                                                        class="text-decoration-underline">See Doc</a>
                                                                                                        @else
                                                                                                        N/A
                                                                                                @endif</td>
                                                                                       
                                                                                    </tr>

                                                                                </tbody>
                                                                            </table>
                                                                            <br>
                                                                            <div class="col-xxl-12 col-md-12">

                                                                                <div class="row">
                                                                                    <div class="col-xxl-12 col-md-12">

                                                                                        <div class="sectitle">
                                                                                            <label for="labelInput"
                                                                                                class="form-label">Geo Tagging Details : </label>
                                                                                            <div class="borderbottom">
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="table-responsive  mb-4">
                                                                                            <table>
                                                                                                <tbody>
                                                                                                    <tr>
                                                                                                        <td><b>Latitude
                                                                                                                :</b>
                                                                                                        </td>
                                                                                                        <td>  @forelse(getTaggingDetail(['at_farmer_reg_details_id'=>$result->id,'at_farm_standing_crop_id'=>$farmstandetail->id]) as $geotagDet)
                                                                                                            {{ $geotagDet->latitude ?? '' }}
                                                        
                                                                                                        @empty
                                                                                                        @endforelse
                                                                                                        </td>
                                                                                                        <td><b>Longitude
                                                                                                                :</b>
                                                                                                        </td>
                                                                                                        <td> @forelse(getTaggingDetail(['at_farmer_reg_details_id'=>$result->id,'at_farm_standing_crop_id'=>$farmstandetail->id]) as $geotagDet)
                                                                                                            {{ $geotagDet->longitude ?? '' }}
                                                        
                                                                                                        @empty
                                                                                                        @endforelse
                                                                                                        </td>
                                                                                                    </tr>


                                                                                                </tbody>
                                                                                            </table>
                                                                                        </div>

                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                        @empty
                                                                        @endforelse
                                                                       
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-xxl-12 col-md-12">
                                                            <div class="repeat-sec">
                                                                <div class="row">
                                                                    <div class="col-xxl-12 col-md-12">

                                                                        <div class="sectitle">
                                                                            <label for="labelInput"
                                                                                class="form-label">Farmer
                                                                                Proposed Crop Details:</label>
                                                                            <div class="borderbottom"></div>
                                                                        </div>
                                                                        @forelse (farmerProposedCorpDetail(['at_farmer_details_id'=>$result->id,'at_farm_details_id'=>$farmdetail->id]) as $key=> $farmprodetail)
                                                                        <div
                                                                            class="table-responsive view-details mb-4 {{ ($key % 2==0) ?'odd-bd' : 'even-bd' }}">
                                                                            <table>
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <td><b>HS code :</b>
                                                                                        </td>
                                                                                        <td>{{ getRefHscodeByID($farmprodetail->ref_hscode_id) ?? '' }}</td>
                                                                                        <td><b>Season Name :</b>
                                                                                        </td>
                                                                                        <td>{{ $farmprodetail->season_name ?? '' }}</td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td><b>Crop Area :</b>
                                                                                        </td>
                                                                                        <td>{{ $farmprodetail->crop_area ?? '' }}</td>
                                                                                        <td><b>Organic Status
                                                                                                :</b></td>
                                                                                        <td>{{ getRefOrganicStatusMasterByID($farmprodetail->organic_status) }}
                                                                                        </td>
                                                                                    </tr>

                                                                                </tbody>
                                                                            </table>
                                                                        </div>
                                                                        @empty
                                                                        @endforelse
                                                                        {{-- <div
                                                                            class="table-responsive view-details mb-4 even-bd">
                                                                            <table>
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <td><b>HS code :</b>
                                                                                        </td>
                                                                                        <td>test</td>
                                                                                        <td><b>Season Name :</b>
                                                                                        </td>
                                                                                        <td>Kharif</td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td><b>Crop Area :</b>
                                                                                        </td>
                                                                                        <td>258</td>
                                                                                        <td><b>Organic Status
                                                                                                :</b></td>
                                                                                        <td>1st Year Convirsion
                                                                                        </td>
                                                                                    </tr>

                                                                                </tbody>
                                                                            </table>
                                                                        </div> --}}
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>



                                        @empty
                                        @endforelse
                                    @endif
                                </div>
                                <div class="col-xxl-12 col-md-12">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label">Farmer Docs : </label>
                                        <div class="borderbottom"></div>
                                    </div>
                                    <div class="table-responsive view-details mb-4">
                                        <table>
                                            <tbody>
                                                <tr>
                                                    <td><b>Land Image:</b></td>
                                                    <td> @if (isset($result->farmerDocs->land_documents_image_path)  && !empty($result->farmerDocs->land_documents_image_path))
                                                        <a target="_BLANK"
                                                                href="{{ asset('public/farmers/' . $result->farmerDocs->land_documents_image_path) }}"
                                                                class="text-decoration-underline">See Doc</a>
                                                                @else
                                                                N/A
                                                        @endif
                                                        
                                                        </td>
                                                    <td><b>Passbook Image :</b></td>
                                                    <td>@if (isset($result->farmerDocs->passbook_image_path)  && !empty($result->farmerDocs->passbook_image_path))
                                                        <a target="_BLANK"
                                                                href="{{ asset('public/farmers/' . $result->farmerDocs->land_documents_image_path) }}"
                                                                class="text-decoration-underline">See Doc</a>
                                                                @else
                                                                N/A
                                                        @endif
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><b>Contact Person Sign Image :</b></td>
                                                    <td>@if (isset($result->farmerDocs->contact_person_sign_image_path)  && !empty($result->farmerDocs->contact_person_sign_image_path))
                                                        <a target="_BLANK"
                                                                href="{{ asset('public/farmers/' . $result->farmerDocs->contact_person_sign_image_path) }}"
                                                                class="text-decoration-underline">See Doc</a>
                                                                @else
                                                                N/A
                                                        @endif</td>
                                                    <td><b>Live Signature Image :</b></td>
                                                    <td>@if (isset($result->farmerDocs->live_signature_image_path)  && !empty($result->farmerDocs->live_signature_image_path))
                                                        <a target="_BLANK"
                                                                href="{{ asset('public/farmers/' . $result->farmerDocs->live_signature_image_path) }}"
                                                                class="text-decoration-underline">See Doc</a>
                                                                @else
                                                                N/A
                                                        @endif</td>
                                                </tr>
                                              
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="col-xxl-12 col-md-12">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label">Farmer OSP Details : </label>
                                        <div class="borderbottom"></div>
                                    </div>
                                    <div class="table-responsive view-details mb-4">
                                        <table>
                                            <tbody>
                                                <tr>
                                                    <td><b>Source of Organic System Plan:</b></td>
                                                    <td>{{ $result->farmerOSPDetail->source_of_organic_system_plan ?? 'N/A' }}</td>
                                                    <td><b>Cropping Pattern :</b></td>
                                                    <td>{{ $result->farmerOSPDetail->cropping_pattern ?? 'N/A' }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><b>Main Crop :</b></td>
                                                    <td>{{ $result->farmerOSPDetail->covered_area_main_corp ?? 'N/A' }}</td>
                                                    <td><b>Inter Crop :</b></td>
                                                    <td>{{ $result->farmerOSPDetail->covered_area_inter_corp ?? 'N/A' }}</td>
                                                </tr>
                                                <tr>
                                                    <td><b>Off Farm :</b></td>
                                                    <td>{{ $result->farmerOSPDetail->off_farm ?? 'N/A' }}</td>
                                                    <td><b>On Farm:</b></td>
                                                    <td>{{ $result->farmerOSPDetail->on_farm ?? 'N/A' }}</td>
                                                </tr>
                                                <tr>
                                                    <td><b>Contamination Control :</b></td>
                                                    <td>{{ $result->farmerOSPDetail->contamination_control ?? 'N/A' }}</td>
                                                    <td><b>Pease Weed Management :</b></td>
                                                    <td>{{ $result->farmerOSPDetail->pease_weed_management ?? 'N/A' }}</td>
                                                   

                                                </tr>
                                                <tr>
                                                    <td><b>Nutrient Management :</b></td>
                                                    <td>{{ $result->farmerOSPDetail->nutrient_management ?? 'N/A' }}
                                                        
                                                    </td>
                                                    
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
@endsection
@push('script')
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>
@endpush

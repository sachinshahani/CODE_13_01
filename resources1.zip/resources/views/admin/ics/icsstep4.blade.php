@extends('admin.layouts.app')
@section('content')
<style>
    .wrapper {
        max-width: 1240px;
        margin: 0 auto;
    }

    .white-bg {
        background-color: white;
        border-bottom: 5px solid #ff9800;
        margin-bottom: 15px;
    }

    .auth-one-bg .slide .carousel-indicators {
        bottom: 25px;
    }

    .auth-page-wrapper .auth-page-content {
        padding-bottom: 0px !important;
    }

    .auth-page-content .card {
        margin-bottom: 0rem;
    }

    .data-tabs .wrapper .nav-tabs button {
        font-size: 17px;
        color: black;
    }

    .data-tabs .wrapper .nav-tabs .active {
        background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
        */ color: white;
        background: orange;
        border-radius: 0px;
    }

    .carousel-caption.d-none.d-md-block {
        background-color: #000000bf;
        left: 0;
        width: 100%;
        bottom: 0;
    }

    .carousel-indicators {
        display: none;
    }

    .custom-banner-caption {
        color: white !important;
    }

    .announcement-heading {
        font-size: 1.2em;
        font-weight: 600;
    }

    .data-tabs .tab-pane ul li {
        font-size: 1em;
        padding: 5px 0;

    }

    .main-logo {
        padding: 10px;
    }

    .data-tabs .nav-item .nav-link {
        background-image: none;
    }

    .navbar-brand-box {
        background: #fff;
    }

    .btn-danger {
        background-color: #40895a;
        border: 1px solid #40895a;
    }

    [data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
        color: white !important;
    }

    .header-buttons .btn-primary {
        margin-right: 10px;
        padding: 6px 15px;
        font-weight: 600;
        background-color: #207005;
        border: none;
        box-shadow: 0px 2px 7px #888888;
    }

    .header-buttons .btn-secondary {
        margin-right: 10px;
        padding: 6px 15px;
        font-weight: 600;
        background-color: #72a055;
        border: none;
        box-shadow: 0px 2px 7px #888888;
    }


    .right-sec {
        border-left: 5px solid #ede7e7;
    }

    .tabdiv {
        background: white;
        padding: 20px;
        margin-top: 10px;
        border: 10px solid #dfdbd5;
    }

    .nav-tabs {
        border-bottom: 0px;
    }

    div#myTabContent {
        border: 1px solid #cccccc;
    }

    .frontfooter footer {
        padding: 20px calc(1.5rem / 2);
        position: static;
        color: #000;
        height: 60px;
        background-color: #f9f9f9;
        margin-top: 30px;
        border-top: 1px solid #e1dfdf;
    }

    span.logo-sm img {
        width: 69px;
    }

    .seperatesec {
        margin-top: 20px;
    }

    .simplebar-content li.nav-item:hover {
        background: #4caf50;
    }

    .sectitle {
        font-size: 14px;
    }

    .required {
        color: red;
    }

    .customtextarea {
        height: 120px;
    }

    ul.boxsection {
        margin: 0;
        padding: 0;
    }

    ul.boxsection li {
        list-style-type: none;
        padding: 7px 0;
        border-bottom: 1px solid #efeded;
    }

    .boxcard .col:nth-child(1) {
        background: #effcfb;
    }

    .boxcard .col:nth-child(2) {
        background: #fdfdfd;
    }

    .boxcard .col:nth-child(3) {
        background: #effcfb;
    }

    .boxcard .col:nth-child(4) {
        background: #fdfdfd;
    }

    .boxcard .col:nth-child(5) {
        background: #effcfb;
    }

    /* --registration-form css  */
    .custom-tab-content {
        padding-top: 0 !important;
        padding-bottom: 0px !important;
    }

    .custom-tab-nav {
        background: white;

    }

    .custom-tab-nav .nav-link {
        border-radius: 0 !important;
        border-bottom: 1px solid #e9ebec;
        border-right: 1px solid #e9ebec;
        font-size: 14px;
        padding: 10px;
    }

    .custom-tab-nav .nav-link.active,
    .custom-tab-nav .show>.nav-link {
        color: rgb(255, 255, 255) !important;
        background-color: #2c8c6d;
        border-bottom: #2c8c6d !important;
        /* border-bottom: #207005 !important; */
        position: relative;
    }

    .custom-tab-nav .nav-link:hover,
    .custom-tab-nav .nav-link:focus {
        border-bottom: 1px solid #207005;
        border-radius: 0;
        font-size: 14px;
        transition: background-color 0.20s linear;
    }

    .custom-tab-nav .nav-link.active:after {
        content: "";
        position: absolute;
        bottom: -16px;
        left: 50%;
        border: 8px solid transparent;
        border-top-color: #2c8c6d;
        z-index: 999;
    }

    .reg-form-btns {
        margin-bottom: 15px;
    }

    .reg-form-btns .btn-secondary {
        color: #fff;
        background-color: #405189;
        border-color: #405189;
    }

    .btn-soft-success:active,
    .btn-soft-success:focus,
    .btn-soft-success:hover {
        border: none;
    }

    .custom-tab-nav ul {
        padding: 0px;
        margin: 0px;
    }

    .custom-tab-nav ul li {
        padding: 0px;
        margin: 0px;
        display: inline-block;
        list-style: none;
    }

    .has-error {
        border: 1px solid red;
    }

    .errormsg {
        color: red;
        font-size: 14px !important;
    }




    /* gmail otp verification  */
    .overlay {
        background: rgb(0 0 0 / 50%);
        position: fixed;
        top: 0;
        z-index: 11111;
        left: 0;
        right: 0;
        bottom: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        display: none;
    }

    .loader {
        position: fixed !important;
        left: 50% !important;
        margin-left: -4em !important;
        top: 20em !important;
    }

    .wrapper {
        max-width: 1240px;
        margin: 0 auto;
    }

    .white-bg {
        background-color: white;
        /* box-shadow: 0px 0px 6px 0px rgb(255 255 255 / 80%); */
        border-bottom: 5px solid #ff9800;
        margin-bottom: 15px;
    }

    .auth-one-bg .slide .carousel-indicators {
        bottom: 25px;
    }

    .auth-page-wrapper .auth-page-content {
        padding-bottom: 0px !important;
    }

    .auth-page-content .card {
        margin-bottom: 0rem;
    }

    .data-tabs .wrapper .nav-tabs button {
        font-size: 17px;
        color: black;
    }

    .data-tabs .wrapper .nav-tabs .active {
        background: linear-gradient(-45deg, #3d5f32 50%, #7ead5f);
        */ color: white;
        background: orange;
        border-radius: 0px;
    }

    .carousel-caption.d-none.d-md-block {
        background-color: #000000bf;
        left: 0;
        width: 100%;
        bottom: 0;
    }

    .carousel-indicators {
        display: none;
    }

    .custom-banner-caption {
        color: white !important;
    }

    .announcement-heading {
        font-size: 1.2em;
        font-weight: 600;
    }

    .data-tabs .tab-pane ul li {
        font-size: 1em;
        padding: 5px 0;

    }

    .main-logo {
        padding: 10px;
    }

    .data-tabs .nav-item .nav-link {
        background-image: none;
    }

    /* .right-sec{
                    box-shadow: 5px 10px 18px #888888;
                } */
    .navbar-brand-box {
        background: #fff;
    }

    [data-layout=vertical][data-sidebar=dark] .navbar-nav .nav-sm .nav-link {
        color: white !important;
    }

    .header-buttons .btn-primary {
        margin-right: 10px;
        padding: 6px 15px;
        font-weight: 600;
        background-color: #207005;
        border: none;
        box-shadow: 0px 2px 7px #888888;
    }

    .header-buttons .btn-secondary {
        margin-right: 10px;
        padding: 6px 15px;
        font-weight: 600;
        background-color: #72a055;
        border: none;
        box-shadow: 0px 2px 7px #888888;
    }


    .right-sec {
        border-left: 5px solid #ede7e7;
    }

    .tabdiv {
        background: white;
        padding: 20px;
        margin-top: 10px;
        border: 10px solid #dfdbd5;
    }

    .nav-tabs {
        border-bottom: 0px;
    }

    div#myTabContent {
        border: 1px solid #cccccc;
    }

    .frontfooter footer {
        padding: 20px calc(1.5rem / 2);
        position: static;
        color: #000;
        height: 60px;
        background-color: #f9f9f9;
        margin-top: 30px;
        border-top: 1px solid #e1dfdf;
    }

    span.logo-sm img {
        width: 69px;
    }

    .seperatesec {
        margin-top: 20px;
    }

    .simplebar-content li.nav-item:hover {
        background: #4caf50;
    }

    .sectitle {
        font-size: 14px;
    }

    .required {
        color: red;
    }

    .customtextarea {
        height: 120px;
    }

    ul.boxsection {
        margin: 0;
        padding: 0;
    }

    ul.boxsection li {
        list-style-type: none;
        padding: 7px 0;
        border-bottom: 1px solid #efeded;
    }

    .boxcard .col:nth-child(1) {
        background: #effcfb;
    }

    .boxcard .col:nth-child(2) {
        background: #fdfdfd;
    }

    .boxcard .col:nth-child(3) {
        background: #effcfb;
    }

    .boxcard .col:nth-child(4) {
        background: #fdfdfd;
    }

    .boxcard .col:nth-child(5) {
        background: #effcfb;
    }

    /* --registration-form css  */
    .custom-tab-content {
        padding-top: 0 !important;
        padding-bottom: 0px !important;
    }

    .custom-tab-nav {
        background: white;

    }

    .custom-tab-nav .nav-link {
        border-radius: 0 !important;
        border-bottom: 1px solid #e9ebec;
        border-right: 1px solid #e9ebec;
        font-size: 14px;
        padding: 10px;
    }

    .custom-tab-nav .nav-link.active,
    .custom-tab-nav .show>.nav-link {
        color: rgb(255, 255, 255) !important;
        background-color: #2c8c6d;
        border-bottom: #2c8c6d !important;
        /* border-bottom: #207005 !important; */
        position: relative;
    }

    .custom-tab-nav .nav-link:hover,
    .custom-tab-nav .nav-link:focus {
        border-bottom: 1px solid #207005;
        border-radius: 0;
        font-size: 14px;
        transition: background-color 0.20s linear;
    }

    .custom-tab-nav .nav-link.active:after {
        content: "";
        position: absolute;
        bottom: -16px;
        left: 50%;
        border: 8px solid transparent;
        border-top-color: #2c8c6d;
        z-index: 999;
    }

    .reg-form-btns {
        margin-bottom: 15px;
    }

    .reg-form-btns .btn-secondary {
        color: #fff;
        background-color: #405189;
        border-color: #405189;
    }

    .btn-soft-success:active,
    .btn-soft-success:focus,
    .btn-soft-success:hover {
        border: none;
    }

    .custom-tab-nav ul {
        padding: 0px;
        margin: 0px;
    }

    .custom-tab-nav ul li {
        padding: 0px;
        margin: 0px;
        display: inline-block;
        list-style: none;
    }

    /* -------  */
    .btn-email {
        font-size: 13px;
        padding: 1px 7px;
        line-height: 17px;

    }

    .btn-mailsend {
        font-size: 13px;
        padding: 1px 7px;
        line-height: 17px;
    }

    .btn-verify {
        font-size: 13px;
        padding: 1px 7px;
        line-height: 34px;
    }

    .inputEmail .input-group-append {
        display: flex;
        align-items: end;
    }

    .inputEmail .validateEmailId {
        border-radius: 4px 0 0 4px;
    }

    .input-group-append .verifiEmail_otp,
    .input-group-append .resendEmail_otp {
        margin-left: 10px;
    }

    .login-pass.otp-email {
        margin-top: 5px
    }

    .login-pass.otp-email .inp-b {
        border-radius: 0 4px 4px 0
    }

    .overlay {
            background: rgb(0 0 0 / 50%);
            position: fixed;
            top: 0;
            z-index: 11111;
            left: 0;
            right: 0;
            bottom: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            display: none;
        }

        .loader {
            position: fixed !important;
            left: 50% !important;
            margin-left: -4em !important;
            top: 20em !important;
        }

        .wrapper {
            max-width: 1240px;
            margin: 0 auto;
        }

        /* Whole-page overlay with dark background */
        #overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            /* Dark overlay with 60% opacity */
            z-index: 9999;
            /* Ensure it's on top of everything */
            display: none;
            /* Initially hidden */
        }

        /* Centered loader (spinner) */
        #loader {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 10000;
            /* Ensure it is above the overlay */
            display: none;
            /* Initially hidden */
        }
        /* Whole-page overlay with dark background */
        #overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            /* Dark overlay with 60% opacity */
            z-index: 9999;
            /* Ensure it's on top of everything */
            display: none;
            /* Initially hidden */
        }

        /* Centered loader (spinner) */
        #loader {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 10000;
            /* Ensure it is above the overlay */
            display: none;
            /* Initially hidden */
        }


    /* end  */
</style>
<!-- start page title -->
<div id="overlay" class="d-none position-fixed top-0 start-0 end-0 bottom-0 bg-dark opacity-50"></div>
<div id="loader"
    class="d-none position-fixed top-0 start-0 end-0 bottom-0 d-flex justify-content-center align-items-center">
    <div class="spinner-border" role="status">
        <span class="visually-hidden">Loading...</span>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">उत्पादक समूह प्रोफ़ाइल/Grower Group Profile </h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Grower Group Profile</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <form method="post" id="inspectorfrm" action="{{ route('superadmin.icsuser.step4post', $userdetails->id) }}"
            enctype="multipart/form-data">
            @csrf
            <input type="hidden" name="roleid" value="{{ $userdetails->ref_operator_type_id ?? '' }}">
            <nav>
                <div class="nav nav-pills nav-fill custom-tab-nav" id="nav-tab" role="tablist">
                    <a class="nav-link" href="{{ route('superadmin.icsuser.step1', $userdetails->id) }}">General
                        Information</a>
                    <a class="nav-link" href="{{ route('superadmin.icsuser.step2', $userdetails->id) }}">Self/Service Provider
                        Details</a>

                    <a class="nav-link active" id="step4-tab" data-bs-toggle="tab"
                        href="{{ route('superadmin.icsuser.step4', $userdetails->id) }}">Internal Inspector Details</a>
                    <a class="nav-link"
                        href="{{ route('superadmin.icsuser.step5', $userdetails->id) }}">Warehouse/Godown
                    </a>
                    <a class="nav-link" href="{{ route('superadmin.icsuser.step6', $userdetails->id) }}">Grower Group Official
                        Details</a>
                    <a class="nav-link" href="{{ route('superadmin.icsuser.step3', $userdetails->id) }}">Farmer
                        Details</a>
                </div>
            </nav>
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step4">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1"> निरीक्षक के विवरण जोड़ें/Add Details of Inspector
                            </h4>
                            <div class="flex-shrink-0">
                                @if (session('error'))
                                <div class="alert alert-danger">
                                    {{ session('error') }}
                                </div>
                                @endif
                                @if (session('success'))
                                <div class="alert alert-success">
                                    {{ session('success') }}
                                </div>
                                @endif
                                @if ($errors)
                                @foreach ($errors->all() as $error)
                                <div class="alert alert-danger">{{ $error }}</div>
                                @endforeach
                                @endif
                            </div>
                        </div>

                        @php
                        $noofInsp = $userdetails->no_of_inspector;
                        $userinsCount = $userinsdetail->count();
                        @endphp


                        <!-- end card header -->
                        <div class="card-body">
                            @if ($noofInsp == $userinsCount)
                            @foreach ($userinsdetail as $key => $value)
                          
                            <div
                                class="live-preview after-add-more  p-3 mb-1 {{ ($key + 1) % 2 == 0 ? '' : '' }}">
                                {{ $key + 1 }}.
                                <div id="row{{ $value->id }}">
                                    <input type="hidden" class="form-control" value="{{ $value->id }}"
                                        name="row_id[]" />
                                    <div class="row seperatesec white-inner">
                                        <div class="col-xxl-3 col-md-3 ">
                                            <div>
                                                <label class="form-label">निरीक्षक का नाम/Name of Inspector<span
                                                        class="required">*</span></label>
                                                <input type="text" class="form-control charater_allow" id="placeholderInput"
                                                    placeholder="Name of Inspector" name="inspector_name[]"
                                                    value="{{ $value->name_of_inspector ?? '' }}" required />
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3">
                                            <div>
                                                <label for="labelInput" class="form-label">मोबाइल नंबर/Mobile Number<span
                                                        class="required">*</span></label>
                                                <input type="text" class="form-control numbersonly mobile mobile_number"
                                                    maxlength="10" id="mobile_number"
                                                    placeholder="Mobile Number" name="mobile_no[]"
                                                    value="{{ $value->mobile_no ?? '' }}" required />
                                            </div>
                                            <button type="button" class="btn btn-primary mt-2" id="getOtpBtn"
                                                onclick="sendOtp()">ओटीपी प्राप्त करें/ Get OTP</button>

                                            <!-- Resend OTP Button (Initially Hidden) -->
                                            <button type="button" class="btn btn-warning mt-2" id="resendOtpBtn"
                                                onclick="sendOtp()" style="display: none;">Resend OTP</button>

                                            <!-- Verified Button (Initially Hidden) -->
                                            <button type="button" class="btn btn-success mt-2" id="verifiedBtn"
                                                style="display: none;" disabled>Verified</button>

                                            <!-- OTP Input Section (Initially Hidden) -->
                                            <div id="otp_section" style="display: none;">
                                                <input type="text" id="otp_input" class="form-control mt-2"
                                                    placeholder="Enter OTP" maxlength="6">
                                                <button type="button" class="btn btn-primary mt-2" onclick="verifyOtp()">Verify
                                                    OTP</button>
                                            </div>
                                        </div>
                                        <!-- <div class="col-xxl-3 col-md-4 ">
                                                                    <div>
                                                                        <label for="labelInput" class="form-label">Email Id<span
                                                                                class="required">*</span></label>
                                                                        <input type="email" class="form-control email_id"
                                                                            id="placeholderInput" placeholder="Email Id" name="email[]"
                                                                            value="{{ $value->email ?? '' }}" required />
                           <input type="hidden"  name="hidden_email[]"
                                                                            value="{{ $value->email ?? '' }}" />
                                                                    </div>
                                                                </div> -->


                                        <!-- get otp  -->

                                        <div class="col-xxl-3 col-md-4">
                                            <div class="inputEmail  col-12 col-sm-12 col-md-12 col-lg-12">
                                                <div
                                                    class="form-group d-flex justify-content-center ge-otp-form">
                                                    <div
                                                        class="col-12 col-sm-12 @if (!empty($value->email)) col-md-12 @else col-md-10 @endif @if (!empty($value->email)) col-lg-12 @else col-lg-10 @endif">
                                                        <label>ईमेल आईडी/Email ID<span
                                                                class="text-danger">*</span></label>
                                                        <input
                                                            class="form-control email_id validateEmailId col-12 col-sm-12 col-md-12 col-lg-12"
                                                            type="text" value="{{ $value->email ?? '' }}"
                                                            placeholder="Email Id" id="email_id1" name="email[]"
                                                            @if (!empty($value->email)) readonly @endif
                                                        required />
                                                        <input type="hidden" name="hidden_email[]" required
                                                            value="{{ $value->email ?? '' }}" />
                                                    </div>
                                                    @if (empty($value->email))
                                                    <div
                                                        class="input-group-append col-12 col-sm-12 col-md-2 col-lg-2">

                                                        <button type="button"
                                                            class="btn-email btn btn-outline-success waves-effect waves-light visitorCat2">OTP प्राप्त करें/Get
                                                            OTP</button>
                                                        <button type="button"
                                                            class="btn btn-ghost-success waves-effect waves-light btn-mailsend"
                                                            style="display:none">मेल भेजा गया/Mail Send</button>
                                                        <button type="button"
                                                            class="btn btn-ghost-success waves-effect waves-light btn-verify"
                                                            style="display:none">सत्यापित/Verified</button>
                                                    </div>
                                                    @endif
                                                </div>
                                                <div class="verify-email justify-content-center">
                                                    <div class="login-pass mb-4 otp-email col-12 col-sm-12 col-md-5 col-lg-12 pl-2"
                                                        style="display:none">
                                                        <div class="input-group">
                                                            <span class="input-group-text mdi mdi-key"
                                                                id="inputGroup-sizing-default"></span>
                                                            <input type="text" class="form-control inp-b"
                                                                aria-label="Sizing example input"
                                                                aria-describedby="inputGroup-sizing-default"
                                                                id="email_otp1">
                                                            <div class="input-group-append">
                                                                <a href="javascript:void(0)"
                                                                    class="verifiEmail_otp btn btn-outline-success waves-effect waves-light">सत्यापित करें/Verify</a>
                                                                <a href="javascript:void(0)"
                                                                    class="resendEmail_otp btn btn-outline-danger waves-effect waves-light">फिर से भेजें/Resend</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- end -->




                                    </div>
                                    <div class="row white-inner">
                                        <div class="sectitle">
                                            <label for="labelInput" class="form-label blue-ht">इंस्पेक्टर का पता/Address of
                                                Inspector</label>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div class="row">
                                                <div class="col-xx-12 col-md-12">
                                                    <label for="labelInput" class="form-label">पता/Address<span
                                                            class="required">*</span></label>
                                                    <textarea placeholder="Address of The Inspector" class="form-control customtextarea" name="address[]" required>{{ $value->address ?? '' }}</textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xxl-9 col-md-9">
                                            <div class="row">
                                                <div class="col-xxl-4 col-md-4 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">राज्य/State<span
                                                                class="required">*</span></label>
                                                        <select class="form-select state" name="state[]"
                                                            required>
                                                            <option value="">Select State</option>
                                                            @forelse(CBstateAssign($cbstate->id) as $state)
                                                            <option value="{{ $state->ref_state_id }}"
                                                                {{ $value->ref_state_id == $state->ref_state_id ? 'selected' : '' }}>
                                                                {{ $state->state_name }}
                                                            </option>
                                                            @empty
                                                            @endforelse
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-xxl-4 col-md-4 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">जिला/District
                                                            <span class="required">*</span></label>
                                                        <select class="form-select district" name="district[]"
                                                            required>
                                                            <option value="">Select District</option>
                                                            @forelse(getDistrictByStateID($value->ref_state_id) as $district)
                                                            <option value="{{ $district->id }}"
                                                                {{ isset($value) && $value->ref_district_id == $district->id ? 'selected' : '' }}>
                                                                {{ $district->district_name }}
                                                            </option>
                                                            @empty
                                                            @endforelse
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-xxl-4 col-md-4 gy-3">
                                                    <div>
                                                        <label for="labelInput"
                                                            class="form-label">तालुका/मंडल/Taluka/Mandal<span
                                                                class="required">*</span></label>
                                                        <select class="form-select block_tehsil"
                                                            name="taluka[]" required>
                                                            <option value="">Select Taluka/Mandal
                                                            </option>
                                                            @forelse(getBlockTehsilByDistrictID($value->ref_district_id) as $region)
                                                            <option value="{{ $region->id }}"
                                                                {{ isset($value->ref_block_tehsil_id) && $value->ref_block_tehsil_id == $region->id ? 'selected' : '' }}>
                                                                {{ $region->block_tehsil_name }}
                                                            </option>
                                                            @empty
                                                            @endforelse
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-xxl-6 col-md-6 gy-3">
                                                    <div>
                                                        <label class="form-label">गाँव/Village </label>
                                                        <select class="form-select village" name="village[]"
                                                            required>
                                                            <option value="">Select Village</option>
                                                            @forelse(getVillageByBlock($value->ref_block_tehsil_id) as $village)
                                                            <option value="{{ $village->id }}"
                                                                @if (isset($value) && $value->ref_village_id == $village->id) selected @endif>
                                                                {{ $village->village_name }}
                                                            </option>
                                                            @empty
                                                            @endforelse
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-xxl-6 col-md-6 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">पिन कोड/Pin
                                                            Code<span class="required">*</span></label>
                                                        <input type="text" class="form-control numbersonly"
                                                            maxlength="6" id="placeholderInput"
                                                            placeholder="Pin Code" name="pincode[]"
                                                            value="{{ $value->pin ?? '' }}" required />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="row white-inner">

                                        <!-- <div class="col-xxl-3 col-md-3 gy-3 ">
                                                        <div>
                                                            <label for="basiInput" class="form-label">ID Proof/पहचान पत्र(आईडी प्रमाण)<span
                                                                    class="required">*</span>
                                                            </label>

                                                            <select class="form-select id_proof" name="id_proof[]"
                                                                required>
                                                                <option value="">-Select-</option>
                                                                <option value="aadhar" @selected($value->id_proof == 'aadhar')>Aadhar
                                                                </option>
                                                                 <option value="voter_id" @selected($value->id_proof == 'voter_id')>Voter
                                                                    Id</option>
                                                                <option value="driving_licence"
                                                                    @selected($value->id_proof == 'driving_licence')>Driving Licence</option> 
                                                            </select>

                                                        </div>
                                                    </div> -->



                                        <!-- <div class="col-xxl-3 col-md-3 gy-3 id_proof_doc"
                                                        {{ empty($value->id_proof_doc) ? 'style=display:none' : '' }}>
                                                        <div>
                                                            <label class="form-label" >Aadhar Doc/ आधार दस्तावेज़<span class="required">*</span></label>
                                                            <input type="file" class="form-control" id=""
                                                                placeholder="ID Proof Doc" name="id_proof_doc[]"
                                                                value="{{ $value->id_proof_doc }}" required>

                                                                @if (!empty($value->id_proof_doc))
                                                                <input type="hidden" name="id_proof_doc[]"
                                                                    value="{{ $value->id_proof_doc ?? '' }}">
                                                                <a target="_BLANK"
                                                                    href="{{ asset('public/inspector/id_proof_doc/' . $value->id_proof_doc) }}"
                                                                    class="text-decoration-underline">See Doc</a>
                                                            @endif

                                                                
                                                        </div>
                                                    </div> -->
                                        <!-- <div class="col-xxl-3 col-md-3 gy-3">
                                                        <div>
                                                            <label for="basiInput" class="form-label">Address Proof/पता 
                                                            </label>
                                                            <div class="input-group">
                                                                <select class="form-select"
                                                                    name="address_proof_of_office[]">
                                                                    <option value="">--Select-- </option>
                                                                    <option value="electricity_bill"
                                                                        {{ $value->address_proof_of_office == 'electricity_bill' ? 'selected' : '' }}>
                                                                        Electricity Bill</option>
                                                                    <option value="rent_agreement"
                                                                        {{ $value->address_proof_of_office == 'rent_agreement' ? 'selected' : '' }}>
                                                                        Rent Agreement</option>
                                                                    <option value="driving_licence"
                                                                        {{ $value->address_proof_of_office == 'driving_licence' ? 'selected' : '' }}>
                                                                        Driving Licence</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div> -->

                                        <!-- 
                                                    <div class="col-xxl-3 col-md-3 gy-3">
                                                        <div>
                                                            <label class="form-label">Address Proof of Doc/दस्तावेज़ का पता प्रमाण</label>
                                                            <input type="file" class="form-control"
                                                                name="address_proof_of_office_doc[]"
                                                                id="address_proof_of_office_doc" accept="image/png, application/pdf, image/jpeg" >
                                                            <span class="form-text">Supported formats:JPG, PNG, PDF. Upto
                                                                2MB</span>
                                                            @if (!empty($value->address_proof_of_office_doc))
                                                                <input type="hidden"
                                                                    name="address_proof_of_office_doc_edit[]"
                                                                    value="{{ $value->address_proof_of_office_doc ?? '' }}">
                                                                <a target="_BLANK"
                                                                    href="{{ asset('public/inspector/address_proof_of_office_doc/' . $value->address_proof_of_office_doc) }}"
                                                                    class="text-decoration-underline">See Doc</a>
                                                            @endif
                                                        </div>
                                                    </div> -->

                                        <!-- <div class="col-xxl-3 col-md-3 gy-3">
                                                        <div>
                                                            <label class="form-label">Photo of Inspector/इंस्पेक्टर का फोटो<span
                                                                    class="required">*</span></label>
                                                            <input type="file" class="form-control"
                                                                name="profile_photo[]"id="profile_photo" accept="image/png, application/pdf, image/jpeg" >
                                                            <span class="form-text">Supported formats:JPG, PNG, PDF. Upto
                                                                2MB</span>
                                                            @if (!empty($value->profile_photo))
                                                                <input type="hidden" name="profile_photo_edit[]"
                                                                    value="{{ $value->profile_photo ?? '' }}">
                                                                <a target="_BLANK"
                                                                    href="{{ asset('public/inspector/profile_photo/' . $value->profile_photo) }}"
                                                                    class="text-decoration-underline">See Doc</a>
                                                            @endif
                                                        </div>
                                                    </div> -->

                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">नियुक्ति पत्र/Appointment Letter<span
                                                        class="required">*</span></label>
                                                <input type="file" class="form-control upload_document"
                                                    name="appointment_doc[]" id="appointment_doc" accept="image/png, application/pdf, image/jpeg">
                                                <span class="form-text">Supported formats:JPG, PNG, PDF. Upto
                                                    1MB</span>
                                                @if (!empty($value->appointment_doc))
                                                <input type="hidden" name="appointment_doc_edit[]"
                                                    value="{{ $value->appointment_doc ?? '' }}">
                                                <a target="_BLANK"
                                                    href="{{ asset('public/inspector/appointment_doc/' . $value->appointment_doc) }}"
                                                    class="text-decoration-underline">See Doc</a>
                                                @endif
                                            </div>
                                        </div>
                                        <!-- <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="labelInput">योग्यता/Qualification<span
                                                        class="required">*</span></label>
                                                    <select class="form-select" name="qualification[]" required>
                                                    <option>-Select Qualification-</option>
                                                  
                                                    <option value="graduate">Graduate</option>
                                                    <option value="postgraduate">Postgraduate</option>
                                                </select>
                                            </div>
                                        </div> -->
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="labelInput">योग्यता/Qualification<span class="required">*</span></label>
                                                <select class="form-select" name="qualification[]" required>
                                                    <option value="">-Select Qualification-</option>
                                                    <option value="graduate" 
                                                        @if (isset($value->qualification) && $value->qualification == 'graduate') selected @endif>
                                                        Graduate
                                                    </option>
                                                    <option value="postgraduate" 
                                                        @if (isset($value->qualification) && $value->qualification == 'postgraduate') selected @endif>
                                                        Postgraduate
                                                    </option>
                                                </select>
                                            </div>
                                        </div>


                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="labelInput">आधार/Aadhaar No.<span
                                                        class="required">*</span></label>

                                                <input type="text" class="form-control aadhar_number contact_person_aadhar_number{{$key}}"
                                                    id="contact_person_aadhar_number"
                                                    name="aadhaar_no[]"
                                                    value="{{ $value->aadhaar_no ?? '' }}" required  onblur="checkAadhaarNo(this.value,'contact_person_aadhar_number{{$key}}')"/>

                                            </div>
                                        </div>
                                        {{-- <div class="mt-2 text-left">
                                               <div class="form-group change">
                                                   <label for="">&nbsp;</label><br />
                                                   <a class="mdi mdi-delete btn btn-soft-danger "
                                                       href="javascript:void(0);"
                                                       onclick="confirmDelete_('{{ $value->id }}')"
                                        alt="Remove"></a>
                                    </div>
                                </div> --}}
                            </div>
                            <hr>
                        </div>
                    </div>
                    @endforeach
                    @elseif ($noofInsp > $userinsCount)
                    @foreach ($userinsdetail as $key => $value)
                    <div
                        class="live-preview after-add-more  p-3 mb-1 {{ ($key + 1) % 2 == 0 ? '' : '' }}">
                        {{ $key + 1 }}.
                        <div id="row{{ $value->id }}">
                            <input type="hidden" class="form-control" value="{{ $value->id }}"
                                name="row_id[]" />
                            <div class="row seperatesec white-inner">
                                <div class="col-xxl-3 col-md-3">
                                    <div>
                                        <label class="form-label">निरीक्षक का नाम/Name of Inspector<span
                                                class="required">*</span></label>
                                        <input type="text" class="form-control charater_allow"
                                            id="placeholderInput" placeholder="Name of Inspector"
                                            name="inspector_name[]"
                                            value="{{ $value->name_of_inspector ?? '' }}" required />
                                    </div>
                                </div>
                                <div class="col-xxl-3 col-md-3">
                                    <div>
                                        <label for="labelInput" class="form-label">मोबाइल नंबर/Mobile Number<span
                                                class="required">*</span></label>
                                        <input type="text" class="form-control numbersonly mobile"
                                            maxlength="10" id="mobile_number"
                                            placeholder="Mobile Number" name="mobile_no[]"
                                            value="{{ $value->mobile_no ?? '' }}" required />
                                    </div>
                                    <button type="button" class="btn btn-primary mt-2" id="getOtpBtn"
                                        onclick="sendOtp()">ओटीपी प्राप्त करें/ Get OTP</button>

                                    <!-- Resend OTP Button (Initially Hidden) -->
                                    <button type="button" class="btn btn-warning mt-2" id="resendOtpBtn"
                                        onclick="sendOtp()" style="display: none;">Resend OTP</button>

                                    <!-- Verified Button (Initially Hidden) -->
                                    <button type="button" class="btn btn-success mt-2" id="verifiedBtn"
                                        style="display: none;" disabled>Verified</button>

                                    <!-- OTP Input Section (Initially Hidden) -->
                                    <div id="otp_section" style="display: none;">
                                        <input type="text" id="otp_input" class="form-control mt-2"
                                            placeholder="Enter OTP" maxlength="6">
                                        <button type="button" class="btn btn-primary mt-2" onclick="verifyOtp()">Verify
                                            OTP</button>
                                    </div>
                                </div>
                                <div class="col-xxl-4 col-md-4 ">
                                    <div>
                                        <label for="labelInput" class="form-label">ईमेल आईडी/Email Id<span
                                                class="required">*</span></label>
                                        <input type="email" class="form-control email_id"
                                            id="placeholderInput" placeholder="Email Id"
                                            name="email[]" value="{{ $value->email ?? '' }}"
                                            required />
                                    </div>
                                    @if (empty($value->email))
                                    <div
                                        class="input-group-append col-12 col-sm-12 col-md-2 col-lg-2">

                                        <button type="button"
                                            class="btn-email btn btn-outline-success waves-effect waves-light visitorCat2">Get
                                            OTP</button>
                                        <button type="button"
                                            class="btn btn-ghost-success waves-effect waves-light btn-mailsend"
                                            style="display:none">Mail Send</button>
                                        <button type="button"
                                            class="btn btn-ghost-success waves-effect waves-light btn-verify"
                                            style="display:none">Verified</button>
                                    </div>
                                    @endif
                                </div>
                            </div>


                            <div class="row white-inner">

                                <div class="sectitle ">
                                    <label for="labelInput" class="form-label blue-ht">इंस्पेक्टर का पता/Address of
                                        Inspector</label>
                                </div>
                                <div class="col-xxl-3 col-md-3 gy-3">
                                    <div class="row">
                                        <div class="col-xx-12 col-md-12">
                                            <label for="labelInput" class="form-label">पता/Address<span
                                                    class="required">*</span></label>
                                            <textarea placeholder="Address of The Inspector" class="form-control customtextarea" name="address[]" required>{{ $value->address ?? '' }}</textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xxl-9 col-md-9">
                                    <div class="row">
                                        <div class="col-xxl-4 col-md-4 gy-3">
                                            <div>
                                                <label for="labelInput" class="form-label">State <span
                                                        class="required">*</span></label>
                                                <select class="form-select state" name="state[]"
                                                    required>
                                                    <option value="">Select State</option>
                                                    @forelse($states as $state)
                                                    <option value="{{ $state->id }}"
                                                        {{ $value->ref_state_id == $state->id ? 'selected' : '' }}>
                                                        {{ $state->state_name }}
                                                    </option>
                                                    @empty
                                                    @endforelse
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-xxl-4 col-md-4 gy-3">
                                            <div>
                                                <label for="labelInput" class="form-label">District
                                                    <span class="required">*</span></label>
                                                <select class="form-select district" name="district[]"
                                                    required>
                                                    <option value="">Select District</option>
                                                    @forelse(getDistrictByStateID($value->ref_state_id) as $district)
                                                    <option value="{{ $district->id }}"
                                                        {{ isset($value) && $value->ref_district_id == $district->id ? 'selected' : '' }}>
                                                        {{ $district->district_name }}
                                                    </option>
                                                    @empty
                                                    @endforelse
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-xxl-4 col-md-4 gy-3">
                                            <div>
                                                <label for="labelInput"
                                                    class="form-label">Taluka/Mandal<span
                                                        class="required">*</span></label>
                                                <select class="form-select block_tehsil"
                                                    name="taluka[]" required>
                                                    <option value="">Select Taluka/Mandal
                                                    </option>
                                                    @forelse(getBlockTehsilByDistrictID($value->ref_district_id) as $region)
                                                    <option value="{{ $region->id }}"
                                                        {{ isset($value->ref_block_tehsil_id) && $value->ref_block_tehsil_id == $region->id ? 'selected' : '' }}>
                                                        {{ $region->block_tehsil_name }}
                                                    </option>
                                                    @empty
                                                    @endforelse
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-xxl-6 col-md-6 gy-3">
                                            <div>
                                                <label class="form-label">Village </label>
                                                <select class="form-select village" name="village[]"
                                                    required>
                                                    <option value="">Select Village</option>
                                                    @forelse(getVillageByBlock($value->ref_block_tehsil_id) as $village)
                                                    <option value="{{ $village->id }}"
                                                        @if (isset($value) && $value->ref_village_id == $village->id) selected @endif>
                                                        {{ $village->village_name }}
                                                    </option>
                                                    @empty
                                                    @endforelse
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-xxl-6 col-md-6 gy-3">
                                            <div>
                                                <label for="labelInput" class="form-label">Pin
                                                    Code<span class="required">*</span></label>
                                                <input type="text" class="form-control numbersonly"
                                                    maxlength="6" id="placeholderInput"
                                                    placeholder="Pin Code" name="pincode[]"
                                                    value="{{ $value->pin ?? '' }}" required />
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>

                            <div class="row white-inner">

                                <div class="col-xxl-3 col-md-3 gy-3 ">
                                    <div>
                                        <label for="basiInput" class="form-label">आईडी प्रमाण/ID Proof<span
                                                class="required">*</span>
                                        </label>
            
                                        <select class="form-select id_proof" name="id_proof[]" required>
                                            <option value="">-Select-</option>
                                            <option value="aadhar">Aadhaar</option>
                                            <!-- <option value="voter_id">Voter Id</option>
                                                                        <option value="driving_licence">Driving Licence</option> -->
                                        </select>
            
                                    </div>
                                </div>
                                <div class="col-xxl-3 col-md-3 gy-3 id_proof_doc" style='display:none;'>
                                    <div>
                                        <label class="form-label upload_document">आधार/Aadhaar No.<span
                                                class="required">*</span></label>
                                        
                                        <input type="text" class="form-control numbersonly contact_person_aadhar_number aadhar_number"
                                            maxlength="12" id="contact_person_aadhar_number0_2"
                                            placeholder="Aadhaar No." name="aadhaar_no[]"
                                            value="" required onblur="checkAadhaarNo(this.value,'contact_person_aadhar_number0_2')"/>
            
            
                                    </div>
                                </div>
            
                                <div class="col-xxl-3 col-md-3 gy-3">
                                    <div>
                                        <label class="form-label">नियुक्ति पत्र/Appointment Letter<span
                                                class="required">*</span></label>
                                        <input type="file" class="form-control upload_document"
                                            name="appointment_doc[]" id="appointment_doc" required>
                                        <span class="form-text" accept="image/png, application/pdf, image/jpeg">Supported formats:JPG, PNG, PDF. Upto
                                            2MB</span>
                                    </div>
                                </div>
                                <div class="col-xxl-3 col-md-3 gy-3">
                                    <div>
                                        <label class="labelInput">योग्यता/Qualification<span
                                                class="required">*</span></label>
                                        <select class="form-select" name="qualification[]" required>
                                            <option>-Select Qualification-</option>
                                            <!-- <option value="10th">10th Grade</option>
                                                                        <option value="12th">12th Grade</option> -->
                                            <option value="graduate">Graduate</option>
                                            <option value="postgraduate">Postgraduate</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="mt-2 text-left">
                                    <div class="form-group change">
            
                                    </div>
                                </div>
                            </div>
                    <hr>
                </div>
            </div>
            @endforeach
            @for ($i = 0; $i < $noofInsp - $userinsCount; $i++)
                <div class="live-preview after-add-more p-3 mb-1 ">

                <div class="row seperatesec white-inner">
                    {{ $i + 1 }}.
                    <div class="col-xxl-3 col-md-3 ">
                        <div>
                            <label class="form-label">निरीक्षक का नाम/Name of Inspector<span
                                    class="required">*</span></label>
                            <input type="text" class="form-control charater_allow" id="placeholderInput"
                                placeholder="Name of Inspector" name="inspector_name[]"
                                value="" required />
                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-3">
                        <div>
                            <label for="labelInput" class="form-label">मोबाइल नंबर/Mobile Number<span
                                    class="required">*</span></label>
                            <input type="text" class="form-control numbersonly mobile"
                                maxlength="10" id="placeholderInput"
                                placeholder="Mobile Number*" name="mobile_no[]"
                                value="" required />


                        </div>
                    </div>

                    <div class="col-xxl-4 col-md-4 ">
                        <div class="inputEmail  col-12 col-sm-12 col-md-12 col-lg-12">
                            <div class="form-group d-flex justify-content-center ge-otp-form">
                                <div class="col-12 col-sm-12 col-md-10 ">
                                    <label>ईमेल आईडी/Email ID<span class="text-danger">*</span></label>
                                    <input
                                        class="form-control validateEmailId col-12 col-sm-12 col-md-12 col-lg-12"
                                        type="text" value="" placeholder="Email Id"
                                        id="email_id1" name="email[]" required />
                                </div>

                                <div
                                    class="input-group-append col-12 col-sm-12 col-md-2 col-lg-2">

                                    <button type="button"
                                        class="btn-email btn btn-outline-success waves-effect waves-light visitorCat2">Get
                                        OTP</button>

                                    <button type="button"
                                        class="btn btn-ghost-success waves-effect waves-light btn-mailsend"
                                        style="display:none">Mail Send</button>
                                    <button type="button"
                                        class="btn btn-ghost-success waves-effect waves-light btn-verify"
                                        style="display:none">Verified</button>
                                </div>

                            </div>
                            <div class="verify-email justify-content-center">
                                <div class="login-pass mb-4 otp-email col-12 col-sm-12 col-md-5 col-lg-12 pl-2"
                                    style="display:none">
                                    <div class="input-group">
                                        <span class="input-group-text mdi mdi-key"
                                            id="inputGroup-sizing-default"></span>
                                        <input type="text" class="form-control inp-b"
                                            aria-label="Sizing example input"
                                            aria-describedby="inputGroup-sizing-default"
                                            id="email_otp1">
                                        <div class="input-group-append">
                                            <a href="javascript:void(0)"
                                                class="verifiEmail_otp btn btn-outline-success waves-effect waves-light">Verify</a>
                                            <a href="javascript:void(0)"
                                                class="resendEmail_otp btn btn-outline-danger waves-effect waves-light">Resend</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="row white-inner">
                    <div class="sectitle">
                        <label for="labelInput" class="form-label blue-ht"><b>इंस्पेक्टर का पता/Address of
                                Inspector</b></label>
                    </div>

                    <div class="col-xxl-3 col-md-3 gy-3">
                        <div class="row">
                            <div class="col-xx-12 col-md-12">
                                <label for="labelInput" class="form-label">पता/Address<span
                                        class="required">*</span></label>
                                <textarea placeholder="Address of The Inspector" class="form-control customtextarea" name="address[]" required></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-9 col-md-9  ">
                        <div class="row  ">
                            <div class="col-xxl-4 col-md-4 gy-3">
                                <div>
                                    <label for="labelInput" class="form-label">राज्य/State<span
                                            class="required">*</span></label>
                                    <select class="form-select state" name="state[]" required>
                                        <option value="">Select State</option>
                                        @forelse($states as $state)
                                        <option value="{{ $state->id }}">
                                            {{ $state->state_name }}
                                        </option>
                                        @empty
                                        @endforelse
                                    </select>
                                </div>
                            </div>

                            <div class="col-xxl-4 col-md-4 gy-3">
                                <div>
                                    <label for="labelInput" class="form-label">जिला/District
                                        <span class="required">*</span></label>
                                    <select class="form-select district" name="district[]"
                                        required>
                                        <option value="">Select District</option>
                                        @forelse($districts as $district)
                                        <option value="{{ $district->id }}">
                                            {{ $district->district_name }}
                                        </option>
                                        @empty
                                        @endforelse
                                    </select>
                                </div>
                            </div>

                            <div class="col-xxl-4 col-md-4 gy-3">
                                <div>
                                    <label for="labelInput"
                                        class="form-label">तहसील/मंडल/Taluka/Mandal<span
                                            class="required">*</span></label>
                                    <select class="form-select block_tehsil" name="taluka[]"
                                        required>
                                        <option value="">Select Taluka/Mandal
                                        </option>
                                        @forelse($regions as $region)
                                        <option value="{{ $region->id }}">
                                            {{ $region->block_tehsil_name }}
                                        </option>
                                        @empty
                                        @endforelse
                                    </select>
                                </div>
                            </div>

                            <div class="col-xxl-6 col-md-6 gy-3">
                                <div>
                                    <label class="form-label">गांव/Village </label>
                                    <select class="form-select village" name="village[]"
                                        required>
                                        <option value="">Select Village</option>
                                        @forelse($villages as $village)
                                        <option value="{{ $village->id }}">
                                            {{ $village->village_name }}
                                        </option>
                                        @empty
                                        @endforelse
                                    </select>
                                </div>
                            </div>

                            <div class="col-xxl-6 col-md-6 gy-3">
                                <div>
                                    <label for="labelInput" class="form-label">पिन कोड/Pin
                                        Code<span class="required">*</span></label>
                                    <input type="text" class="form-control numbersonly"
                                        maxlength="6" id="placeholderInput"
                                        placeholder="Pin Code" name="pincode[]" value=""
                                        required />
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="row white-inner">

                    <div class="col-xxl-3 col-md-3 gy-3 ">
                        <div>
                            <label for="basiInput" class="form-label">आईडी प्रमाण/ID Proof<span
                                    class="required">*</span>
                            </label>

                            <select class="form-select id_proof" name="id_proof[]" required>
                                <option value="">-Select-</option>
                                <option value="aadhar">Aadhaar</option>
                                <!-- <option value="voter_id">Voter Id</option>
                                                            <option value="driving_licence">Driving Licence</option> -->
                            </select>

                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-3 gy-3 id_proof_doc" style='display:none;'>
                        <div>
                            <label class="form-label upload_document">आधार/Aadhaar No.<span
                                    class="required">*</span></label>
                            
                            <input type="text" class="form-control numbersonly contact_person_aadhar_number aadhar_number"
                                maxlength="12" id="contact_person_aadhar_number0_2"
                                placeholder="Aadhaar No." name="aadhaar_no[]"
                                value="" required onblur="checkAadhaarNo(this.value,'contact_person_aadhar_number0_2')"/>


                        </div>
                    </div>

                    <div class="col-xxl-3 col-md-3 gy-3">
                        <div>
                            <label class="form-label">नियुक्ति पत्र/Appointment Letter<span
                                    class="required">*</span></label>
                            <input type="file" class="form-control upload_document"
                                name="appointment_doc[]" id="appointment_doc" required>
                            <span class="form-text" accept="image/png, application/pdf, image/jpeg">Supported formats:JPG, PNG, PDF. Upto
                                2MB</span>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-md-3 gy-3">
                        <div>
                            <label class="labelInput">योग्यता/Qualification<span
                                    class="required">*</span></label>
                            <select class="form-select" name="qualification[]" required>
                                <option>-Select Qualification-</option>
                                <!-- <option value="10th">10th Grade</option>
                                                            <option value="12th">12th Grade</option> -->
                                <option value="graduate">Graduate</option>
                                <option value="postgraduate">Postgraduate</option>
                            </select>
                        </div>
                    </div>
                    <div class="mt-2 text-left">
                        <div class="form-group change">

                        </div>
                    </div>
                </div>

    </div>
    @endfor
    @endif
    {{-- <div class="row seperatesec ">
                                    <div class="col-xxl-4 col-md-4 gy-3">
                                        <div>
                                            <i data-type="wm" data-id=""
                                                class="mdi mdi-plus btn btn-soft-success add-more" data-toggle="tooltip"
                                                title="Add Row"></i>
                                        </div>
                                    </div>
                                </div> --}}

    <div class="row">
        <div class="col-lg-12 gy-4">
            <div class="hstack gap-2">
                <a href="{{ route('superadmin.icsuser.step2', $userdetails->id) }}"
                    class="btn btn-soft-success">Back</a>
                <button type="submit" id="submitbtn"
                    class="btn btn-primary submit-button">Save & Next</button>
                {{-- <a
                                                href="{{ route('superadmin.icsuser.step5', $userdetails->id) }}"class="btn btn-soft-success">Next</a> --}}
            </div>
        </div>
    </div>
</div>
</div>
</div>
</div>
</form>
</div>
</div>
@endsection
@push('script')
<script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>

<script>
    
    $('.upload_document').on('change', function() {
        var $this = $(this);
        var file = $this[0].files[0];
        var fileType = file.type;
        var fileSize = file.size;
        var allowedTypes = ['application/pdf', 'image/jpeg', 'image/png'];

        // Check for file type
        if (!allowedTypes.includes(fileType)) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid File Type',
                text: 'Please upload PDF, JPG, or PNG only.',
            });
            $this.val("");
            return false;
        }

        // Check for file size
        if (fileSize > 1000000) { // 2 MB in bytes
            Swal.fire({
                icon: 'error',
                title: 'File Size Too Large',
                text: 'Please upload files of size 1 MB or less only.',
            });
            $this.val("");
            return false;
        }
    });


    $(document).ready(function() {
    $('.aadhar_number').on('input', function() {
        var value = $(this).val();
        $(this).val(value.replace(/[^0-9]/g, ''));
        if ($(this).val().length > 12) {
            $(this).val($(this).val().slice(0, 12)); 
        }
    });
    $('#inspectorfrm').on('submit', function(event) {
        var isValid = true;
        $('.aadhar_number').each(function() {
            var aadhaarInput = $(this).val();
            if (aadhaarInput.length !== 12) {
                isValid = false;  
                event.preventDefault();
                return false; 
            }
        });

        if (!isValid) {
            event.preventDefault();  
        }
    });
});





function checkAadhaarNo(val, classname) {
    var numericValue = val.replace(/[^0-9]/g, '');
    if (numericValue.length !== 12) {
        Swal.fire({
                icon: 'info',
                title: 'Aadhaar',
                text: 'Please enter 12 digits Aadhaar number.',
            });
        
        document.querySelector('.' + classname).value = '';
    } else {
        document.querySelector('.' + classname).value = numericValue;
    }
}




    $(".btn-email").click(function(e) {
        e.preventDefault();
        var user_email = $('#email_id1').val();
        $(".overlay").show();

        if (user_email != "") {
            $.ajax({
                type: 'POST',
                url: "{{ route('superadmin.usermanagement.email_mobile_OTP') }}",
                data: {
                    'user_email': user_email
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(resp) {
                    if (resp == 1) {

                        Swal.fire({
                            text: "Please verify OTP send on Email id",
                            icon: 'success',
                            confirmButtonText: 'OK'
                        }).then((result) => {
                            $('.otp-email').show(500);
                            $('#email_id1').val(user_email);
                            $('#email_id1').prop('readonly', true);
                            $('.btn-email').hide(500);
                            $('.btn-mailsend').show(100);
                        });

                    }
                    $(".overlay").hide();
                }
            });
        } else {
            Swal.fire("", "Please enter Email ID", "error");
        }
    });


    $(".verifiEmail_otp").click(function(e) {
        e.preventDefault();
        var email_otp = $('#email_otp1').val();
        $(".overlay").show();
        if (email_otp != "") {

            $.ajax({
                type: 'POST',
                url: "{{ route('superadmin.usermanagement.email_mobile_OTP_check') }}",
                data: {
                    'email_otp': email_otp
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(html) {
                    if (html == 0) {
                        Swal.fire("", "Please enter Valid OTP", "error");
                    } else {
                        $('#email_otp').prop('readonly', true);
                        $('.otp-email1').hide(500);
                        $('.btn-email').hide(500);
                        $('.btn-verify').show(500);
                        $('.visitorCat').hide(500);
                        $('.visitorCat1').hide(500);
                        $('.user_detail_page').show(500);
                        $('#email_id').prop('readonly', true);
                        $('.btn-mailsend').hide();
                        $('.login-pass').hide();
                    }
                    $(".overlay").hide();
                }
            });
        } else {
            Swal.fire("", "Please enter OTP", "error");
        }
    });

    $(".resendEmail_otp").click(function(e) {
        e.preventDefault();
        var user_email = $('#email_id1').val();

        $.ajax({
            type: 'POST',
            url: "{{ route('superadmin.usermanagement.email_mobile_OTP') }}",
            data: {
                'user_email': user_email
            },
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(html) {
                Swal.fire("", "Re OTP Send!!", "success");
            }
        });
    });
</script>


<script>
    $('.id_proof').change(function() {
        var th = $(this);
        var idProof = this.value;
        if (idProof != '') {
            th.closest('.row').find('.id_proof_doc').show();
        } else {
            th.closest('.row').find('.id_proof_doc').hide();
        }
    });

    $('.address_proof').change(function() {
        var th = $(this);
        var address_proof = this.value;
        if (address_proof != '') {
            th.closest('.row').find('.address_proof_doc').show();
        } else {
            th.closest('.row').find('.address_proof_doc').hide();
        }
    });

    //$("#inspectorfrm").validate();
    // $("#inspectorfrm").validate({
    //     rules: {
    //         "inspector_name[*]": "required"
    //     },
    // });
    $(document).on('click', '#submitbtn', function() {

        if (checkValidation("inspectorfrm")) {
            $('#inspectorfrm').submit();
            return true;
        } else {
            return false;
        }
    });

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    function confirmDelete_(id) {

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.value) {
                $.ajax({
                    url: "{{ route('superadmin.icsuser.deleteinspector') }}",
                    method: "POST",
                    dataType: 'json',
                    data: {
                        'id': id,
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(result) {
                        $('#row' + id).remove();
                        Swal.fire(
                            'Deleted!',
                            'Record Deleted Successfully..',
                            'success'
                        );
                    }
                });
            }
        })
    }
    $(document).ready(function() {
        $("body").on("click", ".add-more", function() {
            var html = $(".after-add-more").first().clone().find("input").val("").end().find("select")
                .val("").end().find("textarea").val("").end().find("file").val("").end().find("a")
                .remove().end();

            $(html).find(".change").html(
                "<label for=''>&nbsp;</label><br/><a class='mdi mdi-delete btn btn-soft-danger remove'></a>"
            );
            $(".after-add-more").last().after(html);

            $('.state').on('change', function() {
                var th = $(this);
                var state_id = this.value;

                $.ajax({
                    url: districtUrl,
                    type: "POST",
                    data: {
                        state_id: state_id,
                    },
                    dataType: 'json',
                    success: function(result) {
                        if (result) {
                            th.closest('.row').find('.district').html(result);
                        }
                    }
                });
            });

            $('.district').on('change', function() {
                var th = $(this);
                var district_id = this.value;

                $.ajax({
                    url: blockTehsilUrl,
                    type: "POST",
                    data: {
                        district_id: district_id,
                    },
                    dataType: 'json',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(result) {
                        if (result) {
                            th.closest('.row').find('.block_tehsil').html(result);
                        }
                    }
                });
            });
            $('.block_tehsil').on('change', function() {
                var th = $(this);
                var block_tehsil_id = this.value;
                $.ajax({
                    url: villageUrl,
                    type: "POST",
                    data: {
                        block_tehsil_id: block_tehsil_id,
                    },
                    dataType: 'json',
                    success: function(result) {
                        if (result) {
                            th.closest('.row').find('.village').html(result);
                        }
                    }
                });
            });
        });

        $("body").on("click", ".remove", function() {
            $(this).parents(".after-add-more").remove();
        });



    });



    $(document).on('change', '.email_id', function() {
        var email_id = $(this).val();
        $.ajax({
            type: "POST",
            data: {
                "email_id": email_id
            },
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            url: "{{ route('uniqueEmailMobile') }}",
            success: function(result) {

                if (result == 1) {
                    Swal.fire(
                        'Oops!',
                        'Email id already exits.',
                        'error'
                    );
                    $(".submit-button").prop("disabled", true);
                } else {
                    $(".submit-button").prop("disabled", false);
                }
            }
        });
    });
    $(document).on('change', '.mobile', function() {
        var mobile = $(this).val();

        var phoneno = /^\d{10}$/;
        if (mobile.match(phoneno)) {
            //return true;
        } else {
            Swal.fire('', 'Please enter a valid mobile number.', 'warning');
            // $(".mobile").val('');
            $(this).val('');
            return false;
        }
        $.ajax({
            type: "POST",
            data: {
                "mobile": mobile
            },
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            url: "{{ route('uniqueEmailMobile') }}",
            success: function(result) {
                if (result == 2) {
                    Swal.fire(
                        'Oops!',
                        'Mobile Number already exits.',
                        'error'
                    );
                    $(".submit-button").prop("disabled", true);
                } else {
                    $(".submit-button").prop("disabled", false);
                }
            }
        });
    });
</script>

<script>
    function showLoader() {
        document.getElementById('overlay').classList.remove('d-none');
        document.getElementById('loader').classList.remove('d-none');
    }

    function hideLoader() {
        document.getElementById('overlay').classList.add('d-none');
        document.getElementById('loader').classList.add('d-none');
    }

    function checkFormSubmission() {
        var isEmailVerified = document.getElementById('contact_person_email').style.display === 'inline-block';

        if (isOtpVerified && isEmailVerified) {
            document.getElementById('submitBtn').style.display = 'inline-block'; // Show submit button
        }
    }

    function sendOtp() {
        var mobile = document.getElementById('mobile_number').value;
        if (mobile.length === 10) {
            showLoader();
            fetch('{{ route('sendOtpReg')}}', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '{{ csrf_token() }}'
                        },
                        body: JSON.stringify({
                            mobile_number: mobile
                        })
                    })
                .then(response => response.json())
                .then(data => {
                    hideLoader();
                    if (data.status === 'success') {
                        $('.mobile_number').prop("disabled", true);
                        Swal.fire({
                            icon: 'success',
                            title: 'Valid Mobile Number',
                            text: 'OTP sent successfully!',
                        });
                        document.getElementById('otp_section').style.display = 'block'; // Display OTP section
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Failed to send OTP',
                            text: 'Please try again.',
                        });
                    }
                })
                .catch(error => {
                    hideLoader();
                    console.error('Error:', error);
                    Swal.fire({
                        icon: 'error',
                        title: 'An error occurred',
                        text: 'Please try again.',
                    });
                });
        } else {
            hideLoader();
            Swal.fire({
                icon: 'error',
                title: 'Invalid Mobile Number',
                text: 'Please Enter a Valid 10-digit Mobile Number.',
            });
        }
    }

    function verifyOtp() {
        var mobile = document.getElementById('mobile_number').value;
        var otp = document.getElementById('otp_input').value; // Updated to use the correct OTP input field
        if (otp.length === 4) {
            showLoader();
            fetch('{{ route('verifyOtpReg') }}', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '{{ csrf_token() }}'
                        },
                        body: JSON.stringify({
                            mobile_number: mobile,
                            otp: otp
                        })
                    })
                .then(response => {
                    const contentType = response.headers.get("content-type");
                    if (contentType && contentType.includes("application/json")) {
                        return response.json();
                    } else {
                        throw new Error('Received non-JSON response');
                    }
                })
                .then(data => {
                    hideLoader();
                    console.log(data.status);
                    if (data.status === 'success') {
                        Swal.fire({
                            icon: 'success',
                            title: 'OTP Verified',
                            text: 'Your OTP has been verified successfully!',
                        });

                        // Hide Get OTP button and Resend OTP button, show Verified button
                        document.getElementById('mobile_number').readOnly = true;
                        document.getElementById('getOtpBtn').style.display = 'none';
                        document.getElementById('resendOtpBtn').style.display = 'none'; // Hide Resend OTP button
                        document.getElementById('verifiedBtn').style.display =
                            'inline-block'; // Show Verified button

                        // Hide the OTP input section after successful verification
                        document.getElementById('otp_section').style.display = 'none';
                        isOtpVerified = true;
                        // checkFormSubmission();
                    } else {
                        hideLoader();
                        Swal.fire({
                            icon: 'error',
                            title: 'Invalid OTP',
                            text: 'The OTP you entered is incorrect. Please try again.',
                        });
                    }
                })
                .catch(error => {
                    hideLoader();
                    console.error('Error:', error);
                    Swal.fire({
                        icon: 'error',
                        title: 'An error occurred',
                        text: 'Unable to verify the OTP. Please try again.',
                    });
                });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Invalid OTP',
                text: 'Please enter a valid 4-digit OTP.',
            });
        }
    }



    $(document).ready(function() {
            $('.charater_allow').on('keypress', function(event) {
                var keyCode = event.which || event.keyCode;
                if (!((keyCode >= 65 && keyCode <= 90) || 
                      (keyCode >= 97 && keyCode <= 122) || 
                      keyCode == 8 || 
                      keyCode == 46)) { 
                    event.preventDefault(); 
                }
            });
            $('.charater_allow').on('input', function() {
                var value = $(this).val();
                $(this).val(value.replace(/[^a-zA-Z]/g, '')); r
            });
        });



</script>
@endpush
@extends('admin.layouts.app')

@section('content')
    <style>
        .has-error {
            border: 1px solid red;
        }

        .errormsg {
            color: red;
            font-size: 14px !important;
        }
    </style>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0"> Schedule for Survey</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Schedule for Survey</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">
            <form method="post" enctype="multipart/form-data" id="inspSchedule"
                action="{{ route('superadmin.icsuser.inspectorSchedulePost') }}">
                @csrf

                <div class="tab-content py-4 custom-tab-content">
                    <div class="tab-pane fade show active" id="step1">
                        <div class="card">
                            <div class="card-header align-items-center d-flex">
                                <h4 class="card-title mb-0 flex-grow-1">
                                    <div class="alert alert- alert-dismissible  label-arrow fade show" role="alert">
                                        <strong>{{ ucwords(getInspectorName($id)->name_of_inspector) }}</strong> - Inspector
                                        Schedule for Survey Period

                                    </div>
                                </h4>

                            </div>
                            <!-- end card header -->
                            <div class="card-body">
                                <div class="live-preview">
                                    @forelse($scheduleDetails as $key => $value)
                                        @if ($key == 0)
                                            <div class="row seperatesec white-inner">
                                                <div class="col-xxl-6 col-md-6 gy-6">
                                                    <div>
                                                        <input type="hidden" name="at_ics_inspector_details_id"
                                                            value="{{ $id }}">
                                                        <input type="hidden" name="at_user_id" value="{{ $inspId }}">

                                                        <label class="form-label">Start Date<span class="required">
                                                                *</span></label>
                                                        <input type="date" value="{{ $value->schedule_period_from }}"
                                                            class="form-control fssai_license_validity_from"
                                                            name="schedule_period_from" onchange="startDateFunction(this);" required>
                                                    </div>
                                                </div>
                                                <div class="col-xxl-6 col-md-6 gy-6">
                                                    <div>
                                                        <label class="form-label">End Date<span class="required">
                                                                *</span></label>
                                                        <input type="date" class="form-control fssai_license_validity_to"
                                                            value="{{ $value->schedule_period_to }}"
                                                            name="schedule_period_to" onchange="endDateFunction(this);"
                                                            required>
                                                    </div>
                                                </div>

                                            </div>
                                        @endif
                                        <div class="after-add-more">
                                            <div class="row seperatesec white-inner" id="row{{ $value->id }}">
                                                <input type="hidden" name="row_id[]" value="{{ $value->id }}">
                                                <div class="col-xxl-3 col-md-2 gy-3">
                                                    <div>
                                                        {{-- to be registerd by the inspector by schedule time --}}
                                                        <label class="form-label">No. of farmers <span class="required">
                                                                *</span></label>
                                                        <input type="text" class="form-control numbersonly"
                                                            value="{{ $value->number_of_farmer_reg }}"
                                                            id="fssai_license_validity"
                                                            placeholder="Number of farmers to be registerd by the inspector by schedule time"
                                                            name="number_of_farmer_reg[]" required>
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-2 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">State <span
                                                                class="required">*</span></label>
                                                        <select class="form-select state" name="ref_state_id[]" required>
                                                            <option value="">Select State</option>
                                                            @forelse($states as $state)
                                                                <option value="{{ $state->id }}"
                                                                    @if (isset($value->ref_state_id) && $value->ref_state_id == $state->id) selected @endif>
                                                                    {{ $state->state_name }}</option>
                                                            @empty
                                                            @endforelse
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-xxl-4 col-md-2 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">District <span
                                                                class="required">*</span></label>
                                                        <select class="form-select district" name="ref_district_id[]"
                                                            required>
                                                            <option value="">Select District</option>
                                                            @forelse(getDistrictByStateID($value->ref_state_id) as $district)
                                                                <option value="{{ $district->id }}"
                                                                    @if (isset($value->ref_district_id) && $value->ref_district_id == $district->id) selected @endif>
                                                                    {{ $district->district_name }}</option>
                                                            @empty
                                                            @endforelse
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-3 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">Taluka/Mandal
                                                            <span class="required">*</span></label>
                                                        <select class="form-select block_tehsil"
                                                            name="ref_block_tehsil_id[]" required>
                                                            <option value="">Select Taluka/Mandal</option>
                                                            @forelse(getBlockTehsilByDistrictID($value->ref_district_id) as $region)
                                                                <option value="{{ $region->id }}"
                                                                    @if (isset($value->ref_block_tehsil_id) && $value->ref_block_tehsil_id == $region->id) selected @endif>
                                                                    {{ $region->block_tehsil_name }}</option>
                                                            @empty
                                                            @endforelse
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-3 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">Village
                                                            <span class="required">*</span></label>
                                                        <select class="form-select village" name="ref_village_id[]"
                                                            required>
                                                            <option value="">Select Village</option>
                                                            @forelse(getVillageByBlock($value->ref_block_tehsil_id) as $village)
                                                                <option value="{{ $village->id }}"
                                                                    @if (isset($value->ref_village_id) && $value->ref_village_id == $village->id) selected @endif>
                                                                    {{ $village->village_name }}</option>
                                                            @empty
                                                            @endforelse
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="mt-2 text-sm-end">
                                                    <div class="form-group change">

                                                        <label for="">&nbsp;</label><br />
                                                        <a class="mdi mdi-delete btn btn-soft-danger "
                                                            href="javascript:void(0);"
                                                            onclick="confirmDelete_('{{ $value->id }}')"
                                                            alt="Remove"></a>


                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    @empty
                                        <div class="row seperatesec white-inner">
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <input type="hidden" name="at_ics_inspector_details_id"
                                                        value="{{ $id ?? '' }}">
                                                    <input type="hidden" name="at_user_id" value="{{ $inspId ?? '' }}">
                                                    <label class="form-label">Start Date<span class="required">
                                                            *</span></label>
                                                    <input type="date" value=""
                                                        class="form-control fssai_license_validity_from"
                                                        name="schedule_period_from" onchange="startDateFunction(this);" required>
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-md-3 gy-3">
                                                <div>
                                                    <label class="form-label">End Date<span class="required">
                                                            *</span></label>
                                                    <input type="date" class="form-control fssai_license_validity_to"
                                                        value="" name="schedule_period_to"
                                                        onchange="endDateFunction(this);" required>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="after-add-more">
                                            <div class="row seperatesec white-inner">
                                                <input type="hidden" name="row_id[]" value="">
                                                <div class="col-xxl-3 col-md-6 gy-3">
                                                    <div>
                                                        <label class="form-label">Number of farmers to be registerd by the
                                                            inspector by schedule time<span class="required">
                                                                *</span></label>
                                                        <input type="text" class="form-control numbersonly"
                                                            value="" id="fssai_license_validity"
                                                            placeholder="Number of farmers to be registerd by the inspector by schedule time"
                                                            name="number_of_farmer_reg[]" required>
                                                    </div>
                                                </div>
                                                <div class="col-xxl-4 col-md-3 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">State <span
                                                                class="required">*</span></label>
                                                        <select class="form-select state" name="ref_state_id[]" required>
                                                            <option value="">Select State</option>
                                                            @forelse($states as $state)
                                                                <option value="{{ $state->id }}">
                                                                    {{ $state->state_name }}</option>
                                                            @empty
                                                            @endforelse
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-xxl-4 col-md-3 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">District <span
                                                                class="required">*</span></label>
                                                        <select class="form-select district" name="ref_district_id[]"
                                                            required>
                                                            <option value="">-Select District-</option>
                                                            {{-- @forelse($districts as $district)
                                                                <option value="{{$district->id}}">{{$district->district_name}}</option>
                                                            @empty
                                                            @endforelse --}}
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-xxl-6 col-md-3 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">Taluka/Mandal
                                                            <span class="required">*</span></label>
                                                        <select class="form-select block_tehsil"
                                                            name="ref_block_tehsil_id[]" required>
                                                            <option value="">-Select Taluka/Mandal-</option>
                                                            {{-- @forelse($regions as $region)
                                                        <option value="{{$region->id}}">{{$region->block_tehsil_name}}</option>
                                                        @empty
                                                    @endforelse --}}
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-xxl-6 col-md-3 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">Village
                                                            <span class="required">*</span></label>
                                                        <select class="form-select village" name="ref_village_id[]"
                                                            required>
                                                            <option value="">-Select Village-</option>
                                                            {{-- @forelse($villages as $village)
                                                            <option value="{{$village->id}}" >{{$village->village_name}}</option>
                                                        @empty
                                                        @endforelse                               --}}
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-xxl-6 col-md-3 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">Qualification
                                                            <span class="required">*</span></label>
                                                        <select class="form-select" id="qualification"
                                                            name="qualification">
                                                            <option value="10th">10th Grade</option>
                                                            <option value="12th">12th Grade</option>
                                                            <option value="graduate">Graduate</option>
                                                            <option value="postgraduate">Postgraduate</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-xxl-6 col-md-1 gy-3">
                                                    <div class="form-group change">

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    @endforelse
                                    <div class="mt-2 text-sm-end">
                                        <div class="form-group change">
                                            <label for="">&nbsp;</label><br />
                                            <i data-type="wm" class="mdi mdi-plus btn btn-soft-success add-more"
                                                data-toggle="tooltip" title="Add More"></i>
                                            <!-- <a class="btn btn-success add-more"><i class="ri-add-line"></i></a> -->
                                        </div>
                                    </div>
                                    <!--address sec end-->

                                    <div class="row">
                                        <div class="col-lg-12 gy-4">
                                            <div class="hstack gap-2">
                                                <button type="submit" class="btn btn-primary" id="submitbtn">
                                                    Submit
                                                </button>
                                                {{-- <a href="{{ route('superadmin.icsuser.step2', 2) }}"
                                                    class="btn btn-soft-success">
                                                    Next
                                                </a> --}}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>



@endsection
@push('script')
    <script src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
    <script>
        $(document).on('click', '#submitbtn', function() {
            if (checkValidation("inspSchedule")) {
                $('#inspSchedule').submit();
                return true;
            } else {
                return false;
            }
        });

        function startDateFunction(input) {
            var start_date = input.value;
            var end_date = $('input[name="schedule_period_to"]').val();

            var d1 = Date.parse(start_date);
            var d2 = Date.parse(end_date);
           
            // if (end_date.length > 0) {
            //     var d2 = Date.parse(end_date[0].value);
            // }
         
            if (d1 > d2) {
                Swal.fire('', 'Start date should not be greater than end date.', 'warning');
                $('input[name="schedule_period_from"]').val('');
                return false;
            }
        }
        function endDateFunction(input) {
            var end_date = input.value;
            var start_date = document.getElementsByClassName('fssai_license_validity_from');

            if (start_date.length > 0) {
                var d1 = Date.parse(start_date[0].value);
            }
            var d2 = Date.parse(end_date);
            if (d1 > d2) {
                Swal.fire('', 'End date should not be less than start date.', 'warning');
                $('input[name="schedule_period_to"]').val('');
                return false;
            }
        }

        $(document).ready(function() {
            $("body").on("click", ".add-more", function() {
                var html = $(".after-add-more").first().clone().find("input").val("").end().find("select")
                    .val("").end();
                $(html).find(".change").html(
                    "<label for=''>&nbsp;</label><br/><a class='mdi mdi-delete btn btn-soft-danger remove'></a>"
                    );
                $(".after-add-more").last().after(html);


                $('.state').on('change', function() {
                    var th = $(this);
                    var state_id = this.value;

                    $.ajax({
                        url: districtUrl,
                        type: "POST",
                        data: {
                            state_id: state_id,
                        },
                        dataType: 'json',
                        success: function(result) {
                            if (result) {
                                th.closest('.row').find('.district').html(result);
                            }
                        }
                    });
                });

                $('.district').on('change', function() {
                    var th = $(this);
                    var district_id = this.value;

                    $.ajax({
                        url: blockTehsilUrl,
                        type: "POST",
                        data: {
                            district_id: district_id,
                        },
                        dataType: 'json',
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function(result) {
                            if (result) {
                                th.closest('.row').find('.block_tehsil').html(result);
                            }
                        }
                    });
                });
                $('.block_tehsil').on('change', function() {
                    var th = $(this);
                    var block_tehsil_id = this.value;
                    $.ajax({
                        url: villageUrl,
                        type: "POST",
                        data: {
                            block_tehsil_id: block_tehsil_id,
                        },
                        dataType: 'json',
                        success: function(result) {
                            if (result) {
                                th.closest('.row').find('.village').html(result);
                            }
                        }
                    });
                });
            });

            $("body").on("click", ".remove", function() {
                $(this).parents(".after-add-more").remove();
            });
        });

        function confirmDelete_(id) {

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.value) {
                    $.ajax({
                        url: "{{ route('superadmin.icsuser.deleteSchedule') }}",
                        method: "POST",
                        dataType: 'json',
                        data: {
                            'id': id,
                        },
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function(result) {
                            $('#row' + id).remove();
                            Swal.fire(
                                'Deleted!',
                                'Record Deleted Successfully..',
                                'success'
                            );

                        }
                    });

                }
            })
        }
    </script>
@endpush

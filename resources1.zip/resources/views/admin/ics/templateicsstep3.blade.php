 
 <form method="post" id="frm{{ $i }}" action="" enctype="multipart/form-data">
                                @csrf
                                <input type="hidden" name="userid" value="{{ $userdetails->id }}">
                               
                                <input type="hidden" id="userinspectorId" name="user_inspector_id" value="{{ $inspectorID }}" />

                                <div class="live-preview">
                                    <div class="row after-add-more">
                                    <!-- <div class="sectitle gy-3">
                                            <label for="labelInput" class="form-label blue-ht">Farmer No. / {{$i+1}}</label>
                                        </div> -->
                                        <div id="error{{ $i }}"></div>
                                        <div class="sectitle gy-3">
                                            <label for="labelInput" class="form-label blue-ht">किसान का विवरण/Farmer Details</label>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 ">
                                            <label for="basiInput" class="form-label">भूमि स्वामित्व का प्रकार/Select Land Holding Type<span
                                                    class="required">*</span></label>
                                            <select class="form-select whType" name="land_holding_type[]" required>
                                                <option value="">-select-</option>
                                               
                                                    <option value="owned">Owned</option>
                                                    <option value="leased">Leased </option>
                                                    <option value="ancestor">
                                                        Ancestor
                                                    </option>
                                                        
                                                    
                                            </select>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 ">
                                            <div>
                                                <label class="form-label">आधार/Aadhaar No.<span
                                                        class="required">*</span></label>
                                                <input type="text" class="form-control numbersonly" maxlength="12" id="aadhar_number{{$i}}"
                                                    placeholder="Aadhaar No." name="aadhar_number[]"
                                                    value=""
                                                    required />
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3">
                                            <div>
                                                <label class="form-label">किसान का नाम/Name of Farmer<span
                                                        class="required">*</span></label>
                                                <input type="text" class="form-control" id="farmer_name{{$i}}"
                                                    placeholder="Name of Farmer" name="farmer_name[]"
                                                    value=""
                                                    required />
                                            </div>
                                        </div>

                                        <div class="col-xxl-2 col-md-2 ">
                                            <div>
                                                <label class="form-label">लिंग/Gender<span class="required">*</span></label>
                                                <select name="gender[]" id="gender{{$i}}" class="form-select" required>
                                                    <option value="">Select Gender</option>
                                                    <option value="M">
                                                        Male</option>
                                                    <option value="F">
                                                        Female</option>
                                                    <option value="O">
                                                        Other</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3 ">
                                            <div>
                                                <label class="form-label">पिता/पति/Father/Husband<span
                                                        class="required">*</span></label>
                                                <select name="father_flag[]" id="father_flag{{$i}}" class="form-select" required>

                                                    <option value="">Select</option>
                                                    <option value="F">
                                                        Father</option>
                                                    <option value="H">
                                                        Husband</option>
                                                </select>
                                            </div>
                                        </div>
                                       
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label class="form-label">पिता/पति का नाम/Father/Husband Name<span
                                                        class="required">*</span></label>
                                                <input type="text" id="father_name{{$i}}" name="father_name[]" class="form-control" placeholder="Father/Husband Name" value=""
                                                    required>
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div>
                                                <label for="labelInput" class="form-label">मोबाइल नंबर/Mobile No.<span
                                                        class="required">*</span></label>
                                                <input type="text" maxlength="10" class="form-control numbersonly"
                                                    id="mobile_no{{$i}}" onblur="phonenumber(this)"
                                                    placeholder="Mobile Number*" name="mobile_no[]"
                                                    value=""
                                                    required />
                                            </div>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3 ">
                                            <div>
                                                <label for="labelInput" class="form-label">ईमेल आईडी/Email Id</label>
                                                <input type="email" class="form-control" id="email{{$i}}"
                                                    placeholder="Email Id*" name="email[]" onblur="checkEmailValidity(this)"
                                                    value="" />
                                            </div>
                                        </div>

                                        <div class="sectitle gy-3">
                                            <label for="labelInput" class="form-label blue-ht">संपर्क विवरण/Communication Details
                                            </label>
                                        </div>
                                        <div class="col-xxl-3 col-md-3 gy-3">
                                            <div class="row">
                                                <div class="col-xx-12 col-md-12">
                                                    <label for="labelInput" class="form-label">पता/Address<span
                                                            class="required">*</span></label>
                                                    <textarea placeholder="Address of The Farmer" class="form-control customtextarea" id="address{{$i}}" name="address[]"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xxl-9 col-md-9  ">
                                            <div class="row  ">
                                                <div class="col-xxl-4 col-md-4 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">राज्य/State<span
                                                                class="required">*</span></label>
                                                        <select class="form-select state" id="state{{$i}}" name="state[]">
                                                            <option value="">Select State</option>
                                                            @forelse(CBstateAssign($cbstate->id) as $state)
                                                                <option value="{{ $state->ref_state_id }}">
                                                                    {{ $state->state_name }}</option>
                                                            @empty
                                                            @endforelse
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-xxl-4 col-md-4 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">जिला/District<span
                                                                class="required">*</span></label>
                                                        <select id="district{{$i}}" class="form-select district" name="district[]">
                                                            <option value="">Select District</option>
                                                          
                                                              
                                                        
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-xxl-4 col-md-4 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">तहसील/मंडल/Taluka/Mandal
                                                            <span class="required">*</span></label>
                                                        <select class="form-select block_tehsil" name="taluka[]" id="taluka{{$i}}">
                                                            <option value="">Select Taluka/Mandal</option>
                                                            
                                                               
                                                      
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-xxl-6 col-md-6 gy-3">
                                                    <div>
                                                        <label class="form-label">गांव/Village</label>
                                                        <select class="form-select village" name="village[]" id="village{{$i}}">
                                                            <option value="">Select Village</option>
                                                            
                                                             
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-xxl-6 col-md-6 gy-3">
                                                    <div>
                                                        <label for="labelInput" class="form-label">
                                                            पिन कोड/Pin Code<span
                                                                class="required">*</span></label>
                                                        <input type="text" maxlength="6"
                                                            class="form-control numbersonly" id="pincode{{$i}}"
                                                            placeholder="Pin Code" name="pincode[]"
                                                            value=""
                                                            maxlength="6" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xxl-12 col-md-12 gy-3">
                                            <div class="row">
                                                <div class="col-xx-12 col-md-12">
                                                    <label for="labelInput" class="form-label">खेत/फार्मों का पता/Land Address/ <span
                                                            class="required">*</span></label>
                                                    <textarea placeholder="Address of The Land" class="form-control customtextarea" name="land_address[]" id="land_address{{$i}}" required></textarea>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="sectitle gy-3">
                                            <label for="labelInput" class="form-label blue-ht">खेत/फार्मों का विवरण/Farm Details</label>
                                        </div>

                                        <div class="col-xxl-3 gy-3">
                                            <div class="row">
                                                <div class="col-xx-12 col-md-12">
                                                    <label for="labelInput" class="form-label">फार्मों की संख्या/No. of Farms<span
                                                            class="required">*</span></label>
                                                    <input type="number" class="form-control numbersonly" id="number_of_farm" name="number_of_farm[]"
                                                        value="" onblur="farmadd(this,'{{$i}}')">
                                                </div>
                                            </div>
                                        </div>




                                        <!-- खेत/फार्मों का विवरण/ Farm Details -->
                                        <div id="addnewrow{{ $i }}"></div>
                                   


                                         <div class="form-group change">
                                            <div class="btn btn-primary" id="submitbutton{{ $i }}"
                                                onclick="formsubmit({{ $i }})" style="float: right;">
                                                Save
                                            </div>
                                        </div>
                                

                                    </div>
                                </div>
                            </form>
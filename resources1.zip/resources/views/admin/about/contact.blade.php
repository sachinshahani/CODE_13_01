@extends('admin.layouts.app')

<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f9;
        color: #333;
        /* margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center; */
        height: 100vh;
    }
    .contact-container {
        background-color: #fff;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        max-width: 1454px;
        width: 100%;
        display: flex;
        gap: 20px;
        justify-content: space-between;
        flex-wrap: wrap;
    }
    .contact-card {
        flex: 1;
        padding: 15px;
        border: 1px solid #ddd;
        border-radius: 8px;
        min-width: 250px;
    }
    .contact-card h2 {
        font-size: 18px;
        color: #0077b6;
        margin: 0 0 10px;
    }
    .contact-card p {
        margin: 5px 0;
        font-size: 14px;
        color: #555;
    }
    .contact-card p span {
        font-weight: bold;
        color: #333;
    }
    .contact-card p a {
        color: #0077b6;
        text-decoration: none;
    }
    .contact-card p a:hover {
        text-decoration: underline;
    }
</style>
@section('content')
    <div class="row">

        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Organic Division</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        {{-- <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li> --}}
                        <li class="breadcrumb-item active">Organic Division</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <div class="card-header">
        <!-- <h5 class="card-title mb-0" style="text-align: center;">
            Head of Dept.
        </h5> -->
    
        <div class="row justify-content-end mb-2">
            {{-- <div class="col-md-3 text-right">
                <select class="form-select" name="operator_status" id="search" data-label-msg="Status" required>
                    <option value="0">Select status</option>
                    <option value="0">All</option>
                    <option value="1">Suspended</option>
                    <option value="2">Terminated</option>
                    <option value="3">Withdrawal By CB</option>
                    <option value="4">Withdrawal By Operator</option>
                    <option value="5">De Registered</option>
                </select>
            </div> --}}
         
        </div>

    </div>

    <div class="contact-container">
        
        <div class="contact-card">
            
            <h2>Dr. Saswati Bose, General Manager</h2>
            <p><span>Email:</span> <a href="mailto:saswatibose@apeda.gov.in">saswatibose@apeda.gov.in</a></p>
            <p><span>Phone:</span> +91-011-20867004</p>
        </div>
        <div class="contact-card">
            <h2>Ms. Sunita Rai, Deputy General Manager</h2>
            <p><span>Email:</span> <a href="mailto:sunita@apeda.gov.in">sunita@apeda.gov.in</a></p>
            <p><span>Phone:</span> +91-011-41486019</p>
        </div>
    </div>

    
@endsection

@extends('admin.layouts.app')
@section('content')
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Announcement / Notification</h4>
            </div>
        </div>
    </div>
    <div class="flex-shrink-0">
        @if (session('error'))
            <div class="alert alert-danger">
                {{ session('error') }}
            </div>
        @endif
        @if (session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif
        @if ($errors)
            @foreach ($errors->all() as $error)
                <div class="alert alert-danger">{{ $error }}</div>
            @endforeach
        @endif
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">
                <div class="card-header">
                    <h4 class="h5 mb-0 text-danger">For Publishing the Advisory / Notification for the Operators by the
                        Certification Body</h4>
                </div>
                <form action="{{ route('superadmin.Announcementstore') }}" class="commonform1" method="POST"
                    enctype="multipart/form-data" id="commonform1" autocomplete="off">
                    @csrf
                    <div class="card-body">
                        <div class="row">
                            <!-- Select Operator Type -->
                            <div class="col-md-4 mb-2">
                                <label for="title">Select Operator Type:<span class="required">*</span></label>
                                <select name="ref_operator_type_id" id="ref_operator_type_id" class="form-control">
                                    @forelse($operators as $operator)
                                        <option value="{{ $operator->id }}" @selected(old('ref_operator_type_id') == $operator->id)>
                                            {{ $operator->operator_type }}
                                        </option>
                                    @empty
                                        <option>No operators available</option>
                                    @endforelse
                                </select>
                            </div>

                            <!-- Type -->
                            <div class="col-md-4 mb-2">
                                <label for="type">Type:<span class="required">*</span></label>
                                <select id="type" name="type" class="form-control">
                                    <option value="Advisory">Advisory</option>
                                    <option value="notification">Notification</option>
                                </select>
                            </div>
                            <div class="col-md-4 mb-2"></div>
                            <div class="col-md-4 mb-2">
                                <label for="title">Title:<span class="required">*</span></label>
                                <input type="text" id="title" name="title" class="form-control">
                            </div>
                            <div class="col-md-4 mb-2">
                                <label for="date">Published Date:<span class="required">*</span></label>
                                <input type="date" id="published_date" name="published_date" class="form-control">
                            </div>
                            <div class="col-md-4 mb-2">
                                <label for="link">Related Link:</label>
                                <input type="url" id="related_link" name="related_link" class="form-control"
                                    placeholder="https://example.com">
                            </div>
                            <div class="col-md-6 mb-2">
                                <label for="content">Content:<span class="required">*</span></label>
                                <textarea id="content" name="content" class="form-control" rows="3"></textarea>
                            </div>
                            <div class="col-md-6 mb-2 mt-3">
                                <p class="mb-1 text-dark">Upload Document:<span class="required">*</span></p>
                                <div class="input-group mb-1">
                                    <input type="file" class="form-control upload_document" id="attachment"
                                        name="attachment">
                                </div>
                                <small>(Upload only PDF up to 1MB*)</small>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary ">Publish</button>
                    </div>
                </form>
            </div>
            <div class="card">
                <div class="card-header">
                    <h3 class="h5 mb-0">Existing Announcements</h3>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered dataTable">
                            <thead>
                                <tr>
                                    <th>SNo.</th>
                                    <th>Operator Type</th>
                                    <th>Title</th>
                                    <th>Content</th>
                                    <th>Published Date</th>
                                    <th>Related Link</th>
                                    <th>Attachment</th>

                                </tr>
                            </thead>
                            <tbody>
                                @forelse($announcements as $announcement)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ getOperatorTypeById($announcement->ref_operator_type_id ?? 'N/A') }}</td>
                                        <td>{{ $announcement->title }}</td>
                                        <td>{{ Str::limit($announcement->content, 50) }}</td> <!-- Limit content length -->
                                        <td>{{ date('d-m-Y', strtotime($announcement->published_date)) }}</td>
                                        <td>
                                            @if ($announcement->related_link)
                                                <a href="{{ $announcement->related_link }}" target="_blank">View Link</a>
                                            @else
                                                N/A
                                            @endif
                                        </td>
                                        <td>
                                            @if ($announcement->attachment)
                                                <a href="{{ asset('public/attachment/attachment/' . $announcement->attachment) }}"
                                                    target="_blank">Download</a>
                                            @else
                                                N/A
                                            @endif
                                        </td>

                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="8" class="text-center">No announcements found.</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>


@endsection

@push('script')
    <script>
        $('.upload_document').on('change', function() {
            var $this = $(this);
            var file = $this[0].files[0];
            var fileType = file.type;
            var fileSize = file.size;
            var allowedTypes = ['application/pdf'];
            // alert(allowedTypes);

            // Check for file type
            if (!allowedTypes.includes(fileType)) {
                Swal.fire({
                    icon: 'error',
                    title: 'Invalid File Extension',
                    text: 'Please upload PDF only.',
                });
                $this.val("");
                return false;
            }

            // Check for file size
            if (fileSize > 1000000) { // 2 MB in bytes
                Swal.fire({
                    icon: 'error',
                    title: 'File Size Too Large',
                    text: 'Please upload files of size 1 MB or less only.',
                });
                $this.val("");
                return false;
            }
        });
    </script>
@endpush

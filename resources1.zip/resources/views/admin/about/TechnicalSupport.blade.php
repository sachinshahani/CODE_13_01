@extends('admin.layouts.app')

<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f9;
        color: #333;
        /* margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center; */
        height: 100vh;
    }
    .contact-container {
        background-color: #fff;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        max-width: 600px;
        width: 100%;
        display: flex;
        gap: 20px;
        justify-content: space-between;
        flex-wrap: wrap;
    }
    .contact-card {
        flex: 1;
        padding: 15px;
        border: 1px solid #ddd;
        border-radius: 8px;
        min-width: 250px;
    }
    .contact-card h2 {
        font-size: 18px;
        color: #0077b6;
        margin: 0 0 10px;
    }
    .contact-card p {
        margin: 5px 0;
        font-size: 14px;
        color: #555;
    }
    .contact-card p span {
        font-weight: bold;
        color: #333;
    }
    .contact-card p a {
        color: #0077b6;
        text-decoration: none;
    }
    .contact-card p a:hover {
        text-decoration: underline;
    }
</style>
@section('content')
    <div class="row">

        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Technical Support</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        {{-- <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li> --}}
                        <li class="breadcrumb-item active">Technical Support</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    

    <div class="contact-container">

        <div class="contact-card">

           
            <p><span>Email:</span> <a href="mailto:headq@apeda.gov.in">headq@apeda.gov.in</a></p>
            <p><span>Phone:</span>  91-11-41486013, 20867008, 20863919, 20867007</p>
            <p><span>Extn:</span>  445/ 423</p>
        </div>
        
    </div>


@endsection

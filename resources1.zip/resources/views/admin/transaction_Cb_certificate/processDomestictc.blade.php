@extends('admin.layouts.app')
@section('content')
<style>
    .pdf_maindiv {
        border: 1px solid #cccccc;
        width: 100%;
        float: left;
        padding: 3%;
    }

    th {
        border: 1px solid black;
        background-color: 1px solid #3941ab;
    }

</style>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                @if(isset($formData) && $formData !== null)
                    <h4 class="mb-sm-0">TRANSACTION CERTIFICATE</h4>
                    @else
                    <h4 class="mb-sm-0">CREATION OF TRANSACTION CERTIFICATE -  TRANSACTION CERTIFICATION</h4>
                    
                @endif    
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">TRANSACTION CERTIFICATION</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->
    <div class="row"> 
        @if(isset($formData) && $formData !== null)
        <div class="col-lg-12">
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">
                        <div class="row seperatesec  white-inner">
                            <!-- end card header -->
                            <div class="table-responsive text-center">
                              <a href="{{route('superadmin.processDemoesticTc', $formData)}}"  class="btn btn-soft-primary">Click here to preview certificate</a>
                            </div>
                        </div>
                    </div>
                    <form id="generateCbTc">
                        @csrf
                        <div style="text-align: center;">
                            <span id="successmsg" class="badge badge-soft-success"></span><br>
                            <input type="hidden" name="cbGenerateTc" id="cbGenerateTc" value="{{$formData}}">
                            <a href="{{route('superadmin.processDemoesticTc', $formData)}}" class="btn btn-primary mt-2">Edit</a>
                            <a href="#" class="btn btn-primary mt-2" id="submitGenerateTC">Submit & Generate TC</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        @else
        <div class="col-lg-12">
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                            <div class="live-preview">
                                <div class="flex-shrink-0">
                                    @if (session('error'))
                                    <div class="alert alert-danger">
                                        {{ session('error') }}
                                    </div>
                                    @endif
                                    @if (session('success'))
                                    <div class="alert alert-success">
                                        {{ session('success') }}
                                    </div>
                                    @endif
                                    @if($errors)
                                    @foreach ($errors->all() as $error)
                                    <div class="alert alert-danger">{{ $error }}</div>
                                    @endforeach
                                    @endif
                                </div>
                                <div class="row white-inner">
                                    <form method="post" action="{{ route('superadmin.saveDataCbGenerateTc')}}" >
                                        @csrf
                                        <div class="col-xxl-12 col-md-12 ">
                                            <label for="labelInput" class="form-label blue-ht">Seller Information</label>
                                        </div>
                                        <input type="hidden" name="formData" value="formData">
                                        <div class="col-xxl-12 col-md-9 ms-3">
                                            <div class="row  ">
                                            <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                    <tr>
                                                        <td class="pdf_txt1">Scope Certificate Number :</td>
                                                        <td class="pdf_box"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="pdf_txt1">Name of Seller  :</td>
                                                        <td class="pdf_box"></td>
                                                        <td class="pdf_txt1">Address :</td>
                                                        <td class="pdf_box"></td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div><br>

                                        <div class="col-xxl-12 col-md-12 ">
                                            <label for="labelInput" class="form-label blue-ht">Buyer Detail(s)</label>
                                        </div>
                                        <div class="col-xxl-12 col-md-9 ms-3">
                                            <div class="row  ">
                                            <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                <tr>
                                                    <td class="pdf_txt1">Buyer Scope Cert No. :</td>
                                                    <td class="pdf_box">ORG/SC?65214/1655</td>
                                                    <td class="pdf_txt1">Address :</td>
                                                    <td class="pdf_box">PAN India</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Buyer Name :</td>
                                                    <td class="pdf_box">Trader demo</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Counrty of Export :</td>
                                                    <td class="pdf_box">India</td>
                                                </table>
                                            </div>
                                        </div><br>

                                        <div class="col-xxl-12 col-md-12 ">
                                            <label for="labelInput" class="form-label blue-ht">Invoice Detail(s)</label>
                                        </div>
                                        <div class="col-xxl-12 col-md-9 ms-3">
                                            <div class="row  ">
                                            <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                <tr>
                                                    <td class="pdf_txt1">Order Conatct No. :</td>
                                                    <td class="pdf_box"><input type="text" value=""></td>
                                                    <td class="pdf_txt1">Invoice Date of Dispatch/origin :</td>
                                                    <td class="pdf_box">Apr 28 2024, Apr 28 2024</td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Invoice Number. :</td>
                                                    <td class="pdf_box">51651,15161</td>

                                                    <td class="pdf_txt1">Country of dispatch/Origin :</td>
                                                    <td class="pdf_box"><input type="text" value="Kolkata"></td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Invoice value (in Rs.):</td>
                                                    <td class="pdf_box">5655444</td>

                                                    <td class="pdf_txt1">Place of Destination no. :</td>
                                                    <td class="pdf_box"><input type="text" value="New Delhi"></td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Lot no. value (in Rs.):</td>
                                                    <td class="pdf_box"><input type="text" value="12121"></td>
                                                    <td class="pdf_txt1">Reference no. :</td>
                                                    <td class="pdf_box"><input type="text" value="2355569"></td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Marks And No. :</td>
                                                    <td class="pdf_box"><input type="text" value="12121"></td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Total Quantity (in MT) :</td>
                                                    <td class="pdf_box"><input type="text" value="12121"></td>
                                                </tr>
                                                </table>
                                            </div>
                                        </div><br>

                                        <div class="col-xxl-12 col-md-12 ">
                                            <label for="labelInput" class="form-label blue-ht">Transport Detail(s)</label>
                                        </div>
                                        <div class="col-xxl-12 col-md-9 ms-3">
                                            <div class="row  ">
                                            <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                <tr>
                                                    <td class="pdf_txt1">Mode of transport :</td>
                                                    <td class="pdf_box"></td>
                                                    <td class="pdf_txt1">Transaport Documents No. :</td>
                                                    <td class="pdf_box"></td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Transport Date :</td>
                                                    <td class="pdf_box"></td>
                                                    <td class="pdf_txt1">Container/Vehicle No. :</td>
                                                    <td class="pdf_box"></td>
                                                </tr>
                                                </table>
                                            </div>
                                        </div><br>
                                        <div class="col-xxl-12 col-md-12 ">
                                            <label for="labelInput" class="form-label blue-ht">Product Detail(s)</label>
                                        </div>
                                        <div class="col-xxl-12 col-md-9 ms-3">
                                            <div class="row  ">
                                            <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                <tr>
                                                    <td class="pdf_txt1">Product :</td>
                                                    <td class="pdf_box"></td>
                                                    <td class="pdf_txt1">Qauntity :</td>
                                                    <td class="pdf_box"></td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1">Status :</td>
                                                    <td class="pdf_box"></td>
                                                    <td class="pdf_txt1">Comppliance :</td>
                                                    <td class="pdf_box">NOP</td>
                                                </tr>
                                                </table>
                                            </div>
                                        </div><br>

                                        <div class="col-xxl-12 col-md-12 ">
                                            <label for="labelInput" class="form-label blue-ht">Authorized Sigratory</label>
                                        </div>
                                        <div class="col-xxl-12 col-md-9 ms-3">
                                            <div class="row  ">
                                            <table style="padding: 10px; border: 0px;" class="table_pdf">
                                                <tr>
                                                    <td class="pdf_txt1">Certificat With Authorized Signatory :</td>
                                                    <td class="pdf_box"><select name="" id="">
                                                        <option value="">Athorized Person Name</option>
                                                        <option value="">Vikash Chaudhary</option>
                                                        <option value="">Saurabh</option>
                                                        <option value="">Jitendra</option>
                                                    </select></td>
                                                </tr>
                                                <tr>
                                                    <td class="pdf_txt1"></td>
                                                    <td class="pdf_box"></td>
                                                </tr>
                                                </table>
                                            </div>
                                        </div><br>
                                    <div style="text-align: center;">
                                        <span id="successmsg" class="badge badge-soft-success"></span><br>
                                    <button type="submit" class="btn btn-primary mt-2"> Save & Preview</button>
                                        {{-- <a href="{{ route('superadmin.domestictc') }}" class="btn btn-primary mt-2">Back to Packing Details</a>
                                        <a href="{{ route('superadmin.domestictc') }}" class="btn btn-primary mt-2">Delete</a> --}}
                                    </div>
                                </form>
                            </div>
                        </div>
                </div>
            </div>
        </div>
        @endif
    @endsection
    @push('script')
        <div class="modal fade" id="addBatchModalgrid" tabindex="-1" aria-labelledby="addBatchModalgridLabel"
            aria-modal="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addBatchModalgridLabel">Edit Product</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body" id="batch_popup">

                    </div>
                </div>
            </div>
        </div>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Get all elements with the class 'toggle-row'
        const toggleRows = document.querySelectorAll('.toggle-row');

        // Add click event listener to each row
        toggleRows.forEach(row => {
            row.addEventListener('click', () => {
                // Toggle the 'hidden' class on the clicked row
                row.classList.toggle('hidden');
            });
        });
    });
</script>
<script>
$(document).ready(function() {
        $('#submitGenerateTC').click(function(e) {
            e.preventDefault(); // Prevent the default behavior of the anchor tag

            var formData = $('#generateCbTc').serialize();

            $.ajax({
                url: '{{ route('superadmin.saveDataCbGenerateTc') }}',
                type: 'POST',
                data: formData,
                dataType: 'json', // Specify the expected data type
                success: function(response) {
                    // Check the status in the response
                    if (response.status === 'success') {
                        // Display success message with SweetAlert
                        Swal.fire({
                            icon: 'success',
                            title: 'Success!',
                            text: response.message,
                        });
                    } else {
                        // Display error message with SweetAlert
                        Swal.fire({
                            icon: 'error',
                            title: 'Error!',
                            text: response.message,
                        });
                    }
                },
                error: function(xhr) {
                    // Handle errors
                    console.log(xhr.responseText);

                    // Display error message with SweetAlert
                    Swal.fire({
                        icon: 'error',
                        title: 'Error!',
                        text: 'An error occurred while processing your request.',
                    });
                }
            });
        });
    });
</script>
@endpush
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table border="0" cellspacing="0" cellpadding="0"
        style="width:100%;max-width: 800px;margin: 0 auto;border-collapse: collapse;">
        <tbody>
            <tr>
                <td colspan="2" style="text-align:right;margin: 0;padding-bottom:0px;">
                    <img src="{{ asset('public/backend/images/india-org.jpg') }}" alt="" style="max-width: 100px;">
                </td>
            </tr>
            <tr>
                <td colspan="2" style="text-align: center;">
                    <p style="font-family:'Arial';padding: 3px 0;margin: 0;font-weight: bold;font-size:18px">
                        TRANSACTION CERTIFICATE FOR ORGANIC PRODUCTS TRADED WITHIN INDIA
                        FOR EXPORT PURPOSES
                    </p>
                    <pre>
            </td>
            </tr>
            <tr>
                <td style="padding-left:15px;text-align: center;">
                    <img src="{{ asset('public/backend/images/bar.png') }}" alt="">
                </td>
            </tr>
        </tbody>
    </table>
    <table border="1" cellspacing="0" cellpadding="0"
        style="width:100%;max-width: 800px;margin: 0 auto;margin-top:10px;border-collapse: collapse;">
        <tbody>
            <tr>
                <td style="text-align:left;padding-top:10px;">
                    <p style="margin-bottom:5px;margin-top: 0;font-family:'Arial';font-weight:400;font-size: 12px;"><b>1.
                        Certification Body (Name & Address)</b> :</p>
                    <p style="margin-bottom:5px;margin-top: 0;font-family:'Arial';font-weight:400;font-size: 12px;">  </p>
                        {{$user->first_name ?? ''}} & {{$user->address ?? ''}}
                    <p style="margin: 0;font-family:'Arial';font-weight:400;font-size: 12px;"> </p>

                </td>
                <td style="text-align:left;padding-top:10px;">
                    <p style="font-family:'Arial';padding: 3px 0;margin: 0;font-weight:400;font-size: 12px;">
                        <b>2. Transaction Certificate No.</b> :</p>
                    <p
                        style="font-family:'Arial';padding: 3px 0;margin: 0;font-size: 12px;padding-right: 25px; color: red;">
                        {{$tcIssueList[0]->transaction_certificate_no}}</p>
                </td>
            </tr>
            <tr>
                <td colspan="2" style="padding-top:5px;">
                    <p style="margin-bottom:5px;margin-top: 0;font-family:'Arial';font-weight:400;font-size: 12px;"><b>3.
                        Seller (Name and Address of Individual/ICS)</b> :
                        {{ $data->exporter_seller_name ?? '' }} & {{ $data->exporter_seller_address ?? '' }}
                    </p>
                    <p style="margin-bottom:5px;margin-top: 0;font-family:'Arial';font-weight:400;font-size: 12px;">
                       </p>
                    <p style="margin-bottom:5px;margin-top: 0;font-family:'Arial';font-weight:400;font-size: 12px;">
                        </p>
                    <p style="margin: 0;font-family:'Arial';font-weight:400;font-size: 12px;"><span
                            style="font-weight:600">PAN :</span></p>
                </td>
            </tr>
            <tr>
                <td colspan="2" style="padding-top:5px;">
                    <p style="margin-bottom:5px;margin-top: 0;font-family:'Arial';font-weight:400;font-size: 12px;"> <b>4.
                       Buyer (Name and Address) :</b></p>

                        {{ $data->buyer_name ?? '' }} & {{ $data->buyer_address ?? '' }}
                    <p style="margin-bottom:5px;margin-top: 0;font-family:'Arial';font-weight:400;font-size: 12px;">
                        </p>
                    <p style="margin-bottom:5px;margin-top: 0;font-family:'Arial';font-weight:400;font-size: 12px;">
                       </p>
                    <p style="margin: 0;font-family:'Arial';font-weight:600;font-size: 12px;">PAN : {{$user[0]->pan ?? '' }}</p>
                </td>
            </tr>
            <tr>
                <td style="text-align:left;padding-top:5px;">
                    <p style="margin-bottom:5px;margin-top: 0;font-family:'Arial';font-weight:400;font-size: 12px;">5.
                        <b>Place of Dispatch :</b></p>
                    <p style="margin-bottom:5px;margin-top: 0;font-family:'Arial';font-weight:400;font-size: 12px;">
                        {{ $data->country_origin ?? '' }}
                        </p>
                </td>
                <td style="text-align:left;padding-top:5px;">
                    <p style="font-family:'Arial';padding: 3px 0;margin: 0;font-weight:400;font-size: 12px;">
                      <b>  6. Place of Destination :</b></p>
                    <p
                        style="font-family:'Arial';padding: 3px 0;margin: 0;font-weight:400;font-size: 12px;padding-right: 25px;">
                        {{ $data->place_of_destination ?? '' }}
                        </p>
                </td>
            </tr>
            <tr>
                <td colspan="2" style="padding-top:5px;">
                    <p
                        style="font-family:'Arial';padding: 3px 0;margin: 0;font-weight:400;font-size: 12px;margin-bottom: 0;">
                        7.</p>
                    <table border="1" cellspacing="0" cellpadding="0"
                        style="width:100%;margin: 0 auto;margin-top:0px;border-collapse: collapse;">
                        <thead>
                            <tr>
                                <th
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:600;font-size: 12px;padding:3px;line-height:18px">
                                    Product(s)

                                </th>
                                <th
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:600;font-size: 12px;padding:3px;line-height:18px">
                                    HS Code
                                </th>
                                <th
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:600;font-size: 12px;padding:3px;line-height:18px">
                                    HS CodeNPOP Organic
                                    Compliance
                                    (C1/C2/C3/Organic)
                                </th>
                                <th
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:600;font-size: 12px;padding:3px;line-height:18px">
                                    NOP Organic Compliance
                                    (C1/C2/C3/Organic)
                                </th>
                                <th
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:600;font-size: 12px;padding:3px;line-height:18px">
                                    Lot No.&
                                    Quantity(in MT)
                                </th>
                                <th
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:600;font-size: 12px;padding:3px;line-height:18px">
                                    Trade
                                    Name
                                </th>
                                <th
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:600;font-size: 12px;padding:3px;line-height:18px">
                                    Packing Details
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:400;font-size: 12px;padding:3px;line-height:18px">
                                    {{ $ref_product_hs_code->product_name ?? '' }}
                                </td>
                                <td
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:400;font-size: 12px;padding:3px;line-height:18px">
                                {{-----    {{ $tcIssueList[0]->batch_no ?? '' }}--}}
                                {{ $ref_product_hs_code->hs_code ?? '' }}
                                </td>
                                <td
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:400;font-size: 12px;padding:3px;line-height:18px">
                                  {{----------  {{ $tcIssueList[0]->organic_status ?? '' }}-----}}
                                    {{getSingleTableRecordById('ref_organic_status_master', 'id', $tcIssueList[0]->organic_status)->organic_status}}
                                </td>
                                <td
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:400;font-size: 12px;padding:3px;line-height:18px">
                                   {{------------ {{ $tcIssueList[0]->organic_status ?? '' }}-------}}
                                    {{getSingleTableRecordById('ref_organic_status_master', 'id', $tcIssueList[0]->organic_status)->organic_status}}
                                </td>
                                <td
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:400;font-size: 12px;padding:3px;line-height:18px">
                                    {{ $data->lot_number ?? '' }}
                                </td>
                                <td
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:400;font-size: 12px;padding:3px;line-height:18px">
                                    {{ $tcIssueList[0]->trade_name_of_product ?? '' }}
                                </td>
                                <td
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:400;font-size: 12px;padding:3px;line-height:18px;width:30%;">
                                    <p style="margin: 0;padding-bottom: 5px;">{{$pack->pack_size ?? ''}} X 100 Nos. =
                                        <?php  if(isset($pack->pack_size)) { $into_total = $pack->pack_size * 100; }else{ $into_total = ''; }  ?>  {{$into_total}} Kg</p>
                                    {{-- <p style="margin: 0;padding-bottom: 5px;">100.000000Kg X 500 Nos. =
                                        50000.000000 </p>
                                    <p style="margin: 0;padding-bottom: 5px;">200.000000Kg X 150 Nos. =
                                        30000.000000 Kg</p> --}}
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr>
                <td colspan="2" style="padding-top:5px;">
                    <p
                        style="font-family:'Arial';padding: 3px 0;margin: 0;font-weight:400;font-size: 12px;margin-bottom: 0;">
                        8. Transaction Details</p>
                    <table border="1" cellspacing="0" cellpadding="0"
                        style="width:80%;margin: 0 auto;margin-top:15px;border-collapse: collapse;">
                        <tbody>
                            <tr>
                                <td
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:400;font-size: 12px;padding:3px;line-height:18px">
                                    <p style="margin:0;font-size:12px">a) Order/Contract No.</p>
                                    <p style="margin:0;font-size:12px;margin-top: 5px;">{{ $data->container_no ?? '' }}</p>
                                </td>
                            </tr>
                            <tr>
                                <td
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-weight:400;font-size: 12px;padding:3px;line-height:18px">
                                    <p style="margin:0;font-size:12px">b) Invoice No.& Date</p>
                                    <p style="margin:0;font-size:12px;margin-top: 5px;"> {{ $data->lot_number ?? '' }}

                                    <table border="1" cellspacing="0" cellpadding="0"
                                        style="width:80%;margin-top:15px;border-collapse: collapse;">
                                        <thead>
                                            <tr>
                                                <th
                                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-size: 12px;padding:3px;">
                                                    S. No.</th>
                                                <th
                                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-size: 12px;padding:3px;">
                                                    Invoice No.</th>

                                                <th
                                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-size: 12px;padding:3px;">
                                                    Invoice Date</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td
                                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-size: 12px;padding:3px;">
                                                    1</td>
                                                <td
                                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-size: 12px;padding:3px;">
                                                    {{ $data->invoice_no ?? '' }}
                                                <td
                                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-size: 12px;padding:3px;">
                                                    {{  date('d-m-Y h:i;s', strtotime($data->invoice_date ?? '')) }}
                                                   </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table border="1" cellspacing="0" cellpadding="0"
                        style="width:80%;margin: 0 auto;margin-top:15px;border-collapse: collapse;margin-bottom:5px;">
                        <thead>
                            <tr>
                                <th
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-size: 12px;padding:3px;">
                                    c) Mode of Transport</th>
                                <th
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-size: 12px;padding:3px;">
                                    e) Transport Document No.</th>
                                <th
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-size: 12px;padding:3px;">
                                    e)Vehicle No./Bull Cart/Air/others</th>
                                <th
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-size: 12px;padding:3px;">
                                    f) Date of Transport</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-size: 12px;padding:3px;">
                                    {{ $data->transport_mode ?? '' }}
                                   </td>
                                <td
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-size: 12px;padding:3px;">
                                    {{ $data->transport_doc_no ?? '' }}
                                    </td>
                                <td
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-size: 12px;padding:3px;">
                                    {{  date('d-m-Y h:i;s', strtotime($data->invoice_date ?? '' ))}}
                                   </td>
                                <td
                                    style="text-align:left;padding-top:10px !important;font-family:'Arial';font-size: 12px;padding:3px;">
                                    {{  date('d-m-Y h:i;s', strtotime($data->invoice_date ?? '')) }}
                                   </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr>
                <td colspan="2" style="padding-top:5px;font-family:'Arial'">
                    <p style="padding: 3px 0;margin: 0;font-size:12px;">9. Additional Declaration by the Certification
                        Body</p>
                    <p style="padding: 3px 0;margin: 0;font-size:12px;">This is to certify that :</p>
                    <ol style="list-style: lower-alpha;font-family:'Arial';margin:5px;font-size: 12px;">
                        <li style="padding: 3px 0;">This Transaction Certificate is issued after satisfying ourselves
                            with the required inspection under the checked programmes at S.No.7 above;</li>
                        <li style="padding: 3px 0;">On the date of issue of this Transaction Certificate, the
                            Accreditation of this Certification Body under NPOP is valid.</li>
                        <li style="padding: 3px 0;">The above information is correct to the best of our knowledge and
                            belief.</li>
                    </ol>
                    <p style="padding: 3px 0;margin: 0;font-size:12px;">Issued Date: </p>
                    <table cellspacing="0" cellpadding="0"
                        style="width:100%;margin: 0 auto;margin-top:0px;border-collapse: collapse;">
                        <tbody>
                            <tr>
                                <td style="font-family:'Arial';font-size: 12px;padding-top: 40px;">
                                    <p style="margin: 0;padding-bottom: 5px;">Name and Signature of the authorised person</p>
                                    {{-- <p style="margin: 0;padding-bottom: 5px;">Satish Agrawal</p> --}}
                                </td>
                                <td style="padding-top:40px;">
                                    <img src="{{ asset('public/backend/images/qr.png') }}" alt="" style="width:70px;">
                                </td>
                                <td style="padding-top: 40px;">
                                    <img src="{{ asset('public/backend/images/apeda-vec.svg') }}" alt="" style="width:70px;">
                                </td>
                                <td style="font-family:'Arial';font-size: 12px;padding-top: 40px;">
                                    Stamp of Certification Body
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
        </tbody>
    </table>
</body>

</html>

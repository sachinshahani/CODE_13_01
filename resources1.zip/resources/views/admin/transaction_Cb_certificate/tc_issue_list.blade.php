@extends('admin.layouts.app')

@section('content')
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">List of TC Issued</h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="{{ route('superadmin.dashboard') }}">Dashboard</a></li>
                        <li class="breadcrumb-item active">Transaction Certificate</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <div class="clearfix"></div>

    <div class="col-md-12 mt-2">
        @if (session('success'))
            <div class="alert alert-success" id="validate">
                {{ session('success') }}
            </div>
        @endif
        @if (session('importErrors'))
            <div class="alert alert-danger">
                <p>Following Errors Occured While Uploading the list, Please fix and upload again</p>
                <ul>
                    @foreach (session('importErrors') as $failure)
                        @foreach ($failure->errors() as $f)
                            <li>{{ $f . ' at row ' . $failure->row() }}</li>
                        @endforeach
                    @endforeach
                </ul>
            </div>
        @endif
    </div>

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0" style="float: left">
                        List of Transaction Certificate issued
                    </h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="tcIssueList" class="table datatable table-bordered table-striped align-middle"
                            style="width:100%">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>TC Application No</th>
                                    <th>Operator Type</th>
                                    <th>Transaction Certificate Number</th>
                                    <th>TC Date</th>
                                    <th>Action</th>
                                    <th>Certificate</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($tcIssueList as $tcIssueListData)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $tcIssueListData->tc_application_no }}</td>
                                        <td>{{ getOperatorTypeById($tcIssueListData->operator_type) }}</td>
                                        <td>{{ $tcIssueListData->transaction_certificate_no }}</td>
                                        <td>{{ date('d-m-Y', strtotime($tcIssueListData->tc_date)) }}</td>
                                        <td><a href="{{ route('superadmin.cb.TcViewApplication', ['id' => $tcIssueListData->id]) }}">View Application</a></td>
                                        {{-- <td>
                                        @if (!empty($tcIssueListData->file_path))<a download href="{{asset('public/tc')}}/{{$tcIssueListData->file_path ?? ''}}"><i class="mdi mdi-file-certificate text-info fs-24 align-middle me-1 ss-6" data-toggle="tooltip" title="Download Internal Stock"></i></a>@endif

                                        @if ($eMSignedModuleAlow['status'] == 'success' && $eMSignedModuleAlow['isAllowed'] == '1')
                                            $hostName = request()->getSchemeAndHttpHost();
                                            $checkSignedPDf = getDigitalSignedPdf(Auth::id(),basename($tcIssueListData->file_path)); 
                                            print_r($checkSignedPDf); die;
                                            @if ($checkSignedPDf['status'] == 'success') 
                                                $eMSignedModuleResult = [
                                                    'signedPath' => $checkSignedPDf['signedPath'],
                                                    'status' => 'success',
                                                ];
                                            @else
                                                $eMSignedModuleResult = [
                                                    'signedPath' => '', 
                                                    'status' => 'failed',
                                                ];
                                            @endif         
                                            
                                        @endif
                                        <div class="">
                                            @if ($eMSignedModuleResult['status'] == 'success')
                                                @php
                                                    $publicPath = str_replace('var/www/html/apeda/', '', $eMSignedModuleResult['signedPath']);
                                                @endphp
                                                <a class="btn btn-success btn-sm" download href="{{ $hostName . $publicPath }}">Download Signed PDF</a>
                                            @else
                                                <button type="button" class="btn btn-primary btn-sm" id="generateDigitalSign"
                                                    data-filename="{{ basename($tcIssueListData->file_path) }}"
                                                    data-path="/tc/"
                                                    data-filestored="public"
                                                    data-certificate="RC">
                                                    Digital Sign
                                                </button>
                                            @endif
                                        </div>
                                    </td> --}}
                                        <td>
                                            {{-- Download the file if file_path exists --}}
                                            @if (!empty($tcIssueListData->file_path))
                                                <a download href="{{ asset('public/tc/' . $tcIssueListData->file_path) }}">
                                                    <i class="mdi mdi-file-certificate text-info fs-24 align-middle me-1 ss-6"
                                                        data-toggle="tooltip" title="Download Internal Stock"></i>
                                                </a>
                                                {{-- Check eMSignedModuleAlow and Signed PDF conditions --}}
                                                @if ($eMSignedModuleAlow['status'] == 'success' && $eMSignedModuleAlow['isAllowed'] == '1')
                                                    @php
                                                        $hostName = request()->getSchemeAndHttpHost();
                                                        $checkSignedPDf = getDigitalSignedPdf(
                                                            Auth::id(),
                                                            basename($tcIssueListData->file_path),
                                                        );
                                                        $eMSignedModuleResult =
                                                            $checkSignedPDf['status'] == 'success'
                                                                ? [
                                                                    'signedPath' => $checkSignedPDf['signedPath'],
                                                                    'status' => 'success',
                                                                ]
                                                                : [
                                                                    'signedPath' => '',
                                                                    'status' => 'failed',
                                                                ];
                                                    @endphp

                                                    <div>
                                                        @if ($eMSignedModuleResult['status'] == 'success')
                                                            @php
                                                                $publicPath = str_replace(
                                                                    'var/www/html/apeda/',
                                                                    '',
                                                                    $eMSignedModuleResult['signedPath'],
                                                                );
                                                            @endphp
                                                            <a class="btn btn-success btn-sm" download
                                                                href="{{ $hostName . $publicPath }}">Signed
                                                                PDF</a>
                                                        @else
                                                            <button type="button" class="btn btn-primary btn-sm"
                                                                id="generateDigitalSign"
                                                                data-filename="{{ basename($tcIssueListData->file_path) }}"
                                                                data-path="/tc/" data-filestored="public"
                                                                data-certificate="TCC">
                                                                Digital Sign
                                                            </button>
                                                        @endif
                                                    </div>
                                                @endif
                                            @endif


                                        </td>

                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!--end col-->
    </div>
    <!--end row-->

@endsection
@push('script')
    <script>
        // Initialize DataTables on the table with the 'datatable' class
        $(document).ready(function() {
            $('.datatable').DataTable();
        });
    </script>
@endpush

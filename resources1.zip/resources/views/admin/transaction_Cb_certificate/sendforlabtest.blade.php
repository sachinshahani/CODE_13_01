@extends('admin.layouts.app')
@section('content')

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">TC/Lot Details</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">TC/Lot Details</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <div class="tab-content py-4 custom-tab-content">
            <div class="tab-pane fade show active" id="step1">
                <div class="card">
                    <div class="card-body">
                            <div class="live-preview">
                                <div class="row seperatesec white-inner">
                                    {{-- <div class="sectitle">
                                        <label for="labelInput" class="form-label blue-ht">TC/Lot Details</label>
                                    </div> --}}

                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped align-middle " width="50%"
                                            id="datatable_">
                                            <thead>
                                                <tr>
                                                    <th>TC Application No:</th>
                                                    <td>{{$tcno->tc_application_no ?? '' }}</td>
                                                    <th>Date Of Application:</th>
                                                    <td>{{ $tranEntry->updated_at ?? '' }}</td>
                                                </tr>
                                            </thead>
                                            <thead>
                                                <tr>
                                                    <th>Seller:</th>
                                                    <td>{{ getUserById($tranEntry->created_by)->first_name ?? '' }}</td>
                                                    <th>Buyer:</th>
                                                    <td>{{ $tranEntry->buyer_name }}</td>
                                                    <th>Operator Type:</th>
                                                    <td>{{getOperatorTypeById($tcno->operator_type)}}</td>

                                                   
                                                </tr>
                                            </thead>
                                            <thead>
                                                <tr>
                                                    <th>Country:</th>
                                                    <td>{{ $tranEntry->country_origin }}</td>

                                                </tr>
                                            </thead>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="row seperatesec  white-inner">
                                {{-- <div class="sectitle">
                                    <label for="labelInput" class="form-label  blue-ht">Product Details</label>
                                </div> --}}
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped align-middle dataTable no-footer"
                                        width="100%" id="datatable">
                                        <thead>
                                            <tr>
                                                <th>Product HSCODE</th>
                                                <th>Organic Status</th>
                                                <th>Quantity(in MT)</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        @forelse ($data as $val)
                                        <tr>
                                            <td>{{ getHscodeProductName($val->ref_product_id)}} ({{ getHscodeById($val->ref_product_id) }} )</td>
                                            <td>{{ getSingleTableRecordById('ref_organic_status_master', 'id', $val->organic_status)->organic_status }}</td>
                                            <td>{{ $val->qty_in_mt }}</td>
                                            <td><a href="{{ route('superadmin.SendforLabTestproducttestinformation',[$id])}}">Send For Test</a></td>

                                        </tr>
                                        @empty
                                        <tr>
                                            <td colspan="8">No records found..</td>
                                        </tr>
                                        @endforelse
                                           
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    @endsection
    @push('script')

    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $('#datatable').DataTable();
    </script>

    @endpush

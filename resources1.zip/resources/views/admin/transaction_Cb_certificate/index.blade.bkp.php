@extends('admin.layouts.app')

@section('content')
    <div class="clearfix"></div>

    <div class="col-md-12 mt-2">
        @if (session('success'))
            <div class="alert alert-success" id="validate">
                {{ session('success') }}
            </div>
        @endif

        @if (session('importErrors'))
            <div class="alert alert-danger">
                <p>Following Errors Occured While Uploading the list, Please fix and upload again</p>
                <ul>
                    @foreach (session('importErrors') as $failure)
                        @foreach ($failure->errors() as $f)
                            <li>{{ $f . ' at row ' . $failure->row() }}</li>
                        @endforeach
                    @endforeach
                </ul>
            </div>
        @endif
    </div>

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0" style="float: left">
                         Transaction Certificate List
                    </h5>

                </div>
                <div class="card-body table-responsive">
                    <table id="deptUser" class="table table-bordered table-striped align-middle" style="width:100%">
                        <thead>
                            <tr>
                                <th>S.No.</th>
                                <th>TC Application No</th>
                                <th>Date of Application</th>
                                {{-- <th>Seller</th>
                                <th>Buyer</th>
                                <th>Country</th>
                                <th>Status</th>
                                <th>TC Types</th> --}}
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                        </tbody>
                    </table>

                    
                </div>
            </div>
        </div>
        <!--end col-->
    </div>
    <!--end row-->

@endsection



@push('script')
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        var table = $('#deptUser').DataTable({
            //dom: 'l<"clear">Bfrtip',
            //dom:'Bfrtip',
            //dom:'Blfrtip',
            lengthMenu: [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
            ],
            processing: true,
            serverSide: true,
            // ajax: {
            //     url: '{{ route('superadmin.usermanagement.usercreatelist') }}',
            //     type: 'GET',
            //     data: function(d) {
            //         d._token = "{{ csrf_token() }}";
            //         d.status = $("#search").val();
            //     }


            columns: [{
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex',
                    orderable: true
                },
                {
                    data: 'tc_application_no',
                    name: 'tc_application_no',
                    orderable: true
                },
                {
                    data: 'tc_date',
                    name: 'tc_date',
                    orderable: true
                },

                {
                    data: 'action',
                    name: 'name',
                    orderable: false
                },
            ],
            // initComplete: function () {
            //     var btns = $('.dt-button');
            //     //btns.addClass('btn btn-success btn-success');
            //     btns.removeClass('dt-button');

            // },

        });



    </script>
@endpush
var table = $('#pendingTC').DataTable({
    dom: 'Bfrtip',
    lengthMenu: [
        [10, 25, 50, -1],
        [10, 25, 50, "All"]
    ],
    processing: true,
    serverSide: true,
    ajax: {
        url: '{{ route("superadmin.tcrequestCbcertificate") }}',
        type: 'GET',
        data: function(d) {
            d._token = "{{ csrf_token() }}";
            d.operator_status = $("#search").val(); // Send operator_status parameter
        }
    },
    columns: [
        { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: true },
        { data: 'tc_application_no', name: 'tc_application_no', orderable: true },
        { data: 'tc_date', name: 'tc_date', orderable: true },
        { data: 'seller_scn', name: 'seller_scn', orderable: true },
        { data: 'source_from', name: 'source_from', orderable: true },
        { data: 'country', name: 'country', orderable: true },
        { data: 'nop_status', name: 'nop_status', orderable: false },
        { data: 'tc_type', name: 'tc_type', orderable: false },
        { data: 'action', name: 'action', orderable: false },
    ],
    buttons: [
        'excelHtml5',
        {
            extend: 'csvHtml5',
            title: function() {
                return "REPORTS";
            },
            titleAttr: 'CSV REPORTS'
        },
        {
            extend: 'pdfHtml5',
            title: function() {
                return "PDF REPORTS";
            },
            orientation: 'landscape',
            pageSize: 'A4',
            titleAttr: 'PDF REPORTS'
        }
    ]
});
</script>
@endpush
        var table = $('#deptUser').DataTable({
            //dom: 'l<"clear">Bfrtip',
            //dom:'Bfrtip',
            //dom:'Blfrtip',
            lengthMenu: [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
            ],
            processing: true,
            serverSide: true,
            // ajax: {
            //     url: '{{ route('superadmin.usermanagement.usercreatelist') }}',
            //     type: 'GET',
            //     data: function(d) {
            //         d._token = "{{ csrf_token() }}";
            //         d.status = $("#search").val();
            //     }


            columns: [{
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex',
                    orderable: true
                },
                {
                    data: 'tc_application_no',
                    name: 'tc_application_no',
                    orderable: true
                },
                {
                    data: 'tc_date',
                    name: 'tc_date',
                    orderable: true
                },

                {
                    data: 'action',
                    name: 'name',
                    orderable: false
                },
            ],
            // initComplete: function () {
            //     var btns = $('.dt-button');
            //     //btns.addClass('btn btn-success btn-success');
            //     btns.removeClass('dt-button');

            // },

        });



    </script>
@endpush


@extends('admin.layouts.app')

@section('content')

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Creation of Provisional Transaction Certificate - PTC</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Creation of Provisional Transaction Certificate - PTC</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

{{-- <div class="row">
	<div class="col-lg-4">&nbsp;</div>

	<div class="col-lg-4"> <a href="">Click here to view certificate</a></div>

    <div class="col-lg-4">&nbsp;</div>
</div> --}}
<div class="row">
    <div class="col-lg-4">&nbsp;</div>
	<div class="col-lg-4 gy-4 text-center">
		<div class="gap-2 ">
            <a href="{{ route('superadmin.ptcrequestCbcertificateprocess',$id)}}" class="btn btn-primary" >Edit </a>
			<button type="button" class="btn btn-primary"  onclick="renewalFunction()">Submit and Generate PTC </button>
		</div>
	</div>
    <div class="col-lg-4">&nbsp;</div>
</div>


@endsection
@push('script')

<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
$("#registration").validate({
    rules: {

    },
    messages: {

    }

});

function renewalFunction() {
    Swal.fire({
        title: "Are you sure to Generate PTC?",
       // icon: "question",
        showCancelButton: true,
        confirmButtonColor: "#0ab39c",
        confirmButtonText: "Yes, proceed!",
        cancelButtonText: "No, cancel",
    }).then((result) => {
        if (result.value) {
            window.location = "{{ route('superadmin.ptcView' , $id) }}";
        } else {
            console.log('cancel');
            return false;
        }
    });
}
</script>

@endpush

@extends('admin.layouts.app')
@section('content')
    <style>
        /* Style for the container */
        .container {
            display: flex;
            align-items: center;
        }


        .label {
            flex: 1;
        }


        .checkboxes {
            flex: 1;
            display: flex;
            flex-direction: column;
        }


        .checkbox {
            margin-bottom: 10px;
        }
    </style>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Enter Product Test Information</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">Enter Product Test Information</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">
                        <div class="card-body">
                            <form action="{{ route('superadmin.producttestinformationStore') }}" method="post">
                                @csrf
                                <div class="live-preview">
                                    <div class="row seperatesec white-inner">
                                        <div class="sectitle">
                                            <label for="labelInput" class="form-label blue-ht">Product Information</label>
                                        </div>
                                        <input type="hidden" value="{{ $tranEntry->id }}" name="at_op_transaction_certificate_entry_id">
                                        <input type="hidden" value="{{ $data->ref_product_id }}" name="ref_product_id">
                                        <div class="table-responsive">
                                            <table class="table table-bordered table-striped align-middle " width="50%"
                                                id="datatable_">
                                                <thead>

                                                    <tr>
                                                        <th>Product Code:</th>
                                                        <td>{{ getHscodeById($data->ref_product_id) }} </td>
                                                        <th>Size of Composite Sample(in Kg):</th>
                                                        <td><input type="text" class="form-control numbersonly" id="exampleCheck1" required>
                                                        </td>
                                                    </tr>
                                                </thead>
                                            </table>
                                        </div>
                                    </div>
                                </div>

                                <div class="row seperatesec white-inner">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped align-middle" width="50%"
                                            id="datatable_">
                                            <thead>
                                                <tr>
                                                    <th style="vertical-align:top;" >
                                                        <div class="sectitle" >
                                                            <label for="labelInput" class="form-label blue-ht">Product Test
                                                                Type</label>
                                                        </div>
                                                        {{-- <input type="address" placeholder="Address" class="form-control customtextarea" > --}}
                                                    </th>
                                                    <th>
                                                        <div class="sectitle">
                                                            <label for="labelInput" class="form-label blue-ht">Product Test
                                                                Category</label>
                                                        </div>
                                                        <div class="container">
                                                            <div class="label">
                                                                <label for="checkboxGroup">Category for Testing:</label>
                                                            </div>
                                                            <div class="checkboxes">
                                                                @foreach (getOrgTestCategory() as $cat)
                                                                    <div class="checkbox">
                                                                        <input type="checkbox" class="form-check-input"
                                                                            id="option1" name="category_for_testing[]"
                                                                            value="{{ $cat->id ?? '' }}" >
                                                                        <label
                                                                            for="option1">{{ $cat->category_name ?? '' }}</label>
                                                                    </div>
                                                                @endforeach
                                                                
                                                            </div>
                                                        </div>
                                                    </th>
                                                </tr>
                                            </thead>
                                        </table>
                                    </div>
                                </div>
                                <div class="row seperatesec white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label blue-ht">Details of Retention</label>
                                    </div>

                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped align-middle " width="50%"
                                            id="datatable_">
                                            <thead>
                                                <tr>
                                                    <th>Sample Retain with Exporter(in Kg):</th>
                                                    <td><input type="text" class="form-control numbersonly" name="sample_rtn_at_exp" id="exampleCheck1" required></td>
                                                    <th>Sample Retain with CB(in Kg):</th>
                                                    <td><input type="text" class="form-control numbersonly" name="sample_rtn_at_cb" id="exampleCheck1" required></td>
                                                    <th>Sample Retain with Lab(in Kg):</th>
                                                    <td><input type="text" class="form-control numbersonly" name="sample_rtn_at_lab" id="exampleCheck1" required></td>
                                                </tr>
                                            </thead>
                                        </table>
                                    </div>
                                </div>
                                <div class="row seperatesec white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label blue-ht">Period of Retention</label>
                                    </div>

                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped align-middle " width="50%"
                                            id="datatable_">
                                            <thead>
                                                <tr>
                                                    <th>Exporter:</th>
                                                    <td>
                                                        <select class="form-select" aria-label="Default select example" name="sample_rtn_last_dt_exp" id="exampleCheck1" required>
                                                            <option value="">-Select-</option>
                                                            <option value="3">3</option>
                                                            <option value="6">6</option>

                                                        </select>
                                                    </td>
                                                    <th>CB:</th>
                                                    <td>
                                                        <select class="form-select" aria-label="Default select example" name="sample_rtn_last_dt_cb" id="exampleCheck1" required>
                                                            <option value="">-Select-</option>
                                                            <option value="3">3</option>
                                                            <option value="6">6</option>

                                                        </select>
                                                    </td>
                                                   
                                                </tr>
                                                <tr>
                                                   
                                                    <th>Lab:</th>
                                                    <td>
                                                        <select class="form-select" aria-label="Default select example" name="sample_rtn_last_dt_lab" id="exampleCheck1" required>
                                                            <option value="">-Select-</option>
                                                            <option value="3">3</option>
                                                            <option value="6">6</option>

                                                        </select>
                                                    </td>
                                                </tr>
                                            </thead>
                                        </table>
                                    </div>
                                </div>
                                <div class="row seperatesec white-inner">
                                    
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped align-middle " width="50%"
                                            id="datatable_">
                                            <thead>
                                                <tr>
                                                    <th>Select Lab:</th>
                                                    <td>
                                                        <select class="form-select" aria-label="Default select example" name="ref_laboratory_master_id" id="exampleCheck1" required>
                                                            <option value="">-Select-</option>
                                                            @foreach (getLaboratoryMaster() as $lab)
                                                                <option value="{{ $lab->id }}">
                                                                    {{ $lab->lab_name }}</option>
                                                            @endforeach

                                                        </select>
                                                    </td>
                                                </tr>
                                            </thead>
                                        </table>
                                    </div>
                                </div>
                                <div class="row seperatesec white-inner">
                                    <div class="sectitle">
                                        <label for="labelInput" class="form-label  blue-ht">Test Parameters</label>
                                    </div>
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped align-middle dataTable no-footer test-param-tbl"
                                            width="100%" id="">
                                            <thead>
                                                <tr>
                                                    <th>Test Parameters</th>
                                                    <th>MRL Value</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td><select class="form-select test-param" aria-label="Default select example" name="ref_cb_test_parameter_master_id[]" id="exampleCheck1" required>
                                                            <option value="">-Select-</option>
                                                            @foreach (getTestParameter() as $par)
                                                                <option value="{{ $par->id }}" data-mrlval="{{ $par->mrl_value }}">
                                                                    {{ $par->test_parameter_name }}</option>
                                                            @endforeach
                                                           
                                                        </select></td>
                                                    <td><input type="text" class="form-control" value="0.0" name="mrl_value[]" readonly>
                                                    </td>
                                                    <td><a class="btn btn-primary add-button">Add</a></td>
                                                </tr>
                                            </tbody>
                                            {{-- <tbody id="add-colum-body">
                                            </tbody> --}}
                                        </table>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xxl-12 col-md-12 gy-4">
                                        <div class="hstack gap-2"
                                            style="display: flex; justify-content: center; align-items: center;">
                                            <button type="submit" id="add-button"
                                                class="btn btn-primary submit-button">Save</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('script')
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
     
        $(document).on("click", ".add-button", function() {

            $(".test-param-tbl tbody").append(
                '<tr><td><select class="form-select test-param" aria-label="Default select example" name="ref_cb_test_parameter_master_id[]"  id="exampleCheck1" required> <option value="">-Select-</option> @foreach (getTestParameter() as $par) <option value="{{ $par->id }}" data-mrlval="{{ $par->mrl_value }}"> {{ $par->test_parameter_name }}</option> @endforeach </select></td> <td><input type="text" class="form-control" value="0.0" name="mrl_value[]" readonly> </td> <td><a class="btn btn-danger remove-button">Remove</a></td></tr>'
            );

            
         
        });

        $(document).on("click", ".remove-button", function() {
            $(this).closest('tr').remove();
          
           
        });

        $(document).on("change", ".test-param", function(evt) {
            var mrval =$(this).find(':selected').data('mrlval');
            $(this).closest('tr').find("input[name='mrl_value[]']").val(mrval);
        });

        // function ShowModal(ele, id){
        //     // console.log('#ref_cb_test_parameter_master_id'+id);
          
        //     var dataId = $(ele).find(':selected').data('x')
        //     var valu = $('#ref_cb_test_parameter_master_id'+id).val();
        //     alert(dataId);

        // }
    </script>
@endpush

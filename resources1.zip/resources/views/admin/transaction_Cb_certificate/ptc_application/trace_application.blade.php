@extends('admin.layouts.app')
@section('content')

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Trace Provisional Transaction Certificate/Application</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Trace Provisional Transaction Certificate/Application</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <div class="tab-content py-4 custom-tab-content">
            <div class="tab-pane fade show active" id="step1">
                <div class="card">
                    <div class="card-body">
                            <div class="live-preview">
                                <div class="row seperatesec white-inner">
                                    {{-- <div class="sectitle">
                                        <label for="labelInput" class="form-label blue-ht">TC/Lot Details</label>
                                    </div> --}}

                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped align-middle " width="50%"
                                            id="datatable_">
                                            <thead>
                                                <tr>
                                                    <th>PTC Application No:</th>
                                                    <td>{{ $tranEntry->tc_application_no ?? '' }}</td>
                                                    <th>Scope Certification No. :</th>
                                                    <td>{{ $tranEntry->seller_at_op_certificate_standard_details_id ?? '' }}</td>
                                                   
                                                </tr>
                                            </thead>
                                            <thead>
                                                <tr>
                                                    <th>Seller:</th>
                                                    <td>{{ $tranEntry->exporter_seller_name ??'' }}</td>
                                                    <th>Buyer:</th>
                                                    <td>{{ $tranEntry->buyer_name ?? '' }}</td>
                                                </tr>
                                            </thead>
                                            <thead>
                                                <tr>
                                                    <th>Total Quantity(in MT):</th>
                                                    <td>{{ $tranEntry->total_qty ?? '' }}</td>
                                                    <th>Current CB:</th>
                                                    <td>{{ user_name(Auth::user()->id) }}</td>
                                                </tr>
                                            </thead>
                                            <thead>
                                                <tr>
                                                   
                                                    <th>Status:</th>
                                                    <td>{{ $tranEntry->applicant_status ?? 'Active' }}</td>
                                                </tr>
                                            </thead>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="row seperatesec  white-inner">
                                {{-- <div class="sectitle">
                                    <label for="labelInput" class="form-label  blue-ht">Product Details</label>
                                </div> --}}
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped align-middle dataTable no-footer"
                                        width="100%" id="datatable">
                                        <thead>
                                            <tr>
                                                <th>Product Name</th>
                                                <th>Organic Status</th>
                                                <th>BatchLot ID</th>
                                                <th>Quantity(in MT)</th>
                                              
                                            </tr>
                                        </thead>
                                        <tbody>
                                    
                                        <tr>
                                            <td>aaaa</td>
                                            <td>asas</td>
                                            <td>14525263</td>
                                            <td>12000</td>

                                        </tr>
                                      
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    @endsection
    @push('script')

    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $('#datatable').DataTable();
    </script>

    @endpush

@extends('admin.layouts.app')
@section('content')
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">PTC/Lot Details</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item active">PTC/Lot Details</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">
            <div class="tab-content py-4 custom-tab-content">
                <div class="tab-pane fade show active" id="step1">
                    <div class="card">
                        <div class="card-body">
                            <div class="flex-shrink-0">
                                @if (session('error'))
                                <div class="alert alert-danger">
                                    {{ session('error') }}
                                </div>
                                @endif
                                @if (session('success'))
                                <div class="alert alert-success">
                                    {{ session('success') }}
                                </div>
                                @endif
                                @if($errors)
                                @foreach ($errors->all() as $error)
                                <div class="alert alert-danger">{{ $error }}</div>
                                @endforeach
                                @endif
                            </div>
                            <div class="live-preview">
                                <div class="row seperatesec white-inner">
                                    {{-- <div class="sectitle">
                                        <label for="labelInput" class="form-label blue-ht">PTC/Lot Details</label>
                                    </div> --}}

                                    <div class="table-responsive">
                                        <form method="post" action="{{ route('superadmin.ptcCancelApplicationPost', $id) }}">
                                            @csrf
                                            <input type="hidden" name="at_op_transaction_vs_transaction_product_id"
                                                value="{{ $id }}">
                                            <input type="hidden" name="ptc_rejected_flag" value="1">
                                            <table class="table table-bordered table-striped align-middle " width="50%"
                                                id="datatable_">

                                                <tr>
                                                    <th>PTC Application No:</th>
                                                    <td>AAAAAAA</td>
                                                    <th>Date Of Application:</th>
                                                    <td>{{ $tranEntry->updated_at ?? '' }}</td>
                                                </tr>

                                                <tr>
                                                    <th>Seller:</th>
                                                    <td>{{ getUserById($tranEntry->created_by)->first_name ?? '' }}</td>
                                                    <th>Buyer:</th>
                                                    <td>{{ $tranEntry->buyer_name }}</td>
                                                </tr>

                                                <tr>

                                                    <td>Remarks:
                                                        <textarea name="cb_remarks" class="form-control customtextarea" required>{{ $tranEntry->cb_remarks??'' }}</textarea>
                                                    </td>

                                                </tr>

                                            </table>
                                            @if($tranEntry->ptc_rejected_flag!=1)
                                            <div class="col-lg-12 gy-4">
                                                <div class="hstack gap-2">

                                                    <button type="submit" class="btn btn-primary"
                                                        style="text-align: center;">
                                                        Cancel/Reject Application
                                                    </button>

                                                </div>
                                            </div>
                                            @endif
                                        </form>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('script')
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $('#datatable').DataTable();
    </script>
@endpush

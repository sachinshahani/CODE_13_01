@extends('admin.layouts.app')
@section('content')

<!-- start page title -->
{{-- @php
$data = App\Models\AtOpTransactionCertificateEntry::where('created_by',$id)->first();
@endphp --}}
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Creation of Transaction Certificate - TC</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    <li class="breadcrumb-item active">Creation of Transaction Certificate - TC</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <div class="tab-content py-4 custom-tab-content">
            <div class="tab-pane fade show active" id="step1">
                <div class="card">
                    <div class="card-body">
                    <form action="{{route('superadmin.storeTcrequestcertificatepreview')}}" method="post">
                        @csrf
                        <input type="hidden" name="row_id" value="{{$data->id??''}}">
                        <input type="hidden" name="tcid" value="{{$productdetails[0]->id ?? ''}}">
                        <div class="live-preview">
                            <div class="row seperatesec white-inner">
                                <div class="sectitle">
                                    <label for="labelInput" class="form-label blue-ht">Seller Information</label>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped align-middle " width="50%"
                                        id="datatable_">
                                        <thead>
                                           
                                            <tr>
                                                <th>Scope Certificate No:</th>
                                                <td>{{ $data->seller_at_op_certificate_standard_details_id ?? '' }}</td>
                                                <th>Address:</th>
                                                <td>{{ $data->exporter_seller_address ?? '' }}</td>
                                            </tr>

                                            <tr>
                                                <th>Name of Seller:</th>
                                                <td>{{ $data->exporter_seller_name ?? '' }}</td>
                                                <th></th>
                                                <td></td>
                                            </tr>
                                        </thead>

                                    </table>
                                </div>
                            </div>
                            <div class="row seperatesec white-inner">
                                <div class="sectitle">
                                    <label for="labelInput" class="form-label blue-ht">Buyer Information</label>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped align-middle " width="50%"
                                        id="datatable_">
                                        <thead>
                                            <tr>
                                                <th>Buyer Scope Certificate No:</th>
                                                <td>{{ $data->buyer_at_op_certificate_standard_details_id ?? '' }}</td>
                                                <th>Address:</th>
                                                <td>{{ $data->buyer_address ?? '' }}</td>
                                            </tr>

                                            <tr>
                                                <th>Name of Buyer:</th>
                                                <td>{{ $data->buyer_name ?? '' }}</td>
                                                <th>Country of Export:</th>
                                                <td>{{ $data->buyer_country_code ?? '' }}</td>


                                            </tr>
                                        </thead>


                                    </table>
                                </div>
                            </div>
                            <!--form3 tab end here-->
                            <div class="row seperatesec white-inner">
                                <div class="sectitle">
                                    <label for="labelInput" class="form-label blue-ht">Invoice Details</label>
                                </div>
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-6">
                                            <table style="padding: 10px; border: 0px;"
                                                class="table_pdf table_contact_person">
                                                <tr>
                                                    <input type="hidden" name="cre_id" value="{{ $data->created_by ?? '' }}">
                                                    <th>Order/contract No</th>
                                                    <td><input type="text" name="order_contract_no" value="{{ $data->order_contract_no ?? '' }}" class="form-control" id="exampleCheck1" required></td>
                                                </tr>

                                                <tr>
                                                    <th>Invoice No.</th>
                                                    <td><input type="text" name="invoice_no" value="{{ $data->invoice_no ?? '' }}" class="form-control" id="exampleCheck1" required></td>
                                                </tr>
                                                <tr>
                                                    <th>Invoice Value (in RS.)</th>
                                                    <td><input type="text" name="invoice_value" value="{{ $data->invoice_value ?? '' }}" class="form-control" id="exampleCheck1" required></td>
                                                </tr>
                                                <tr>
                                                    <th>Lot No.</th>
                                                    <td><input type="text" name="" class="form-control" id="exampleCheck1" value="{{ $data->lot_number ?? ''}}" required></td>
                                                </tr>
                                                <tr>
                                                    <th>Marks And No.</th>
                                                    <td><input type="text" class="form-control" id="exampleCheck1" value="{{ $data->marks_no ?? ''}}" required></td>
                                                </tr>
                                                <tr>
                                                    <th>Total Quantity(in MT).</th>
                                                    <td><input type="text" name="total_qty" class="form-control" id="exampleCheck1" value="{{ $data->total_qty ?? '' }}" required></td>
                                                </tr>
                                            </table>

                                        </div>
                                        <div class="col-6">

                                            <table style="padding: 10px; border: 1px;"
                                                class="table_pdf table_contact_person">
                                                <tr>
                                                    <th>Invoice Date.</th>
                                                    <td><input type="text" name="invoice_date" class="form-control" id="exampleCheck1" value="{{ date('d-m-Y', strtotime($data->invoice_date ?? '')) }}" required>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th>Country Of Dispatch/Origin.</th>
                                                    <td><input type="text" name="country_origin" value="{{ $data->country_origin ?? '' }}" class="form-control" id="exampleCheck1" required></td>
                                                </tr>
                                                <tr>
                                                    <th>Place of Destination.</th>
                                                    <td><input type="text" class="form-control" id="exampleCheck1" value="{{ $data->place_of_destination ?? '' }}" required></td>
                                                </tr>
                                                <tr>
                                                    <th>Reference No.</th>
                                                    <td><input type="text" class="form-control" id="exampleCheck1" value="{{ $data->reference_no ?? '' }}" required></td>
                                                </tr>
                                            </table>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--form4 tab end here-->
                            <div class="row seperatesec white-inner">
                                <div class="sectitle">
                                    <label for="labelInput" class="form-label blue-ht">Transport Details</label>
                                </div>

                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped align-middle " width="50%"
                                        id="datatable_">
                                        <thead>
                                            <tr>
                                                <th>Model Of Transport:</th>
                                                <td>{{ $data->transport_mode ?? '' }}</td>
                                                <th>Transport Date:</th>
                                                <td>{{date('d-m-Y', strtotime($data->transport_date ?? ''))}} </td>
                                            </tr>
                                        </thead>
                                        <thead>
                                            <tr>
                                                <th>Transport Document No:</th>
                                                <td>{{ $data->transport_doc_no ?? '' }}</td>
                                                <th>Conatiner/Vehicle No:</th>
                                                <td>{{ $data->container_no ?? '' }}</td>
                                            </tr>
                                        </thead>

                                    </table>
                                </div>
                            </div>

                            <div class="row seperatesec  white-inner">
                                <div class="sectitle">
                                    <label for="labelInput" class="form-label  blue-ht">Product Details</label>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped align-middle dataTable no-footer"
                                        width="100%" id="datatable">
                                        <thead>
                                            <tr>
                                                <th>Product.</th>
                                                <th>Status.</th>
                                                <th>Quantity(in MT).</th>
                                                {{-- <th>Compliance.</th> --}}
                                            </tr>
                                        </thead>
                                        @forelse ($productdetails as $key=>$value)
                                        
                                        <tbody>
                                            <tr>
                                                <td>{{getHscodeProductName($value->getTransProductSource[$key++]->ref_product_id ?? '')}}</td>
                                                {{-- <td>{{getRefOrganicStatuscodeByname($value->organic_status ?? '')}}</td> --}}
                                                <td>{{getSingleTableRecordById('ref_organic_status_master', 'id', $value->organic_status)->organic_status}}</td>
                                                <td>{{$value->total_qty ?? ''}}</td>
                                            </tr>
                                            @empty
                                            <tr>
                                                <td colspan="8">No records found..</td>
                                            </tr>
                                        </tbody>
                                        @endforelse
                                    </table>
                                </div>
                            </div>
                            <div class="row seperatesec  white-inner">
                                <div class="sectitle">
                                    <label for="labelInput" class="form-label  blue-ht">Authorized Signatory:</label>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-borderles" style="padding: 10px; border: 0px;">
                                        <tbody>
                                            <tr>
                                                <th>Certificate With Authorized Signatory:</th>
                                                <td>
                                                    <select name="signatory_code" class="form-select" required>
                                                        <option value="">Choose Authorized Signatory...</option>
                                                        @forelse($authsign as $vals)
                                                        <option value="{{$vals->id}}" >{{$vals->first_name}}</option>
                                                        @empty
                                                        <span>no</span>
                                                        @endforelse
                                                    </select>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-xxl-12 col-md-12 gy-4">
                                <div class="hstack gap-2" style="display: flex; justify-content: center; align-items: center;">
                                    <button type="submit" id="submitbtn" class="btn btn-primary submit-button">Save And Preview TC</button>
                                </div>
                            </div>
                        </div>
                    </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endsection
    @push('script')
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        // $('#datatable').DataTable();
    </script>
    @endpush

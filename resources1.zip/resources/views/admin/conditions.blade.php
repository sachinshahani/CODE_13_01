<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terms and Conditions - TraceNet System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
            padding: 20px;
            background: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        header {
            background: #4faf17;
            color: #fff;
            padding: 10px 0;
            text-align: center;
        }
        h1 {
            margin-top: 0;
        }
        h2 {
            border-bottom: 2px solid #333;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        ul {
            list-style: none;
            padding: 0;
        }
        li {
            margin-bottom: 10px;
        }
        .section {
            margin-bottom: 20px;
        }
        footer {
            text-align: center;
            padding: 10px 0;
            background: #4cbd18;
            color: #fff;
        }
        a {
            color: #007bff;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <header>
        <h1>TraceNet System - Terms and Conditions</h1>
    </header>
    <div class="container">
        <div class="section">
            <h2>1. Introduction</h2>
            <p>The TraceNet System is an online platform designed to facilitate the registration, verification, auditing, issuance of scope certificates, Transaction Certificates (TC), and other related processes for the export of organic products. These Terms and Conditions govern the use of the TraceNet System by Certification Bodies (CBs) and operators. By accessing and using the TraceNet System, you agree to comply with these Terms and Conditions, as well as the National Programme for Organic Production (NPOP) 2024 and any other applicable laws, regulations, or guidelines.</p>
        </div>
        <div class="section">
            <h2>2. Compliance with System Requirements and NPOP 2024</h2>
            <ul>
                <li><strong>2.1 Certification Bodies (CBs):</strong> Certification Bodies are required to adhere to the technical and operational standards as outlined by the TraceNet System. This includes complying with all relevant regulations, procedures, and guidelines under NPOP 2024. CBs must ensure that their personnel are adequately trained and proficient in the use of the TraceNet System to carry out their functions effectively.</li>
                <li><strong>2.2 Operators:</strong> Operators registered on the TraceNet System must ensure that their activities align with the system’s requirements and NPOP 2024 standards. They are responsible for the accuracy, integrity, and timely submission of all data within the system. Operators must immediately update and inform their CB about any incorrect, incomplete, or outdated information related to their organic product activities..</li>
            </ul>
        </div>
        <div class="section">
            <h2>3. Data Use and Verification</h2>
            <ul>
                <li><strong>3.1 Data Entry and Accuracy:</strong> Users (CBs and Operators) must ensure that all information entered into the TraceNet System is accurate, truthful, and complete. False, misleading, or fraudulent information may result in penalties, including suspension or termination of access to the TraceNet system and revocation of certifications.</li>
                <li><strong>3.2 Verification and Audits:</strong> The information entered into the TraceNet System may be subject to verification and audit by authorized personnel, including the relevant regulatory authorities or designated audit bodies. This may involve reviews of registration details, certification processes, data and Transaction Certificates (TC) issuance records to verify compliance with NPOP 2024 and system requirements.</li>
                <li><strong>3.3 Use of Data for Complaints and Misuse:</strong>Data entered into the system may be used to investigate complaints or allegations of misuse, including identifying irregularities or breaches of these Terms and Conditions. Operators and Certification Bodies are required to cooperate fully in such investigations.</li>
            </ul>
        </div>
        <div class="section">
            <h2>4. Issuance of Certificates</h2>
            <ul>
                <li><strong>4.1 Scope Certificates:</strong>Scope certificates will be issued based on the successful verification and audit of an operator's compliance with NPOP 2024 standards. The TraceNet System will monitor the generation of Scope Certificates and the Scope Certificate will be generated by the Certification Bodies through the TraceNet System after all necessary information has been accurately and completely entered by the operator and verified by the CB.</li>
                <li><strong>4.2 Transaction Certificates (TC):</strong> ITransaction Certificates (TCs) will be issued for each consignment of organic products intended for export or domestic trade. TCs will only be issued by the Certification Bodies through the TraceNet System after verifying that all necessary documentation and information, as per the system requirements, have been submitted correctly.</li>
            </ul>
        </div>
        <div class="section">
            <h2>5. IT System Terms and Conditions</h2>
            <ul>
                <li><strong>5.1 System Access and Security:</strong> Access to the TraceNet System is restricted to authorized users only. Users must maintain the confidentiality of their login credentials and are solely responsible for all the activities conducted under their account. Any unauthorized access, data breaches, or system compromise must be reported to the APEDA immediately..</li>
                <li><strong>5.2 Data Protection:</strong> The TraceNet System is designed to protect the confidentiality and integrity of all data entered by the users. Users are required to comply with all applicable data protection laws and regulations when entering, processing, or accessing any personal or organizational data within the system. This includes taking the written consent for personal data of operators, farmers, data retention policies, secure storage, and secure transmission practices.</li>
                <li><strong>5.3 System Availability and Maintenance:</strong> The TraceNet System may be temporarily unavailable due to scheduled maintenance, upgrades, or unforeseen technical issues. APEDA will make reasonable efforts to notify users in advance of planned downtime. APEDA is not liable for any loss of data, service interruptions, or other disruptions resulting from downtime.</li>
                <li><strong>5.4 Prohibited Activities:</strong>Users are prohibited from engaging in activities that could harm, disrupt, or otherwise compromise the functionality of the TraceNet System. This includes, but is not limited to, unauthorized access, data tampering, hacking, introducing malware, or any other action that would interfere with the normal operation of the system.</li>
                <li><strong>5.5 Modifications and Updates:</strong> The TraceNet System and its associated Terms and Conditions may be updated or modified at the discretion of the APEDA. Users will be notified of significant changes, and continued use of the system after any such updates will be construed as acceptance of the revised terms.</li>
            </ul>
        </div>
        <div class="section">
            <h2>6. Limitation of Liability</h2>
            <p>APEDA is not liable for any direct, indirect, incidental, or consequential damages arising from the use or inability to use the TraceNet System. This includes, but is not limited to, data accuracy issues, system downtime, loss of data, or unauthorized access. Users agree to indemnify the system provider from any claims arising from their use or misuse of the TraceNet System.</p>
        </div>
        <div class="section">
            <h2>7. Termination of Access</h2>
            <p>APEDA reserves the right to suspend or terminate access to the TraceNet System at any time, for any user who violates these Terms and Conditions or fails to comply with NPOP 2024 standards. Users may also be terminated if they fail to maintain accurate, up-to-date records, or if they engage in fraudulent activities.</p>
        </div>
        <div class="section">
            <h2>8. Governing Law</h2>
            <p>These Terms and Conditions are governed by and construed in accordance with the laws of the jurisdiction of Delhi, India. Any disputes arising from the use of the TraceNet System or these Terms and Conditions will be subject to the exclusive jurisdiction of the courts in Delhi, India.</p>
        </div>
        <div class="section">
            <h2>9. Additional Terms for Mobile Application Users</h2>
            <ul>
                <li><strong>9.1 Mobile App Access:</strong> Operators and Certification Bodies using the TraceNet mobile application must ensure that they comply with all the relevant guidelines and procedures applicable to the mobile platform. This includes using the app securely, ensuring data privacy, and updating the app when necessary</li>
                <li><strong>9.2 Mobile App Security:</strong>Users must take appropriate measures to secure their mobile devices, including but not limited to using strong passwords, encryption, and enabling device security features such as biometric authentication or two-factor authentication (2FA) where available APEDA will not be held responsible for any breaches caused by user negligence.</li>
                <li><strong>9.3 App Functionality and Compatibility:</strong> The TraceNet mobile application is designed to function on specified platforms (e.g., Android, iOS). APEDA makes no guarantees regarding the app's compatibility with all devices or operating systems. Users are advised to ensure that their devices meet the minimum technical specifications to access the app effectively.</li>
            </ul>
        </div>
        <div class="section">
            <h2>10. Force Majeure</h2>
            <p>APEDA shall not be liable for any failure or delay in performing its obligations under these Terms and Conditions if such failure or delay is caused by events beyond the reasonable control of APEDA. Such events may include but are not limited to natural disasters, acts of government, pandemic or technological failures.</p>
            <p>By using the TraceNet System, the certification body and Operators registered under NPOP acknowledge and agree to comply with all the terms set forth herein. Should you have any questions or require further clarification regarding these Terms and Conditions, please contact the APEDA or refer to the user support documentation.</p>
        </div>
    </div>
    <footer>
        <p>&copy; 2024 TraceNet System. All Rights Reserved.</p>
    </footer>
</body>

</html>

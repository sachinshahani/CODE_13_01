<?php


use Illuminate\Http\Request;
use App\Http\Controllers\API\AuthController;
use App\Http\Controllers\API\ProcessorController;
use App\Http\Controllers\API\TraderController;
use App\Http\Controllers\API\IndividualProController;
use App\Http\Controllers\API\MasterController;
use App\Http\Controllers\API\OtpController;
use App\Http\Controllers\API\ExternalInspection;
use App\Http\Controllers\API\PanVerificationController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/



Route::controller(AuthController::class)->group(function () {
    Route::post('register', 'register')->name('register');
    Route::post('/login', 'login')->name('login');
    Route::post('/ForgetPassword', 'ForgetPassword')->name('ForgetPassword');
    // Route::get('reset-password/{token}', 'showResetPasswordForm')->name('showResetPasswordForm');

    Route::post('/ResetPassword', 'ResetPassword')->name('ResetPassword');

    // Route::group(['middleware' => 'auth:api'], function(){
    //     Route::post('/order','listins')->name('inspectorlist');
    //    });

    Route::post('/farmerlist', 'farmerlist')->name('farmerlist');
    Route::get('/getState', 'getState')->name('getState');
    Route::get('/getDistrictByState/{state}', 'getDistrictByState')->name('getDistrictByState');
    Route::get('/getTalukByDistrict/{dis}', 'getTalukByDistrict')->name('getTalukByDistrict');
    Route::get('/getvillByTaluk/{tal}', 'getvillByTaluk')->name('getvillByTaluk');
    Route::get('/getScheduleLocByInsId/{id}', 'getScheduleLocByInsId')->name('getScheduleLocByInsId');

    //gaurav//
    Route::get('/getInspectionSchedule/{id}', 'getInspectionSchedule')->name('getInspectionSchedule');
    Route::get('/getFarmerSchedule/{id?}', 'getFarmerSchedule')->name('getFarmerSchedule');
    Route::get('/getFarmSchedule/{id?}', 'getFarmSchedule')->name('getFarmSchedule');
    Route::get('/getUserData', 'getUserData')->name('getUserData');


    Route::post('regFarmerList', 'regFarmerList')->name('regFarmerList');
    Route::post('/scheduleAccRej', 'scheduleAccRej')->name('scheduleAccRej');
    Route::get('/getBanks', 'getBanks')->name('getBanks');
    Route::post('/farmerDetails', 'farmerDetails')->name('farmerDetails');
    Route::put('/farmer/update/{farmer_id}', 'updateFarmerDetails');
    Route::post('/fileUploads', 'fileUploads')->name('fileUploads');
    Route::post('/multipleUploads', 'multipleUploads')->name('multipleUploads');

    Route::post('/inspDashboard', 'inspDashboard')->name('inspDashboard');
    Route::post('/getCheckPoints', 'getCheckPoints')->name('getCheckPoints');
    Route::post('/farmManagement', 'farmManagement')->name('farmManagement');
    Route::post('/inspFarmerList', 'inspFarmerList')->name('inspFarmerList');
    Route::post('/inspFarmerDetail', 'inspFarmerDetail')->name('inspFarmerDetail');
    Route::post('/inspFarmerPost', 'inspFarmerPost')->name('inspFarmerPost');
    Route::post('/farmDetail', 'farmDetail')->name('farmDetail');
    Route::post('/farmDetailUpdate', 'farmDetailUpdate')->name('farmDetailUpdate');
    Route::post('/plotDetailSave', 'plotDetailSave')->name('plotDetailSave');
    Route::post('/inspectionDetail', 'inspectionDetail')->name('inspectionDetail');
    Route::post('/nonConformitySave', 'nonConformitySave')->name('nonConformitySave');
    Route::post('/getNonConformity', 'getNonConformity')->name('getNonConformity');
    Route::post('/deleteNonConformity', 'deleteNonConformity')->name('deleteNonConformity');
    Route::post('/internalApprovalSave', 'internalApprovalSave')->name('internalApprovalSave');
    Route::post('/farmList', 'farmList')->name('farmList');
    Route::post('/confirmInspection', 'confirmInspection')->name('confirmInspection');
    Route::get('/getFarmerDetailById/{id}', 'getFarmerDetailById')->name('getFarmerDetailById');

    Route::post('/sendOtp', 'sendOtp')->name('sendOtp');

    // Route::post('/send-email','sendEmail')->name('sendEmail');

});

Route::controller(ExternalInspection::class)->prefix('external')->group(function () {
    Route::post('login', 'login')->name('login');
    Route::get('inspectionCompleteList', 'inspectionCompleteList')->name('inspectionCompleteList');
    Route::post('complete-inspection-detail', 'inspectionCompleteDetail')->name('inspectionCompleteDetail');
    Route::post('saveRemarks', 'saveRemarks');
    Route::post('getGeneratePdf', 'getGeneratePdf');
    Route::post('sampling-info', 'SamplingInfo');
    Route::get('Crop-Product-list', 'getCropProductData')->name('getCropProductData');
    Route::get('/getTrederProfileDetails/{operator_id}/{item_id}','getTrederProfileDetails')->name('getTrederProfileDetails');
    Route::get('/getProcessorProfileDetails/{operator_id}/{item_id}','getProcessorProfileDetails')->name('getProcessorProfileDetails');
    Route::get('/getWildHarvesterProfileDetails/{operator_id}/{item_id}','getWildHarvesterProfileDetails')->name('getWildHarvesterProfileDetails');
    Route::get('/getWGrowerGroupProfileDetails/{operator_id}/{item_id}','getWGrowerGroupProfileDetails')->name('getWGrowerGroupProfileDetails');
    Route::get('/GetIndivisualProducerProfileDetails/{operator_id}/{item_id}','GetIndivisualProducerProfileDetails')->name('GetIndivisualProducerProfileDetails');
    
	Route::post('/getCheckList','getCheckList')->name('getCheckList');
    Route::post('/saveCheckProcessRemarks','saveCheckProcessRemarks')->name('saveCheckProcessRemarks');
    Route::post('/saveCheckTraderRemarks','saveCheckTraderRemarks')->name('saveCheckTraderRemarks');
    Route::post('/saveCheckWildHarvestRemarks','saveCheckWildHarvestRemarks')->name('saveCheckWildHarvestRemarks');
    Route::post('/saveCheckIndividualFarmerRemarks','saveCheckIndividualFarmerRemarks')->name('saveCheckIndividualFarmerRemarks');
	Route::post('/saveCheckGrowerGroupRemarks','saveCheckGrowerGroupRemarks')->name('saveCheckGrowerGroupRemarks');
	
    Route::post('Upcominginspection', 'Upcominginspection')->name('Upcominginspection');
    Route::post('dueInspection', 'dueInspection')->name('dueInspection');
    Route::post('completedInspection', 'completedInspection')->name('completedInspection');
    Route::get('/DetailsProcessor/{item_id}','DetailsProcessor')->name('DetailsProcessor');
    Route::get('/DetailsTrader/{item_id}','DetailsTrader')->name('DetailsTrader');
    Route::get('/DetailsWildHarvester/{item_id}','DetailsWildHarvester')->name('DetailsWildHarvester');
    Route::get('/DetailsIndiProd/{item_id}','DetailsIndiProd')->name('DetailsIndiProd');

    Route::post('/searchApi','searchApi')->name('searchApi');
    Route::post('/rescheduleInspection',  'rescheduleInspection')->name('rescheduleInspection');
    Route::post('/acceptRejectSchedule',  'acceptRejectSchedule')->name('acceptRejectSchedule');
    Route::post('/ProcessorReport', 'ProcessorReport')->name('ProcessorReport');
    Route::post('/IndivisualproducerReport', 'IndivisualproducerReport')->name('IndivisualproducerReport');
    Route::post('/WildCHarvesterReport', 'WildCHarvesterReport')->name('WildCHarvesterReport');

});

Route::controller(ProcessorController::class)->prefix('processor')->group(function () {
    // Route::post('register', 'register')->name('pro.register');
    Route::post('login', 'login')->name('login');
    Route::post('/ResetPassword', 'ResetPassword')->name('ResetPassword');
    Route::get('/getState', 'getState')->name('processor.getState');
    Route::get('/getDistrictByState/{state}', 'getDistrictByState')->name('getDistrictByState');
    Route::get('/getTalukByDistrict/{dis}', 'getTalukByDistrict')->name('getTalukByDistrict');
    Route::get('/getvillByTaluk/{tal}', 'getvillByTaluk')->name('getvillByTaluk');
    Route::get('/getBanks', 'getBanks')->name('getBanks');
    Route::get('/getCategories', 'getCategories')->name('getCategories');
    Route::post('/getProduct', 'getProduct')->name('getProduct');
    Route::post('/saveBanks', 'saveBanks')->name('saveBanks');

    Route::post('/fileUploads', 'fileUploads')->name('fileUploads');
    Route::post('processorDash', 'processorDash')->name('processorDash');
    Route::post('processorDetailSave', 'processorDetailSave')->name('processorDetailSave');
    Route::post('unitDetailsave', 'unitDetailsave')->name('unitDetailsave');
    Route::post('listDocSave', 'listDocSave')->name('listDocSave');
});


Route::controller(TraderController::class)->prefix('trader')->group(function () {
    // Route::post('register', 'register')->name('pro.register');
    //  Route::post('login', 'login')->name('login');
    //  Route::post('/ResetPassword', 'ResetPassword')->name('ResetPassword');
    //  Route::get('/getState','getState')->name('getState');
    //  Route::get('/getDistrictByState/{state}','getDistrictByState')->name('getDistrictByState');
    //  Route::get('/getTalukByDistrict/{dis}','getTalukByDistrict')->name('getTalukByDistrict');
    //  Route::get('/getvillByTaluk/{tal}','getvillByTaluk')->name('getvillByTaluk');
    Route::get('/getBanks', 'getBanks')->name('getBanks');
    Route::post('/saveBanks', 'saveBanks')->name('saveBanks');

    Route::post('/fileUploads', 'fileUploads')->name('fileUploads');
    Route::post('/traderDash', 'traderDash')->name('traderDash');
    Route::post('/traderDetailSave', 'traderDetailSave')->name('traderDetailSave');
    Route::post('/traderUnitDetailsave', 'traderUnitDetailsave')->name('traderUnitDetailsave');
    Route::post('/listDocSave', 'listDocSave')->name('listDocSave');
});

Route::controller(IndividualProController::class)->prefix('individual')->group(function () {
    // Route::post('register', 'register')->name('pro.register');
    //  Route::post('login', 'login')->name('login');
    //  Route::post('/ResetPassword', 'ResetPassword')->name('ResetPassword');
    //  Route::get('/getState','getState')->name('getState');
    //  Route::get('/getDistrictByState/{state}','getDistrictByState')->name('getDistrictByState');
    //  Route::get('/getTalukByDistrict/{dis}','getTalukByDistrict')->name('getTalukByDistrict');
    //  Route::get('/getvillByTaluk/{tal}','getvillByTaluk')->name('getvillByTaluk');
    //Route::get('/getBanks','getBanks')->name('getBanks');
    Route::post('/saveBanks', 'saveBanks')->name('saveBanks');

    //Route::post('/fileUploads','fileUploads')->name('fileUploads');
    Route::post('/traderDash', 'traderDash')->name('traderDash');
    Route::post('/farmerDetailSave', 'farmerDetailSave')->name('farmerDetailSave');
    //Route::post('/traderUnitDetailsave','traderUnitDetailsave')->name('traderUnitDetailsave');
    Route::post('/listDocSave', 'listDocSave')->name('listDocSave');
});


Route::controller(MasterController::class)->group(function () {});

// Pan Verfication Api 
Route::controller(PanVerificationController::class)->group(function () {
    Route::post('/validate-pan-v1', 'validatePanApiV1')->name('validate-pan.validateV1');
});

Route::post('/send-otp', [OtpController::class, 'sendOtp']);




//  Route::group(['middleware' => 'auth:api'], function(){
//   Route::post('/order', [App\Http\Controllers\API\AuthController::class,'listins'])->name('api.inspectorlist');
//  });

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });

<?php

namespace App\Observers;

use App\Models\RefScheme;

class RefSchemeObserver
{
    /**
     * Handle the RefScheme "created" event.
     *
     * @param  \App\Models\RefScheme  $refScheme
     * @return void
     */
    public function created(RefScheme $refScheme)
    {
        $refScheme->scheme_id = 'SC-'.$refScheme->id.'/'.date('Y');
        $refScheme->save();
    }

    /**
     * Handle the RefScheme "updated" event.
     *
     * @param  \App\Models\RefScheme  $refScheme
     * @return void
     */
    public function updated(RefScheme $refScheme)
    {

    }

    /**
     * Handle the RefScheme "deleted" event.
     *
     * @param  \App\Models\RefScheme  $refScheme
     * @return void
     */
    public function deleted(RefScheme $refScheme)
    {
        //
    }

    /**
     * Handle the RefScheme "restored" event.
     *
     * @param  \App\Models\RefScheme  $refScheme
     * @return void
     */
    public function restored(RefScheme $refScheme)
    {
        //
    }

    /**
     * Handle the RefScheme "force deleted" event.
     *
     * @param  \App\Models\RefScheme  $refScheme
     * @return void
     */
    public function forceDeleted(RefScheme $refScheme)
    {
        //
    }
}

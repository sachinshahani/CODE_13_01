<?php

namespace App\Exports;

use App\Models\User;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\WithHeadings;

class DeptUserExport implements FromCollection, WithHeadings
{
    use Exportable;

    protected $users;

    public function __construct($users)
    {
        $this->users = $users;
    }

    public function collection()
    {
        return $this->users;
    }

    public function headings(): array
    {
        return [
            'S.No.',
            'Application No.',
            'Name Of Operator',
            'Reg No.',
            'Contact Person Email',
            'Contact Person Mobile',
            'Created On',
            'Status',
        ];
    }
}

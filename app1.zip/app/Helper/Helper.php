<?php
/* @This helper is used for Common functions*/

use App\Models\RefState;
use App\Models\RefDistrict;
use App\Models\RefVillage;
use App\Models\RefRegion;
use App\Models\Role;
use App\Models\RefBank;
use App\Models\UserInspector;
use App\Models\RefOperatorType;
use App\Models\AtFarmerLandGeoDetail;
use App\Models\AtFarmerProposedCorpDetail;
use App\Models\AtFarmerStandingCorpDetail;
use App\Models\AtFarmDetails;
use App\Models\AtFarmerRegDetail;
use App\Models\RefCheckPoints;
use App\Models\RefProduct;
use App\Models\RefCategory;
use App\Models\RefDesignation;
use App\Models\AtPurchaseDetails;
use App\Models\AtClosingStock;
use App\Models\User;
use App\Models\AtInputProductCategory;
use App\Models\AtProudctUse;
use App\Models\WildHarvesterForestProductDetail;
use App\Models\IndividualProducerDetailOfStandingCorp;
use App\Models\IndividualProducerFarmerDetail;
use App\Models\RefTransportationMode;
use App\Models\CertificateStandardDetail;
use App\Models\RefPackingMaster;
use App\Models\AtFarmerLandDetail;
use App\Models\AtAccrediationDocumentUpload;
use App\Models\WildHarvesterDetail;
use App\Models\AtOspIcsIndividual;
use App\Models\CBStatewiseRestriction;
use App\Models\RefHelpDeskStatus;
use App\Models\AtCBRegistrationPermission;
use App\Models\SourceDetails;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Http;
use Carbon\Carbon;



if (!function_exists('pr')) {
    function pr($request)
    {
        echo '<pre>';
        print_r($request);
    }
}

if (!function_exists('pra')) {
    function pra($request)
    {
        pr($request->toArray());
    }
}



//Send Mail with template
function send_mailTemplate($to, $subject, $templates, $data, $cc = null, $bcc = null, $applicationType = null)
{
    try {
        $res = Mail::send(
            $templates,
            $data,
            function ($message) use ($to, $subject, $cc, $bcc) {
                $message->to($to);
                if (!empty($cc)) {
                    $message->cc($cc);
                }
                if (!empty($bcc)) {
                    $message->bcc($bcc);
                }
                $message->from('no-reply@gmail.com');

                $message->subject($subject);
            }
        );

        return true;
    } catch (\Exception $e) {
        Log::error($e);

        return true;
    }
}
/*
*send OTP
*/
if (!function_exists('generateOTP')) {
    function generateOTP()
    {
        return rand(10000, 99999);
        //return '11111';
        //return '12345';
    }
}

function random_string($str_len = 30)
{
    $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    $result = '';
    for ($i = 0; $i < $str_len; $i++) {
        $result .= $characters[mt_rand(0, 61)];
    }

    return $result;
}
function random_numeric($str_len = 30)
{
    $randnum = rand(1111111111, mt_getrandmax());

    return  $randnum;
}
function saveMedia($file, $repository_name = '/brochure', $str_len = 5, $file_permission = 'public')
{
    $disk_name = 'uploads';
    $filename = random_string($str_len) . '_' . time() . '.' . $file->getClientOriginalExtension();
    Storage::disk('uploads')->put($repository_name . '/' . $filename, file_get_contents($file->getRealPath()), $file_permission);

    return '/' . $disk_name . (($repository_name != '') ? $repository_name . '/' : '') . $filename;
}
function getAmountInWords(float $number)
{
    $decimal = round($number - ($no = floor($number)), 2) * 100;
    $hundred = null;
    $digits_length = strlen($no);
    $i = 0;
    $str = [];
    $words = [
        0 => '', 1 => 'one', 2 => 'two',
        3 => 'three', 4 => 'four', 5 => 'five', 6 => 'six',
        7 => 'seven', 8 => 'eight', 9 => 'nine',
        10 => 'ten', 11 => 'eleven', 12 => 'twelve',
        13 => 'thirteen', 14 => 'fourteen', 15 => 'fifteen',
        16 => 'sixteen', 17 => 'seventeen', 18 => 'eighteen',
        19 => 'nineteen', 20 => 'twenty', 30 => 'thirty',
        40 => 'forty', 50 => 'fifty', 60 => 'sixty',
        70 => 'seventy', 80 => 'eighty', 90 => 'ninety',
    ];
    $digits = ['', 'hundred', 'thousand', 'lakh', 'crore'];
    while ($i < $digits_length) {
        $divider = ($i == 2) ? 10 : 100;
        $number = floor($no % $divider);
        $no = floor($no / $divider);
        $i += $divider == 10 ? 1 : 2;
        if ($number) {
            $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
            $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
            $str[] = ($number < 21) ? $words[$number] . ' ' . $digits[$counter] . $plural . ' ' . $hundred : $words[floor($number / 10) * 10] . ' ' . $words[$number % 10] . ' ' . $digits[$counter] . $plural . ' ' . $hundred;
        } else {
            $str[] = null;
        }
    }
    $Rupees = implode('', array_reverse($str));
    $paise = ($decimal > 0) ? '.' . ($words[$decimal / 10] . ' ' . $words[$decimal % 10]) . ' Paise' : '';

    return ($Rupees ? $Rupees . 'Rupees ' : '') . $paise;
}


function IndMoneyFormat($number)
{
    $decimal = (string) ($number - floor($number));
    $money = floor($number);
    $length = strlen($money);
    $delimiter = '';
    $money = strrev($money);

    for ($i = 0; $i < $length; $i++) {
        if (($i == 3 || ($i > 3 && ($i - 1) % 2 == 0)) && $i != $length) {
            $delimiter .= ',';
        }
        $delimiter .= $money[$i];
    }

    $result = strrev($delimiter);
    $decimal = preg_replace("/0\./i", '.', $decimal);
    $decimal = substr($decimal, 0, 3);

    if ($decimal != '0') {
        $result = $result . $decimal;
    }

    return $result;
}

function getRoles()
{
    $result = Role::where('id', '!=', 1)->where('id', '!=', 7)->get();

    return $result;
}

function getZone()
{
    $result = Zone::where('is_deleted', '=', 0)->get();

    return $result;
}

function getAllState()
{
    $result = RefState::orderBy('state_name', 'Asc')->get();
    return $result;
}
function getAllDesignation()
{
    $result = RefDesignation::orderBy('designation_name', 'Asc')->get();
    return $result;
}

function getCBCountStateWise($id)
{
    $cb = User::where('ref_state_id', $id)->where('ref_operator_type_id', 1)->count();
    return $cb ?? 0;
}

function getAllProduct()
{
    $result = RefProduct::orderBy('product_name', 'Asc')->get();
    return $result;
}
function getAllCategory()
{
    $result = RefCategory::orderBy('category_name', 'Asc')->get();
    return $result;
}

function getStateNameById($id)
{
    // Ensure $id is an integer
    $id = (int) $id;

    $result = RefState::where('id', $id)->value('state_name');
    return $result;
}

function getDistrictNameById($id)
{
    // Ensure $id is an integer
    $id = (int) $id;

    $result = RefDistrict::where('id', $id)->value('district_name');
    return $result;
}
function getVillageNameById($id)
{
    // Ensure $id is an integer
    $id = (int) $id;

    $result = RefVillage::where('id', $id)->value('village_name');
    return $result;
}
function statusdata(){
    $result = RefHelpDeskStatus::all();
    return $result;
}
function getHelpstatusdata($id){
    $result = RefHelpDeskStatus::where('id',$id)->first();
    return $result->status ?? '';
}
// function getCBNamesById($operatorTypeId)s
// {
//     $results = USER::where('ref_operator_type_id', $operatorTypeId)->pluck('first_name', 'id')->toArray();
//     return $results;
// }
// function getCBNamesById()
// {
//     $operatorTypeId = 1;  // Set the operator type ID to 1
//     $results = USER::where('ref_operator_type_id', $operatorTypeId)->pluck('first_name');
//     return $results;
// }
function getCBNamesById()
{
    $result = USER::where('ref_operator_type_id', 1)
    // add by sandeep
    ->whereNotIn('operator_status', [6,7,8])
    ->where('id', '!=', 302)
    ->orderBy('first_name', 'asc')
    // end
    ->get();
    return $result;
}


function getState($zone_id)
{
    $result = RefState::where('ref_zone_id', '=', $zone_id)->where('is_deleted', '=', 0)->get();

    return $result;
}


function getMonth()
{
    $result = [1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April', 5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August', 9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'];

    return $result;
}

function getopertorstatus()
{
    $result = [1 => 'Suspended', 2 => 'Terminate', 3 => 'Withdrawal By CB', 4 => 'Withdrawal By Operator', 5 => 'De Registered'];

    return $result;
}

function getMonthById($id)
{
    $result = [1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April', 5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August', 9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'];
    foreach ($result as $key => $row) {
        if ($id == $key) {
            return $row;
        }
    }
}

function getMonthByName($name)
{
    $result = [1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April', 5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August', 9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'];
    foreach ($result as $key => $row) {
        if ($name == $row) {
            return $key;
        }
    }
}


function dateFormat($date)
{
    if ($date) {
        return date('d/m/Y', strtotime($date));
    } else {
        return '';
    }
}
function yearFormat($date)
{
    if ($date) {
        return date('Y', strtotime($date));
    } else {
        return '';
    }
}

function monthFormat($date)
{
    if ($date) {
        return date('M', strtotime($date));
    } else {
        return '';
    }
}

function getLocality($zoneid)
{
    $localityQry = DB::table('ref_state')->where('is_deleted', 0);
    if ($zoneid) {
        $localityQry = $localityQry->where('ref_zone_id', $zoneid);
    }
    $locality = $localityQry->orderBy('state_name', 'Asc')->get();

    return $locality;
}
function getLocalityByID($locality)
{
    $localityQry = DB::table('ref_state')->where('is_deleted', 0)->where('id', $locality);
    $locality = $localityQry->orderBy('state_name', 'Asc')->first();

    return $locality;
}

function getZoneNameByID($id)
{
    $localityQry = Zone::where('is_deleted', 0)->where('id', $id);
    $locality = $localityQry->orderBy('zone_name', 'Asc')->first();

    return $locality;
}

function getDistrict($stateid)
{
    $districtQry = DB::table('ref_district')->where('is_deleted', 0);
    if ($stateid) {
        $districtQry = $districtQry->where('ref_state_code', $stateid);
    }
    $district = $districtQry->orderBy('district_name', 'Asc')->get();

    return $district;
}

function getDistrictID($district)
{
    $districtQry = DB::table('ref_district')->where('is_deleted', 0);
    if ($district) {
        $districtQry = $districtQry->where('id', $district);
    }
    $district = $districtQry->first();

    return $district;
}


function get_field_name($id)
{
    $fields = \App\Models\RefFields::where('id', $id)->first();
    return ($fields) ? $fields->name : '';
}

function get_activity_name($id)
{
    $fields = \App\Models\ActivitiesMaster::where('id', $id)->select('name')->first();

    return $fields->name;
}

function get_activity_name_fields($id)
{
    $fields = \App\Models\ActivityNameFields::where('activity_name_id', $id)->select('ref_field_id')->get();

    return $fields;
}
function get_state_name($id)
{
    if ($id != '') {
        $dis = \App\Models\RefState::where('id', $id)->first();

        return $dis->state_name ?? '';
    } else {
        return null;
    }
}
function get_district_name($id)
{
    $dis = \App\Models\RefDistrict::where('district_code', $id)->first();

    return $dis->district_name ?? '';
}

function get_district_name_by_id($id)
{
    if ($id != '') {
        $dis = \App\Models\RefDistrict::where('id', $id)->first();

        return $dis->district_name;
    } else {
        return null;
    }
}

function get_village_name($id)
{
    $dis = \App\Models\RefVillage::where('village_code', $id)->first();

    return $dis->village_name ?? '';
}

function get_village_name_by_id($id)
{
    $dis = \App\Models\RefVillage::where('id', $id)->first();

    return $dis->village_name ?? '';
}

function get_block_name($id)
{
    $dis = \App\Models\RefBlock::where('id', $id)->first();

    return $dis->block_name ?? '';
}

function get_roles()
{
    $roles = \App\Models\Role::where('id', '!=', '7')->get();
    return $roles;
}



function deleteOldImage($file_name, $imagePath)
{
    if (is_null($file_name)) {
        return;
    }

    if (file_exists($imagePath)) {
        unlink($imagePath);
    }
    return true;
}

function get_inspector_data($id)
{
    $inspdetails = \App\Models\UserInspector::where('id', $id)->first();
    return $inspdetails;
}


function getDistrictByStateID($stateid)
{
    $district = array();
    if ($stateid != '') {
        $district = RefDistrict::where("ref_state_id", $stateid)
            ->orderBy('district_name')->get();
    }
    return $district;
}

function getBlockTehsilByDistrictID($district)
{
    $blockTehsil = array();
    if ($district != '') {
        $blockTehsil = RefRegion::where("ref_district_id", $district)
            ->orderBy('block_tehsil_name')->get();
    }
    return $blockTehsil;
}

function getBlockTehsilByID($id)
{
    $blockTehsil = RefRegion::where("id", $id)
        ->orderBy('block_tehsil_name')->first();
    return $blockTehsil->block_tehsil_name;
}

function getVillageByBlock($block_id)
{
    $village = array();
    if ($block_id != '') {
        $village = RefVillage::where("ref_block_tehsil_id", $block_id)
            ->orderBy('village_name')->get();
    }
    return $village;
}

/* function getGender($gen)
{
    if ($gen == 'M') {
        return 'Male';
    } elseif ($gen == 'F') {
        return 'Female';
    } elseif ($gen == 'T') {
        return 'Transgender';
    }
} */

function getGenderName()
{
    $data = [
        '1' => 'Male',
        '2' => 'Female',
        '3' => 'Transgender',
    ];

    return $data;
}


function getGenderNameByID($id)
{
    $data = [
        '1' => 'Male',
        '2' => 'Female',
        '3' => 'Transgender',
    ];

    return $data[$id];
}

function getRefBank()
{
    $bank = RefBank::get();
    return $bank;
}


function getDesibationById($id)
{
    $bank = RefDesignation::where('id', $id)->first();
    return $bank->designation_name ?? '';
}



function getRefBankById($id)
{
    $bank = RefBank::where('id', $id)->first();
    return $bank->bank_name ?? '';
}


function getRefHscode()
{
    $hscode = array(); //DB::table('ref_hscode')->get();
    return $hscode;
}


function getRefHscodeByID($id)
{
    if (!is_numeric($id) || intval($id) <= 0) {
        return null;
    }

    $hscode = RefProduct::where('id', intval($id))->first();

    if ($hscode) {
        return $hscode->hs_code;
    }

    return null;
}

function getRefProduct()
{
   // $product = DB::table('ref_product','asc')->get();
       
   

   $product = DB::table('ref_product')
        ->select('*') // Specify necessary columns
        ->orderBy('product_name', 'asc') // Sort by product_name in ascending order
        ->get();
    return $product;
}

function getInspectorName($insId)
{
    $inspector = UserInspector::where('id', $insId)->first();
    return $inspector;
}
function getStateName($id)
{
    if ($id != '') {
        $statename = DB::table('ref_state')->where('is_deleted', 0)->where('id', $id)->first();
        if (!empty($statename)) {
            return $statename->state_name;
        }
    }
    return 'NA';
}


function getDisName($id)
{
    if ($id != '') {
        $disname = DB::table('ref_district')->where('is_deleted', 0)->where('id', $id)->first();
        if (!empty($disname)) {
            return $disname->district_name;
        }
    }
    return 'NA';
}
function getTalukName($id)
{
    if ($id != '') {
        $talname = DB::table('ref_block_tehsil')->where('is_deleted', 0)->where('id', $id)->first();
        if (!empty($talname)) {
            return $talname->block_tehsil_name;
        }
    }
    return 'NA';
}
function getVillName($id)
{
    if ($id != '') {
        $villname = DB::table('ref_village')->where('is_deleted', 0)->where('id', $id)->first();
        if (!empty($villname)) {
            return $villname->village_name;
        }
    }
    return 'NA';
}
function getTaggingDetail($data)
{
    $tagDet = AtFarmerLandGeoDetail::where($data)->get();
    return $tagDet;
}
function farmerProposedCorpDetail($data)
{
    $farproDet = AtFarmerProposedCorpDetail::where($data)->get();
    return $farproDet;
}
function farmerStandingCorpDetail($data)
{
    $farstanDet = AtFarmerStandingCorpDetail::where($data)->get();
    return $farstanDet;
}
function getRefOrganicStatusMaster()
{
    $orgStatus = DB::table('ref_organic_status_master')->get();
    return $orgStatus;
}
// function getRefOrganicStatusMasterByID($id)
// {
//     $result = DB::table('ref_organic_status_master')->where('id',$id)->first();
//     return $result->organic_status ?? '';
// }

function getRefOrganicStatuscodeByname($id)
{
    if(!empty($id)){

    $result = DB::table('ref_organic_status_master')->where('id', $id)->first();
    return $result->organic_status_code ?? '';
    }else{
        return redirect()->back();
    }
}

function getRefOrganicStatusMasterByID($id)
{
    // Ensure $id is an integer
    $id = (int) $id;

    // Use the appropriate query builder syntax for Laravel
    $result = DB::table('ref_organic_status_master')->where('id', $id)->first();

    // Check if $result is not null before accessing its properties
    return $result ? $result->organic_status : '';
}


function getRolesTitle($id)
{
    $result = Role::where('id', $id)->first();

    return $result->title;
}

function getCheckPointsById($id)
{
    $result = RefCheckPoints::where('id', $id)->first();
    return $result->check_points ?? '';
}


function getDashboardGraph($month, $ref_operator_type_id)
{


    $startMonth = Carbon::now()->month($month)->day(1)->format("Y-m-d 00:00:00");
    $lastMonth = Carbon::now()->month($month)->endOfMonth()->format("Y-m-d 23:59:59");
     //dd( $startMonth , $lastMonth);
    //$first_day_this_month = '2023-'.$month.'-01 00:00:00'; // hard-coded '01' for first day

    //$last_day_this_month  = '2023-'.$month.'-28 00:00:00';

    $last_month_users = User::select('ref_operator_type_id', DB::raw('COUNT(id) as users'))->groupBy('ref_operator_type_id')
        ->where('user_type', '=', 1)
        ->where('ref_operator_type_id', '=', $ref_operator_type_id)
        ->where('status', 1)
        ->whereBetween('created_at', [$startMonth, $lastMonth])
        ->count();

       // dd($last_month_users);
    return $last_month_users;
}

function getDashboardmandator($month)
{
    $startMonth = Carbon::now()->month($month)->day(1)->format("Y-m-d 00:00:00");
    $lastMonth = Carbon::now()->month($month)->endOfMonth()->format("Y-m-d 23:59:59");


    $last_month_users = DB::table('mandator_register')
        ->whereBetween('created_at', [$startMonth, $lastMonth])
        ->count();
    // dd($last_month_users);
    return $last_month_users;
}

function getRegno($id, $opr)
{
    $st = 'Not Alloted';
    $us = User::select('created_at')->where('id', $id)->where('status', 2)->first();

    if ($us) {
        // $m = date('m',strtotime($us->created_at));
        // $y = substr(date('Y',strtotime($us->created_at)),-2);
        // if($opr==2){
        //     $st = "ORG/SC/".$y.$m."/00".$id;
        // }else if($opr==3){
        //     $st = "ORG/SC/".$y.$m."/00".$id;
        // }else if($opr==4){
        //     $st = "ORG/SC/".$y.$m."/00".$id;
        // }else if($opr==5){
        //     $st = "ORG/SC/".$y.$m."/00".$id;
        // }else if($opr==6){
        //     $st = "ORG/SC/".$y.$m."/00".$id;
        // }else{

        // }

        $st = $us->registration_no;
    }
    return $st;
}


function getOperatorTypeById($id)
{
    
    if (empty($id)) {
        // Redirect back with an alert message
        return false;
    }
    $result = DB::table('ref_operator_type')->where('id', $id)->first();

    //dd($result);
    return $result->operator_type ?? '';
}


function user_name($id)
{
    $us = User::select('first_name', 'middle_name', 'last_name')->where('id', $id)->first();
    if ($us) {
        $first_name = $middle_name = $last_name = '';
        if (!empty($us->first_name)) {
            $first_name = $us->first_name;
        }
        if (!empty($us->middle_name)) {
            $middle_name = ' ' . $us->middle_name;
        }
        if (!empty($us->last_name)) {
            $last_name = ' ' . $us->last_name;
        }
        return ucwords($first_name . $middle_name . $last_name);
    } else {
        return 1;
    }
}

function getHscodeProductName($id)
{

    if ($id) {
        $product = DB::table('ref_product')->where('id', $id)->first();
        return $product->product_name ?? '';
    } else {
        return false;
    }
}
function getHscodeProductNameTrans($id)
{

    if ($id) {
        $product = DB::table('ref_product')->where('hs_code', $id)->first();
        return $product->product_name ?? '';
    } else {
        return false;
    }
}


function getHscodeProductNameTransById($id)
{
    // dd($id)
    if ($id) {
        $product = DB::table('ref_product')->where('id', $id)->first();
        return $product->product_name ?? '';
    } else {
        return false;
    }
}


function getHscodeById($id)
{
    if ($id) {
        $product = DB::table('ref_product')->where('id', $id)->first();
        return $product->hs_code;
    } else {
        return false;
    }
}

function getRefCountryMaster()
{
    $result = DB::table('ref_country_master')->orderBy('country_name', 'Asc')->get();
    return $result;
}

function get_product_cat_name($id)
{
    $dis = \App\Models\AtInputProductCategory::where('id', $id)->first();
    return $dis->category_name ?? '';
}

function get_product_subcat_name($id)
{
    $dis = \App\Models\AtInputProductSubCategory::where('id', $id)->first();

    return $dis->sub_product_category_name ?? '';
}

function getCountryName($id)
{
    $result = DB::table('ref_country_master')->where('id', $id)->first();
    return $result->country_name;
}

function getScopeCerNo($id, $opr)
{

    $st = 'NA';
    $us = User::select('created_at', 'id')->where('id', $id)->where('status', 2)->first();
    if ($us) {
        $m = date('m', strtotime($us->created_at));
        $y = substr(date('Y', strtotime($us->created_at)), -2);
        $lst = str_pad($us->id, 0, "0", STR_PAD_LEFT);
        if ($opr == 2) {
            $st = "ORG/SC/" . $y . $m . "/" . $lst;
        } else if ($opr == 3) {
            $st = "ORG/SC/" . $y . $m . "/" . $lst;
        } else if ($opr == 4) {
            $st = "ORG/SC/" . $y . $m . "/" . $lst;
        } else if ($opr == 5) {
            $st = "ORG/SC/" . $y . $m . "/" . $lst;
        } else {
            $st = "ORG/SC/" . $y . $m . "/" . $lst;
        }
    }
    return $st;
}
function getProductByICS($id)
{
    
    // get all inspector by id
    $inspectors = UserInspector::with('getRegisteredfarmers')->where('at_user_id', $id)->get();
    $data = array();
    $i = $ar = 0;
    foreach ($inspectors as $key => $ins) {
        if (!empty($ins->getRegisteredfarmers)) {
            foreach ($ins->getRegisteredfarmers as $key => $farmer) {
                //dd('2');
                if (!empty($farmer->getFarmerFarms)) {
                    foreach ($farmer->getFarmerFarms as $key => $farm) {
                        //dd('3');
                        if (!empty($farm->getFarmsStandingCrop)) {

                            foreach ($farm->getFarmsStandingCrop as $key => $crop) {

                                $data[$crop->season_name][$i]['crop'] = $crop->crop_name;

                                $data[$crop->season_name][$i]['organic_status'] = $crop->organic_status;
                                $data[$crop->season_name][$i]['crop_type'] = "Main";
                                $data[$crop->season_name][$i++]['area'] = $crop->crop_area;
                            }
                        }
                    }
                }
            }
        }
    }
    // get all farmer by inspector
    // get all standing crop by farmer
    // now get common products with area and production quantity
    return $data;
}


function getProductByWH($id)
{
    // Get all inspector by id
    $product = WildHarvesterForestProductDetail::where('at_user_id', $id)->get();
    return $product;
}



function getProductByIP($id)
{
    // get all inspector by id
    $inspectors = IndividualProducerFarmerDetail::with('getIndividualProducerFarmDetail')->where('at_user_id', $id)->get();

    $data = array();
    $i = $ar = 0;

    foreach ($inspectors as $key => $farmer) {
        //dd('2');
        if (!empty($farmer->getIndividualProducerFarmDetail)) {
            foreach ($farmer->getIndividualProducerFarmDetail as $key => $farm) {
                //dd('3');
                if (!empty($farm->getFarmsStandingCrop)) {

                    foreach ($farm->getFarmsStandingCrop as $key => $crop) {

                        $data[$crop->season_name][$i]['crop'] = $crop->name_of_corp;
                        $data[$crop->season_name][$i]['organic_status'] = $crop->organic_status;
                        $data[$crop->season_name][$i]['crop_type'] = "Main";
                        $data[$crop->season_name][$i++]['area'] = $crop->area;
                    }
                }
            }
        }
    }

    // get all farmer by inspector
    // get all standing crop by farmer
    // now get common products with area and production quantity
    return $data;
}


function getFarmersByICS($id)
{
    // get all inspector by id
    $inspectors = UserInspector::with('getRegisteredfarmers')->where('at_user_id', $id)->get();

    // get all farmer by inspector
    // get all standing crop by farmer
    // now get common products with area and production quantity
    return $inspectors;
}

if (!function_exists('getInputProductCategoryById')) {
    function getInputProductCategoryById($id)
    {
        return AtInputProductCategory::where('id', $id)->first();
    }
}
if (!function_exists('getProudctUseById')) {
    function getProudctUseById($id)
    {
        return AtProudctUse::where('id', $id)->first();
    }
}

if (!function_exists('countTableRecordById')) {
    function countTableRecordById($table_name, $field_name, $id)
    {
        return DB::table($table_name)->where($field_name, $id)->count();
    }
}

if (!function_exists('getSingleTableRecordById')) {
    function getSingleTableRecordById($table_name, $field_name, $id)
    {
        return DB::table($table_name)->where($field_name, $id)->first();
    }
}

if (!function_exists('getMultipleTableRecordById')) {
    function getMultipleTableRecordById($table_name, $field_name, $id)
    {
        return DB::table($table_name)->where($field_name, $id)->get();
    }
}

function getbyOperatornameRegNo($id)
{
    $registration_no = 'Not Alloted';
    $us = User::select('registration_no')->where('id', $id)->first();

    if (!empty($us->registration_no)) {
        $registration_no = $us->registration_no;
    }
    return $registration_no;
}

function getFarmDetailsByID($id)
{
    $farmData = AtFarmDetails::where('id', $id)->first();
    if (!empty($farmData)) {
        return $farmData;
    } else {
        return '';
    }
}

function getFarmerNameByID($id)
{

    if (!empty($id)) {
        $farmerData = AtFarmerRegDetail::where('id', $id)->first();
        return $farmerData->farmer_first_name . ' ' . $farmerData->farmer_middle_name . ' ' . $farmerData->farmer_last_name;
    } else {
        return '';
    }
}
function getFarmersByFarmID($id)
{
    $farmData = AtFarmDetails::where('id', $id)->first();
    if (!empty($farmData)) {
        $farmerData = getFarmerNameByID($farmData->at_farmer_reg_details_id);
        return $farmerData;
    } else {
        return '';
    }
}

function getRefTransportationMode()
{

    return  RefTransportationMode::get();
}

function getProductAndStatus($id, $type)
{
    $productData = array();
    if ($type == 'ics' || $type == 2) {
        //for ICS
        $data = AtClosingStock::where('id', $id)->first();

        if (!empty($data)) {
            $result = AtFarmerStandingCorpDetail::where('id', $data->at_farmer_standing_crop_details_id)->first();

            if (!empty($result) && $result->ref_product_id != '') {
                $product = RefProduct::where('id', $result->ref_product_id)->first();
                if (!empty($product)) {
                    $productData['id'] = $product->id ?? '';
                    $productData['product'] = $product->product_name ?? '';
                }
                if (!empty($result) && $result->organic_status != '') {
                    $staus = DB::table('ref_organic_status_master')->where('id', $result->organic_status)->first();
                    if (!empty($staus)) {
                        $productData['sts_id'] = $staus->id ?? '';
                        $productData['sts_name'] = $staus->organic_status ?? '';
                    }
                }
            }

            return $productData;
        }
    } elseif ($type == '3') {
        //for INDIVIDUAL PRODUCER
        $data = AtClosingStock::where('id', $id)->first();

        if (!empty($data)) {
            $result = IndividualProducerDetailOfStandingCorp::where('id', $data->at_ip_details_standing_crop_id)->first();
            // dd($result);
            if (!empty($result) && $result->ref_product_id != '') {
                $product = RefProduct::where('id', $result->ref_product_id)->first();
                if (!empty($product)) {
                    $productData['id'] = $product->id ?? '';
                    $productData['product'] = $product->product_name ?? '';
                }
                if (!empty($result) && $result->organic_status != '') {
                    $staus = DB::table('ref_organic_status_master')->where('id', $result->organic_status)->first();
                    if (!empty($staus)) {
                        $productData['sts_id'] = $staus->id ?? '';
                        $productData['sts_name'] = $staus->organic_status ?? '';
                    }
                }
            }

            ///dd($productData);
            return $productData;
        }
    } elseif ($type == '4') {
        //for WILD HARVESTER

        $data = AtClosingStock::where('id', $id)->first();

        if (!empty($data)) {
            $result = WildHarvesterForestProductDetail::where('id', $data->at_wh_forest_product_details_id)->first();

            if (!empty($result) && $result->ref_product_id != '') {
                $product = RefProduct::where('id', $result->ref_product_id)->first();
                if (!empty($product)) {
                    $productData['id'] = $product->id ?? '';
                    $productData['product'] = $product->product_name ?? '';
                }

                if (!empty($result) && $result->organic_status != '') {
                    $staus = DB::table('ref_organic_status_master')->where('id', $result->organic_status)->first();
                    if (!empty($staus)) {
                        $productData['sts_id'] = $staus->id ?? '';
                        $productData['sts_name'] = $staus->organic_status ?? '';
                    }
                }
            }

            ///dd($productData);
            return $productData;
        }
    } else {
        return '';
    }
}

if (!function_exists('getRefProductById')) {
    function getRefProductById($id)
    {
        return RefProduct::where('id', $id)->first();
    }
}

if (!function_exists('getProductNameById1')) {
    function getProductNameById1($id)
    {
        $res = RefProduct::where('id', $id)->first();
        return $res->product_name;
    }
}

function getScopeCerNoById($id)
{

    $us = CertificateStandardDetail::select('scope_certificate_no')->where('at_user_id', $id)->where('status', 1)->first();
    $st = '';
    if ($us) {
        $st = $us->scope_certificate_no;
    }
    return $st;
}
if (!function_exists('getUserById')) {
    function getUserById($id)
    {
        // Ensure $id is a valid integer
        if (!is_numeric($id) || intval($id) <= 0) {
            return null; // or handle the invalid input appropriately
        }

        // Cast $id to an integer
        $id = intval($id);

        // Execute the query
        return User::where('id', $id)->first();
    }
}


if (!function_exists('getTestParameter')) {
    function getTestParameter()
    {
        return DB::table('ref_cb_test_parameter_master')->get();
    }
}

// if (! function_exists('getTestParameterById')) {
//     function getTestParameterById($id)
//     {
// 		return DB::table('ref_cb_test_parameter_master')->select('test_parameter_name')->first();
//     }
// }
function getTestParameterById($id)
{

    $parameter = DB::table('ref_cb_test_parameter_master')->where('id', $id)->first();

    if ($parameter) {
        return $parameter->test_parameter_name;
    }

    return false; // Return a default string if not found
}


if (!function_exists('getOrgTestCategory')) {
    function getOrgTestCategory()
    {
        return DB::table('ref_org_test_category_mster')->get();
    }
}
if (!function_exists('getLaboratoryMaster')) {
    function getLaboratoryMaster()
    {
        return DB::table('ref_laboratory_master')->get();
    }
}

function getLabNameById($id)
{
    $result = DB::table('ref_laboratory_master')->where('id', $id)->first();
    if (!empty($result)) {
        return $result->lab_name;
    } else {
        return '';
    }
}

function getCategoryNameById($id)
{
    $result = DB::table('ref_category')->where('id', $id)->first();
    if (!empty($result)) {
        return $result->category_name;
    } else {
        return '';
    }
}
function getCountryNameById($id)
{
    $result = DB::table('ref_country_master')->where('id', $id)->first();
    if (!empty($result)) {
        return $result->country_name;
    } else {
        return '';
    }
}

function getParameterNameById($id)
{
    $result = DB::table('ref_cb_test_parameter_master')->where('id', $id)->first();
    if (!empty($result)) {
        return $result->test_parameter_name;
    } else {
        return '';
    }
}

function getParameterMtrById($id)
{
    $result = DB::table('ref_cb_test_parameter_master')->where('id', $id)->first();
    if (!empty($result)) {
        return $result->mrl_value;
    } else {
        return '';
    }
}

function getProductName($id)
{
    $result = DB::table('ref_product')->where('id', $id)->first();
    if (!empty($result)) {
        return $result->product_name;
    } else {
        return '';
    }
}
function getProductNameById($id)
{
    $result = DB::table('ref_packing_master')->where('id', $id)->first();
    if (!empty($result)) {
        return $result->packing_type;
    } else {
        return '';
    }
}

function getTransportNameById($id)
{
    $result = DB::table('ref_transportation_mode')->where('id', $id)->first();
    if (!empty($result)) {
        return $result->mode_name;
    } else {
        return '';
    }
}
function getPackinNameById($id)
{
    $result = DB::table('ref_packing_master')->where('id', $id)->first();
    if (!empty($result)) {
        return $result->packing_type;
    } else {
        return '';
    }
}


if (!function_exists('getPackingMaster')) {
    function getPackingMaster()
    {
        return RefPackingMaster::get();
    }
}

if (!function_exists('getPackingMasterById')) {
    function getPackingMasterById($id)
    {
        if ($id != '') {
            return RefPackingMaster::where('id', $id)->first();
        } else {
            return '';
        }
    }
}
function getCBListForNOC()
{

    //$selfCB = User::where('id',$userid)->first();
    //dd("aaaaaaaaaa".$selfCB->created_by);
    return User::where('ref_operator_type_id', 1)->get();
}

function getFarmerRegNo($id, $statsid)
{
    $state = RefState::select('state_short_name')->where('id', $statsid)->first();

    if ($state) {
        // $m = date('m',strtotime($us->created_at));
        //$y = substr(date('Y',strtotime($us->created_at)),-2);
        $lst = str_pad($id, 6, "0", STR_PAD_LEFT);
        $reg_no = $state->state_short_name . $lst;
    } else {
        $reg_no = '';
    }
    return $reg_no;
}

function getFarmRegNo($id, $statsid)
{
    $state = RefState::select('state_short_name')->where('id', $statsid)->first();

    if ($state) {
        $lst = str_pad($id, 6, "0", STR_PAD_LEFT);
        $reg_no = $state->state_short_name . $lst;
    } else {
        $reg_no = '';
    }
    return $reg_no;
}

function getFarmArea($fid)
{
    $area = AtFarmerLandDetail::where('at_farmer_reg_details_id', $fid)->select('total_area')->get();
    $totalArea = 0;
    foreach ($area as $ta) {
        $totalArea = $totalArea + $ta->total_area;
    }
    return $totalArea;
}


function getAddress($tbl_name, $fie_name, $userId)
{

    $address = '';
    $data = DB::table($tbl_name)->where($fie_name, $userId)->first();
    $state = getStateName($data->ref_state_id);
    $district = get_district_name_by_id($data->ref_district_id);
    $tehsil = getBlockTehsilByID($data->ref_block_tehsil_id);
    $village = getVillName($data->ref_village_id);
    $pin = $data->pin ?? '';

    $address = $state . ', ' . $district . ', ' . $tehsil . ', ' . $village . ', ' . $pin;

    return $address;
}


function getClosingStockByCropId($scid)
{
    $result = AtClosingStock::where('at_farmer_standing_crop_details_id', $scid)->first();
    if (!empty($result)) {
        return $result;
    } else {
        return '';
    }
}



function checkOSPDetail($fid)
{
    $result = AtOspIcsIndividual::where('at_farmer_reg_details_id', $fid)->count();
    if ($result > 0) {
        return "Filled";
    } else {
        return '-';
    }
}

function getAccrediationDocumentByID($id, $creBy)
{

    $result = AtAccrediationDocumentUpload::where('ref_cba_supporting_document_master_id', $id)->where('created_by', $creBy)->first();
    if (!empty($result)) {
        return $result;
    } else {
        return '';
    }
}

if (!function_exists('getIssueType')) {
    function getIssueType()
    {
        return DB::table('ref_issue_type')->where('id', '!=', 6)->get();
    }
}

// if (! function_exists('getIssueTypee')) {
//     function getIssueTypee($issueTypeId)
//     {
//         $issueTypes = DB::table('ref_issue_type')->where('id', $issueTypeId)->get();
//         $issueName = '';

//         if ($issueTypes->isNotEmpty()) {
//             $issueName = $issueTypes->pluck('issue_name')->first();
//         }

//         return $issueName;
//     }
// }


function getIssueTypeByOpe()
{
    return DB::table('ref_issue_type')->get();
}
function getIssueTypeByID($id)
{
    //dd($id);
    $data = DB::table('ref_issue_type')->where('id', $id)->first();

    return $data->issue_name ?? '';
}
function getActivitiesTypeByID($id)
{
    $data = DB::table('ref_activities_type')->where('id', $id)->first();

    return $data->type ?? '';
}
if (!function_exists('getSubIssueType')) {
    function getSubIssueType()
    {
        return DB::table('ref_sub_issue_type')->get();
    }
}
function getSubIssueTypeByID($id)
{
    //dd($id);
    $data = DB::table('ref_sub_issue_type')->where('id', $id)->first();

    return $data->sub_issue_name ?? '';
}
function getWildHarvesterName($id)
{
    if ($id != '') {
        $whname = WildHarvesterDetail::where('id', $id)->first();
        if (!empty($whname)) {
            return $whname->area_cultivation ?? '';
        }
    }
    return '';
}

function send_email($emails, $subject, $maildata)
{

    $headers = [
        'From' => 'From: Apeda<iaiapplication2022@gmail.com>',
        'MIME-Version' => '1.0',
        'Content-Type' => 'text/html; charset=iso-8859-1'
    ];

    @mail($emails, $subject, $maildata, $headers);
    return true;
}


// function aggregateDataByYear($data, $startYear, $endYear) {
//     $aggregatedData = array_fill_keys(range($startYear, $endYear), [
//         'year' => 0,
//         'approvedCount' => 0,
//         'pendingCount' => 0,
//         'totalCount' => 0,
//     ]);

//     foreach ($data as $record) {
//         $year = $record->year;
//         $aggregatedData[$year] = (array)$record + $aggregatedData[$year];
//     }

//     return $aggregatedData;
// }



// if (!function_exists('sendOtp')) {
//     function sendOtpHelp($mobileNumber, $otp)
//     {

//         $apiUrl = 'https://apeda.gov.in/apedaMobile/api/apedawebsite/sendNicOTP';
//         $data = [
//             'txtmessage' => "Your OTP for APEDA online registration is : $otp",
//             'senderID' => 'APEDAI',
//             'mobilenumber' => $mobileNumber,
//             'templateID' => '1707160681109422053',
//         ];

//         $ch = curl_init($apiUrl);
//         curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//         curl_setopt($ch, CURLOPT_HTTPHEADER, [
//             'Content-Type: application/json',
//         ]);
//         curl_setopt($ch, CURLOPT_POST, true);
//         curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

//         $response = curl_exec($ch);
//         if (curl_errno($ch)) {
//             return ['error' => curl_error($ch)];
//         }
//         curl_close($ch);

//         return json_decode($response, true);
//     }
// }

if (!function_exists('sendOtpHelp')) {
    // Old SMS API Module 
    function sendOtpHelp($mobileNumber, $otp)
    {

        $apiUrl = 'https://apeda.gov.in/apedaMobile/api/apedawebsite/sendNicOTP';
        $data = [
            'txtmessage' => "Your OTP for APEDA online registration is : $otp",
            'senderID' => 'APEDAI',
            'mobilenumber' => $mobileNumber,
            'templateID' => '1707160681109422053',
        ];

        $ch = curl_init($apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
        ]);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

        $response = curl_exec($ch);

        if (curl_errno($ch)) {
            curl_close($ch);
            return [
                'status' => false,
                'message' => 'Curl error: ' . curl_error($ch),
            ];
        }

        curl_close($ch);

        // Handle plain string response
        if (is_string($response)) {
            // Parse the string for relevant information
            $success = strpos($response, 'Message Accepted') !== false;
            $message = $response;

            return [
                'status' => $success,
                'message' => $message,
            ];
        }

        return [
            'status' => false,
            'message' => 'Unexpected response format from API.',
        ];
    }

}
if (!function_exists('sendOtpHydgw')) {

    //Hydgw sms Gov Module 

    function sendOtpHydgw($mobileNumber, $otp)
    {
        $apiUrl = 'https://hydgw.sms.gov.in/failsafe/MLink?=null';
        
        // Prepare the parameters according to the new API format
        $data = [
            'username' => 'apeda.otp',  // Your username
            'pin' => 'ncqAXt8G',        // Your pin
            'mnumber' => $mobileNumber, // Mobile number of the recipient
            'message' => "Your OTP for Mobile verification is : $otp , More details at www.apeda.gov.in",  // OTP message
            'signature' => 'APEDAP',    // Signature as required by the API
            'dlt_entity_id' => '1701159083068647860', // Entity ID (make sure it's correct)
            'dlt_template_id' => '1707162575686013734', // Template ID (make sure it's correct)
        ];
    
        $ch = curl_init($apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_ENCODING, '');
        curl_setopt($ch, CURLOPT_TIMEOUT, 0);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));  // Use http_build_query for POST data
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: text/plain',
        ]);
    
        $response = curl_exec($ch);
    
        if (curl_errno($ch)) {
            curl_close($ch);
            return [
                'status' => false,
                'message' => 'Curl error: ' . curl_error($ch),
            ];
        }
    
        curl_close($ch);
    
        // Handle plain string response
        if (is_string($response)) {
            // Check the response for success
            $success = strpos($response, 'Success') !== false; // Modify based on API success condition
            $message = $response;
    
            return [
                'status' => $success,
                'message' => $message,
            ];
        }
    
        return [
            'status' => false,
            'message' => 'Unexpected response format from API.',
        ];
    }
    

}



// if (!function_exists('sendOtp')) {
//     function sendOtpHelp($mobileNumber, $otp)
//     {
//         $apiUrl = 'https://hydgw.sms.gov.in/failsafe/MLink?';

//         // Updated data as per the new API credentials
//         $data = [
//             'username' => 'apeda.otp', // Primary username
//             'pin' => 'ncqAXt8G',      // Corresponding pin
//             'destination' => $mobileNumber, // Mobile number to send OTP
//             'message' => "Your OTP for APEDA online registration is: $otp",
//             'sender' => 'APEDAI',
//             'service' => 'SMS', // Assuming 'SMS' is the service type for this API
//         ];

//         $ch = curl_init($apiUrl);
//         curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//         curl_setopt($ch, CURLOPT_HTTPHEADER, [
//             'Content-Type: application/x-www-form-urlencoded',
//         ]);
//         curl_setopt($ch, CURLOPT_POST, true);
//         curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data)); // Use 'http_build_query' for URL-encoded POST

//         $response = curl_exec($ch);
//         if (curl_errno($ch)) {
//             return ['error' => curl_error($ch)];
//         }
//         curl_close($ch);

//         return json_decode($response, true);
//     }
// }



if (!function_exists('sendLoginDetailsSms')) {
    function sendLoginDetailsSms($mobileNumber, $username, $email, $password = '123456')
    {
        $apiUrl = 'https://apeda.gov.in/apedaMobile/api/apedawebsite/sendNicOTP';

       // $message = 'Your Login details to access TraceNet are Name: '.$username.', User ID: '.$email.', Password: '.$password.'. More details at www.apeda.gov.in';

       $message = "Your Login details to access Tracenet are  Name : $username , User ID :$email and  Password  : $password , More details at www.apeda.gov.in";

       // dd($message );
        $data = [
            'txtmessage' => $message,
            'senderID' => 'APEDAI',
            'mobilenumber' => $mobileNumber,
            'templateID' => '1707161761984762652',
        ];

        $ch = curl_init($apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
        ]);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

        $response = curl_exec($ch);
        if (curl_errno($ch)) {
            Log::error('SMS sending failed: ' . curl_error($ch));
        }
        curl_close($ch);


        return json_decode($response, true);
    }
}


function logHistory($name, $username, $type, $user_action)
{

    $data = [];
    if ($username) :
        $data = array(
            "user_name" => $name,
            "user_type" => $username,
            "user_id" => $type,
            "ip_address" => $_SERVER['REMOTE_ADDR'],
            'user_action' => $user_action,
            'action_url' => url()->full(),
            'created_on' => now(),
            );
        DB::table('log_history')->insert($data);
        return true;
    endif;
}



function getAllOperatorType()
{
    $result = RefOperatorType::select('operator_type', 'id')
                ->whereIn('id', [2, 3, 4, 5, 6])
                ->orderBy('operator_type', 'asc')
                ->get();
    return $result;
}

 

// function getcbNameById($id)
// {
//     // Ensure $id is an integer
//     $id = (int) $id;

//     $result = USER::where('id', $id)->value('first_name');
//     return $result;
// }


function getcbNameById($id)
{
    // Ensure $id is an integer
    $id = (int) $id;

    // Get first name and last name
    $firstName = USER::where('id', $id)->value('first_name');
    $lastName = USER::where('id', $id)->value('last_name');

    // Concatenate first and last name with a space between them
    $fullName = $firstName . ' ' . $lastName;

    return $fullName;
}


// if (!function_exists('maskAadhaarNumber')) {
//     function maskAadhaarNumber($aadhaar) {
//         if (preg_match('/^\d{12}$/', $aadhaar)) {
//             return '**** **** '.substr($aadhaar, -4);
//         }
//         return $aadhaar; // Return as is if not valid
//     }
// }

if (!function_exists('maskAadhaarNumber')) {
    function maskAadhaarNumber($aadhaar)
    {
        $decryptedAadhaar = null;
        $aadhaarNumber = $aadhaar;
        if(!empty($aadhaarNumber))
        {
            if (is_numeric($aadhaarNumber))
            {
                $maskedAadhaar = str_repeat('*', strlen($aadhaarNumber) - 4) . substr($aadhaarNumber, -4);
            }
            else
            {
                $decryptedAadhaar = \Crypt::decrypt($aadhaarNumber);
                $maskedAadhaar = str_repeat('*', strlen($decryptedAadhaar) - 4) . substr($decryptedAadhaar, -4);
            }
            return $maskedAadhaar;
        }
        else
        {
           
            return '';
        }
    }
}


function isValidBase64($string) {
    $decodedString = urldecode($string);
    if (base64_encode(base64_decode($decodedString, true)) === $decodedString) {
        return true;  
    } else {
        return false;  
    }
}

function getCBNamesBycreatedBy($created_by)
{
    $result = USER::where('id', $created_by)->value('first_name');
    return $result;
}

//eMsigned Mudule permission 

if (!function_exists('getUserDigitalSignatureModules')) {
    function getUserDigitalSignatureModules($userId, $module)
    {
        // Fetch user details from the database
        $user = DB::table('at_user')
            ->select('eSignModuleAllow', 'emStatus')
            ->where('id', $userId)
            ->where('is_deleted', 0)
            ->first();
        if (!$user) {
            return ['status' => 'error', 'msg' => 'User not found.'];
        }

        if ($user->emStatus !== 1) {
            return ['status' => 'error', 'msg' => 'User account is not active.'];
        }

        // Decode the allowed modules from JSON
        $modulesAllowed = json_decode($user->eSignModuleAllow, true);
        // Check if the specific module is allowed
        $isAllowed = in_array($module, $modulesAllowed);

        return [
            'status' => 'success',
            'msg' => $isAllowed ? "$module is allowed for this user." : "$module is not allowed for this user.",
            'isAllowed' => $isAllowed,
        ];
    }
}

if (!function_exists('getDigitalSignedPdf')) {
    function getDigitalSignedPdf($userId, $fileName)
    {
        // Fetch user details from the database
        $data = DB::table('at_emsigner_signature')
            ->select('filename', 'signedPath','signedStatus')
            ->where('at_user_id', $userId)
            ->where('filename', $fileName)
            ->where('signedStatus', '1')
            ->first();
        if (!$data) {
            return ['status' => 'error', 'msg' => 'Signed PDF found.'];
        }

        return [
            'status' => 'success',
            'filename' => $data->filename,
            'signedPath' => $data->signedPath,
            'signedStatus' => $data->signedStatus,
        ];
    }
}

if (!function_exists('determineESignLocation')) {
    function determineESignLocation($eSignLocation,$eSignStaticLocation)
    {
        $eSignLocation = $eSignLocation ?? 'Unknown'; 

        $eSignStaticLocation = $eSignStaticLocation ?? '';

        if ($eSignLocation === 'SL') {
            // Use static location if available, or set blank
            return $eSignStaticLocation ?: '';
        } elseif ($eSignLocation === 'DL') {
            // Fetch dynamic location using IP
            $userIP = request()->ip(); // Get user's IP address
            $geoInfo = getGeoLocationFromIP($userIP);
            print_r( $geoInfo); die;
            return $geoInfo ?: 'Unknown Dynamic Location';
        }

        // Default fallback
        return 'Unknown Location';
    }    
}

function getGeoLocationFromIP($ip)
{
    // Initialize cURL session
    $ch = curl_init();

    // Set cURL options
    curl_setopt($ch, CURLOPT_URL, "http://ip-api.com/json/{$ip}"); // API URL with the IP

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // Return response as a string
    curl_setopt($ch, CURLOPT_TIMEOUT, 5); // Timeout for the request in seconds

    // Execute cURL request
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    // Close the cURL session
    curl_close($ch);

    // Check for a successful response
    if ($httpCode == 200 && $response) {
        $geoData = json_decode($response, true);
        if (isset($geoData['status']) && $geoData['status'] === 'success') {
            return [
                'city' => $geoData['city'] ?? 'Unknown',
                'region' => $geoData['regionName'] ?? 'Unknown',
                'country' => $geoData['country'] ?? 'Unknown',
            ];
        }
    }

    // Return null or an appropriate fallback if the request fails
    return null;
}

if (!function_exists('getUsereMSignerData')) {
    function getUsereMSignerData($userId)
    {
        // Fetch user details from the database
        $user = DB::table('at_user')
            ->select('emUserId', 'emName', 'emStatus', 'eSignType', 'eSignReason', 'eSignLocation', 'eSignStaticLocation')
            ->where('id', $userId)
            ->where('is_deleted', 0)
            ->first();
        if (!$user) {
            return ['status' => 'error', 'msg' => 'User not found.'];
        }

        if ($user->emStatus !== 1) {
            return ['status' => 'error', 'msg' => 'User account is not active.'];
        }

        $emUserId = $user->emUserId ?? 'Unknown emUserId';
        $emName = $user->emName ?? 'Unknown emName';
        $emStatus = $user->emStatus ?? 'Unknown emStatus';
        $eSignType = $user->eSignType ?? 'Unknown eSignType';
        $eSignReason = $user->eSignReason ?? 'Unknown eSignReason';
        $eSignLocation = determineESignLocation($user->eSignLocation,$user->eSignStaticLocation);

        return [
            'status' => 'success',
            'emUserId' => $emUserId,
            'emName' => $emName,
            'emUserId' => $emUserId,
            'eSignType' => $eSignType,
            'emStatus' => $emStatus,
            'eSignReason' => $eSignReason,
            'eSignLocation' => $eSignLocation,
        ];
    }
}


 


if (!function_exists('CBstateAssign')) {
    
    function CBstateAssign($id) {
        $CBstateAssign = CBStatewiseRestriction::leftjoin('ref_state', 'ref_state.id', 'cb_statewise_restriction.ref_state_id')
        ->select('ref_state.id as refStateId','ref_state.state_name', 'cb_statewise_restriction.*')
        ->where('cb_id', $id)
        ->orderBy('ref_state_id', 'ASC')
        ->get();
                   
        return $CBstateAssign;
    }   
}


if (!function_exists('CBstateAssignForWithoutfn')) {
    function CBstateAssignForWithoutfn($created_by_id) {
		$cbstate = User::where('id',$created_by_id)->first();
        $CBstateAssign = CBStatewiseRestriction::leftjoin('ref_state', 'ref_state.id', 'cb_statewise_restriction.ref_state_id')
        ->select('ref_state.id as refStateId','ref_state.state_name', 'cb_statewise_restriction.*')
        ->where('cb_id', $cbstate->id)
        ->orderBy('ref_state_id', 'ASC')
        ->get();
        return $CBstateAssign;
    }   
}



if (!function_exists('getMenusubmenu')) {
    function getMenusubmenu($id) {
        $results = DB::table('at_cb_registration_permission as cb')
                    ->leftJoin('module as md', 'md.id', '=', 'cb.module_id')
                    ->leftJoin('sub_module as smb', 'smb.id', '=', 'cb.sub_module_id')
                    ->where('cb.cb_id', $id)
                    ->whereNull('cb.deleted_at')
                    ->select('md.id as module_id', 'md.module_name', 
                             'smb.id as submodule_id', 'smb.sub_module_name', 'smb.module_path') 
                     ->orderBy('smb.id')         
                    ->get();

        $menuStructure = [];
        foreach ($results as $result) {
            $moduleId = $result->module_id;
            $submoduleId = $result->submodule_id;
            if (!isset($menuStructure[$moduleId])) {
                $menuStructure[$moduleId] = [
                    'module_name' => $result->module_name,
                    'submodules' => []
                ];
            }

            if ($submoduleId) {
                $menuStructure[$moduleId]['submodules'][] = [
                    'submodule_id' => $submoduleId,
                    'submodule_name' => $result->sub_module_name,
                    'module_path' => $result->module_path 
                ];
            }
        }

        return $menuStructure;
    }
}

function getOperatorNameByRegNo($id)
{
    //$id = (int) $id;

    // Get first name and last name
    $firstName = USER::where('registration_no', $id)->value('first_name');
    $lastName = USER::where('registration_no', $id)->value('last_name');

    // Concatenate first and last name with a space between them
    $fullName = $firstName . ' ' . $lastName;

    return $fullName;
}

function getcbLogoById($id)
{    
    $id = (int) $id;

    $logo = USER::where('id', $id)->value('cb_logo_path');

    $logoName = $logo;

    return $logoName;
}

function getSourceQty($userId,$productId)
{        

    $quantitySource = SourceDetails::where('at_user_id', $userId)
    ->where('product_code', $productId)
    ->pluck('quantity_source')
    ->first();  
    
    return $quantitySource;
}


function getTranProdIdByDetailsSourc($id)
{
    if ($id) {
        $product = DB::table('at_op_transaction_vs_transaction_product as tcpro')
            ->leftJoin('at_op_transaction_product_sourced as pro_sour', 'pro_sour.at_op_transaction_vs_transaction_product_id', '=', 'tcpro.id')
            ->leftJoin('at_op_transaction_packing_details as pc_det', 'pc_det.at_op_transaction_product_sourced_id', '=', 'pro_sour.id')
            ->where('tcpro.id', $id)
            ->first();
        
        return $product ?? '';
    } else {
        return false;
    }
}



function getProductIdTransByHscode($id)
{
    if ($id) {
        $product = DB::table('ref_product')
            ->where('hs_code', $id)
            ->first();
        
        return $product ?? '';
    } else {
        return false;
    }
}
function getProductBYCBName($cbId)
{
    if ($cbId) {
        $getproduct = DB::table('cb_product_wise_restriction as prdres')
            ->select(
                'prdres.id as cbres_id',   
                'prdres.cb_id',   
                'prdres.ref_product_id',   
                'prdres.status',   
                'refpro.id',
                'refpro.hs_code',
                'refpro.product_name',
                'refpro.hscode_description',
                'refpro.ref_category_id'
            )
            ->leftJoin('ref_product as refpro', 'refpro.id', '=', 'prdres.ref_product_id')
            ->where('prdres.cb_id', $cbId)
            ->orderBy('prdres.id', 'ASC')
            ->get();
        
        return $getproduct ?? '';
    } else {
        return false;
    }
}










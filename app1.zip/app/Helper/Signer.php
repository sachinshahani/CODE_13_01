<?php

namespace App\Helpers;

use OpenSSL;
use InvalidArgumentException;

class Signer
{
    private $privateKey;

    public function __construct($privateKeyPath)
    {
        // Load the private key from a file
        if (!file_exists($privateKeyPath)) {
            throw new InvalidArgumentException("Private key file not found: " . $privateKeyPath);
        }

        $this->privateKey = openssl_pkey_get_private(file_get_contents($privateKeyPath));
        if ($this->privateKey === false) {
            throw new InvalidArgumentException("Invalid private key: " . openssl_error_string());
        }
    }

    public function sign($data)
    {
        // Generate the signature
        $signature = '';
        if (!openssl_sign($data, $signature, $this->privateKey, OPENSSL_ALGO_SHA256)) {
            throw new InvalidArgumentException("Signing failed: " . openssl_error_string());
        }

        // Encode the signature in base64
        return base64_encode($signature);
    }
}

<?php

namespace App\Repositories\Reports;

use App\Models\FinancialProgress;
use App\Models\FinancialTarget;
use App\Models\Office;
use App\Models\SchemeHead;
use App\Repositories\BaseRepository;

/**
 * Class FinancialRepository.
 */
class FinancialRepository extends BaseRepository
{
    public function getFinancialTable($scheme_id, $f_year, $month, $allocation)
    {
        $format[] = [];
        $offices = Office::with(['targets'=>function($q) use($scheme_id,$f_year)
        {
            return $q->where(['ref_scheme_id'=>$scheme_id,'ref_financial_year_id'=>$f_year]);
        }]);
        if($allocation == 'BE'){
            $offices = $offices->withSum('targets','target');
        }else{
            $offices = $offices->withSum('targets','revised_target');
        }
        $offices = $offices->get();
//        $offices = Office::with(['targets' => function ($q) use ($scheme_id, $f_year) {
//            return $q->where(['ref_scheme_id' => $scheme_id, 'ref_financial_year_id' => $f_year]);
//        }])
//        ->withSum('targets', 'target')->get();

        foreach ($offices as $off) {
            $out = [];
            $out[] = $off->office_code;

            foreach ($off->targets as $target) {
                if($allocation == 'BE') {
                    $out[] = $target->target;
                }else {
                    $out[] = $target->revised_target;
                }
            }
            if($allocation == 'BE') {
                $out[] = $off->targets_sum_target;
            }else {
                $out[] = $off->targets_sum_revised_target;
            }
            $format[] = $out;
            $progcess = FinancialProgress::select('progress')->where(['ref_scheme_id' => $scheme_id, 'ref_financial_year_id' => $f_year, 'month' => $month, 'ref_office_id' => $off->id])->get();

            if ($progcess->isNotEmpty()) {
                $out_new = [];
                $sum = 0;
                $out_new[] = '';
                foreach ($progcess as $p) {
                    $sum = $sum + $p->progress;
                    $out_new[] = $p->progress;
                }
                $out_new[] = $sum;
            }
            $format[] = $out_new;
        }
        if($allocation == 'BE') {
            $head_wise_sum = FinancialTarget::select('mis_scheme_head_id', \DB::raw('sum(target) as  target_sum'))->where(['ref_scheme_id' => $scheme_id, 'ref_financial_year_id' => $f_year])->groupBy('mis_scheme_head_id')->get();
        }else {
            $head_wise_sum = FinancialTarget::select('mis_scheme_head_id', \DB::raw('sum(revised_target) as  target_sum'))->where(['ref_scheme_id' => $scheme_id, 'ref_financial_year_id' => $f_year])->groupBy('mis_scheme_head_id')->get();
        }
        if ($head_wise_sum) {
            $target_total = [];
            $target_total[] = 'Total';
            $hwsum = 0;
            foreach ($head_wise_sum as $h_sum) {
                $target_total[] = $h_sum->target_sum;
                $hwsum = $hwsum + $h_sum->target_sum;
            }
            $target_total[] = $hwsum;
            $format[] = $target_total;
        }
        $head_wise_progress_sum = FinancialProgress::query()
                    ->select(\DB::raw('sum(financial_office_progress.progress) as progress_sum'))
                    ->Join('financial_office_target as t', 't.id', '=', 'financial_office_progress.financial_office_target_id')
                    ->where(['financial_office_progress.ref_scheme_id' => $scheme_id, 'financial_office_progress.ref_financial_year_id' => $f_year, 'financial_office_progress.month' => $month])
                    ->groupBy('t.mis_scheme_head_id')
                    ->get();

        if ($head_wise_progress_sum) {
            $progress_total = [];
            $progress_total[] = '';
            $hwpsum = 0;
            foreach ($head_wise_progress_sum as $h_sum) {
                $progress_total[] = $h_sum->progress_sum;
                $hwpsum = $hwpsum + $h_sum->progress_sum;
            }
            $progress_total[] = $hwpsum;
            $format[] = $progress_total;
        }

        return $format;
    }

    public function getTypeWiseTable($scheme_id, $f_year, $month, $type)
    {
        $format[] = [];

        $collection = collect(['Offices']);
        $headers = $collection->concat(SchemeHead::with('head')->join('ref_head', 'ref_head.id', 'mis_scheme_head.ref_head_id')->where('mis_scheme_head.ref_scheme_id', $scheme_id)->where('ref_head.type', $type)->get()->pluck('head.head_code'))->push('Total')->toArray();
        \DB::enableQueryLog();
        $offices = Office::with(['targets' => function ($q) use ($scheme_id, $f_year, $type) {
            return $q->whereHas('schemehead', function ($query) use ($type) {
                $query->whereHas('head', function ($qt) use ($type) {
                    $qt->where('type', $type);
                });
            })->where(['ref_scheme_id' => $scheme_id, 'ref_financial_year_id' => $f_year]);
        }])
            ->withSum('targets', 'target')->get();
        if ($headers) {
            foreach ($headers as $h) {
                $head_out = [];
                $head_out[] = $h;
            }
            $format[] = $head_out;
            foreach ($offices as $off) {
                $out = [];
                $out[] = $off->office_code;
                $tsum = 0;
                foreach ($off->targets as $target) {
                    $out[] = $target->target;
                    $tsum = $tsum + $target->target;
                }
                $out[] = $tsum;
                $format[] = $out;

                $progcess = FinancialProgress::whereHas('target', function ($q) use ($type) {
                    return $q->whereHas('schemehead', function ($query) use ($type) {
                        $query->whereHas('head', function ($qt) use ($type) {
                            $qt->where('type', $type);
                        });
                    });
                })->select('progress')->where(['ref_scheme_id' => $scheme_id, 'ref_financial_year_id' => $f_year, 'month' => $month, 'ref_office_id' => $off->id])->get();

                if ($progcess->isNotEmpty()) {
                    $out_new = [];
                    $sum = 0;
                    $out_new[] = '';
                    foreach ($progcess as $p) {
                        $sum = $sum + $p->progress;
                        $out_new[] = $p->progress;
                    }
                    $out_new[] = $sum;
                }
                $format[] = $out_new;
            }
            $head_wise_sum = FinancialTarget::whereHas('schemehead', function ($query) use ($type) {
                $query->whereHas('head', function ($qt) use ($type) {
                    $qt->where('type', $type);
                });
            })->select('mis_scheme_head_id', \DB::raw('sum(target) as  target_sum'))->where(['ref_scheme_id' => $scheme_id, 'ref_financial_year_id' => $f_year])->groupBy('mis_scheme_head_id')->get();
            if ($head_wise_sum) {
                $target_total = [];
                $target_total[] = 'Total';
                $hwsum = 0;
                foreach ($head_wise_sum as $h_sum) {
                    $target_total[] = $h_sum->target_sum;
                    $hwsum = $hwsum + $h_sum->target_sum;
                }
                $target_total[] = $hwsum;
                $format[] = $target_total;
            }
            $head_wise_progress_sum = FinancialProgress::whereHas('target', function ($q) use ($type) {
                return $q->whereHas('schemehead', function ($query) use ($type) {
                    $query->whereHas('head', function ($qt) use ($type) {
                        $qt->where('type', $type);
                    });
                });
            })->select(\DB::raw('sum(financial_office_progress.progress) as progress_sum'))
                ->Join('financial_office_target as t', 't.id', '=', 'financial_office_progress.financial_office_target_id')->where(['financial_office_progress.ref_scheme_id' => $scheme_id, 'financial_office_progress.ref_financial_year_id' => $f_year, 'financial_office_progress.month' => $month])
                ->groupBy('t.mis_scheme_head_id')
                ->get();

            if ($head_wise_progress_sum) {
                $progress_total = [];
                $progress_total[] = '';
                $hwpsum = 0;
                foreach ($head_wise_progress_sum as $h_sum) {
                    $progress_total[] = $h_sum->progress_sum;
                    $hwpsum = $hwpsum + $h_sum->progress_sum;
                }
                $progress_total[] = $hwpsum;
                $format[] = $progress_total;
            }

            return $format;
        } else {
            return false;
        }
    }
}

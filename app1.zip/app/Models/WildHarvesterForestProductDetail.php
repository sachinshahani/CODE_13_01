<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WildHarvesterForestProductDetail extends Model
{

    protected $table ='at_wh_forest_product_details';

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'area_under_cultivation',
        'forest_product_image',
        'organic_status',
        'updated_by',
        'updated_at',
        'at_wh_forest_details_id',
        'ref_product_id',
        'ref_hscode_id',
        'at_user_id',
        'type_of_the_forest_product',
        'name_of_the_forest_product',
        'created_at',

    ];


    public function getbyidproductname(){

        return $this->hasMany(RefProduct::class,'id','ref_product_id');
    }



    public function getwhClosingstock()
    {
        return $this->hasOne(AtClosingStock::class,'at_wh_forest_product_details_id','id');
    }

}

<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CBCategoryWiseRestriction extends Model
{

    use HasFactory;

    protected $table ='cb_category_wise_restriction';

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'id',
        'cb_id',
        'ref_eligible_category_id',
        'status',
        'updated_at',
        'updated_by',
        'created_at',
        'created_by',
        'deleted_at',
    ];

}

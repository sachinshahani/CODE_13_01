<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtBatchDetail extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'at_batch_details';

    protected $fillable = [
        'id',
        'at_user_id',
        'batch_id',
        'product_code',
        'product_name',
        'expiry_date',
        'total_quantity',
        'lot_created_date',
        'source_from',
        'created_at',
        'updated_at',
        'created_by',
        'updated_by',
        'deleted_at',
        'quantity_source'
    ];

    // protected $dates = ['deleted_at']; 

    public function user()
    {
        return $this->belongsTo(User::class, 'at_user_id', 'id');
    }


}

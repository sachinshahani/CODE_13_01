<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtClosingStock extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;
	use SoftDeletes;
    public $timestamps = true;
    protected $table = 'at_closing_stock';

    protected $guarded = [];
    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];


    public function getwhproducts()
    {
        return $this->hasOne(WildHarvesterForestProductDetail::class,'id','at_wh_forest_product_details_id');
    }

	public function getPurchaseDetails()
    {
        return $this->hasMany(AtPurchaseDetails::class,'at_closing_stock_id','id');
    }


	public function getFarmerStandingCorpDetail()
    {
        return $this->hasOne(AtFarmerStandingCorpDetail::class,'id','at_farmer_standing_crop_details_id');
    }

	public function IPDetailOfStandingCorp()
    {
        return $this->hasOne(IndividualProducerDetailOfStandingCorp::class,'id','at_ip_details_standing_crop_id');
    }


	/* public function getWHForestProductDetail()
    {
        return $this->hasOne(WildHarvesterForestProductDetail::class,'id','at_wh_forest_product_details_id');
    } */


}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtCbaApplicationDdetailForAamendment extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'at_cba_application_detail_for_amendment';

    protected $fillable = [
 
    'at_user_id',
    'existing_name',
    'amendment_name',
    'name_document_upload',
    'address',
    'address_document_upload',
    'operational_address',
    'operational_address_document_upload',
    'ref_block_tehsil_id',
    'block_document_upload',
    'ref_district_id',
    'district_document_upload',
    'ref_state_id',
    'state_document_upload',
    'pin',
    'pin_document_upload',
    'operational_pin',
    'operational_pin_document_upload',
    'logo_change',
    'logo_change_document_upload',
    'legal_status',
    'legal_status_document_upload',
    'supporting_document',
    'supporting_document_upload',
    'accreditation_existing_validity',
    'extended_accreditation_validity',
    'extended_accreditation_validity_document_upload',
    'remarks',
    
    ];
}

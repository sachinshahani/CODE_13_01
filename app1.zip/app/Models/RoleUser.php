<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class RoleUser extends Model
{
    use  HasFactory;
    

    protected $table = 'role_user';
    protected $primaryKey = 'user_id';
    public $incrementing = false;      // Since the table lacks an auto-incrementing primary key
    public $timestamps = false;

    protected $fillable = [
        'user_id',
        'role_id',
    ];

    public function users()
    {
        return $this->hasMany(User::class, 'id', 'user_id');
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SourceDetails extends Model
{
    use HasFactory;
    protected $table = 'at_source_details';
    //public $timestamps = false;

    protected $fillable = [

        'id',
        'at_user_id',
        'batch_id',
        'batchdetails_id',
        'tc_no',
        'used_quantity',
        'available_quantity',
        'quantity_source',
        'created_at',
        'deleted_at',

    ];
}

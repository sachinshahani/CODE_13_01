<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class InspectionChecklistIndividualFarmer extends Model
{
    public $timestamps = false;

    protected $table = 'at_inspection_checklist_individual_farmer';

    protected $fillable = [
        'id',
        'farmer_name',
        'farmer_code',
        'farmer_address',
        'total_area_ha',
        'ref_inspection_type_master_id',
        'inspector_name',
        'inspection_date',
        'latitude',
        'longitude',
        'operation_name',
        'land_offered_certification',
        'no_of_farms_plots',
        'last_prohibited_material_date',
        'registration_date_with_ics',
        'ref_production_type_id',
        'land_status',
        'sign_of_farmer_img',
        'sign_date_of_farmer',
        'sign_of_inspector_img',
        'sign_date_of_inspector',
        'name_of_ics_representative',
        'sign_of_ics_representative_img',
        'sign_date_of_ics_representative',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'overall_observation',
        'total_cultivable_land',
        'land_offer_for_certification',
        'c_one',
        'c_two',
        'c_three',
        'organic',        
        'any_nc_ofc_one',
        'any_nc_ofc_two',

        'warehouse_img',
        'stock_capacity',
        'stock_availability',
        'remarks',
        'operator_id',
        'inspector_id',
        'type_of_inspection_initial',
        'production_type',
        'selfie_with_contact_person',
    ];
}

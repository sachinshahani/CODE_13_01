<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AtApplicationRCAC extends Model
{
    use HasFactory;

    public $timestamps = false;

    protected $table = 'at_rcac_application_details';

    protected $fillable = [

        'id',
        'operator_type_id',
        'lc_type',
        'lc_no',
        'ptc_no',
        'registration_no',
        'exporter_name',
        'quota',
        'office',
        'product_category',
        'trade_notice_no',
        'hscode',
        'product_name',
        'product_status',
        'quantity',
        // 'lc_no',
        'validity_date',
        'remaining_qty',
        'applying_qty',
        'fob',
        'port_of_origin',
        'value',
        'cif_amount',
        'importer_name',
        'importer_address',
        'certificate_dispatch_by',
        'importer_country',
        'mode_of_payment',
        'declaration',
        'created_at',
        'created_by',
        'updated_on',
        'updated_by',
        'deleted_at',
        'paymentId',
        'ptId',
        'status',
        'paymentStatus'

    ];
}

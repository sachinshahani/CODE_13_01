<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtOrderDetailsReceivedFromBuyer extends Model
{
    use HasFactory;
	use SoftDeletes;

	protected $table ='at_order_details_received_from_buyer';

    public $timestamps = false;


    protected $fillable = [
        "at_purchase_request_id",
        "order_number",
        "quantity",
        "ref_product_id",
        "upload_copy_invoice",
        "copy_invoice_remaks",
        "order_validity",
        "invoice_number",
        "order_status",
		'created_at',
		'created_by',
		'updated_at',
		'updated_by',
		'deleted_at'
	];


    
   //at_order_details_received_from_buyer
   public function getOrderDetails()
   {
       return $this->hasOne(AtOrderAccepted::class,'at_order_details_received_from_buyer_id','id');
   }


}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtOpTransactionVsTransactionProduct extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable,SoftDeletes;
    protected $table = 'at_op_transaction_vs_transaction_product';
    protected $fillable = [
		'transaction_certificate_no',
        'tc_application_no',
        'requested_tc_no',
        'seller_scn',
        'farm_no',
        'total_qty',
        'tc_date',
        'operator_type',
        'quantity_for_tc',
        'rem_qty',
        'category_code',
        'product_code',
        'organic_status',
        'cn_code',
        'batch_no',
        'trade_name_of_product',
        'lab_test_report',
        'psc_report',
        'economic_part',
        'source_from',
        'farm_harvest_year',
        'nop_status',
        'qty_value',
        'currency_type_id',
        'total_value_currency_wise',
        'inr_rate',
        'eu_category',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
        'deleted_at',
        'value_inr',
        'at_purchase_request_id',
        'is_deleted',
        'deleted_at',
        'file_path',
        'batch_creation_id',
    ];


    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    public function getTransProductSource()
    {
        return $this->hasMany(AtOpTransactionProductSourced::class,'at_op_transaction_vs_transaction_product_id','id');
    }



}

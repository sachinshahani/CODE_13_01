<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class RefDistrict extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'ref_district';

    protected $fillable = ['id', 'district_code', 'district_name', 'ref_state_id', 'created_by', 'created_at', 'updated_at', 'updated_by', 'is_deleted', 'deleted_at'];
}

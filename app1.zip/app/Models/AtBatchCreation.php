<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtBatchCreation extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'at_batch_creation';

    protected $guarded = [];

    // protected $dates = ['deleted_at'];

    public function user()
    {
        return $this->belongsTo(User::class, 'at_user_id', 'id');
    }

    public function batchDetails()
    {
        return $this->hasMany(AtBatchDetail::class, 'batch_id', 'id');
    }
    public function sourceDetails(){

        return $this->hasMany(SourceDetails::class, 'batch_id', 'id');
    }


}

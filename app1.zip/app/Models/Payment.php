<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    use HasFactory;

    protected $table ='at_payments';


    protected $fillable = [
        'orderId',
        'serviceId',
        'amount',
        'paymentMode',
        'trackId',
        'result',
        'errorCode',
        'errorDescription',
        'paymentId',
        'currency',
        'rcId',
    ];
}


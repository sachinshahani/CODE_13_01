<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtExternalInspectionObservation extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable,SoftDeletes;
    protected $table = 'at_external_inspection_observation';
    protected $fillable = [
		"at_external_inspection_id",
		"description_of_observation",
		"grade",
		"corrective_date",
		"closure_date",
		"closure_remark",
        "status",
		"created_by",
		"updated_at",
		"updated_by",
		"created_at",
		"deleted_at"
		
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
 

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
 
}

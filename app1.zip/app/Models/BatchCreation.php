<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BatchCreation extends Model
{
    use HasFactory;

    protected $table = 'at_batch_creation';

    public $timestamps = false;

    protected $fillable = [
        'scope_certificate_no',
        'unit_name',
        'hs_code',
        'product',
        'organic_status',
        'quantity',
        'percentage',
        'processing_date',
        'expiry_date',
        'by_product',
        'created_at',
        'updated_at',
        'created_by',
        'updated_by',
        'at_user_id',
        'batch_id',
        'total_quantity',
        'lot_created_date',
        'source_from',
        

    ];
}

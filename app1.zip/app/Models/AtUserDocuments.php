<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class AtUserDocuments extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;
    protected $table = 'at_user_documents';
    protected $fillable = [
        'at_user_id',
        'at_user_registration_details_id',
        'ref_document_id',
        'legal_doc_upload',
        'office_building_photo',
        'address_proof_of_office',
        'address_proof_of_office_doc',
        'registration_certificate',
        'signature',
        'contact_person_photo',
        'ayush_doc_path',
        'forest_doc_path',
        'icode_attachment',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'is_deleted',
        'deleted_at',
        'is_migrated',
        'hindi_registration_certificate',
    ];
}
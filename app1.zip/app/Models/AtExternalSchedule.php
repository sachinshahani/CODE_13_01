<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AtExternalSchedule extends Model
{
    use HasFactory;

    protected $table = 'at_external_schedule';
    protected $fillable = [
		"id",
		"at_user_id",
		"submission_of_inspection_report",
		"inspection_date",
		"inspector_contact",
		"created_at",
		"updated_at",
		"inspector_name",
		"created_by",
		"operator_type",
		"operator_name",
		"operator_mobile",
        "operator_email",
		"reg_no",
		"operator_type_id",
		"status",
		"sampling_status",
		"operator_address",
		"approve",
		"remarks"
	

    ];


}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AtProProcessingUnit extends Model
{
    use HasFactory;

    protected $table = 'at_pro_processing_unit';

    protected $fillable = [
        
        'at_user_id',
        'number_of_processing_unit',
        'reg_agency_name',
        'processing_unit_id',
        'processing_units_name',
        'fssai_license_number',
        'license_document',
        'license_validity_from',
        'license_validity_to',
        'no_of_processing_lines',
        'agreement_status',
        'number_of_product',
        'additional_certificate',
        'geo_tagging_processing_unit',
        'address',
        'ref_state_id',
        'ref_district_id',
        'ref_block_tehsil_id',
        'ref_village_id',
        'pin_code',
        'reflect_farm',
        'image_after_tagging',
        'installed_capacity_under_organic',
        'daily_processing_capacity',
        'processing_type',
        'processing_unit_image',
        'created_by',
        'updated_at',
        'updated_by',
        'approval_flag',
        'approved_by',
        'is_deleted',
        'deleted_at',
        'created_at',

        
    ];


    public function user()
    {
        return $this->belongsTo(User::class, 'at_user_id', 'id');
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtInspectionNonConformity extends Model
{
    use HasFactory, SoftDeletes;

    public $timestamps = false;

    protected $table = 'at_inspection_non_conformity';

    protected $fillable = [
        'id',
        'at_farmer_reg_details_id',
        'at_farmer_inspection_details_id',
        'grade',
        'description',
        'submission_date_corrective_action',
        'created_by',
        'updated_at',
        'updated_by',
        'deleted_at',
        'at_inspector_id',
        'inspection_status'
        
    ];
}

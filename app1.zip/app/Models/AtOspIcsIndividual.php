<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class AtOspIcsIndividual extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;
    protected $table = 'at_osp_ics_individual';
    protected $fillable = [
        "at_farmer_reg_details_id",
        "source_of_organic_system_plan",
        "cropping_pattern",
        "covered_area_main_corp",
        "covered_area_inter_corp",
        "off_farm",
        "on_farm",
        "contamination_control",
        "pease_weed_management",
        "nutrient_management",
        "created_at",
        "updated_at",
        "created_by"
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
 

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
 
}

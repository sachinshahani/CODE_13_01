<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AtInspectionProcessorProduct extends Model
{
    use HasFactory;

    protected $table = 'at_inspection_processor_product_report';

    protected $fillable = [
        'at_inspection_processor_report_id',
        'product_name',
        'trade_name',
        'ingredients_list',
        'source_of_ingredients',
        'imported_ingredient_name',
        'quantity_imported',
        'country_of_origin',
        'certification_details',
        'composition_percentage',
        'process_flow',
        'test_reports',
        'reason_for_imported_ingredient',
        'additional_observations',
        'created_at',
        'created_by',
        'updated_by',
        'updated_at'
    ];




}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class UserWarehouseManagerOfficers extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;
    protected $table = 'at_ics_warehouse_manager_details';
    protected $fillable = [
        'at_ics_warehouse_details_id',
        'at_user_id',
        'first_name',
        'middle_name',
        'last_name',
        'email_id',
        'ref_document_id',
        'aadhar_card_number',
        'contact_number',
        'status',
        'user_type',     //WM=Warehouse Manager,PM=Purchase Manager,FO=Field Officers,AM=Approval Manager 
        'created_at',        
        'created_by',
        'updated_at',
        'updated_by',
        'is_deleted',
        'no_field_officer',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
 

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
 
}

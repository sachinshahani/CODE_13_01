<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Zone extends Model
{
    use HasFactory;

    public $timestamps = false;

    protected $table = 'ref_zone';

    protected $fillable = ['id', 'ref_member_id', 'zone_id', 'zone_code', 'zone_name', 'zone_description', 'ref_status_id', 'state_ut', 'state_unit_office', 'divisional_office', 'laboratory', 'created_at', 'created_by', 'updated_at', 'updated_by', 'is_deleted'];
}

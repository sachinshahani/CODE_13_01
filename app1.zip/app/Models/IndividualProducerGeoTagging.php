<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class IndividualProducerGeoTagging extends Model
{

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $table = "at_ip_geo_tagging_details";

    protected $fillable = [
        'at_user_id',
        'at_ip_farmer_reg_details_id',
        'at_ip_farm_details_id',
        'at_ip_details_standing_crop_id',
        'geo_tagging_of_farm',
        'total_area_of_farm',
        'under_organic_cultivation',
        'latitude',
        'longitude',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
    ];


    

}

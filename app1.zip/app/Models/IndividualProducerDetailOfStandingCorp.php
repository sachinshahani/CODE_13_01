<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class IndividualProducerDetailOfStandingCorp extends Model
{

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $table = 'at_ip_details_standing_crop';

    protected $fillable = [
        'at_ip_farm_details_id',
        'ref_hscode_id',
        'at_user_id',
        'name_of_corp',
        'ref_operator_type_id',
        'season_name',
        'area',
        'crop_photo',
        'organic_status',
        'created_at',
        'updated_at',
        'geotag_photo'
    ];


    public function getClosingstock()
    {
        return $this->hasOne(AtClosingStock::class,'at_ip_details_standing_crop_id','id');
    }



}

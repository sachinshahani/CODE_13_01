<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RefDesignation extends Model
{
    use HasFactory;

    protected $table = 'ref_designation_master';

    protected $fillable = ['id', 'designation_name', 'employee_type', 'created_at', 'created_by', 'updated_at',  'updated_by',];

}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserVerification extends Model
{
    use HasFactory;

    public $timestamps = false;

    protected $table = 'user_verification';

    protected $fillable = ['mobile_no','otp','verify_status','otp_count','valid_otp_count','created_on','updated_on','deleted_at'];
}


<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class RefState extends Model
{
    use HasFactory, SoftDeletes;

    public $timestamps = false;

    protected $table = 'ref_state';

    protected $fillable = [
        'id',
        'state_code',
        'state_short_name',
        'state_name',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'is_deleted',
        'deleted_at'
    ];
}

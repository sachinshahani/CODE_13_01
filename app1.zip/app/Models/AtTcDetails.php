<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AtTcDetails extends Model
{
    use HasFactory;


    protected $table = 'at_tc_details';

    protected $fillable = [
 
    'id',
    'tc_no',
    'product',
    'available_quantity',
    'quantity_source',
    'created_at',
    'updated_at',
    'created_by',
    'updated_by',
    
    ];
}

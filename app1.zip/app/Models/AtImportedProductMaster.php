<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
// use Laravel\Sanctum\HasApiTokens;
use Laravel\Passport\HasApiTokens;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtImportedProductMaster extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes;
    protected $table = 'at_imported_product_master';
    protected $fillable = [
        'at_user_id',
        'ref_operator_type_id',
        'application_no',
        'scope_certificate_no',
        'bill_of_entry_no',
        'bill_of_entry_date',
        'ref_country_master_id',
        'exporter_name',
        'nop_certificate_no',
        'nop_certified_by',
        'forward_to_cb',
        'is_approved',
        'is_rejected',
        'approved_on',
        'approved_by',
        'remarks',
        'bill_of_entry_file',
        'exporter_certification_details_issued_by_exporting_country',
        'contract_invoice_of_operator_with_exporter',
        'inspection_date',
        'inspected_by',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
        'deleted_at'
        
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    public function importProductDetails()
    {
        return $this->hasMany(AtImportedProductDetails::class,'at_imported_product_master_id','id');
    }
    

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */

}

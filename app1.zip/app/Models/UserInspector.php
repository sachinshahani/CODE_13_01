<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
// use Laravel\Sanctum\HasApiTokens;
use Laravel\Passport\HasApiTokens;
use Illuminate\Database\Eloquent\SoftDeletes;

class UserInspector extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes;
    protected $table = 'at_ics_inspector_details';
    protected $fillable = [
        'at_user_id',
        'ref_operator_type_id',
        'name_of_inspector',
        'gender',
        'mobile_no',
        'address',
        'ref_state_id',
        'ref_district_id',
        'ref_block_tehsil_id',
        'ref_village_id',
        'pin',
        'ref_document_id',
        'inspector_photo',
        'appointment_letter',
        'id_proof',
        'id_proof_doc',
        'address_proof_of_office_doc',
        'address_proof_of_office',
        'profile_photo',
        'appointment_doc',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
        'deleted_at',
        'email',
        'password',
        'qualification',
        'aadhaar_no'
        
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    public function farmersRegSchedule()
    {
        return $this->hasOne(FarmersRegSchedule::class,'at_ics_inspector_details_id','id');
    }
    public function farmersInspSchedule()
    {
        return $this->hasOne(InspectionSchedule::class,'at_ics_inspector_details_id','id');
    }
    public function getRegisteredfarmers()
    {
       return $this->hasMany(AtFarmerRegDetail::class,'at_ics_inspector_id','id')->with('getFarmerFarms');
    }
	
	 

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */

}

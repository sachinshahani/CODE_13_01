<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtOpTransactionProductSourced extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable,SoftDeletes;
    protected $table = 'at_op_transaction_product_sourced';
    protected $fillable = [
		'at_op_transaction_vs_transaction_product_id',
        'tc_applicatio_no',
        'seller_scn',
        'registration_no',
        'ref_product_id',
        'at_closing_stock_id',
        'at_purchase_details_id',
        'organic_status',
        'economic_part_sourced_for',
        'product_code',
        'harvest_year',
        'qty_in_mt',
        'source_date',
        'receipt_number',
        'transaction_certificate_no',
        'source_flag',
        'economic_part',
        'source_from',
        'value',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
        'deleted_at',
        'quantity_source',
        'available_quantity',
    ];

    
    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
 
}

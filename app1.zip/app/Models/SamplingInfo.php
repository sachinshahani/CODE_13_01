<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Passport\HasApiTokens;
use Illuminate\Database\Eloquent\SoftDeletes;

class SamplingInfo extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes;

    protected $dates = [
        'deleted_at'
    ];

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $table = 'sampling_info';
    protected $fillable = [
       'id',
		'client_no',
	   'sampling_date',
	   'client_name',
	   'product_name',
	   'ref_product_kind_id',
	   'ref_crop_stage_id',
	   'sample_packed_in',
	   'sample_weight',
	   'prd',
	   'prc',
	   'lot_number',
	   'farm',
	   'storage_location',
	   'sample_location_sketch',
	   'seal_numbers',
	   'inspector_name',
	   'witness_name',
	   'declaration',
	   'witness_signature_doc',
	   'operator_signature_doc',
	   'inspector_signature_doc',
	   'date_witnessed',
	   'date_operator_signed',
	   'date_inspector_signed',
	   'at_user_id',
	   'ref_operator_type_id',
	     'created_at',
        'updated_at',
       
    ];

}

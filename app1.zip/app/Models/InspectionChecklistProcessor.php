<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class InspectionChecklistProcessor extends Model
{
    public $timestamps = false;

    protected $table = 'at_inspection_checklist_processor';

    protected $fillable = [
        'id',
        'processor_name',
        'processor_code',
        'processing_unit_address',
        'related_activities_processing_unit',
        'additional_site_address',
        'related_activities_additional_site',
        'ref_inspection_type_id',
        'inspection_date',
        'inspector_name',
        'inspection_time',
        'latitude',
        'longitude',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'sign_processor_img',
        'sign_processor_date',
        'sign_inspector_img',
        'sign_inspector_date',
        'warehouse_img',
        'stock_capacity',
        'stock_availability',
        'remarks',
        'selfie_with_contact_person',
        'operator_id'
    ];
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class AtFarmerLandDetail extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;
    protected $table = 'at_farm_details';
    protected $fillable = [
        "at_farmer_reg_details_id",
        "registration_no",
        "owner_farmerid",
        "farm_name",
        "landmark",
        "pin",
        "farm_no",
        "area_in_ha",
        "total_area",
        "survay_no",
        "no_of_plot",
        "latitude",
        "logititude",
        "ref_state_id",
        "ref_district_id",
        "ref_block_tehsil_id",
        "ref_village_id",
        "farm_processing",
        "completed_three_years_pgs",
        "pgs_certificate",
        "created_at",
        "created_by",
        "approved_remark",
        "cancellation_flag",
        "approval_flag",
        "approved_by",
        "approved_date",
        "active_flag",
        "amend_remark",
        "ref_organic_status_master_id",
        "area_organic_cultivation",
        "noc_no",
        "noc_status",
        "noc_date",
        "is_upgraded",
        "updated_at",
        "updated_by",
        "cb_remarks",
        "cancelled_by",
        "cancellation_on",
        "remarks",
        "farmer_dairy",
        "near_by"
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
 

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    public function getFarmsStandingCrop()
    {
        return $this->hasMany(AtFarmerStandingCorpDetail::class,'at_farm_details_id','at_farmer_reg_details_id');
    }
 
}

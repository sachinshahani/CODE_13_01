<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class InspectionChecklistWildCollectionHarvest extends Model
{
    public $timestamps = false;

    protected $table = 'at_inspection_checklist_wild_collection_harvest';

    protected $fillable = [
        'id',
        'operator_id',
        'wild_collector_name',
        'tracenet_code',
        'authorized_person_name',
        'inspection_officer_name',
        'wild_collector_address',
        'inspection_date',
        'forest_division_description',
        'inspection_time',
        'permission_letter_from_forest_dept',
        'signature_of_wild_collector',
        'warehouse_img',
        'signature_date_wild_collector',
        'signature_of_inspector',
        'name_of_inspector',
        'signature_date_inspector',
        'name_of_wild_harvester',
        'stock_capacity',
        'stock_availability',
        'selfie_with_contact_person',
        'remarks',
        'inspector_id',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at'
    ];
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PpInspectionChecklistCropDetails extends Model
{
    public $timestamps = false;

    protected $table = 'at_ip_inspection_checklist_crop_details';

    protected $fillable = [
        'id',
        'inspection_checklist_id',
        'crop_name',
        'season',
        'status',
        'main_or_intercrop',
        'area_ha',
        'estimated_yield_mt',
        'landscape',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at'
    ];
}

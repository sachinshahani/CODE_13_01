<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ProcessorDocument extends Model
{
    use HasFactory;
	use SoftDeletes;
  
	protected $table ='at_pro_documents_list';

    public $timestamps = false;
 

    protected $fillable = [
		'at_user_id', 	 
		'aadhar_card_image_path',
		'pan_card_image_path',
		'land_documents_image_path',
		'passbook_image_path',
		'contact_person_sign_image_path',	
		'live_signature_image_path',	
		'created_at', 
		'created_by', 
		'updated_at', 
		'updated_by', 
		'deleted_at'
	];
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class CertificateStandardDetail extends Model
{
    use  HasFactory;

    protected $table = 'at_op_certificate_standard_details';
    protected $fillable = [
        "at_user_id",
		"ref_operator_type_id",
		"standard_type",
		"accreditation_agency_no",
		"accreditation_agency_name",
		"scope_certificate_no",
		"scope_for",
		"is_renewed",
		"validity_start_date",
		"validity_end_date",
		"barcode",
		"file_name",
		"remarks",
		"created_at",
		"created_by",
		"updated_at",
		"updated_by",
		"deleted_at",
		"status"
    ];

    function getuser(){
        return $this->belongsTo(User::class,'at_user_id','id');
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AtCbaPaymentDetail extends Model
{
    use HasFactory;

    protected $table = 'at_cba_payment_details';

    protected $fillable = [
 
     'at_accrediation_certificationbody_master_id',
     'application_no',
     'payment_mode',
     'bank_name',
     'application_fee',
     'tax',
     'total_amount',
     'transaction_no',
     'invoice_no',
     'payment_date',
     'description',
     'transaction_status',
     'application_type',
     'transaction_type'
     
 
    ];

}

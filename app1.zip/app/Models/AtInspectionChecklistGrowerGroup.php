<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtInspectionChecklistGrowerGroup extends Model
{
    public $timestamps = false;

    protected $table = 'at_inspection_checklist_grower_group';

    protected $fillable = [
        'id',
        'grower_group_name',
        'grower_group_address',
        'authorized_representative_name',
        'ics_manager_contact_details',
        'mobile_no_ics_manager',
        'grower_group_email',
        'registration_number',
        'ics_address',
        'ics_managed_by',
        'service_provider_name',
        'service_provider_address',
        'ref_inspection_type_id',
        'grower_group_status',
        'inspection_date_from',
        'inspection_date_to',
        'team_leader_name',
        'team_members_names',
        'authorized_signatory_name',
        'number_of_farmers',
        'total_area_ha',
        'any_change_in_farmers',
        'number_of_new_farmers_added',
        'observations_on_new_farmers',
        'any_change_in_area',
        'new_area_added',
        'total_area_offered_for_certification',
        'crop_season',
        'intercrops_buffer_crop_cover_crop',
        'crop_area_ha',
        'estimated_yield_mt',
        'crop_status',
        'perennial_plant_name',
        'number_of_plants',
        'age_of_plant',
        'planting_year',
        'estimated_yield_perennial_mt',
        'perennial_plant_status',
        'overall_observations',
        'declaration_text',
        'client_declaration_signature',
        'inspector_declaration_signature',
        'authorized_person_name',
        'inspector_name',
        'declaration_date',
        'declaration_place',
        'selfie_with_contact_person',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'at_external_schedule_id'
    ];
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtRiskAssessment extends Model
{
    use HasFactory, SoftDeletes;

    public $timestamps = false;

    protected $table = 'at_risk_assessment';

    protected $fillable = [
        'id',
        'at_user_id',
        'size_of_holding',
        'no_of_member',
        'similarity_between_prod_vs_crop',
        'inter_mingling',
        'parallel_production',
        'split_production',
        'local_hazards',
        'change_production_plan',
        'joining_member',
        'risk_type',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'deleted_at'
    ];
}



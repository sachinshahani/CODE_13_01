<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AtBankDetails extends Model
{
    use HasFactory;

    protected $table = 'at_bank_details';

    protected $fillable = [
        'id',
        'ref_bank_id',
        'at_user_id',
        'ref_operator_type_id',
        'account_number',
        'ifsc_code',
        'branch_name',
        'bank_address',
        'pincode',
        'farmer_photo',
        'updated_at',
        'created_at',
        'deleted_at',
        
    ];



}

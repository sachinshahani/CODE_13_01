<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use App\Models\RefModule;


class AtCBRegistrationPermission extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;
    protected $table = 'at_cb_registration_permission';
    protected $guarded = [];
    // protected $dates = ['created_at','updated_at','deleted_at']; 
    // protected $fillable = [
    //     'id',
    //     'cb_id',
    //     'module_id',
    //     'sub_module_id',
    //     'remarks',
    //     'created_at',
    //     'created_by',
    //     'updated_at',
    //     'updated_by',
    //     'deleted_at'
    // ];


    public function getsubmenu()
    {
        return $this->hasMany(RefModule::class,'id','module_id');
    }
 
 
}

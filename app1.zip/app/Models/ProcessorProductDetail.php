<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ProcessorProductDetail extends Model
{
    use HasFactory;
	use SoftDeletes;

    public $timestamps = false;
  
	protected $table ='at_pro_products_details';

    protected $fillable = [
		'at_user_id', 
		'at_pro_processing_unit_id', 
		'processing_unit_id', 
		'ref_hscode_id',	
		'ref_product_id',
		'product_processor_name',
		'organic_status',
		'product_image',
		'product_description',
		'created_at', 
		'created_by', 
		'updated_at', 
		'updated_by', 
		'is_deleted',
		'deleted_at',
		'ref_category_id'
	];
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Passport\HasApiTokens;
use Illuminate\Database\Eloquent\SoftDeletes;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes;

    protected $dates = [
        'deleted_at'
    ];

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $table = 'at_user';
    protected $fillable = [
        'ref_operator_type_id',
        'operator_name',
        'first_name',
        'employee_id',
        'employee_type',
        'join_date',
        'total_experience',
        'training',
        'upload_biodata',
        'middle_name',
        'last_name',
        'mobile_no',
        'dob_doi_date',
        'email',
        'address',
        'document_type',
        'legal_doc_upload',
        'no_of_farmers',
        'no_of_inspector',
        'ref_village_id',
        'ref_village_id',
        'ref_block_tehsil_id',
        'ref_district_id',
        'ref_state_id',
        'pin',
        'gender',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'is_deleted',
        'user_name',
        'password',
        'user_type',
        'deleted_at',
        'status',
        'resourse_type',
        'din',
        'pan',
        'contact_person_first_name',
        'contact_person_middle_name',
        'contact_person_last_name',
        'contact_person_mobile_number',
        'contact_person_gender',
        'contact_person_pan_number',
        'contact_person_aadhar_number',
        'contact_person_person_photo',
        'contact_person_email',
        'date_of_registration',
        'processor_photo',
        'processor_state_id',
        'processor_district_id',
        'processor_block_tehsil_id',
        'processor_village_id',
        'processor_pin',
        'processor_address',
        'no_of_collectors',
        'legal_document_number',
        'office_building_photo',
        'risk_assessment',
        'external_inspection',
        'internal_inspection',
        'address_proof_of_office',
        'address_proof_of_office_doc',
        'cb_reg_ramerks',
        'standerd_type',
        'contact_designation',
        'entity_firm',
        'contact_gender',
        'aadhar_number',
        'designation',
        'qualification',
        'remark',
        'registration_no',
        'login_status',
        'registration_certificate',
        'address_2',
        'fax',
        'application_type',
        'office_phone_number',
        'website_address',
        'legal_status',
        'year_of_establishment',
        'date_of_establishment',
        'gst_no',
        'country',
        'descriptions',
        'signature',
        'last_login_ip',
        'operator_pan',
        'lab_id',
        'fssai_licence',
        'ayush_licence',
        'ayush_validity',
        'ayush_doc_path',
        'iecode',
        'forest_licence',
        'forest_doc_path',
        'fssai_doc_path',
        'fssai_validity',
        'at_expire',
        'entity_firm',
        'father_name',
        'failed_attempt',
        'account_locked',
        'account_locked_on',
        'emStatus', 
        'eSignType', 
        'emUserId', 
        'emName', 
        'eSignReason', 
        'eSignLocation', 
        'eSignStaticLocation', 
        'eSignModuleAllow', 
        'eSignUpdated_by', 
        'eSignUpdated_at', 
        'eSignCreated_at',

    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    // public function icsusers()
    // {
    //     return $this->belongsToMany(Role::class)->where('id', 2);
    // }
    public function roles()
    {
        return $this->belongsToMany(Role::class);
    }


    // public function getRoleNames()
    // {
    //     return $this->hasOne(Role::class,'user_id','id');
    // }
    public function role()
    {
        return $this->hasOne(RoleUser::class, 'user_id', 'id');
    }

    public function TraderMoreDetail()
    {
        return $this->hasOne(TradersBasicDetail::class, 'at_user_id', 'id');
    }

    public function GeoTaggingWarehouseDetail()
    {
        return $this->hasMany(GeoTaggingWarehouseDetail::class, 'at_user_id', 'id');
    }

    public function TradersProductDetails()
    {
        return $this->hasMany(TradersProductDetail::class, 'at_user_id', 'id');
    }

    public function TradersDocuments()
    {
        return $this->hasOne(TradersDocument::class, 'at_user_id', 'id');
    }

    public function ProcessorMoreDetail()
    {
        return $this->hasOne(ProcessorBasicDetail::class, 'at_user_id', 'id');
    }
    public function GeoTaggingProcessorDetail()
    {
        return $this->hasMany(GeoTaggingProcessorDetail::class, 'at_user_id', 'id');
    }
    public function ProcessorProductDetails()
    {
        return $this->hasMany(ProcessorProductDetail::class, 'at_user_id', 'id');
    }

    public function ProcessorDocuments()
    {
        return $this->hasOne(ProcessorDocument::class, 'at_user_id', 'id');
    }


    public function getWildHarvesterDetail()
    {
        return $this->hasOne(WildHarvesterDetail::class, 'at_user_id', 'id');
    }


    public function getPermittedForestAreaDetail()
    {
        return $this->hasOne(WildHarvesterPermittedForestAreaDetail::class, 'at_user_id', 'id');
    }


    public function getForestProductDetail()
    {
        return $this->hasOne(WildHarvesterForestProductDetail::class, 'at_user_id', 'id');
    }


    public function getWildHarvesterDocument()
    {
        return $this->hasOne(WildHarvesterDocument::class, 'at_user_id', 'id');
    }

    public function bankDetails()
    {
        return $this->hasOne(WildHarvesterBankDetail::class, 'at_user_id', 'id');
    }

    public function appliedScope()
    {
        return $this->hasOne(CertificateStandardDetail::class, 'at_user_id', 'id');
    }

    public function certificateStandardDetails()
    {
        return $this->hasMany(AtOpCertificateStandardDetail::class, 'at_user_id', 'id');
    }

    public function operatorType()
    {
        return $this->belongsTo(RefOperatorType::class, 'ref_operator_type_id', 'id');
    }

    public function farmersRegSchedule()
    {
        return $this->hasOne(FarmersRegSchedule::class,'at_user_id','id');
    }
    function users(){
        return $this->hasMany(User::class,'id','user_id');
    }

    public function ProProcessingdDetails()
    {
        return $this->hasOne(AtProProcessingUnit::class, 'at_user_id', 'id');
    }
    public function getUserInspector()
    {
        return $this->hasMany(UserInspector::class, 'at_user_id', 'id');
    }



}

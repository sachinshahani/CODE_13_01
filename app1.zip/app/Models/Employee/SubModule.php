<?php

namespace App\Models\Employee;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SubModule extends Model
{
    use HasFactory;

    protected $table = 'sub_module';

    protected $fillable = ['module_id', 'sub_module_name', 'module_path', 'created_by', 'updated_by'];

    // Relationship to Module
    public function module()
    {
        return $this->belongsTo(Module::class, 'module_id');
    }

    public function employeeModules()
    {
        return $this->hasMany(EmployeeModule::class, 'sub_module_id');
    }
}

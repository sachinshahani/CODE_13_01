<?php

namespace App\Models\Employee;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Employee\Module;

class EmployeeModule extends Model
{
    use HasFactory;

    protected $table = 'employee_module';

    // Fields that can be mass-assigned
    protected $fillable = ['emp_id', 'sub_module', 'status', 'remark', 'created_by', 'updated_by'];

    // Relationship to Module
    public function module()
    {
        return $this->belongsTo(Module::class, 'module_id');
    }

    // Relationship to SubModule
    public function subModule()
    {
        return $this->belongsTo(SubModule::class, 'sub_module_id');
    }

    public function moduleMappings()
    {
        return $this->hasMany(ModuleMapping::class, 'emp_id', 'emp_id'); // Relate using emp_id
    }


    // Relationship to Employee (assuming there's an Employee model)

    public function user()
    {
        return $this->belongsTo(\App\Models\User::class, 'emp_id');
    }
}

<?php

namespace App\Models\Employee;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ModuleMapping extends Model
{
    use HasFactory;

    protected $table = 'module_mapping';

    // protected $guarded = ['id'];

    // Add the attributes that are mass assignable
    protected $fillable = [
        'emp_id',
        'module_id',
        'sub_module_id',
        // Add other fields that you want to allow for mass assignment
    ];


    // No timestamps for this table (since they aren't mentioned in the structure)
    public $timestamps = false;

    // Relationship to EmployeeModule
    public function employeeModule()
    {
        return $this->belongsTo(EmployeeModule::class, 'emp_id');
    }

    // Relationship to Module
    public function module()
    {
        return $this->belongsTo(Module::class, 'module_id');
    }

    // Relationship to SubModule
    public function subModule()
    {
        return $this->belongsTo(SubModule::class, 'sub_module_id');
    }
}

<?php

namespace App\Models\Employee;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Module extends Model
{
    use HasFactory;

    protected $table = 'module';

    protected $fillable = ['module_name', 'created_by', 'updated_by'];

    public function employeeModules()
    {
        return $this->hasMany(EmployeeModule::class, 'module_id');
    }

    // Relationship to SubModule
    public function subModules()
    {
        return $this->hasMany(SubModule::class, 'module_id');
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Notification extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'notification';

    protected $fillable = [
        "notification_message",
        "receiver_id",
        "receiver_status",
        "created_at",
        "created_by",
        "updated_at",
        "updated_by",
	    ];
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtInspectionApprovalInternalInspector extends Model
{
    use HasFactory, SoftDeletes;

    public $timestamps = false;

    protected $table = 'at_inspection_approval_internal_inspector';

    protected $fillable = [
        'id',
        'at_farmer_reg_details_id',
        'at_ics_inspector_details_id',
        'compliance_with_previous_conditions',
        'compliance_this_year',
        'comments_by_internal_inspector',
        'created_by',
        'updated_at',
        'updated_by',
        'deleted_at',
        'inspection_status',
        'farmer_signature',
        'inspector_signature'
        
    ];
}

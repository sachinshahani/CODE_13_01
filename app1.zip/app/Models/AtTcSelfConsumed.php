<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class  AtTcSelfConsumed extends Model
{
    use HasFactory, SoftDeletes;


    protected $table = 'at_tc_self_consumed';

    protected $fillable = [
 
    'id',
    'transaction_certificate_no',
    'at_op_transaction_certificate_entry_id',
    'ref_product_id',
    'ref_organic_status_master_id',
    'at_purchase_details_id',
    'at_op_transaction_product_sourced_id',
    'at_closing_stock_id',
    'self_qty_consumed',
    'remark',
    'created_at',
    'updated_at',
    'created_by',
    'updated_by',
    'is_read'
    ];
}

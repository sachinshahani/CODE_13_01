<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Laravel\Passport\HasApiTokens;
use Illuminate\Database\Eloquent\SoftDeletes;

class eMSignerCertificateModal extends Model
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes;


    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $table = 'at_emsigner_signature';
    protected $fillable = [
        'ref_operator_type_id',
        'at_user_id',
        'filename',
        'filePath',
        'fileFolder',
        'moduleName',
        'eSignType',
        'emUserId',
        'emName',
        'eSignReason',
        'eSignLocation',
        'transactionId',
        'signedPath',
        'signedStatus',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'is_deleted',
        'preSignedTempFile',
        'responseCode',
        'gatewayParamResponseCode',
        'gatewayTransactionResponseCode',
        'getSignedPdfResponseCode',
    ];
    // If your primary key or timestamps differ, define them
    protected $primaryKey = 'id';
    public $timestamps = true;

    // Override the query to handle case-sensitive column names
    public function getTransactionIdAttribute($value)
    {
        return $this->attributes['"transactionId"'];
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class IndividualProducerDetailOfProposedCorp extends Model
{

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $table = 'at_ip_details_proposed_crop';

    protected $fillable = [
        'at_ip_farm_details_id',
        'details_name_of_corp',
        'ref_hscode_id',
        'at_user_id',
        'ref_operator_type_id',
        'season_name',
        'area',
        'organic_status',
        'updated_at',
        'created_at',
    ];

    public function getFramsDetails(){
        return $this->hasMany(IndividualProducerFarmDetail::class, 'id', 'at_ip_farm_details_id');
    }
}

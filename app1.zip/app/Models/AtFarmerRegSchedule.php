<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AtFarmerRegSchedule extends Model
{
    use HasFactory;
    protected $table = 'at_farmers_reg_schedule';
    protected $fillable = [
		"id",
        "at_ics_inspector_details_id",
		"at_user_id",
		"schedule_period_from",
		"schedule_period_to",
		"number_of_farmer_reg",
		"address",
		"ref_state_id",
		"ref_district_id",
		"ref_block_tehsil_id",
		"ref_village_id",
		"pin",
		"created_at",
		"created_by",
		"updated_at",
		"updated_by",
		"deleted_at",
		"total_attempt",
		"status",
		

    ];
}

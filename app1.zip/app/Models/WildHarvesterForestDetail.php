<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WildHarvesterForestDetail extends Model
{

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'user_id',
        'area_in_hectars',
        'forest_permit_number',
        'forest_permit_number_up_to',
        'state',
        'circle',
        'division',
        'sub_division',
        'range',
        'sub_range',
        'beat',
        'compartment_no',
        'latitude',
        'longitude',
        'created_at',
        'updated_at',
    ];

}

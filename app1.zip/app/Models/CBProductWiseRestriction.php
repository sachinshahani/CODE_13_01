<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CBProductWiseRestriction extends Model
{
    use HasFactory;

    protected $table = 'cb_product_wise_restriction';

    protected $fillable = [
		'id',
		'cb_id',
		'ref_product_id',
		'hs_code',
		'status',
		'created_by',
		'created_at',
		'updated_by',
		'updated_at',
		'deleted_at',
	    ];
}

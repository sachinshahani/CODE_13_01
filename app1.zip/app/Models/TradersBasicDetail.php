<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Auth;

class TradersBasicDetail extends Model
{
    use HasFactory;
    use SoftDeletes;
	
	protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];
	/**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'ref_user_id',         
        'trader_photo',
        'contact_person_name',
        'contact_person_gender',
        'contact_person_address',
        'contact_person_state',
        'contact_person_district',
        'contact_person_taluka_mandal',
        'contact_person_village',
        'contact_person_pincode',
        'contact_person_mobile',
        'contact_person_email',
        'contact_person_photo',
        'pan_number',
        'aadhar_number',
        'bank_name',
        'account_number',
        'ifsc_code',
		'branch_name',
		'address',
		'pincode',
		'created_at',
        'updated_at',
        'deleted_at',
        'created_by',
    ];
	
	public static function boot()
     {
        parent::boot();
        static::creating(function($model)
        {
            $user = Auth::user();          
            $model->created_by = $user->id;
             
        });
        static::updating(function($model)
        {
            $user = Auth::user();
            $model->updated_by = $user->id;
        });      
    }







}
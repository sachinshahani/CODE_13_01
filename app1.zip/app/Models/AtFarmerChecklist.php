<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtFarmerChecklist extends Model
{
    use HasFactory, SoftDeletes;

    public $timestamps = false;

    protected $table = 'at_farmer_insepction_checklist_remarks';

    protected $fillable = [
        'id',
        'at_farmer_inspection_details_id',
        'ref_insepction_checklist_id',
        'check_points_flag',
        'check_points_remarks',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'deleted_at',
        'type',
        'at_farmer_reg_details_id',
        'at_inspector_id',
        'inspection_status'
    ];
}

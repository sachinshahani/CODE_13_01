<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class WildHarvesterBankDetail extends Model
{

    use SoftDeletes;

    protected $table ='at_bank_details';

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'at_user_id',
        'ref_operator_type_id',
        'ref_bank_id',
        'account_number',
        'ifsc_code',
        'branch_name',
        'bank_address',
        'pincode',
        // 'farmer_photo',
        'updated_at',
        'created_at',
        'deleted_at',
    ];

}

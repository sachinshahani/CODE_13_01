<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AtInternalStockTransfe extends Model
{
    use HasFactory;
    protected $table = 'at_internal_stock_transfer_details';

    protected $fillable = [
        'id',
        'producer_name',
        'address1',
        'scope_certification_no',
        'seller_id_proof',
        'transfer_name',
        'email_id',
        'address2',
        'transferee_scope_certification_no',
        'transferee_id_proof',
        'transferee_name',
        'transferee_address',
        'ref_state_id',
        'transferee_email_id',
        'internal_transfer_no',
        'date_of_internal_transfer',
        'transfer_value',
        'place_of_dispatch',
        'lot_no',
        'place_of_destination',
        'marks_and_no',
        'reference_no',
        'transportation_mode',
        'vehicle_no',
        'transport_document_no',
        'date_of_transport',
        'gross_weight',
        'created_at',
        'updated_at',
        'created_by',
        'updated_by',
        'deleted_at'
    ];


}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class AtUserLoginDetails extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;
    protected $table = 'at_user_login_details';
    protected $fillable = [
        'at_user_id',
        'ref_operator_type_id',
        'user_name',
        'password',
        'user_type',
        'status',
        'login_status',
        'online_req_no',
        'first_change_password',
        'esign_authentication',
        'last_login_ip',
        'lab_id',
        'failed_attempt',
        'account_locked',
        'account_locked_on',
        'emuserid',
        'emname',
        'emstatus',
        'esigntype',
        'esignreason',
        'esignlocation',
        'esignstaticlocation',
        'esignmoduleallow',
        'esignupdated_at',
        'esignupdated_by',
        'esigncreated_at',
        'deleted_at',
        'is_deleted',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
    ];
}
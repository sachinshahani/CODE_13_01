<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtFarmerRegDetail extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes;
    protected $table = 'at_farmer_reg_details';
    protected $fillable = [
		"at_user_id",
        "ref_operator_type_id",
		"registration_no",
		"registration_date",
		"owner_farmerid",
		"ref_document_id",
		"land_holding_type",
		"farmer_first_name",
		"gender",
		"father_husband_flag",
		"father_husband_first_name",
		"farmer_address",
		"farmer_address1",
		"landmark",
		"ref_state_id",
		"ref_district_id",
		"ref_block_tehsil_id",
		"ref_village_id",
		"pin",
		"phone",
		"mobile_no",
		"approved_remark",
		"cancellation_flag",
		"approval_flag",
		"approved_by",
		"approval_date",
		"active_flag",
		"amend_remark",
		"noc_status",
		"noc_no",
		"noc_date",
		"cb_remarks",
		"email_id",
		"aadhar_approved_flag",
		"aadhar_approved_on",
		"aadhar_approved_by",
		"created_at",
		"created_by",
		"updated_at",
		"updated_by",
		"farmer_middle_name",
		"farmer_last_name",
		"father_husband_middle_name",
		"father_husband_last_name",
		"at_ics_inspector_id",
		"aadhar_number",
		"deleted_at",
		"farmerPhoto",
		"inspection_status",
		"inspection_step",
        "cb_status",
        "farmer_reg_status",
        "no_of_farm"
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */


    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
	// public function farmerProposedCorpDetail()
    // {
    //     return $this->hasMany(AtFarmerProposedCorpDetail::class,'at_farmer_details_id','id');
    // }
	// public function farmerStandingCorpDetail()
    // {
    //     return $this->hasMany(AtFarmerStandingCorpDetail::class,'at_farmer_details_id','id');
    // }
	public function farmerBankDetail()
    {
        return $this->hasOne(AtFarmerBankDetail::class,'at_farmer_reg_id','id');
    }
	public function farmerLandDetail()
    {
        return $this->hasMany(AtFarmerLandDetail::class,'at_farmer_reg_details_id','id');
    }
	public function farmerDocs()
    {
        return $this->hasOne(AtFarmerDocumentsList::class,'at_farmer_details_id','id');
    }

	public function farmerOSPDetail()
    {
        return $this->hasOne(AtOspIcsIndividual::class,'at_farmer_reg_details_id','id');
    }
    public function getFarmerFarms()
    {
        return $this->hasMany(AtFarmerLandDetail::class,'at_farmer_reg_details_id','id')->with('getFarmsStandingCrop');
    }
	// public function farmerLandGeoDetail()
    // {
    //     return $this->hasMany(AtFarmerLandGeoDetail::class,'at_farmer_reg_details_id','id');
    // }

}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class IpFarmInputDetails extends Model
{
    public $timestamps = false;

    protected $table = 'on_ip_farm_input_details';

    protected $fillable = [
        'id',
        'inspection_checklist_id',
        'crop_name',
        'source_of_seed_planting_stock',
        'conventional_or_organic',
        'treated_or_untreated',
        'gmo_or_non_gmo',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at'
    ];
}

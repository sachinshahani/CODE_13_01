<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtPurchaseDetails extends Model
{
    use HasFactory, SoftDeletes;

    public $timestamps = true;

    protected $table = 'at_purchase_details';

    protected $fillable = [
        'id',
        'at_closing_stock_id',
        'at_user_id',
        'at_farm_details_id',
        'purchase_id',
        'purchase_qty',
        'date_of_purchase',
        'harvest_date',
        'ref_state_id',
        'ref_district_id',
        'commodity',
        'status',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'deleted_at',
        'ref_operator_type_id',
        'store_warehouse'
    ];
   
    public function getClosingStockDetails()
	{
		return $this->hasOne(AtClosingStock::Class,'id','at_closing_stock_id');
	}
	
	
	public function getPurchaseRequest()
    {
        return $this->hasMany(AtPurchaseRequest::class,'at_closing_stock_id','id');
    }

}



<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtOpTransactionPackingDetails extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable,SoftDeletes;
    protected $table = 'at_op_transaction_packing_details';
    protected $fillable = [
		'at_op_transaction_product_sourced_id',
        'tc_application_no',
        'ref_product_id',
        'ref_packing_master_id',
        'organic_status',
        'no_of_box',
        'pack_size',
        'total_qty_in_kg',
        'product_status',
        'harvest_year',
        'source_from',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
        'deleted_at',
    ];

    
    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
 
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class UserWarehouse extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;
    protected $table = 'at_ics_warehouse_details';
    protected $fillable = [
        'at_user_id',
        'warehouse_available',
        'warehouse_type',
        'number_of_warehouse',
        'licence_number',
        'registration_no',
        'reg_agency_name',
        'warehouse_area',
        'capacity',
        'warehouse_name',
        'ref_document_id',
        'address',
        'ref_state_id',
        'ref_district_id',
        'ref_block_tehsil_id',
        'ref_village_id',
        'pin_code',
        'address_proof_of_office',
        'office_building_photo',
        'address_proof_of_office_doc',
        'no_field_officer',
        'additional_certification',
        'valid_upto',
        'contract_status',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
        'approval_flag',
        'approved_by',
        'approved_date',
        'cb_remarks',
        'is_deleted'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
 

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
 
}

<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class RefBank extends Model
{

    use HasFactory, SoftDeletes;

    protected $table ='ref_bank';

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'id',
        'bank_name',
        'is_active',
        'created_at',
        'created_by',
        'deleted_at',
    ];

}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class AtFarmerStandingCorpDetail extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;
    protected $table = 'at_farmer_standing_crop_details';
    protected $fillable = [
        "id",
        "ref_product_id",
        "season_name",
        "crop_name",
        "crop_area",
        "crop_photo",
        "geotag_photo",
        "organic_status",
        "at_farmer_details_id",
        "at_farm_details_id",
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    public function getClosingstock()
    {
        return $this->hasOne(AtClosingStock::class,'at_ip_details_standing_crop_id','id');
    }

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */

}

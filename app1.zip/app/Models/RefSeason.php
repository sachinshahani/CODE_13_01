<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RefSeason extends Model
{
    use HasFactory;

    protected $table = 'ref_season_type';

    protected $fillable = [
        'id',
        'season_type',
        'active_flag',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
       
        
    ];



}
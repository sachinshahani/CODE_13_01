<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class TraderGeoTaggingDetails extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;
    protected $table = 'trader_geo_tagging_details';
    protected $fillable = [
        "id",
        "at_trader_geo_tagging_warehouse_unit_id",
        "latitude",
        "longitude",
        "created_at",
        "created_by",
        "updated_at",
        "updated_by",
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */


    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */

}

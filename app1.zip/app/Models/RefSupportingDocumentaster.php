<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RefSupportingDocumentaster extends Model
{
    use HasFactory;


    protected $table = 'ref_cba_supporting_document_master';
}

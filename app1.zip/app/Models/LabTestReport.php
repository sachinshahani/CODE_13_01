<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\SoftDeletes;

class LabTestReport extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;
	use SoftDeletes;
    public $timestamps = true;
    protected $table = 'lab_test_report';

    protected $guarded = [];
    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

}

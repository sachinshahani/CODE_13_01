<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class RefProcuremenEntry extends Model
{ 
    use HasFactory , SoftDeletes;
    protected $table = 'ref_procurement_entry';

    protected $fillable = ['id', 'ref_product_id', 'at_farmers_details_id', 'at_farms_details_id', 'quantity_source', 'receipt_no', 'receipt_date','created_by','created_at','updated_by','updated_at','deleted_at', 'lot_number', 'is_deleted'];


    public function RefProcuremenEntries(){
        return $this->hasMany(IndividualProducerDetailOfStandingCorp::class, 'id','ref_product_id');
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtInputApprovalUnitRegDetail extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'at_input_approval_unit_reg_details';
	protected $guarded = [];
    /* protected $fillable = [
        "notification_message",
        "receiver_id",
        "receiver_status",
        "created_at",
        "created_by",
        "updated_at",
        "updated_by",
	    ]; */

	public function getCompanyList()
	{
		return $this->hasOne(AtInputApprovalRegDetail::class,'id','at_input_approval_reg_details_id');
	}

	public function getProductsDetails()
	{
		return $this->hasMany(AtInputApprovalProductDetail::Class,'at_input_approval_unit_reg_detail_id','id');
	}

    public function getProductWithIngredientName()
	{
		return $this->hasMany(AtInputApprovalProductDetail::Class,'at_input_approval_unit_reg_detail_id','id')->with('getIngredient');
	}

}

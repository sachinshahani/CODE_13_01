<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class AtFarmerDocumentsList extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;
    protected $table = 'at_farmer_documents_list';
    protected $fillable = [
        "at_farmer_details_id",
        "aadhar_card_image_path",
        "pan_card_image_path",
        "land_documents_image_path",
        "passbook_image_path",
        "contact_person_sign_image_path",
        "live_signature_image_path",
        "voter_id_card",
        "kishan_credit_card",
        "ration_card"
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
 

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
 
}

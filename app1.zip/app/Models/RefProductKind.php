<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class RefProductKind extends Model
{

    use HasFactory, SoftDeletes;

    protected $table ='ref_product_kind';

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'product_kind_id',
        'product_kind_name',
		'created_by',
		'created_at',
		'updated_by',
		'updated_at',
        'deleted_at',
    ];

}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class IndividualProducerBankDetail extends Model
{

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $table = "at_bank_details";

    protected $fillable = [
        'ref_bank_id',
        'at_user_id',
        'ref_operator_type_id',
        'bank_name',
        'account_number',
        'ifsc_code',
        'branch_name',
        'bank_address',
        'pincode',
        'farmer_photo',
        'updated_at',
        'created_at',
        'deleted_at',
    ];

}

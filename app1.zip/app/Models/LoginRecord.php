<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LoginRecord extends Model
{
    use HasFactory;

    protected $table = 'at_login_record';
    protected $fillable = [
		"id",
        "user_id",
        "ip_address",

    ];

}

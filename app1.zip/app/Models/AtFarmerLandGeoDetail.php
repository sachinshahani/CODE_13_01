<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class AtFarmerLandGeoDetail extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;
    protected $table = 'geo_tagging_details';
    protected $fillable = [
        "at_farmer_reg_details_id",
        "latitude",
        "longitude",
        "at_farm_id",
        "at_farm_standing_crop_id",
        "created_at",
        "created_by",
        "updated_at",
        "updated_by",
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
 

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
 
}

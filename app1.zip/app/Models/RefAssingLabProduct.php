<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RefAssingLabProduct extends Model
{
    use HasFactory;

    protected $table ='ref_assing_lab_product';

    public $timestamps = false;


    protected $fillable = [

         'id',
        'lab_id',
		'module',
		'product_name',
		'eto_status',
		'gmo_status',
		'ptmonth',
		'ptyear',
        'nrldate',
        'file',
        'blocked_by',
        'recommended_by',


	];
}

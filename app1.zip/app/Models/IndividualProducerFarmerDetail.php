<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class IndividualProducerFarmerDetail extends Model
{

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $table = "at_ip_farmer_reg_details";

    protected $fillable = [
        'at_user_id',
        'ref_operator_type_id',
        'registration_no',
        'registration_date',
        'owner_farmerid',
        'ref_document_id',
        'farmer_first_name',
        'farmer_middle_name',
        'farmer_last_name',
        'gender',
        'father_husband_flag',
        'father_husband_first_name',
        'father_husband_middle_name',
        'father_husband_last_name',
        'farmer_address',
        'farmer_address1',
        'landmark',
        'ref_state_id',
        'ref_district_id',
        'ref_block_tehsil_id',
        'ref_village_id',
        'pin',
        'phone',
        'mobile_no',
        'approved_remark',
        'cancellation_flag',
        'approval_flag',
        'approved_by',
        'approval_date',
        'active_flag',
        'amend_remark',
        'noc_status',
        'noc_no',
        'noc_date',
        'cb_remarks',
        'email_id',
        'aadhar_number',
        'pan_number',
        'aadhar_approved_flag',
        'aadhar_approved_on',
        'aadhar_approved_by',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by'
    ];
	
	
	public function getIndividualProducerFarmDetail()
    {
        return $this->hasMany(IndividualProducerFarmDetail::class,'at_farmer_reg_details_id','id')->with('getFarmsStandingCrop');
    }

}

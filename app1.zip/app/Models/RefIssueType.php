<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RefIssueType extends Model
{
    use HasFactory;

    public $timestamps = false;

    protected $table = 'ref_issue_type';

    protected $fillable = [
        
        'issue_name',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'is_deleted',
        'deleted_at'
    ];
}

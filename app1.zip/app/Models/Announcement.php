<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Announcement extends Model
{
    use HasFactory;

    protected $table = 'at_announcement_notification';

    protected $fillable = [

        
        'id',
        'ref_operator_type_id',
        'type',
        'title',
        'content',
        'published_date',
        'related_link',
        'attachment',
     
    ];
}

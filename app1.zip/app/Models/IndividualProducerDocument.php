<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class IndividualProducerDocument extends Model
{

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $table = "at_ip_documents_list";

    protected $fillable = [
        'at_user_id',
        'at_farmer_reg_details_id',
        'aadhar_card',
        'aadhar_card_image_path',
        'pan_card',
        'pan_card_image_path',
        'land_documets',
        'land_documents_image_path',
        'passbook',
        'passbook_image_path',
        'contact_person_sign',
        'contact_person_sign_image_path',
        'live_signature',
        'live_signature_image_path',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
        'deleted_at',
    ];

}

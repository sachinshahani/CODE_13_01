<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class RefHelpDeskStatus extends Model
{
    use HasFactory, SoftDeletes;

    public $timestamps = false;

    protected $table = 'ref_help_desk_status';

    protected $fillable = [
        'id',
        'status',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'deleted_at'
    ];
}

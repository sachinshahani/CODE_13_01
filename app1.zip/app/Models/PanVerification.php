<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PanVerification extends Model
{
    use HasFactory;

    protected $table = 'at_pan_verification_request';

    public $timestamps = true;

    protected $fillable = [
        'user_request_id',
        'registrationId',
        'at_user_id',
        'response',
        'dct_category',
        'response_code',
        'pan_number',
        'user_name',
        'user_dob',
        'user_father_name',
        'created_by',
        'updated_by',
        'pan_status',
        'name_status',
        'dob_status',
        'fname_status',
        'pan_status_message',
        'name_status_message',
        'dob_status_message',
        'fname_status_message',
        'registration_form',
        'legal_entity_type',
        'match_response'
    ];

    protected $casts = [
        'created_at' => 'date',
        'updated_at' => 'date',
    ];

}

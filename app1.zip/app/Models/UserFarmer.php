<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class UserFarmer extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;
    protected $table = 'users_farmer';
    protected $fillable = [
        'name',
        'email',
        'address',
        'mobile_no',
        'village',
        'taluka',
        'city',
        'district',
        'state',
        'pin_code',
        'ref_user_id',
        'pan_card',
        'aadhar_card',
        'address_proof_of_office',
        'address_proof_of_office_doc',
        'profile_photo',
        'appointment_doc',
        'created_by',
        'created_at',
        'updated_at',
        'is_deleted',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
 

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
 
}

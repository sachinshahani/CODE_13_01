<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DeletionLog extends Model
{
    use HasFactory;

    protected $table = 'at_deletion_log';

    protected $fillable = [
        
        'record_id', 
        'reason'
    
    ];

}

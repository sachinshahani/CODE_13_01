<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtFarmerInspectionPlotDetails extends Model
{
    use HasFactory, SoftDeletes;

    public $timestamps = false;

    protected $table = 'at_farmer_inspection_plot_details';

    protected $fillable = [
        'at_farmer_reg_details_id',
        'at_farmer_standing_crop_details_id',
        'at_farmer_inspection_details_id',
        'plot_no',
        'area',
        'main_crop',
        'inter_crop',
        'product',
        'quantity',
        'date',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'deleted_at',
        'at_inspector_id',
        'inspection_status',
        'showing_date',
        'estimated_yield',
        'season_name',
        'farm_id'
    ];
}

<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class RefPackingMaster extends Model
{
    use HasFactory, SoftDeletes;

    public $timestamps = false;

    protected $table = 'ref_packing_master';

    protected $fillable = ['id', 'packing_code', 'packing_type', 'created_by', 'created_at', 'updated_at', 'updated_by','is_deleted','deleted_at'];
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class MandatorRegister extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;
    protected $table = 'mandator_register';
    protected $fillable = [
		"id",
		"mandator_name",
		"contact_first_name",
		"contact_middle_name",
		"contact_last_name",
		"mobile",
		"aadhar_no",
		"email",
        "pan",
		"state_id",
		"district_id",
		"taluka_mandal_id",
        "village_id",
        "pin_code",
        "address",
        "status",
        "created_by",
        "created_at",
        "updated_by",
        "updated_at",
        "is_deleted",
        "deleted_at",
        "contact_mobile",
        "contact_email",
        "contact_designation",
        "contact_aadhar_no",
        "contact_photo",
        "id_proof",
        "mandator_resume",
        "gst_number",
        "gst_state_id",
    ];
}
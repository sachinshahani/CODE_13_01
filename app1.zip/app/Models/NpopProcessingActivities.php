<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class NpopProcessingActivities extends Model
{
    public $timestamps = false;

    protected $table = 'ref_npop_processing_activities';

    protected $fillable = [
        'id',
        'type',
        'activity',
        'status',
        'remarks',
        'operator_id',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by'
    ];
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class IpFarmInputDetailsNutrientManagement extends Model
{
    public $timestamps = false;

    protected $table = 'on_ip_farm_input_details_nutrient_management';

    protected $fillable = [
        'id',
        'inspection_checklist_id',
        'input_name',
        'on_off_farm',
        'approval_status',
        'composition',
        'frequency_of_usage',
        'application_rate',
        'additional_notes',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at'
    ];
}

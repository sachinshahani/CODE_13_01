<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;

class WildHarvesterDetail extends Model
{

    use  HasFactory, SoftDeletes;
   
    protected $table = 'at_wh_forest_details';

    

    protected $fillable = [
        'at_user_id',
        'area_cultivation',
        'ref_operator_type_id',
        'father_first_name',
        'father_middle_name',
        'father_last_name',
        'ref_state_id',
        'ref_district_id',
        'ref_block_tehsil_id',
        'ref_village_id',
        'circle',
        'sub_division',
        'division',
        'gender',
        'range',
        'sub_range',
        'beat',
        'compartment_no',
        'latitude',
        'longitude',
        'mou_permit_no',
        'permit_no_valid_upto',
        'pin',
        'address',
        'mobile_number',
        'aadhar_number',
        'pan_number',
        'email_id',
        'no_of_collectors',
        'updated_by',
        'updated_at',
        'created_at', 
        'deleted_at', 
    ];

}

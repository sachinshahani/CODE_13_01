<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AtInspectionIndividualProducerReport extends Model
{
    use HasFactory;

    protected $table = 'at_inspection_individual_producer_report';
    protected $fillable = [
        'id',
        'at_user_id',
        'at_external_schedule_id',
        'name_of_individual',
        'farmer_address_with_gps',
        'contact_person_mobile_no',
        'contact_person_email_id',
        'tracenet_registration_no',
        'name_of_inspector',
        'date_of_inspection',
        'time_of_inspection',
        'type_of_inspection',
        'total_land_owned',
        'area_under_organic_cultivation',
        'crops_under_organic_cultivation',
        'inspector_signature',
        'inspector_name',
        'inspection_date',
        'report_received_date',
        'reviewer_name',
        'reviewer_signature',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
    ];

    // public function products()
    // {
    //     return $this->hasMany(AtInspectionProcessorProduct::class, 'at_inspection_processor_report_id');
    // }

    public function compliances()
    {
        return $this->hasMany(AtComplianceDetail::class, 'at_inspection_processor_report_id');
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class NpopProcessingActivitiesStatus extends Model
{
    public $timestamps = false;

    protected $table = 'at_npop_processing_activities_status';

    protected $fillable = [
        'id',
        'inspection_checklist_id',
        'ref_npop_processing_activities_id',
        'status',
        'remarks',
        'operator_id',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by'
    ];
}

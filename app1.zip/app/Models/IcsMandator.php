<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class IcsMandator extends Model
{
    use HasFactory;
    protected $table = 'at_ics_mandator_registration_details';

    protected $fillable = [
        'at_user_id',
        'first_name',
        'middle_name',
        'last_name',
        'id_proof',
        'id_proof_doc',
        'address_proof_of_office',
        'address_proof_of_office_doc',
        'profile_photo',
        'office_building_photo',
        'appointment_doc',
        'accreditation_agency_no',
        'mand_type',
        'registration_no',
        'last_registration_datename',
        'company_mandator_name',
        'gst_number',
        'address1',
        'address2',
        'address3',
        'ref_state_id',
        'ref_district_id',
        'ref_block_tehsil_id',
        'ref_village_id',
        'pin_code',
        'email_id',
        'mobile_no',
        'ref_document_id',
        'document_number',
        'registered_with',
        'image_name',
        'image_path',
        'issuing_authority_name',
        'issuing_authority_location',
        'document_updated_on',
        'active_flag',
        'creation_remarks',
        'update_remarks',
        'registration_letter',
        'mandator_resume',
        'declaration',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
        'deleted',
        'is_registred',
        'pan_card',
    ];
}

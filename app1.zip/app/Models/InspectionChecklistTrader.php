<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class InspectionChecklistTrader extends Model
{
    public $timestamps = false;

    protected $table = 'at_inspection_checklist_trader';

    protected $fillable = [
        'id',
        'trader_name',
        'iec_no',
        'operator_address',
        'total_area',
        'type_of_inspection_initial',
        'email_id',
        'inspector_name',
        'inspection_date',
        'latitude',
        'longitude',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'sign_of_trader_img',
        'sign_date_of_trader',
        'sign_of_inspector_img',
        'sign_date_of_inspector',
        'name_of_trader',
        'warehouse_processing_unit_godown_img',
        'remarks',
        'operator_id',
        'inspector_id',
        'stock_capacity',
        'selfie_with_contact_person',
        'stock_availability'
    ];
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class AtFarmerBankDetail extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;
    protected $table = 'at_farmer_bank_details';
    protected $fillable = [
		"ref_bank_id",
		"account_number",
		"ifsc_code",
		"branch_name",
		"bank_address",
		"pincode",
		"farmer_photo",
		"updated_at",
		"created_at",
		"deleted_at",
		"bank_name",
		"at_farmer_reg_id"
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
 

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
 
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class AtFarmerInspectionDetail extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;
    protected $table = 'at_farmer_inspection_details';
    protected $fillable = [
		"at_farmer_reg_details_id",
		"at_inspection_schedule_id",
		"inspection_date",
		"inspection_time",
		"bank_alocation_trackddress",
		"created_at",
		"created_by",
		"updated_at",
		"updated_by",
    "season_name",
    "at_inspector_id",
    "inspection_status"
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
 

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
 
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtGrowerGroupCropsDetails extends Model
{
    public $timestamps = false;

    protected $table = 'at_inspection_checklist_grower_group_crops_details';

    protected $fillable = [
        'id',
        'at_inspection_checklist_grower_group_id',
        'crop_season',
        'crop_main',
        'intercrops_buffer_crop_cover_crop',
        'crop_area_ha',
        'estimated_yield_mt',
        'crop_status',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at'
    ];
}

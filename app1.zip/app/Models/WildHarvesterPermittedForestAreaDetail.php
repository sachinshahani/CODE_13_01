<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WildHarvesterPermittedForestAreaDetail extends Model
{

    protected $table = 'at_wh_permitted_forest_area';
    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'at_user_id',
        'at_wh_forest_details_id',
        'forest_farm_image',
        'image_after_tagging',
        'total_forest_area_under_organic',
        'organic_cultivation',
        'updated_by',
        'updated_at',
        'created_at',
    ];

}

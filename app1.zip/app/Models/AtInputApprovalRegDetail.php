<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtInputApprovalRegDetail extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'at_input_approval_reg_details';
	protected $guarded = [];
    /* protected $fillable = [
        "notification_message",
        "receiver_id",
        "receiver_status",
        "created_at",
        "created_by",
        "updated_at",
        "updated_by",
	    ]; */

	public function getUnitRegDetails()
	{
		return $this->hasMany(AtInputApprovalUnitRegDetail::class,'at_input_approval_reg_details_id','id')->with('getProductsDetails');
	}

	public function getInspectionMaster()
	{
		return $this->hasMany(AtInputApprovalInspectionMaster::class,'registration_id','id')->with('getInspectionMasterDetail');
	}

    public function getUnitRegDetailsWithIngredient()
	{
		return $this->hasMany(AtInputApprovalUnitRegDetail::class,'at_input_approval_reg_details_id','id')->with('getProductWithIngredientName');
	}


}

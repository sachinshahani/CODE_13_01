<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RefSubDistrict extends Model
{
    use HasFactory;

    protected $table = 'ref_sub_district';
}

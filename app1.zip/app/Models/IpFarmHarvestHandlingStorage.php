<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class IpFarmHarvestHandlingStorage extends Model
{
    public $timestamps = false;

    protected $table = 'at_ip_farm_harvest_handling_storage';

    protected $fillable = [
        'id',
        'inspection_checklist_id',
        'last_year_season',
        'major_crop_grown',
        'harvest_month',
        'quantity_kg',
        'last_year_total_production',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at'
    ];
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\IndividualProducerGeoTagging;

class IndividualProducerFarmDetail extends Model
{

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $table = "at_ip_farm_details";

    protected $fillable = [
        'at_farmer_reg_details_id',
        'at_user_id',
        'registration_no',
        'owner_farmerid',
        'land_holding_type',
        'farm_name',
        'landmark',
        'pin',
        'farm_no',
        'area_in_ha',
        'total_area',
        'survay_no',
        'latitude',
        'logititude',
        'ref_state_id',
        'ref_district_id',
        'ref_block_tehsil_id',
        'ref_village_id',
        'farm_processing',
        'created_at',
        'created_by',
        'approved_remark',
        'cancellation_flag',
        'approval_flag',
        'approved_by',
        'approved_date',
        'active_flag',
        'amend_remark',
        'ref_organic_status_master_id',
        'noc_no',
        'noc_status',
        'noc_date',
        'is_upgraded',
        'updated_at',
        'updated_by',
        'cb_remarks',
        'cancelled_by',
        'cancellation_on',
        'remarks',
        
    ];
	
	public function getFarmsStandingCrop()
    {
        return $this->hasMany(IndividualProducerDetailOfStandingCorp::class,'at_ip_farm_details_id','id');
    }

    public function state()
    {
        return $this->belongsTo(RefState::class, 'ref_state_id');
    }

    public function district()
    {
        return $this->belongsTo(RefDistrict::class, 'ref_district_id');
    }

    public function blockTehsil()
    {
        return $this->belongsTo(RefVillage::class, 'ref_block_tehsil_id');
    }
    

}

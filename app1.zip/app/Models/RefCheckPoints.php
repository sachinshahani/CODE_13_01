<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class RefCheckPoints extends Model
{
    use HasFactory, SoftDeletes;

    public $timestamps = false;

    protected $table = 'ref_insepction_checklist';

    protected $fillable = [
        'id',
        'check_points',
        'type',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'deleted_at'
    ];
}

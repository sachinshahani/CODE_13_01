<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
// use Laravel\Sanctum\HasApiTokens;
use Laravel\Passport\HasApiTokens;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtImportedProductDetails extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes;
    protected $table = 'at_imported_product_details';

    protected $fillable = [
        'at_imported_product_master_id',
        'ref_product_id',
        'import_qty_in_mt',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
        'deleted_at'
        
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    public function farmersRegSchedule()
    {
        return $this->hasOne(FarmersRegSchedule::class,'at_ics_inspector_details_id','id');
    }
    public function farmersInspSchedule()
    {
        return $this->hasOne(InspectionSchedule::class,'at_ics_inspector_details_id','id');
    }

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */

}

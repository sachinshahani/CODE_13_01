<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RefFinancialYear extends Model
{
    use HasFactory;

    public $timestamps = false;

    protected $table = 'ref_financial_year';

    protected $fillable = ['id', 'financial_year', 'created_by', 'updated_by', 'created_at', 'updated_at', 'is_deleted'];
}

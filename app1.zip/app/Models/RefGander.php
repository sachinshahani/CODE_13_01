<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RefGander extends Model
{
    use HasFactory;

    protected $table = 'ref_gender';

    protected $fillable = [
        'id',
        'gender_code',
        'gender',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
       
        
    ];



}
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AtIpFarmerRegDetail extends Model
{
    use HasFactory;

    protected $table = 'at_ip_farmer_reg_details';

    protected $fillable = [
 
     'ref_operator_type_id',
     'registration_no',
     'owner_farmerid',
     'farm_name',
     'landmark',
     'farm_no',
     'area_in_ha',
     'total_area',
     'survay_no',
     'latitude',
     'logititude',
     'ref_state_id',
     'ref_district_id',
     'ref_block_tehsil_id',
     'ref_village_id',
     'farm_processing',
     'created_at',
     'created_by',
     'approved_remark',
     'cancellation_flag',
     'approval_flag',
     'approved_by',
     'approved_date',
     'active_flag',
     'amend_remark',
     'ref_organic_status_master_id',
     'noc_no',
     'noc_status',
     'noc_date',
     'is_upgraded',
     'updated_at',
     'updated_by',
     'cb_remarks',
     'cancelled_by',
     'cancellation_on',
     'remarks',
 
    ];
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RefOperatorType extends Model
{
    use HasFactory;

    protected $table = 'ref_operator_type';

    protected $fillable = [
        
        'operator_type_code',
        'operator_type',
        'created_by',
        'created_on',
        'updated_by',
        'updated_on',
        'is_deleted',
        
        
    ];
    public function totalCertificate(){
        return $this->hasMany(CertificateStandardDetail::class,'ref_operator_type_id','id');
    }
}

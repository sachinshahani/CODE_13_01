<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtPurchaseStorageClosingStock extends Model
{
    use HasFactory, SoftDeletes;

    public $timestamps = true;

    protected $table = 'at_purchase_storage_closing_stock';

    protected $fillable = [
        'id',
        'at_purchase_details_id',
        'at_ics_warehouse_details_id',
        'at_ics_purchase_manager_details_id',
        'transport_date',
        'status',
        'commodity',
        'qty',
        'no_of_bags_packages',
        'weight',
        'date_of_storage',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'deleted_at',
        'at_ics_warehouse_manager_details_id',
        'address',
        
    ];
   
    // public function getClosingStockDetails()
	// {
	// 	return $this->hasOne(AtClosingStock::Class,'id','at_closing_stock_id');
	// }

}



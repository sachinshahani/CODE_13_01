<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AtInspectionProcessorReport extends Model
{
    use HasFactory;
    protected $table = 'at_inspection_processor_report';
    protected $fillable = [
        'processor_name',
        'registered_address',
        'authorized_person',
        'contact_details',
        'legal_status',
        'license_details',
        'audited_sites',
        'inspection_type',
        'specific_reason',
        'sampling_done',
        'remarks',
    ];

    public function products()
    {
        return $this->hasMany(AtInspectionProcessorProduct::class, 'at_inspection_processor_report_id');
    }

    public function compliances()
    {
        return $this->hasMany(AtComplianceDetail::class, 'at_inspection_processor_report_id');
    }
}





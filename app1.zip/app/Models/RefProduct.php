<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class RefProduct extends Model
{

    use HasFactory, SoftDeletes;

    protected $table ='ref_product';

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'id',
        'hs_code',
        'product_name',
        'hscode_description',
        'ref_category_id',
    ];

}

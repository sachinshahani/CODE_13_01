<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtAccrediationCertificationBody extends Model
{
    use HasFactory, SoftDeletes;


    protected $table = 'at_accrediation_certificationbody_master';

   protected $fillable = [

    'accrediation_agency_no',
    'at_user_id',
    'ref_designation_master_id',
    'category_type',
    'created_at',
    'created_by',
    'updated_at',
    'updated_by',
    'deleted_at',
    'application_type',
    'ref_document_id',
    'first_name',
    'cb_head_name',
    'contact_person_first_name',
    'contact_person_mobile_number',
    'contact_person_email',
    'is_your_registered',
    'cb_address_type',
    'cb_registered_office_address',
    'country',
    'ref_state_id',
    'ref_district_id',
    'ref_block_tehsil_id',
    'ref_village_id',
    'pin',
    'office_phone_number',
    'fax',
    'cb_email_id',
    'website_address',
    'legal_status',
    'year_of_establishment',
    'date_of_establishment',
    'gst_no',
    'descriptions',
    'declaration_date',
    'declaration_signature',
    'declaration_payment_mode',




   ];

}

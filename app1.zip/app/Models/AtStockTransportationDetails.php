<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtStockTransportationDetails extends Model
{
    use HasFactory, SoftDeletes;

    public $timestamps = true;

    protected $table = 'at_purchase_stock_transportation_details';

    protected $fillable = [
        'id',
        'at_purchase_details_id',
        'transportation_date',
        'ref_transportation_mode_id',
        'at_closing_stock_id',
        'vehicle_number',
        'purchased_qty',
        'place_of_dispatch',
        'place_of_destination',
        'at_ics_warehouse_details_id',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'deleted_at',
        'status',
        'commodity',
        'mandator_address'
       
    ];
   
    // public function getClosingStockDetails()
	// {
	// 	return $this->hasOne(AtClosingStock::Class,'id','at_closing_stock_id');
	// }

}



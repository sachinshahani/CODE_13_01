<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtOpNocDetails extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;
	use SoftDeletes;
    public $timestamps = true;
    protected $table = 'at_op_noc_details';

    protected $guarded = [];
    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    public function farmernDetail()
    {
        return $this->hasOne(AtFarmerRegDetail::class,'id','at_farmer_reg_details_id');
    }

    public function certificateDetails()
    {
        return $this->hasOne(CertificateStandardDetail::class, 'at_user_id', 'at_user_id');
    }
}

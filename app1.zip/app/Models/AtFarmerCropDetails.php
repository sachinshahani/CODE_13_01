<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AtFarmerCropDetails extends Model
{
    use HasFactory;
    protected $table = 'at_farmer_proposed_crop_details';
    protected $fillable = [
		"id",
        "ref_product_id",
		"season_name",
		"crop_area",
		"organic_status",
		"at_farmer_details_id",
		"at_farm_details_id",
		"created_at",
		"updated_at",
        "crop_name"



    ];
}

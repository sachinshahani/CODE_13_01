<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Auth;

class GeoTaggingWarehouseDetail extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $table ='at_trader_geo_tagging_warehouse_unit';

	protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];
	/**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'at_user_id',         
        'warehouse_unit_id',
        'warehouse_name',
        'fssai_license_number',
        'license_document',
        'license_validity',
        'address',
        'agreement_status',
        'number_of_products',
        'additional_certificate',
        'geo_tagging_warehouse_unit',
        'image_after_tagging',         
        'total_capacity',         
        'organic_installed_capacity',         
		'created_at',
        'updated_at',
        'deleted_at',
        'created_by',
        'deleted_at',
        'GeoTaggingWarehouseDetail'
    ];
	
	// public static function boot()
    //  {
    //     parent::boot();
    //     static::creating(function($model)
    //     {
    //         $user = Auth::user();          
    //         $model->created_by = $user->id;
             
    //     });
    //     static::updating(function($model)
    //     {
    //         $user = Auth::user();
    //         $model->updated_by = $user->id;
    //     });      
    // }







}
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AtOrganicOperator extends Model
{
    use HasFactory;

    public $timestamps = false;
    protected $table = 'organic_operator';
    protected $guarded = [];
    // protected $fillable = [
    //     'operator_type',
    //     'cb_type',
    //     'operator_name',
    //     'pan',
    //     'document_type',
    //     'legal_document_number',
    //     'address',
    //     'pin_code',
    //     'contact_first_name',
    //     'contact_middle_name',
    //     'contact_last_name',
    //     'contact_gender',
    //     'mobile',
    //     'aadhar_number',
    //     'created_on',
    //     'created_by',
    //     'updated_on',
    //     'updated_by',
    //     'deleted_at',

    // ];
}

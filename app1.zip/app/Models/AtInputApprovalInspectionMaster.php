<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtInputApprovalInspectionMaster extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'at_input_approval_inspection_master';
	protected $guarded = [];
	
	public function getInspectionMasterDetail()
	{
		return $this->hasMany(AtInputApprovalInspectionDetail::class,'at_input_approval_inspection_master_id','id');
	}
    
}

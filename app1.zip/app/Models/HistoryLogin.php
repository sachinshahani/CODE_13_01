<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HistoryLogin extends Model
{
    use HasFactory;

    protected $table ='log_history';

    protected $fillable = [
		'id',
		'user_name',
		'user_type',
		'ip_address',
		'user_id',
		'user_action',
		'created_on',
		'updated_on',
		'deleted_at',
		'action_url',
		'device_name',
		'device_type'

	];
}

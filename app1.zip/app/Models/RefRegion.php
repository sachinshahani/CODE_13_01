<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class RefRegion extends Model
{
    use HasFactory, SoftDeletes;

    public $timestamps = false;

    protected $table = 'ref_block_tehsil';

    protected $fillable = ['id', 'block_tehsil_code', 'block_tehsil_name', 'ref_district_id', 'ref_state_id', 'created_by', 'created_at', 'updated_at', 'updated_by', 'is_deleted','deleted_at'];
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AtHelpDeskDetail extends Model
{
    use HasFactory;


    public $timestamps = false;

    protected $table = 'at_helpdesk_details';

    protected $fillable = [
        
        'at_user_id',
        'ref_issue_type_id',
        'ref_sub_issue_type_id',
        'issue_id',
        'issue_related_to',
        'description',
        'registration_number',
        'status',
        'from_date',
        'to_date',
        'ref_document_id',
        'document_upload',
        'remarks',
        
    ];
}

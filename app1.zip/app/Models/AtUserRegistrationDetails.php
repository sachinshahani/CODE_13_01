<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class AtUserRegistrationDetails extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;
    protected $table = 'at_user_registration_details';
    protected $fillable = [
        'at_user_id',
        'at_user_login_details_id',
        'ref_operator_type_id',
        'first_name',
        'middle_name',
        'last_name',
        'mobile_no',
        'email',
        'address',
        'ref_block_tehsil_id',
        'ref_district_id',
        'ref_state_id',
        'pin',
        'managed_by',
        'ref_village_id',
        'no_of_farmers',
        'no_of_inspector',
        'remember_token',
        'contact_person_first_name',
        'contact_person_middle_name',
        'contact_person_last_name',
        'contact_person_mobile_number',
        'contact_person_gender',
        'contact_person_pan_number',
        'contact_person_aadhar_number',
        'contact_person_email',
        'date_of_registration',
        'legal_document_number',
        'risk_assessment',
        'external_inspection',
        'internal_inspection',
        'cb_reg_remarks',
        'standerd_type',
        'contact_designation',
        'contact_gender',
        'aadhar_number',
        'entity_firm',
        'registration_no',
        'operator_status',
        'from_date',
        'to_date',
        'to_years',
        'is_migrated',
        'fssai_licence',
        'ayush_licence',
        'ayush_validity',
        'forest_licence',
        'iecode',
        'fssai_validity',
        'at_expire',
        'dob_in',
        'father_name',
        'dob_doi_date',
        'online_req_no',
        'is_deleted',
        'deleted_at',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
    ];
}
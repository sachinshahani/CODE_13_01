<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtOpTransactionCertificateEntry extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable,SoftDeletes;
    protected $table = 'at_op_transaction_certificate_entry';
    protected $fillable = [
		'transaction_certificate_no',
		'tc_applicatio_no',
		'seller_at_op_certificate_standard_details_id',
		'nop_cert',
		'exporter_seller_name',
		'exporter_seller_address',
        'seller_email',
		'seller_country_code',
		'buyer_at_op_certificate_standard_details_id',
		'buyer_name',
		'buyer_address',
		'buyer_country_code',
        'eu_country_buyer',
        'byuer_ref_state_id',
        'buyer_email',
        'consignee_name',
        'destination_address',
        'consignee_country_code',
        'eu_country_consignee',
        'consignee_state',
        'consignee_email',
        'producer_name',
        'producer_address',
        'export_type',
        'invoice_no',
        'invoice_currency',
        'invoice_value',
        'invoice_date',
        'packed_bulk',
        'transport_mode',
        'transport_doc_no',
        'container_no',
        'ship_no',
        'ship_name',
        'vessel_date',
        'bill_of_lading',
        'date_of_lading',
        'train_no',
        'wagon_no',
        'flight_no',
        'flight_date',
        'airway_bill_no',
        'airway_bill_date',
        'country_origin',
        'total_qty',
        'rem_qty',
        'send_certificate_to',
        'harvest_year',
        'reference_no',
        'serial_no',
        'marks_no',
        'net_weight',
        'gross_weight',
        'declare_qty',
        'batch_no',
        'scope_of_selling',
        'signatory_code',
        'country_of_clearance',
        'seal_no',
        'eori_no',
        'issued_flag',
        'cancellation_flag',
        'cancellation_remark',
        'cancel_on',
        'tc_date',
        'container_no_road',
        'container_no_air',
        'container_no_ship',
        'barcode',
        'old_tc_flag',
        'old_tc_no',
        'applicant_acc_no',
        'applicant_scn',
        'applicant_status',
        'applicant_created_by',
        'applicant_created_on',
        'ie_code',
        'order_contract_no',
        'transport_date',
        'buyer_pan_no',
        'seller_pan_no',
        'place_of_destination',
        'pdf_file_name',
        'cb_logo_name',
        'tc_type',
        'ptc_no',
        'ptc_applied_on',
        'ptc_approved_flag',
        'ptc_rejected_flag',
        'ptc_approved_on',
        'cb_remarks',
        'applied_for_tc',
        'applied_for_tc_on',
        'ptc_signatory_code',
        'ptc_barcode',
        'ptc_pdf_file_name',
        'buyer_id_proof',
        'house_bill_no',
        'is_imp_ing',
        'seller_reg_no',
        'buyer_reg_no',
        'ptc_valid_till',
        'apeda_comment',
        'stock_type',
        'seller_fssai_licence_no',
        'buyer_fssai_licence_no',
        'seller_id_proof_type',
        'buyer_id_proof_type',
        'coi_no',
        'coi_date',
        'coi_doc',
        'other_usa',
        'operator_buy_trader',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
        'deleted_at',
        'at_op_transaction_vs_transaction_product_id',
        'lot_number'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
 

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
 
}

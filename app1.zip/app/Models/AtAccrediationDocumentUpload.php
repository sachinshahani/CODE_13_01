<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtAccrediationDocumentUpload extends Model
{
   
    use HasFactory, SoftDeletes;

    protected $table = 'at_accrediation_document_upload';

    protected $fillable = [
 
    'at_accrediation_certificationbody_master_id',
    'ref_cba_supporting_document_master_id',
    'document_upload',
    
    ];


}

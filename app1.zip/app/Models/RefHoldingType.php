<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RefHoldingType extends Model
{
    use HasFactory;

    protected $table = 'ref_land_holding_type';


    protected $fillable = [
        'id',
        'land_holding_type',
        'created_at',
        'created_by',
        'creation_remarks',
        'updated_at',
        'updated_by',
        
       
        
    ];



}
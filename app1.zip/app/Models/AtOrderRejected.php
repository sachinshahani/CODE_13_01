<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtOrderRejected extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;
	use SoftDeletes;
    public $timestamps = true;
    protected $table = 'at_order_rejected_ics';

    protected $guarded = [];
    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    // at_order_details_received_from_buyer
    // public function getwhproducts()
    // {
    //     return $this->hasOne(WildHarvesterForestProductDetail::class,'id','at_wh_forest_product_details_id');
    // }


}

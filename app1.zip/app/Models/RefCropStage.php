<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class RefCropStage extends Model
{

    use HasFactory, SoftDeletes;

    protected $table ='ref_crop_stage';

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'crop_stage_id',
        'crop_stage_name',
		'created_by',
		'created_at',
		'updated_by',
		'updated_at',
        'deleted_at',
    ];

}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ForwardLabSample extends Model
{
    use HasFactory;

    protected $table = 'forward_lab_samble';

    protected $fillable = [
        
        'at_org_sample_rtn_dtl_id', 
        'sample_code',
        'drawn_sample_date',
        'sample_retains_qty',
        'place_sampling',
        'sample_weight',
        'person_name',
        'lab_code',
        'sample_retaining_date',
        'created_by',
        'updated_at',
        'updated_by',
        'deleted_at',
        'created_at',
    
    ];

}

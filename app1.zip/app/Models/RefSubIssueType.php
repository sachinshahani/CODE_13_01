<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RefSubIssueType extends Model
{
    use HasFactory;

    public $timestamps = false;

    protected $table = 'ref_sub_issue_type';

    protected $fillable = [
        
        'ref_issue_type_id',
        'sub_issue_name',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'is_deleted',
        'deleted_at'
    ];
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtCbTestParameterEntry extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;
	use SoftDeletes;
    public $timestamps = true;
    protected $table = 'at_cb_test_parameter_entry';

    protected $guarded = [];
    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

}

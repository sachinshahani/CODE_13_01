<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtExternalInspection extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable,SoftDeletes;
    protected $table = 'at_external_inspection';
    protected $fillable = [
		"at_user_id",
		"submission_of_inspection_report",
		"inspection_date",
		"inspector_name",
		"inspector_contact",
		"created_by",
		"updated_at",
		"updated_by",
		"created_at",
		"deleted_at",
		"status",
		"remark",
    "closure_remark"
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
 

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */


     public function ObservationDetail()
     {
         return $this->hasMany(AtExternalInspectionObservation::class,'at_external_inspection_id','id');
     }
 
}

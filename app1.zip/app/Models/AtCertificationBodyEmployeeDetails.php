<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class AtCertificationBodyEmployeeDetails extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;
    protected $table = 'at_certification_body_employee_details';
    protected $fillable = [
        'at_user_id',
        'at_user_login_details_id',
        'ref_operator_type_id',
        'first_name',
        'mobile_no',
        'email',
        'user_type',
        'status',
        'aadhar_number',
        'designation',
        'remark',
        'employee_id',
        'join_date',
        'total_experience',
        'training',
        'employee_type',
        'resourse_type',
        'is_migrated',
        'pan',
        'din',
        'upload_biodata',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'is_deleted',
        'deleted_at',
        'gender',
    ];
}
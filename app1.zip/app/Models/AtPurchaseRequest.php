<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtPurchaseRequest extends Model
{
    use HasFactory;
	use SoftDeletes;

	protected $table ='at_purchase_request';

    public $timestamps = false;


    protected $fillable = [
		"at_user_id",
        "ref_operator_type_id",
        "commodity",
        "status",
        "quantity",
        "upload_copy_of_performa_invoice",
        "copy_of_performa_invoice_remaks",
        "no_of_packages",
        "order_status",
		'created_at',
		'created_by',
		'updated_at',
		'updated_by',
		'deleted_at'
	];
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RefOrganicStatus extends Model
{
    use HasFactory;

    protected $table = 'ref_organic_status_master';

    protected $fillable = [
        'id',
        'standard_type_id',
        'organic_status_code',
        'organic_status',
        'weight',
        'processing_flag',
        'active_flag',
        'created_at',
        'created_by',
        'creation_remarks',
        'updated_at',
        'updated_by',
        'remarks'
       
        
    ];



}
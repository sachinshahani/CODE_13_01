<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtInputApprovalProductIngredientDetail extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'at_input_approval_ingredient_details';
	protected $guarded = [];

	public function getUnitsDetails()
	{
		return $this->hasOne(AtInputApprovalUnitRegDetail::Class,'id','at_input_approval_unit_reg_detail_id');
	}

}
    
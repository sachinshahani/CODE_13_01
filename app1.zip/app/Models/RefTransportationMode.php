<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class RefTransportationMode extends Model
{
    use HasFactory, SoftDeletes;

    public $timestamps = true;

    protected $table = 'ref_transportation_mode';

    protected $fillable = [
        'id',
        'mode_name',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'deleted_at',
       
    ];
   
    // public function getClosingStockDetails()
	// {
	// 	return $this->hasOne(AtClosingStock::Class,'id','at_closing_stock_id');
	// }

}



<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtLcRcAc extends Model
{
    use HasFactory;

    use SoftDeletes;

	protected $table ='at_lc_rcac';

     public $timestamps = false;


    protected $fillable = [


        "id",
        "operator_type_id",
		"lc_type",
        "lc_no",
        "lc_file",
        "lc_date",
        "lc_validity_date",
        "lc_qty",
        "importer_name",
        "importer_address",
        "importer_country",
        "declaration",
		'created_on',
		'created_by',
		'updated_on',
		'updated_by',
		'deleted_at'
	];


}

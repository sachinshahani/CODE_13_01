<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AtInternalStockTransferPackingDetails extends Model
{
    use HasFactory;


    protected $table = 'at_internal_stock_transfer_packing_details';
    protected $fillable = [
        'at_user_id',
        'batch_details_id',
        'product_id',
        'organic_status',
        'created_by',
        'updated_by',
        'created_at',
        'updated_at'
    ];
}

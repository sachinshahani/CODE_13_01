<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class TradersProductDetail extends Model
{
    use HasFactory;
	use SoftDeletes;

    protected $table ='at_traders_products_details';

    public $timestamps = false;


    protected $fillable = [
		'at_user_id',
		'at_trader_geo_tagging_warehouse_unit_id',
		'warehouse_unit_id',
		'ref_hscode_id',
		'ref_product_id',
		'product_trader_name',
		'organic_status',
		'product_image',
		'created_at',
		'created_by',
		'updated_at',
		'updated_by',
		'deleted_at',
		'product_description',
		'ref_category_id'
	];


}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtInputApprovalProudctMode extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'at_input_approval_proudct_mode';
	protected $guarded = [];
    
}

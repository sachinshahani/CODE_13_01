<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AtAccrediationEmployeeDetails extends Model
{
    use HasFactory;
    protected $table = 'at_accrediation_certificationbody_emp_details';
    protected $guarded = [];
    // protected $fillable = [

    //     'id',
    //     'at_accrediation_certificationbody_master_id',
    //     'employee_type',
    //     'name',
    //     'ref_designation_master_id',
    //     'qualification',
    //     'total_experience',
    //     'date_of_joining',
    //     'training',
    //     'upload_biodata',
    //     'training',
    //     'upload_biodata',
    //     'created_at',
    //     'created_by',
    //     'updated_at',
    //     'updated_by',
    //     'deleted_at',


    // ];
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtSlider extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'at_slider';

    protected $fillable = [
		'title',
		'summary',
		'link',
		'image',
		'slider_type',
		'created_by',
		'created_at',
		'updated_by',
		'updated_at',
		'deleted_at',
		'language',
		'status',
	    ];
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AtComplianceDetails extends Model
{
    public $timestamps = false;

    protected $table = 'at_compliance_details';

    protected $fillable = [
        'id',
        'at_inspection_checklist_grower_group_id',
        'compliance_previous_condition',
        'noncompliance_type',
        'action_taken',
        'status_of_action_taken',
        'remarks',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'at_inspection_processor_report_id'
    ];
}

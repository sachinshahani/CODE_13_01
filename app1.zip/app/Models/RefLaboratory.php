<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RefLaboratory extends Model
{
    use HasFactory;
	
    public $timestamps = true;
    protected $table = 'ref_laboratory_master';
    protected $guarded = [];
    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];
}

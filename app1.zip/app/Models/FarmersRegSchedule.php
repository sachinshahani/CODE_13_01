<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\SoftDeletes;

class FarmersRegSchedule extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes;

    protected $table = 'at_farmers_reg_schedule';

    protected $fillable = [
        'at_ics_inspector_details_id',
        'at_user_id',
        'schedule_period_from',
        'schedule_period_to',
        'number_of_farmer_reg',
        'address',
        'ref_state_id',
        'ref_district_id',
        'ref_block_tehsil_id',
        'ref_village_id',
        'pin',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
        'deleted_at',
        'total_attempt',
        'status'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
   

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */

}

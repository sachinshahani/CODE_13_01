<?php

namespace App\Services;

use App\Models\User;

class NotificationService
{
    public function notifySuperAdmins($notification)
    {
        $superAdmins = User::where('ref_operator_type_id', 101)->get();

       
        foreach ($superAdmins as $superAdmin) {
            $superAdmin->notify($notification);
        }
    }
}

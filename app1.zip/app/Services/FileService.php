<?php

namespace App\Services;

use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

class FileService
{
    private string $localRoot;
    private array $cloudConfig;
    private bool $encryptFiles;
    private string $encryptionKey;
    private string $fcpattern;
    private bool $mimeCheck;

    public function __construct()
    {
        $this->localRoot = config('filesystems.upload_directory');
        $this->cloudConfig = config('filesystems.cloud');
        $this->encryptFiles = config('filesystems.encrypt_files');
        $this->encryptionKey = config('filesystems.encryption_key');
        $this->mimeCheck = config('filesystems.mime_check');
        $this->fcpattern = config('filesystems.fc_pattern');
    }

    
    /**
     * Uploads a file to local storage.
     */

    public function uploadFile(Request $request, string $directory, array $allowedExtensions, string $fileKey): array
    {
       
        if (!$request->hasFile($fileKey)) {
            return ['status' => false, 'message' => 'No file uploaded.'];
        }

        $file = $request->file($fileKey); 
        $extension = $file->getClientOriginalExtension();
        $fileName = $file->getClientOriginalName();
        $fileTmpName = $file->getRealPath();

        if (!in_array(strtolower($extension), $allowedExtensions)) {
            return ['status' => false, 'message' => 'Invalid file extension.'];
        }


        $uniqueName = uniqid() . '_' . Str::slug(pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME)) . '.' . $extension;

         // Get dynamic attributes from the request
        $dataName = $request->input('folder-name', $directory);
        $dataSuName = trim($request->input('folder-suName', ''));

        if (str_contains($this->fcpattern, '.GMT')) {
            $patternDate = now()->format('Y-m-d.H:i');
        }else{
            $patternDate = now()->format('Y-m-d');
        }

        $relativePath = "{$dataName}/{$patternDate}";
        if (!empty($dataSuName)) {
            $relativePath .= "/{$dataSuName}";
        }

        $absolutePath = "{$this->localRoot}/{$relativePath}";
        
        //\Log::info('Relative Path: ' . $relativePath);
        //\Log::info('Absolute Path: ' . $absolutePath);

        // Create directory if it doesn't exist
        if (!File::exists($absolutePath)) {
            try {
                File::makeDirectory($absolutePath, 0755, true);
                $this->addIndexFile($absolutePath);
            } catch (\Exception $e) {
                \Log::error('Failed to create directory: ' . $absolutePath . ' Error: ' . $e->getMessage());
                return ['status' => false, 'message' => 'Server error while creating directory.'];
            }
        }

        $filePath = "{$absolutePath}/{$uniqueName}";

        // MIME and file content checks
        if ($this->mimeCheck) {
            $mime = $file->getMimeType();
            $allowedMimeTypes = [
                'image/jpeg',
                'image/png',
                'image/jpg',
                'application/pdf',
                'application/msword',
                'image/gif',
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                'video/vnd.uvvu.mp4',
                'application/mp4',
                'video/mp4',
                'video/x-msvideo',
                'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'application/vnd.ms-excel'
            ];

            if (!in_array($mime, $allowedMimeTypes)) {
                return ['status' => false, 'message' => 'Invalid MIME type.'];
            }

            $section = strtoupper(base64_encode(file_get_contents($fileTmpName)));
            $nsection = substr($section, 0, 8);

            // Validate the first bytes of the file for magic numbers
            if (!in_array($nsection, ['JVBERI0X', '/9J/4AAQ', 'IVBORW0K'])) {
                return ['status' => false, 'message' => 'File content validation failed.'];
            }

            $fileContents = file_get_contents($fileTmpName);
            if (
                strpos($fileContents, 'script') !== false || strpos($fileContents, 'php') !== false ||
                strpos($fileContents, 'prompt') !== false || strpos($fileContents, 'alert') !== false
            ) {
                return ['status' => false, 'message' => 'File contains invalid content.'];
            }
        }

        // Move file and optionally encrypt
        try {
            if ($this->encryptFiles) {
                $encryptedContent = Crypt::encrypt(file_get_contents($fileTmpName), $this->encryptionKey);
                File::put($filePath, $encryptedContent);
            } else {
                $file->move($absolutePath, $uniqueName);
            }
        } catch (\Exception $e) {
            \Log::error('File save failed: ' . $e->getMessage());
            return ['status' => false, 'message' => 'Error saving file.'];
        }

        // File size fallback
        $fileSize = filesize($filePath);

        // Save metadata in DB
        $fileRecord = \DB::table('at_upload_document_files')->insertGetId([
            'path' => $relativePath,
            'file_name' => $uniqueName,
            'original_name' => $fileName,
            'size' => $fileSize,
            'created_at' => now(),
        ]);

        return [
            'status' => true,
            'message' => 'File uploaded successfully.',
            'file_id' => $fileRecord,
            'file_name' => $uniqueName,
            'path' => $relativePath,
        ];
    }

    /**
     * Uploads a file to cloud storage.
     */
    private function uploadToCloud($file, string $directory, string $timestamp, string $uniqueName): array
    {
        $relativePath = "{$directory}/{$timestamp}/{$uniqueName}";
        $cloudUrl = "{$this->cloudConfig['server_url']}/upload";

        // Prepare data for cloud upload
        $response = Http::withHeaders([
            'Authorization' => "Bearer {$this->cloudConfig['api_key']}",
        ])->attach(
            'file',
            file_get_contents($file->getRealPath()),
            $uniqueName
        )->post($cloudUrl, [
            'path' => $this->cloudConfig['upload_path'] . "/{$relativePath}",
        ]);

        if ($response->successful()) {
            // Store metadata in the database
            $fileRecord = \DB::table('at_upload_document_files')->insertGetId([
                'path' => $relativePath,
                'file_name' => $uniqueName,
                'original_name' => $file->getClientOriginalName(),
                'size' => $file->getSize(),
                'created_at' => now(),
            ]);

            return [
                'status' => true,
                'message' => 'File uploaded successfully to cloud storage.',
                'file_id' => $fileRecord,
                'file_name' => $uniqueName,
                'path' => $relativePath,
            ];
        }

        return [
            'status' => false,
            'message' => 'Failed to upload file to cloud storage.',
        ];
    }

    /**
     * Adds an `index.php` file to prevent direct directory listing
     */
    /**
     * Decrypt and serve a file for download.
     */
    public function downloadFile(int $fileId)
    {
        $file = \DB::table('at_upload_document_files')->find($fileId);

        if (!$file) {
            abort(404, 'File not found.');
        }

        $filePath = "{$this->localRoot}/{$file->path}/{$file->file_name}";

        if (!File::exists($filePath)) {
            abort(404, 'File not found on server.');
        }

        if ($this->encryptFiles) {
            $decryptedContent = Crypt::decrypt(File::get($filePath), $this->encryptionKey);
            return response($decryptedContent, 200, [
                'Content-Type' => mime_content_type($filePath),
                'Content-Disposition' => "attachment; filename=\"{$file->original_name}\"",
            ]);
        }

        return response()->download($filePath, $file->original_name);
    }

    /**
     * Adds an index file to secure directories.
     */
    private function addIndexFile(string $directory): void
    {
        $indexFilePath = "{$directory}/index.php";
        if (!File::exists($indexFilePath)) {
            File::put(
                $indexFilePath,
                <<<PHP
    <?php
    header('HTTP/1.0 403 Forbidden');
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Access Denied</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f4f4f4;
                text-align: center;
                padding: 50px;
            }
            h1 {
                font-size: 50px;
                color: #e74c3c;
            }
            p {
                font-size: 20px;
                color: #555;
            }
        </style>
    </head>
    <body>
        <h1>Access Denied</h1>
        <p>You do not have permission to access this directory.</p>
    </body>
    </html>
    PHP
            );
        }

        $htaccessPath = "{$directory}/.htaccess";
        if (!File::exists($htaccessPath)) {
            File::put($htaccessPath, "Options -Indexes\n");
        }
    }
}

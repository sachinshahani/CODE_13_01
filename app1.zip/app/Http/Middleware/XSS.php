<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class XSS
{
    // public function handle(Request $request, Closure $next)
    // {
    //     // Only process POST requests
    //     if (!$request->isMethod('post')) {
    //         return $next($request);
    //     }

    //     $input = $request->all();
    //     $invalidCharacters = [];

    //     // Define patterns to detect invalid characters
    //     $patterns = [
    //         '/<\?php/i', '/script/i', '/alert/i', '/prompt/i',
    //         '/onmouseover/i', '/</', '/>/', '/&/', '/\|/', 
    //         '/;/', '/\$/', '/%/', '/\'/', '/"/', '/\//', 
    //         '/\(/', '/\)/', '/\+/', '/\?/', '/{/', '/}/', '/`/',  '/document/i',  '/window/i',  '/eval/i',  '/fetch/i',
    //         '/base64/i',  '/javascript:/i', '/vbscript:/i',
    //     ];

    //     // Check for invalid input and sanitize
    //     array_walk_recursive($input, function (&$value) use ($patterns, &$invalidCharacters) {
    //         foreach ($patterns as $pattern) {
    //             if (preg_match($pattern, $value)) {
    //                 $invalidCharacters[] = $value;
    //                 $value = preg_replace($pattern, '', $value); // Remove invalid characters
    //             }
    //         }
    //     });

    //     // If invalid characters are found
    //     if (!empty($invalidCharacters)) {
    //         $invalidCharsString = implode(', ', array_unique($invalidCharacters));
    //         session()->flash('error', "Invalid characters detected: $invalidCharsString. Please remove them and try again.");
    //         return redirect()->back()->withInput();
    //     }

    //     // Sanitize remaining input
    //     array_walk_recursive($input, function (&$value) {
    //         $value = htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
    //     });

    //     $request->merge($input);
    //     return $next($request);
    // }
    
    public function handle(Request $request, Closure $next)
    {
        // Only process POST requests
        if (!$request->isMethod('post')) {
            return $next($request);
        }

        // Get all request inputs, excluding files
        $input = $request->except($request->files->keys()); // Exclude file inputs from being validated
        $invalidCharacters = [];

        // Define patterns to detect invalid characters
        $patterns = [
            // '/<\?php/i', '/script/i', '/alert/i', '/prompt/i',
            // '/onmouseover/i', '/</', '/>/', '/&/', '/\|/', 
            // '/;/', '/\$/', '/%/', '/\'/', '/"/', '/\//', 
            // '/\(/', '/\)/', '/\+/', '/\?/', '/{/', '/}/', '/`/',  
            // '/document/i', '/window/i', '/eval/i', '/fetch/i',
            // '/base64/i', '/javascript:/i', '/vbscript:/i',
        ];

        // Check for invalid input and sanitize
        array_walk_recursive($input, function (&$value) use ($patterns, &$invalidCharacters) {
            foreach ($patterns as $pattern) {
                if (preg_match($pattern, $value)) {
                    $invalidCharacters[] = $value;
                    $value = preg_replace($pattern, '', $value); // Remove invalid characters
                }
            }
        });

        // If invalid characters are found
        if (!empty($invalidCharacters)) {
            $invalidCharsString = implode(', ', array_unique($invalidCharacters));
            session()->flash('error', "Invalid characters detected: $invalidCharsString. Please remove them and try again.");
            return redirect()->back()->withInput();
        }

        // Sanitize remaining input (still excluding files)
        array_walk_recursive($input, function (&$value) {
            $value = htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
        });

        // Merge the sanitized input back into the request
        $request->merge($input);

        return $next($request);
    }

}

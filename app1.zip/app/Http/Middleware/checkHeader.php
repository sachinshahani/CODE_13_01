<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Response;  
class checkHeader
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {   
        //return Response::json($_SERVER);
        if(!isset($_SERVER['HTTP_X_USER'])){  
            $response =  array(
                        'status' => false,
                        'message' => 'Please set custom header'
                    );
            return Response::json($response);  
        }  
  
        if($_SERVER['HTTP_X_USER'] != 'zur1xjb4'){  
            $response =  array(
                        'status' => false,
                        'message' => 'wrong custom header'
                    );
            return Response::json($response);
        }  
  
        return $next($request);  
    }
}

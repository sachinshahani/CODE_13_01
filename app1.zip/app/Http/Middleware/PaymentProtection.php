<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PaymentProtection
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        // Check if user is authenticated
        // if (!Auth::check()) {
        //     return redirect()->route('home')->withErrors(['message' => 'You must be logged in to access the payment system.']);
        // }

        // Optional: Check if the authenticated user has a specific role
        // $user = Auth::user();
        // if (!$user->hasRole(['admin', 'payment_manager'])) {
        //     return redirect()->back()->withErrors(['message' => 'You do not have permission to access the payment system.']);
        // }

        // Optional: Add more security checks if needed, e.g., rate limiting, IP check, etc.

        return $next($request); // Continue to the controller
    }
}

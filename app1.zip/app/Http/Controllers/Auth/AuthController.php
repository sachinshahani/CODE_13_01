<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\LoginRecord;
use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Mail;
use App\Models\AtSlider;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
//use RealRashid\SweetAlert\Facades\Alert;
use RealRashid\SweetAlert\Facades\Alert;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;


class AuthController extends Controller
{
    //

    protected $redirectTo = '/';

    protected $guard = 'misadmin';

    public function __construct()
    {
        $this->middleware('guest:misadmin')->except('logout');
    }

    // public function apedalogin()
    // {
    //     $sliders = AtSlider::where('status', 1)
    //     ->where('language', 'EN') 
    //     ->orderBy('created_at', 'desc')->get();
    //   // dd($sliders);
    //     return view('auth.login', compact('sliders'));
    // }
    public function apedalogin(Request $request)
    {

        // dd('sddsdfsfsdfdsfdsfdsfsdf');
        $language = $request->input('language', 'HI');


        $sliders = AtSlider::where('status', 1)->where('language', $language)->orderBy('created_at', 'desc')->get();


        return view('auth.login', compact('sliders'));
    }



    public function lab_login()
    {
        $sliders = AtSlider::where('status', 1)->orderBy('created_at', 'desc')->get();

        return view('auth.lab_login', compact('sliders'));
    }

    public function cb_login()
    {

        $sliders = AtSlider::where('status', 1)->orderBy('created_at', 'desc')->get();
        return view('auth.cb_login', compact('sliders'));
    }

    public function refreshCaptcha()
    {
        // echo captcha_img('flat');
        // exit;
        return captcha_img('math');
    }
    public function apedaregister()
    {
        $sliders = AtSlider::where('status', 1)->orderBy('created_at', 'desc')->get();

        return view('auth.register', compact('sliders'));
    }
    public function register(Request $request)
    {
        //dd($request->all());

        $rules = [

            'user_name' => 'required|string|max:255|unique:at_user',
            'mobile_no' => 'required|string|max:10|unique:at_user',
            // 'password' => 'required|string|confirmed',
        ];


        $messages = [
            'user_name.unique' => 'User Name is already taken. Please choose a different one.',
            'mobile_no.unique' => 'The mobile number is already in use. Please use a different one.',
            // 'password.confirmed' => 'The password confirmation does not match.',
        ];


        $request->validate($rules, $messages);

        $user = User::create([

            'first_name' => $request->input('first_name'),
            'user_name' => $request->input('user_name'),
            'email' => $request->input('email'),
            'mobile_no' => $request->input('mobile_no'),
            'password' => hash('sha256', $request->input('password')),
            'user_type' => 1,
            'ref_operator_type_id' => 103,

        ]);
        // dd($user);
        // $user->roles()->attach(1);

        return redirect()->route('cb_login');
    }

    // public function login(Request $request)
    // {
    //     $this->validate(
    //         $request,
    //         [
    //             'username' => 'required',
    //             'password' => 'required',
    //             'captcha' => 'required|captcha',
    //         ],
    //         [
    //             'captcha.captcha' => 'Invalid captcha code.',
    //         ]
    //     );

    //     try 
    //     {

    //         $userdata = User::with('roles')->where('user_name', $request->input('username'))
    //         ->first();


    //         if(isset($userdata) || !empty($userdata->created_by)) 
    //         {
    //             $createdByUser = User::find($userdata->created_by); 
    //             if($createdByUser && ($createdByUser->operator_status == 6 || $createdByUser->operator_status == 7 || $createdByUser->operator_status == 8)) 
    //             {
    //                 $Empyuserdata = User::where('created_by', $createdByUser->id)
    //                                     ->where('ref_operator_type_id', 9)
    //                                     ->get(); 
    //                 if ($Empyuserdata->count() > 0 && $userdata->ref_operator_type_id == 9) 
    //                 {
    //                     switch ($createdByUser->operator_status) 
    //                     {
    //                         case 6:
    //                             return redirect()->back()->with('error', 'Your Account Terminated');
    //                             break;
    //                         case 7:
    //                             return redirect()->back()->with('error', 'Your Account Suspended');
    //                             break;
    //                         case 8:
    //                             return redirect()->back()->with('error', 'Your Account Blocked');
    //                             break;
    //                     }
    //                 } 
    //             }
    //         }

    //         $user = User::where('user_name', $request->input('username'))
    //             ->where('user_type', 1)
    //             ->where('login_status', 1)
    //             ->first();

    //         if ($user && $user->ref_operator_type_id != 102) 
    //         {

    //             $userPass = hash('sha256', $user->password . session('salt'));
    //             if ($userPass != $request->password) 
    //             {

    //                 return redirect()->back()->with('error', 'Invalid Credentials.');
    //             }
    //             else
    //             {
    //                 if ($user->operator_status == 1) 
    //                 {
    //                     return redirect()->back()->with('error', 'Your account has been suspended.');
    //                 } 
    //                 elseif ($user->operator_status == 2) 
    //                 {
    //                     return redirect()->back()->with('error', 'Your account has been terminated.');
    //                 }
    //                 elseif ($user->operator_status == 3)
    //                 {
    //                     return redirect()->back()->with('error', 'Withdrawal By CB.');
    //                 }
    //                 elseif ($user->operator_status == 4)
    //                 {
    //                     return redirect()->back()->with('error', 'Withdrawal By Operator.');
    //                 }
    //                 elseif ($user->operator_status == 5) 
    //                 {
    //                     return redirect()->back()->with('error', 'De-d Registration.'); 
    //                 } 
    //                 elseif ($user->operator_status == 6) 
    //                 {
    //                     return redirect()->back()->with('error', 'Your account has been Terminated.'); 
    //                 } 
    //                 elseif ($user->operator_status == 7) 
    //                 {
    //                     return redirect()->back()->with('error', 'Your account has been Suspended.'); 
    //                 } 
    //                 elseif ($user->operator_status == 8) 
    //                 {
    //                     return redirect()->back()->with('error', 'Your account has been Blocked.'); 
    //                 }
    //                 else 
    //                 {
    //                     if ($user->first_change_password == 0) 
    //                     {
    //                         Auth::guard('misadmin')->loginUsingId($user->id);
    //                         return redirect()->route('superadmin.chnageFirstPassword');
    //                     }
    //                     else 
    //                     {
    //                         Auth::guard('misadmin')->loginUsingId($user->id);
    //                         if ($user->ref_operator_type_id == 101) 
    //                         {
    //                             $name = $userdata->first_name;
    //                             $username = $userdata->roles[0]->title;
    //                             $type = $userdata->id;
    //                             $user_action = "Login Successfully";
    //                          
                                //logHistory($name, $username, $type, $user_action);
    //                             return redirect()->route('superadmin.admin.dashboard');
    //                         }
    //                         // if ($user->ref_operator_type_id == 102) {

    //                         //     return redirect()->route('lab_login');
    //                         // }
    //                         else 
    //                         {


    //                             // $name = $userdata->first_name;
    //                             // $username = $userdata->roles[0]->title;
    //                             // $type = $userdata->id;
    //                             // $user_action = "Login Successfully";
    //                             $this->// logHistory($name, $username, $type, $user_action);
                                // logHistory($name, $username, $type, $user_action);

    //                             $name = $userdata->first_name;

    //                             // Check if the user has any roles and access the first role if it exists
    //                             if (isset($userdata->roles[0])) 
    //                             {
    //                                 $username = $userdata->roles[0]->title;
    //                             } 
    //                             else 
    //                             {
    //                                 // Set a default value if no roles are assigned
    //                                 $username = 'No role assigned';
    //                             }

    //                             $type = $userdata->id;
    //                             $user_action = "Login Successfully";

    //                             // Call the logHistory function with the appropriate variables
                                //logHistory($name, $username, $type, $user_action);

    //                             return redirect()->route('superadmin.dashboard');
    //                         }
    //                     }
    //                 }
    //             }
    //         } 
    //         else 
    //         {
    //             return redirect()->back()->with('error', 'Invalid Credentials.');
    //         }
    //     } 
    //     catch (Exception $e) 
    //     {
    //         Log::error($e);
    //         return redirect()->back()->with('error', 'Invalid Credentials.');
    //     }
    // }

    // new login code 


    public function login(Request $request)
    {

        $validator = Validator::make(
            $request->all(),
            [
                'username' => 'required',
                'password' => 'required',
                'captcha' => 'required|captcha',
            ],
            [
                'captcha.captcha' => 'Invalid captcha code.',
            ]
        );

        if ($validator->fails()) {
            return response()->json([
                'message' => 'Validation Error',
                'errors' => $validator->errors(),
            ], 422);
        }

        try {



            $userdatamultipeusebyPAN = User::where('user_name', $request->input('username'))
                ->where('user_type', 1)
                ->where('login_status', 1)
                ->where('status', '!=', 3)
                ->select('id', 'ref_operator_type_id', 'user_name', 'password')
                ->get();
            if (!empty($userdatamultipeusebyPAN) && isset($userdatamultipeusebyPAN)) {
                $shouldid = count($userdatamultipeusebyPAN) > 1;
                if ($shouldid) {
                    foreach ($userdatamultipeusebyPAN as $user) {
                        $userPass = hash('sha256', $user['password'] . session('salt'));
                        if ($userPass == $request->password) {
                            return response()->json(['data' => $userdatamultipeusebyPAN]);
                        }
                    }
                    return response()->json(['message' => 'Invalid Credentials'], 401);
                }
            }

            $userdata = User::with('roles')->where('user_name', $request->input('username'))->where('status', '!=', 3)->first();
            if (isset($userdata) || !empty($userdata->created_by)) {

                $createdByUser = User::find($userdata->created_by);
                if ($createdByUser && ($createdByUser->operator_status == 6 || $createdByUser->operator_status == 7 || $createdByUser->operator_status == 8)) {
                    $Empyuserdata = User::where('created_by', $createdByUser->id)
                        ->where('ref_operator_type_id', 9)
                        ->get();
                    if ($Empyuserdata->count() > 0 && $userdata->ref_operator_type_id == 9) {
                        switch ($createdByUser->operator_status) {
                            case 6:
                                return response()->json(['message' => 'Your Account Terminated'], 403);
                                break;
                            case 7:
                                return response()->json(['message' => 'Your Account Suspended'], 403);
                                break;
                            case 8:
                                return response()->json(['message' => 'Your Account Blocked'], 403);
                                break;
                        }
                    }
                }
            }

            $user = User::where('user_name', $request->input('username'))
                ->where('user_type', 1)
                ->where('login_status', 1)
                ->first();
            if (empty($user)) {
                return response()->json(['message' => 'This username you entered does not exist.'], 404);
            }

            if ($user->status == 3) {
                return redirect()->back();
            }
            if ($user && $user->ref_operator_type_id != 102) {

                $userPass = hash('sha256', $user->password . session('salt'));
                if ($userPass != $request->password) {
                    return response()->json(['message' => 'Invalid Credentials'], 401);
                } else {
                    if ($user->operator_status == 1) {
                        return response()->json(['message' => 'Your account has been suspended.'], 403);
                    } elseif ($user->operator_status == 2) {
                        return response()->json(['message' => 'Your account has been terminated.'], 403);
                    } elseif ($user->operator_status == 3) {
                        return response()->json(['message' => 'Withdrawal By CB.'], 403);
                    } elseif ($user->operator_status == 4) {
                        return response()->json(['message' => 'Withdrawal By Operator.'], 403);
                    } elseif ($user->operator_status == 5) {
                        return response()->json(['message' => 'De-d Registration.'], 403);
                    } elseif ($user->operator_status == 6) {
                        return response()->json(['message' => 'Your account has been Terminated.'], 403);
                    } elseif ($user->operator_status == 7) {
                        return response()->json(['message' => 'Your account has been Suspended.'], 403);
                    } elseif ($user->operator_status == 8) {
                        return response()->json(['message' => 'Your account has been Blocked.'], 403);
                    } else {

                        if ($user->first_change_password == 0) {
                            Auth::guard('misadmin')->loginUsingId($user->id);
                            return response()->json(['redirectUrl' => route('superadmin.chnageFirstPassword')]);
                        } else {
                            Auth::guard('misadmin')->loginUsingId($user->id);
                            if ($user->ref_operator_type_id == 101) {
                                $name = $userdata->first_name;
                                $username = $userdata->roles[0]->title;
                                $type = $userdata->id;
                                $user_action = "Login Successfully";
                                $this->storeUserSession($type, $user_action);
                                $this->logHistory($name, $username, $type, $user_action);
                                // logHistory($name, $username, $type, $user_action);
                                // return redirect()->route('superadmin.admin.dashboard');
                                return response()->json(['redirectUrl' => route('superadmin.admin.dashboard')]);
                            }
                            // if ($user->ref_operator_type_id == 102) {

                            //     return redirect()->route('lab_login');
                            // }
                            else {


                                $name = $userdata->first_name;
                                $username = $userdata->roles[0]->title;
                                $type = $userdata->id;
                                $user_action = "Login Successfully";
                                $this->storeUserSession($type, $user_action);
                                $this->logHistory($name, $username, $type, $user_action);
                                //logHistory($name, $username, $type, $user_action);

                                $name = $userdata->first_name;

                                // Check if the user has any roles and access the first role if it exists
                                if (isset($userdata->roles[0])) {
                                    $username = $userdata->roles[0]->title;
                                } else {
                                    // Set a default value if no roles are assigned
                                    $username = 'No role assigned';
                                }
                                // dd($username);

                                $type = $userdata->id;
                                // dd()
                                $user_action = "Login Successfully";

                                // Call the logHistory function with the appropriate variables
                               
                                $this->logHistory($name, $username, $type, $user_action);
                                // logHistory($name, $username, $type, $user_action);

                                //return redirect()->route('superadmin.dashboard');
                                return response()->json(['redirectUrl' => route('superadmin.dashboard')]);
                            }
                        }
                    }
                }
            } else {
                return response()->json(['message' => 'Invalid Credentials'], 401);
            }
        } catch (ThrottleRequestsException $e) {
            // Handle Throttle (429) Exception
            Log::debug('ThrottleRequestsException occurred', ['exception' => $e]);
            return response()->json([
                'message' => 'Too Many Attempts. Please try again later.',
                'redirectUrl' => route('429'),
            ], 429);
        } catch (Exception $e) {
            // Handle any general exceptions
            Log::error($e);
            return response()->json(['message' => 'An error occurred. Please try again later.'], 500);
        }
    }





    public function apedaloginRolesSelect(Request $request)
    {

        $rolesuserID = $request->input('Roles');
        return view('auth.templateloginroles', compact('rolesuserID'))->render();
    }


    public function apedaloginRolesstore(Request $request)
    {

        //    dd($request->all());
        $Id = $request->input('user_id');
        $operator_type_id = $request->input('roles_user_id');
        $user = User::where('id', $Id)->where('ref_operator_type_id', $operator_type_id)->first();
        // dd($user);       
        if ($user->first_change_password == 0) {
            Auth::guard('misadmin')->loginUsingId($user->id);
            return  redirect()->route('superadmin.chnageFirstPassword');
        } else {
            Auth::guard('misadmin')->loginUsingId($user->id);
            return  redirect()->route('superadmin.admin.dashboard');
        }
    }
    // end 

    // public function login_cb(Request $request)
    // {
    //     $this->validate(
    //         $request,
    //         [
    //             'username' => 'required',
    //             'password' => 'required',
    //             'captcha' => 'required|captcha',
    //         ],
    //         [
    //             'captcha.captcha' => 'Invalid captcha code.',
    //         ]
    //     );

    //     try {
    //         $user = User::where('user_name', $request->input('username'))
    //             ->where('user_type', 1)
    //             ->where('login_status', 1)
    //             ->first();

    //         if ($user && $user->ref_operator_type_id !=102)
    //         {

    //             $userPass = hash('sha256', $user->password . session('salt'));
    //             if ($userPass != $request->password) {
    //                 return redirect()->back()->with('error', 'Invalid Credentials.');
    //             }
    //              else
    //               {
    //                 if ($user->operator_status == 1) {
    //                     return redirect()->back()->with('error', 'Your account has been suspended.');
    //                 } elseif ($user->operator_status == 2) {
    //                     return redirect()->back()->with('error', 'Your account has been terminated.');
    //                 } elseif ($user->operator_status == 3) {
    //                     return redirect()->back()->with('error', 'Withdrawal By CB.');
    //                 }
    //                 elseif ($user->operator_status == 4) {
    //                     return redirect()->back()->with('error', 'Withdrawal By Operator.');
    //                 }
    //                 elseif ($user->operator_status == 5) {
    //                     return redirect()->back()->with('error', 'De-d Registration.');
    //                 } else {

    //                         if ($user->first_change_password == 0) {
    //                             Auth::guard('misadmin')->loginUsingId($user->id);
    //                             return redirect()->route('superadmin.chnageFirstPassword');
    //                         }

    //                     else
    //                     {
    //                         Auth::guard('misadmin')->loginUsingId($user->id);
    //                         if ($user->ref_operator_type_id == 103) {
    //                             return redirect()->route('superadmin.admin.Cbdashboard');
    //                         }
    //                         // if ($user->ref_operator_type_id == 102) {

    //                         //     return redirect()->route('lab_login');
    //                         // }
    //                         else {
    //                             return redirect()->route('superadmin.dashboard');
    //                         }
    //                     }
    //                 }
    //             }
    //         }
    //         else {
    //             return redirect()->back()->with('error', 'Invalid Credentials.');
    //         }
    //     } catch (Exception $e) {
    //         Log::error($e);
    //         return redirect()->back()->with('error', 'Invalid Credentials.');
    //     }
    // }

    public function login_cb(Request $request)
    {
        $this->validate(
            $request,
            [
                'username' => 'required',
                'password' => 'required',
                'captcha' => 'required|captcha',
            ],
            [
                'captcha.captcha' => 'Invalid captcha code.',
            ]
        );

        try {
            $user = User::where('user_name', $request->input('username'))
                ->where('user_type', 1)
                ->where('login_status', 1)
                ->first();

            if ($user && $user->ref_operator_type_id != 102) {
                $userPass = hash('sha256', $user->password . session('salt'));
                if ($userPass != $request->password) {
                    return redirect()->back()->with('error', 'Invalid Credentials.');
                } else {
                    if ($user->operator_status == 1) {
                        return redirect()->back()->with('error', 'Your account has been suspended.');
                    } elseif ($user->operator_status == 2) {
                        return redirect()->back()->with('error', 'Your account has been terminated.');
                    } elseif ($user->operator_status == 3) {
                        return redirect()->back()->with('error', 'Withdrawal By CB.');
                    } elseif ($user->operator_status == 4) {
                        return redirect()->back()->with('error', 'Withdrawal By Operator.');
                    } elseif ($user->operator_status == 5) {
                        return redirect()->back()->with('error', 'De-d Registration.');
                    } else {
                        Auth::guard('misadmin')->loginUsingId($user->id);
                        if ($user->ref_operator_type_id == 103) {
                            return redirect()->route('superadmin.admin.Cbdashboard');
                        } else {
                            return redirect()->route('superadmin.dashboard');
                        }
                    }
                }
            } else {
                return redirect()->back()->with('error', 'Invalid Credentials.');
            }
        } catch (Exception $e) {
            Log::error($e);
            return redirect()->back()->with('error', 'Invalid Credentials.');
        }
    }


    public function login_lab(Request $request)
    {
        // dd($request->all());

        $this->validate(
            $request,
            [
                'username' => 'required',
                'password' => 'required',
                'captcha' => 'required|captcha',
            ],
            [
                'captcha.captcha' => 'Invalid captcha code.',
            ]
        );

        try {
            $user = User::where('user_name', $request->input('username'))
                ->where('user_type', 1)
                ->where('login_status', 1)
                ->where('lab_id', $request->input('ref_laboratory_master_id'))
                ->first();




            if ($user) {
                $userPass = hash('sha256', $user->password . session('salt'));
                if ($userPass != $request->password) {
                    return redirect()->back()->with('error', 'Invalid Credentials.');
                } else {
                    if ($user->operator_status == 1) {
                        return redirect()->back()->with('error', 'Your account has been suspended.');
                    } elseif ($user->operator_status == 2) {
                        return redirect()->back()->with('error', 'Your account has been terminated.');
                    } elseif ($user->operator_status == 3) {
                        return redirect()->back()->with('error', 'Withdrawal By CB.');
                    } elseif ($user->operator_status == 4) {
                        return redirect()->back()->with('error', 'Withdrawal By Operator.');
                    } elseif ($user->operator_status == 5) {
                        return redirect()->back()->with('error', 'De-d Registration.');
                    } else {

                        if ($user->first_change_password == 0) {
                            Auth::guard('misadmin')->loginUsingId($user->id);
                            return redirect()->route('superadmin.chnageFirstPassword');
                        } else {
                            Auth::guard('misadmin')->loginUsingId($user->id);

                            if ($user->ref_operator_type_id == 102) {

                                return redirect()->route('superadmin.lab.dashboard');
                            }
                        }
                    }
                }
            } else {
                return redirect()->back()->with('error', 'Invalid Credentials.');
            }
        } catch (Exception $e) {
            Log::error($e);
            return redirect()->back()->with('error', 'Invalid Credentials.');
        }
    }



    public function logout(Request $request)
    {

        $username = Auth::guard('misadmin')->user()->roles[0]->title ?? '0';
        $name = Auth::guard('misadmin')->user()->first_name;
        $type = Auth::guard('misadmin')->user()->id;
        $user_action = "Logout Successfully";
        $this->logHistory($name, $username, $type, $user_action);
        //logHistory($name, $username, $type, $user_action);
        Auth::guard('misadmin')->logout();
        $request->session()->flush();

        return redirect()->route('apeda');
    }



    public function showForgetPasswordForm()
    {
        $sliders = AtSlider::where('status', 1)->orderBy('created_at', 'desc')->get();

        return view('auth.forgetpassword', compact('sliders'));
    }

    // public function sendMailForgetPassword(Request $request)
    // {
    //     $this->validate($request, [
    //         'username' => 'required',
    //     ]);

    //     $emails = $request->username;

    //     $maildata  = ['send_message' => "<strong> Dear User <br>
    //      <a href=" . url('/change-password', encrypt($emails)) . ">Click here </a> for Reset Password. "];

    //     Mail::send('mail.inspector_register', $maildata, function ($message) use ($emails) {  // use mail template in view/api folder
    //         $message->subject("Apeda Reset Password"); // Email subject body
    //         $message->to($emails);
    //     });

    //     return redirect()->back()->with('success', 'Mail has been sent Successfully .');
    // }

    public function sendMailForgetPassword(Request $request)
    {
        $this->validate($request, [
            'username' => 'required',
        ]);

        $emails = $request->username;
        $user = User::select('id')->where('email', $emails)->first();

        if (!$user) {
            return redirect()->back()->with('error', 'User not found.');
        }

        $maildata = [
            'send_message' => "<strong> Dear User, <br>
         <a href=" . url('/change-password', encrypt($emails)) . ">Click here </a> for Reset Password. ",
            'userId' => $user->id
        ];

        Mail::send('mail.inspector_register', $maildata, function ($message) use ($emails) {
            $message->subject("Apeda Reset Password");
            $message->to($emails);
        });

        return redirect()->back()->with('success', 'Mail has been sent Successfully.');
    }


    public function changePassword($email)
    {
        $emailData = decrypt($email);
        return view('auth.changepassword', ["emailData" => $emailData]);
    }
    public function submitForgetPasswordForm(Request $request)
    {

        $this->validate($request, [

            'passwords' => 'required|min:6',
            'confirm_password' => 'required|min:6|same:passwords',

        ]);

        $token = Str::random(64);

        $password = hash('sha256', $request->passwords);
        $username = $request->username;


        $user = User::where('email', $username)
            ->where('user_type', '=', 1)
            ->where('status', 1)
            ->first();

        if ($user) {
            User::where('email', $user->user_name)->update(['password' => $password]);
            // dd(493);
            $emails = $user->email;
            $maildata  = ['send_message' => "<strong> Dear " . $user->first_name . "</strong><br> Your password has been reset successfully.<br> Your Credentials has given below :- <br><strong> Username : " . $user->user_name . " <br><strong> Password : " . $request->passwords . " <br> </strong> <br> <a href=" . url('/') . ">Click here </a> for login "];

            Mail::send('mail.inspector_register', $maildata, function ($message) use ($emails) {  // use mail template in view/api folder
                $message->subject("Apeda Reset Password"); // Email subject body
                $message->to($emails);
            });


            // Auth::guard('misadmin')->loginUsingId($user->id);

            return redirect()->route('apeda')->with('success', 'Password has been changed Successfully.');
        } else {

            return redirect()->back()->with('error', 'Invalid User.');
        }
        // DB::table('password_resets')->insert([
        //     'email' => $request->email,
        //     'token' => $token,
        //     'created_at' => Carbon::now()
        //   ]);

        Mail::send('emails.forgetPassword', ['token' => $token], function ($message) use ($request) {
            $message->to($request->email);
            $message->subject('Reset Password');
        });
        Alert::success('Success', 'We have e-mailed your password reset link!');
        return redirect()->route('forget.password.get')->with('message', 'We have e-mailed your password reset link!');
    }


    private function storeUserSession($type, $user_action)
    {
        if ($type) {
            $ipAddress =  $_SERVER['REMOTE_ADDR']; // Get user's IP address
            $userAgent = request()->header('User-Agent'); // Get user-agent string
            $payload = json_encode(Session::all()); // Get current session data
            $lastActivity = time(); // Timestamp for last activity
            
            $data = [
                'user_id'                  => $type,
                'at_user_login_details_id' => null,
                'ip_address'               => $ipAddress,
                'user_agent'               => $userAgent,
                'payload'                  => $payload,
                'last_activity'            => $lastActivity,
            ];
            //print_r($data); die;
            $inserted = DB::table('at_user_sessions')->insert($data);
            return $inserted ? 1 : 0; // Return 1 for success, 0 for failure
        }
            
    }
    

    private function getDeviceType($userAgent)
    {
        if (preg_match('/mobile/i', $userAgent)) {
            return 'Mobile';
        } elseif (preg_match('/tablet/i', $userAgent)) {
            return 'Tablet';
        } elseif (preg_match('/desktop|windows|macintosh/i', $userAgent)) {
            return 'Desktop';
        } else {
            return 'Unknown';
        }
    }


    private function logHistory($name, $username, $type, $user_action)
    {
        if ($username) {
            $device_name = request()->header('User-Agent'); // Extract device name from User-Agent header
            $device_type = $this->getDeviceType($device_name); 
            $data = [
                "user_name"   => $name,
                "user_type"   => $username,
                "user_id"     => $type,
                "ip_address"  => $_SERVER['REMOTE_ADDR'],
                'device_name' => $device_name,
                'device_type' => $device_type,
                "user_action" => $user_action,
                "action_url"  => url()->full(),
                "created_on"  => now(),
            ];

            $inserted = DB::table('log_history')->insert($data);

            return $inserted ? 1 : 0; // Return 1 for success, 0 for failure
        }

        return 0; // Return 0 if $username is not provided
    }

   

}

<?php

namespace App\Http\Controllers\DigitalSignature;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Permission;
use App\Models\User;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;
use App\Models\eMSignerCertificateModal;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class emudhraeSignController extends Controller
{
    protected $eSignType;
    protected $licenceFilePath;
    protected $pfxPath;
    protected $pfxPassword;
    protected $pfxAlias;
    protected $proxyReq;
    protected $proxyIp;
    protected $proxyPort;
    protected $proxyUserID;
    protected $proxyUserPassword;
    protected $redirectURL;
    protected $responseURL;
    protected $tempFolderPath;
    protected $resolveFilePaths;

    protected $generateBase64Encode;
    protected $inputPath;
    protected $outputPath;
    protected $cliPath;
    protected $sessionTimeout;
    protected $scopCoordinates;
    protected $tcCoordinates;
    protected $registrationCoordinates;
    protected $internalStockCoordinates;
    protected $genrateTransactionStatusFile;
    protected $genrateSignedDataFile;
    protected $inputTransactionStatus;
    protected $outputTransactionStatus;
    protected $fileUrl;
    protected $coordinates;
    protected $findTransactionStatusFile;
    protected $transactionStatus;
    protected $getSignedOutput;
    protected $getSignedInput;
    protected $createSignedFile;
    protected $findSignedFileFile;
    protected $updateSignedInput;
    protected $generateSignedPdfData;
    protected $SignedPdfs;
    protected $rootPath;
    protected $filePutContent;
    protected $nocCoordinates;

    public function __construct()
    {
        if (app()->environment('production')) {
            $this->licenceFilePath = env('SIGNATURE_LICENCEPATH_PROD');
            $this->pfxPath = env('SIGNATURE_PFXPATH_PROD');
            $this->pfxPassword = env('SIGNATURE_PFXPASSWORD_PROD');
        } else {
            $this->licenceFilePath = env('SIGNATURE_LICENCEPATH_DEV');
            $this->pfxPath = env('SIGNATURE_PFXPATH_DEV');
            $this->pfxPassword = env('SIGNATURE_PFXPASSWORD_DEV', 'emudhra');
        }

        //eMsigner Auth Version
        $this->eSignType = env('SIGNATURE_ESIGN_TYPE');


        //eMsigner Basic Configration
        $this->pfxAlias = env('SIGNATURE_PFXALIAS');
        $this->proxyReq = env('SIGNATURE_PROXYREQ');
        $this->proxyIp = env('SIGNATURE_PROXYIP');
        $this->proxyPort = env('SIGNATURE_PROXYPORT');
        $this->proxyUserID = env('SIGNATURE_PROXYUSERID');
        $this->proxyUserPassword = env('SIGNATURE_PROXYUSERPASSWORD');
        $this->sessionTimeout = env('SIGNATURE_SESSIONTIMEOUT');
        $this->redirectURL = env('SIGNATURE_REDIRECTURL');
        $this->responseURL = env('SIGNATURE_RESPONSEURL');

        //eMudhra Path/Folder Configration
        $this->rootPath = env('SIGNATURE_ROOT_PATH');
        $this->tempFolderPath = env('SIGNATURE_TEMPFOLDER');

        //Input/Output Path/Folder
        $this->inputPath = env('SIGNATURE_INPUTSFOLDER');
        $this->outputPath = env('SIGNATURE_OUTPUTFOLDER');

        //Transaction Path/Folder
        $this->inputTransactionStatus = env('SIGNATURE_TRANSACTIONSTATUSINPUT');
        $this->outputTransactionStatus = env('SIGNATURE_TRANSACTIONSTATUSOUTPUTS');

        //Signed In/Out Path/Folder
        $this->getSignedOutput = env('SIGNATURE_GETSINNEDPDFOUTPUTS');
        $this->getSignedInput = env('SIGNATURE_GETSINNEDPDFINPUTS');

        //Signed PDFS Path/Folder
        $this->SignedPdfs = env('SIGNATURE_SINNEDPDFS');

        //eMsigner cli Path/Folder
        $this->cliPath = env('SIGNATURE_CLI_PATH');

        //Page Coordinates
        $this->scopCoordinates = env('SIGNATURE_COORDINATES_SCOP');
        $this->tcCoordinates = env('SIGNATURE_COORDINATES_TC');
        $this->registrationCoordinates = env('SIGNATURE_COORDINATES_REGISTRAION');
        $this->internalStockCoordinates = env('SIGNATURE_COORDINATES_ICT');
        $this->nocCoordinates = env('SIGNATURE_COORDINATES_NOC');
    }
    //File Path Finder Fucntion
    private function resolveFilePaths(string $fileName, string $path, string $storageType): array
    {
        $host = request()->getSchemeAndHttpHost(); // e.g., https://staging1.apeda.in
        $cleanedPath = str_replace('public/', '', $path); // Ensure consistent path for public files
        $fileUrl = '';
        $directoryPath = '';

        if ($storageType === 'public') {
            $fileUrl = $host . '/public/' . $cleanedPath . '/' . $fileName;
            $directoryPath = public_path($cleanedPath . '/' . $fileName);
        } elseif ($storageType === 'storage') {
            $fileUrl = $host . '/storage/' . $path . '/' . $fileName;
            $directoryPath = storage_path('app/' . $path . '/' . $fileName);
        } else {
            throw new \InvalidArgumentException('Invalid file storage location.');
        }

        if (!file_exists($directoryPath)) {
            throw new \Exception('File not found: ' . $directoryPath);
        }

        return [
            'hostPath' => $fileUrl,
            'directoryPath' => $directoryPath,
        ];
    }

    //File Base 64 Encode Fucntion
    private function generateBase64Encode(Request $request)
    {
        $request->validate([
            'file_name' => 'required|string',
            'path' => 'required|string',
            'storage_type' => 'required|string',
        ]);

        try {
            $filePaths = $this->resolveFilePaths(
                $request->input('file_name'),
                $request->input('path'),
                $request->input('storage_type')
            );

            // Read and encode the file content
            $fileContent = file_get_contents($filePaths['directoryPath']);
            return base64_encode($fileContent);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 400);
        }
    }
    /**
     * Writes content to a file and ensures the directory exists.
     *
     * @param string $directoryPath The directory where the file should be saved.
     * @param string $fileName The name of the file.
     * @param string $content The content to write to the file.
     * @throws \Exception If the content cannot be written to the file.
     */
    private function filePutContent(string $directoryPath, string $fileName, string $content)
    {
        // Ensure the directory exists
        if (!is_dir($directoryPath)) {
            if (!mkdir($directoryPath, 0777, true) && !is_dir($directoryPath)) {
                throw new \Exception("Failed to create directory: $directoryPath");
            }
        }

        // Combine directory and file name to get the full path
        $filePath = $directoryPath . DIRECTORY_SEPARATOR . $fileName;

        // Write the content to the file
        if (file_put_contents($filePath, $content) === false) {
            throw new \Exception("Failed to write to file: $filePath");
        }

        // Set permissions to 777
        chmod($filePath, 0777);

        // Return the file path for confirmation or further processing
        return $filePath;
    }

    private function coordinates(Request $request)
    {
        $request->validate([
            'docName' => 'required|string',
        ]);

        $coordinatesMapping = [
            'SCC' => $this->scopCoordinates,
            'TCC' => $this->tcCoordinates,
            'RC'  => $this->registrationCoordinates,
            'IST'  => $this->internalStockCoordinates,
            'NOC'  => $this->nocCoordinates,
        ];

        $docName = $request->input('docName');
        if (array_key_exists($docName, $coordinatesMapping)) {
            return $coordinatesMapping[$docName];
        }

        return response()->json(['error' => 'Coordinates not found.'], 404);
    }

    private function findTransactionStatusFile($transactionID)
    {
        // Construct the file name using the transaction ID
        $inputFileName = "getTransactionStatus_Input_{$transactionID}.json";
        $outputFileName = "getTransactionStatus_Output_{$transactionID}.json";

        // Build the full file path
        $filePathInput = $this->inputTransactionStatus . DIRECTORY_SEPARATOR . $inputFileName;
        $filePathOutput = $this->outputTransactionStatus . DIRECTORY_SEPARATOR . $outputFileName;

        // Check if the file exists in the folder
        if (file_exists($filePathInput)) {
            // File exists, return the file path in the response
            return response()->json([
                'status' => 'success',
                'message' => 'File found.',
                'inputFilePath' => $filePathInput,
                'outputFilePath' => $filePathOutput,
            ]);
        } else {
            // File does not exist, return an error response
            return response()->json([
                'status' => 'error',
                'message' => 'File not found.',
                'filePath' => null,
            ], 404);
        }
    }

    private function createSignedFile($transactionID)
    {
        // Construct the file name using the transaction ID
        $fileNameOutput = "getSignedPdf_Output_{$transactionID}.json";
        $fileNameInput = "getSignedPdf_Input_{$transactionID}.json";

        if (!is_dir($this->getSignedOutput)) {
            mkdir($this->getSignedOutput, 0777, true);
        }
        if (!is_dir($this->getSignedInput)) {
            mkdir($this->getSignedOutput, 0777, true);
        }
        // Build the full file path
        $filePathOutput = $this->getSignedOutput . DIRECTORY_SEPARATOR . $fileNameOutput;
        $filePathInput = $this->getSignedInput . DIRECTORY_SEPARATOR . $fileNameInput;

        file_put_contents($filePathOutput, '');

        // Check if the file exists in the folder
        if (file_exists($filePathOutput)) {
            // File exists, return the file path in the response
            return response()->json([
                'status' => 'success',
                'message' => 'File found.',
                'filePathOutput' => $filePathOutput,
                'filePathInput' => $filePathInput
            ]);
        } else {
            // File does not exist, return an error response
            return response()->json([
                'status' => 'error',
                'message' => 'File not found.',
                'filePath' => null,
            ], 404);
        }
    }

    private function genrateSignedDataFile(array $data)
    {
        if (!isset($data['transactionID']) || empty($data['transactionID'])) {
            throw new \InvalidArgumentException("transactionID is required.");
        }
        $transactionID = $data['transactionID'];
        $getSignedPdfResponse = $this->createSignedFile($transactionID);
        $getSignedPdfFile = json_decode($getSignedPdfResponse->getContent(), true);

        if ($getSignedPdfFile['status'] === "success") {
            $signedPdfInputPath = $getSignedPdfFile['filePathInput'] ?? null;
            $signedPdfOutputPath = $getSignedPdfFile['filePathOutput'] ?? null;
        } else {
            return response()->json([
                'error' => 'Signed Input Sign File not found',
            ], 400);
        }
        $setSignedPdfData = [
            "transactionID" => $data['transactionID'],
            "responseXML" => $data['responseXML'],
            "status" => $data['status'],
            "responseCode" => $data['responseCode'],
            "gatewayParameter" => $data['gatewayParameter'],
            "preSignedTempFile" => $data['preSignedTempFile'],
            "licenceFilePath" => $this->licenceFilePath,
            "pfxPath" => $this->pfxPath,
            "pfxPassword" => $this->pfxPassword,
            "pfxAlias" => $this->pfxAlias,
            "proxyReq" => $this->proxyReq,
            "proxyIp" => $this->proxyIp,
            "proxyPort" => $this->proxyPort,
            "sessionTimeout" => $this->sessionTimeout,
            "proxyUserID" => $this->proxyUserID,
            "proxyUserPassword" => $this->proxyUserPassword,
        ];
        // Save JSON data to the file
        file_put_contents($signedPdfInputPath, json_encode($setSignedPdfData, JSON_UNESCAPED_SLASHES));

        // Return the generated file name
        if (file_exists($signedPdfInputPath)) {
            // File exists, return the file path in the response
            return response()->json([
                'status' => 'success',
                'message' => 'Signed PDF File found.',
                'signedPdfOutput' => $signedPdfOutputPath,
                'signedPdfInput' => $signedPdfInputPath
            ]);
        } else {
            // File does not exist, return an error response
            return response()->json([
                'status' => 'error',
                'message' => 'File not found.',
                'filePath' => null,
            ], 404);
        }
    }

    private function updateSignedInput(array $data)
    {

        if (!isset($data['transactionID']) || empty($data['responseXML']) || empty($data['transactionID'])) {
            throw new \InvalidArgumentException("responseXML is required.");
        }
        $transactionID = $data['transactionID'];
        $responseXML = $data['responseXML'];
        $preSignedTempFile = $data['preSignedTempFile'];

        $getSignedPdfResponse = $this->createSignedFile($transactionID);
        $getSignedPdfFile = json_decode($getSignedPdfResponse->getContent(), true);

        if ($getSignedPdfFile['status'] === "success") {
            $signedPdfInputPath = $getSignedPdfFile['filePathInput'] ?? null;
            $signedPdfOutputPath = $getSignedPdfFile['filePathOutput'] ?? null;
            $response = json_decode(file_get_contents($signedPdfInputPath), true); //print_r($response); die;

            $updatedSignedPdfData = [
                "transactionID" => $data['transactionID'],
                "responseXML" => $responseXML,
                "status" => $response['status'],
                "responseCode" => $response['responseCode'],
                "gatewayParameter" => $response['gatewayParameter'],
                "preSignedTempFile" => $preSignedTempFile,
                "licenceFilePath" => $this->licenceFilePath,
                "pfxPath" => $this->pfxPath,
                "pfxPassword" => $this->pfxPassword,
                "pfxAlias" => $this->pfxAlias,
                "proxyReq" => $this->proxyReq,
                "proxyIp" => $this->proxyIp,
                "proxyPort" => $this->proxyPort,
                "sessionTimeout" => $this->sessionTimeout,
                "proxyUserID" => $this->proxyUserID,
                "proxyUserPassword" => $this->proxyUserPassword,

            ];
            // Save JSON data to the file
            file_put_contents($signedPdfInputPath, json_encode($updatedSignedPdfData, JSON_UNESCAPED_SLASHES));
        } else {
            return response()->json([
                'error' => 'Signed Input Sign File not found',
            ], 400);
        }

        if (file_exists($signedPdfInputPath)) {
            // File exists, return the file path in the response
            return response()->json([
                'status' => 'success',
                'message' => 'File Updated.',
                'filePathInput' => $signedPdfInputPath,
                'filePathoutput' => $signedPdfOutputPath,
            ]);
        } else {
            // File does not exist, return an error response
            return response()->json([
                'status' => 'error',
                'message' => 'File not found.',
                'filePath' => null,
            ], 404);
        }
    }

    private function genrateTransactionStatusFile(array $data)
    {
        if (!isset($data['transactionID']) || empty($data['transactionID'])) {
            throw new \InvalidArgumentException("transactionID is required.");
        }

        $transactionID = $data['transactionID'];
        $transactionStatusData = [
            "transactionID" => $transactionID,
            "pfxPath" => $this->pfxPath,
            "licenceFilePath" => $this->licenceFilePath,
            "pfxPassword" => $this->pfxPassword,
            "pfxAlias" => $this->pfxAlias,
            "proxyIp" => $this->proxyIp,
            "proxyPort" => $this->proxyPort,
            "sessionTimeout" => $this->sessionTimeout,
            "proxyUserID" => $this->proxyUserID,
            "proxyUserPassword" => $this->proxyUserPassword,
        ];

        $inputFileName = "getTransactionStatus_Input_{$transactionID}.json";
        $outputFileName = "getTransactionStatus_Output_{$transactionID}.json";

        // Ensure directories exist
        if (!is_dir($this->inputTransactionStatus)) {
            mkdir($this->inputTransactionStatus, 0777, true);
        }
        if (!is_dir($this->outputTransactionStatus)) {
            mkdir($this->outputTransactionStatus, 0777, true);
        }

        // Paths for input and output files
        $filePathInput = $this->inputTransactionStatus . DIRECTORY_SEPARATOR . $inputFileName;
        $filePathOutput = $this->outputTransactionStatus . DIRECTORY_SEPARATOR . $outputFileName;

        // Save input data to input file
        file_put_contents($filePathInput, json_encode($transactionStatusData, JSON_UNESCAPED_SLASHES));

        // Create a blank output file
        file_put_contents($filePathOutput, '');

        // Return both file paths
        return [
            'inputFile' => $filePathInput,
            'outputFile' => $filePathOutput,
        ];
    }

    public function initiateSign(Request $request)
    {
        //User data for eMSigned
        $userSignData = getUsereMSignerData(Auth::id());

        $base64 = $this->generateBase64Encode($request);
        $filePaths = $this->resolveFilePaths(
            $request->input('file_name'),
            $request->input('path'),
            $request->input('storage_type')
        );

        $pageCoordinates = $this->coordinates($request);
        $inputJson = [
            "inputs" => [[
                "base64doc" => $base64,
                "docInfo" => "docInfo1",
                "docURL" => $filePaths['hostPath'],
                "signerName" => $userSignData['emName'],
                "reason" => $userSignData['eSignReason'],
                "location" => $userSignData['eSignLocation'],
                "pageCoordinates" => $pageCoordinates,
                "coSign" => true,
                "isHash" => false,
                "appearanceType" => "StandardSignature"
            ]],
            "tempFolderPath" => $this->tempFolderPath,
            "eSignType" => $this->eSignType,
            "authMode" => "",
            "signerID" => $userSignData['emUserId'],
            "redirectURL" => $this->redirectURL,
            "responseURL" => $this->responseURL,
            "transactionID" => "",
            "pfxPath" => $this->pfxPath,
            "licenceFilePath" => $this->licenceFilePath,
            "pfxPassword" => $this->pfxPassword,
            "pfxAlias" => $this->pfxAlias,
            "proxyReq" => $this->proxyReq,
            "proxyIp" => $this->proxyIp,
            "proxyPort" => $this->proxyPort,
            "sessionTimeout" => $this->sessionTimeout,
            "proxyUserID" => $this->proxyUserID,
            "proxyUserPassword" => $this->proxyUserPassword,

        ];
 // print_r($inputJson); die;
        // Convert JSON to a string
        $jsonContent = json_encode($inputJson, JSON_UNESCAPED_SLASHES);

        // Write the content to the file

        try {
            //Input FileName Select
            $inputFileName = ($this->eSignType === 'V3') ? 'getGatewayParam_InputV3.json' : 'getGatewayParam_InputV2.json';
            $inputFilePath = $this->filePutContent($this->inputPath, $inputFileName, $jsonContent);

            //Output FileName Select
            $outPutFileName = $this->outputPath . DIRECTORY_SEPARATOR . 'getGatewayParam_Output.json';
          
        } catch (\Exception $e) {
            echo "Error: " . $e->getMessage();
        }

        $escapedInputPath = escapeshellarg($inputFilePath);
        $escapedOutputPath = escapeshellarg($outPutFileName);
		

        try {
            // Construct the command
            $command = "java -jar {$this->cliPath} -method GetGatewayParam -input {$escapedInputPath} -output {$escapedOutputPath}";

            // Execute the command and capture output and return status
            $output = [];
            $returnVar = 0;
            exec($command, $output, $returnVar);

            // Log the command and output for debugging
            // Log::info("Executed Command: {$command}");
            // Log::info("Command Output: " . implode("\n", $output));
            // Log::info("Command Return Code: {$returnVar}");

            if ($returnVar === 0) {
                // Command executed successfully
                $response = json_decode(file_get_contents($outPutFileName), true);

                if (json_last_error() !== JSON_ERROR_NONE) {
                    throw new \Exception("Failed to decode JSON from output file: " . json_last_error_msg());
                }

                // Generate Signed File
                $this->genrateSignedDataFile($response);

                // Calling the function and capturing the response
                $queryInsertData = [
                    'ref_operator_type_id' => Auth::user()->ref_operator_type_id, // Get the operator type ID
                    'at_user_id' => Auth::id(), // Get the user ID
                    'transactionId' => $response['transactionID'],
                    'filename' => $request->input('file_name'),
                    'filePath' =>  $request->input('path'),
                    'fileFolder' =>  $request->input('storage_type'),
                    "signerName" => $userSignData['emName'],
                    "reason" => $userSignData['eSignReason'],
                    "location" => $userSignData['eSignLocation'],
                    'moduleName' => $request->input('path'),
                    'eSignType' => $userSignData['eSignType'],
                    'emUserId' => $userSignData['emUserId'],
                    'emName' =>  $userSignData['emName'],
                    'eSignReason' => $userSignData['eSignReason'],
                    'eSignLocation' => $userSignData['eSignLocation'],
                    'gatewayParamResponseCode' => $response['status'],
                    'preSignedTempFile' => $response['preSignedTempFile'],
                    'responseCode' => $response['responseCode'],
                    'created_at' => now(), // Set the creation timestamp
                    'created_by' => Auth::id(), // Creator's ID
                ];  //dd($queryInsertData); die;

                $this->saveOrUpdateData($queryInsertData);

                // Create Transaction File
                $this->genrateTransactionStatusFile(['transactionID' => $response['transactionID']]);

                // Filtered response
                $isSuccess = $response['status'] === 1;
                $filteredResponse = [
                    'transactionID' => $response['transactionID'] ?? null,
                    'status' => $isSuccess ? 'success' : 'failed',
                    'responseCode' => $response['responseCode'] ?? null,
                    'gatewayParameter' => $response['gatewayParameter'] ?? null,
                ];

                return response()->json($filteredResponse);
            } else {
                // Command failed
                Log::error("Command Execution Failed. Return Code: {$returnVar}");
                Log::error("Command Output: " . implode("\n", $output));

                return response()->json([
                    'status' => 'failed',
                    'error' => "Command execution failed. Check logs for details.",
                ], 500);
            }
        } catch (\Exception $e) {
            // Catch and log any unexpected errors
            Log::error("Error during command execution: " . $e->getMessage());
            return response()->json([
                'status' => 'error',
                'message' => $e->getMessage(),
            ], 500);
        }
    }

    // public function digitaleSignRedirect(Request $request)
    // {
    //     $postData = $request->all();

    //     if (isset($postData['txnref'])) {
    //         // Decode txnref
    //         $decodedTxnref = base64_decode($postData['txnref']);
    //         $txnrefParts = explode('|', $decodedTxnref);
    //         $firstPart = isset($txnrefParts[0]) ? trim($txnrefParts[0]) : null;
    //         $secondPart = isset($txnrefParts[1]) ? trim($txnrefParts[1]) : null;

    //         // Retrieve transaction status file response
    //         $trInputFileResponse = $this->findTransactionStatusFile($firstPart);

    //         // Decode JSONResponse into an array
    //         $trInputFile = json_decode($trInputFileResponse->getContent(), true);

    //         if ($trInputFile['status'] === "success") {
    //             $trInputPath = $trInputFile['inputFilePath'] ?? null;
    //             $trOutputPath = $trInputFile['outputFilePath'] ?? null;
    //         } else {
    //             return response()->json([
    //                 'error' => 'Input Sign File not found',
    //             ], 400);
    //         }

    //         $escapedInputPath = escapeshellarg($trInputPath);
    //         $escapedOutputPath = escapeshellarg($trOutputPath);

    //         try {
    //             // Construct the command
    //             $command = "java -jar {$this->cliPath} -method getTransactionStatus -input {$escapedInputPath} -output {$escapedOutputPath}";

    //             // Execute the command and capture output and return status
    //             $output = [];
    //             $returnVar = 0;
    //             //exec($command, $output, $returnVar);

    //             // Log the command and output for debugging
    //             Log::info("Executed Command: {$command}");
    //             Log::info("Command Output: " . implode("\n", $output));
    //             Log::info("Command Return Code: {$returnVar}");

    //             if ($returnVar === 0) {
    //                 // Command executed successfully
    //                 $response = json_decode(file_get_contents($trOutputPath), true);
    //                 //print_r($response); die;
    //                 if (json_last_error() !== JSON_ERROR_NONE) {
    //                     throw new \Exception("Failed to decode JSON from output file: " . json_last_error_msg());
    //                 }
    //                 //Output FileName Select
    //                 $outPutFileName = $this->outputPath . DIRECTORY_SEPARATOR . 'getGatewayParam_Output.json';

    //                 if (file_exists($outPutFileName)) {
    //                     $outPutResponse = json_decode(file_get_contents($outPutFileName), true);

    //                     if (json_last_error() !== JSON_ERROR_NONE) {
    //                         throw new \Exception("Failed to decode JSON from output file: " . json_last_error_msg());
    //                     }

    //                     // Proceed with the response data
    //                     // Example: Log or process the response
    //                     Log::info("Successfully read and decoded JSON: " . json_encode($response, JSON_PRETTY_PRINT));
    //                 } else {
    //                     throw new \Exception("Output file not found at: {$outPutFileName}");
    //                 }

    //                 // Filtered response
    //                 $isSuccess = $response['status'] === 1;
    //                 $filteredResponse = [
    //                     'responseXML' => $response['responseXML'],
    //                     'preSignedTempFile' => $outPutResponse['preSignedTempFile'],
    //                     'transactionID' =>  $firstPart
    //                 ];
    //                 try {
    //                     $updateSignedInput = $this->updateSignedInput($filteredResponse);
    //                     $signedFileResponse = json_decode($updateSignedInput->getContent(), true);
    //                     //print_r($signedFileResponse); die;
    //                     if ($signedFileResponse['status'] === "success") {
    //                         $generateSignedPdfData = $this->createSignedPdfOutput($signedFileResponse);

    //                         // Further processing with $generateSignedPdfData
    //                         Log::info("Signed PDF Data: " . json_encode($generateSignedPdfData, JSON_PRETTY_PRINT));
    //                     } else {
    //                         throw new \Exception("Signed file response indicates failure.");
    //                     }
    //                 } catch (\Exception $e) {
    //                     Log::error("Error during signed PDF generation: " . $e->getMessage());
    //                     return response()->json(['status' => 'error', 'message' => $e->getMessage()], 500);
    //                 }

    //                 //return response()->json($filteredResponse);
    //             } else {
    //                 // Command failed
    //                 Log::error("Command Execution Failed. Return Code: {$returnVar}");
    //                 Log::error("Command Output: " . implode("\n", $output));

    //                 return response()->json([
    //                     'status' => 'failed',
    //                     'error' => "Command execution failed. Check logs for details.",
    //                 ], 500);
    //             }
    //         } catch (\Exception $e) {
    //             // Catch and log any unexpected errors
    //             Log::error("Error during command execution: " . $e->getMessage());

    //             return response()->json([
    //                 'status' => 'error',
    //                 'message' => $e->getMessage(),
    //             ], 500);
    //         }
    //     } else {
    //         return response()->json([
    //             'error' => 'eSign Status: Failure. No signed documents were generated.',
    //         ], 400);
    //     }
    // }
    public function digitaleSignRedirect(Request $request)
    {
        $postData = $request->all();

        if (!isset($postData['txnref'])) {
            return response()->json([
                'error' => 'eSign Status: Failure. No signed documents were generated.',
            ], 400);
        }

        // Decode txnref
        $decodedTxnref = base64_decode($postData['txnref']);
        $txnrefParts = explode('|', $decodedTxnref);
        $firstPart = isset($txnrefParts[0]) ? trim($txnrefParts[0]) : null;
        $secondPart = isset($txnrefParts[1]) ? trim($txnrefParts[1]) : null;

        // Retrieve transaction status file response
        $trInputFileResponse = $this->findTransactionStatusFile($firstPart);
        $trInputFile = json_decode($trInputFileResponse->getContent(), true);

        if ($trInputFile['status'] !== "success") {
            return response()->json([
                'error' => 'Input Sign File not found',
            ], 400);
        }

        $trInputPath = $trInputFile['inputFilePath'] ?? null;
        $trOutputPath = $trInputFile['outputFilePath'] ?? null;

        // Escape file paths to avoid command injection
        $escapedInputPath = escapeshellarg($trInputPath);
        $escapedOutputPath = escapeshellarg($trOutputPath);

        try {
            // Construct the command for executing the jar
            $command = "java -jar {$this->cliPath} -method getTransactionStatus -input {$escapedInputPath} -output {$escapedOutputPath}";
            // Log the command being executed
            Log::info("Executing command: {$command}");

            // Execute the command
            $output = [];
            $returnVar = 0;
            // Uncomment the line below to actually run the command
            exec($command, $output, $returnVar);

            Log::info("Command Output: " . implode("\n", $output));
            Log::info("Command Return Code: {$returnVar}");

            if ($returnVar !== 0) {
                Log::error("Command Execution Failed. Return Code: {$returnVar}");
                return response()->json([
                    'status' => 'failed',
                    'error' => "Command execution failed. Check logs for details.",
                ], 500);
            }

            // Read and process the output JSON file
            $response = json_decode(file_get_contents($trOutputPath), true);

            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new \Exception("Failed to decode JSON from output file: " . json_last_error_msg());
            }

            $queryInsertData = [
                'transactionId' => $firstPart,
                'gatewayTransactionResponseCode' => $response['status'],
            ];

            $this->saveOrUpdateData($queryInsertData);

            // Check for the output file that contains the necessary pre-signed file data
            $outPutFileName = $this->outputPath . DIRECTORY_SEPARATOR . 'getGatewayParam_Output.json';

            if (!file_exists($outPutFileName)) {
                throw new \Exception("Output file not found at: {$outPutFileName}");
            }

            $outPutResponse = json_decode(file_get_contents($outPutFileName), true);

            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new \Exception("Failed to decode JSON from output file: " . json_last_error_msg());
            }

            // Filtered response data to send further
            $filteredResponse = [
                'responseXML' => $response['responseXML'],
                'preSignedTempFile' => $outPutResponse['preSignedTempFile'],
                'transactionID' => $firstPart
            ];

            // Update signed input with the filtered response
            $updateSignedInput = $this->updateSignedInput($filteredResponse);

            $signedFileResponse = json_decode($updateSignedInput->getContent(), true);

            if ($signedFileResponse['status'] !== "success") {
                throw new \Exception("Signed file response indicates failure.");
            }

            // Generate signed PDF data
            $generateSignedPdfData = $this->createSignedPdfOutput($signedFileResponse);



            if ($generateSignedPdfData['status'] !== "Success") {
                throw new \Exception("Signed PDF Save indicates failure.");
            }

            // Finally, redirect to the route with the appropriate parameters

            session()->save(); // Ensure the session is persisted

            return redirect()->route('eSign.digital.Response', [
                'transactionID' => $generateSignedPdfData['transactionID'],
                'status' => $generateSignedPdfData['status'],
            ]);
        } catch (\Exception $e) {
            Log::error("Error during process: " . $e->getMessage());
            return response()->json([
                'status' => 'error',
                'message' => $e->getMessage(),
            ], 500);
        }
    }


    /**
     * Handles the signed PDF output generation.
     *
     * @param array $signedFileResponse The response containing signed file paths.
     * @throws \Exception If any error occurs during the process.
     * @return array The generated signed PDF data.
     */
    private function createSignedPdfOutput(array $signedFileResponse)
    {
        // Extract the input and output file paths
        $signedPdfInputPath = $signedFileResponse['filePathInput'] ?? null;
        $signedPdfOutputPath = $signedFileResponse['filePathoutput'] ?? null;

        if (!$signedPdfInputPath || !$signedPdfOutputPath) {
            throw new \Exception("Input or Output path for signed PDF is missing.");
        }

        // Construct the CLI command
        $command = "java -jar {$this->cliPath} -method getSignedPdf -input " . escapeshellarg($signedPdfInputPath) . " -output " . escapeshellarg($signedPdfOutputPath);

        // Execute the command
        exec($command, $output, $status);

        if ($status !== 0) {
            throw new \Exception("Command execution failed. Return code: {$status}. Output: " . implode("\n", $output));
        }

        // Read the output JSON file
        $response = json_decode(file_get_contents($signedPdfOutputPath), true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new \Exception("Failed to decode JSON response: " . json_last_error_msg());
        }

        // Generate signed PDF data
        $generateSignedPdfData = $this->generateSignedPdfData($response);

        $queryInsertData = [
            'transactionId' => $response['transactionID'],
            'getSignedPdfResponseCode' => $response['status'],
            'signedStatus' => $response['status'],
            'signedPath' => $generateSignedPdfData['outputPaths']['0'],

        ];

        $this->saveOrUpdateData($queryInsertData);

        return $generateSignedPdfData;
    }

    /**
     * Processes the response data to generate signed PDF files.
     *
     * @param array $data The response data containing transaction ID and return values.
     * @throws \Exception If the required data is missing or the signed document is invalid.
     * @return array Contains the transaction ID, status, and paths of generated PDFs.
     */
    private function generateSignedPdfData(array $data)
    {
        // Validate the required data
        if (!isset($data['transactionID']) || empty($data['transactionID'])) {
            throw new \InvalidArgumentException("Transaction ID is required.");
        }

        if (!isset($data['returnValues']) || !is_array($data['returnValues'])) {
           
            throw new \InvalidArgumentException("Invalid or missing returnValues data.");
        }

        $transactionID = $data['transactionID'];
        $returnValues = $data['returnValues'];

        // Define the output directory for signed PDFs
        $outputDir = $this->SignedPdfs . DIRECTORY_SEPARATOR . $transactionID;

        // Ensure the output directory exists
        if (!is_dir($outputDir)) {
            mkdir($outputDir, 0777, true);
        }

        $filePaths = []; // To store paths of all generated PDF files

        foreach ($returnValues as $element) {
            // Validate the signed document
            if (!isset($element['signedDocument']) || empty($element['signedDocument'])) {
                throw new \Exception("The signed document is missing for docId: {$element['docId']}. Please check the signing process.");
            }

            // Decode the Base64 signed document
            $decodedContent = base64_decode(urldecode($element['signedDocument']), true);
            if ($decodedContent === false) {
                throw new \Exception("Invalid Base64 content for document ID {$element['docId']}.");
            }

            // Validate the content to ensure it is a valid PDF
            if (strpos($decodedContent, '%PDF') !== 0) {
                throw new \Exception("The content for document ID {$element['docId']} is not a valid PDF.");
            }

            // Define the file path for the PDF
            $fileName = $outputDir . DIRECTORY_SEPARATOR . $element['docId'] . '-' . $transactionID . '.pdf';

            // Write the PDF to the file
            if (file_put_contents($fileName, $decodedContent) === false) {
                throw new \Exception("Failed to write PDF for document ID {$element['docId']}.");
            }

            // Store the file path for the response
            $filePaths[] = $fileName;
        }

        // Prepare and return the response
        return [
            'transactionID' => $transactionID,
            'status' => 'Success',
            'outputPaths' => $filePaths, // List of all generated PDF file paths
        ];
    }

    private function saveOrUpdateData($data)
    {
        // Check if the record already exists based on transactionID
        $existingData = DB::table('at_emsigner_signature')
            ->whereRaw('"transactionId" = ?', [$data['transactionId']])
            ->first();

        if ($existingData) {
            // Record exists, update the data
            // Check if the record already exists based on transactionID
            $updated = DB::table('at_emsigner_signature')
                ->whereRaw('"transactionId" = ?', [$data['transactionId']])
                ->update($data);
            if ($updated) {
                // Return a success response
                return response()->json([
                    'status' => 'success',
                    'message' => 'Data has been updated successfully.'
                ], 200);
            } else {
                // Return a failure response if update failed
                return response()->json([
                    'status' => 'failed',
                    'message' => 'Failed to update the data.'
                ], 400);
            }
        } else {
            // Record does not exist, create a new one
            $saveData = eMSignerCertificateModal::create($data);

            if ($saveData) {
                // Return a success response if data was created successfully
                return response()->json([
                    'status' => 'success',
                    'message' => 'Your application has been submitted to CB.'
                ], 200);
            } else {
                // Return a failure response if data creation failed
                return response()->json([
                    'status' => 'failed',
                    'message' => 'Application not forwarded.'
                ], 400);
            }
        }
    }

    public function handleDigitalSignResponse(Request $request)
    {
        try {
            // Extract transactionID and status from the request
            $transactionID = $request->query('transactionID');
            $status = $request->query('status');

            if (!$transactionID || !$status) {
                return redirect()->back()->withErrors(['msg' => 'Invalid response from e-sign service.']);
            }

            return redirect()->route('superadmin.applyScopeCertificate')->with('loader', true);
        } catch (Exception $e) {
            // Handle any exceptions and redirect back with error message
            return redirect()->back()->withErrors(['msg' => 'Something went wrong.']);
        } catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
            // Handle DecryptException separately if needed
            return redirect()->back()->withErrors(['msg' => 'Decryption error.']);
        }
    }
}

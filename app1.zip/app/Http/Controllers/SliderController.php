<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Lang;
use Illuminate\Support\Facades\Log;
use Exception;
use App\Http\Controllers\Controller;
use App\Models\AtSlider;
use Yajra\DataTables\DataTables;
use DB;
use Carbon\Carbon;
use App\Events\PushNotificationEvent;
use Illuminate\Support\Facades\Gate;
use RealRashid\SweetAlert\Facades\Alert;
use Illuminate\Support\Facades\Auth;

class SliderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
       // abort_unless(\Gate::allows('user_access'), 403);
        
        try {
           
             
            if ($request->ajax()) {
          
                $slider = AtSlider::orderBy('created_at', 'desc')->get();
              
                return Datatables::of($slider)
                    ->addIndexColumn()
                    ->addColumn('title', function($row){
                           
                        return $row->title ?? '';
                    })
                    ->addColumn('summary', function($row){
                        return $row->summary??'';
                    }) ->addColumn('image', function($row){
                         //return $row->image??'';
                         if(!empty($row->image)){
                            $imgUrl = url('/public/slider/'.$row->image);
                            return '<a target="_BLANK" href='.$imgUrl.'
                             class="text-decoration-underline"><span class="badge badge-soft-success">view file</span></a>';
    
                         }else{
                            return 'No Image';
                         }
                       
                    }) ->addColumn('status', function($row){
                        if($row->status==1){
                            return '<span class="badge badge-soft-success">Active</span>';
                        }else{
                            return '<span class="badge badge-soft-danger">In Active</span>';
                        }
                        
                    }) 
                    ->addColumn('language', function($row){
                        if($row->language=='HI'){
                            return 'Hindi';
                        }else{
                            return 'English';
                        }
                        
                    }) 
                    ->addColumn('action', function($row){
                       
                        $addEditDetailButton = '';
                          
                                $addEditDetailButton = '<a href='.route('slider.edit', [$row->id]).'><span><i class="mdi mdi-pencil text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Edit Individual User"></i></span></a>';
                           
                                $addEditDetailButton.='<a href="JavaScript:void(0);" class="deletedata" data-value="'.$row->id.'"><span><i class="mdi mdi-delete-circle text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Delete"></i></span></a>';
                          
                                return $addEditDetailButton;
                            
                    })
                    ->rawColumns(['action','status','image'])
                    ->make(true);
            }

            return view('admin.slider.index');
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //abort_unless(\Gate::allows('slider_create'), 403);
        try {
            return view('admin.slider.create');
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {


        //abort_unless(\Gate::allows('slider_create'), 403);
        //dd($request->all());
        $request->validate([
            'title' => 'Required',
            'language' => 'Required',
            'summary' => 'Required'
        ]);
        $language = $request->input('language'); 
       try {
            $documentRootPath =  public_path('slider');            
            $file_path = time() . rand() . '.' . $request->file('image')->getClientOriginalExtension();

            $request->file('image')->move($documentRootPath, $file_path);
            $image = $file_path;
           
            $data = array(
                'title' => $request->title,
                'summary' => $request->summary,
                'link' => $request->link ?? null,
                'image' => $image,
                'language' => $language,
                'status' => 1,
                'created_by' => Auth::guard('misadmin')->user()->id,
              );
          
            $slider = AtSlider::create($data); 
 
            if($slider)
            {
                Alert::success('Success', 'Saved successfully.');
                
            }else{
              
                Alert::error('error', 'Something Went Wrong.');
            }
            
            return redirect()->route('slider.index');

        } catch (\Throwable $e) {
           //dd($e->getMessage());
            Log::error($e);
            $flash = array(
                'flag' => 'success',
                'message' =>$e->getMessage(),
            );
            return back()->with('flash', $flash);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
       // abort_unless(\Gate::allows('slider_edit'), 403);
        try {

            //$id = hashid('hashids')->decode($id)[0];
            $data = AtSlider::whereId($id)->first();
            //dd($data);
            return view('admin.slider.create', compact('data'));

        } catch (\Throwable $th) {
          
            Log::error($th);
            $flash = array(
                'flag' => 'success',
                'message' => $th->getMessage()
            );
            return back()->with('flash', $flash);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //abort_unless(\Gate::allows('slider_edit'), 403);
        $request->validate([
            'title' => 'Required',
            'summary' => 'Required'
        ]);

        try {

            $image = '';

            if (!empty($request->file('image'))) 
            {
                if (!empty($request->image_edit)) 
                {
                    $imagePath = public_path('slider') . $request->image_edit;
                    deleteOldImage($request->image_edit, $imagePath);
                }
                $documentRootPath =  public_path('slider');
                $file_path = time() . rand() . '.' . $request->file('image')->getClientOriginalExtension();
                $request->file('image')->move($documentRootPath, $file_path);
                $image = $file_path;
            } 
            else 
            {
                if (!empty($request->image_edit))
                       $image = $request->image_edit;
            }
    
            AtSlider::whereId($id)->update([
                'title' => $request->title,
                'summary' => $request->summary,
                'link' => $request->link ?? null,
                'image' => $image,
                'language' => $request->language,
                'status' => $request->status,
                'created_by' => Auth::guard('misadmin')->user()->id,
            ]);

            Alert::success('', 'Updated successfully');
            return redirect()->route('slider.index');

        } catch (\Throwable $th) {
            Log::error($th);
            $flash = array(
                'flag' => 'success',
                'message' => $th->getMessage()
            );
            return back()->with('flash', $flash);
        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
       
        //abort_unless(\Gate::allows('slider_delete'), 403);
        try {
           $id=$request->id;
            AtSlider::where('id',$id)->delete();

            $flash = array(
                'flag' => 'success',
                'message' => 'Deleted Successfully'
            );
            return back()->with('flash', $flash);
        } catch (Exception $e) {
            Log::error($e);
            $flash = array(
                'flag' => 'success',
                'message' => $e->getMessage()
            );
            return back()->with('flash', $flash);
        }
    }


    
}

<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\RefState;
use App\Models\RefDistrict;
use App\Models\RefRegion;
use App\Models\RefVillage;
use App\Models\RefBank;
use App\Models\IndividualProducerFarmerDetail;
use App\Models\IndividualProducerDetailOfProposedCorp;
use App\Models\IndividualProducerDetailOfStandingCorp;
use App\Models\IndividualProducerDocument;
use App\Models\IndividualProducerFarmDetail;
use App\Models\IndividualProducerGeoTagging;
use App\Models\GeoTaggingProcessorDetail;
use App\Models\WildHarvesterBankDetail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use DB;
use Exception;
use Illuminate\Support\Facades\Validator;


class IndividualProController extends Controller
{
   
    public function traderDash(Request $request){
        $x = new \stdClass();

        $validator = Validator::make($request->all(), [
            "user_id" =>'required',
            ]);
            if (!$validator->fails())
            {
               
                $insDetTabs = array('trader_detail','bank_detail','unit_detail','product_detail','docs');
                //$data = AtFarmerRegDetail::select('inspection_step')->where('id', $request->farmer_id)->where('at_ics_inspector_id',$request->at_inspector_id)->first();
               
                $rdata = array();
                foreach($insDetTabs as $key => $val){
                   $rdata[$key]['name'] = $val;

                   if($val=='trader_detail'){
                     $rdata[$key]['status'] = 0;
                   }elseif($val=='bank_detail'){
                     $rdata[$key]['status'] = 0;
                   }elseif($val=='unit_detail'){
                    $rdata[$key]['status'] = 0;
				   }elseif($val=='product_detail'){
                     $rdata[$key]['status'] = 0;
                   }elseif($val=='docs'){
                    $rdata[$key]['status'] =  0;
                   }else{
                    $rdata[$key]['status'] = 0;
                  }
                }
             
               if($rdata){
                return response()->json(['status'=>200, 'message'=>"Trader Data", 'data'=> $rdata]);
                }else{
                    return response()->json(['status'=>400, 'message'=>"Data not Found", 'data'=> []]);
                }
                
            } else {
                return response()->json(['status'=>400, 'message'=>$validator->errors()->first(), 'data'=> []]);
            }
    }

    public function saveBanks(Request $request){
        $x = new \stdClass();
        $validator = Validator::make($request->all(), 
        [            
            'user_id' => 'required',
            'ref_bank_id' => 'required',
            'account_number' => 'required|numeric',
            'ifsc_code' => 'required',
            'branch_name' => 'required',
            'bank_address' => 'required',
            'pincode' => 'required|numeric|digits:6',
        ]
      );        

        try{
            if ($validator->fails()) { 
                return response()->json(['status'=>400, 'message'=>$validator->errors()->first(), 'data'=> []]);
            } else {
                
                
                $newUser = WildHarvesterBankDetail::updateOrCreate([
					'at_user_id'   => $request->user_id,
				], [
                    'at_user_id'   => $request->user_id,
					'ref_operator_type_id'   =>3,
					'ref_bank_id' => $request->ref_bank_id,
					'account_number' => $request->account_number,
					'ifsc_code' => $request->ifsc_code,
					'branch_name' => $request->branch_name,
					'bank_address' => $request->bank_address,
					'pincode' => $request->pincode,

				]);
                if($newUser){
               
                    return response()->json(['status'=>200, 'message'=>"Data Successfully Saved.", 'data'=> $x]);
                }else{
                    return response()->json(['status'=>200, 'message'=>"Data not saved.", 'data'=> $x]);
                }
            }
        } catch (Exception $e) {
            \Log::error($e->getMessage());
            $response =  array(
                'status' => 400,
                'message' => $e->getMessage(),
                'data' => array()
            );
            return response()->json($response);
        }
    }
    public function listDocSave(Request $request){
        $x = new \stdClass();

        $validator = Validator::make($request->all(), [
            'user_id' => 'required',
            'aadhar_card' => 'required',
            'pan_card' => 'required',
            'land_document' => 'required',
            'passbook' => 'required',
            'contact_person_sign' => 'required',
            'live_signature' => 'required',
            
		 ]);

            if (!$validator->fails())
            {
               
               $data = array(
                    'at_user_id' => $request->user_id,
                    'aadhar_card_image_path' => $request->aadhar_card,
                    'pan_card_image_path' => $request->pan_card,
                    'passbook_image_path' => $request->passbook,
                    'land_documents_image_path' => $request->land_document,
                    'contact_person_sign_image_path' => $request->contact_person_sign,
                    'live_signature_image_path' => $request->live_signature,
                    'created_by' => $request->user_id,
				    'created_at' => date('Y-m-d H:i:s'),
    
                );
                 
                $saveData = IndividualProducerDocument::create($data);

                if($saveData){
               
                    return response()->json(['status'=>200, 'message'=>"Data Successfully Saved.", 'data'=> $x]);
                }else{
                    return response()->json(['status'=>200, 'message'=>"Data not saved.", 'data'=> $x]);
                }
            } else {
               
                return response()->json(['status'=>400, 'message'=>$validator->errors()->first(), 'data'=> []]);
            }
    }

    public function farmerDetailSave(Request $request){
        try {
           
                $x = new \stdClass();
                 $validator = Validator::make($request->all(), [
                        
                        'user_id' => 'required',
                        'registration_date' => 'required',
                        'farmer_first_name' => 'required',
                        'farmer_last_name' => 'required',
                        'gender' => 'required',
                        'father_husband_first_name' => 'required',
                        'farmer_address' => 'required',
                        'ref_state_id' => 'required',
                        'ref_district_id' => 'required',
                        'ref_block_tehsil_id' => 'required',
                        'ref_village_id' => 'required',
                        'pin' => 'required',
                        'farmer_address' => 'required',
                        'mobile_no' => 'required',
                        'aadhar_number' => 'required',
                        'farmerPhoto' => 'required',
                        'landDetail' => 'required',
                        //'landDetail.*.area_in_hectars' => 'required',
                        'landDetail.*.khasra_number' => 'required',
                        //'landDetail.*.total_area' => 'required',
                     ],
					[
					    'user_id.required'=>'User ID is required.',
					    'registration_date.required'=>'Date of Registration is required.',
                        'farmer_first_name.required'=>'Farmer Name is required.',
                        'farmer_last_name.required'=>'Farmer Name Last is required.',
                        'gender.required'=>'Gender is required.',
                        'father_first_name.required'=>'Father Name is required.',
                        'farmer_address.required'=>'Farmer Address is required.',
                        'state.required'=>'State is required.',
                        'taluka.required'=>'Taluka Block is required.',
                        'district.required'=>'District is required.',
                        'village.required'=>'Village is required.',
                        'pin.required'=>'Pin Code is required.',
                        'farmer_address.required'=>'Address is required.',
                        'mobile_no.required'=>'Mobile Number is required.',
                        'aadhar_number.required'=>'Aadhar Number is required.',
                        'farmerPhoto.required'=>'Farmer Photo is required.',
					]
					);
                    if (!$validator->fails())
                    {
                        $data=array(
                            "ref_operator_type_id" =>2,
                            "registration_no" =>$request->registration_no??'',
                            "registration_date" =>$request->registration_date??'',
                           // "owner_farmerid"=>$request->user_id,
                            "farmer_first_name"=>$request->farmer_first_name,
                            "farmer_middle_name"=>$request->farmer_middle_name,
                            "farmer_last_name"=>$request->farmer_last_name,
                            "gender"=>$request->gender,
                            "father_husband_flag"=>$request->father_husband_flag ?? '',
                            "father_husband_first_name"=>$request->father_husband_first_name ?? '',
                            "farmer_address"=>$request->farmer_address??'',
                            "farmer_address1"=>$request->farmer_address1??'',
                            "landmark"=>$request->landmark,
                            "ref_state_id"=>$request->ref_state_id,
                            "ref_district_id" =>$request->ref_district_id,
                            "ref_block_tehsil_id" =>$request->ref_block_tehsil_id,
                            "ref_village_id" =>$request->ref_village_id,
                            "pin"=>$request->pin,
                            "mobile_no"=>$request->mobile_no,
                            "aadhar_number"=>$request->aadhar_no,
                            "pan_number"=>$request->pan_number,
                            "email_id"=>$request->email_id,
                            "at_user_id"=>$request->user_id,
                            //"at_ics_inspector_id" =>$request->at_ics_inspector_id??'',
                            "farmerPhoto"=>$request->farmerPhoto,
                        );
                
                        $farmer = IndividualProducerFarmerDetail::create($data); 
                        if($farmer){
                        // Land_details
                            if(!empty($request->landDetail)){
                                foreach($request->landDetail as $lands){
                                
                                    $land=array(
                                        "at_farmer_reg_details_id"=>$farmer->id,
                                        "at_user_id"=>$request->user_id,
                                        "registration_no" => $request->farmerDetails['registration_no']??'',
                                        "owner_farmerid" =>  $farmer->id,
                                        "farm_name"=>$lands['farm_owner']??'',
                                        "landmark"=>$lands['landmark']??0,
                                        "pin"=>$lands['pin']??0,
                                        "farm_no"=>$lands['farm_no']??0,
                                        "area_in_ha"=>$lands['area_in_hectars']??'0',
                                        "total_area"=>$lands['total_area']??'0',
                                        "survay_no"=>$lands['khasra_number'],
                                        //"no_of_plot"=>$lands['no_of_plot']??'',
                                        "ref_state_id"=>$request->farmerDetails['ref_state_id']??'1',
                                        "ref_district_id" =>$request->farmerDetails['ref_district_id']??'1',
                                        "ref_block_tehsil_id" =>$request->farmerDetails['ref_block_tehsil_id']??'1',
                                        "ref_village_id" =>$request->farmerDetails['ref_village_id']??'1',
                                        "farm_processing"=>$lands['farm_processing']??0,
                                        //"completed_three_years_pgs"=>$lands['completed_three_years_pgs']??'',
                                        //"pgs_certificate"=>$lands['pgs_certificate']??'',
                                       // "ref_organic_status_master_id"=>'4',
                                        //"area_organic_cultivation" => $lands['area_organic_cultivation'] ?? 0,
                                        
                                    );
                                    
                                    $landdet = IndividualProducerFarmDetail::create($land);
                                    
                                    if(!empty($lands['mStandingCrop'])){
                                       
                                        // mStandingCrop details
                                            foreach($lands['mStandingCrop'] as $sscorp){
                                            $scorp=array(
                                               // "ref_hscode_id"=>$sscorp['ref_hscode_id'],
                                                "season_name"=>$sscorp['season_name'],
                                                "crop_name" =>$sscorp['crop_name'],
                                                "crop_area"=>$sscorp['area'],
                                                "crop_photo"=>$sscorp['crop_photo'],
                                                "geotag_photo"=>$sscorp['geotag_photo'],
                                                "organic_status"=>$sscorp['organic_status'],
                                                "at_ip_farmer_details_id"=>$farmer->id,
                                                "at_ip_farm_details_id"=>$landdet->id,
                                                "at_user_id"=>$request->user_id
                                            );
                                            
                                            $scorps = IndividualProducerDetailOfStandingCorp::create($scorp);

                                            
                                            if(!empty($sscorp['geotag'])){
                                                foreach($sscorp['geotag'] as $geos){
                                                    $geo=array(
                                                        "at_ip_farmer_reg_details_id"=>$farmer->id,
                                                        "latitude"=>$geos['slatitude'],
                                                        "longitude"=>$geos['slongitude'],
                                                        "at_ip_farm_details_id"=>$landdet->id,
                                                        "at_ip_details_standing_crop_id"=>$scorps->id,
                                                        "at_user_id"=>$request->user_id
                                                    );
                                                    $geos = IndividualProducerGeoTagging::create($geo);
                                                }
                                            }
                                        }
                                    }
                                  
                                    if(!empty($lands['mProposedCrop'])){
                                        // mProposedCrop details
                                        foreach($lands['mProposedCrop'] as $ppcorp){
                                            $pcorp=array(
                                                //"ref_hscode_id"=>$ppcorp['ref_hscode_id'],
                                                "season_name"=>$ppcorp['season_name'],
                                                "crop_name" =>$ppcorp['crop_name'],
                                                "crop_area"=>$ppcorp['area'],
                                                "organic_status"=>$ppcorp['organic_status'],
                                                "at_ip_farmer_details_id"=>$farmer->id,
                                                "at_ip_farm_details_id"=>$landdet->id,
                                                "at_user_id"=>$request->user_id
                                            );
                                            $ps = IndividualProducerDetailOfProposedCorp::create($pcorp);
                                        }
                                    }
                                }
                            }
                        }
                        //********** If Else   
                       
                        if($farmer){
                            return response()->json(['status'=>200, 'message'=>"Farmer Successfully Registered", 'data'=> $x]);
                        }else{
                            return response()->json(['status'=>200, 'message'=>"Farmer Not Registered", 'data'=> $x]);
                        }
                    }else{
                       
                        return response()->json(['status'=>400, 'message'=>$validator->errors()->first(), 'data'=> []]);
                        //return $validator->errors();
                    }
                      //********** If Else 
     
            } catch (\Illuminate\Database\QueryException $e) {
                //Log::error($e->getMessage());
                $response =  array(
                    'status' => 400,
                    'message' => "Internal Server Error",
                    'data' =>$e->getMessage()
                );
                return response()->json($response);
            }
     
    }  


}

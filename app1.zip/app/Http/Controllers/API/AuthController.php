<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\UserInspector;
use App\Models\AtFarmerRegDetail;
use App\Models\AtFarmerBankDetail;
use App\Models\AtFarmerLandDetail;
use App\Models\AtFarmerLandGeoDetail;
use App\Models\AtFarmerStandingCorpDetail;
use App\Models\AtFarmerProposedCorpDetail;
use App\Models\AtFarmerRegSchedule;
use App\Models\AtFarmerCropDetails;
use App\Models\RefState;
use App\Models\RefDistrict;
use App\Models\RefRegion;
use App\Models\RefVillage;
use App\Models\RefBank;
use App\Models\RefBlock;
use App\Models\AtBankDetails;
use App\Models\AtFarmDetails;
use App\Models\FarmersRegSchedule;
use App\Models\AtOspIcsIndividual;
use App\Models\AtFarmerDocumentsList;
use App\Models\RefCheckPoints;
use App\Models\InspectionSchedule;
use App\Models\AtFarmerChecklist;
use App\Models\AtFarmerInspectionDetail;
use App\Models\AtFarmerInspectionPlotDetails;
use App\Models\AtInspectionNonConformity;
use App\Models\RefGander;
use App\Models\RefSeason;
use App\Models\RefOrganicStatus;
use App\Models\RefHoldingType;
use App\Models\RefProduct;
use App\Models\AtInspectionApprovalInternalInspector;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use DB;
use Exception;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Illuminate\Support\Facades\Mail;
use RealRashid\SweetAlert\Facades\Alert;

//use StdClass;

class AuthController extends Controller
{
    public function register(Request $request)
    {
        $validatedData = $request->validate([
            'name' => 'required|max:55',
            'user_name' => 'required|max:55',
            'phone' => 'required|max:10',
            'email' => 'email|required|unique:users,email',
            'password' => 'required'
        ]);

        $validatedData['password'] = bcrypt($request->password);

        $user = User::create($validatedData);

        $accessToken = $user->createToken('authToken')->accessToken;

        return response(['user' => $user, 'access_token' => $accessToken]);
    }

    public function login(Request $request)
    {
        $x = new \stdClass();
        $validator = Validator::make($request->all(), [
            'email' => 'required',
            'password' => 'required',
            'user_type' => 'required',
            'login_type' => 'required'
        ]);

        if ($validator->fails()) {

            return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
            // return response()->json($validator->errors());
        } else {
            $userPass = hash('sha256', $request->password);
            $u = $request->email;
            $user_type = $request->user_type;
            $login_type = $request->login_type;
            $regData = array();
            $total = 0;
            $attempt = 0;
            $pending = 0;
            // $userdetails = UserInspector::where('email',$request->email)
            if ($user_type == 'inspector') {

                $userdetails = UserInspector::where(function ($query) use ($u) {
                    $query->where('email', $u)
                        ->orWhere('mobile_no', $u);
                })->where('password', $userPass)->first();

//dd($userdetails);
                if (empty($userdetails)) {
                    return response()->json(['status' => 400, 'message' => "Invalid Credentials", 'data' =>  $x]);
                }
            } else {
                return response()->json(['status' => 400, 'message' => "User type not found.", 'data' => $x]);
            }
            $accessToken = $userdetails->createToken('authToken')->accessToken;
            // return response(['user' => $userdetails, 'access_token' => $accessToken] );
            return response()->json(['status' => 200, 'message' => "Login Successfully", 'data' => $userdetails, 'access_token' => $accessToken]);
        }
    }
    // public function login(Request $request)
    // {
    //     $x = new \stdClass();
    //     $validator = Validator::make($request->all(), [
    //         'email' => 'required',
    //         'password' => 'required',
    //         'user_type' => 'required',
    //         'login_type' => 'required'
    //     ]);

    //     if ($validator->fails()) {
    //         return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
    //     } else {
    //         $userPass = hash('sha256', $request->password);
    //         $u = $request->email;
    //         $user_type = $request->user_type;
    //         $login_type = $request->login_type;

    //         if ($user_type == 'inspector') {
    //             $userdetails = UserInspector::where(function ($query) use ($u) {
    //                 $query->where('email', $u)
    //                     ->orWhere('mobile_no', $u);
    //             })->where('password', $userPass)->first();

    //             if (empty($userdetails)) {
    //                 return response()->json(['status' => 400, 'message' => "Invalid Credentials", 'data' =>  $x]);
    //             }
    //             $accessToken = $userdetails->createToken('authToken')->accessToken;
    //             $ddd['inspector info'] = [
    //                 'state_id'  => $userdetails->ref_state_id,
    //                 'state_name'  => getStateNameById($userdetails->id),
    //                 'city_id'  => $userdetails->ref_block_tehsil_id,
    //                 'city_name'  => getBlockTehsilByID($userdetails->ref_block_tehsil_id),
    //                 'accessToken' => $accessToken
    //             ];

    //             // Fetch state and city information
    //             //     $state = RefState::find($userdetails->id);
    //             //     $city = RefRegion::find($userdetails->id);

    //             //   // dd($state);

    //             //     // Add state and city information to the user details
    //             //     $userdetails->state_id = $state ? $state->id : null;
    //             //     $userdetails->state_name = $state ? $state->state_name : null;
    //             //     $userdetails->city_id = $city ? $city->id : null;
    //             //     $userdetails->city_name = $city ? $city->block_tehsil_name : null;


    //             return response()->json([
    //                 'status' => 200,
    //                 'message' => "Login Successfully",
    //                 'data' => $ddd,
    //                 // 'access_token' => $accessToken
    //             ]);
    //         } else {
    //             return response()->json(['status' => 400, 'message' => "User type not found.", 'data' => $x]);
    //         }
    //     }
    // }


    public function ForgetPassword(Request $request)
    {

        $validator = Validator::make($request->all(), [
            "email" => 'required| email|exists:at_ics_inspector_details'
        ]);
        if ($validator->fails()) {
            return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
        } else {

            $token = Str::random(64);
            DB::table('password_resets')->insert([
                'email' => $request->email,
                'token' => $token,
                'created_at' => Carbon::now()
            ]);
            Mail::send('mail.forgetPassword', ['token' => $token], function ($message) use ($request) {
                $message->to($request->email);
                $message->subject('Reset Password');
            });


            // return back()->with('message', 'We have e-mailed your password reset link!');
            return response()->json(['status' => 200, 'message' => "We have e-mailed your password reset link!", 'data' => []]);
        }
    }

    // public function showResetPasswordForm(Request $request){
    //     $updatePassword = DB::table('password_resets')
    //         ->where([
    //           'token' => $request->token
    //         ])
    //         ->first();
    //     return view('admin.ics.forgetpassword',compact('updatePassword'));

    // }

    public function ResetPassword(Request $request)
    {
        $validator = Validator::make($request->all(), [
            "mobile" => 'required',
            "old_password" => 'required',
            "password" => 'required| min:6| max:20',
            "password_confirmation" => 'required| min:6| max:20| same:password',
        ]);
        if ($validator->fails()) {
            return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
        } else {
            $obj = new \stdClass();
            $oldpassword = hash('sha256', $request->input('old_password'));
            $password = hash('sha256', $request->input('password'));
            $getData =  UserInspector::where(['mobile_no' => $request->input('mobile'), 'password' => $oldpassword])->first();
            if ($getData) {
                $resetpass = UserInspector::where(['mobile_no' => $request->input('mobile')])->update(['password' => $password]);
                //return $resetpass;
                $getupdate = UserInspector::where('mobile_no', $request->input('mobile'))->first();

                //********** If Else
                if (!empty($getupdate)) {
                    return response()->json(['status' => 200, 'message' => "Password Reset successfully", 'data' => $getupdate]);
                } else {
                    return response()->json(['status' => 400, 'message' => "Otp does not Match", 'data' => $obj]);
                }
            } else {

                return response()->json(['status' => 400, 'message' => "Data Not Found.", 'data' => $obj]);
            }
        }
        //********** If Else
    }
    public function farmerlist(Request $request)
    {
        $validator = Validator::make($request->all(), [
            "id" => 'required',
        ]);
        if ($validator->fails()) {
            return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
        } else {
            $ins = UserInspector::where('id', $request->id)->count();

            if ($ins > 0) {
                $farmerlist = AtFarmerRegDetail::where('at_ics_inspector_id', $request->id)->get();
                if (count($farmerlist) > 0) {
                    $data = array();
                    $i = 0;
                    foreach ($farmerlist as $val) {
                        $data[$i] = $val;
                        if ($val->farmerPhoto != '') {
                            $data[$i]['farmerPhoto'] = asset('public/farmers/') . '/' . $val->farmerPhoto;
                        } else {
                            $data[$i]['farmerPhoto'] = '';
                        }
                        $i++;
                    }
                    return response()->json(['status' => 200, 'message' => "Farmer list found", 'data' => $data]);
                } else {
                    return response()->json(['status' => 200, 'message' => "Farmer list not found", 'data' => []]);
                }
            } else {
                return response()->json(['status' => 400, 'message' => "Farmer Not found  sdsdsd", 'data' => []]);
            }
        }
    }

    public function getState()
    {
        $states = RefState::get();
        if ($states) {
            return response()->json(['status' => 200, 'message' => "states data", 'data' => $states]);
        } else {
            return response()->json(['status' => 400, 'message' => "states not Found", 'data' => []]);
        }
    }

    public function getDistrictByState($st)
    {
        $dis = RefDistrict::where('ref_state_id', $st)->get();
        if ($dis) {
            return response()->json(['status' => 200, 'message' => "district data", 'data' => $dis]);
        } else {
            return response()->json(['status' => 400, 'message' => "district not Found", 'data' => []]);
        }
    }

    public function getTalukByDistrict($dis)
    {
        $dis = RefRegion::where('ref_district_id', $dis)->get();
        if ($dis) {
            return response()->json(['status' => 200, 'message' => "Taluk data", 'data' => $dis]);
        } else {
            return response()->json(['status' => 400, 'message' => "Taluk not found", 'data' => []]);
        }
    }

    public function getvillByTaluk($tal)
    {
        $dis = RefVillage::where('ref_block_tehsil_id', $tal)->get();
        if ($dis) {
            return response()->json(['status' => 200, 'message' => "Village data", 'data' => $dis]);
        } else {
            return response()->json(['status' => 400, 'message' => "Village not found", 'data' => []]);
        }
    }

    public function getBanks()
    {
        $banks = RefBank::get();
        if ($banks) {
            return response()->json(['status' => 200, 'message' => "banks data", 'data' => $banks]);
        } else {
            return response()->json(['status' => 400, 'message' => "banks not found", 'data' => []]);
        }
    }



    // public function getHscode(){
    //     $codes = DB::table('ref_hscode')->get();
    //     if($codes){
    //         return response()->json(['status'=>200, 'message'=>"Hs Codes", 'data'=> $codes]);
    //     }else{
    //         return response()->json(['status'=>400, 'message'=>"Hs Codes not found", 'data'=> '']);
    //     }
    // }


    public function farmerDetails(Request $request)
    {
        try {
          // dd($request->all());
            $x = new \stdClass();
            $validator = Validator::make(
                $request->all(),
                [
                    "farmerDetails" => 'required',
                    // "farmerDetails.registration_no" =>'required',
                    "farmerDetails.aadhar_no" => 'required',
                    "farmerDetails.farmer_first_name" => 'required',
                    "farmerDetails.gender" => 'required',
                    // "farmerDetails.father_husband_flag" =>'required',
                    // "farmerDetails.father_husband_first_name" =>'required',
                    "farmerDetails.farmer_address" => 'required',
                    "farmerDetails.ref_state_id" => 'required',
                    "farmerDetails.ref_district_id" => 'required',
                    "farmerDetails.ref_block_tehsil_id" => 'required',
                    "farmerDetails.ref_village_id" => 'required',
                    "farmerDetails.pin" => 'required|numeric|digits:6',
                    "farmerDetails.mobile_no" => 'required',
                    "farmerDetails.at_ics_inspector_id" => 'required',
                   // 'landDetails.*.farm_owner' => 'required',
                    'landDetails.*.total_area_of_farm' => 'required',
                    'landDetails.*.survay_no' => 'required',
                    'landDetails.*.no_of_plot' => 'required',
                    'landDetails.*.completed_three_years_pgs' => 'required',
                    'landDetails.*.area_organic_cultivation' => 'required',
                    'landDetails.*.mStandingCrop' => 'required',
                    'landDetails.*.mStandingCrop.*.geotag.*.slatitude' => 'required',
                    'landDetails.*.mStandingCrop.*.geotag.*.slongitude' => 'required',
                    'landDetails.*.pin' => 'required|numeric|digits:6',
                  //  'landDetails.*.farmer_dairy' => 'required',
                    'ospDetails' => 'required',
                    //'ospDetails.source_org_sys_plan' => 'required',
                    'ospDetails.cropping_patterns' => 'required',
                    'ospDetails.main_crop' => 'required',
                    'ospDetails.inter_crop' => 'required',
                    'ospDetails.off_farm' => 'required',
                    'ospDetails.on_farm' => 'required',
                    'ospDetails.contamination_control' => 'required',
                    'ospDetails.pest_weed_mngmt' => 'required',
                    'ospDetails.nutrient_mngmt' => 'required',
                    //'bankDetails.pincode' => 'required|numeric|digits:6',


                    // 'standing_corp' => 'required',
                    // 'proposed_corp' => 'required',

                ],
                [
                    "farmerDetails.required" => 'Farmerdetail is required.',
                    "farmerDetails.aadhar_no.required" => 'Aadhar no. is required.',
                    "farmerDetails.farmer_first_name.required" => 'Farmer first name is required.',
                    "farmerDetails.gender.required" => 'Farmer gender is required.',
                    "farmerDetails.farmer_address.required" => 'Farmer Address is required.',
                    "farmerDetails.ref_state_id.required" => 'State is required.',
                    "farmerDetails.ref_district_id.required" => 'District is required.',
                    "farmerDetails.ref_block_tehsil_id.required" => 'Tehsil is required.',
                    "farmerDetails.ref_village_id.required" => 'Village is required.',
                    "farmerDetails.pin.required" => 'Pincode is required.',
                    "farmerDetails.pin.numeric" => 'Pincode should be numeric.',
                    "farmerDetails.pin.digits" => 'Pincode should be 6 digits.',
                    "farmerDetails.mobile_no.required" => 'Mobile no. is required.',
                    //'landDetails.*.farm_owner.required' => 'Farm owner is required.',
                    //'landDetails.*.near_by.required' => 'Farm near by is required.',
                    'landDetails.*.total_area_of_farm.required' => 'Total area of farm is required.',
                    'landDetails.*.survay_no.required' => 'Khata no. is required.',
                    'landDetails.*.no_of_plot.required' => 'No. of Plat is required.',
                    'landDetails.*.completed_three_years_pgs.required' => 'Completed three years is required.',
                    'landDetails.*.area_organic_cultivation.required' => 'Organic cultivation is required.',
                    'landDetails.*.mStandingCrop.required' => 'Standing Crop is required.',
                    'landDetails.*.mStandingCrop.*.geotag.*.slatitude.required' => 'Latitude is required.',
                    'landDetails.*.mStandingCrop.*.geotag.*.slongitude.required' => 'Longitude is required.',
                    "landDetails.pin.required" => 'Pincode is required.',
                    "landDetails.pin.numeric" => 'Pincode should be numeric.',
                    "landDetails.pin.digits" => 'Pincode should be 6 digits.',
                    'ospDetails.required' => 'OSP Detail is required.',
                   // 'ospDetails.source_org_sys_plan.required' => 'Source of Organic is required.',
                    'ospDetails.cropping_patterns.required' => 'Cropping patterns is required.',
                    'ospDetails.main_crop.required' => 'Main crop is required.',
                    'ospDetails.inter_crop.required' => 'Inter Crop is required.',
                    'ospDetails.off_farm.required' => 'Off farm is required.',
                    'ospDetails.on_farm.required' => 'On farm is required.',
                    'ospDetails.contamination_control.required' => 'Contamination Control is required.',
                    'ospDetails.pest_weed_mngmt.required' => 'Pest &  Weed Management is required.',
                    'ospDetails.nutrient_mngmt.required' => 'Nutrient management is required.',
                ]
            );
            if (!$validator->fails()) {
                $data = array(
                    "registration_no" => !empty($request->farmerDetails['registration_no']) ? $request->farmerDetails['registration_no'] : 'Null',
                    "registration_date" => !empty($request->farmerDetails['registration_date']) ? $request->farmerDetails['registration_date'] : 'Null',
                    "owner_farmerid" => !empty($request->farmerDetails['owner_farmerid']) ? $request->farmerDetails['owner_farmerid'] : 'Null',
                    "farmer_first_name" => !empty($request->farmerDetails['farmer_first_name']) ? $request->farmerDetails['farmer_first_name'] : 'Null',
                    "farmer_middle_name" => !empty($request->farmerDetails['farmer_middle_name']) ? $request->farmerDetails['farmer_middle_name'] : 'Null',
                    "farmer_last_name" => !empty($request->farmerDetails['farmer_last_name']) ? $request->farmerDetails['farmer_last_name'] : 'Null',
                    "gender" => !empty($request->farmerDetails['gender']) ? $request->farmerDetails['gender'] : 'Null',
                    "father_husband_flag" => !empty($request->farmerDetails['father_husband_flag']) ? $request->farmerDetails['father_husband_flag'] : 'Null',
                    "father_husband_first_name" => !empty($request->farmerDetails['father_husband_first_name']) ? $request->farmerDetails['father_husband_first_name'] : 'Null',
                    "father_husband_middle_name" => !empty($request->farmerDetails['father_husband_middle_name']) ? $request->farmerDetails['father_husband_middle_name'] : 'Null',
                    "father_husband_last_name" => !empty($request->farmerDetails['father_husband_last_name']) ? $request->farmerDetails['father_husband_last_name'] : 'Null',
                    "farmer_address" => !empty($request->farmerDetails['farmer_address']) ? $request->farmerDetails['farmer_address'] : 'Null',
                    "landmark" => !empty($request->farmerDetails['landmark']) ? $request->farmerDetails['landmark'] : 'Null',
                    "ref_state_id" => !empty($request->farmerDetails['ref_state_id']) ? $request->farmerDetails['ref_state_id'] : 'Null',
                    "ref_district_id" => !empty($request->farmerDetails['ref_district_id']) ? $request->farmerDetails['ref_district_id'] : 'Null',
                    "ref_block_tehsil_id" => !empty($request->farmerDetails['ref_block_tehsil_id']) ? $request->farmerDetails['ref_block_tehsil_id'] : 'Null',
                    "ref_village_id" => !empty($request->farmerDetails['ref_village_id']) ? $request->farmerDetails['ref_village_id'] : 'Null',
                    "pin" => !empty($request->farmerDetails['pin']) ? $request->farmerDetails['pin'] : 'Null',
                    "mobile_no" => !empty($request->farmerDetails['mobile_no']) ? $request->farmerDetails['mobile_no'] : 'Null',
                    "email_id" => !empty($request->farmerDetails['email_id']) ? $request->farmerDetails['email_id'] : 'Null',
                    "at_ics_inspector_id" => !empty($request->farmerDetails['at_ics_inspector_id']) ? $request->farmerDetails['at_ics_inspector_id'] : 'Null',
                    "at_user_id" => !empty($request->farmerDetails['at_user_id']) ? $request->farmerDetails['at_user_id'] : 'Null',
                    "farmerPhoto" => !empty($request->farmerDetails['farmerPhoto']) ? $request->farmerDetails['farmerPhoto'] : 'Null',
                    "aadhar_number" => !empty($request->farmerDetails['aadhar_no']) ? $request->farmerDetails['aadhar_no'] : 'Null',
                );
                

                $farmer = AtFarmerRegDetail::create($data);
                //dd($farmer);
                $reg_no = getFarmerRegNo($farmer->id, $request->farmerDetails['ref_state_id']);
                AtFarmerRegDetail::where('id', $farmer->id)->update(['registration_no' => $reg_no, 'owner_farmerid' => $reg_no]);
                
                if ($farmer) {
                    // add bank details

                    if (!empty($request->bankDetails['ref_bank_id'])) {
                        $bank = array(
                            'ref_bank_id' => $request->bankDetails['ref_bank_id'],
                            'at_farmer_reg_id' => $farmer->id,
                            "bank_name" => $request->bankDetails['bank_name'],
                            "account_number" => $request->bankDetails['account_number'],
                            "ifsc_code" => $request->bankDetails['ifsc_code'],
                            "branch_name" => $request->bankDetails['branch_name'],
                            "bank_address" => $request->bankDetails['bank_address'],
                            "pincode" => $request->bankDetails['pincode']
                        );
                        $banks = AtFarmerBankDetail::create($bank);
                    }
                    // Land_details
                    if (!empty($request->landDetails)) {
                        foreach ($request->landDetails as $lands) {

                            $land = array(
                                "at_farmer_reg_details_id" => $farmer->id,
                                //"registration_no"=>$request->farmerDetails['registration_no']??'',
                                "owner_farmerid" => $farmer->id,
                                "farm_name" => $lands['farm_owner'],
                                // "farm_name" => $lands['ownership_type'] == 'self' 
                                //     ? $lands['farm_owner'] 
                                //     : $lands['farm_owner'] . " | " . $lands['owner_mobile'],
                                "landmark" => !empty($lands['landmark']) ? $lands['landmark'] : Null,
                                "pin" => !empty($lands['pin']) ? $lands['pin'] : Null,
                                "farm_no" => !empty($lands['farm_no']) ? $lands['farm_no'] : Null,
                                "area_in_ha" => !empty($lands['total_area_of_farm']) ? $lands['total_area_of_farm'] : 0,
                                "total_area" => !empty($lands['total_area_of_farm']) ? $lands['total_area_of_farm'] : 0,
                                "survay_no" => !empty($lands['survay_no']) ? $lands['survay_no'] : Null,
                                "no_of_plot" => !empty($lands['no_of_plot']) ? $lands['no_of_plot'] : Null,
                                "ref_state_id" => !empty($request->farmerDetails['ref_state_id']) ? $request->farmerDetails['ref_state_id'] : Null,
                                "ref_district_id" => !empty($request->farmerDetails['ref_district_id']) ? $request->farmerDetails['ref_district_id'] : Null,
                                "ref_block_tehsil_id" => !empty($request->farmerDetails['ref_block_tehsil_id']) ? $request->farmerDetails['ref_block_tehsil_id'] : Null,
                                "ref_village_id" => !empty($request->farmerDetails['ref_village_id']) ? $request->farmerDetails['ref_village_id'] : Null,
                                "near_by" => !empty($lands['near_by']) ? $lands['near_by'] : Null,
                                "farm_processing" => !empty($lands['farm_processing']) ? $lands['farm_processing'] : 0,
                                "completed_three_years_pgs" => !empty($lands['completed_three_years_pgs']) ? $lands['completed_three_years_pgs'] : Null,
                                "pgs_certificate" => !empty($lands['pgs_certificate']) ? $lands['pgs_certificate'] : Null,
                                "ref_organic_status_master_id" => '4',
                                "area_organic_cultivation" => !empty($lands['area_organic_cultivation']) ? $lands['area_organic_cultivation'] : 0,
                                "farmer_dairy" => !empty($lands['farmer_dairy']) ? $lands['farmer_dairy'] : Null,
                            );
                            
                           // dd($land);
                            $landdet = AtFarmerLandDetail::create($land);
//dd($landdet);
                            $farmreg_no = getFarmRegNo($landdet->id, $request->farmerDetails['ref_state_id'],);
                            AtFarmerLandDetail::where('id', $landdet->id)->update(['registration_no' => $farmreg_no, 'farm_no' => $farmreg_no]);

                            if (!empty($lands['mStandingCrop'])) {
                                // mStandingCrop details
                                foreach ($lands['mStandingCrop'] as $sscorp) {
                                    $scorp = array(
                                        "ref_product_id" => $sscorp['ref_hscode_id'],
                                        "season_name" => $sscorp['season_name'],
                                        "crop_name" => $sscorp['crop_name'],
                                        "crop_area" => $sscorp['area'],
                                        "crop_photo" => $sscorp['crop_photo'],
                                        "geotag_photo" => $sscorp['geotag_photo'],
                                        "organic_status" => $sscorp['organic_status'],
                                        "at_farmer_details_id" => $farmer->id,
                                        "at_farm_details_id" => $landdet->id
                                    );
                                    $scorps = AtFarmerStandingCorpDetail::create($scorp);

                                    //geotag details
                                    if (!empty($sscorp['geotag'])) {
                                        foreach ($sscorp['geotag'] as $geos) {
                                            $geo = array(
                                                "at_farmer_reg_details_id" => $farmer->id,
                                                "latitude" => $geos['slatitude'],
                                                "longitude" => $geos['slongitude'],
                                                "at_farm_id" => $landdet->id,
                                                "at_farm_standing_crop_id" => $scorps->id
                                            );
                                            $geos = AtFarmerLandGeoDetail::create($geo);
                                        }
                                    }
                                }
                            }

                            if (!empty($lands['mProposedCrop'])) {
                                // mProposedCrop details
                                foreach ($lands['mProposedCrop'] as $ppcorp) {
                                    $pcorp = array(
                                        "ref_product_id" => $ppcorp['ref_hscode_id'],
                                        "season_name" => $ppcorp['season_name'],
                                        "crop_name" => $ppcorp['crop_name'],
                                        "crop_area" => $ppcorp['area'],
                                        "organic_status" => $ppcorp['organic_status'],
                                        "at_farmer_details_id" => $farmer->id,
                                        "at_farm_details_id" => $landdet->id
                                    );
                                    $ps = AtFarmerProposedCorpDetail::create($pcorp);
                                }
                            }

                            if ($request->docDetails) {
                                $udoc = array(
                                    // "aadhar_card_image_path" => $request->docDetails['aadhar_card'],
                                    "pan_card_image_path" => $request->docDetails['pan_card'],
                                    "land_documents_image_path" => $request->docDetails['land_doc'],
                                    "passbook_image_path" => $request->docDetails['bank_doc'],
                                    // "contact_person_sign_image_path" => $request->docDetails['sign_doc'],
                                    "live_signature_image_path" => $request->docDetails['sign_doc'],
                                    "voter_id_card" => $request->docDetails['voter_id_card'],
                                    "kishan_credit_card" => $request->docDetails['kishan_credit_card'],
                                    "ration_card" => $request->docDetails['ration_card'],
                                    "at_farmer_details_id" => $farmer->id


                                );

                                $scorps = AtFarmerDocumentsList::create($udoc);
                            }

                            if ($request->ospDetails) {
                                $osp = array(
                                    "source_of_organic_system_plan" => $request->ospDetails['source_org_sys_plan'],
                                    "cropping_pattern" => $request->ospDetails['cropping_patterns'],
                                    "covered_area_main_corp" => $request->ospDetails['main_crop'],
                                    "covered_area_inter_corp" => $request->ospDetails['inter_crop'],
                                    "off_farm" => $request->ospDetails['off_farm'],
                                    "on_farm" => $request->ospDetails['on_farm'],
                                    "contamination_control" => $request->ospDetails['contamination_control'],
                                    "pease_weed_management" => $request->ospDetails['pest_weed_mngmt'],
                                    "nutrient_management" => $request->ospDetails['nutrient_mngmt'],
                                    "at_farmer_reg_details_id" => $farmer->id
                                );
                                $ospssaave = AtOspIcsIndividual::create($osp);
                            }

                            FarmersRegSchedule::where(['at_ics_inspector_details_id' => $request->farmerDetails['at_ics_inspector_id'], 'ref_village_id' => $request->farmerDetails['ref_village_id']])->increment('total_attempt');
                        }
                    }
                }

                //********** If Else
                if ($farmer) {
                    return response()->json(['status' => 200, 'message' => "Farmer Successfully Registered", 'data' => $x]);
                } else {
                    return response()->json(['status' => 200, 'message' => "Farmer Not Registered", 'data' => $x]);
                }
            } else {

                return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
                //return $validator->errors();
            }
            //********** If Else

        } catch (\Illuminate\Database\QueryException $e) {
            //Log::error($e->getMessage());

            $response =  array(
                'status' => 400,
                'message' => "Internal Server Error",
                'data' => $e->getMessage()
            );
            return response()->json($response);
        }
    }

    public function updateFarmerDetails(Request $request, $farmer_id)
    {
        try {
            //dd($request->all());
            $x = new \stdClass();
            $validator = Validator::make(
                $request->all(),
                [
                    "farmerDetails" => 'required',
                    "farmerDetails.aadhar_no" => 'required',
                    "farmerDetails.farmer_first_name" => 'required',
                    "farmerDetails.gender" => 'required',
                    "farmerDetails.farmer_address" => 'required',
                    "farmerDetails.ref_state_id" => 'required',
                    "farmerDetails.ref_district_id" => 'required',
                    "farmerDetails.ref_block_tehsil_id" => 'required',
                    "farmerDetails.ref_village_id" => 'required',
                    "farmerDetails.pin" => 'required|numeric|digits:6',
                    "farmerDetails.mobile_no" => 'required',
                    "farmerDetails.at_ics_inspector_id" => 'required',
                    'landDetails.*.farm_owner' => 'required',
                    'landDetails.*.total_area_of_farm' => 'required',
                    'landDetails.*.survay_no' => 'required',
                    'landDetails.*.no_of_plot' => 'required',
                    'landDetails.*.completed_three_years_pgs' => 'required',
                    'landDetails.*.area_organic_cultivation' => 'required',
                    'landDetails.*.mStandingCrop' => 'required',
                    'landDetails.*.mStandingCrop.*.geotag.*.slatitude' => 'required',
                    'landDetails.*.mStandingCrop.*.geotag.*.slongitude' => 'required',
                    'landDetails.*.pin' => 'required|numeric|digits:6',
                    'ospDetails' => 'required',
                    'ospDetails.cropping_patterns' => 'required',
                    'ospDetails.main_crop' => 'required',
                    'ospDetails.inter_crop' => 'required',
                    'ospDetails.off_farm' => 'required',
                    'ospDetails.on_farm' => 'required',
                    'ospDetails.contamination_control' => 'required',
                    'ospDetails.pest_weed_mngmt' => 'required',
                    'ospDetails.nutrient_mngmt' => 'required',
                ]
            );

            if (!$validator->fails()) {
                // Update Farmer Details
                $data = [
                    "registration_no" => $request->farmerDetails['registration_no'] ?? '',
                    "registration_date" => $request->farmerDetails['registration_date'],
                    "owner_farmerid" => $request->farmerDetails['owner_farmerid'] ?? '',
                    "farmer_first_name" => $request->farmerDetails['farmer_first_name'],
                    "farmer_middle_name" => $request->farmerDetails['farmer_middle_name'],
                    "farmer_last_name" => $request->farmerDetails['farmer_last_name'],
                    "gender" => $request->farmerDetails['gender'],
                    "father_husband_flag" => $request->farmerDetails['father_husband_flag'] ?? '',
                    "father_husband_first_name" => $request->farmerDetails['father_husband_first_name'] ?? '',
                    "father_husband_middle_name" => $request->farmerDetails['father_husband_middle_name'] ?? '',
                    "father_husband_last_name" => $request->farmerDetails['father_husband_last_name'] ?? '',
                    "farmer_address" => $request->farmerDetails['farmer_address'],
                    "landmark" => $request->farmerDetails['landmark'],
                    "ref_state_id" => $request->farmerDetails['ref_state_id'],
                    "ref_district_id" => $request->farmerDetails['ref_district_id'],
                    "ref_block_tehsil_id" => $request->farmerDetails['ref_block_tehsil_id'],
                    "ref_village_id" => $request->farmerDetails['ref_village_id'],
                    "pin" => $request->farmerDetails['pin'],
                    "mobile_no" => $request->farmerDetails['mobile_no'],
                    "email_id" => $request->farmerDetails['email_id'],
                    "at_ics_inspector_id" => $request->farmerDetails['at_ics_inspector_id'],
                    "at_user_id" => $request->farmerDetails['at_user_id'],
                    "farmerPhoto" => $request->farmerDetails['farmerPhoto'],
                    "aadhar_number" => $request->farmerDetails['aadhar_no']
                ];

                $farmer = AtFarmerRegDetail::where('id', $farmer_id)->update($data);

                if ($farmer) {
                    // Update Bank Details if available
                    if (!empty($request->bankDetails['ref_bank_id'])) {
                        $bank = [
                            'ref_bank_id' => $request->bankDetails['ref_bank_id'],
                            'at_farmer_reg_id' => $farmer_id,
                            "bank_name" => $request->bankDetails['bank_name'],
                            "account_number" => $request->bankDetails['account_number'],
                            "ifsc_code" => $request->bankDetails['ifsc_code'],
                            "branch_name" => $request->bankDetails['branch_name'],
                            "bank_address" => $request->bankDetails['bank_address'],
                            "pincode" => $request->bankDetails['pincode']
                        ];
                        AtFarmerBankDetail::updateOrCreate(['at_farmer_reg_id' => $farmer_id], $bank);
                    }

                    // Update Land Details
                    if (!empty($request->landDetails)) {
                        foreach ($request->landDetails as $lands) {
                            $land = [
                                "at_farmer_reg_details_id" => $farmer_id,
                                "owner_farmerid" => $farmer_id,
                                "farm_name" => $lands['farm_owner'],
                                "landmark" => $lands['landmark'] ?? 0,
                                "pin" => $lands['pin'] ?? 0,
                                "farm_no" => $lands['farm_no'] ?? 0,
                                "area_in_ha" => $lands['total_area_of_farm'],
                                "total_area" => $lands['total_area_of_farm'],
                                "survay_no" => $lands['survay_no'],
                                "no_of_plot" => $lands['no_of_plot'],
                                "ref_state_id" => $request->farmerDetails['ref_state_id'],
                                "ref_district_id" => $request->farmerDetails['ref_district_id'],
                                "ref_block_tehsil_id" => $request->farmerDetails['ref_block_tehsil_id'],
                                "ref_village_id" => $request->farmerDetails['ref_village_id'],
                                "farm_processing" => $lands['farm_processing'] ?? 0,
                                "completed_three_years_pgs" => $lands['completed_three_years_pgs'],
                                "pgs_certificate" => $lands['pgs_certificate'],
                                "ref_organic_status_master_id" => '4',
                                "area_organic_cultivation" => $lands['area_organic_cultivation'] ?? 0
                            ];
                            AtFarmerLandDetail::updateOrCreate(['at_farmer_reg_details_id' => $farmer_id], $land);

                            // Update Standing Crop Details
                            if (!empty($lands['mStandingCrop'])) {
                                foreach ($lands['mStandingCrop'] as $sscorp) {
                                    $scorp = [
                                        "ref_product_id" => $sscorp['ref_hscode_id'],
                                        "season_name" => $sscorp['season_name'],
                                        "crop_name" => $sscorp['crop_name'],
                                        "crop_area" => $sscorp['area'],
                                        "crop_photo" => $sscorp['crop_photo'],
                                        "geotag_photo" => $sscorp['geotag_photo'],
                                        "organic_status" => $sscorp['organic_status'],
                                        "at_farmer_details_id" => $farmer_id
                                    ];
                                    $scorps =  AtFarmerStandingCorpDetail::updateOrCreate(['at_farmer_details_id' => $farmer_id], $scorp);

                                    if (!empty($sscorp['geotag'])) {
                                        foreach ($sscorp['geotag'] as $geos) {
                                            $geo = [
                                                "at_farmer_reg_details_id" => $farmer_id,
                                                "latitude" => $geos['slatitude'],
                                                "longitude" => $geos['slongitude'],
                                                "at_farm_id" => $farmer_id,
                                                "at_farm_standing_crop_id" => $scorps->id
                                            ];
                                            AtFarmerLandGeoDetail::updateOrCreate(['at_farmer_reg_details_id' => $farmer_id], $geo);
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (!empty($lands['mProposedCrop'])) {
                        foreach ($lands['mProposedCrop'] as $ppcorp) {
                            $pcorp = [
                                "ref_product_id" => $ppcorp['ref_hscode_id'],
                                "season_name" => $ppcorp['season_name'],
                                "crop_name" => $ppcorp['crop_name'],
                                "crop_area" => $ppcorp['area'],
                                "organic_status" => $ppcorp['organic_status'],
                                "at_farmer_details_id" => $farmer_id
                            ];
                            AtFarmerProposedCorpDetail::updateOrCreate(['at_farmer_details_id' => $farmer_id], $pcorp);
                        }
                    }
                    if ($request->docDetails) {
                        $udoc = array(
                            // "aadhar_card_image_path" => $request->docDetails['aadhar_card'],
                            "pan_card_image_path" => $request->docDetails['pan_card'],
                            "land_documents_image_path" => $request->docDetails['land_doc'],
                            "passbook_image_path" => $request->docDetails['bank_doc'],
                            // "contact_person_sign_image_path" => $request->docDetails['sign_doc'],
                            "live_signature_image_path" => $request->docDetails['sign_doc'],
                            "voter_id_card" => $request->docDetails['voter_id_card'],
                            "kishan_credit_card" => $request->docDetails['kishan_credit_card'],
                            "ration_card" => $request->docDetails['ration_card'],
                            "at_farmer_details_id" => $farmer_id


                        );

                        $scorps = AtFarmerDocumentsList::updateOrCreate(['at_farmer_details_id' => $farmer_id], $udoc);
                    }

                    // Update OSP Details
                    if (!empty($request->ospDetails)) {
                        $osp = [
                            "source_of_organic_system_plan" => $request->ospDetails['source_org_sys_plan'],
                            "cropping_pattern" => $request->ospDetails['cropping_patterns'],
                            "covered_area_main_corp" => $request->ospDetails['main_crop'],
                            "covered_area_inter_corp" => $request->ospDetails['inter_crop'],
                            "off_farm" => $request->ospDetails['off_farm'],
                            "on_farm" => $request->ospDetails['on_farm'],
                            "contamination_control" => $request->ospDetails['contamination_control'],
                            "pease_weed_management" => $request->ospDetails['pest_weed_mngmt'],
                            "nutrient_management" => $request->ospDetails['nutrient_mngmt'],
                            "at_farmer_reg_details_id" => $farmer_id
                        ];
                        AtOspIcsIndividual::updateOrCreate(['at_farmer_reg_details_id' => $farmer_id], $osp);
                    }

                    $x->status = "Success";
                    $x->msg = "Farmer record updated successfully!";
                } else {
                    $x->status = "Error";
                    $x->msg = "Error while updating farmer record.";
                }
            } else {
                $x->status = "Validation Error";
                $x->msg = $validator->errors();
            }
        } catch (Exception $ex) {
            $x->status = "Exception";
            $x->msg = $ex->getMessage();
        }

        return response()->json($x);
    }


    public function getScheduleLocByInsId($id)
    {
        $diss = FarmersRegSchedule::where('at_ics_inspector_details_id', $id)->get();
        //dd($diss);
        if (!empty($diss)) {
            $dis = array();
            $i = 0;
            foreach ($diss as $key => $vals) {
                $dis[$i] = $vals;
                $dis[$i++]['address'] = 'Vill -' . getVillName($vals->ref_village_id) . ', Block-' . getTalukName($vals->ref_block_tehsil_id) . ', District-' . getDisName($vals->ref_district_id) . ', State-' . getStateName($vals->ref_state_id);
                //if($vals->status==0)
                //$vals->status='Pending';
            }
            if (count($dis) > 0) {
                return response()->json(['status' => 200, 'message' => "Scheduled Location data", 'data' => $dis]);
            } else {
                return response()->json(['status' => 400, 'message' => "Scheduled list not found", 'data' => []]);
            }
        } else {
            return response()->json(['status' => 400, 'message' => "No Scheduled Location Found", 'data' => []]);
        }
    }


    public function getInspectionSchedule($id)
    {
        $diss = InspectionSchedule::where('at_ics_inspector_details_id', $id)->get();
        // dd($diss);
        if (!empty($diss)) {
            $dis = array();
            $i = 0;
            foreach ($diss as $key => $vals) {
                $dis[$i] = $vals;
                $dis[$i++]['address'] = 'Vill -' . getVillName($vals->ref_village_id) . ', Block-' . getTalukName($vals->ref_block_tehsil_id) . ', District-' . getDisName($vals->ref_district_id) . ', State-' . getStateName($vals->ref_state_id);
                //if($vals->status==0)
                //$vals->status='Pending';
            }
            if (count($dis) > 0) {
                return response()->json(['status' => 200, 'message' => "Inspection Scheduled  data", 'data' => $dis]);
            } else {
                return response()->json(['status' => 400, 'message' => "Inspection Scheduled list not found", 'data' => []]);
            }
        } else {
            return response()->json(['status' => 400, 'message' => "No Inspection Scheduled  Found", 'data' => []]);
        }
    }


    public function getFarmerSchedule()
    {
        $diss = FarmersRegSchedule::all();
        // dd($diss);
        if (!empty($diss)) {
            $dis = array();
            $i = 0;
            foreach ($diss as $key => $vals) {
                $dis[$i] = $vals;
                $dis[$i++]['address'] = 'Vill -' . getVillName($vals->ref_village_id) . ', Block-' . getTalukName($vals->ref_block_tehsil_id) . ', District-' . getDisName($vals->ref_district_id) . ', State-' . getStateName($vals->ref_state_id);
                //if($vals->status==0)
                //$vals->status='Pending';
            }
            if (count($dis) > 0) {
                return response()->json(['status' => 200, 'message' => "Farmer Scheduled  data", 'data' => $dis]);
            } else {
                return response()->json(['status' => 400, 'message' => "Farmer Scheduled list not found", 'data' => []]);
            }
        } else {
            return response()->json(['status' => 400, 'message' => "No Farmer Scheduled  Found", 'data' => []]);
        }
    }

    public function getFarmSchedule()
    {
        $diss = AtFarmDetails::all();
        // dd($diss);
        if (!empty($diss)) {
            $dis = array();
            $i = 0;
            foreach ($diss as $key => $vals) {
                $dis[$i] = $vals;
                $dis[$i++]['address'] = 'Vill -' . getVillName($vals->ref_village_id) . ', Block-' . getTalukName($vals->ref_block_tehsil_id) . ', District-' . getDisName($vals->ref_district_id) . ', State-' . getStateName($vals->ref_state_id);
                //if($vals->status==0)
                //$vals->status='Pending';
            }
            if (count($dis) > 0) {
                return response()->json(['status' => 200, 'message' => "Farmer Scheduled  data", 'data' => $dis]);
            } else {
                return response()->json(['status' => 400, 'message' => "Farmer Scheduled list not found", 'data' => []]);
            }
        } else {
            return response()->json(['status' => 400, 'message' => "No Farmer Scheduled  Found", 'data' => []]);
        }
    }



    public function regFarmerList(Request $request)
    {
        $x = new \stdClass();

        $validator = Validator::make($request->all(), [
            "village_id" => 'required',
        ]);
        if (!$validator->fails()) {
            $data = array();
            $insp_id = $request->at_inspector_id;
            $village = $request->village_id;
            $farmerList = AtFarmerRegDetail::where('ref_village_id', $village)->where('farmer_reg_status', 0)->get();

            foreach ($farmerList as $key => $flist) {
                $data[$key]['farmer_id'] = $flist['id'] ?? '';
                $data[$key]['farmer_name'] = $flist['farmer_first_name'] ?? '';
                $data[$key]['mobile'] = $flist['mobile_no'] ?? '';
                $data[$key]['address'] = 'Vill -' . getVillName($flist->ref_village_id) . ', Block-' . getTalukName($flist->ref_block_tehsil_id) . ', District-' . getDisName($flist->ref_district_id) . ', State-' . getStateName($flist->ref_state_id);;
                $data[$key]['status'] = $flist['farmer_reg_status'] ?? '0';
            }

            if ($farmerList->count() > 0) {
                return response()->json(['status' => 200, 'message' => "farmer data", 'data' => $farmerList]);
            } else {
                return response()->json(['status' => 400, 'message' => "farmer not Found", 'data' => []]);
            }
        } else {
            return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
        }
    }

    public function scheduleAccRej(Request $request)
    {
        $validator = Validator::make($request->all(), [
            "id" => 'required',
            "status" => 'required',
        ]);
        if ($validator->fails()) {
            return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
        } else {
            if (!empty($request->status)) {

                $data = FarmersRegSchedule::where('id', $request->id)->update(['status' => $request->status]);

                if ($request->status == 1) {
                    return response()->json(['status' => 200, 'message' => "Scheduled has been accepted.", 'data' => []]);
                } elseif ($request->status == 2) {
                    return response()->json(['status' => 200, 'message' => "Scheduled has been rejected.", 'data' => []]);
                } else {
                    return response()->json(['status' => 400, 'message' => "Something went wrong.", 'data' => []]);
                }
            } else {
                return response()->json(['status' => 400, 'message' => "No Scheduled Location Found", 'data' => []]);
            }
        }
    }

    public function fileUploads(Request $request)
    {
        // dd('gg');
        $validator = Validator::make(
            $request->all(),
            [
                'file_type' => 'required',
                'docfile' => 'required|mimes:jpeg,jpg,png,pdf,xlx,csv|max:10000'
            ]
        );

        try {
            if ($validator->fails()) {
                return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
            } else {
                $getImage2 = $request->docfile;
                $imageName2 = time() . '.' . $getImage2->extension();
                $imagePath = public_path() . '/farmers/';
                if ($getImage2->move($imagePath, $imageName2)) {
                    $response =  array(
                        'status' => 200,
                        'message' => "File Uploaded",
                        'data' => array($request->file_type, $imageName2)
                    );
                } else {
                    $response =  array(
                        'status' => 400,
                        'message' => "File Not Uploaded",
                        'data' => array()
                    );
                }
                return response()->json($response);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            $response =  array(
                'status' => 400,
                'message' => "Internal Server Error",
                'data' => array()
            );


            return response()->json($response);
        }
    }

    public function multipleUploads(Request $request)
    {
       
        $validator = Validator::make(
            $request->all(),
            [
                'doc.*' => 'required|mimes:jpeg,jpg,png,pdf|max:10000',
            ]
        );

    
        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'message' => $validator->errors()->first(),
                'data' => []
            ]);
        }

        $filePaths = [];

       
        if ($request->hasFile('doc')) {
            foreach ($request->file('doc') as $doc) {

                $fileName = time() . '_' . $doc->getClientOriginalName();
                $filePath = public_path('farmers');

             
                if (!file_exists($filePath)) {
                    mkdir($filePath, 0755, true);
                }

              
                if ($doc->move($filePath, $fileName)) {
                    $filePaths[] = '/farmers/' . $fileName;
                } else {
                    return response()->json([
                        'status' => 400,
                        'message' => "Error uploading $fileName",
                        'data' => []
                    ]);
                }
            }
        } else {
            return response()->json([
                'status' => 400,
                'message' => "No files were uploaded",
                'data' => []
            ]);
        }

      
        return response()->json([
            'status' => 200,
            'message' => "Files Uploaded Successfully",
            'data' => $filePaths
        ]);
    }

    public function inspDashboard(Request $request)
    {
        // chech inspection assignment

        $id = $request->id;
        $type = $request->login_type;

        $data = array();
        if ($type == 'registration') {

            //$data['total'] = FarmersRegSchedule::where('at_ics_inspector_details_id',$id)->get()->count();
            // $data['attempt'] = FarmersRegSchedule::where('at_ics_inspector_details_id',$id)->where('status',1)->get()->count();
            $data['total_farmers'] = FarmersRegSchedule::where('at_ics_inspector_details_id', $id)->sum('number_of_farmer_reg');
            $data['attempt_farmers'] = FarmersRegSchedule::where('at_ics_inspector_details_id', $id)->sum('total_attempt');
            $data['pending_farmers'] = $data['total_farmers'] - $data['attempt_farmers'];
        }
        if ($type == 'inspection') {

            $inspData = InspectionSchedule::where('at_ics_inspector_details_id', $id)->get();

            if (!empty($inspData)) {
                $data['from_date'] = $inspData[0]->schedule_period_from ?? '';
                $data['to_date'] = $inspData[0]->schedule_period_to ?? '';
                $data['total_farmers'] = InspectionSchedule::where('at_ics_inspector_details_id', $id)->sum('number_of_farmers');
                $data['villagesData'] = array();

                foreach ($inspData as $key => $value) {
                    $data['villagesData'][$key]['vill_id'] = $value->ref_village_id;
                    $data['villagesData'][$key]['vill_name'] = get_village_name_by_id($value->ref_village_id);
                    $data['villagesData'][$key]['total_farmers'] = InspectionSchedule::where('at_ics_inspector_details_id', $id)->where('ref_village_id', $value->ref_village_id)->first()->number_of_farmers;
                    $data['villagesData'][$key]['attempt'] = InspectionSchedule::where('at_ics_inspector_details_id', $id)->where('ref_village_id', $value->ref_village_id)->first()->total_attempt;
                    $data['villagesData'][$key]['pending'] = $data['villagesData'][$key]['total_farmers'] - $data['villagesData'][$key]['attempt'];
                }
            }
        }
        //$empty_data=array();
        if (!empty($data['total_farmers'])) {
            $response =  array('status' => 200, 'message' => "Data found", 'data' => $data);
        } else {
            $response =  array('status' => 400, 'message' => "Data not found", 'data' => $data);
        }
        return response()->json($response);
    }



    public function getCheckPoints(Request $request)
    {

        // 1- Animal Husbandry,  2- Farm Management,  3 - Post Harvest Measures and Processing, 4 - Risk Management
        $type = $request->type;
        //dd($type);
        if ($type == '1') {
            $ty = 'Animal Husbandry';
        } elseif ($type == '2') {
            $ty = 'Farm Management';
        } elseif ($type == '3') {
            $ty = 'Post Harvest Measures and Processing';
        } elseif ($type == '4') {
            $ty = 'Risk Management';
        }
        $checklist = RefCheckPoints::where('type', $ty)->get();
        if ($checklist) {
            return response()->json(['status' => 200, 'message' => "checkPoints data", 'data' => $checklist]);
        } else {
            return response()->json(['status' => 400, 'message' => "CheckPoints not Found", 'data' => []]);
        }
    }


    public function farmManagement(Request $request)
    {
        $x = new \stdClass();
        $validator = Validator::make($request->all(), [
            "type_id" => 'required',
            "checklist.*" => 'required',
            "checklist.*.at_farmer_reg_details_id" => 'required',
            "checklist.*.at_inspector_id" => 'required',
            "checklist.*.ref_insepction_checklist_id" => 'required',
            "checklist.*.check_points_flag" => 'required',
            "checklist.*.check_points_remarks" => 'required',

        ]);
        if (!$validator->fails()) {
            if (!empty($request->checklist)) {

                foreach ($request->checklist as $chlist) {
                    $data = array(
                        "at_farmer_reg_details_id" => $chlist['at_farmer_reg_details_id'] ?? '',
                        "at_inspector_id" => $chlist['at_inspector_id'] ?? '',
                        "ref_insepction_checklist_id" => $chlist['ref_insepction_checklist_id'] ?? '',
                        "check_points_flag" => $chlist['check_points_flag'] ?? '',
                        "check_points_remarks" => $chlist['check_points_remarks'] ?? '',
                        "type" => $request->type_id ?? '',
                        "inspection_status" => 1
                    );

                    $checkPoint = AtFarmerChecklist::create($data);
                }
                if ($checkPoint) {

                    return response()->json(['status' => 200, 'message' => "Data Successfully Saved.", 'data' => $x]);
                } else {
                    return response()->json(['status' => 200, 'message' => "Data not saved.", 'data' => $x]);
                }
            }
        } else {
            return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
        }
    }

    public function inspFarmerList(Request $request)
    {
        $x = new \stdClass();

        $validator = Validator::make($request->all(), [
            //"insp_id" =>'required',
            "at_inspector_id" => 'required',
            "village_id" => 'required',
        ]);
        if (!$validator->fails()) {
            $data = array();
            $insp_id = $request->at_inspector_id;
            $village = $request->village_id;
            $farmerList = AtFarmerRegDetail::where('ref_village_id', $village)->get();
            // ->where(function($q) use ($insp_id){
            // 	return $q->orWhere('at_ics_inspector_id','!=',$insp_id)->Where('inspection_status',0)->orWhere(function($qx) use ($insp_id){
            // 		return $qx->where('at_ics_inspector_id',$insp_id)->Where('inspection_status',1);
            // 	});
            // })->get();

            foreach ($farmerList as $key => $flist) {
                $data[$key]['farmer_id'] = $flist['id'] ?? '';
                $data[$key]['farmer_name'] = $flist['farmer_first_name'] ?? '';
                $data[$key]['status'] = $flist['inspection_status'] ?? '0';
            }

            if ($farmerList->count() > 0) {
                return response()->json(['status' => 200, 'message' => "farmer data", 'data' => $data]);
            } else {
                return response()->json(['status' => 400, 'message' => "farmer not Found", 'data' => []]);
            }
        } else {
            return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
        }
    }

    public function inspFarmerDetail(Request $request)
    {
        $x = new \stdClass();

        $validator = Validator::make($request->all(), [
            "farmer_id" => 'required',
        ]);
        if (!$validator->fails()) {
            $data = array();
            $farmerId = $request->farmer_id;
            $farmerData = AtFarmerRegDetail::where('id', $farmerId)->first();
            //dd($farmerData);
            for ($i = 0; $i < 1; $i++) {
                $data[$i]['farmer_id'] = $farmerData['id'] ?? '';
                $data[$i]['farmer_name'] = $farmerData['farmer_first_name'] ?? '';
                $data[$i]['vill_id'] = $farmerData['ref_village_id'] ?? '';
                $data[$i]['farmer_village'] = get_village_name_by_id($farmerData['ref_village_id']) ?? '';
                //$data[$i]['farmer_photo']= $farmerData['farmerPhoto'] ?? '';
                if (!empty($farmerData['farmerPhoto'])) {
                    $data[$i]['farmer_photo_url'] = url('/') . '/farmers/' . $farmerData['farmerPhoto'];
                }
            }

            if ($data) {
                return response()->json(['status' => 200, 'message' => "data found", 'data' => $data]);
            } else {
                return response()->json(['status' => 400, 'message' => "data not Found", 'data' => []]);
            }
        } else {
            return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
        }
    }

    public function inspFarmerPost(Request $request)
    {
        $x = new \stdClass();
        $validator = Validator::make($request->all(), [
            //"at_inspection_schedule_id" =>'required',
            "at_farmer_reg_details_id" => 'required',
            "at_inspector_id" => 'required',
            "inspection_date" => 'required',
            "inspection_time" => 'required',
            "location_track" => 'required',

        ]);
        if (!$validator->fails()) {
            $data = array(
                'at_farmer_reg_details_id' => $request->at_farmer_reg_details_id,
                'at_inspector_id' => $request->at_inspector_id,
                'inspection_date' => $request->inspection_date,
                'inspection_time' => $request->inspection_time,
                'location_track' => $request->location_track,
                'inspection_status' => 1
            );
            //
            $farmersave = AtFarmerInspectionDetail::create($data);
            if ($farmersave) {
                //AtFarmerRegDetail::where('id', $request->at_farmer_reg_details_id)->update(['inspection_step'=>1]);
                return response()->json(['status' => 200, 'message' => "Farmer profile details verified successfully.", 'data' => $x]);
            } else {
                return response()->json(['status' => 200, 'message' => "Data not verified.", 'data' => $x]);
            }
        } else {
            return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
        }
    }

    public function farmList(Request $request)
    {
        $x = new \stdClass();

        $validator = Validator::make($request->all(), [
            "farmer_id" => 'required',
        ]);
        if (!$validator->fails()) {
            $data = array();
            $farmer_id = $request->farmer_id;

            $farmList = AtFarmerLandDetail::where('at_farmer_reg_details_id', $farmer_id)->get();

            foreach ($farmList as $key => $flist) {
                $plotCount = AtFarmerInspectionPlotDetails::where('at_farmer_reg_details_id', $farmer_id)->count();
                $data[$key]['farm_id'] = $flist['id'] ?? '';
                $data[$key]['farm_name'] = $flist['farm_name'] ?? '';
                if (isset($flist['no_of_plot']) && $flist['no_of_plot'] != null) {
                    $data[$key]['status'] = $flist['no_of_plot'] == $plotCount ? 1 : 0;
                } else {
                    $data[$key]['status'] = 0;
                }
            }

            if ($data) {
                return response()->json(['status' => 200, 'message' => "farmer data", 'data' => $data]);
            } else {
                return response()->json(['status' => 400, 'message' => "farmer not Found", 'data' => []]);
            }
        } else {
            return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
        }
    }

    public function farmDetail(Request $request)
    {
        $x = new \stdClass();

        $validator = Validator::make($request->all(), [
            "farm_id" => 'required',
        ]);
        if (!$validator->fails()) {
            $data = array();
            $id = $request->farm_id;
            $farmDetail = AtFarmerLandDetail::where('id', $id)->get();
            //dd($farmDetail);
            $ses_name = array('Rabi', 'Khariff', 'Zaid');
            foreach ($farmDetail as $key => $frmdet) {
                //    $no_of_plot = AtFarmerStandingCorpDetail::where(['at_farmer_details_id'=>$frmdet->at_farmer_reg_details_id, 'at_farm_details_id'=>$frmdet->id])->count();
                $data[$key]['survay_no'] = $frmdet->survay_no ?? '';
                $data[$key]['no_of_plot'] = $frmdet->no_of_plot ?? '';
                $data[$key]['total_area'] = $frmdet->total_area ?? '';
                $data[$key]['area_under_organic'] = $frmdet->area_organic_cultivation ?? '';
                $data[$key]['at_farm_details_id'] = $frmdet->id;
                foreach ($ses_name as $k => $val) {
                    $data[$key]['season_detail'][$k]['season_name'] = $val;
                }
                $data[$key]['state'] = $frmdet->ref_state_id ?? '';
                $data[$key]['state_name'] = get_state_name($frmdet->ref_state_id) ?? '';
                $data[$key]['district'] = $frmdet->ref_district_id ?? '';
                $data[$key]['district_name'] = get_district_name_by_id($frmdet->ref_district_id) ?? '';
                $data[$key]['block_tehsil'] = $frmdet->ref_block_tehsil_id ?? '';
                $data[$key]['block_tehsil_name'] = getBlockTehsilByID($frmdet->ref_block_tehsil_id) ?? '';
                $data[$key]['village'] = $frmdet->ref_village_id ?? '';
                $data[$key]['village_name'] = get_village_name_by_id($frmdet->ref_village_id) ?? '';
                $data[$key]['pincode'] = $frmdet->pin ?? '';
                $stand_crop = AtFarmerStandingCorpDetail::where(['at_farmer_details_id' => $request->farmer_id, 'at_farm_details_id' => $frmdet->id])->pluck('id')->toArray();
                foreach ($stand_crop as $k => $val) {
                    $data[$key]['stnd_crop'][$k]['ids'] = $val;
                }
            }

            if ($data) {
                return response()->json(['status' => 200, 'message' => "data found", 'data' => $data]);
            } else {
                return response()->json(['status' => 400, 'message' => "data not Found", 'data' => []]);
            }
        } else {
            return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
        }
    }


    public function farmDetailUpdate(Request $request)
    {
        $x = new \stdClass();

        $validator = Validator::make($request->all(), [
            "at_inspector_id" => 'required',
            "farmer_id" => 'required',
            "season_name" => 'required',
        ]);
        if (!$validator->fails()) {
            $data = array(
                // 'farm_id' =>$request->at_inspector_id,
                'at_inspector_id' => $request->at_inspector_id,
                'at_farmer_reg_details_id' => $request->farmer_id,
            );
            //

            $datasave = AtFarmerInspectionDetail::where($data)->update(['season_name' => $request->season_name]);


            if ($datasave) {
                return response()->json(['status' => 200, 'message' => "Data Update Successfully.", 'data' => $x]);
            } else {
                return response()->json(['status' => 400, 'message' => "data not saved.", 'data' => $x]);
            }
        } else {
            return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
        }
    }


    public function plotDetailSave(Request $request)
    {
        $x = new \stdClass();

        $validator = Validator::make($request->all(), [
            // "farm_id" =>'required',
            // "season_name" =>'required',
            "plotDetails" => 'required',
            "plotDetails.*.at_farmer_reg_details_id" => 'required',
            // "plotDetails.*.at_farmer_standing_crop_details_id" =>'required',
            "plotDetails.*.at_inspector_id" => 'required',
            "plotDetails.*.plot_no" => 'required',
            "plotDetails.*.area" => 'required',
            "plotDetails.*.main_crop" => 'required',
            "plotDetails.*.inter_crop" => 'required',
            "plotDetails.*.product" => 'required',
            "plotDetails.*.quantity" => 'required',
        ]);

        if (!$validator->fails()) {

            foreach ($request->plotDetails as $plots) {

                $plot = array(
                    "at_farmer_reg_details_id" => $plots['at_farmer_reg_details_id'],
                    "at_inspector_id" => $plots['at_inspector_id'],
                    "plot_no" => $plots['plot_no'],
                    "area" => $plots['area'],
                    "main_crop" => $plots['main_crop'],
                    "inter_crop" => $plots['inter_crop'],
                    "product" => $plots['product'],
                    "quantity" => $plots['quantity'],
                    "created_at" => date('Y-m-d H:i:s'),
                    "inspection_status" => 1,
                    "showing_date" => date('Y-m-d'),
                    "estimated_yield" => $plots['estimated_yield'],
                    // "season_name" => $request->season_name,
                    // "farm_id" => $request->farm_id
                );
                $plotdet = AtFarmerInspectionPlotDetails::create($plot);
            }
            //

            if ($plotdet) {
                //AtFarmerRegDetail::where('id', $request->at_farmer_reg_details_id)->update(['inspection_step'=>2]);
                return response()->json(['status' => 200, 'message' => "Data Successfully Saved.", 'data' => $x]);
            } else {
                return response()->json(['status' => 200, 'message' => "Data not saved.", 'data' => $x]);
            }
        } else {

            return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
        }
    }


    public function inspectionDetail(Request $request)
    {
        $x = new \stdClass();

        $validator = Validator::make($request->all(), [
            "at_inspector_id" => 'required',
            "farmer_id" => 'required'
        ]);
        if (!$validator->fails()) {
            $condition = array(
                "at_inspector_id" => $request->at_inspector_id,
                "at_farmer_reg_details_id" => $request->farmer_id,
            );
            $insDetTabs = array('farmer_detail', 'farm_detail', 'inspection_checklist', 'risk_mgmt', 'non_conformity', 'approval');
            $data = AtFarmerRegDetail::select('inspection_step')->where('id', $request->farmer_id)->where('at_ics_inspector_id', $request->at_inspector_id)->first();

            $rdata = array();
            foreach ($insDetTabs as $key => $val) {
                $rdata[$key]['name'] = $val;

                if ($val == 'farmer_detail') {
                    $rdata[$key]['status'] = AtFarmerInspectionDetail::where($condition)->first()->inspection_status ?? 0;
                } elseif ($val == 'farm_detail') {
                    $rdata[$key]['status'] = AtFarmerInspectionPlotDetails::where($condition)->first()->inspection_status ?? 0;
                } elseif ($val == 'inspection_checklist') {
                    $animal_hus = AtFarmerChecklist::where($condition)->where('type', 1)->first()->inspection_status ?? 0;
                    $farm_mgmt = AtFarmerChecklist::where($condition)->where('type', 2)->first()->inspection_status ?? 0;
                    $post_harvest = AtFarmerChecklist::where($condition)->where('type', 3)->first()->inspection_status ?? 0;

                    if ($animal_hus == 1 && $farm_mgmt == 1 && $post_harvest) {
                        $rdata[$key]['status'] = 1;
                    } else {
                        $rdata[$key]['status'] = 0;
                    }
                    //$rdata[$key]['status'] = AtFarmerChecklist::where($condition)->where('type','!=',4)->first()->inspection_status ?? 0;
                } elseif ($val == 'risk_mgmt') {
                    $rdata[$key]['status'] = AtFarmerChecklist::where($condition)->where('type', '=', 4)->first()->inspection_status ?? 0;
                } elseif ($val == 'non_conformity') {
                    $rdata[$key]['status'] = AtInspectionNonConformity::where($condition)->first()->inspection_status ?? 0;
                } elseif ($val == 'approval') {
                    $rdata[$key]['status'] = AtInspectionApprovalInternalInspector::where('at_farmer_reg_details_id', $request->farmer_id)->where('at_ics_inspector_details_id', $request->at_inspector_id)->first()->inspection_status ?? 0;
                } else {
                    $rdata[$key]['status'] = 0;
                }
            }

            if ($rdata) {
                return response()->json(['status' => 200, 'message' => "Inspection Status", 'data' => $rdata]);
            } else {
                return response()->json(['status' => 400, 'message' => "Data not Found", 'data' => []]);
            }
        } else {
            return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
        }
    }


    public function nonConformitySave(Request $request)
    {
        $x = new \stdClass();

        $validator = Validator::make($request->all(), [
            "at_farmer_reg_details_id" => 'required',
            "at_inspector_id" => 'required',
            "noncondetails" => 'required',
            "noncondetails.*.grade" => 'required',
            "noncondetails.*.description" => 'required',
            // "submission_date" =>'required',
        ]);

        if (!$validator->fails()) {
            foreach ($request->noncondetails as $ncd) {

                $nonConformity = array(
                    "at_farmer_reg_details_id" => $request->at_farmer_reg_details_id,
                    "at_inspector_id" => $request->at_inspector_id,
                    "grade" => $ncd['grade'],
                    "description" => $ncd['description'],
                    "submission_date_corrective_action" => date("Y-m-d h:s:i"),
                    "created_by" => $request->at_inspector_id,
                    "inspection_status" => 1
                );

                $nonConformityDet = AtInspectionNonConformity::create($nonConformity);
            }

            if ($nonConformityDet) {

                return response()->json(['status' => 200, 'message' => "Data Successfully Saved.", 'data' => $x]);
            } else {
                return response()->json(['status' => 200, 'message' => "Data not saved.", 'data' => $x]);
            }
        } else {

            return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
        }
    }
    public function getNonConformity(Request $request)
    {
        $x = new \stdClass();

        $validator = Validator::make($request->all(), [
            "at_farmer_reg_details_id" => 'required',
            "at_inspector_id" => 'required',
        ]);

        if (!$validator->fails()) {
            $farmer_id = $request->at_farmer_reg_details_id;
            $insp_id = $request->at_inspector_id;
            $data = array();
            $getdata = AtInspectionNonConformity::where('at_farmer_reg_details_id', $farmer_id)->where('at_inspector_id', $insp_id)->get();
            foreach ($getdata as $key => $val) {
                $data[$key]["id"] = $val->id;
                $data[$key]["grade"] = $val->grade;
                $data[$key]["description"] = $val->description;
                $data[$key]["submission_date_corrective_action"] = date("Y-m-d h:s:i");
            }

            if ($data) {
                return response()->json(['status' => 200, 'message' => "Non Conformity Data", 'data' => $data]);
            } else {
                return response()->json(['status' => 200, 'message' => "Data not found.", 'data' => $x]);
            }
        } else {

            return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
        }
    }

    public function deleteNonConformity(Request $request)
    {

        $x = new \stdClass();

        $validator = Validator::make($request->all(), [
            "nc_id" => 'required',

        ]);

        if (!$validator->fails()) {
            $data = AtInspectionNonConformity::where('id', $request->nc_id)->delete();

            if ($data) {

                return response()->json(['status' => 200, 'message' => "Data Successfully Deleted.", 'data' => $x]);
            } else {
                return response()->json(['status' => 200, 'message' => "Something went wrong.", 'data' => $x]);
            }
        } else {

            return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
        }
    }
    public function internalApprovalSave(Request $request)
    {
        $x = new \stdClass();

        $validator = Validator::make($request->all(), [
            "at_farmer_reg_details_id" => 'required',
            "at_inspector_id" => 'required',
            "compliance_with_previous_conditions" => 'required',
            "compliance_this_year" => 'required',
            "comments_by_internal_inspector" => 'required',
            "farmer_signature" => 'required',
            "inspector_signature" => 'required',
        ]);

        if (!$validator->fails()) {
            $data = array(
                "at_farmer_reg_details_id" => $request->at_farmer_reg_details_id,
                "at_ics_inspector_details_id" => $request->at_inspector_id,
                "compliance_with_previous_conditions" => $request->compliance_with_previous_conditions,
                "compliance_this_year" => $request->compliance_this_year,
                "comments_by_internal_inspector" => $request->comments_by_internal_inspector,
                "created_by" => $request->at_inspector_id,
                "farmer_signature" => $request->farmer_signature,
                "inspector_signature" => $request->inspector_signature,
                "inspection_status" => 1
            );

            $saveData = AtInspectionApprovalInternalInspector::create($data);


            if ($saveData) {

                return response()->json(['status' => 200, 'message' => "Data Successfully Saved.", 'data' => $x]);
            } else {
                return response()->json(['status' => 200, 'message' => "Data not saved.", 'data' => $x]);
            }
        } else {

            return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
        }
    }



    public function confirmInspection(Request $request)
    {

        $x = new \stdClass();

        $validator = Validator::make($request->all(), [
            "at_farmer_reg_details_id" => 'required',
            "at_inspector_id" => 'required',
        ]);

        if (!$validator->fails()) {
            $cond = array(
                "id" => $request->at_farmer_reg_details_id,
                // "at_ics_inspector_id" =>$request->at_inspector_id,
            );
            $data = AtFarmerRegDetail::where($cond)->update(['inspection_status' => 1]);

            // InspectionSchedule::where('at_ics_inspector_details_id',$id)->where('ref_village_id',$value->ref_village_id)->increment('total_attempt');

            if ($data) {
                InspectionSchedule::where('at_ics_inspector_details_id', $request->at_inspector_id)->increment('total_attempt');
                return response()->json(['status' => 200, 'message' => "Farmer inspection Successfully Done.", 'data' => $x]);
            } else {
                return response()->json(['status' => 200, 'message' => "Something went wrong.", 'data' => $x]);
            }
        } else {

            return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
        }
    }

    public function getFarmerDetailById($id)
    {
        $x = new \stdClass();
        if ($id != '') {
            $data = AtFarmerRegDetail::with('farmerLandDetail')->where('id', $id)->first();
            if ($data) {
                return response()->json(['status' => 200, 'message' => "Farmer details.", 'data' => $data]);
            } else {
                return response()->json(['status' => 200, 'message' => "Something went wrong.", 'data' => $x]);
            }
        } else {
            return response()->json(['status' => 400, 'message' => "Farmer id not found", 'data' => []]);
        }
    }

    public function getUserData(Request $request)
    {

       // dd('dsds');
        $inspector_id = $request->inspector_id;

        $currentDate = now()->toDateString();

        $validator = Validator::make(
            $request->all(),
            [
                'inspector_id' => 'required'
            ],
            [
                'inspector_id.required' => 'Inspector ID is required'
            ]
        );

        if ($validator->fails()) {
            return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
        }

        $farmers = AtFarmerRegSchedule::select(
            'at_ics_inspector_details_id',
            'ref_village_id',
            'number_of_farmer_reg',
            'schedule_period_to',
            DB::raw("COUNT(CASE WHEN status = 1 THEN 1 END) AS pending"),
            DB::raw("COUNT(CASE WHEN status = 2 THEN 1 END) AS complete"),
            DB::raw("number_of_farmer_reg - COUNT(CASE WHEN status = 2 THEN 1 END) AS total_farmers")
        )
        ->where('at_ics_inspector_details_id', $inspector_id)
        ->where('schedule_period_to', '>=', $currentDate)
        ->groupBy(
            'at_ics_inspector_details_id',
            'ref_village_id',
            'number_of_farmer_reg',
            'schedule_period_to'
        )
        ->get();
    
        $schedule = AtFarmerRegDetail::where('at_ics_inspector_id', $inspector_id)
            ->leftJoin('at_farmer_proposed_crop_details', 'at_farmer_reg_details.id', '=', 'at_farmer_proposed_crop_details.at_farmer_details_id')
            ->leftJoin('at_farmer_standing_crop_details', 'at_farmer_reg_details.id', '=', 'at_farmer_standing_crop_details.at_farmer_details_id')
            ->leftJoin('at_farm_details', 'at_farmer_reg_details.id', '=', 'at_farm_details.at_farmer_reg_details_id')
            ->leftJoin('at_farmer_bank_details', 'at_farmer_reg_details.id', '=', 'at_farmer_bank_details.at_farmer_reg_id')
            ->leftJoin('at_farmer_documents_list', 'at_farmer_reg_details.id', '=', 'at_farmer_documents_list.at_farmer_details_id')
            ->leftJoin('at_osp_ics_individual', 'at_farmer_reg_details.id', '=', 'at_osp_ics_individual.at_farmer_reg_details_id')
            ->leftJoin('at_farmers_reg_schedule', 'at_farmers_reg_schedule.at_ics_inspector_details_id', '=', 'at_farmer_reg_details.at_ics_inspector_id')
            ->select(
                'at_farmer_reg_details.*',
                'at_farmer_proposed_crop_details.crop_area',
                'at_farmer_proposed_crop_details.id as pid',
                'at_farmer_proposed_crop_details.season_name',
                'at_farmer_proposed_crop_details.organic_status',
                'at_farmer_proposed_crop_details.crop_name as pcrop',
                'at_farmer_standing_crop_details.id as stid',
                'at_farmer_standing_crop_details.season_name as stsn',
                'at_farmer_standing_crop_details.crop_area as stca',
                'at_farmer_standing_crop_details.organic_status as sts',
                'at_farmer_standing_crop_details.crop_name as stcn',
                'at_farmer_standing_crop_details.crop_photo',
                'at_farmer_standing_crop_details.geotag_photo',
                'at_farm_details.registration_no',
                'at_farm_details.farm_name',
                'at_farm_details.farm_no',
                'at_farm_details.area_in_ha',
                'at_farm_details.total_area',
                'at_farm_details.survay_no',
                'at_farm_details.no_of_plot',
                'at_farm_details.ref_state_id as farm_state',
                'at_farm_details.ref_district_id as farm_city',
                'at_farm_details.ref_block_tehsil_id as framtehsil',
                'at_farm_details.ref_village_id as frmvill',
                'at_farmer_bank_details.ref_bank_id',
                'at_farmer_bank_details.account_number',
                'at_farmer_bank_details.ifsc_code',
                'at_farmer_bank_details.branch_name',
                'at_farmer_bank_details.bank_address',
                'at_farmer_bank_details.pincode',
                'at_farmer_bank_details.farmer_photo',
                'at_farmer_bank_details.bank_name',
                'at_farmer_bank_details.id as bid',
                'at_farmer_documents_list.aadhar_card_image_path',
                'at_farmer_documents_list.pan_card_image_path',
                'at_farmer_documents_list.land_documents_image_path',
                'at_farmer_documents_list.passbook_image_path',
                'at_farmer_documents_list.contact_person_sign_image_path',
                'at_farmer_documents_list.live_signature_image_path',
                'at_farmer_documents_list.voter_id_card',
                'at_farmer_documents_list.kishan_credit_card',
                'at_farmer_documents_list.ration_card',
                'at_osp_ics_individual.source_of_organic_system_plan',
                'at_osp_ics_individual.cropping_pattern',
                'at_osp_ics_individual.covered_area_main_corp',
                'at_osp_ics_individual.covered_area_inter_corp',
                'at_osp_ics_individual.off_farm',
                'at_osp_ics_individual.on_farm',
                'at_osp_ics_individual.contamination_control',
                'at_osp_ics_individual.pease_weed_management',
                'at_osp_ics_individual.nutrient_management',
                'at_farmers_reg_schedule.schedule_period_from',
                'at_farmers_reg_schedule.schedule_period_to',
                
            )
            ->distinct('at_farmer_reg_details.id')
            // ->where('at_farmers_reg_schedule.schedule_period_from', '>', $currentDate)
            ->where('at_farmers_reg_schedule.schedule_period_to', '>=', $currentDate)
            ->get();

          // dd($schedule);

        if ($farmers->isEmpty() && $schedule->isEmpty()) {
            return response()->json(['status' => 404, 'message' => "No data found for this Inspector", 'data' => []]);
        }

        $villageSchedule = [];
        $farmerList = [];
        $farmerDetails = [];
        $Crop_Status = [];
        $Season = [];
        $Taluka = [];
        $Village = [];
        $Gender = [];
        $Banks = [];

    
            foreach ($farmers as $farmer) {
               
              
                $villageSchedule[] = [
                    "inspector_id" => $farmer->at_ics_inspector_details_id,
                    "address" => 'Vill -' . getVillName($farmer->ref_village_id) . ', Block-' .  ($farmer->ref_block_tehsil_id) . ', District-' . getDisName($farmer->ref_district_id) . ', State-' . getStateName($farmer->ref_state_id),
                    "village_id" => $farmer->ref_village_id,
                    "Total_Farmer" => $farmer->total_farmers,
                    "Scheduled_Period" => dateFormat($farmer->schedule_period_from) . ' To ' . dateFormat($farmer->schedule_period_to),
                    "total_pending" => $farmer->pending,
                    "total_completed" => $farmer->complete,
                ];
            }


        foreach ($schedule as $k => $sch) {
            $farmerList[] = [
                "inspector_id" => $sch->at_ics_inspector_id ?? '',
                "village_id" => $sch->ref_village_id ?? '',
                "farmer_id" => $sch->id ?? '',
                "MobileNo" => $sch->mobile_no ?? '',
                "Address" => $sch->farmer_address ?? '',
                "FarmerName" => $sch->farmer_first_name ?? '',
                "Father_husband_flag" => $sch->father_husband_flag ?? '',
                "Father_husband_name" => $sch->father_husband_first_name ?? '',
                "gender" => $sch->gender ?? '',           
                "status" => ($sch->inspection_status == 1 ? 'completed' : 'pending'), // Set status based on value (1 = completed, 0 = pending)
            ];

            $farmerDetails[] = [

                "farmerIndividual" => [
                    "inspector_id" => $sch->at_ics_inspector_id ?? '',
                    "farmer_id" => $sch->id ?? '',
                    "registration_no" => $sch->registration_no ?? '',
                    "registration_date" => $sch->registration_date ?? '',
                    "owner_farmerid" => $sch->owner_farmerid ?? '',
                    "farmer_first_name" => $sch->farmer_first_name ?? '',
                    "farmer_middle_name" => $sch->farmer_middle_name ?? '',
                    "farmer_last_name" => $sch->farmer_last_name ?? '',
                    "gender" => $sch->gender ?? '',
                    "father_husband_flag" => $sch->father_husband_flag ?? '',
                    "father_husband_first_name" => $sch->father_husband_first_name ?? '',
                    "father_husband_middle_name" => $sch->father_husband_middle_name ?? '',
                    "father_husband_last_name" => $sch->father_husband_last_name ?? '',
                    "farmer_address" => $sch->farmer_address ?? '',
                    "landmark" => $sch->landmark ?? '',
                    "state_id" => $sch->ref_state_id ?? '',
                    "district_id" => $sch->ref_district_id ?? '',
                    "block_tehsil_id" => $sch->ref_block_tehsil_id ?? '',
                    "village_id" => $sch->ref_village_id ?? '',
                    "state" => getStateNameById($sch->ref_state_id) ?? '',
                    "district" => getDistrictNameById($sch->ref_district_id) ?? '',
                    "block_tehsil" => getBlockTehsilByID($sch->ref_block_tehsil_id) ?? '',
                    "village" => getVillageNameById($sch->ref_village_id) ?? '',
                    "pin" => $sch->pin,
                    "mobile_no" => $sch->mobile_no ?? '',
                    "email_id" => $sch->email_id ?? '',
                    "at_user_id" => $sch->at_user_id ?? '',
                    "farmerPhoto" => $sch->farmerPhoto ?? '',
                    "aadhar_number" => $sch->aadhar_number ?? '',
                    "schedule_period_to" => $sch->schedule_period_to ?? '',
                    "schedule_period_from" => $sch->schedule_period_from ?? '',
                ],
                "farmDetails" => [
                    "FarmHolderName" => $sch->farm_name ?? '',
                    "NumberofFarm" => $sch->farm_no ?? '',
                    "NoofPlot" => $sch->no_of_plot ?? '',
                    "KhasraNo" => $sch->survay_no ?? '',
                    "Area_in_ha" => $sch->area_in_ha ?? '',
                    "TotalArea" => $sch->total_area ?? '',
                    "StateId" => ($sch->farm_state) ?? '',
                    "CityId" => ($sch->farm_city) ?? '',
                    "State" => getStateNameById($sch->farm_state) ?? '',
                    "City" => getDistrictNameById($sch->farm_city) ?? '',
                    "Taluka" => ($sch->framtehsil) ?? '',
                    "Village" => $sch->frmvill ?? '',
                    "Pin" => $sch->pin ?? '',
                    "ProposedCrop" => [
                        [
                            "crop_name" => $sch->crop_name ?? 'Coriander',
                            "crop_status" => getRefOrganicStatusMasterByID($sch->organic_status) ?? '',
                            "crop_season" => $sch->season_name ?? '',
                            "crop_area" => $sch->crop_area ?? '',
                        ]
                    ],
                    "StandingCrop" => [
                        [
                            "crop_name" => $sch->stcn ?? '',
                            "season" => $sch->stsn ?? '',
                            "crop_status" => getRefOrganicStatusMasterByID($sch->sts) ?? '',
                            "crop_area" => $sch->stca ?? '',
                            "crop_photo" => $sch->crop_photo ?? '',
                            "geo_tag_photo" => $sch->geotag_photo ?? '',
                        ]
                    ]
                ],
                "bankDetails" => [
                    "Bank_id" => $sch->bid,
                    "Bank_Name" => $sch->bank_name ?? '',
                    "Account_Number" => $sch->account_number ?? '',
                    "IFSC_Code" => $sch->ifsc_code ?? '',
                    "Branch_Name" => $sch->branch_name ?? '',
                    "Address" => $sch->bank_address ?? '',
                    "Pin_Code" => $sch->pincode ?? '',
                ],
                "DocumentDetails" => [
                    "Voter_Id" => $sch->voter_id_card ?? '',
                    "Kishan_Credit_Card" => $sch->kishan_credit_card ?? '',
                    "PAN" => $sch->pan_card_image_path ?? '',
                    "Land_Document" => $sch->land_documents_image_path ?? '',
                    "Bank" => $sch->passbook_image_path ?? '',
                    "Sign_doc" => $sch->contact_person_sign_image_path ?? '',
                    "RationCard" => $sch->ration_card ?? '',
                ],
                "OSPDetails" => [
                    "source_of_organic_system_plan" => $sch->source_of_organic_system_plan ?? '',
                    "cropping_pattern" => $sch->cropping_pattern ?? '',
                    "covered_area_main_corp" => $sch->covered_area_main_corp ?? '',
                    "covered_area_inter_corp" => $sch->covered_area_inter_corp ?? '',
                    "off_farm" => $sch->off_farm ?? '',
                    "on_farm" => $sch->on_farm ?? '',
                    "contamination_control" => $sch->contamination_control ?? '',
                    "pease_weed_management" => $sch->pease_weed_management ?? '',
                    "nutrient_management" => $sch->nutrient_management ?? ''
                ]
            ];

            $land_holding = RefHoldingType::select('id','land_holding_type as holding_type')->get();
            $Crop_Status = RefOrganicStatus::select('id','organic_status as cropStatus')->get();

            $product = RefProduct::select('id','hs_code as hscode', 'product_name', 'hscode_description')->get();
         
            $season = RefSeason::select('id','season_type as season')->get();
           
            // $Product[] = [
            //     "Sid" => !empty($sch->stid) ? $sch->stid : null,
            //     "standingcrop_product_name" => !empty($sch->stcn) ? $sch->stcn : null,
            //     "Pid" => !empty($sch->pid) ? $sch->pid : null,
            //     "proposedcrop_product_name" => !empty($sch->pcrop) ? $sch->pcrop : null
            // ];
            
        }

          $taluka = UserInspector::
                rightJoin('ref_block_tehsil','ref_block_tehsil.ref_district_id','=','at_ics_inspector_details.ref_district_id')
                ->select(
                    // 'at_ics_inspector_details.id',
                    'ref_block_tehsil.id as block_id',
                    'ref_block_tehsil.block_tehsil_name',
                    // 'at_ics_inspector_details.ref_district_id',
                    
                )
            ->where('at_ics_inspector_details.id', $inspector_id)
           ->get();

           $village = UserInspector::
           rightJoin('ref_block_tehsil','ref_block_tehsil.ref_district_id','=','at_ics_inspector_details.ref_district_id')
           ->rightJoin('ref_village','ref_village.ref_block_tehsil_id','=','ref_block_tehsil.id')
                
                ->select(
                    // 'at_ics_inspector_details.id',
                    'ref_village.ref_block_tehsil_id as taluka_id',
                    'ref_village.id as Vill_id',
                    'ref_village.village_name',
                    // 'at_ics_inspector_details.ref_district_id',
                    
                )
            ->where('at_ics_inspector_details.id', $inspector_id)
           ->get();

       
        $Banks = [];  

        RefBank::chunk(100, function($bankm) use (&$Banks) {
            foreach ($bankm as $bank) {
                $Banks[] = [
                    "id" => $bank->id ?? '',
                    "name" => $bank->bank_name ?? '',
                ]; 
            }
        });
       $gender = RefGander::select('id','gender_code as gender')->get();
        
        $commonDetails = [
            "land_holding" =>  $land_holding,
            "crop_status" => $Crop_Status,   
            "season" => $season,
            "taluka" => $taluka,
            "village" => $village,
            "gender" => $gender,
            "Banks"  => $Banks,
            "Product"  => $product,
        ];
        

        $response = [
            "village_schedule" => $villageSchedule,
            "farmer_list" => $farmerList,
            "farmer_details" => $farmerDetails,
            "common_details" => $commonDetails,
        ];

        return response()->json(['status' => 200, 'message' => "Get Schedule Master", 'data' => $response]);
    }


    public function sendOtp(Request $request)
    {
        $x = new \stdClass();

        $validator = Validator::make($request->all(), [
            "mobile_number" => 'required|string',
        ]);

        if (!$validator->fails()) {
            $mobileNumber = $request->input('mobile_number');
            $otp = rand(1000, 9999);

            $response = sendOtpHelp($mobileNumber, $otp);

            if ($response['status'] === true) {
                return response()->json([
                    'status' => 200,
                    'message' => "OTP sent successfully.",
                    'data' => $response,
                ]);
            } else {
                return response()->json([
                    'status' => 500,
                    'message' => $response['message'] ?? 'Failed to send OTP.',
                    'data' => $x,
                ]);
            }
        } else {
            return response()->json([
                'status' => 400,
                'message' => $validator->errors()->first(),
                'data' => [],
            ]);
        }
    }



}

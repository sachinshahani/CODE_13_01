<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\AtFarmerRegDetail;
use App\Models\UserInspector;
use App\Models\SamplingInfo;
use App\Models\RefProductKind;
use App\Models\RefCropStage;
use App\Models\UserWarehouseManagerOfficers;
use App\Models\AtFarmerInspectionDetail;
use App\Models\AtFarmerInspectionPlotDetails;
use App\Models\AtFarmerChecklist;
use App\Models\NpopProcessingActivities;
use App\Models\RefOperatorType;
use App\Models\InspectionChecklistProcessor;
use App\Models\AtInspectionNonConformity;
use App\Models\AtExternalSchedule;
use App\Models\AtInspectionProcessorProduct;
use App\Models\AtInspectionApprovalInternalInspector;
use App\Models\AtInspectionChecklistGrowerGroup;
use App\Models\AtInspectionProcessorReport;
use App\Models\AtInspectionIndividualProducerReport;
use App\Models\RefFarmObservations;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\GeoTaggingWarehouseDetail;
use App\Models\TradersProductDetail;
use App\Models\GeoTaggingProcessorDetail;
use App\Models\WildHarvesterDetail;
use App\Models\WildHarvesterBankDetail;
use App\Models\WildHarvesterForestProductDetail;
use App\Models\WildHarvesterPermittedForestAreaDetail;
use App\Models\InspectionChecklistTrader;
use App\Models\InspectionChecklistWildCollectionHarvest;
use App\Models\IcsMandator;
use App\Models\IndividualProducerFarmerDetail;
use App\Models\PpInspectionChecklistCropDetails;
use App\Models\IpFarmInputDetails;
use App\Models\IpFarmInputDetailsNutrientManagement;
use App\Models\IpFarmPestDiseaseWeedManagement;
use App\Models\InspectionChecklistIndividualFarmer;
use App\Models\IpFarmHarvestHandlingStorage;
use App\Models\NpopProcessingActivitiesStatus;
use App\Models\AtComplianceDetails;
use App\Models\AtGrowerGroupCropsDetails;
use DB;
use Exception;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;

class ExternalInspection extends Controller
{
    public function login(Request $request)
    {
        // dd('dsds');
        $x = new \stdClass(); // To represent an empty object
        $validator = Validator::make($request->all(), [
            'mobile_no' => 'required',
            'password' => 'required',
            'user_type' => 'required',
        ]);

        if ($validator->fails()) {
            // Return an empty object in 'data' instead of an empty array
            return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => new \stdClass()]);
        } else {
            $userPass = hash('sha256', $request->password);
            $u = $request->mobile_no;
            $user_type = $request->user_type;

            $regData = array();
            $total = 0;
            $attempt = 0;
            $pending = 0;

            $userdetails = User::with('users')
                ->where(function ($query) use ($u) {
                    $query->where('mobile_no', $u)
                        ->orWhere('email', $u);
                })
                ->where('password', $userPass)
                ->where('ref_operator_type_id', $user_type)
                ->first();

            if (empty($userdetails)) {
                // Return an empty object in 'data' instead of an empty array
                return response()->json(['status' => 400, 'message' => "Invalid Credentials.", 'data' => $x]);
            } else {
                $data = array(
                    'user_id' => $userdetails->id ?? 'Record not exist',
                    'Date_of_registration' => $userdetails->created_at ? date("Y-m-d", strtotime($userdetails->created_at)) : 'Record not exist',
                    'External_Inspector_name' => $userdetails->first_name ?? 'Record not exist',
                    'Emplooye_Id' => $userdetails->employee_id ?? 'Record not exist',
                    'Emplooye_Type' => $userdetails->employee_type ?? 'Record not exist',
                    'Date_of_joining' => $userdetails->join_date ?? 'Record not exist',
                    'Total_experience' => $userdetails->total_experience ?? 'Record not exist',
                    'Training' => $userdetails->training ?? 'Record not exist',
                    'Bio_data' => $userdetails->upload_biodata ?? 'Record not exist',
                    'Aadhaar_no' => $userdetails->aadhar_number ?? 'Record not exist',
                    'Designation' => $userdetails->designation ?? 'Record not exist',
                    'Qualification' => $userdetails->qualification ?? 'Record not exist',
                    'mobile_no' => $userdetails->mobile_no ?? 'Record not exist',
                );

                $accessToken = $userdetails->createToken('authToken')->accessToken;
                return response()->json(['status' => 200, 'message' => "Login Successfully", 'data' => $data, 'access_token' => $accessToken]);
            }
        }
    }


    public function inspectionCompleteList(Request $request)
    {

        // dd("dasd");


        $totalData = AtFarmerRegDetail::where('inspection_status', 1)->get();

        // dd($totalData);
        // Create an array to store the formatted data
        $responseData = $totalData->map(function ($row) {
            return [
                'farmer_id' =>  $row->id,
                'name' => $row->farmer_first_name ?? '',
                'email' => $row->email_id ?? '',
                'mobile' => $row->mobile_no ?? '',
                'address' => $row->farmer_address ?? '',
                //'insp_name' => getInspectorName($row->at_ics_inspector_id)->name_of_inspector ?? '',
                'created_on' => date('d/m/Y', strtotime($row->created_at)) ?? '',
                'external_inspection_status' => $row->external_inspection_status == 0 ? 'Pending' : ($row->external_inspection_status == 1 ? 'Complete' : ''),



                // 'action' => route('superadmin.generatePdf') . '?fid=' . $row->id,
                // 'insid' => $row->at_ics_inspector_id,

            ];
        });

        // Return a JSON response with the formatted data
        return response()->json([
            'status' => 'success',
            'data' => $responseData
        ], 200);


        // Return a 400 response if the request is not AJAX
        return response()->json(['status' => 'error', 'message' => 'Bad Request'], 400);
    }

    public function inspectionCompleteDetail(Request $request)
    {

        // dd('gfhfg');
        //  dd($request->all());
        $fid = $request->fid;
        $insid = $request->insid;
        $regDetail = AtFarmerRegDetail::with(['farmerLandDetail', 'farmerBankDetail', 'farmerDocs', 'farmerOSPDetail'])->where('id', $fid)->first();
        $farInspDetail = AtFarmerInspectionDetail::where('at_farmer_reg_details_id', $fid)->where('at_inspector_id', $insid)->first();
        //$farInspDetail = AtFarmerInspectionDetail::where('at_farmer_reg_details_id',$fid)->where('at_inspector_id',$insid)->first();
        $farPlotDetail = AtFarmerInspectionPlotDetails::where('at_farmer_reg_details_id', $fid)->get();
        $farCheckList = AtFarmerChecklist::where('at_farmer_reg_details_id', $fid)->get();
        $nonConDetail = AtInspectionNonConformity::where('at_farmer_reg_details_id', $fid)->get();
        $appInspDetail = AtInspectionApprovalInternalInspector::where('at_farmer_reg_details_id', $fid)->first();

        return response()->json([
            'regDetail' => $regDetail,
            'farInspDetail' => $farInspDetail,
            'farPlotDetail' => $farPlotDetail,
            'farCheckList' => $farCheckList,
            'nonConDetail' => $nonConDetail,
            'appInspDetail' => $appInspDetail
        ]);
    }

    // public function saveRemarks(Request $request)
    // {
    //     $x = new \stdClass();
    //     $validator = Validator::make(
    //         $request->all(),
    //         [
    //             'fid' => 'required',
    //             'status' => 'required|in:1,2', // 1 = अनुमत/Approved, 2= अस्वीकार/Reject-
    //             'approved_remark' => 'required|string|max:255', // Validate remark
    //         ]
    //     );

    //     try {
    //         if ($validator->fails()) {
    //             return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
    //         } else {
    //             $newUser = DB::table('at_external_approved_remark')->insert([
    //                 'farmer_id' => $request->fid,
    //                 'status' => $request->status, // Save numeric status
    //                 'approved_remark' => $request->approved_remark, // Save remark
    //             ]);



    //             if ($newUser) {
    //                 return response()->json(['status' => 200, 'message' => "Data Successfully Saved.", 'data' => $x]);
    //             } else {
    //                 return response()->json(['status' => 200, 'message' => "Data not saved.", 'data' => $x]);
    //             }
    //         }
    //     } catch (Exception $e) {
    //         \Log::error($e->getMessage());
    //         $response = [
    //             'status' => 400,
    //             'message' => $e->getMessage(),
    //             'data' => []
    //         ];
    //         return response()->json($response);
    //     }
    // }


    public function saveRemarks(Request $request)
    {
        $x = new \stdClass();
        $validator = Validator::make(
            $request->all(),
            [
                'fid' => 'required',
                'status' => 'required|in:1,2', // 1 = अनुमत/Approved, 2 = अस्वीकार/Reject
                'approved_remark' => 'required|string|max:255', // Validate remark
            ]
        );

        try {
            if ($validator->fails()) {
                return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
            }

            // Begin transaction
            DB::beginTransaction();

            // Insert into at_external_approved_remark
            $newUser = DB::table('at_external_approved_remark')->insert([
                'farmer_id' => $request->fid,
                'status' => $request->status,
                'approved_remark' => $request->approved_remark,
            ]);

            if ($newUser) {
                // Update external_inspection_status in AtFarmerRegDetail
                $updateStatus = DB::table('at_farmer_reg_details')
                    ->where('id', $request->fid)
                    ->update(['external_inspection_status' => 1]);

                if ($updateStatus) {
                    // Commit the transaction
                    DB::commit();
                    return response()->json(['status' => 200, 'message' => "Data Successfully Saved.", 'data' => $x]);
                } else {
                    // Rollback if update fails
                    DB::rollBack();
                    return response()->json(['status' => 400, 'message' => "Failed to update external_inspection_status.", 'data' => $x]);
                }
            } else {
                // Rollback if insert fails
                DB::rollBack();
                return response()->json(['status' => 400, 'message' => "Data not saved.", 'data' => $x]);
            }
        } catch (Exception $e) {
            DB::rollBack();
            \Log::error($e->getMessage());
            return response()->json(['status' => 400, 'message' => $e->getMessage(), 'data' => []]);
        }
    }





    public function getGeneratePdf(Request $request)
    {

        $validator = Validator::make(
            $request->all(),
            [
                'fid' => 'required',
            ]
        );
        if ($validator->fails()) {
            return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
        }

        try {


            $fid = $request->fid;
            $insid = $request->insid;
            $oper_type = 2;
            $regDetail = AtFarmerRegDetail::with(['farmerLandDetail', 'farmerBankDetail', 'farmerDocs', 'farmerOSPDetail'])
                ->where('id', $fid)
                ->first();
            if (!$regDetail) {
                return response()->json(['status' => 404, 'message' => 'Farmer not found in the registration details table.', 'data' => []]);
            }
            $farInspDetail = AtFarmerInspectionDetail::where('at_farmer_reg_details_id', $fid)
                ->where('at_inspector_id', $insid)
                ->first();
            $farPlotDetail = AtFarmerInspectionPlotDetails::where('at_farmer_reg_details_id', $fid)->get();
            $farCheckList = AtFarmerChecklist::where('at_farmer_reg_details_id', $fid)->get();
            $nonConDetail = AtInspectionNonConformity::where('at_farmer_reg_details_id', $fid)->get();
            $appInspDetail = AtInspectionApprovalInternalInspector::where('at_farmer_reg_details_id', $fid)->first();
            if ($farPlotDetail->isEmpty() || $farCheckList->isEmpty() || $nonConDetail->isEmpty() || !$appInspDetail) {
                return response()->json([
                    'status' => 404,
                    'message' => 'Some related data is missing for the farmer.',
                    'data' => []
                ]);
            }

            $pdf = PDF::loadView('admin.internal_approval.inspection-compelete-detail-download', compact(
                'oper_type',
                'regDetail',
                'farInspDetail',
                'farPlotDetail',
                'farCheckList',
                'nonConDetail',
                'appInspDetail',
                'fid'
            ));

            $pdfDirectory = public_path('mob_insp_details/' . $fid);
            if (!File::exists($pdfDirectory)) {
                File::makeDirectory($pdfDirectory, 0777, true);
            }
            // $fileName = 'inspection-details-' . $fid . '-' . time() . '.pdf';
            $fileName = 'inspection_details_' . $fid . '.pdf';
            $filePath = $pdfDirectory . '/' . $fileName;
            $pdf->save($filePath);
            $pdfUrl = asset('public/mob_insp_details/' . $fid . '/' . $fileName);
            return response()->json(['pdf_url' => $pdfUrl]);
        } catch (Exception $e) {
            \Log::error($e->getMessage());
            $response =  array(
                'status' => 400,
                'message' => $e->getMessage(),
                'data' => array()
            );
            return response()->json($response);
        }
    }

    public function SamplingInfo(Request $request)
    {

        // $requestData = $this->checkValidRequest($request);
        $requestData = $request;
        // dd( $requestData->all());
        // if ($requestData->has('status') && $requestData->get('status') === "false") {
        //     return response()->json(['status' => '400','message' => $requestData['message'],'data' => []]);
        //     // return json_encode(['data' => $this->returnEncryptedResponse(json_encode(['status' => '400','message' => $requestData['message'],'data' => []]))]);
        //}

        DB::beginTransaction();
        $validator = Validator::make($request->all(), [
            // "client_no" => 'required',
            // "date_of_sampling" => 'required',
            // "client_name" => 'required',
            // "product_name" => 'required',
            // "ref_product_kind_id" => 'required',
            // "ref_crop_stage_id" => 'required',
        ]);

        try {

            if ($validator->fails()) {
                return response()->json(['error' => $validator->errors()], 422);
            }

            $dataToInsert = array(
                "client_no" => $requestData['client_no'],
                "sampling_date" => $requestData['sampling_date'],
                "client_name" => $requestData['client_name'],
                "product_name" => $requestData['product_name'],
                "ref_product_kind_id" => $requestData['ref_product_kind_id'],
                "ref_crop_stage_id" => $requestData['ref_crop_stage_id'],
                "sample_packed_in" => $requestData['sample_packed_in'],
                "sample_weight" => $requestData['sample_weight'],
                "prd" => $requestData['prd'],
                "prc" => $requestData['prc'],
                "farm" => $requestData['farm'],
                "lot_number" => $requestData['lot_number'],
                "storage_location" => $requestData['storage_location'],
                "sample_location_sketch" => $requestData['sample_location_sketch'],
                "seal_numbers" => $requestData['seal_numbers'],
                "inspector_name" => $requestData['inspector_name'],
                "witness_name" => $requestData['witness_name'],
                "declaration" => $requestData['declaration'],
                "witness_signature_doc" => $requestData['witness_signature_doc'],
                "operator_signature_doc" => $requestData['operator_signature_doc'],
                "inspector_signature_doc" => $requestData['inspector_signature_doc'],
                "date_witnessed" => $requestData['date_witnessed'],
                "date_operator_signed" => $requestData['date_operator_signed'],
                "date_inspector_signed" => $requestData['date_inspector_signed'],
                "at_user_id" => $requestData['at_user_id'],
                "ref_operator_type_id" => $requestData['ref_operator_type_id'],
                // 'created_at' => date("Y-m-d H:i:s")


            );
            $datasucces =  SamplingInfo::create($dataToInsert);

            if (isset($datasucces)) {
                // return $this->returnEncryptedResponse(json_encode(['status' => 200, 'message' => 'create success', 'data' => $datasucces]));
                $externalSchedule = AtExternalSchedule::where('at_user_id', $requestData['at_user_id'])->first();
                if ($externalSchedule) {
                    $externalSchedule->update([
                        'sampling_status' => 1,
                        'updated_at' => date("Y-m-d H:i:s"),
                    ]);
                }
                DB::commit();
                return response()->json(['status' => 200, 'message' => 'Submitted successfully']);
            } else {

                DB::rollBack();
                return response()->json(['status' => 400, 'message' => 'Failed to sampling', 'data' => []]);
            }
        } catch (Exception $e) {
            DB::rollBack();
            \Log::error($e->getMessage());
            return response()->json(['status' => '404', 'message' => $e->getMessage()], 404);
        } catch (\Illuminate\Database\QueryException $exception) {
            \Log::error($exception->getMessage());
            return response()->json(['status' => '500', 'message' => 'Query Exception'], 500);
        }
    }

    public function getCropProductData(Request $request)
    {
        // Fetching CropStage and ProductKind data
        $CropStage = RefCropStage::select('crop_stage_id', 'crop_stage_name')->orderBy('crop_stage_id', 'ASC')->get();

        $ProductKind = RefProductKind::select('product_kind_id', 'product_kind_name')->orderBy('product_kind_id', 'ASC')->get();

        // Organize data into an array
        $data = [
            'crop_stage' => $CropStage,
            'product_kind' => $ProductKind,
        ];

        // If data is present, return the response with data
        if (!empty($data['crop_stage']) || !empty($data['product_kind'])) {
            return response()->json([
                'status' => 200,
                'message' => "ALL Details",
                'data' => $data
            ]);
        } else {
            // Return error message if no data is found
            return response()->json([
                'status' => 400,
                'message' => 'Type does not exist',
                'data' => ''
            ]);
        }
    }



    public function getCheckList(Request $request)
    {
        $type = $request->operator_type_code;

        $operatorType = RefOperatorType::where('operator_type_code', $type)->where('is_deleted', false)->first();
        $operator_type = str_replace(' ', '_', $operatorType->operator_type);
        $operator_id = $operatorType->id;
        $activities = NpopProcessingActivities::where('operator_id', $operatorType->id)->get();
        $groupedActivities = $activities->groupBy('type');
        if ($groupedActivities->isNotEmpty()) {
            $processorData = [];

            foreach ($groupedActivities as $type => $items) {
                if (!empty($type)) {
                    $typeName = str_replace(' ', '_', getActivitiesTypeByID($type));
                } else {
                    $typeName = 'activites';
                }
                $processorData[$typeName] = $items->map(function ($item) {
                    return [
                        'id' => $item->id,
                        'activity' => $item->activity,
                        'remarks' => $item->remarks,
                        'status' => $item->status
                    ];
                });
            }

            return response()->json([
                'status' => 200,
                'message' => "checkPoints data",
                'operator_id' => $operator_id,
                $operator_type => $processorData,
            ]);
        } else {
            return response()->json(['status' => 400, 'message' => "CheckPoints not Found", $operatorType->operator_type => []]);
        }
    }

    public function saveCheckProcessRemarks(Request $request)
    {
        $x = new \stdClass();

        $validator = Validator::make(
            $request->all(),
            [
                'operator_id' => 'required',
                'user_id' => 'required',
                'inspector_id' => 'required',
                'processor_name' => 'required',
                'processor_code' => 'required',
                'processing_unit_address' => 'required',
                'related_activities_processing_unit' => 'required',
                'additional_site_address' => 'required',
                'related_activities_additional_site' => 'required',
                'inspection_date' => 'required',
                'inspector_name' => 'required',
                'inspection_time' => 'required',
                'm_latitude' => 'required',
                'm_longitude' => 'required',
                'sign_processor_img' => 'required|string',
                'sign_processor_date' => 'required',
                'sign_inspector_img' => 'required|string',
                'sign_inspector_date' => 'required',
                'warehouse_img' => 'required|string',
                'remarks' => 'required|string',
                'npop_general' => 'required|array',
                'npop_organic_mangement_plan' => 'required|array',
                'npop_seperation_measures' => 'required|array',
                'npop_facility_practices_pest_contron' => 'required|array',
                'npop_import_export' => 'required|array',
                'npop_account_tracability_doc' => 'required|array',
                'npop_labelling' => 'required|array',
                'npop_food_processing_handling_composition' => 'required|array',
                'npop_food_proccesing_handling_processing_packaging' => 'required|array',
                'npop_sampling' => 'required|array',
                'npop_analysis' => 'required|array',
                'stock_capacity' => 'required',
                'stock_availability' => 'required',
                'selfie_with_contact_person' => 'required'
            ]
        );

        try {
            if ($validator->fails()) {
                return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
            } else {

                $insert_data = array(
                    'operator_id' => $request->operator_id,
                    'processor_name' => $request->processor_name,
                    'processor_code' => $request->processor_code,
                    'processing_unit_address' => $request->processing_unit_address,
                    'related_activities_processing_unit' => $request->related_activities_processing_unit,
                    'additional_site_address' => $request->additional_site_address,
                    'related_activities_additional_site' => $request->related_activities_additional_site,
                    'inspection_date' => date("Y-m-d", strtotime($request->inspection_date)),
                    'inspector_name' => $request->inspector_name,
                    'inspection_time' => $request->inspection_time,
                    'latitude' => $request->m_latitude,
                    'longitude' => $request->m_longitude,
                    'sign_processor_img' => $request->sign_processor_img,
                    'sign_processor_date' => date("Y-m-d", strtotime($request->sign_processor_date)),
                    'sign_inspector_img' => $request->sign_inspector_img,
                    'sign_inspector_date' => date("Y-m-d", strtotime($request->sign_inspector_date)),
                    'warehouse_img' => $request->warehouse_img,
                    'stock_capacity' => $request->stock_capacity,
                    'stock_availability' => $request->stock_availability,
                    'remarks' => $request->remarks,
                    'selfie_with_contact_person' => $request->selfie_with_contact_person,
                    'created_by' => $request->user_id,
                    'created_at' => date('Y-m-d H:i:s'),
                );

                $newUserInsert_Id = InspectionChecklistProcessor::insertGetId($insert_data);

                $this->insertActivities($request->npop_general, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->npop_organic_mangement_plan, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->npop_seperation_measures, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->npop_facility_practices_pest_contron, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->npop_import_export, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->npop_account_tracability_doc, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->npop_labelling, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->npop_food_processing_handling_composition, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->npop_food_proccesing_handling_processing_packaging, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->npop_sampling, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->npop_analysis, $request->operator_id, $newUserInsert_Id);


                AtExternalSchedule::where('at_user_id', $request->user_id)->update(['status' => 1]);
                return response()->json(['status' => 200, 'message' => "Data Successfully Saved.", 'data' => $x]);
            }
        } catch (Exception $e) {
            \Log::error($e->getMessage());
            $response = array(
                'status' => 400,
                'message' => $e->getMessage(),
                'data' => array()
            );
            return response()->json($response);
        }
    }

    private function insertActivities($activities, $operator_id, $newUserInsert_Id)
    {
        if (is_array($activities) && !empty($activities)) {
            foreach ($activities as $activity) {
                $insert_data = array(
                    "inspection_checklist_id" => $newUserInsert_Id,
                    "ref_npop_processing_activities_id" => $activity['id'],
                    "status" => $activity['status'],
                    "remarks" => $activity['remarks'],
                    "operator_id" => $operator_id,
                    "created_by" => request()->user_id,
                    "created_at" => date('Y-m-d H:i:s'),
                );
                NpopProcessingActivitiesStatus::insert($insert_data);
            }
        }
    }

    private function updateActivities($activities)
    {
        if (is_array($activities) && !empty($activities)) {
            foreach ($activities as $activity) {
                $update_data = array(
                    "status" => $activity['status'],
                    "remarks" => $activity['remarks'],
                    "updated_by" => request()->user_id,
                    "updated_at" => date('Y-m-d H:i:s'),
                );
                NpopProcessingActivities::where(['id' => $activity['id']])->update($update_data);
            }
        }
    }

    public function saveCheckTraderRemarks(Request $request)
    {
        $x = new \stdClass();

        $validator = Validator::make(
            $request->all(),
            [
                'nameOfTrader_traderUnit' => 'required',
                'ec_no' => 'required',
                'address_of_opr' => 'required',
                'total_area' => 'required',
                'email' => 'required|email',
                'type_of_inspection_initial' => 'required',
                'inspector_name' => 'required',
                'inspection_date' => 'required',
                'mLatitude' => 'required',
                'mLongitude' => 'required',
                'landDetails' => 'required|array',
                'user_id' => 'required',
                'operator_id' => 'required',
                'inspector_id' => 'required',
                'sign_of_trader_img' => 'required',
                'sign_of_inspector_img' => 'required',
                'warehouse_processing_unit_godown_img' => 'required',
                'stock_capacity' => 'required',
                'selfie_with_contact_person' => 'required',
                'stock_availability' => 'required'
            ]
        );

        try {
            if ($validator->fails()) {
                return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
            } else {

                // Convert date formats for the trader and inspector
                $sign_date_of_trader = date("Y-m-d", strtotime($request->sign_date_of_trader));
                $sign_date_of_inspector = date("Y-m-d", strtotime($request->sign_date_of_inspector));

                $insert_data = array(
                    'type_of_inspection_initial' => $request->type_of_inspection_initial,
                    'trader_name' => $request->nameOfTrader_traderUnit,
                    'iec_no' => $request->ec_no,
                    'operator_address' => $request->address_of_opr,
                    'total_area' => $request->total_area,
                    'email_id' => $request->email,
                    'inspector_name' => $request->inspector_name,
                    'inspection_date' => date("Y-m-d", strtotime($request->inspection_date)),
                    'latitude' => $request->mLatitude,
                    'longitude' => $request->mLongitude,
                    'created_by' => $request->user_id,
                    'created_at' => now(),
                    'sign_of_trader_img' => $request->sign_of_trader_img,
                    'sign_date_of_trader' => $sign_date_of_trader,
                    'sign_of_inspector_img' => $request->sign_of_inspector_img,
                    'sign_date_of_inspector' => $sign_date_of_inspector,
                    'name_of_trader' => $request->name_of_trader,
                    'warehouse_processing_unit_godown_img' => $request->warehouse_processing_unit_godown_img,
                    'remarks' => $request->remarks,
                    'operator_id' => $request->operator_id,
                    'inspector_id' => $request->inspector_id,
                    'stock_capacity' => $request->stock_capacity,
                    'selfie_with_contact_person' => $request->selfie_with_contact_person,
                    'stock_availability' => $request->stock_availability
                );

                $newUserInsert_Id = InspectionChecklistTrader::insertGetId($insert_data);

                if (is_array($request->landDetails) && !empty($request->landDetails)) {
                    foreach ($request->landDetails as $activity) {
                        $insert_data = array(
                            "inspection_checklist_id" => $newUserInsert_Id,
                            "ref_npop_processing_activities_id" => $activity['id'],
                            "status" => $activity['status'],
                            "remarks" => $activity['remarks'],
                            "operator_id" => $request->operator_id,
                            "created_by" => request()->user_id,
                            "created_at" => date('Y-m-d H:i:s'),
                        );
                        NpopProcessingActivitiesStatus::insert($insert_data);
                        // NpopProcessingActivities::where(['id' => $activity['id']])->update($update_data);
                    }
                }


                AtExternalSchedule::where('at_user_id', $request->user_id)->update(['status' => 1]);
                return response()->json(['status' => 200, 'message' => "Data Successfully Saved.", 'data' => $x]);
            }
        } catch (Exception $e) {
            \Log::error($e->getMessage());
            $response = array(
                'status' => 400,
                'message' => $e->getMessage(),
                'data' => array()
            );
            return response()->json($response);
        }
    }



    public function saveCheckWildHarvestRemarks(Request $request)
    {
        $x = new \stdClass();

        $validator = Validator::make(
            $request->all(),
            [
                'wild_collector_name' => 'required',
                'tracenet_code' => 'required',
                'authorized_person_name' => 'required',
                'inspection_officer_name' => 'required',
                'wild_collector_address' => 'required',
                'inspection_date' => 'required',
                'forest_division_description' => 'required',
                'inspection_time' => 'required',
                'permission_letter_from_forest_dept' => 'required',
                'user_id' => 'required',
                'operator_id' => 'required',
                'inspector_id' => 'required',
                'activities_id' => 'required|array',
                'sign_of_wild_harvestor_img' => 'required',
                'sign_of_inspector_img' => 'required',
                'warehouse_img' => 'required',
                'stock_capacity' => 'required',
                'selfie_with_contact_person' => 'required',
                'stock_availability' => 'required'
            ]
        );

        try {
            if ($validator->fails()) {
                return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
            } else {

                // Convert date formats for the wild harvester and inspector
                $sign_date_of_wild_harvestor = date("Y-m-d", strtotime($request->sign_date_of_wild_harvestor));
                $sign_date_of_inspector = date("Y-m-d", strtotime($request->sign_date_of_inspector));

                $insert_data = array(
                    'wild_collector_name' => $request->wild_collector_name,
                    'tracenet_code' => $request->tracenet_code,
                    'authorized_person_name' => $request->authorized_person_name,
                    'inspection_officer_name' => $request->inspection_officer_name,
                    'wild_collector_address' => $request->wild_collector_address,
                    'inspection_date' => date("Y-m-d", strtotime($request->inspection_date)),
                    'forest_division_description' => $request->forest_division_description,
                    'inspection_time' => $request->inspection_time,
                    'permission_letter_from_forest_dept' => $request->permission_letter_from_forest_dept,
                    'created_by' => $request->user_id,
                    'created_at' => now(),
                    'signature_of_wild_collector' => $request->sign_of_wild_harvestor_img,
                    'signature_date_wild_collector' => $sign_date_of_wild_harvestor,
                    'name_of_wild_harvester' => $request->name_of_wild_harvester,
                    'signature_of_inspector' => $request->sign_of_inspector_img,
                    'signature_date_inspector' => $sign_date_of_inspector,
                    'name_of_inspector' => $request->name_of_inspector,
                    'warehouse_img' => $request->warehouse_img,
                    'remarks' => $request->remarks,
                    'operator_id' => $request->operator_id,
                    'inspector_id' => $request->inspector_id,
                    'stock_capacity' => $request->stock_capacity,
                    'selfie_with_contact_person' => $request->selfie_with_contact_person,
                    'stock_availability' => $request->stock_availability
                );

                $newUserInsert_Id = InspectionChecklistWildCollectionHarvest::insertGetId($insert_data);


                if (is_array($request->activities_id) && !empty($request->activities_id)) {
                    foreach ($request->activities_id as $key => $activity) {
                        $insert_data = array(
                            "inspection_checklist_id" => $newUserInsert_Id,
                            "ref_npop_processing_activities_id" => $activity['id'],
                            "status" => $activity['status'],
                            "remarks" => $activity['remarks'],
                            "operator_id" => $request->operator_id,
                            "created_by" => request()->user_id,
                            "created_at" => date('Y-m-d H:i:s'),
                        );
                        NpopProcessingActivitiesStatus::insert($insert_data);
                    }
                }

                AtExternalSchedule::where('at_user_id', $request->user_id)->update(['status' => 1]);
                return response()->json(['status' => 200, 'message' => "Data Successfully Saved.", 'data' => $x]);
            }
        } catch (Exception $e) {
            \Log::error($e->getMessage());
            $response = array(
                'status' => 400,
                'message' => $e->getMessage(),
                'data' => array()
            );
            return response()->json($response);
        }
    }


    public function saveCheckIndividualFarmerRemarks(Request $request)
    {
        $x = new \stdClass();

        $validator = Validator::make(
            $request->all(),
            [
                'name_of_farmer' => 'required',
                'farmer_code' => 'required',
                'address_of_farmer' => 'required',
                'total_area' => 'required',
                'type_of_inspection_initial' => 'required',
                'inspector_name' => 'required',
                'date_of_inspection' => 'required',
                'm_latitude' => 'required',
                'm_longitude' => 'required',
                'name_of_operation' => 'required',
                'land_offered_for_cert' => 'required',
                'no_of_farm' => 'required',
                'last_date_of_prohibated_material_used' => 'required',
                'date_of_reg_with_ics' => 'required',
                'production_type' => 'required',
                'status_of_land' => 'required',
                'total_cultivable_land' => 'required',
                'land_offer_for_certification' => 'required',
                'stock_capacity' => 'required',
                'selfie_with_contact_person' => 'required',
                'stock_availability' => 'required'
            ]
        );

        try {
            if ($validator->fails()) {
                return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
            } else {


                $insert_data = array(
                    'type_of_inspection_initial'   => $request->type_of_inspection_initial,
                    'farmer_name'   => $request->name_of_farmer,
                    'farmer_code' => $request->farmer_code,
                    'farmer_address' => $request->address_of_farmer,
                    'total_area_ha' => $request->total_area,
                    'inspector_name' => $request->inspector_name,
                    'inspection_date' => date("Y-m-d", strtotime($request->date_of_inspection)),
                    'latitude' => $request->m_latitude,
                    'longitude' => $request->m_longitude,
                    'operation_name' => $request->name_of_operation,
                    'land_offered_certification' => $request->land_offered_for_cert,
                    'no_of_farms_plots' => $request->no_of_farm,
                    'last_prohibited_material_date' => date("Y-m-d", strtotime($request->last_date_of_prohibated_material_used)),
                    'registration_date_with_ics' => date("Y-m-d", strtotime($request->date_of_reg_with_ics)),
                    'production_type' => $request->production_type,
                    'land_status' => $request->status_of_land,
                    'total_cultivable_land' => $request->total_cultivable_land,
                    'land_offer_for_certification' => $request->land_offer_for_certification,
                    'c_one' => $request->c_one,
                    'c_two' => $request->c_two,
                    'c_three' => $request->c_three,
                    'organic' => $request->organic,
                    'overall_observation' => $request->overall_observation_of_insp,
                    'sign_of_farmer_img' => $request->sign_of_farmer_img,
                    'sign_date_of_farmer' => date("Y-m-d", strtotime($request->sign_date_of_farmer)),
                    'sign_date_of_inspector' => date("Y-m-d", strtotime($request->sign_date_of_inspector)),
                    'sign_date_of_ics_representative' => date("Y-m-d", strtotime($request->sign_date_of_ics_representative)),
                    'sign_of_inspector_img' => $request->sign_of_inspector_img,
                    'name_of_ics_representative' => $request->name_of_ics_representative,
                    'sign_of_ics_representative_img' => $request->sign_of_ics_representative_img,
                    'any_nc_ofc_one' => $request->any_nc_ofc_one,
                    'any_nc_ofc_two' => $request->any_nc_ofc_two,
                    'warehouse_img' => $request->warehouse_img,
                    'stock_capacity' => $request->stock_capacity,
                    'stock_availability' => $request->stock_availability,
                    'remarks' => $request->remarks,
                    'operator_id' => $request->operator_id,
                    'inspector_id' => $request->inspector_id,
                    'selfie_with_contact_person' => $request->selfie_with_contact_person,
                    'created_by' => $request->user_id,
                    'created_at' => date('Y-m-d H:i:s')
                );

                $newUserInsert_Id = InspectionChecklistIndividualFarmer::insertGetId($insert_data);


                if (is_array($request->added_crop_details) && !empty($request->added_crop_details)) {
                    foreach ($request->added_crop_details as $crop) {
                        $insert_data = array(
                            "inspection_checklist_id" => $newUserInsert_Id,
                            "crop_name" => $crop['crop_name'],
                            "season" => $crop['crop_season'],
                            "status" => $crop['status'],
                            "main_or_intercrop" => $crop['main_intercrop_a'],
                            "area_ha" => $crop['area'],
                            "estimated_yield_mt" => $crop['estimated_yield'],
                            "created_by" => $request->user_id,
                            "created_at" => date('Y-m-d H:i:s'),
                        );
                        PpInspectionChecklistCropDetails::insert($insert_data);
                    }
                }

                $this->insertActivities($request->landscape_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->choice_of_crop_varieties_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->nutrient_management_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->pest_disease_weed_mgmt_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->contamination_control_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->soil_water_conservation_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->information_sampling_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->harvest_handling_storage_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->additinal_requirements_checklist, $request->operator_id, $newUserInsert_Id);


                if (is_array($request->added_on_farm_input_available) && !empty($request->added_on_farm_input_available)) {
                    foreach ($request->added_on_farm_input_available as $input) {
                        $insert_data = array(
                            "inspection_checklist_id" => $newUserInsert_Id,
                            "crop_name" => $input['crop_name'],
                            "source_of_seed_planting_stock" => $input['source_of_seed'],
                            "conventional_or_organic" => $input['conventional_organic'],
                            "treated_or_untreated" => $input['treated_untreated'],
                            "gmo_or_non_gmo" => $input['gmo_nongmo'],
                            "created_by" => $request->user_id,
                            "created_at" => date('Y-m-d H:i:s'),
                        );
                        IpFarmInputDetails::insert($insert_data);
                    }
                }

                if (is_array($request->added_nutrient_details) && !empty($request->added_nutrient_details)) {
                    foreach ($request->added_nutrient_details as $nutrient) {
                        $insert_data = array(
                            "inspection_checklist_id" => $newUserInsert_Id,
                            "input_name" => $nutrient['input_usedbrand_name'],
                            "on_off_farm" => $nutrient['onfarm_offfarm'],
                            "approval_status" => $nutrient['approved_notapproved'],
                            "composition" => $nutrient['composition'],
                            "frequency_of_usage" => $nutrient['frequency_of_usage'],
                            "application_rate" => $nutrient['application_rate'],
                            "created_by" => $request->user_id,
                            "created_at" => date('Y-m-d H:i:s'),
                        );
                        IpFarmInputDetailsNutrientManagement::insert($insert_data);
                    }
                }

                if (is_array($request->added_harvesting_details) && !empty($request->added_harvesting_details)) {
                    foreach ($request->added_harvesting_details as $harvest) {
                        $insert_data = array(
                            "inspection_checklist_id" => $newUserInsert_Id,
                            "last_year_season" => $harvest['last_year_season'],
                            "major_crop_grown" => $harvest['major_grown_up'],
                            "harvest_month" => $harvest['harvesting_month'],
                            "quantity_kg" => $harvest['quantity'],
                            "created_by" => $request->user_id,
                            "created_at" => date('Y-m-d H:i:s'),
                        );
                        IpFarmHarvestHandlingStorage::insert($insert_data);
                    }
                }

                AtExternalSchedule::where('at_user_id', $request->user_id)->update(['status' => 1]);

                return response()->json(['status' => 200, 'message' => "Data Successfully Saved.", 'data' => $x]);

                // if ($newUserInsert_Id) {
                //     AtExternalSchedule::where('at_user_id', $request->user_id)->update(['status' => 1]);

                //     return response()->json(['status' => 200, 'message' => "Data Successfully Saved.", 'data' => $x]);
                // } else {
                //     return response()->json(['status' => 500, 'message' => "Data not saved.", 'data' => $x]);
                // }
            }
        } catch (Exception $e) {
            \Log::error($e->getMessage());
            $response =  array(
                'status' => 400,
                'message' => $e->getMessage(),
                'data' => array()
            );
            return response()->json($response);
        }
    }

    public function saveCheckGrowerGroupRemarks(Request $request)
    {

       // dd($request->all());
        $x = new \stdClass();

        $validator = Validator::make(
            $request->all(),
            [
                'grower_group_name' => 'required',
                'grower_group_address' => 'required',
                'authorized_representative_name' => 'required',
                'mobile_no_ics_manager' => 'required',
                'grower_group_email' => 'required',
                'registration_number' => 'required',
                'ics_grower_group_address' => 'required',
                'ics_managed_by' => 'required',
                'service_provider_name' => 'required',
                'service_provider_address' => 'required',
                'inspection_type' => 'required',
                'status_grower_group' => 'required',
                'registration' => 'required',
                'inspection_date_from' => 'required',
                'inspection_date_to' => 'required',
                'team_leader_name' => 'required',
                'team_members_names' => 'required',
                'authorized_signatory_name' => 'required',
                'number_of_farmers' => 'required',
                'total_area_ha' => 'required',
                'any_change_in_number_farmers' => 'required',
                'number_of_new_farmers_added' => 'required',
                'observations_on_new_farmers' => 'required',
                'any_change_in_area' => 'required',
                'new_area_added' => 'required',
                'total_area_offered_for_certification' => 'required',
                'added_compliance_details' => 'array',
                'added_compliance_details.*.compliance_previous_condition' => 'required',
                'added_compliance_details.*.noncompliance_type' => 'required',
                'added_compliance_details.*.action_taken' => 'required',
                'added_compliance_details.*.status_of_action_taken' => 'required',
                'added_compliance_details.*.remarks' => 'required',
                'added_crops_summary' => 'array',
                'added_crops_summary.*.crop_season' => 'required',
                'added_crops_summary.*.crop_option' => 'required',
                'added_crops_summary.*.crop_area' => 'required',
                'added_crops_summary.*.estimated_yield' => 'required',
                'added_crops_summary.*.crop_status' => 'required',
                'overall_observation_project_inspector_remarks' => 'required',
                'selfie_with_contact_person' => 'required',
                'user_id' => 'required',
                'operator_id' => 'required',
                'inspector_id' => 'required'
            ]
        );

        try {
            if ($validator->fails()) {
                return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
            } else {
                // Inserting grower group details
                $insert_data = array(
                    'grower_group_name' => $request->grower_group_name,
                    'grower_group_address' => $request->grower_group_address,
                    'authorized_representative_name' => $request->authorized_representative_name,
                    'mobile_no_ics_manager' => $request->mobile_no_ics_manager,
                    'grower_group_email' => $request->grower_group_email,
                    'registration_number' => $request->registration_number,
                    'ics_address' => $request->ics_grower_group_address,
                    'ics_managed_by' => $request->ics_managed_by,
                    'service_provider_name' => $request->service_provider_name,
                    'service_provider_address' => $request->service_provider_address,
                    'ref_inspection_type_id' => $request->inspection_type,
                    'grower_group_status' => $request->status_grower_group,
                    'registration' => $request->registration,
                    'inspection_date_from' => date("Y-m-d", strtotime($request->inspection_date_from)),
                    'inspection_date_to' => date("Y-m-d", strtotime($request->inspection_date_to)),
                    'team_leader_name' => $request->team_leader_name,
                    'team_members_names' => $request->team_members_names,
                    'authorized_signatory_name' => $request->authorized_signatory_name,
                    'at_external_schedule_id' =>$request->inspector_id, 
                    'number_of_farmers' => $request->number_of_farmers,
                    'total_area_ha' => $request->total_area_ha,
                    'any_change_in_farmers' => $request->any_change_in_number_farmers,
                    'number_of_new_farmers_added' => $request->number_of_new_farmers_added,
                    'observations_on_new_farmers' => $request->observations_on_new_farmers,
                    'any_change_in_area' => $request->any_change_in_area,
                    'new_area_added' => $request->new_area_added,
                    'total_area_offered_for_certification' => $request->total_area_offered_for_certification,
                    'overall_observation_project_inspector_remarks' => $request->overall_observation_project_inspector_remarks,
                    'selfie_with_contact_person' => $request->selfie_with_contact_person,
                    'created_by' => $request->user_id,
                    'created_at' => date('Y-m-d H:i:s')
                );

                $newUserInsert_Id = AtInspectionChecklistGrowerGroup::insertGetId($insert_data);

                // Insert added compliance details
                if (is_array($request->added_compliance_details) && !empty($request->added_compliance_details)) {
                    foreach ($request->added_compliance_details as $compliance) {
                        $insert_data = array(
                            "at_inspection_checklist_grower_group_id" => $newUserInsert_Id,
                            "compliance_previous_condition" => $compliance['compliance_previous_condition'],
                            "noncompliance_type" => $compliance['noncompliance_type'],
                            "action_taken" => $compliance['action_taken'],
                            "status_of_action_taken" => $compliance['status_of_action_taken'],
                            "remarks" => $compliance['remarks'],
                            "created_by" => $request->user_id,
                            "created_at" => date('Y-m-d H:i:s'),
                        );
                        AtComplianceDetails::insert($insert_data);
                    }
                }

                // Insert added crops summary
                if (is_array($request->added_crops_summary) && !empty($request->added_crops_summary)) {
                    foreach ($request->added_crops_summary as $v) {
                        $insert_data = array(
                            "at_inspection_checklist_grower_group_id" => $newUserInsert_Id,
                            "crop_season" => $v['crop_season'],
                            "crop_main" => $v['crop_main'],
                            "intercrops_buffer_crop_cover_crop" => $v['crop_option'],
                            "crop_area_ha" => $v['crop_area'],
                            "estimated_yield_mt" => $v['estimated_yield'],
                            "crop_status" => $v['crop_status'],
                            "created_by" => $request->user_id,
                            "created_at" => date('Y-m-d H:i:s'),
                        );
                        AtGrowerGroupCropsDetails::insert($insert_data);
                    }
                }

                // Insert activities for various checklists
                $this->insertActivities($request->scope_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->constitution_of_ics_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->internal_control_system_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->internal_control_system_manager_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->internal_inspector_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->approval_committee_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->field_officers_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->purchase_officers_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->wharehouse_manager_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->internal_standard_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->conflict_of_interest_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->scope_of_certification_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->trade_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->procedures_implement_internal_control_system_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->operating_document_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->internal_inspections_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->internal_approvals_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->yield_estimates_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->non_compliances_sanctions_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->training_ics_personnel_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->training_of_farmers_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->buying_procedures_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->storage_handling_procedures_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->general_observation_grower_group_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->inspection_parallel_production_farms_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->packaging_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->labeling_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->logo_checklist, $request->operator_id, $newUserInsert_Id);
                $this->insertActivities($request->records_and_accounts_checklist, $request->operator_id, $newUserInsert_Id);

                // Mark external schedule as complete
                AtExternalSchedule::where('at_user_id', $request->user_id)->update(['status' => 1]);

                return response()->json(['status' => 200, 'message' => "Data Successfully Saved.", 'data' => $x]);
            }
        } catch (Exception $e) {
            \Log::error($e->getMessage());
            $response =  array(
                'status' => 400,
                'message' => $e->getMessage(),
                'data' => array()
            );
            return response()->json($response);
        }
    }

    private function updateCheckIndividualActivities($activities)
    {
        if (is_array($activities) && !empty($activities)) {
            foreach ($activities as $activity) {
                $update_data = array(
                    "status" => $activity['status'],
                    "remarks" => $activity['remarks'],
                    "updated_by" => request()->user_id,
                    "updated_at" => date('Y-m-d H:i:s'),
                );
                NpopProcessingActivities::where(['id' => $activity['id']])->update($update_data);
            }
        }
    }

    // public function upcomingInspection(Request $request)
    // {
    //     $validator = Validator::make(
    //         $request->all(),
    //         [
    //             'inspector_id' => 'required',
    //         ],
    //         [
    //             'inspector_id.required' => 'Inspector ID is required.',
    //         ]
    //     );

    //     if ($validator->fails()) {
    //         return response()->json([
    //             'errors' => $validator->errors(),
    //         ], 422);
    //     }

    //     $inspector_id = $request->inspector_id;

    //     // Get the current date
    //     $currentDate = now()->toDateString();

    //     // Update the status to 0 for records with inspection_date on or after the current date
    //     AtExternalSchedule::where('inspector_name', $inspector_id)
    //         ->where('inspection_date', '>=', $currentDate)
    //         ->update(['status' => 0]);

    //     // Query to fetch schedules for the inspector with a future inspection date
    //     $schedules = AtExternalSchedule::where('inspector_name', $inspector_id)
    //         ->where('inspection_date', '>=', $currentDate)
    //         ->get();

    //     // Check if no schedules are found
    //     if ($schedules->isEmpty()) {
    //         return response()->json([
    //             'message' => 'No upcoming schedules found for the given inspector ID.',
    //         ], 404);
    //     }

    //     // Prepare the response data
    //     $data = [
    //         'UpcomingInspections' => $schedules->map(function ($schedule) {
    //             return [
    //                 'id' => $schedule->id ?? '',
    //                 'UserId' => $schedule->at_user_id ?? '',
    //                 'OperatorTypeId' => $schedule->operator_type_id ?? '',
    //                 'OperatorType' => $schedule->operator_type ?? '',
    //                 'OperatorName' => $schedule->operator_name ?? '',
    //                 'OperatorMobile' => $schedule->operator_mobile ?? '',
    //                 'OperatorEmail' => $schedule->operator_email ?? '',
    //                 'OperatorRegistration' => $schedule->reg_no ?? '',
    //                 'ScheduleFrom' => date('d-m-Y', strtotime($schedule->submission_of_inspection_report ?? '')),
    //                 'ScheduleTo' => date('d-m-Y', strtotime($schedule->inspection_date ?? '')),
    //                 'SamplingStatus' => $schedule->sampling_status == 0 ? 'Sample not drawn' : ($schedule->sampling_status == 1 ? 'Sample drawn' : 'Unknown'),
    //             ];
    //         }),
    //     ];

    //     return response()->json($data, 200);
    // }


    public function upcomingInspection(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'inspector_id' => 'required',
            ],
            [
                'inspector_id.required' => 'Inspector ID is required.',
            ]
        );

        if ($validator->fails()) {
            return response()->json([
                'errors' => $validator->errors(),
            ], 422);
        }

        $inspector_id = $request->inspector_id;


        $currentDate = now()->toDateString();




        // AtExternalSchedule::where('inspector_name', $inspector_id)
        //     ->where('inspection_date', '>=', $currentDate)
        //     ->where('status', 0) // Only update if status is still 0
        //     ->update(['status' => 1]);

        // Update the status to 0 for records with inspection_date on or after the current date


        $schedules = AtExternalSchedule::where('inspector_name', $inspector_id)
            ->where('status', 0)
            // ->where('approve', 0)
            ->orderBy('inspection_date', 'asc')
            ->get();


        // Query to fetch schedules for the inspector with a future inspection date
        // $schedules = AtExternalSchedule::where('inspector_name', $inspector_id)

        //     ->where('inspection_date', '>=', $currentDate)

        //     ->get();

        // Check if no schedules are found
        if ($schedules->isEmpty()) {


            return response()->json(['status' => 400, 'message' => "No upcoming schedules found for the given inspector.'", 'UpcomingInspections' => []]);
        }

        // Prepare the response data
        $data = [
            'UpcomingInspections' => $schedules->map(function ($schedule) {
                return [
                    'id' => $schedule->id ?? '',
                    'UserId' => $schedule->at_user_id ?? '',
                    'OperatorTypeId' => $schedule->operator_type_id ?? '',
                    'OperatorType' => $schedule->operator_type ?? '',
                    'OperatorName' => $schedule->operator_name ?? '',
                    'OperatorMobile' => $schedule->operator_mobile ?? '',
                    'OperatorEmail' => $schedule->operator_email ?? '',
                    'OperatorAddress' => $schedule->operator_address ?? '',
                    'OperatorRegistration' => $schedule->reg_no ?? '',
                    'ScheduleFrom' => date('d-m-Y', strtotime($schedule->submission_of_inspection_report ?? '')),
                    'ScheduleTo' => date('d-m-Y', strtotime($schedule->inspection_date ?? '')),
                    'SamplingStatus' => $schedule->sampling_status == 0 ? 'Sample not drawn' : ($schedule->sampling_status == 1 ? 'Sample drawn' : 'Unknown'),
                    'accept_reject_status' => $schedule->approve ?? '',

                ];
            }),
        ];

        return response()->json($data, 200);
    }


    public function searchApi(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'inspector_id' => 'required_without:OperatorRegistration',
                'OperatorRegistration' => 'required_without:inspector_id',
            ],
            [
                'inspector_id.required_without' => 'Inspector ID is required when Operator Registration is not provided.',
                'OperatorRegistration.required_without' => 'Operator Registration is required when Inspector ID is not provided.',
            ]
        );

        if ($validator->fails()) {
            return response()->json([
                'errors' => $validator->errors(),
            ], 400);
        }

        $inspector_id = $request->inspector_id;
        $operator_registration = $request->OperatorRegistration;

        $query = AtExternalSchedule::query();

        if ($inspector_id) {
            $query->where('inspector_name', $inspector_id);
        }

        if ($operator_registration) {
            $query->where('reg_no', $operator_registration);
        }

        $query->where('status', 0)->orderBy('inspection_date', 'asc');

        $schedules = $query->get();

        if ($schedules->isEmpty()) {
            return response()->json(['status' => 400, 'message' => "No data found.", 'SearchRecord' => []]);
        }

        $data = [
            'SearchRecord' => $schedules->map(function ($schedule) {
                return [
                    'id' => $schedule->id ?? '',
                    'UserId' => $schedule->at_user_id ?? '',
                    'OperatorTypeId' => $schedule->operator_type_id ?? '',
                    'OperatorType' => $schedule->operator_type ?? '',
                    'OperatorName' => $schedule->operator_name ?? '',
                    'OperatorMobile' => $schedule->operator_mobile ?? '',
                    'OperatorEmail' => $schedule->operator_email ?? '',
                    'OperatorAddress' => $schedule->operator_address ?? '',
                    'OperatorRegistration' => $schedule->reg_no ?? '',
                    'ScheduleFrom' => date('d-m-Y', strtotime($schedule->submission_of_inspection_report ?? '')),
                    'ScheduleTo' => date('d-m-Y', strtotime($schedule->inspection_date ?? '')),
                    'SamplingStatus' => $schedule->sampling_status == 0 ? 'Sample not drawn' : ($schedule->sampling_status == 1 ? 'Sample drawn' : 'Unknown'),
                ];
            }),
        ];

        return response()->json($data, 200);
    }

    public function rescheduleInspection(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'inspector_id' => 'required|integer',
                'user_id' => 'required|integer',
                'due_date' => 'required|date|after_or_equal:today',
                'remarks' => 'nullable|string|max:255',
            ],
            [
                'inspector_id.required' => 'Inspector ID is required.',
                'inspector_id.integer' => 'Inspector ID must be a valid number.',
                'user_id.required' => 'User ID is required.',
                'user_id.integer' => 'User ID must be a valid number.',
                'due_date.required' => 'Due date is required.',
                'due_date.date' => 'Due date must be a valid date.',
                'due_date.after_or_equal' => 'Due date must be today or a future date.',
                'remarks.string' => 'Remarks must be a valid string.',
                'remarks.max' => 'Remarks should not exceed 255 characters.',
            ]
        );
    
        if ($validator->fails()) {
            return response()->json([
                'errors' => $validator->errors(),
            ], 400);
        }
    
        $inspector_id = $request->inspector_id;
        $user_id = $request->user_id;
        $due_date = $request->due_date;
        $remarks = $request->remarks;
    
        // Fetch due inspections for the given inspector and user
        $dueInspections = AtExternalSchedule::where('inspector_name', $inspector_id)
            ->where('at_user_id', $user_id) // Filter by user_id
            ->where('status', '!=', 1) // Exclude completed inspections
            ->whereDate('inspection_date', '>', now())
            ->get();
    
        if ($dueInspections->isEmpty()) {
            return response()->json([
                'status' => 400,
                'message' => "No due inspections found for the given inspector and user.",
            ]);
        }
    
        // Update the due inspections with the new due_date and remarks
        foreach ($dueInspections as $inspection) {
            $inspection->inspection_date = $due_date;
            if (!is_null($remarks)) {
                $inspection->remarks = $remarks; // Update remarks if provided
            }
            $inspection->save();
        }
    
        return response()->json([
            'status' => 200,
            'message' => 'Inspections rescheduled successfully.',
            'rescheduledInspections' => $dueInspections->map(function ($inspection) {
                return [
                    'id' => $inspection->id,
                    'UserId' => $inspection->at_user_id,
                    'NewInspectionDate' => $inspection->inspection_date,
                    'Remarks' => $inspection->remarks,
                ];
            }),
        ]);
    }
    

    public function acceptRejectSchedule(Request $request)
    {
       // dd($request->all());

        $validator = Validator::make(
            $request->all(),
            [
                // 'inspection_id' => 'required|integer|exists:at_external_schedule,id',
                'user_id'=> 'required',
                'status' => 'required',
                'remarks' => 'nullable|string|max:255',
            ],
            [
                'user_id.required' => 'Operator ID is required.',
                //  'inspection_id.exists' => 'The specified inspection does not exist.',
                'status.required' => 'Status is required.',
                //'status.in' => 'Status must be either "accept" or "reject".',
                'remarks.string' => 'Remarks must be a valid string.',
                'remarks.max' => 'Remarks should not exceed 255 characters.',
            ]
        );


        if ($validator->fails()) {
            return response()->json([
                'errors' => $validator->errors(),
            ], 422);
        }

        $inspection_id = $request->inspector_id;
        $at_user_id = $request->user_id;
        $status = $request->status;
        $remarks = $request->remarks;


        $inspection = AtExternalSchedule::where('inspector_name', $inspection_id)->first();

        //dd($inspection);

        if (!$inspection) {
            return response()->json([
                'status' => 404,
                'message' => 'Inspection not found.',
            ], 404);
        }

        $inspection->at_user_id = $at_user_id;
        $inspection->approve = $status;
        $inspection->remarks = $remarks;
        $inspection->save();


        return response()->json([
            'status' => 200,
            'message' => 'Inspection schedule updated successfully.',
            'inspection' => [
                'id' => $inspection->id,
                'at_user_id' => $inspection->at_user_id,
                'approve' => $inspection->approve == 1 ? 'accepted' : ($inspection->approve == 2 ? 'rejected' : ''),
                'remarks' => $inspection->remarks,
            ],
        ]);
    }



    public function ProcessorReport(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'processor_name' => 'nullable|string',
                'registered_address' => 'nullable|string',
                'authorized_person_name' => 'nullable|string',
                'contact_details_mobile' => 'nullable|string',
                'contact_details_email' => 'nullable|string|email',
                'legal_status_operator' => 'nullable|string',
                'license_number' => 'nullable|string',
                'license_validity' => 'nullable|string',
                'number_sites_audited' => 'nullable|string',
                'respective_addresses' => 'nullable|string',
                'type_inspection' => 'nullable|string',
                'inspection_reason_audit' => 'nullable|string',
                'confirmation_legal_entity' => 'nullable|string',
                'scope_certification_contract' => 'nullable|string',
                'compliance_license_number' => 'nullable|string',
                'compliance_license_validity' => 'nullable|string',
                'manufacturing_capacity' => 'nullable|string',
                'products_certified_number' => 'nullable|string',
                'single_ingredient' => 'nullable|string',
                'multi_ingredient' => 'nullable|string',
                'product_details' => 'nullable|array',
                'product_details.*.product_name' => 'required_with:product_details|string',
                'product_details.*.trade_name' => 'required_with:product_details|string',
                'product_details.*.list_of_ingredients' => 'required_with:product_details|string',
                'product_details.*.source_of_ingredients' => 'required_with:product_details|string',
                'summary_non_compliances' => 'nullable|array',
                'summary_non_compliances.*.npop_clause' => 'required_with:summary_non_compliances|string',
                'summary_non_compliances.*.non_compliance' => 'required_with:summary_non_compliances|string',
                'summary_non_compliances.*.category' => 'required_with:summary_non_compliances|string',
                'additional_remarks' => 'nullable|string',
                'inspector_name' => 'nullable|string',
                'inspector_date' => 'nullable|date',
                //'user_id' => 'required',
            ]
        );

        try {
            if ($validator->fails()) {
                return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
            }

            // Insert processor report details
            $insert_data = [
                'processor_name' => $request->processor_name,
                'registered_address' => $request->registered_address,
                'authorized_person_name' => $request->authorized_person_name,
                'contact_details_mobile' => $request->contact_details_mobile,
                'contact_details_email' => $request->contact_details_email,
                'legalstatus' => $request->legal_status_operator,
                'document_number' => $request->license_number,
                'document_validity' => $request->license_validity,
                'no_of_sites_audited' => $request->number_sites_audited,
                'site_addresses' => $request->respective_addresses,
                'ref_inspection_type_master_id' => $request->type_inspection,
                'specific_reason_for_audit' => $request->inspection_reason_audit,
                'legal_entity_confirmation' => $request->confirmation_legal_entity,
                'certification_scope' => $request->scope_certification_contract,
                'national_legal_compliance' => $request->compliance_license_number,
               // 'compliance_license_validity' => $request->compliance_license_validity,
                'manufacturing_capacity' => $request->manufacturing_capacity,
                'total_products_certified' => $request->products_certified_number,
                'total_single_ingredient' => $request->single_ingredient,
                'total_multi_ingredient' => $request->multi_ingredient,
                'product_processing_description' => $request->additional_remarks,
                'inspector_name' => $request->inspector_name,
                'inspection_date' => $request->inspector_date,
                'at_user_id' => $request->user_id,
                'at_external_schedule_id'=> $request->Inspector_id,
                'created_at' => now()
            ];

            $processorDataId = AtInspectionProcessorReport::insertGetId($insert_data);

            // Insert product details
            if (is_array($request->product_details) && !empty($request->product_details)) {
                foreach ($request->product_details as $product) {
                    AtInspectionProcessorProduct::insert([
                        'at_inspection_processor_report_id' => $processorDataId,
                        'product_name' => $product['product_name'],
                        'trade_name' => $product['trade_name'],
                        'ingredients_list' => $product['list_of_ingredients'],
                        'source_of_ingredients' => $product['source_of_ingredients'],
                        'created_by' => $request->user_id,
                        'created_at' => now()
                    ]);
                }
            }

            // Insert compliance details
            if (is_array($request->summary_non_compliances) && !empty($request->summary_non_compliances)) {
                foreach ($request->summary_non_compliances as $compliance) {
                    AtComplianceDetails::insert([
                        'at_inspection_processor_report_id' => $processorDataId,
                        'noncompliance_type' => $compliance['npop_clause'],
                        'compliance_previous_condition' => $compliance['non_compliance'],
                        //'category' => $compliance['category'],
                        'created_by' => $request->user_id,
                        'created_at' => now()
                    ]);
                }
            }

            return response()->json(['status' => 200, 'message' => "Data Successfully Saved.", 'data' => ['id' => $processorDataId]]);
        } catch (Exception $e) {
            \Log::error($e->getMessage());
            return response()->json(['status' => 400, 'message' => $e->getMessage(), 'data' => []]);
        }
    }

    public function IndivisualproducerReport(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'name_of_individual' => 'nullable|string',
                'farmer_address_with_gps' => 'nullable|string',
                'contact_person_mobile_no' => 'nullable|string',
                'contact_person_email_id' => 'nullable|string',
                'tracenet_registration_no' => 'nullable',
                'summary_non_compliances' => 'nullable|array',
                'summary_non_compliances.*.npop_clause' => 'required_with:summary_non_compliances|string',
                'summary_non_compliances.*.non_compliance' => 'required_with:summary_non_compliances|string',
                'summary_non_compliances.*.category' => 'required_with:summary_non_compliances|string',
                'additional_remarks' => 'nullable|string',
                'inspector_name' => 'nullable|string',
                'inspector_date' => 'nullable|date',
                //'user_id' => 'required',
            ]
        );

        try {
            if ($validator->fails()) {
                return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
            }

            // Insert processor report details
            $insert_data = [
                'name_of_individual' => $request->name_of_individual,
                'farmer_address_with_gps' => $request->farmer_address_with_gps,
                'contact_person_mobile_no' => $request->contact_person_mobile_no,
                'contact_person_email_id' => $request->contact_person_email_id,
                'tracenet_registration_no' => $request->tracenet_registration_no,
                'name_of_inspector' => $request->name_of_inspector,
                'date_of_inspection' => $request->date_of_inspection,
                'time_of_inspection' => $request->time_of_inspection,
                'type_of_inspection' => $request->type_of_inspection,
                'total_land_owned' => $request->total_land_owned,
                'area_under_organic_cultivation' => $request->area_under_organic_cultivation,
                'crops_under_organic_cultivation' => $request->crops_under_organic_cultivation,
                'inspector_signature' => $request->scope_certification_contract,
                'inspector_name' => $request->inspector_name,
                'inspection_date' => $request->inspection_date,
                'report_received_date' => $request->report_received_date,
                'reviewer_name' => $request->reviewer_name,
                'reviewer_signature' => $request->reviewer_signature,
                'created_by' => $request->user_id,
                'updated_at' => now(),
                'at_user_id' => $request->user_id,
                'at_external_schedule_id'=> $request->Inspector_id,
                'created_at' => now(),
               //'updeted_by' => $request->user_id,
            ];

            $processorDataId = AtInspectionIndividualProducerReport::insertGetId($insert_data);

           
            // if (is_array($request->ref_operator_type_id) && !empty($request->ref_operator_type_id)) {
            //     foreach ($request->ref_operator_type_id as $operrator_id) {
            //         RefFarmObservations::insert([
            //             //'at_inspection_processor_report_id' => $processorDataId,
            //             'ref_operator_type_id' => $operrator_id['operator_type_id'],
            //             'created_by' => $request->user_id,
            //             'created_at' => now(),
            //             'updated_by' => now()
            //         ]);
            //     }
            // }

            // Insert compliance details
            if (is_array($request->summary_non_compliances) && !empty($request->summary_non_compliances)) {
                foreach ($request->summary_non_compliances as $compliance) {
                    AtComplianceDetails::insert([
                        'at_inspection_individual_producer_report_id' => $processorDataId,
                        'noncompliance_type' => $compliance['npop_clause'],
                        'compliance_previous_condition' => $compliance['non_compliance'],
                        //'category' => $compliance['category'],
                        'created_by' => $request->user_id,
                        'created_at' => now()
                    ]);
                }
            }

            return response()->json(['status' => 200, 'message' => "Data Successfully Saved.", 'data' => ['id' => $processorDataId]]);
        } catch (Exception $e) {
            \Log::error($e->getMessage());
            return response()->json(['status' => 400, 'message' => $e->getMessage(), 'data' => []]);
        }
    }


    // public function WildCHarvesterReport(Request $request)
    // {
    //     $validator = Validator::make(
    //         $request->all(),
    //         [
    //             'name_of_wild_harvester' => 'nullable|string',
    //             'no_of_ollectors' => 'nullable|string',
    //             'reg_no' => 'nullable|string',
    //             'authorized_person' => 'nullable|string',
    //             'contact_mobile' => 'nullable',
    //             'contact_email' => 'nullable',
    //             'collection_area' => 'nullable',
    //             'type_of_inspection' => 'nullable',
    //             'permission_letter' => 'nullable',
    //             'documentation_concerning' => 'nullable',
    //             'summary_non_compliances' => 'nullable|array',
    //             'summary_non_compliances.*.npop_clause' => 'required_with:summary_non_compliances|string',
    //             'summary_non_compliances.*.non_compliance' => 'required_with:summary_non_compliances|string',
    //             'summary_non_compliances.*.category' => 'required_with:summary_non_compliances|string',
    //             'additional_remarks' => 'nullable|string',
    //             'inspector_name' => 'nullable|string',
    //             'inspector_date' => 'nullable|date',
    //             //'user_id' => 'required',
    //         ]
    //     );

    //     try {
    //         if ($validator->fails()) {
    //             return response()->json(['status' => 400, 'message' => $validator->errors()->first(), 'data' => []]);
    //         }

    //         // Insert processor report details
    //         $insert_data = [
    //             'name_of_wild_harvester' => $request->name_of_wild_harvester,
    //             'no_of_ollectors' => $request->no_of_ollectors,
    //             'reg_no' => $request->reg_no,
    //             'authorized_person' => $request->authorized_person,
    //             'address' => $request->address,
    //             'contact_mobile' => $request->name_of_inspector,
    //             'contact_email' => $request->date_of_inspection,
    //             'collection_area' => $request->collection_area,
    //             'type_of_inspection' => $request->type_of_inspection,
    //             'permission_letter' => $request->permission_letter,
    //             'documentation_concerning' => $request->documentation_concerning,
    //             'carried_ou' => $request->carried_ou,
    //             'last_year_procurement_details' => $request->last_year_procurement_details,
    //             'details_of_organic_products' => $request->details_of_organic_products,
    //             'pests_insect_management' => $request->pests_insect_management,
    //             'inspector_signature'=> $request->inspector_signature,
    //             'inspector_name'=> $request->inspector_name,
    //             'report_received_date' => $request->report_received_date,
    //             'reviewer_name' => $request->reviewer_name,
    //             'reviewer_signature' => $request->reviewer_signature,
    //             'created_by' => $request->user_id,
    //             'updated_at' => now(),
    //             'at_user_id' => $request->user_id,
    //             'at_external_schedule_id'=> $request->Inspector_id,
    //             'created_at' => now(),
    //             'updeted_by' => $request->user_id,
                
    //         ];

    //         $processorDataId = AtInspectionIndividualProducerReport::insertGetId($insert_data);

           
    //         // if (is_array($request->ref_operator_type_id) && !empty($request->ref_operator_type_id)) {
    //         //     foreach ($request->ref_operator_type_id as $operrator_id) {
    //         //         RefFarmObservations::insert([
    //         //             //'at_inspection_processor_report_id' => $processorDataId,
    //         //             'ref_operator_type_id' => $operrator_id['operator_type_id'],
    //         //             'created_by' => $request->user_id,
    //         //             'created_at' => now(),
    //         //             'updated_by' => now()
    //         //         ]);
    //         //     }
    //         // }

    //         // Insert compliance details
    //         if (is_array($request->summary_non_compliances) && !empty($request->summary_non_compliances)) {
    //             foreach ($request->summary_non_compliances as $compliance) {
    //                 AtComplianceDetails::insert([
    //                     'at_inspection_individual_producer_report_id' => $processorDataId,
    //                     'noncompliance_type' => $compliance['npop_clause'],
    //                     'compliance_previous_condition' => $compliance['non_compliance'],
    //                     //'category' => $compliance['category'],
    //                     'created_by' => $request->user_id,
    //                     'created_at' => now()
    //                 ]);
    //             }
    //         }

    //         return response()->json(['status' => 200, 'message' => "Data Successfully Saved.", 'data' => ['id' => $processorDataId]]);
    //     } catch (Exception $e) {
    //         \Log::error($e->getMessage());
    //         return response()->json(['status' => 400, 'message' => $e->getMessage(), 'data' => []]);
    //     }
    // }




    public function dueInspection(Request $request)
    {
        $x = new \stdClass();
        $validator = Validator::make(
            $request->all(),
            [
                'inspector_id' => 'required',
            ],
            [
                'inspector_id.required' => 'Inspector ID is required.',
            ]
        );

        if ($validator->fails()) {
            return response()->json([
                'errors' => $validator->errors(),
            ], 422);
        }

        $inspector_id = $request->inspector_id;


        $today = now();
        //dd($today);

        $dueInspections = AtExternalSchedule::where('inspector_name', $inspector_id)
            ->where('status', '!=', 1)
            ->whereDate('inspection_date', '>', $today)  // change ">" 
            ->get();

        // dd($dueInspections);
        if ($dueInspections->isEmpty()) {

            return response()->json(['status' => 400, 'message' => "No due inspections found for the given inspector.'", 'DueInspections' => []]);
        }


        $data = [
            'DueInspections' => $dueInspections->map(function ($inspection) {
                return [
                    'id' => $inspection->id ?? '',
                    'UserId' => $inspection->at_user_id ?? '', // UserId == item_id
                    'OperatorTypeId' => $inspection->operator_type_id ?? '',
                    'OperatorType' => $inspection->operator_type ?? '',
                    'OperatorName' => $inspection->operator_name ?? '',
                    'OperatorMobile' => $inspection->operator_mobile ?? '',
                    'OperatorEmail' => $inspection->operator_email ?? '',
                    'OperatorRegistration' => $inspection->reg_no ?? '',
                    'InspectionDate' => $inspection->inspection_date ?? '',
                    'Status' => $inspection->status == 0 ? 'pending' : $inspection->status,
                    'SamplingStatus' => $inspection->sampling_status == 0 ? 'Sample not found' : ($inspection->sampling_status == 1 ? 'Sample found' : 'Unknown'),
                ];
            }),
        ];

        return response()->json($data, 200);
    }

    public function completedInspection(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'inspector_id' => 'required',
            ],
            [
                'inspector_id.required' => 'Inspector ID is required.',
            ]
        );

        if ($validator->fails()) {
            return response()->json([
                'errors' => $validator->errors(),
            ], 422);
        }

        $inspector_id = $request->inspector_id;


        $completedInspections = AtExternalSchedule::where('inspector_name', $inspector_id)
            ->where('status', 1)
            ->get();


        if ($completedInspections->isEmpty()) {
            // return response()->json([
            //     'message' => 'No completed inspections found for the given inspector ID.',
            // ], 404);

            return response()->json(['status' => 400, 'message' => "No completed inspections found for the given inspector.'", 'CompletedInspections' => []]);
        }


        $data = [
            'CompletedInspections' => $completedInspections->map(function ($inspection) {
                return [
                    $today = now(),
                    'id' => $inspection->id ?? '',
                    'user_id' => $inspection->at_user_id ?? '',
                    'OperatorTypeId' => $inspection->operator_type_id ?? '',
                    'OperatorType' => $inspection->operator_type ?? '',
                    'OperatorName' => $inspection->operator_name ?? '',
                    'OperatorMobile' => $inspection->operator_mobile ?? '',
                    'OperatorEmail' => $inspection->operator_email ?? '',
                    'OperatorRegistration' => $inspection->reg_no ?? '',
                    'InspectionDate' => $inspection->inspection_date ?? '',
                    'CompletionDate' => date('d-m-Y', strtotime($today)),
                ];
            }),
        ];

        return response()->json($data, 200);
    }




    public function getTrederProfileDetails($operator_id, $item_id)
    {
        // user details
        $getUserDetails = User::where('ref_operator_type_id', $operator_id)
            ->where('id', $item_id)
            // ->where('status', 2)
            ->first();

        // wherehouse details
        $traders_warehouse_details = GeoTaggingWarehouseDetail::where('at_user_id', $item_id)->get();

        // product details
        $traders_product_details = TradersProductDetail::where('at_user_id', $item_id)->get();



        // dd($traders_warehouse_details);
        // Check if user details exist
        if (!$getUserDetails) {
            return response()->json([
                'status' => 404,
                'message' => 'User not found',
                'data' => new \stdClass(),
            ]);
        }


        if ($getUserDetails->registration_certificate) {
            $certificateUrl = asset('public/' . $getUserDetails->registration_certificate);
        } else {
            $certificateUrl = 'N/A';
        }

        if ($getUserDetails->office_building_photo) {
            $office_building_photo = asset('public/' . $getUserDetails->office_building_photo);
        } else {
            $office_building_photo = 'N/A';
        }

        $gender = 'Other';
        if ($getUserDetails->contact_person_gender == 1) {
            $gender = 'Male';
        } elseif ($getUserDetails->contact_person_gender == 2) {
            $gender = 'Female';
        }

        $addressProof = 'N/A';
        if ($getUserDetails->address_proof_of_office == 'electricity_bill') {
            $addressProof = 'Electricity Bill';
        } elseif ($getUserDetails->address_proof_of_office == 'water_bill') {
            $addressProof = 'Water Bill';
        } elseif ($getUserDetails->address_proof_of_office == 'rent_agreement') {
            $addressProof = 'Rent Agreement';
        }

        if ($getUserDetails->address_proof_of_office_doc) {
            $address_proof_doc = asset('public/' . $getUserDetails->address_proof_of_office_doc);
        } else {
            $address_proof_doc = "N/A";
        }


        $warehouses = [];
        foreach ($traders_warehouse_details as $wr) {
            $warehouses = $wr;
            $warehouses->additional_certificate = $wr->additional_certificate != '' ? asset('public/traders/additional_certificate/' . $wr->additional_certificate) : '';

            $warehouses->image_after_tagging = $wr->image_after_tagging != '' ? asset('public/traders/reflect_farm_image_after_tagging/' . $wr->image_after_tagging) : '';

            $warehouses->license_document = $wr->license_document != '' ? asset('public/traders/license_document/' . $wr->license_document) : '';
        }


        $product_details = [];
        foreach ($traders_product_details as $pd) {
            $product_details = $pd;
            $product_details->product_image = $pd->product_image != '' ? asset('public/traders/product_photo/' . $pd->product_image) : '';
        }



        $data = [
            'company_trader_details' => [
                'trader_name' => user_name($getUserDetails->id) ?? 'N/A',
                'registration_no' => $getUserDetails->registration_no  ?? 'N/A',
                'legal_document_number' => $getUserDetails->legal_document_number ?? 'N/A',
                'registration_certificate' => $certificateUrl  ?? 'N/A',
                'office_building_photo' => $office_building_photo,
            ],
            'trader_address' => [
                'state' => getStateName($getUserDetails->ref_state_id) ?? 'N/A',
                'district' => getDisName($getUserDetails->ref_district_id) ?? 'N/A',
                'taluka_mandal' => getTalukName($getUserDetails->ref_block_tehsil_id) ?? 'N/A',
                'village' => getVillName($getUserDetails->village) ?? 'N/A',
                'pin_code' => $getUserDetails->pin ?? 'N/A',
                'Address' => $getUserDetails->address ?? 'N/A',
            ],
            'contact_person_details' => [
                'first_name' => $getUserDetails->contact_person_first_name ?? 'N/A',
                'middle_name' => $getUserDetails->contact_person_middle_name ?? 'N/A',
                'last_name' => $getUserDetails->contact_person_last_name ?? 'N/A',
                'email_id' => $getUserDetails->email ?? 'N/A',
                'gender' => $gender,
                'address_proof_of_office' => $addressProof,
                'number_of_farmers' => $getUserDetails->no_of_farmers,
                'contact_no' => $getUserDetails->contact_person_mobile_number ?? 'N/A',
                'aadhaar_no' => $getUserDetails->contact_person_aadhar_number ?? 'N/A',
                'contact_designation' => $getUserDetails->contact_designation ?? 'N/A',
                'address_proof_of_office_doc' => $address_proof_doc,
            ],
            'trader_warehouse' => $warehouses,
            'product_details' => $product_details,
        ];

        return response()->json([
            'status' => 200,
            'message' => 'Success',
            'data' => $data,
        ]);
    }



    public function getProcessorProfileDetails($operator_id, $item_id)
    {
        $user = User::with('bankDetails')->where('ref_operator_type_id', $operator_id)->where('id', $item_id)->first();

        $gtDetail = GeoTaggingProcessorDetail::where('at_user_id', $item_id)->get();
        // dd($gtDetail);

        if (!$user) {
            return response()->json([
                'status' => 404,
                'message' => 'User not found',
                'data' => new \stdClass(),
            ]);
        }


        if ($user->registration_certificate) {
            $certificateUrl = asset('public/' . $user->registration_certificate);
        } else {
            $certificateUrl = 'N/A';
        }


        if ($user->processor_photo) {
            $processor_photo = asset('public/processor_photo/' . $user->processor_photo);
        } else {
            $processor_photo = 'N/A';
        }

        $gender = 'Other';
        if ($user->contact_person_gender == 1) {
            $gender = 'Male';
        } elseif ($user->contact_person_gender == 2) {
            $gender = 'Female';
        }

        if ($user->contact_person_photo) {
            $contact_person_photo =  asset('public/contact_person_photo/' . $user->contact_person_photo);
        } else {
            $contact_person_photo = "N/A";
        }


        $Geo_tagging_of_processing_unit = [];
        foreach ($gtDetail as $pd) {
            $Geo_tagging_of_processing_unit = $pd;
            $Geo_tagging_of_processing_unit->license_document = $pd->license_document != '' ? asset('public/processor/license_document/' . $pd->license_document) : '';

            $Geo_tagging_of_processing_unit->additional_certificate = $pd->additional_certificate != '' ? asset('public/processor/additional_certificate/' . $pd->additional_certificate) : '';

            $Geo_tagging_of_processing_unit->image_after_tagging = $pd->image_after_tagging != '' ? asset('public/processor/image_after_tagging/' . $pd->image_after_tagging) : '';

            $Geo_tagging_of_processing_unit->processing_unit_image = $pd->processing_unit_image != '' ? asset('public/processor/processing_unit_image/' . $pd->processing_unit_image) : '';
        }



        $data = [
            'processor_details' => [
                'processor_name' => user_name($user->id) ?? 'N/A',
                'registration_no' => $user->registration_no  ?? 'N/A',
                'legal_document_number' => $user->legal_document_number ?? 'N/A',
                'registration_certificate' => $certificateUrl  ?? 'N/A',
                'registration_date' => date('d-m-Y', strtotime($user->created_at)) ?? 'N/A',
                'photo_of_processing_unit' => $processor_photo,
            ],
            'processor_address' => [
                'state' => getStateName($user->ref_state_id) ?? 'N/A',
                'district' => getDisName($user->ref_district_id) ?? 'N/A',
                'taluka_mandal' => getTalukName($user->ref_block_tehsil_id) ?? 'N/A',
                'village' => getVillName($user->village) ?? 'N/A',
                'pin_code' => $user->pin ?? 'N/A',
                'Address' => $user->address ?? 'N/A',
            ],
            'contact_person_details' => [
                'first_name' => $user->contact_person_first_name ?? 'N/A',
                'middle_name' => $user->contact_person_middle_name ?? 'N/A',
                'last_name' => $user->contact_person_last_name ?? 'N/A',
                'email_id' => $user->email ?? 'N/A',
                'gender' => $gender,
                'contact_person_photo' => $contact_person_photo,
                'adhaar_no' => maskAadhaarNumber($user->contact_person_aadhar_number) ?? 'N/A',
                'pan' => $user->contact_person_pan_number ?? 'N/A',
                'contact_no' => $user->contact_person_mobile_number ?? 'N/A',
                'contact_person_address' => [
                    'state' => getStateName($user->processor_state_id) ?? 'N/A',
                    'district' => getDisName($user->processor_district_id) ?? 'N/A',
                    'taluka_mandal' => getTalukName($user->processor_block_tehsil_id) ?? 'N/A',
                    'village' => getVillName($user->processor_village_id) ?? 'N/A',
                    'pin_code' => $user->processor_pin ?? 'N/A',
                    'address' => $user->processor_address ?? 'N/A',
                ],
                'bank_details_of_processor' => [
                    'bank_name' => isset($user->bankDetails) != NULL ? getRefBankById($user->bankDetails->ref_bank_id) : 'N/A',
                    'account_no' => $user->bankDetails->account_number ?? 'N/A',
                    'ifsc_code' => $user->bankDetails->ifsc_code ?? 'N/A',
                    'branch_name' => $user->bankDetails->branch_name ?? 'N/A',
                    'pin_code' => $user->bankDetails->pincode ?? 'N/A',
                    'bank_address' => $user->bankDetails->bank_address ?? 'N/A',
                ],
            ],
            'geo_tagging_of_processing_unit' =>  $Geo_tagging_of_processing_unit,
        ];

        return response()->json([
            'status' => 200,
            'message' => 'Success',
            'data' => $data,
        ]);
    }



    public function getWildHarvesterProfileDetails($operator_id, $item_id)
    {
        // dd($operator_id);
        $user = User::where('id', $item_id)->where('ref_operator_type_id', $operator_id)->first();

        $wh_details = WildHarvesterDetail::where('at_user_id', $item_id)->first();

        $wh_bankDetail = WildHarvesterBankDetail::where('at_user_id', $item_id)->first();

        $wh_product_details = WildHarvesterForestProductDetail::where('at_user_id', $item_id)->get();
        // dd($user);

        $wh_forest_details = WildHarvesterPermittedForestAreaDetail::where('at_user_id', $item_id)->get();


        if (!$user) {
            return response()->json([
                'status' => 404,
                'message' => 'User not found',
                'data' => new \stdClass(),
            ]);
        }


        $Geo_tagging_of_processing_unit = [];
        foreach ($wh_product_details as $pd) {
            $Geo_tagging_of_processing_unit = $pd;
            $Geo_tagging_of_processing_unit->at_wh_forest_details_id = $pd->at_wh_forest_details_id != '' ? getWildHarvesterName($pd->at_wh_forest_details_id) : '';
        }



        $geo_agging_of_permitted_forest_area = [];
        foreach ($wh_forest_details as $pd) {
            $geo_agging_of_permitted_forest_area = $pd;
            $geo_agging_of_permitted_forest_area->at_wh_forest_details_id = $pd->at_wh_forest_details_id != '' ? getWildHarvesterName($pd->at_wh_forest_details_id) : '';

            $geo_agging_of_permitted_forest_area = $pd;
            $geo_agging_of_permitted_forest_area->image_after_tagging = $pd->image_after_tagging != '' ? $pd->image_after_tagging : '';


            $geo_agging_of_permitted_forest_area->forest_farm_image = $pd->forest_farm_image != '' ? asset('public/research/uploads/' . $pd->forest_farm_image) : '';
        }

        if ($user->registration_certificate) {
            $certificateUrl = asset('public/' . $user->registration_certificate);
        } else {
            $certificateUrl = 'N/A';
        }

        if (!empty($wh_bankDetail->farmer_photo)) {
            $farmer_photo = asset('public/research/uploads/' . $wh_bankDetail->farmer_photo);
        } else {
            $farmer_photo = 'N/A';
        }



        $gender = 'Other';
        if ($user->gender == 1) {
            $gender = 'Male';
        } elseif ($user->gender == 2) {
            $gender = 'Female';
        }

        $data = [
            'wild_harvester_details' => [
                'wild_harvester_name' => user_name($user->id) ?? 'N/A',
                'registration_no' => $user->registration_no  ?? 'N/A',
                'legal_document_number' => $user->legal_document_number ?? 'N/A',
                'registration_certificate' => $certificateUrl  ?? 'N/A',
                'gender' => $gender,
                'father_first_name' => $wh_details->father_first_name ?? 'N/A',
                'father_middle_name' => $wh_details->father_middle_name ?? 'N/A',
                'father_last_name' => $wh_details->father_last_name ?? 'N/A',
            ],
            'wild_harvester_address' => [
                'state' => getStateName($user->ref_state_id) ?? 'N/A',
                'district' => getDisName($user->ref_district_id) ?? 'N/A',
                'taluka_mandal' => getTalukName($user->ref_block_tehsil_id) ?? 'N/A',
                'village' => getVillName($user->ref_village_id) ?? 'N/A',
                'pin_code' => $user->pin ?? 'N/A',
                'address' => $user->address ?? 'N/A',
            ],
            'contact_person_details' => [
                'mobile_no' => $user->contact_person_mobile_number ?? 'N/A',
                'email_id' => $user->contact_person_email ?? 'N/A',
                'adhaar_no' => maskAadhaarNumber($user->contact_person_aadhar_number) ?? 'N/A',
                'no_of_collectors' => $user->no_of_collectors ?? 'N/A',
                'pan_no' => $user->user_name ?? 'N/A',

            ],
            'bank_details' => [
                // 'bank_details' => getRefBankById($wh_bankDetail->ref_bank_id) ?? 'N/A',
                'ifsc_code' => $wh_bankDetail->ifsc_code ?? 'N/A',
                'bank_address' => $wh_bankDetail->bank_address ?? 'N/A',
                'wild_harvester_photo' => !empty($wh_bankDetail->farmer_photo) ? asset('public/research/uploads/' . $wh_bankDetail->farmer_photo) : 'N/A',
                'account_number' => $wh_bankDetail->account_number ?? 'N/A',
                'branch_name' => $wh_bankDetail->branch_name ?? 'N/A',
                'bank_pin_code' => $wh_bankDetail->pincode ?? 'N/A',
            ],

            'forest_details' => [
                'mou_forest_permit' =>  $wh_details->mou_permit_no ?? 'N/A',
                'mou_forest_permit_valid_up_to' => $wh_details->permit_no_valid_upto ?? 'N/A',
                'state' => getStateName($wh_details->ref_state_id) ?? 'N/A',
                'circle' => $wh_details->circle ?? 'N/A',
                'division' => $wh_details->division ?? 'N/A',
                'sub_division' => $wh_details->sub_division ?? 'N/A',
                'range' => $wh_details->range ?? 'N/A',
                'sub_range' => $wh_details->sub_range ?? 'N/A',
                'beat' => $wh_details->beat ?? 'N/A',
                'compartment_no' => $wh_details->compartment_no ?? 'N/A',
                'latitude' => $wh_details->latitude ?? 'N/A',
                'longitude' => $wh_details->longitude ?? 'N/A',
            ],

            'details_of_forest_product' =>  $wh_product_details,
            'geo_tagging_of_permitted_forest_area' => $geo_agging_of_permitted_forest_area,
        ];

        return response()->json([
            'status' => 200,
            'message' => 'Success',
            'data' => $data,
        ]);
    }





    public function getWGrowerGroupProfileDetails($operator_id, $item_id)
    {
        // dd($item_id);
        $user = User::where('id', $item_id)->where('ref_operator_type_id', $operator_id)->first();

        $icsmandator = IcsMandator::where('at_user_id', $item_id)->first();


        if (!$user) {
            return response()->json([
                'status' => 404,
                'message' => 'User not found',
                'data' => new \stdClass(),
            ]);
        }

        if ($user->registration_certificate) {
            $certificateUrl = asset('public/' . $user->registration_certificate);
        } else {
            $certificateUrl = 'N/A';
        }

        if ($user->office_building_photo) {
            $office_building_photo = asset('public/ics/office_building_photo/' . $user->office_building_photo);
        } else {
            $office_building_photo = 'N/A';
        }


        if ($user->address_proof_of_office_doc) {
            $address_proof_of_office_doc = asset('public/ics/address_proof_of_office_doc/' . $user->address_proof_of_office_doc);
        } else {
            $address_proof_of_office_doc = 'N/A';
        }


        $gender = 'Other';
        if ($user->contact_gender == 1) {
            $gender = 'Male';
        } elseif ($user->contact_gender == 2) {
            $gender = 'Female';
        }


        $addressProof = 'N/A';
        if ($user->address_proof_of_office == 'electricity_bill') {
            $addressProof = 'Electricity Bill';
        } elseif ($user->address_proof_of_office == 'water_bill') {
            $addressProof = 'Water Bill';
        } elseif ($user->address_proof_of_office == 'rent_agreement') {
            $addressProof = 'Rent Agreement';
        }

        if (!empty($icsmandator->profile_photo)) {
            $profile_photo = asset('public/ics/profile_photo/' . $icsmandator->profile_photo);
        } else {
            $profile_photo = 'N/A';
        }


        if (!empty($icsmandator->address_proof_of_office_doc)) {
            $address_proof_of_office_doc =  asset('public/ics/address_proof_of_office_doc/' . $icsmandator->address_proof_of_office_doc);
        } else {
            $address_proof_of_office_doc = 'N/A';
        }

        if (!empty($icsmandator->appointment_doc)) {
            $appointment_doc =  asset('public/ics/appointment_doc/' . $icsmandator->appointment_doc);
        } else {
            $appointment_doc = 'N/A';
        }


        $data = [
            'grower_group_details' => [
                'grower_group_name' => user_name($user->id) ?? 'N/A',
                'registration_number' => $user->registration_no ?? 'N/A',
                'registration_certificate' => $certificateUrl,
                'standerd_type' => $user->standerd_type ?? 'N/A',
                'pan_no' => $user->user_name ?? 'N/A',
                'office_building_photo' => $office_building_photo,

            ],
            'grower_group_address' => [
                'State' =>  getStateName($user->ref_state_id) ?? 'N/A',
                'district' => getDisName($user->ref_district_id)  ?? 'N/A',
                'taluka_mandal' =>  getTalukName($user->ref_block_tehsil_id) ?? 'N/A',
                'village' => getVillName($user->ref_village_id) ?? 'N/A',
                'pin_code' => $user->pin ?? 'N/A',
                'address' => $user->address ?? 'N/A',
            ],
            'contact_person_details' => [
                'first_name' => $user->contact_person_first_name ?? 'N/A',
                'middle_name' => $user->contact_person_middle_name ?? 'N/A',
                'last_name' => $user->contact_person_last_name ?? 'N/A',
                'email_id' => $user->email ?? 'N/A',
                'gender' => $gender,
                'address_proof_of_office' => $addressProof,
                'no_of_farmers' => $user->no_of_farmers ?? 'N/A',
                'managed_by' =>  $user->managed_by ?? 'N/A',
                'adhaar_no' => maskAadhaarNumber($user->contact_person_aadhar_number) ?? 'N/A',
                'pan' => $user->contact_person_pan_number ?? 'N/A',
                'contact_no' => $user->contact_person_mobile_number ?? 'N/A',
                'contact_designation' => $user->contact_designation ?? 'N/A',
                'address_proof_of_office_doc' => $address_proof_of_office_doc,
                'no_of_inspector' => $user->no_of_inspector ?? 'N/A',
            ],
            'self_service_provider_details' => [
                'first_name' => $icsmandator->first_name ?? 'N/A',
                'middle_name' =>  $icsmandator->middle_name ?? 'N/A',
                'last_name' => $icsmandator->last_name ?? 'N/A',
                'email_id' => $icsmandator->email_id ?? 'N/A',
                'mobile_no' => $icsmandator->mobile_no ?? 'N/A',
            ],
            'office_address' => [
                'state' => isset($icsmandator->ref_state_id) ? getStateName($icsmandator->ref_state_id) : 'N/A',
                'taluka_mandal' => isset($icsmandator->ref_block_tehsil_id) ? getTalukName($icsmandator->ref_block_tehsil_id) : 'N/A',
                'pin_code' => $icsmandator->pin_code ?? 'N/A',
                'id_proof' => $icsmandator->id_proof ?? 'N/A',
                'photo_of_grower_group_manager' =>  $profile_photo,
                'district' => isset($icsmandator->ref_district_id) ? getDisName($icsmandator->ref_district_id) : 'N/A',
                'village' => isset($icsmandator->ref_village_id) ? getVillName($icsmandator->ref_village_id) : 'N/A',
                'address1' => $icsmandator->address1 ?? 'N/A',
                'address_proof_of_office_doc' => $address_proof_of_office_doc,
                'appointment_doc' => $appointment_doc,



            ],
        ];

        return response()->json([
            'status' => 200,
            'message' => 'Success',
            'data' => $data,
        ]);
    }



    public function GetIndivisualProducerProfileDetails($operator_id, $item_id)
    {
        // dd('hi');
        $user = User::where('id', $item_id)->where('ref_operator_type_id', $operator_id)->first();

        $farmerDetails = IndividualProducerFarmerDetail::where('at_user_id', $item_id)->get();

        if (!$user) {
            return response()->json([
                'status' => 404,
                'message' => 'User not found',
                'data' => new \stdClass(),
            ]);
        }


        if ($user->registration_certificate) {
            $certificateUrl = asset('public/' . $user->registration_certificate);
        } else {
            $certificateUrl = 'N/A';
        }


        $farmer_details = [];
        foreach ($farmerDetails as $pd) {
            $farmer_details = $pd;
            $farmer_details->farmer_first_name = $pd->farmer_first_name != '' ? ($pd->farmer_first_name) : '';

            if ($pd->gender == 1) {
                $farmer_details->gender = 'Male';
            } elseif ($pd->gender == 2) {
                $farmer_details->gender = 'Female';
            } elseif ($pd->gender == 3) {
                $farmer_details->gender = 'Other';
            } else {
                $farmer_details->gender = 'N/A';
            }


            if (!empty($pd->father_husband_flag)) {
                if ($pd->father_husband_flag == 1) {
                    $pd->father_husband_flag = 'Father';
                } elseif ($pd->father_husband_flag == 2) {
                    $pd->father_husband_flag = 'Husband';
                } else {
                    $pd->father_husband_flag = 'N/A';
                }
            } else {
                $pd->father_husband_flag = 'N/A';
            }
        }

        $data = [
            'individual_producer_details' => [
                'individual_producer_name' => user_name($user->id) ?? 'N/A',
                'registration_number' => $user->registration_no ?? 'N/A',
                'registration_certificate' => $certificateUrl,
            ],
            'individual_producer_address' => [
                'State' =>  getStateName($user->ref_state_id) ?? 'N/A',
                'district' => getDisName($user->ref_district_id)  ?? 'N/A',
                'taluka_mandal' =>  getTalukName($user->ref_block_tehsil_id) ?? 'N/A',
                'village' => getVillName($user->ref_village_id) ?? 'N/A',
                'pin_code' => $user->pin ?? 'N/A',
                'address' => $user->address ?? 'N/A',
            ],
            'contact_details_of_individual_producer' => [
                'mobile_no' => $user->mobile_no ?? 'N/A',
                'aadhaar_no' => maskAadhaarNumber($user->contact_person_aadhar_number) ?? 'N/A',
                'pan_no' => $user->user_name ?? 'N/A',
                'email' => $user->email ?? 'N/A',
            ],
           'farmer_details' => (object) $farmer_details,
        ];


        return response()->json([
            'status' => 200,
            'message' => 'Success',
            'data' => $data,
        ]);
    }


    public function DetailsProcessor($item_id)
    {


        $gtDetail = InspectionChecklistProcessor::where('created_by', $item_id)->first();
        //dd($gtDetail);

        if (!$gtDetail) {
            return response()->json([
                'status' => 404,
                'message' => 'Detail not found',
                'data' => new \stdClass(),
            ]);
        }


        if ($gtDetail->sign_processor_img) {
            $processorSign = asset('public/farmers/' . $gtDetail->sign_processor_img);
        } else {
            $processorSign = 'N/A';
        }


        if ($gtDetail->sign_inspector_img) {
            $inspectorSign = asset('public/farmers/' . $gtDetail->sign_inspector_img);
        } else {
            $inspectorSign = 'N/A';
        }



        if ($gtDetail->warehouse_img) {
            $warehouseImg =  asset('public/farmers/' . $gtDetail->warehouse_img);
        } else {
            $warehouseImg = "N/A";
        }


        $data = [
            'Details' => [
                'processor_name' => ($gtDetail->processor_name) ?? 'N/A',
                'registration_no' => $gtDetail->processor_code  ?? 'N/A',
                'address' => $gtDetail->processing_unit_address ?? 'N/A',
                'related_activities_processing_unit' => $gtDetail->related_activities_processing_unit ?? 'N/A',
                'additional_site_address' => $gtDetail->additional_site_address ?? 'N/A',
                'related_activities_additional_site' => $gtDetail->related_activities_additional_site ?? 'N/A',
                'inspection_date' => $gtDetail->inspection_date ?? 'N/A',
                'inspector_name' => $gtDetail->inspector_name ?? 'N/A',
                'inspection_time' => $gtDetail->inspection_time ?? 'N/A',
                'latitude' => $gtDetail->latitude ?? 'N/A',
                'longitude' => $gtDetail->longitude ?? 'N/A',
                'userId' => $gtDetail->created_by ?? 'N/A',
                'remarks' => $gtDetail->remarks ?? 'N/A',
                'stock_capacity' => $gtDetail->stock_capacity ?? 'N/A',
                'stock_availability' => $gtDetail->stock_availability ?? 'N/A',
                'ProcessorSign' => $processorSign  ?? 'N/A',
                'InspectorSign' => $inspectorSign  ?? 'N/A',
                'WarehouseImage' => $warehouseImg  ?? 'N/A',
                //'registration_date' => date('d-m-Y', strtotime($gtDetail->created_at)) ?? 'N/A',

            ],


        ];

        return response()->json([
            'status' => 200,
            'message' => 'Success',
            'data' => $data,
        ]);
    }

    public function DetailsTrader($item_id)
    {


        $gtDetail = InspectionChecklistTrader::where('created_by', $item_id)->first();
        //dd($gtDetail);

        if (!$gtDetail) {
            return response()->json([
                'status' => 404,
                'message' => 'Detail not found',
                'data' => new \stdClass(),
            ]);
        }


        if ($gtDetail->sign_of_trader_img) {
            $traderSign = asset('public/farmers/' . $gtDetail->sign_of_trader_img);
        } else {
            $traderSign = 'N/A';
        }


        if ($gtDetail->sign_of_inspector_img) {
            $inspectorSign = asset('public/farmers/' . $gtDetail->sign_of_inspector_img);
        } else {
            $inspectorSign = 'N/A';
        }



        if ($gtDetail->warehouse_processing_unit_godown_img) {
            $warehouseImg =  asset('public/farmers/' . $gtDetail->warehouse_processing_unit_godown_img);
        } else {
            $warehouseImg = "N/A";
        }


        $data = [
            'Details' => [
                'name' => $gtDetail->trader_name ?? 'N/A',
                'iec_no' => $gtDetail->iec_no ?? 'N/A',
                'operator_address' => $gtDetail->operator_address ?? 'N/A',
                'total_area' => $gtDetail->total_area ?? 'N/A',
                'email_id' => $gtDetail->email_id ?? 'N/A',
                // 'registration_no' => $gtDetail->processor_code  ?? 'N/A',
                // 'address' => $gtDetail->processing_unit_address ?? 'N/A',
                'inspection_date' => $gtDetail->inspection_date ?? 'N/A',
                'inspector_id' => $gtDetail->inspector_id ?? 'N/A',
                'inspector_name' => $gtDetail->inspector_name ?? 'N/A',
                // 'inspection_time' => $gtDetail->inspection_time ?? 'N/A',
                'latitude' => $gtDetail->latitude ?? 'N/A',
                'longitude' => $gtDetail->longitude ?? 'N/A',
                'userId' => $gtDetail->created_by ?? 'N/A',
                'remarks' => $gtDetail->remarks ?? 'N/A',
                'stock_capacity' => $gtDetail->stock_capacity ?? 'N/A',
                'stock_availability' => $gtDetail->stock_availability ?? 'N/A',
                'TraderSign' => $traderSign  ?? 'N/A',
                'InspectorSign' => $inspectorSign  ?? 'N/A',
                'WarehouseImage' => $warehouseImg  ?? 'N/A',
                //'registration_date' => date('d-m-Y', strtotime($gtDetail->created_at)) ?? 'N/A',

            ],


        ];

        return response()->json([
            'status' => 200,
            'message' => 'Success',
            'data' => $data,
        ]);
    }

    public function DetailsWildHarvester($item_id)
    {


        $gtDetail = InspectionChecklistWildCollectionHarvest::where('created_by', $item_id)->first();
        //dd($gtDetail);

        if (!$gtDetail) {
            return response()->json([
                'status' => 404,
                'message' => 'Detail not found',
                'data' => new \stdClass(),
            ]);
        }


        if ($gtDetail->signature_of_wild_collector) {
            $traderSign = asset('public/farmers/' . $gtDetail->signature_of_wild_collector);
        } else {
            $traderSign = 'N/A';
        }


        if ($gtDetail->signature_of_inspector) {
            $inspectorSign = asset('public/farmers/' . $gtDetail->signature_of_inspector);
        } else {
            $inspectorSign = 'N/A';
        }



        if ($gtDetail->warehouse_img) {
            $warehouseImg =  asset('public/farmers/' . $gtDetail->warehouse_img);
        } else {
            $warehouseImg = "N/A";
        }


        $data = [
            'Details' => [
                'name' => $gtDetail->wild_collector_name ?? 'N/A',
                'tracenet_code' => $gtDetail->tracenet_code ?? 'N/A',
                'authorized_person_name' => $gtDetail->authorized_person_name ?? 'N/A',
                'inspection_officer_name' => $gtDetail->inspection_officer_name ?? 'N/A',
                'wild_collector_address' => $gtDetail->wild_collector_address ?? 'N/A',
                'forest_division_description' => $gtDetail->forest_division_description  ?? 'N/A',
                'permission_letter_from_forest_dept' => $gtDetail->permission_letter_from_forest_dept ?? 'N/A',
                'inspection_date' => $gtDetail->signature_date_inspector ?? 'N/A',
                'inspector_id' => $gtDetail->inspector_id ?? 'N/A',
                'inspector_name' => $gtDetail->name_of_inspector ?? 'N/A',
                'inspection_time' => $gtDetail->inspection_time ?? 'N/A',
                // 'latitude' => $gtDetail->latitude ?? 'N/A',
                // 'longitude' => $gtDetail->longitude ?? 'N/A',
                'userId' => $gtDetail->created_by ?? 'N/A',
                'remarks' => $gtDetail->remarks ?? 'N/A',
                'stock_capacity' => $gtDetail->stock_capacity ?? 'N/A',
                'stock_availability' => $gtDetail->stock_availability ?? 'N/A',
                'TraderSign' => $traderSign  ?? 'N/A',
                'InspectorSign' => $inspectorSign  ?? 'N/A',
                'WarehouseImage' => $warehouseImg  ?? 'N/A',
                //'registration_date' => date('d-m-Y', strtotime($gtDetail->created_at)) ?? 'N/A',

            ],


        ];

        return response()->json([
            'status' => 200,
            'message' => 'Success',
            'data' => $data,
        ]);
    }

    public function DetailsIndiProd($item_id)
    {


        $gtDetail = InspectionChecklistIndividualFarmer::where('created_by', $item_id)->first();
        //dd($gtDetail);

        if (!$gtDetail) {
            return response()->json([
                'status' => 404,
                'message' => 'Detail not found',
                'data' => new \stdClass(),
            ]);
        }


        if ($gtDetail->sign_of_farmer_img) {
            $traderSign = asset('public/farmers/' . $gtDetail->sign_of_farmer_img);
        } else {
            $traderSign = 'N/A';
        }


        if ($gtDetail->sign_of_inspector_img) {
            $inspectorSign = asset('public/farmers/' . $gtDetail->sign_of_inspector_img);
        } else {
            $inspectorSign = 'N/A';
        }



        if ($gtDetail->warehouse_img) {
            $warehouseImg =  asset('public/farmers/' . $gtDetail->warehouse_img);
        } else {
            $warehouseImg = "N/A";
        }


        $data = [
            'Details' => [
                'name' => $gtDetail->farmer_name ?? 'N/A',
                'farmer_code' => $gtDetail->farmer_code ?? 'N/A',
                'farmer_address' => $gtDetail->farmer_address ?? 'N/A',
                'total_area_ha' => $gtDetail->total_area_ha ?? 'N/A',
                'land_offered_certification' => $gtDetail->land_offered_certification ?? 'N/A',
                'no_of_farms_plots' => $gtDetail->no_of_farms_plots  ?? 'N/A',
                'last_prohibited_material_date' => $gtDetail->last_prohibited_material_date ?? 'N/A',
                'registration_date_with_ics' => $gtDetail->registration_date_with_ics ?? 'N/A',
                'land_status' => $gtDetail->land_status ?? 'N/A',
                'overall_observation' => $gtDetail->overall_observation ?? 'N/A',
                'total_cultivable_land' => $gtDetail->total_cultivable_land ?? 'N/A',
                'land_offer_for_certification' => $gtDetail->land_offer_for_certification ?? 'N/A',
                'c_one' => $gtDetail->c_one ?? 'N/A',
                'c_two' => $gtDetail->c_two ?? 'N/A',
                'c_three' => $gtDetail->c_three ?? 'N/A',
                'organic' => $gtDetail->organic ?? 'N/A',
                'any_nc_ofc_one' => $gtDetail->any_nc_ofc_one ?? 'N/A',
                'any_nc_ofc_two' => $gtDetail->any_nc_ofc_two ?? 'N/A',
                'inspection_date' => $gtDetail->signature_date_inspector ?? 'N/A',
                'inspector_id' => $gtDetail->inspector_id ?? 'N/A',
                'inspector_name' => $gtDetail->name_of_inspector ?? 'N/A',
                'inspection_time' => $gtDetail->inspection_time ?? 'N/A',
                'latitude' => $gtDetail->latitude ?? 'N/A',
                'longitude' => $gtDetail->longitude ?? 'N/A',
                'userId' => $gtDetail->created_by ?? 'N/A',
                'remarks' => $gtDetail->remarks ?? 'N/A',
                'stock_capacity' => $gtDetail->stock_capacity ?? 'N/A',
                'stock_availability' => $gtDetail->stock_availability ?? 'N/A',
                'TraderSign' => $traderSign  ?? 'N/A',
                'InspectorSign' => $inspectorSign  ?? 'N/A',
                'WarehouseImage' => $warehouseImg  ?? 'N/A',
                //'registration_date' => date('d-m-Y', strtotime($gtDetail->created_at)) ?? 'N/A',

            ],


        ];

        return response()->json([
            'status' => 200,
            'message' => 'Success',
            'data' => $data,
        ]);
    }
}

<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\RefState;
use App\Models\RefDistrict;
use App\Models\RefRegion;
use App\Models\RefVillage;
use App\Models\RefBank;
use App\Models\RefProduct;
use App\Models\ProcessorDocument;
use App\Models\GeoTaggingProcessorDetail;
use App\Models\ProcessorProductDetail;
use App\Models\ProcessorGeoTaggingDetails;
use App\Models\WildHarvesterBankDetail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use DB;
use Exception;
use Illuminate\Support\Facades\Validator;


class ProcessorController extends Controller
{
    public function register(Request $request)
    {
        $validatedData = $request->validate([
            'name' => 'required|max:55',
            'user_name' => 'required|max:55',
            'phone' => 'required|max:10',
		    'email' => 'email|required|unique:users,email',
            'password' => 'required'
        ]);

        $validatedData['password'] = bcrypt($request->password);

        $user = User::create($validatedData);

        $accessToken = $user->createToken('authToken')->accessToken;

        return response([ 'user' => $user, 'access_token' => $accessToken]);
    }

    public function login(Request $request)
    {

        $x = new \stdClass();
        $validator = Validator::make($request->all(), [
            'mobile_no' => 'required',
            'password' => 'required',
            'user_type' => 'required',
            ]);

        if ($validator->fails()) {

            return response()->json(['status'=>400, 'message'=>$validator->errors()->first(), 'data'=> []]);
           // return response()->json($validator->errors());
        } else {


            $userPass = hash('sha256', $request->password);
            $u = $request->mobile_no;
            $user_type = $request->user_type;

            $regData = array();
            $total = 0;
            $attempt = 0;
            $pending = 0;

            $userdetails = User::where(function ($query) use ($u) {
                $query->where('mobile_no',$u);
            })->where('password',$userPass)
            ->where('ref_operator_type_id',$user_type)->first();


            if (empty($userdetails)) {
                return response()->json(['status'=>400, 'message'=>"Invalid Credentials.", 'data'=>  $x ]);
            }else{
                $data = array(
				    'user_id'=>$userdetails->id,
                    'date_of_registration'=>date("Y-m-d", strtotime($userdetails->created_at)),
                    'registration_no' =>$userdetails->registration_no,
                    'name_of_processor'=>$userdetails->first_name,
                    'ref_state_id'=>$userdetails->ref_state_id,
                    'state_name'=>get_state_name($userdetails->ref_state_id),
                    'ref_district_id'=>$userdetails->ref_district_id,
                    'district_name'=>get_district_name_by_id($userdetails->ref_district_id),
                    'ref_block_tehsil_id'=>$userdetails->ref_block_tehsil_id,
                    'block_tehsil_name'=>getBlockTehsilByID($userdetails->ref_block_tehsil_id),
                    'ref_village_id'=>$userdetails->ref_village_id,
                    'village_name'=>get_village_name_by_id($userdetails->ref_village_id),
                    'address'=>$userdetails->address,
                    'pincode'=>$userdetails->pin,
                    'mobile_no'=>$userdetails->mobile_no,

                );

                $accessToken =$userdetails->createToken('authToken')->accessToken;
                return response()->json(['status'=>200, 'message'=>"Login Successfully", 'data'=> $data, 'access_token' => $accessToken]);

            }
        }
    }

    public function ForgetPassword(Request $request){

        $validator = Validator::make($request->all(), [
            "email"=> 'required| email'
        ]);
        if ($validator->fails()) {
            return response()->json(['status'=>400, 'message'=>$validator->errors()->first(), 'data'=> []]);
         } else {
            $data= UserInspector::where('email', $request->email)->first();
            if (!$data) {
                return response()->json(['status'=>400, 'message'=> "Email Id does not match in our records.", 'data'=>""]);
            }
            $email = $request->input('email');
            $pass = 1234567;
            $otp = UserInspector:: where(['email'=> $email])->update(['password'=> hash('sha256', $pass)]); // where condition use for multiple
            return response()->json(['status'=>200, 'message'=>"Code send successfully", 'data'=> $pass]);
        }
    }
    public function ResetPassword(Request $request){
        $validator = Validator::make($request->all(), [
            "email"=> 'required| email',
            "otp"=> 'required| min:4| max:4',
            "password"=> 'required| min:6| max:20',
            "password_confirmation"=> 'required| min:6| max:20| same:password',
        ]);
        if ($validator->fails()) {
            return response()->json(['status'=>400, 'message'=>$validator->errors()->first(), 'data'=> []]);
         } else {
            $getotp = $request->input('otp');
            $password = $request->input('password');
            $password_confirmation = $request->input('password_confirmation');

            //***** Update value in column table
            $resetpass = User::where(['email'=>$request->input('email'),'otp'=>$getotp])->update(['password'=> Hash::make($password)]);
            //***** Update value in column table

            $getupdate = User::where('otp', $getotp)->get();

            //********** If Else
            if($getupdate->count() == 1){
            return response()->json(['status'=>200, 'message'=>"Password Reset successfully", 'data'=> $getupdate]);
            }else{
            return response()->json(['status'=>400, 'message'=>"Otp does not Match", 'data'=> []]);
            }
        }
       //********** If Else


    }


    public function getState(){
        $states = RefState::get();
        if($states){
            return response()->json(['status'=>200, 'message'=>"states data", 'data'=> $states]);
        }else{
            return response()->json(['status'=>400, 'message'=>"states not Found", 'data'=> []]);
        }
    }

    public function getDistrictByState($st){
        $dis = RefDistrict::where('ref_state_id',$st)->get();
        if($dis){
            return response()->json(['status'=>200, 'message'=>"district data", 'data'=> $dis]);
        }else{
            return response()->json(['status'=>400, 'message'=>"district not Found", 'data'=> []]);
        }
    }

    public function getTalukByDistrict($dis){
        $dis = RefRegion::where('ref_district_id',$dis)->get();
        if($dis){
            return response()->json(['status'=>200, 'message'=>"Taluk data", 'data'=> $dis]);
        }else{
            return response()->json(['status'=>400, 'message'=>"Taluk not found", 'data'=> []]);
        }

    }

    public function getvillByTaluk($tal){
        $dis = RefVillage::where('ref_block_tehsil_id',$tal)->get();
        if($dis){
            return response()->json(['status'=>200, 'message'=>"Village data", 'data'=> $dis]);
        }else{
            return response()->json(['status'=>400, 'message'=>"Village not found", 'data'=> []]);
        }

    }

    public function getBanks(){
        $banks = RefBank::get();
        if($banks){
            return response()->json(['status'=>200, 'message'=>"banks data", 'data'=> $banks]);
        }else{
            return response()->json(['status'=>400, 'message'=>"banks not found", 'data'=> []]);
        }

    }

    public function getCategories(){
        $categoties = DB::table('ref_category')->get();
        if($categoties){
            return response()->json(['status'=>200, 'message'=>"Categoties data.", 'data'=> $categoties]);
        }else{
            return response()->json(['status'=>400, 'message'=>"Categoties not found.", 'data'=> []]);
        }

    }
    public function getProduct(Request $request){
        $x = new \stdClass();
        $validator = Validator::make($request->all(),
        [
            'cat_id' => 'required',
        ],
        [
            'cat_id.required'=>'Category id is required.'
        ]
        );
        if (!$validator->fails())
        {
            $products = RefProduct::where('ref_category_id',$request->cat_id)->get();
            if($products){
                return response()->json(['status'=>200, 'message'=>"Hscode Product data.", 'data'=> $products]);
            }else{
                return response()->json(['status'=>400, 'message'=>"Hscode Product not found.", 'data'=> []]);
            }
        } else {

            return response()->json(['status'=>400, 'message'=>$validator->errors()->first(), 'data'=> []]);
        }


    }

    public function saveBanks(Request $request){
        $x = new \stdClass();
        $validator = Validator::make($request->all(),
        [
            'user_id' => 'required',
            'ref_bank_id' => 'required',
            'account_number' => 'required|numeric',
            'ifsc_code' => 'required',
            'branch_name' => 'required',
            'bank_address' => 'required',
            'pincode' => 'required|numeric|digits:6',
        ]
      );

        try{
            if ($validator->fails()) {
                return response()->json(['status'=>400, 'message'=>$validator->errors()->first(), 'data'=> []]);
            } else {


                $newUser = WildHarvesterBankDetail::updateOrCreate([
					'at_user_id'   => $request->user_id,
				], [
					'at_user_id'   => $request->user_id,
					'ref_operator_type_id'   => 6,
					'ref_bank_id' => $request->ref_bank_id,
					'account_number' => $request->account_number,
					'ifsc_code' => $request->ifsc_code,
					'branch_name' => $request->branch_name,
					'bank_address' => $request->bank_address,
					'pincode' => $request->pincode,

				]);
                if($newUser){

                    return response()->json(['status'=>200, 'message'=>"Data Successfully Saved.", 'data'=> $x]);
                }else{
                    return response()->json(['status'=>200, 'message'=>"Data not saved.", 'data'=> $x]);
                }
            }
        } catch (Exception $e) {
            \Log::error($e->getMessage());
            $response =  array(
                'status' => 400,
                'message' => $e->getMessage(),
                'data' => array()
            );
            return response()->json($response);
        }
    }



    public function fileUploads(Request $request)
    {
       // dd('gg');
        $validator = Validator::make($request->all(),
        [
            'file_type' => 'required',
            'docfile' => 'required|mimes:jpeg,jpg,png,pdf,xlx,csv|max:10000'
        ]
      );

        try {
            if ($validator->fails()) {
                return response()->json(['status'=>400, 'message'=>$validator->errors()->first(), 'data'=> []]);
            } else {

                $getImage2 = $request->docfile;
                $imageName2 = time().'.'.$getImage2->extension();
                $imagePath = public_path(). '/processor/';
                if($getImage2->move($imagePath, $imageName2)){
                            $response =  array(
                                'status' => 200,
                                'message' => "File Uploaded",
                                'data' => array($request->file_type,$imageName2)
                            );
                    }else{
                        $response =  array(
                            'status' => 400,
                            'message' => "File Not Uploaded",
                            'data' => array()
                        );
                    }
                return response()->json($response);
            }
        } catch (Exception $e) {
            \Log::error($e->getMessage());
            $response =  array(
                'status' => 400,
                'message' => "Internal Server Error",
                'data' => array()
            );


            return response()->json($response);
        }
    }


    public function processorDash(Request $request){
        $x = new \stdClass();

        $validator = Validator::make($request->all(), [
            "user_id" =>'required',
            ]);
            if (!$validator->fails())
            {

                $insDetTabs = array('processor_detail','bank_detail','unit_detail','product_detail','docs');
                //$data = AtFarmerRegDetail::select('inspection_step')->where('id', $request->farmer_id)->where('at_ics_inspector_id',$request->at_inspector_id)->first();

                $rdata = array();
                foreach($insDetTabs as $key => $val){
                   $rdata[$key]['name'] = $val;

                   if($val=='processor_detail'){
                     $rdata[$key]['status'] = 0;
                   }elseif($val=='bank_detail'){
                     $rdata[$key]['status'] = 0;
                   }elseif($val=='unit_detail'){
                    $rdata[$key]['status'] = 0;
				   }elseif($val=='product_detail'){
                     $rdata[$key]['status'] = 0;
                   }elseif($val=='docs'){
                    $rdata[$key]['status'] =  0;
                   }else{
                    $rdata[$key]['status'] = 0;
                  }

                }

               if($rdata){
                return response()->json(['status'=>200, 'message'=>"Processor Data", 'data'=> $rdata]);
                }else{
                    return response()->json(['status'=>400, 'message'=>"Data not Found", 'data'=> []]);
                }

            } else {
                return response()->json(['status'=>400, 'message'=>$validator->errors()->first(), 'data'=> []]);
            }
    }

    public function processorDetailSave(Request $request){
        $x = new \stdClass();

        $validator = Validator::make($request->all(), [
            'user_id' => 'required',
            'date_of_registration' => 'required',
			'processor_first_name' => 'required',
            'processor_address' => 'required',
            'processor_state_id' => 'required',
            'processor_district_id' => 'required',
            'processor_block_tehsil_id' => 'required',
            'processor_village_id' => 'required',
            'processor_pin' => 'required|numeric|digits:6',
            'mobile_no' => 'required|numeric|digits:10',
            'contact_person_first_name' => 'required',
            'contact_person_gender' => 'required',
            'contact_person_mobile_number' => 'required|numeric|digits:10',
            'contact_person_pan_number' => 'required',
            'contact_person_aadhar_number' => 'required',
            'contact_person_email' => 'required',
            'contact_person_photo' => 'required',
            'ref_state_id' => 'required',
            'ref_district_id' => 'required',
            'ref_block_tehsil_id' => 'required',
            'ref_village_id' => 'required',
            'pin' => 'required|numeric|digits:6',
            'address' => 'required',

		 ]);

            if (!$validator->fails())
            {

                $data=array(
                    "date_of_registration" =>$request->date_of_registration,
                    "first_name" =>$request->processor_first_name,
                    "processor_address" =>$request->processor_address,
                    "processor_state_id" =>$request->processor_state_id,
                    "processor_district_id" =>$request->processor_district_id,
                    "processor_block_tehsil_id" =>$request->processor_block_tehsil_id,
                    "processor_village_id" =>$request->processor_village_id,
                    "processor_pin" =>$request->processor_pin,
                    //"mobile_no" =>$request->mobile_no,
                    "contact_person_first_name" => $request->contact_person_first_name,
                    "contact_person_middle_name" => $request->contact_person_middle_name,
                    "contact_person_last_name" => $request->contact_person_last_name,
                    "contact_person_gender" => $request->contact_person_gender,
                    "contact_person_mobile_number" => $request->contact_person_mobile_number,
                    "contact_person_pan_number" => $request->contact_person_pan_number,
                    "contact_person_aadhar_number" => $request->contact_person_aadhar_number,
                    "contact_person_photo" => $request->contact_person_photo,
                    "contact_person_email" => $request->contact_person_email,
                    "ref_state_id" => $request->ref_state_id,
                    "ref_district_id" => $request->ref_district_id,
                    "ref_block_tehsil_id" => $request->ref_block_tehsil_id,
                    "ref_village_id" => $request->ref_village_id,
                    "pin" => $request->pin,
                    "address" => $request->address
                );

                $saveData = User::where('id', $request->user_id)->update($data);
                if($saveData){

                    return response()->json(['status'=>200, 'message'=>"Data Successfully Saved.", 'data'=> $x]);
                }else{
                    return response()->json(['status'=>200, 'message'=>"Data not saved.", 'data'=> $x]);
                }
            } else {

                return response()->json(['status'=>400, 'message'=>$validator->errors()->first(), 'data'=> []]);
            }
    }

    public function listDocSave(Request $request){
        $x = new \stdClass();

        $validator = Validator::make($request->all(), [
            'user_id' => 'required',
            'aadhar_card' => 'required',
            'pan_card' => 'required',
            'passbook' => 'required',
            'contact_person_sign' => 'required',
            'live_signature' => 'required',

		 ]);

            if (!$validator->fails())
            {

               $data = array(
                    'at_user_id' => $request->user_id,
                    'aadhar_card_image_path' => $request->aadhar_card,
                    'pan_card_image_path' => $request->pan_card,
                    'passbook_image_path' => $request->passbook,
                    'contact_person_sign_image_path' => $request->contact_person_sign,
                    'live_signature_image_path' => $request->live_signature,
                    'created_by' => $request->user_id,
				    'created_at' => date('Y-m-d H:i:s'),

                );

                $saveData = ProcessorDocument::where('at_user_id', $request->user_id)->create($data);
                if($saveData){

                    return response()->json(['status'=>200, 'message'=>"Data Successfully Saved.", 'data'=> $x]);
                }else{
                    return response()->json(['status'=>200, 'message'=>"Data not saved.", 'data'=> $x]);
                }
            } else {

                return response()->json(['status'=>400, 'message'=>$validator->errors()->first(), 'data'=> []]);
            }
    }

    public function unitDetailsave(Request $request){
        try {

                 $x = new \stdClass();
                 $validator = Validator::make($request->all(), [
                    "user_id" => 'required',
                    "unitDetails" =>'required',
                    "unitDetails*.number_of_processing_unit" =>'required|numeric',
                    "unitDetails*.no_of_processing_lines" =>'numeric',
                    "unitDetails*.number_of_product" =>'numeric',
                   // "unitDetails*.processing_unit_id" =>'required',
                    "unitDetails*.processing_unit_name" =>'required',
                    "unitDetails*.fssai_license_number" =>'required',
                    "unitDetails*.license_validity_from" =>'required|date_format:Y-m-d',
                    "unitDetails*.license_validity_to" =>'required|date_format:Y-m-d|after:unitDetails*.license_validity_from',
                    "unitDetails*.total_capacity" =>'required',
                    "unitDetails.*.installed_capacity_under_organic" =>'required',
                    'unitDetails.*.geoDetails' => 'required',
                    'unitDetails.*.geoDetails.*.slatitude' => 'required',
                    'unitDetails.*.geoDetails.*.slongitude' => 'required',
                    'unitDetails.*.productDetails' => 'required',
                    'unitDetails.*.productDetails.*.processing_unit_id' => 'required',
                    'unitDetails.*.productDetails.*.cat_id' => 'required',
                    'unitDetails.*.productDetails.*.ref_hscode_id' => 'required',
                    'unitDetails.*.productDetails.*.product_description' => 'required',
                    'unitDetails.*.productDetails.*.product_processor_name' => 'required',
                    'unitDetails.*.productDetails.*.organic_status' => 'required',
                    'unitDetails.*.productDetails.*.product_image' => 'required',
                    ],
					[
					"unitDetails.*.required" =>'Unit Detail is required.',
                    "unitDetails.*.number_of_processing_unit.required" =>'Number of Processing Unit is required.',
                    "unitDetails.*.number_of_processing_unit.numeric" =>'Number of Processing Unit should be numeric.',
                    "unitDetails.*.no_of_processing_lines.numeric" =>'No. of Processing Lines should be numeric.',
                    //"unitDetails.*.processing_unit_id.required" =>'Processing Unit ID is required.',
                    "unitDetails.*.processing_unit_name.required" =>'Name of the Processing Units is required.',
                    "unitDetails.*.fssai_license_number.required" =>'License Number is required.',
                    "unitDetails.*.license_validity_from.required" =>'License Validity From is required.',
                    "unitDetails.*.license_validity_from.date_format" =>'License Validity From format does not match the format Y-m-d.',
                    "unitDetails.*.license_validity_to.required" =>'License Validity To is required.',
                    "unitDetails.*.license_validity_to.date_format" =>'License Validity To format does not match the format Y-m-d.',
                    "unitDetails.*.license_validity_to.after" =>'License Validity To must be a date after to License Validity From.',
                    "unitDetails.*.total_capacity.required" =>'Total Capacity of Processing Unit is required.',
                    "unitDetails.*.installed_capacity_under_organic.required" =>'Installed Capacity Under Organic Processing is required.',
                    'unitDetails.*.geoDetails' => "Geo Details is required.",
                    "unitDetails.*.geoDetails.*.slatitude" =>'Latitude is required.',
                    "unitDetails.*.geoDetails.*.slongitude" =>'Longitude is required.',
                    'unitDetails.*.productDetails' => "Product Details is required.",
                    'unitDetails.*.productDetails.*.processing_unit_id.required' => 'Product Processing Unit ID is required.',
                    'unitDetails.*.productDetails.*.cat_id.required' => 'Category is required.',
                    'unitDetails.*.productDetails.*.ref_hscode_id.required' => 'HS Code of the Product is required.',
                    'unitDetails.*.productDetails.*.product_description.required' => 'Product Description is required.',
                    'unitDetails.*.productDetails.*.product_processor_name.required' => 'Name of Processor is required.',
                    'unitDetails.*.productDetails.*.organic_status.required' => 'Organic Status is required.',
                    'unitDetails.*.productDetails.*.product_image.required' => 'Product Image is required.',

					]
					);
                    if (!$validator->fails())
                    {
                        //dd($request->all());

                        if(!empty($request->unitDetails)){
                            foreach($request->unitDetails as $units){

                                $unit=array(
                                    "at_user_id" => $request->user_id,
                                    "number_of_processing_unit"=>$units['number_of_processing_unit']??'0',
                                    "processing_unit_id"=>$units['processing_unit_id']??'0',
                                    "processing_units_name"=>$units['processing_units_name']??'',
                                    "fssai_license_number"=>$units['fssai_license_number']??'',
                                    "license_validity_from"=>$units['license_validity_from']??'',
                                    "license_validity_to"=>$units['license_validity_to']??'',
                                    "no_of_processing_lines"=>$units['no_of_processing_lines']??'',
                                    "address"=>$units['address']??'',
                                    "agreement_status"=>$units['agreement_status']??'',
                                    "number_of_product"=>$units['number_of_product']??'',
                                    "geo_tagging_processing_unit"=>$units['geo_tagging_processing_unit']??'',
                                    "total_capacity"=>$units['total_capacity']??'',
                                    "installed_capacity_under_organic"=>$units['installed_capacity_under_organic']??'',
                                    "license_document" => $units['license_document'],
                                    "additional_certificate" => $units['additional_certificate'],
                                    "reflect_farm" => $units['reflect_farm'],
                                    "image_after_tagging" => $units['image_after_tagging'],
                                    "daily_processing_capacity" => $units['daily_processing_capacity'],
                                    "processing_type" => $units['processing_type'],
                                    "processing_unit_image" => $units['processing_unit_image']

                                );
                                //dd($unit);
                                $unitsdet = GeoTaggingProcessorDetail::create($unit);

                                if(!empty($units['geoDetails'])){
                                    foreach($units['geoDetails'] as $geos){
                                        $geo=array(
                                            "at_pro_processing_unit_id"=>$unitsdet->id,
                                            "latitude"=>$geos['slatitude'],
                                            "longitude"=>$geos['slongitude'],
                                            "created_at" => date('Y-m-d H:i:s'),
                                            "created_by" => $request->user_id,
                                           );
                                        $geos = ProcessorGeoTaggingDetails::create($geo);
                                    }
                                }

                                if(!empty($units['productDetails'])){
                                    // mStandingCrop details
                                    foreach($units['productDetails'] as $unitpro){
                                    $data=array(
                                        'at_user_id' => $request->user_id,
                                        'processing_unit_id' => $unitpro['processing_unit_id'],
                                        'ref_category_id' => $unitpro['cat_id'],
                                        'ref_hscode_id' => $unitpro['ref_hscode_id'],
                                        'product_description' => $unitpro['product_description'],
                                        'ref_product_id' => $unitsdet->id,
                                        'product_processor_name' => $unitpro['product_processor_name'],
                                        'organic_status' => $unitpro['organic_status'],
                                        "created_at" => date('Y-m-d H:i:s'),
                                        "created_by" => $request->user_id,
                                        'product_image' => $unitpro['product_image']
                                    );
                                   // dd($data);
                                    $unitdata = ProcessorProductDetail::create($data);

                                    }
                                }
                            }
                            return response()->json(['status'=>200, 'message'=>"Data Successfully Saved.", 'data'=> $x]);
                        }else{
                            return response()->json(['status'=>200, 'message'=>"Data not saved.", 'data'=> $x]);
                        }
                    }else{

                        return response()->json(['status'=>400, 'message'=>$validator->errors()->first(), 'data'=> []]);
                        //return $validator->errors();
                    }
                      //********** If Else

            } catch (\Illuminate\Database\QueryException $e) {
                \Log::error($e->getMessage());
                $response =  array(
                    'status' => 400,
                    'message' => "Internal Server Error",
                    'data' =>$e->getMessage()
                );
                return response()->json($response);
            }

    }




}

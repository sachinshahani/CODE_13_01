<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;


class OtpController extends Controller
{
    public function sendOtp(Request $request)
    {
        $request->validate([
            'mobile_number' => 'required|string',
        ]);

        $mobileNumber = $request->input('mobile_number');
        $otp = rand(1000, 9999);

        $response = sendOtp($mobileNumber, $otp);

        dd( $response);

        return response()->json($response);
    }
}

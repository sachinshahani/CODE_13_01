<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use GuzzleHttp\Client;
use App\Models\PanVerification;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Contracts\Encryption\DecryptException;
use Illuminate\Support\Facades\Auth;

use App\Http\Controllers\Controller;

use Carbon\Carbon;
use Exception;




class PanVerificationController extends Controller
{
    protected $apiEndpoint = 'https://vtf.apeda.in/EmailNIC/panTest.aspx';

    public function validatePanApiV1(Request $request)
    {
        //try {

            $encryptedData = $request->input('data');
            $decodedData =  json_decode(base64_decode($encryptedData), true);  //print_r($decodedData); die;

            $pan = $decodedData['pan'] ?? null;
            $name = $decodedData['name'] ?? null;

            $fName = $decodedData['fatherName'] ?? null; //print_r($fName); die;
            $dob = $decodedData['dob'] ?? null;
            $type = $decodedData['type'] ?? null;
            $userId = $decodedData['user'] ?? null; 
            $registrationId = $decodedData['registrationId'] ?? null; //print_r($registrationId); die;
            $registrationForm = $decodedData['registrationForm'] ?? null; //print_r($registrationId); die;
            $legalEntityType = $decodedData['legalEntityType'] ?? null; //print_r($legalEntityType); die;
            $doctype = $decodedData['doctype'] ?? null; //print_r($legalEntityType); die;
            //$panVerifyResponse = $decodedData['panVerifyResponse'] ?? null; //print_r($registrationId); die;

            $atUserId = $decodedData['atUserId'] ?? null; //print_r($legalEntityType); die;

            if ($type === 'IN' && (!$pan || !$name || !$dob || !$fName)) {
                return response()->json(['error' => 'Required fields missing for Individual Account.'], 400);
            } elseif ($type === 'OG' && (!$pan || !$name || !$dob)) {
                return response()->json(['error' => 'Required fields missing for Organization Account.'], 400);
            } elseif (!in_array($type, ['IN', 'OG'])) {
                return response()->json(['error' => 'Invalid account type'], 400);
            }

       

            $formattedDob = \Carbon\Carbon::parse($dob)->format('d/m/Y'); 


            $queryParams = [
                'pan' => $pan,
                'name' => $this->formatAndTrimName($name),
                'fName' => $this->formatAndTrimName($fName),
                'dob' => $formattedDob
            ]; 
           
            $response = Http::get($this->apiEndpoint, $queryParams);

            $result = json_decode($response->body(), true);             
            if (json_last_error() !== JSON_ERROR_NONE) {
                return response()->json(['error' => 'Invalid JSON response from API'], 500);
            }

            // Prepare response
            $outputData = $result[0];
            //print_r($outputData); die;
            $formattedOutputData = [
                'pan' => $outputData['pan'],
                'pan_status' => $outputData['pan_status'],
                'pan_status_message' => $this->getStatusMessage($outputData['pan_status']),
                'name' => $outputData['name'],
                'name_message' => $this->getNameMessage($outputData['name']),
                'fathername' => $outputData['fathername'] ?? '',
                'fathername_message' =>  $this->getfNameMessage($outputData['fathername']),
                'dob' => $outputData['dob'],
                'dob_message' => $this->getDobMessage($outputData['dob']),
                'seeding_status' => $outputData['seeding_status'],
                'seeding_message' => $this->getseedingMessage($outputData['seeding_status']),
                // Additional fields as needed
            ];

            $responseCode = '1'; // Assume success as default
            $responseMessage = $this->getResponseMessage($responseCode);
            $match_response = $outputData['seeding_status'] === $doctype && $outputData['name'] === 'Y' && $outputData['dob'] === 'Y' && $outputData['pan_status'] === 'E' ? 'S' : 'F';

             // Store verification in the database
             PanVerification::create([
                'user_request_id' => $userId,
                'response' => $response->body(),
                'response_code' => '1',
                'registrationId' => $registrationId,
                'dct_category' => $type,
                'pan_number' => $pan,
                'pan_status' => $outputData['pan_status'] ?? null,
                'user_name' => $this->formatAndTrimName($name),
                'name_status' => $outputData['name'] ?? null,
                'user_dob' => $dob,
                'dob_status' => $outputData['dob'] ?? null,
                'user_father_name' => $this->formatAndTrimName($fName),
                'fname_status' => $outputData['fathername'] ?? null,
                'pan_status_message' => $this->getStatusMessage($outputData['pan_status']),
                'name_status_message' => $this->getNameMessage($outputData['name']),
                'dob_status_message'=> $this->getDobMessage($outputData['dob']),
                'fname_status_message'=> null,
                'registration_form'=> $registrationForm,
                'legal_entity_type' => $this->formatAndTrimName($legalEntityType),
                'match_response' => $match_response,
                'created_by' => $userId,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'updated_by' => $userId,
                'at_user_id' => $atUserId,
            ]);

           // Prepare the data array to be encrypted
            $responseData = [
                'response_Code' => $responseCode,
                'response_Message' => $responseMessage,
                'outputData' => $formattedOutputData,
                'message' => 'PAN verification completed successfully'
            ];

            // Base64 encode the response data
            $encryptedResponse = base64_encode(json_encode($responseData));

            return response()->json(['data' => $encryptedResponse]);

        // } catch (\Exception $e) {
        //     Log::error('API Request Exception:', ['message' => $e->getMessage()]);
        //     return response()->json(['error' => 'An error occurred while processing the API request'], 500);
        // }
    }


    private function formatAndTrimName($name)
    {
        $trimmedName = rtrim($name);
        $trimmedName = preg_replace('/\s+$/', '', $trimmedName); 
        $formattedName = strtoupper($trimmedName); 
        $formattedName = str_replace(' ', ' ', $formattedName);
        return $formattedName; 
    }

    private function getStatusMessage($status)
    {
        $messages = [
            'E' => 'Existing and Valid',
            'F' => 'Marked as Fake',
            'X' => 'Marked as Deactivated',
            'D' => 'Deleted',
            'N' => 'Record (PAN) Not Found in ITD Database/Invalid PAN',
            'EA' => 'Existing and Valid but event marked as Amalgamation in ITD database',
            'EC' => 'Existing and Valid but event marked as Acquisition in ITD database',
            'ED' => 'Existing and Valid but event marked as Death in ITD database',
            'EI' => 'Existing and Valid but event marked as Dissolution in ITD database',
            'EL' => 'Existing and Valid but event marked as Liquidated in ITD database',
            'EM' => 'Existing and Valid but event marked as Merger in ITD database',
            'EP' => 'Existing and Valid but event marked as Partition in ITD database',
            'ES' => 'Existing and Valid but event marked as Split in ITD database',
            'EU' => 'Existing and Valid but event marked as Under Liquidation in ITD database'
        ];
        return $messages[$status] ?? 'Unknown Status';
    }

    private function getNameMessage($nameStatus)
    {
        $nameMessages = [
            'Y' => 'Match',
            'N' => 'Not Match',
            // 'Y' => 'YES (the name is a match)',
            // 'N' => 'NO (the name does not match)',
        ];
        return $nameMessages[$nameStatus] ?? 'Unknown Status';
    }
    private function getfNameMessage($fNameStatus)
    {
        $nameMessages = [
            'Y' => 'Match',
            'N' => 'Not Match',
            // 'Y' => 'YES (the father\'s name is a match)',
            // 'N' => 'NO (the father\'s name does not match)',
        ];
        return $nameMessages[$fNameStatus] ?? 'Unknown Status';
    }
    private function getDobMessage($nameStatus)
    {
        $nameMessages = [
            'Y' => 'Match',
            'N' => 'Not Match',
            // 'Y' => 'YES (the DOB/DOI is a match)',
            // 'N' => 'NO (the DOB/DOI does not match)',
        ];
        return $nameMessages[$nameStatus] ?? 'Unknown Status';
    }

    private function getResponseMessage($code)
    {
        $responseCodeMessage = [
            "1"  => "Success",
            "2"  => "System Error",
            "3"  => "Authentication Failure",
            // Add other response codes here
        ];
        return $responseCodeMessage[$code] ?? 'Unknown response code';
    }

    private function getseedingMessage($code)
    {
        $responseCodeMessage = [
            "Y"  => "",
            "R"  => "Inoperative PAN ",
            "NA"  => "non-Individual PANs",
            // Add other response codes here
        ];
        return $responseCodeMessage[$code] ?? 'Unknown response code';
    }

}

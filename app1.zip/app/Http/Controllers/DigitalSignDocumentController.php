<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Response;

class DigitalSignDocumentController extends Controller
{
     /**
     * Generate Base64 string for a PDF file.
     *
     * @param  Request  $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function generateBase64(Request $request)
    {
        // Validate request input
        $request->validate([
            'file_name' => 'required|string',
            'path' => 'required|string',
            'storage_type' => 'required|string'
        ]);

        $fileName = $request->input('file_name');
        $filePath = '';

        // Determine the correct file path based on where the file is stored
        if ($request->input('storage_type') === 'public') {
            // Remove any extra `public/` from the path to avoid duplication
            $cleanedPath = str_replace('public/', '', $request->input('path'));
            $filePath = public_path($cleanedPath . '/' . $fileName);
        } elseif ($request->input('storage_type') === 'storage') {
            // If file is stored in storage/app directory
            $filePath = storage_path('app/' . $request->input('path') . '/' . $fileName);
        } else {
            return response()->json(['error' => 'Invalid file storage location.'], 400);
        }
        // Check if the file exists at the resolved path
        if (file_exists($filePath)) {
            // Read the file and convert it to Base64
            $fileContent = file_get_contents($filePath);
            $base64String = base64_encode($fileContent);

            return response()->json(['base64' => $base64String]);
        } else {
            return response()->json(['error' => 'File not found.'], 404);
        }
    }


}

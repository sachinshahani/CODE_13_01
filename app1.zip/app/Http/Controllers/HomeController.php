<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Models\UserInspector;
use App\Models\User;
use Carbon\Carbon;
use App\Models\RefRegion;
use App\Models\RefDistrict;
use App\Models\CBStatewiseRestriction;
use App\Models\RefVillage;
use App\Models\UserVerification;
use RealRashid\SweetAlert\Facades\Alert;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Crypt;
use App\Models\AtUserLoginDetails;
use App\Models\AtUserRegistrationDetails;



class HomeController extends Controller
{
    public function home()
    {
        return view('welcome');
    }


    public function getLocations()
    {
        $locations = \App\Models\MisPhysicalProgressCaptureActivityFields::join('ref_fields', 'ref_fields.id', '=', 'mis_physical_progress_capture_activity_fields.ref_fields_id')->where(function ($query) {
            $query->where('ref_fields.name', 'X')->orWhere('ref_fields.name', 'Y');
        })->select('mis_physical_progress_capture_activity_fields.ref_fields_id', 'mis_physical_progress_capture_activity_fields.field_value')->get();

        $locs = array();
        $i = 0;
        $loopindex_increment =  false;
        foreach ($locations as $l) {
            if ($l->ref_fields_id == 5) {
                $locs[$i]['lat'] = $l->field_value;
            } elseif ($l->ref_fields_id == 6) {
                $locs[$i]['long'] = $l->field_value;
                $loopindex_increment = true;
            }
            if ($loopindex_increment == true) {
                $i++;
                $loopindex_increment = false;
            }
        }

        return json_encode($locs);
    }

    public function showResetPasswordForm(Request $request)
    {
        $updatePassword = DB::table('password_resets')
            ->where([
                'token' => $request->token
            ])
            ->first();
        return view('admin.ics.forgetpassword', compact('updatePassword'));
    }

    public function submitRePassInsp(Request $request)
    {
        //dd($request->all());
        $request->validate([
            'passwords' => 'required|min:6',
            'confirm_password' => 'required|min:6|same:passwords',
        ]);
        try {
            //dd($request->all());

            if ($request->passwords != '') {
                $pass = hash('sha256', $request->passwords);
                $user = UserInspector::where('email', $request->email)->update(["password" => $pass]);
                return redirect()->back()->with('success', __('message.changed_success'));
            } else {
                dd('in esle');
                return redirect()->back()->with('error', __('message.not_match'));
            }
        } catch (Exception $e) {
            Log::error($e);

            return redirect()->back()->with('error', 'Invalid Credentials.');
        }
    }

    public function OrganicOperator(Request $request)
    {

        return view('admin.organic_operator');
    }
    public function Conditions(Request $request)
    {

        return view('admin.conditions');
    }
    public function ConditionsHindi(Request $request)
    {

        return view('admin.conditions_hindi');
    }


    public function OrganicOperatorPost(Request $request)
    {
        // dd($request->all());
        // DB::beginTransaction();
        $this->validate(
            $request,
            [
                'captcha' => 'required|captcha',
                'first_name' => 'required',
                'user_name' => 'required',
                'cb_type' => 'required',
                'pin' => 'required',
                'address' => 'required|string|max:255',
                'contact_person_first_name' => 'required|string|max:255',
                'contact_person_last_name' => 'required|string|max:255',
                'contact_person_gender' => 'required',
                'contact_person_email' => 'required',
                'contact_person_mobile_number' => 'required',
                'contact_person_aadhar_number' => 'required',
                'dob_doi_date' => 'required',
                'operator_type_id' => 'required',
                'entity_firm' => 'required|string',
                'father_name' => 'required_if:entity_firm,Propietor|string|max:255',
            ],
            [
                'captcha.captcha' => 'Invalid captcha code.',
                'first_name.required' => 'Enter Operator Name.',
                'user_name.required' => 'Enter PAN Detail.',
                'pin.required' => 'Enter PAN Detail.',
                'cb_type.required' => 'Choose Certification Bodies',
                'address.required' => 'address Feild is required',
                'contact_person_first_name.required' => 'Contact Person first Name is required',
                'contact_person_last_name.required' => 'Contact Person last Name is required',
                'contact_person_gender.required' => 'Contact Person gender is required',
                'contact_person_email.required' => 'Contact Person email is required',
                'contact_person_mobile_number.required' => 'Contact Person mobile No. is required',
                'contact_person_aadhar_number.required' => 'Contact Person aadhar No. is required',
                'dob_doi_date' => 'Date of Incorporation required',
                'operator_type_id' => 'Operator Type is required',
                'entity_firm' => 'Legal Entity Type is required',
                'father_name.required_if' => 'The Father Name field is required when the entity firm is Propietor.',
            ]
        );

        try {

            $Checker = User::where('ref_operator_type_id', $request->operator_type_id)->where('user_name', $request->user_name)->first();
            if ($Checker) {
                session()->flash('error', 'PAN card already taken..! Please Enter New PAN Card');
                return redirect()->back();
            }

            $aadharno = Crypt::encrypt(base64_decode(urldecode($request->contact_person_aadhar_number)));
            $ref = rand(1000, 9999) . date('Ymd');
            $password = 123456;
            $data = [

                'contact_person_pan_number' => 'OPR-' . $ref, // for save ref no using contact_person_pan_number column
                'ref_operator_type_id' => !empty($request->operator_type_id) ? $request->operator_type_id : NULL,
                'created_by' => !empty($request->cb_type) ? $request->cb_type : NULL,
                'first_name' => !empty($request->first_name) ? $request->first_name : NULL,
                'user_name' => !empty($request->user_name) ? $request->user_name : NULL,
                'document_type' => !empty($request->document_type) ? $request->document_type : NULL,
                'password' => hash('sha256', $password),
                'address' => !empty($request->address) ? $request->address : NULL,
                'pin' => !empty($request->pin) ? $request->pin : NULL,
                'contact_person_first_name' => !empty($request->contact_person_first_name) ? $request->contact_person_first_name : NULL,
                'contact_person_middle_name' => !empty($request->contact_person_middle_name) ? $request->contact_person_middle_name : NULL,
                'contact_person_last_name' => !empty($request->contact_person_last_name) ? $request->contact_person_last_name : NULL,
                'contact_person_gender' => !empty($request->contact_person_gender) ? $request->contact_person_gender : NULL,
                'contact_person_email' => !empty($request->contact_person_email) ? $request->contact_person_email : NULL,
                'ref_state_id' => !empty($request->state) ? $request->state : NULL,
                'ref_district_id' => !empty($request->district) ? $request->district : NULL,
                'ref_block_tehsil_id' => !empty($request->taluka) ? $request->taluka : NULL,
                'ref_village_id' => !empty($request->village) ? $request->village : NULL,
                'email' => !empty($request->contact_person_email) ? $request->contact_person_email : NULL,
                'contact_person_mobile_number' => !empty($request->contact_person_mobile_number) ? $request->contact_person_mobile_number : NULL,
                'mobile_no' => !empty($request->contact_person_mobile_number) ? $request->contact_person_mobile_number : NULL,
                'contact_person_aadhar_number' => $aadharno,
                'contact_designation' => !empty($request->contact_designation) ? $request->contact_designation : NULL,
                'user_type' => 1,
                'status' => 0,
                'at_expire' => Carbon::now()->addDays(180),
                'standerd_type' => !empty($request->standerd_type) ? $request->standerd_type : NULL,
                'dob_doi_date' =>  !empty($request->dob_doi_date) ? $request->dob_doi_date : NULL,
                'entity_firm' =>  !empty($request->entity_firm) ? $request->entity_firm : NULL,
                'father_name' =>  !empty($request->father_name) ? $request->father_name : NULL,
            ];

            // dd($request->all(), $data);
            $results =  User::create($data);
            // if($results){
            //       DB::commit();
            //       sendLoginDetailsSms($results->contact_person_mobile_number, $results->contact_person_first_name, $results->user_name);
            // }
            
            $atUserLoginDetailsData = [
                'at_user_id' => !empty($results->id) ? $results->id : NULL,
                'ref_operator_type_id' => !empty($request->operator_type_id) ? $request->operator_type_id : NULL,
                'user_name' => !empty($request->user_name) ?  $request->user_name : NULL,
                'password' => hash('sha256', $password),
                'user_type' => 1,
                'status' => 0,
                'created_by' => !empty($request->cb_type) ? $request->cb_type : NULL,
            ];
            $atuserLloginDetails_id = AtUserLoginDetails::create($atUserLoginDetailsData);

            $atUserRegistrationDetailsData = [
                'at_user_id' => !empty($results->id) ? $results->id : NULL,
                'at_user_login_details_id' => !empty($atuserLloginDetails_id->id) ? $atuserLloginDetails_id->id : NULL,
                'ref_operator_type_id' => !empty($request->operator_type_id) ? $request->operator_type_id : NULL,
                'first_name' => !empty($request->first_name) ? $request->first_name : NULL,
                'mobile_no' => !empty($request->contact_person_mobile_number) ? $request->contact_person_mobile_number : NULL,
                'email' => !empty($request->contact_person_email) ? $request->contact_person_email : NULL,
                'address' => !empty($request->address) ? $request->address : NULL,
                'ref_block_tehsil_id' => !empty($request->taluka) ? $request->taluka : NULL,
                'ref_district_id' => !empty($request->district) ? $request->district : NULL,
                'ref_state_id' => !empty($request->state) ? $request->state : NULL,
                'pin' => !empty($request->pin) ? $request->pin : NULL,
                'ref_village_id' => !empty($request->village) ? $request->village : NULL,
                // 'no_of_farmers' => !empty($request->contact_person_first_name) ? $request->contact_person_first_name : NULL,
                'contact_person_first_name' => !empty($request->contact_person_first_name) ? $request->contact_person_first_name : NULL,
                'contact_person_middle_name' => !empty($request->contact_person_middle_name) ? $request->contact_person_middle_name : NULL,
                'contact_person_last_name' => !empty($request->contact_person_last_name) ? $request->contact_person_last_name : NULL,
                'contact_person_mobile_number' => !empty($request->contact_person_mobile_number) ? $request->contact_person_mobile_number : NULL,
                'contact_person_gender' => !empty($request->contact_person_gender) ?: NULL,
                // 'contact_person_pan_number' => !empty($ref) ?  $ref : NULL,
                'online_req_no' => !empty('OPR-' . $ref) ?  'OPR-' . $ref : NULL,
                'contact_person_aadhar_number' => !empty($aadharno) ? $aadharno : NULL,
                'contact_person_email' => !empty($request->contact_person_email) ?: NULL,
                'standerd_type' => !empty($request->standerd_type) ? $request->standerd_type : NULL,
                'contact_designation' => !empty($request->contact_designation) ? $request->contact_designations : NULL,
                'aadhar_number' => !empty($aadharno) ? $aadharno : NULL,
                'entity_firm' => !empty($request->entity_firm) ? $request->entity_firm : NULL,
                'at_expire' => !empty(Carbon::now()->addDays(180)) ? Carbon::now()->addDays(180) : NULL,
                'dob_doi_date' => !empty($request->dob_doi_date) ? $request->dob_doi_date : NULL,
                'created_by' => !empty($request->cb_type) ? $request->cb_type : NULL,
            ];

            AtUserRegistrationDetails::create($atUserRegistrationDetailsData);

            Alert::success('Success', 'Your application has been submitted to your CB for approval.')->flash();
            return redirect()->route('home');
        } catch (Exception $e) {
            DB::rollback();
            Alert::error('Error', $e->getMessage());
            \Log::error($e->getMessage());
            abort(404);
        } catch (\Illuminate\Database\QueryException $exception) {
            DB::rollback();
            Alert::error('Error', $exception->getMessage());
            \Log::error($exception->getMessage());
            Alert::error('error', "Query Exception");
            return redirect()->back()->with('loader', true);
        }
    }


    public function AccreditationPage(Request $request)
    {

        return view('admin.acreditation_index');
    }


    public function getStateIDDistrict(Request $request)
    {


        $city = $request->state_id;

        $data = RefDistrict::where("ref_state_id", $request->state_id)
            ->orderBy('district_name')->get();
        $selected = '';

        $option = '<option value="">-Select District-</option>';
        if (count($data) > 0) {
            foreach ($data as $key => $value) {
                if ($city == $value->id) {
                    $selected = 'selected';

                    $option .= '<option value="' . $value->id . '"  selected="' . $selected . '">' . $value->district_name . '</option>';
                } else {
                    $option .= '<option value="' . $value->id . '">' . $value->district_name . '</option>';
                }
            }
        } else {

            $option .= '<option value="">No record found.</option>';
        }
        return response()->json($option);
    }


    public function getDistBlockTehsil(Request $request)
    {
        $city = $request->id;
        $data = RefRegion::where("ref_district_id", $request->district_id)
            ->orderBy('block_tehsil_name')->get();
        $selected = '';

        $option = '<option value="">-Select Taluka/Mandal-</option>';
        if (count($data) > 0) {
            foreach ($data as $key => $value) {
                $option .= '<option value="' . $value->id . '">' . $value->block_tehsil_name . '</option>';
            }
        } else {

            $option .= '<option value="">No record found.</option>';
        }
        return response()->json($option);
    }


    public function getBlockTehsilVillage(Request $request)
    {


        $data = RefVillage::where("ref_block_tehsil_id", $request->block_tehsil_id)
            ->orderBy('village_name')->get();

        $option = '<option value="">-Select Village-</option>';
        if (count($data) > 0) {
            foreach ($data as $key => $value) {
                $option .= '<option value="' . $value->id . '">' . $value->village_name . '</option>';
            }
        } else {
            $option .= '<option value="">No record found.</option>';
        }
        return response()->json($option);
    }


    public function getCBID(Request $request)
    {



        $data = CBStatewiseRestriction::leftjoin('ref_state', 'ref_state.id', 'cb_statewise_restriction.ref_state_id')
            ->select('ref_state.id as refStateId', 'ref_state.state_name', 'cb_statewise_restriction.*')
            ->where('cb_id', $request->cb_id)
            ->orderBy('ref_state_id', 'ASC')
            ->get();

        $option = '<option value="">-Select State-</option>';
        if (count($data) > 0) {
            foreach ($data as $key => $value) {
                $option .= '<option value="' . $value->refStateId . '">' . $value->state_name . '</option>';
            }
        } else {
            $option .= '<option value="">No record found.</option>';
        }
        return response()->json($option);
    }
    
    public function getCBIDOperator(Request $request){
        $results = DB::table('at_cb_registration_permission as cb')
                    ->leftJoin('module as md', 'md.id', '=', 'cb.module_id')
                    ->leftJoin('sub_module as smb', 'smb.id', '=', 'cb.sub_module_id')
                    ->where('cb.cb_id', $request->cb_id)
                    ->whereNull('cb.deleted_at')
                    ->select('md.id as module_id', 'md.module_name', 
                             'smb.id as submodule_id', 'smb.sub_module_name', 'smb.module_path','cb.sub_module_id') 
                     ->orderBy('smb.id')         
                    ->get();

            // dd($results);
        $option = '<option value="">-Select-</option>';
        if (count($results) > 0) {
            foreach ($results as $key => $value) {
                if($value->submodule_id == 2 || $value->submodule_id == 3 || $value->submodule_id == 4 || $value->submodule_id == 5 || $value->submodule_id ==6){
                $option .= '<option value="' . $value->sub_module_id . '">' . $value->sub_module_name . '</option>';
            }
            }
        } else {
            $option .= '<option value="">No record found.</option>';
        }
        return response()->json($option);
    }


    public function OrganicOperatorgetDetailsPan(Request $request)
    {
        $result = User::where('ref_operator_type_id',$request->ref_operator_type_id)->where('user_name', $request->PanID)->first();
        if ($result) {
            return response()->json([
                'status' => true,
                'message' => 'PAN already in use with same activity.'
            ]);
        } else {
            return response()->json([
                'status' => false,
                'message' => 'No user found with this PanID.'
            ]);
        }
    }


    public function sendOtp(Request $request)
    {
        $request->validate([
            'mobile_number' => 'required|digits:10',
        ]);

        $mobileNumber = $request->input('mobile_number');
        $otp = rand(1000, 9999);


        $response = sendOtpHelp($mobileNumber, $otp);


        $otpCount = 1;
        $sendComOTP = UserVerification::updateOrCreate(
            ['mobile_no' => $mobileNumber],
            ['otp' => $otp, 'otp_count' => $otpCount, 'created_on' => now(), 'updated_on' => now()]
        );


        if ($sendComOTP) {
            return response()->json(['status' => 'success', 'message' => 'OTP sent successfully']);
        } else {
            return response()->json(['status' => 'error', 'message' => 'Failed to send OTP']);
        }
    }

    public function verifyOtp(Request $request)
    {
        $request->validate([
            'mobile_number' => 'required|digits:10',
            'otp' => 'required|digits:4',
        ]);

        $mobileNumber = $request->input('mobile_number');
        $otp = $request->input('otp');

        // Check if the OTP is correct
        $verification = UserVerification::where('mobile_no', $mobileNumber)
            ->where('otp', $otp)
            ->first();
        if (isset($verification)) {
            // Update the verify_status to 1 after OTP is verified
            $verification->verify_status = 1;
            $verification->save();

            return response()->json(['status' => 'success', 'message' => 'OTP verified successfully']);
        } else {
            return response()->json(['status' => 'error', 'message' => 'Invalid OTP']);
        }
    }

    public function emailMobileOTP(Request $request)
    {
        try {
            // if (isset($request->user_mobile)) {
            //     $user_mobile = $request->user_mobile;
            //     session(['user_mobile' => $user_mobile]);
            //     $mobileOTP = rand('1000', '9999');
            //     //$mobileOTP = 1234;
            //     session(['mobileOTP' => $mobileOTP]);
            //     $msg = "Your OTP for login is $mobileOTP. Regards, Rashtrapati Bhavan.";
            //     $dlt_template_id = '1107161534668346421';
            //     send_otp($user_mobile, $msg, $dlt_template_id);
            //     echo 1;
            // } else

            // if (User::where('email', $request->email)->count() > 0) {
            //     return response()->json([
            //         'status' => 'error',
            //         'message' => 'Email already taken'
            //     ], 400);
            // }


            if (isset($request->user_email)) {
                $user_email = $request->user_email;
                session(['user_email' => $user_email]);
                $emailOTP = rand('1000', '9999');
                session(['emailOTP' => $emailOTP]);
                $emails = $user_email;
                $maildata = array();
                $maildata  = ['send_message' => "Dear User <br><br>Your OTP for validating Email address " . $emailOTP . " <br><br>Regards, <br>Apeda Team"];
                Mail::send('mail.inspector_register', $maildata, function ($message) use ($emails) {
                    $message->subject("Apeda OTP"); // Email subject body
                    $message->to($emails);
                });
                echo 1;
            }
        } catch (Exception $e) {
            Log::error($e);
        }
    }


    public function emailMobileOTPcheck(Request $request)
    {
        try {
            // if (isset($request->mobile_otp)) {
            //     $mobile_otp = $request->mobile_otp;
            //     $mobileOTP = session('mobileOTP');
            //     if ($mobile_otp == $mobileOTP) {
            //         echo 1;
            //         session(['validmobileOTP' => 1]);
            //     } else {
            //         echo 0;
            //     }
            // } else
            if (isset($request->email_otp)) {
                $email_otp = $request->email_otp;
                $emailOTP = session('emailOTP');
                if ($email_otp == $emailOTP) {
                    echo 1;
                    session(['validemailOTP' => 1]);
                } else {
                    echo 0;
                }
                // echo session('emailOTP');
            }
        } catch (Exception $e) {
            Log::error($e);
        }
    }
}

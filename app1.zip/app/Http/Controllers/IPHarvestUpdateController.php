<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\AtFarmerStandingCorpDetail;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;
use Exception;


class IPHarvestUpdateController extends Controller
{
        public function updateIPActualYield(){
        $user_id = Auth::guard('misadmin')->user()->id;
        return view('admin.harvest_update.ip.update_actual_yield');
    }

    






   }

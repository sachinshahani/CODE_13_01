<?php

namespace App\Http\Controllers\PaymentGateway;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use App\Models\User;
use GuzzleHttp\Client;
use App\Models\Payment;
use App\Models\AtApplicationRCAC;

class PaymentController extends Controller
{

    protected $apiUrl;
    protected $apiKey;
    protected $apiSecret;
    protected $encryptionKey;
    protected $encryptionIv;
    protected $merchantId;
    protected $schemeCode;
    protected $returnUrlCode;
    protected $returnUrl;
    protected $instituteName;
    protected $branchName;

    public function __construct()
    {
        if (app()->environment('production')) {
            // Use production keys
            $this->apiUrl = env('QFIX_API_URL_PROD', 'https://api.qfix.com');
            $this->apiKey = env('QFIX_API_KEY_PROD', '');
            $this->apiSecret = env('QFIX_API_SECRET_PROD', '');
            $this->encryptionKey = env('QFIX_ENCRYPTION_KEY_PROD', 'ZY31M82COAD5OIH0');
            $this->encryptionIv = env('QFIX_ENCRYPTION_IV_PROD', '');
            $this->merchantId = env('QFIX_MERCHANT_ID_PROD', 'PERP00176');
            $this->schemeCode = env('QFIX_SCHEME_CODE_PROD', 'PERP00176_S1');
            $this->returnUrlCode = env('QFIX_RETURN_URL_CODE_PROD', 'P00176R1');
        } else {
            // Use development keys
            $this->apiUrl = env('QFIX_API_URL_DEV', 'https://api.dev.qfix.com');
            $this->apiKey = env('QFIX_API_KEY_DEV', '');
            $this->apiSecret = env('QFIX_API_SECRET_DEV', '');
            $this->encryptionKey = env('QFIX_ENCRYPTION_KEY_DEV', 'VYPKPFPIMKNVCA53');
            $this->encryptionIv = env('QFIX_ENCRYPTION_IV_DEV', 'ZXZX6E2GNOW3ASYU');
            $this->merchantId = env('QFIX_MERCHANT_ID_DEV', 'TERP00083');
            $this->schemeCode = env('QFIX_SCHEME_CODE_DEV', 'TERP00083_S1');
            $this->returnUrlCode = env('QFIX_RETURN_URL_CODE_DEV', '');
        }
        $this->returnUrl = route('payment.callback');

        $this->instituteName =  env('INSTITUDE_NAME', 'Agricultural and Processed Food Products Export Development Authority');
        $this->branchName =  env('BRANCH_NAME', 'Agricultural and Processed Food Products Export Development Authority');

    }


    // public function index()
    // {
    //     return view('payment.test_create');
    // }


    public function createPayment(Request $request)
    {

        // Validate the request
        $request->validate([
            'amount' => 'required|numeric',
             'user_id' => 'required|string|max:100',
             'rc_id' => 'required|string|max:100',
             'orderId' => 'required|string|max:100',
             'serviceId' => 'required|string|max:100',
            'currency' => 'required|string|max:3',
            // 'customer_email' => 'required|email',
            // 'customer_number' => 'required|digits:10',
            // 'customer_address' => 'required|string|max:200',
            // 'customer_city' => 'required|string|max:50',
            // 'customer_state' => 'required|string|max:50',
            // 'customer_country' => 'required|string|max:50',
            // 'customer_pincode' => 'required|string|max:10',
            // 'return_url' => 'required|url',
        ]);

        $userData = $this->getUserData($request->user_id); //print_r($userData); die;

        $data = $userData->getData(true);
        if (!isset($data)) {
            return response()->json(['error' => 'User not found'], 404);
        }
        //print_r($data); die;
        $returnUrl = $this->returnUrl . "?orderId=" . urlencode($request->orderId) . "&serviceId=" . urlencode($request->serviceId). "&rc_id=" . urlencode($request->rc_id);

        $payload = "merchant_unique_reference_number=" . time() . "|"
            . "amount=" . $request->amount . "|"
            . "currency_code=" . $request->currency . "|"
            . "customer_name=" .  $data['name'] . "|"
            . "customer_email=" .  $data['email'] . "|"
            . "customer_number=" .  $data['mobile_no'] . "|"
            . "customer_address=" .  $data['address']. "|"
            . "customer_city=" . $request->customer_city . "|"
            . "customer_state=" . $request->customer_state . "|"
            . "customer_country=" . $request->customer_country . "|"
            . "customer_pincode=" .  $data['pin'] . "|"
            . "return_url_code=|"
            . "udf_1=|"
            . "udf_2=|"
            . "udf_3=|"
            . "udf_4=|"
            . "udf_5=|"
            . "udf_6=|"
            . "udf_7=|"
            . "udf_8=|"
            . "udf_9=|"
            . "udf_10=|"
            . "date=" . now()->format('d/m/Y') . "|"
            . "split_payment_data=|"
            . "return_url=" . $returnUrl . "|"
            . "product_details=|";
        $encryptedPayload = $this->encryptPayload($payload, $this->encryptionKey, $this->encryptionIv);
        
        $paymentUrl = "https://www.eduqfix.com/checkout/integration/payment"
            . "?merchantId=" . $this->merchantId
            . "&command=INITIATE"
            . "&schemeCode=" . $this->schemeCode
            . "&payload=" . urlencode($encryptedPayload);

        return redirect($paymentUrl);
    }

    public function paymentCallback(Request $request)
    {
        $encryptedPayload = $request->input('payload');
        $decryptedPayload = $this->decryptPayload($encryptedPayload, $this->encryptionKey, $this->encryptionIv);
        parse_str(str_replace('|', '&', $decryptedPayload), $data);
       
        $serviceId = $request->query('serviceId');
        $orderId = $request->query('orderId');
        $rc_id = $request->query('rc_id');
        $payment = Payment::create([
            'orderId' =>  $orderId ?? null,
            'serviceId' => $serviceId ?? null,
            'amount' => $data['amount'] ?? null,
            'paymentMode' => $data['paymentMode'] ?? null,
            'trackId' => $data['trackId'] ?? null,
            'result' => $data['result'] ?? null,
            'errorCode' => $data['errorCode'] ?? null,
            'errorDescription' => $data['errorDescription'] ?? null,
            'paymentId' => $data['paymentId'] ?? null,
            'currency' => $data['currency'] ?? 'INR',
            'rcId' => $rc_id ?? null,
        ]);          

        $paymentId = $payment->id;
        $atApplicationRCAC = AtApplicationRCAC::find($rc_id); 

        if ($atApplicationRCAC) {
            $status = ($data['result'] === 'SUCCESS') ? 1 : 0;
            //print_r($status); die;
            $atApplicationRCAC->update([
                'paymentId' => $data['paymentId'] ?? null, 
                'paymentStatus' => $data['result'] ?? null, 
                'status' => $status, 
                'ptId' => $paymentId,
              
            ]); // print_r($atApplicationRCAC); die;
        }

        if (isset($data['result']) && $data['result'] === 'SUCCESS') {
            return redirect()->route('payment.payment_status', ['result' => 'success']);
        } else {
            return redirect()->route('payment.payment_status', ['result' => 'failure']);
        }
    }

    public function paymentStatus($result)
    {
        return view('payment.status', ['payment_status' => $result]);
    }


    private function encryptPayload($payload, $secretKey, $iv)
    {
        $ivspec = utf8_encode($iv);
        $digest = $this->hexToStr(hash('sha256', utf8_encode($secretKey)));
        $cipher = openssl_encrypt($payload, "AES-256-CBC", $digest, OPENSSL_RAW_DATA, $ivspec);
        return rtrim(strtr(base64_encode($cipher), '+/', '-_'), '=');
    }

    private function decryptPayload($encryptedPayload, $secretKey, $iv)
    {
        $encodedText = base64_decode(str_pad(strtr($encryptedPayload, '-_', '+/'), strlen($encryptedPayload) % 4, '=', STR_PAD_RIGHT));
        $ivspec = utf8_encode($iv);
        $digest = $this->hexToStr(hash('sha256', utf8_encode($secretKey)));
        return openssl_decrypt($encodedText, "AES-256-CBC", $digest, OPENSSL_RAW_DATA, $ivspec);
    }

    private function hexToStr($hex)
    {
        $string = '';
        for ($i = 0; $i < strlen($hex) - 1; $i += 2) {
            $string .= chr(hexdec($hex[$i] . $hex[$i + 1]));
        }
        return $string;
    }

    private function getUserData($id)
    {
        $userdata = User::select('first_name', 'middle_name', 'last_name', 'contact_person_mobile_number', 'email','address','pin')
            ->where('id', $id)
            ->first();
    
        if (!$userdata) {
            return response()->json(['error' => 'User not found'], 404); // Return an error if no user found
        }
    
        $data = [
            'name' => trim($userdata->first_name . ' ' . $userdata->middle_name . ' ' . $userdata->last_name),
            'email' => $userdata->email,
            'mobile_no' => $userdata->contact_person_mobile_number,
            'address' => $userdata->address,
            'pin' => $userdata->pin,
        ];
        return response()->json($data);
    }
    
}

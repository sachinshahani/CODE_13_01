<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\User;
use App\Models\RefState;
use App\Models\RefDistrict;
use App\Models\RefRegion;
use App\Models\RefVillage;
use App\Models\RoleUser;
use App\Models\UserInspector;
use App\Models\AtFarmerRegDetail;
use App\Models\AtFarmDetails;
use App\Models\RefProduct;
use App\Models\CertificateStandardDetail;
use App\Models\AtOpTransactionVsTransactionProduct;
use App\Models\MandatorRegister;
use App\Models\AtOpNocDetails;
use App\Models\IcsMandator;
use App\Models\UserWarehouse;
use App\Models\UserWarehouseManagerOfficers;
use App\Models\AtOrgSampleRtnDtl;
use App\Models\ForwardLabSample;
use App\Models\AtCbTestParameterEntry;
use App\Models\AtOpTransactionProductSourced;
use App\Models\AtOpTransactionCertificateEntry;
use App\Models\LabTestReport;
use App\Models\RefLaboratory;
use PDF;
use Dompdf\Dompdf;
use RealRashid\SweetAlert\Facades\Alert;
use Illuminate\Support\Facades\Auth;
use DB;
use Carbon\Carbon;
use DataTables;



class LabDashboardController extends Controller
{
    public function lab_dashboard(Request $request)
    {
        $role = Auth::user()->id;
        $lab_id = Auth::user()->lab_id;
        $c1 = date('Y-m-01');
        $c2 = date('Y-m-t');

        $l1 = date('Y-m-01', strtotime("-1 month"));
        $l2 = date('Y-m-t', strtotime("-1 month"));

        $ll1 = date('Y-m-01', strtotime("-2 month"));
        $ll2 = date('Y-m-t', strtotime("-2 month"));

        $cur_month_users = User::select('ref_operator_type_id', DB::raw('COUNT(id) as users'))->groupBy('ref_operator_type_id')
            ->where('user_type', '=', 1)
            ->where('status', 1)
            ->where('ref_operator_type_id', '!=', 7)
            ->where('ref_operator_type_id', '!=', 1)
            ->whereBetween('created_at', [$c1, $c2])
            ->get();

        $last_month_users = User::select('ref_operator_type_id', DB::raw('COUNT(id) as users'))->groupBy('ref_operator_type_id')
            ->where('user_type', '=', 1)
            ->where('status', 1)
            ->where('ref_operator_type_id', '!=', 7)
            ->where('ref_operator_type_id', '!=', 1)
            ->whereBetween('created_at', [$l1, $l2])
            ->get();
        $llast_month_users = User::select('ref_operator_type_id', DB::raw('COUNT(id) as users'))->groupBy('ref_operator_type_id')
            ->where('user_type', '=', 1)
            ->where('status', 1)
            ->where('ref_operator_type_id', '!=', 7)
            ->where('ref_operator_type_id', '!=', 1)
            ->whereBetween('created_at', [$ll1, $ll2])
            ->get();



        $icsWithFarmerCount = User::select('at_user.first_name as first_name', 'at_ics_inspector_details.id', DB::raw('COUNT(at_farmer_reg_details.id) as users'))
            ->join('at_ics_inspector_details', 'at_ics_inspector_details.at_user_id', 'at_user.id')
            ->join('at_farmer_reg_details', 'at_farmer_reg_details.at_ics_inspector_id', 'at_ics_inspector_details.id')
            ->where('at_user.ref_operator_type_id', 2)
            ->groupBy('at_user.id', 'at_ics_inspector_details.id')
            ->get();


        $operatorCountByState = User::select('ref_state_id', DB::raw('COUNT(id) as users'))
            ->groupBy('ref_state_id')
            ->where('user_type', '=', 1)
            ->where('ref_operator_type_id', '!=', 7)
            ->where('ref_operator_type_id', '!=', 1)
            ->where('status', 1)
            ->get()->toArray();



        $users = User::all();
        $ics = $users->where('ref_operator_type_id', 2)->count();
        $individual = $users->where('ref_operator_type_id', 3)->count();
        $harvester = $users->where('ref_operator_type_id', 4)->count();
        $trader  = $users->where('ref_operator_type_id', 5)->count();
        $processor  = $users->where('ref_operator_type_id', 6)->count();
        $mandators  = MandatorRegister::count();


        $inspDetail  = UserInspector::where('at_user_id', Auth::guard('misadmin')->user()->id)->get();
        $insp = $inspDetail->count();
        $inspIds = array();
        if (!empty($inspDetail)) {
            foreach ($inspDetail as $key => $value) {
                $inspIds[] = $value->id;
                # code...
            }
        }

        $farmers =  AtFarmerRegDetail::whereIn('at_ics_inspector_id', $inspIds)->count();

        $scList = CertificateStandardDetail::whereHas('getuser', function ($q) {
            return $q->where('created_by', Auth::id());
        })
            ->where('status', 1)->where('scope_certificate_no', '!=', '')
            ->get();

        if ($request->sc_certificate != '') {
            $scList = CertificateStandardDetail::whereHas('getuser', function ($q) {
                return $q->where('created_by', Auth::id());
            })
                ->where('status', $request->sc_certificate)->where('is_renewed', '!=', 1)
                ->get();
        }
        $tcData = AtOpTransactionVsTransactionProduct::where('tc_application_no', 'LIKE', 'TC%')->orderBy('created_at', 'asc')->get();
        $ptcData = AtOpTransactionVsTransactionProduct::where('tc_application_no', 'LIKE', 'PTC%')->orderBy('created_at', 'asc')->get();
        $product = RefProduct::offset(10)->limit(10)->get();

        $nocList = AtOpNocDetails::where('noc_status', '!=', 'Pending')->get();

        $ipAddress = $_SERVER['REMOTE_ADDR'];

        $lab =  AtOrgSampleRtnDtl::where('ref_laboratory_master_id', $lab_id)->count();
        $genrate_report_lab =  AtOrgSampleRtnDtl::where('ref_laboratory_master_id', $lab_id)->where('save_test_status', 1)->count();


        return view('admin.lab.dashboard', compact('ics', 'individual', 'harvester', 'trader', 'processor', 'mandators', 'insp', 'farmers', 'users', 'cur_month_users', 'last_month_users', 'llast_month_users', 'icsWithFarmerCount', 'operatorCountByState', 'scList', 'tcData', 'ptcData', 'product', 'nocList', 'ipAddress', 'lab', 'genrate_report_lab'));
    }

    public function sampling_collection_lot_list(Request $request)
    {
        $user_id = Auth::user()->lab_id;
        if ($request->ajax()) {
            $inspIds =  AtOrgSampleRtnDtl::where('ref_laboratory_master_id', $user_id)->whereNull('save_status')->get();
            return Datatables::of($inspIds)
                ->addIndexColumn()
                ->addColumn('reg_no', function ($row) {
                    return $row->transaction_certificate_no;
                })
                ->addColumn('name', function ($row) {
                    return $row->ref_product_id ?? '';
                })
                ->addColumn('tc_no', function ($row) {
                    return $row->tc_no ?? '';
                })->addColumn('address', function ($row) {
                    return $row->address ?? '';
                })->addColumn('reg_type', function ($row) {

                    return "";
                })->addColumn('company_name', function ($row) {
                    // $user_id =  getOperatorTypeById($row->operator_type) ?? '-';
                    $user_id = $row->operator_type ?? '-';
                    return $user_id;
                })

                ->addColumn('product_name', function ($row) {
                    if ($row === null || !isset($row->ref_product_id)) {
                        return '';
                    }

                    $productName = getProductNameById1($row->ref_product_id);
                    return $productName ?? '';
                })
                ->addColumn('action', function ($row) {

                    $actionBtn = '<a href=' . route('superadmin.lab.lab_sampling_collection_view', $row->id) . '> Process</a>';



                    return $actionBtn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }

        return view('admin.lab.sampling_collection_lot_list');
    }

    public function lab_sampling_collection_view(Request $request, $id)
    {

        $user = Auth::user()->lab_id;
        $inspIds =  AtOrgSampleRtnDtl::where('id', $id)->first();



        return view('admin.lab.lab_sampling_collection_view', compact('inspIds'));
    }

    public function lab_sampling_collection_proceed($id)
    {

        $inspIds =  AtOrgSampleRtnDtl::where('id', $id)->first();
        $user = User::where('id', $id)->first();

        return view('admin.lab.lab_sampling_collection_proceed', compact('inspIds', 'id'));
    }

    public function save_sample_details(Request $request)
    {

        $user_id = Auth::user()->id;
        $data = array(
            'at_org_sample_rtn_dtl_id' => $request->at_org_sample_rtn_dtl_id,
            'sample_code' => $request->sample_code,
            'drawn_sample_date' => $request->drawn_sample_date,
            'sample_weight' => $request->sample_weight,
            'person_name' => $request->person_name,
            'created_by' => $user_id,

            // 'sample_retains_qty' => $request->sample_retains_qty,
            // 'place_sampling' => $request->place_sampling,
            // 'lab_code' => $request->lab_code,
            //'sample_retaining_date' => $request->sample_retaining_date,
        );
        $user = ForwardLabSample::create($data);
        $record = AtOrgSampleRtnDtl::where('id', $request->at_org_sample_rtn_dtl_id)->first();
        if ($record) {
            $record->save_status = 1;
            $record->save();
        }

        //return redirect()->back()->with('success', 'Forward Successfully.');
        Alert::success('Success', 'Details Save Successfully');
        return redirect()->route('superadmin.lab.sampling_receiplat_list');
    }

    public function sampling_receiplat_list(Request $request)
    {

        $user_id = Auth::user()->id;
        $labs_id = Auth::user()->lab_id;

        $lab_id = User::where('id', $user_id)->select('lab_id')->first();

        if ($request->ajax()) {

            $totalData = AtOrgSampleRtnDtl::where('ref_laboratory_master_id', $labs_id)
                ->where('save_status', 1)
                ->whereNull('forward_status')
                ->leftJoin('forward_lab_samble', 'at_org_sample_rtn_dtl.id', '=', 'forward_lab_samble.at_org_sample_rtn_dtl_id') // Joining the tables
                ->select(
                    'at_org_sample_rtn_dtl.id as id',
                    'at_org_sample_rtn_dtl.tc_no as lot_number',
                    'at_org_sample_rtn_dtl.operator_user_id as operator_user_id',
                    'at_org_sample_rtn_dtl.operator_type as operator_type',

                    'forward_lab_samble.sample_code',
                    'forward_lab_samble.drawn_sample_date',
                    'forward_lab_samble.place_sampling',
                    'forward_lab_samble.id as forward_id'
                )
                ->get();






            return Datatables::of($totalData)
                ->addIndexColumn()
                ->addColumn('tc_no', function ($row) {
                    return $row->lot_number;
                })->addColumn('company_name', function ($row) {

                    $user_id =  $row->operator_type ?? '--';
                    return $user_id;
                })->addColumn('sample_code', function ($row) {

                    return $row->sample_code ?? '';
                })
                ->addColumn('drawn_sample_date', function ($row) {

                    return dateFormat($row->drawn_sample_date ?? '');
                })->addColumn('action', function ($row) {
                    $actionBtn = '<a href=' . route('superadmin.lab.lab_sampling_receiplat_view', $row->id) . '> Process</a>';
                    return $actionBtn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }

        return view('admin.lab.sampling_receiplat_list');
    }

    public function lab_sampling_receiplat_view($id)
    {

        $inspIds =  AtOrgSampleRtnDtl::where('id', $id)->first();

        $sample_data =  ForwardLabSample::where('at_org_sample_rtn_dtl_id', $id)->first();

        $user = User::where('id', $id)->first();

        return view('admin.lab.lab_sampling_receiplat_view', compact('inspIds', 'id', 'sample_data'));
    }



    public function forward_sample_details(Request $request)
    {
        // dd($request->all());
        $user_id = Auth::user()->id;
        $data = array(
            'sample_code' => $request->sample_code,
            'drawn_sample_date' => $request->drawn_sample_date,
            'sample_weight' => $request->sample_weight,
            'person_name' => $request->person_name,
            'sample_retains_qty' => $request->sample_retains_qty,
            'place_sampling' => $request->place_sampling,
            'lab_code' => $request->lab_code,
            'sample_retaining_date' => $request->sample_retaining_date,
            'updated_by' => $user_id,
        );

        $record = ForwardLabSample::where('at_org_sample_rtn_dtl_id', $request->at_org_sample_rtn_dtl_id)->first();
        if ($record) {
            $record->update($data);
            Alert::success('Success', 'Updated Successfully');
        } else {
            ForwardLabSample::create(array_merge($data, ['at_org_sample_rtn_dtl_id' => $request->at_org_sample_rtn_dtl_id]));
            Alert::success('Success', 'Forward Successfully');
        }

        $record = AtOrgSampleRtnDtl::where('id', $request->at_org_sample_rtn_dtl_id)->first();
        if ($record) {
            $record->forward_status = 1;
            $record->save();
        }

        return redirect()->route('superadmin.lab.test_rest_entry');
    }

    public function test_rest_entry(Request $request)
    {
        $user_id = Auth::user()->id;
        $labs_id = Auth::user()->lab_id;

        $lab_id = User::where('id', $user_id)->select('lab_id')->first();

        if ($request->ajax()) {

            $totalData = AtOrgSampleRtnDtl::where('ref_laboratory_master_id', $labs_id)->where('forward_status', 1)
                ->whereNull('save_test_status')
                ->leftJoin('forward_lab_samble', 'at_org_sample_rtn_dtl.id', '=', 'forward_lab_samble.at_org_sample_rtn_dtl_id') // Joining the tables
                ->select(
                    'at_org_sample_rtn_dtl.id as id',
                    'at_org_sample_rtn_dtl.tc_no as lot_number',
                    'at_org_sample_rtn_dtl.operator_user_id as operator_user_id',

                    'forward_lab_samble.sample_code',
                    'forward_lab_samble.drawn_sample_date',
                    'forward_lab_samble.place_sampling',
                    'forward_lab_samble.id as forward_id',
                    'forward_lab_samble.lab_code as lab_code',
                    'forward_lab_samble.person_name as person_name'
                )->get();
            return Datatables::of($totalData)
                ->addIndexColumn()
                ->addColumn('tc_no', function ($row) {
                    return $row->lot_number;
                })->addColumn('lab_code', function ($row) {
                    return $row->lab_code;
                })->addColumn('sample_code', function ($row) {

                    return $row->sample_code ?? '';
                })
                ->addColumn('person_name', function ($row) {

                    return $row->person_name ?? '';
                })
                ->addColumn('drawn_sample_date', function ($row) {

                    return dateFormat($row->drawn_sample_date ?? '');
                })->addColumn('action', function ($row) {
                    $actionBtn = '<a href=' . route('superadmin.lab.test_rest_entry_view', $row->id) . '> Process</a>';
                    return $actionBtn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }

        return view('admin.lab.test_rest_entry');
    }

    public function test_rest_entry_view($id)
    {
        $inspIds =  AtOrgSampleRtnDtl::where('id', $id)->first();
        // dd($inspIds);
        $sample_data =  ForwardLabSample::where('at_org_sample_rtn_dtl_id', $id)->first();
        $user = User::where('id', $id)->first();
        $samples = AtCbTestParameterEntry::where('at_op_transaction_certificate_entry_id', $inspIds->at_op_transaction_certificate_entry_id)->get();
        // dd($samples);
        return view('admin.lab.test_rest_entry_view', compact('inspIds', 'id', 'sample_data', 'samples'));
    }

    public function genrate_test_report(Request $request)
    {
        $user_id = Auth::user()->id;
        $labs_id = Auth::user()->lab_id;

        //dd($labs_id);

        $lab_id = User::where('id', $user_id)->select('lab_id')->first();

        if ($request->ajax()) {

            $totalData = AtOrgSampleRtnDtl::where('ref_laboratory_master_id', $labs_id)
                ->where('save_test_status', 1)
                ->leftJoin('forward_lab_samble', 'at_org_sample_rtn_dtl.id', '=', 'forward_lab_samble.at_org_sample_rtn_dtl_id') // Joining the tables
                ->select(
                    'at_org_sample_rtn_dtl.id as id',
                    'at_org_sample_rtn_dtl.tc_no as lot_number',
                    'at_org_sample_rtn_dtl.operator_user_id as operator_user_id',
                    'at_org_sample_rtn_dtl.operator_type as operator_type',

                    'forward_lab_samble.sample_code',
                    'forward_lab_samble.drawn_sample_date',
                    'forward_lab_samble.place_sampling',
                    'forward_lab_samble.id as forward_id',
                    'forward_lab_samble.lab_code as lab_code',
                    'forward_lab_samble.person_name as person_name'
                )
                ->get();


            return Datatables::of($totalData)
                ->addIndexColumn()
                ->addColumn('tc_no', function ($row) {
                    return $row->lot_number;
                })->addColumn('lab_code', function ($row) {
                    return $row->lab_code;
                })->addColumn('sample_code', function ($row) {

                    return $row->sample_code ?? '';
                })
                ->addColumn('person_name', function ($row) {

                    return $row->person_name ?? '';
                })
                ->addColumn('company_name', function ($row) {
                    $user_id =  $row->operator_type ?? '-';
                    return $user_id;
                })
                ->addColumn('drawn_sample_date', function ($row) {

                    return dateFormat($row->drawn_sample_date ?? '');
                })->addColumn('action', function ($row) {
                    $actionBtn = '<a href=' . route('superadmin.lab.genrate_test_report_html_version', $row->id) . ' target="_blank"> Html Version</a>';
                    return $actionBtn;
                })
                ->addColumn('download', function ($row) {

                    $actionBtns = '<a href=' . route('superadmin.lab.genrate_test_report_download', $row->id) . ' target="_blank"> Download</a>';



                    return $actionBtns;
                })
                ->rawColumns(['action', 'download'])
                ->make(true);
        }

        return view('admin.lab.genrate_test_report');
    }


    public function genrate_test_report_view($id)
    {


        $inspIds =  AtOrgSampleRtnDtl::where('id', $id)->first();

        $sample_data =  ForwardLabSample::where('at_org_sample_rtn_dtl_id', $id)->first();

        $user = User::where('id', $id)->first();

        return view('admin.lab.genrate_test_report_view', compact('inspIds', 'id', 'sample_data'));
    }

    public function genrate_test_report_html_version($id)
    {
        $inspIds =  AtOrgSampleRtnDtl::where('id', $id)->first();

        $sample_data =  ForwardLabSample::where('at_org_sample_rtn_dtl_id', $id)->first();

        $user = User::where('id', $id)->get();


        // New

        $labs_id = Auth::user()->lab_id;

        $sample_data =  ForwardLabSample::where('at_org_sample_rtn_dtl_id', $id)->first();
        $lab =  RefLaboratory::where('id',  $labs_id)->first();
        $LabTestReport =  LabTestReport::where('at_op_transaction_certificate_entry_id', $id)->first();
        $LabTestReports =  LabTestReport::where('at_op_transaction_certificate_entry_id', $id)->get();
        $LabTestParameter =  AtCbTestParameterEntry::where('id',  $id)->first();

        $tranEntry = AtOpTransactionCertificateEntry::where('at_op_transaction_vs_transaction_product_id',$id)->first();

   // dd( $lab);
  //dd(  $LabTestReports);

        return view('admin.lab.genrate_test_report_html_version', compact('inspIds', 'id', 'sample_data', 'LabTestReport', 'lab', 'LabTestParameter', 'tranEntry', 'LabTestReports'));
    }

    public function genrate_test_report_download($id)
    {
        $inspIds =  AtOrgSampleRtnDtl::where('id', $id)->first();
        $sample_data =  ForwardLabSample::where('at_org_sample_rtn_dtl_id', $id)->first();
        $user = User::where('id', $id)->first();
        $labs_id = Auth::user()->lab_id;
        $sample_data =  ForwardLabSample::where('at_org_sample_rtn_dtl_id', $id)->first();
        $LabTestReport =  LabTestReport::where('at_op_transaction_certificate_entry_id', $id)->first();
        $lab =  RefLaboratory::where('id', $labs_id)->first();
        $LabTestReports =  LabTestReport::where('at_op_transaction_certificate_entry_id', $id)->get();

        $downloadedFileName = time().'form-1.pdf';
        $pdf = PDF::loadView('admin.lab.genrate_test_report_download', compact('inspIds','id','sample_data','LabTestReport', 'lab','LabTestReports'));
        return $pdf->stream($downloadedFileName);
    }



    public function test_rest_entry_genrate($id)
    {

        $data = AtOpTransactionProductSourced::where('at_op_transaction_vs_transaction_product_id', $id)->first();
        $tranEntry = AtOpTransactionCertificateEntry::where('at_op_transaction_vs_transaction_product_id', $id)->first();
        $tcno = AtOpTransactionVsTransactionProduct::where('id', $id)->first();
        $atOrgSampleRtnDtl = AtOrgSampleRtnDtl::where('id', $id)->first();
        return view('admin.lab.test_rest_entry_view_genrate', compact('id', 'data', 'tranEntry', 'tcno', 'atOrgSampleRtnDtl'));
    }

    public function lab_test_save(Request $request)
    {
        //dd($request->all());
        if (!empty($request->test_parameter_name)) {
            foreach ($request->test_parameter_name as $key => $testParameterName) {
                if (!empty($testParameterName)) {

                    $blq = isset($request->mrl_value[$key]) ? floatval($request->mrl_value[$key]) : '';
                    $equipment = isset($request->equipment[$key]) ? intval($request->equipment[$key]) : '';
                    $result = isset($request->result[$key]) ? $request->result[$key] : "";
                    $id = isset($request->id[$key]) ? $request->id[$key] : "";
                    // $test_start_date = isset($request->test_start_date[$key]) ? $request->test_start_date[$key] : "";
                    // $test_end_date = isset($request->test_end_date[$key]) ? $request->test_end_date[$key] : "";

                    $data = [
                        'at_op_transaction_certificate_entry_id' => $id,
                        'test_parameter_id' => $testParameterName,
                        'blq' => $blq,
                        'equipment' => $equipment,
                        'result' => $result,

                        'created_by' => Auth::user()->id,
                        'test_start_date' => $request->test_start_date,
                        'test_end_date' => $request->test_end_date,

                    ];


                    LabTestReport::create($data);
                }
            }

            $record = AtOrgSampleRtnDtl::where('id', $request->id)->first();
            if ($record) {
                $record->save_test_status = 1;
                $record->save();
            }

            return redirect()->route('superadmin.lab.genrate_test_report');
        } else {
            // If there's no test parameters found
            Alert::error('Error', 'No test parameters found');
        }

        return redirect()->back();
    }

    public function test_report_summary()
    {


        return view('admin.lab.test_report_summary');
    }
    public function manage_test_para()
    {


        return view('admin.lab.manage_test_para');
    }



    public function manage_user_list()
    {


        return view('admin.lab.manage_user_list');
    }

    public function add_user()
    {


        return view('admin.lab.add_user');
    }
}

<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Models\Permission;
use App\Models\Role;
use App\Models\RoleUser;
use App\Models\User;
use App\Models\UserSelf;
use App\Models\UserInspector;
use App\Models\Notification;
// use App\Models\UserFarmer;
use App\Models\AtFarmerLandDetail;
use App\Models\UserWarehouse;
use App\Models\UserWarehouseManagerOfficers;
use App\Models\RefState;
use App\Models\RefDistrict;
use App\Models\RefVillage;
use App\Models\RefRegion;
use App\Models\FarmersRegSchedule;
use App\Models\IcsMandator;
use App\Models\AtUser;
use App\Models\MandatorRegister;
use App\Models\AtFarmerRegDetail;
use App\Models\InspectionSchedule;
use RealRashid\SweetAlert\Facades\Alert;
use Validator;
use DataTables;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
//use Yajra\DataTables\DataTables;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;

class IcsUserController extends Controller
{
    //


    public function deptUseradd(Request $request)
    {
        $states = RefState::orderBy('state_name', 'ASC')->get();
        $districts = RefDistrict::orderBy('district_name', 'ASC')->get();
        $regions = RefRegion::orderBy('region_name', 'ASC')->get();
        $villages = RefVillage::orderBy('village_name', 'ASC')->limit(10)->get();
        return view('admin/usermanagement/deptUser/add', compact('states', 'districts', 'regions', 'villages'));
    }

    public function step1($id)
    {
        $userdetails = User::find($id);
        $userinsCount = UserInspector::where('at_user_id', $id)->count();
        $states = RefState::orderBy('state_name', 'ASC')->get();
        $districts = RefDistrict::orderBy('district_name', 'ASC')->get();
        $regions = RefRegion::orderBy('block_tehsil_name', 'ASC')->limit(100)->get();
        $villages = RefVillage::where('id', '=', $userdetails->ref_village_id)->orderBy('village_name', 'ASC')->limit($userdetails->ref_village_id, 100)->get();
        return view('admin.ics.icsprofile', compact('states', 'districts', 'regions', 'villages', 'userdetails', 'userinsCount'));
    }

    public function step1post(Request $request, $id)
    {
        // dd($request->all());
        $contactpersonaadhar_number = Crypt::encrypt(base64_decode(urldecode($request->contact_person_aadhar_number)));
        //dd($contactpersonaadhar_number );
        $request->validate([
            'first_name' => 'required',
            //'entity_firm' => 'required',
            //'last_name' => 'required',
            // 'email' => 'required|email',
            // 'mobile' => 'required',
            'address' => 'required',
            //'village' => 'required',
            //'taluka' => 'required',
            // 'state' => 'required',
            'pincode' => 'required',
            // '_hidden_legal_doc_upload'=> 'required',
            // 'ref_office_id' => 'required',
            // 'role_id' => 'required',
            // 'document_type' =>'',
            // 'no_of_farmers' =>'',
            // 'no_of_inspector' =>'',
            'managed_by' => 'required',
            'address_proof_of_office' => 'required',
            //'address_proof_of_office_doc' =>'required',
            // 'office_building_photo' => 'mimes:jpeg,jpg,png,pdf,xlx,csv|max:10000'
        ]);

        try {

            if ($request->hasFile('office_building_photo')) {

                if (!empty($request->office_building_photo_edit)) {
                    $imagePath = public_path('ics/office_building_photo/') . $request->office_building_photo_edit;
                    deleteOldImage($request->office_building_photo_edit, $imagePath);
                }
                $documentRootPath = 'public/ics/office_building_photo';
                $file_path = time() . rand() . '.' . $request->file('office_building_photo')->getClientOriginalExtension();
                $request->file('office_building_photo')->move($documentRootPath, $file_path);
                $office_building_photo = $file_path;
            } else {
                $office_building_photo = $request->office_building_photo_edit;
            }
            //address proof
            if ($request->hasFile('address_proof_of_office_doc')) {
                if (!empty($request->address_proof_of_office_doc_edit)) {
                    $imagePath = public_path('ics/address_proof_of_office_doc/') . $request->address_proof_of_office_doc_edit;
                    deleteOldImage($request->address_proof_of_office_doc_edit, $imagePath);
                }
                $documentRootPath = 'public/ics/address_proof_of_office_doc';
                $file_path = time() . rand() . '.' . $request->file('address_proof_of_office_doc')->getClientOriginalExtension();
                $request->file('address_proof_of_office_doc')->move($documentRootPath, $file_path);
                $address_proof_of_office_doc = $file_path;
            } else {
                $address_proof_of_office_doc = $request->address_proof_of_office_doc_edit;
            }

            $user = User::find($id);
            $user->first_name = $request->first_name;
            $user->contact_person_first_name = $request->contact_first_name;
            $user->contact_person_middle_name = $request->contact_middle_name;
            $user->contact_person_last_name = $request->contact_last_name;
            $user->contact_person_mobile_number = $request->mobile_no;
            $user->contact_person_email = $request->email;
            // $user->contact_person_aadhar_number = $contactpersonaadhar_number;
            $user->contact_person_aadhar_number = Crypt::encrypt(base64_decode(urldecode($request->contact_person_aadhar_number)));
            $user->address = $request->address;
            $user->ref_village_id = $request->ref_village_id;
            $user->ref_block_tehsil_id = $request->ref_block_tehsil_id;
            $user->ref_district_id = $request->ref_district_id;
            $user->ref_state_id = $request->ref_state_id;
            $user->pin = $request->pincode;
            $user->contact_person_mobile_number = $request->mobile_no;
            $user->document_type = $request->document_type;
            $user->legal_document_number = $request->legal_document_number;
            $user->legal_doc_upload = $request->_hidden_legal_doc_upload;
            $user->no_of_farmers = $request->no_of_farmers;
            $user->no_of_inspector = $request->no_of_inspector;
            $user->managed_by = $request->managed_by;
            $user->office_building_photo = $office_building_photo;
            $user->address_proof_of_office = $request->address_proof_of_office;
            $user->address_proof_of_office_doc = $address_proof_of_office_doc;
            $user->user_type = 1;
            $user->entity_firm = $request->entity_firm;
            // $user->created_by = Auth::guard('misadmin')->user()->id;
            $user->save();

            //dd($user);

            if ($request->roleid == 2) {
                Alert::success('Success', __('message.add_first_success'));
                return redirect()->route('superadmin.icsuser.step2', $user->id);
                //return redirect()->route('superadmin.icsuser.step2',$user->id)->with('success', __('message.add_first_success'));
            } else {
                Alert::success('Success',  __('message.add_success'));
                return redirect()->back();
                //return redirect()->back()->with('success', __('message.add_success'));
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function step2($id)
    {
        if (empty($id)) {
            abort(404);
        }
        $userdetails = User::find($id);
        $cbstate = User::where('id', $userdetails->created_by)->first();
        $userselfdetail = IcsMandator::where('at_user_id', $id)->first();
        //dd($userselfdetail);
        $states = RefState::orderBy('state_name', 'ASC')->get();
        $districts = getDistrictByStateID($userselfdetail->ref_state_id ?? '');
        $regions = getBlockTehsilByDistrictID($userselfdetail->ref_district_id ?? '');
        $villages = getVillageByBlock($userselfdetail->ref_block_tehsil_id ?? '');
        return view('admin.ics.icsstep2', compact('states', 'districts', 'regions', 'villages', 'userdetails', 'userselfdetail', 'cbstate'));
    }

    public function step2post(Request $request, $id)
    {
        try {
            // dd($request->all());
            $request->validate([
                'first_name' => 'required',
                'last_name' => 'required',
                //'email_id' => 'required|email_id|unique:at_ics_mandator_registration_details',
                // 'state' => 'required',
                // 'district' => 'required',
                // // 'mobile_no' => 'required|numeric|unique:at_user,mobile_no',
                // 'taluka' => 'required',
                // 'village' => 'required',
                'pincode' => 'required|numeric|digits:6',
                'address' => 'required',
                //  'id_proof' => 'required',
                //'id_proof_doc' => 'required|numeric|digits:12|unique:at_user,id_proof_doc',

                //'address_proof_of_office_doc' => 'mimes:jpeg,jpg,png,pdf,xlx,csv|max:10000',
                'profile_photo' => 'mimes:jpeg,jpg,png,pdf,xlx,csv|max:10000',
                'appointment_doc' => 'mimes:jpeg,jpg,png,pdf,xlx,csv|max:10000',
            ]);



            if ($request->hasFile('profile_photo')) {
                if (!empty($request->profile_photo_edit)) {
                    $imagePath = public_path('ics/profile_photo/') . $request->profile_photo_edit;
                    deleteOldImage($request->profile_photo_edit, $imagePath);
                }
                $documentRootPath = 'public/ics/profile_photo';
                $file_path = time() . rand() . '.' . $request->file('profile_photo')->getClientOriginalExtension();
                $request->file('profile_photo')->move($documentRootPath, $file_path);
                $profile_photo = $file_path;
            } else {
                $profile_photo = $request->profile_photo_edit;
            }


            if ($request->hasFile('appointment_doc')) {
                if (!empty($request->appointment_doc_edit)) {
                    $imagePath = public_path('ics/appointment_doc/') . $request->appointment_doc_edit;
                    deleteOldImage($request->appointment_doc_edit, $imagePath);
                }
                $documentRootPath = 'public/ics/appointment_doc';
                $file_path = time() . rand() . '.' . $request->file('appointment_doc')->getClientOriginalExtension();
                $request->file('appointment_doc')->move($documentRootPath, $file_path);
                $appointment_doc = $file_path;
            } else {
                $appointment_doc = $request->appointment_doc_edit;
            }

            if ($request->hasFile('office_building_photo')) {
                if (!empty($request->office_building_photo_edit)) {
                    $imagePath = public_path('ics/office_building_photo/') . $request->office_building_photo_edit;
                    deleteOldImage($request->office_building_photo_edit, $imagePath);
                }
                $documentRootPath = 'public/ics/office_building_photo';
                $file_path = time() . rand() . '.' . $request->file('office_building_photo')->getClientOriginalExtension();
                $request->file('office_building_photo')->move($documentRootPath, $file_path);
                $office_building_photo = $file_path;
            } else {
                $office_building_photo = $request->office_building_photo_edit;
            }

            $user = User::find($id);
            if (isset($user)) {
                if (isset($request->pan)) {
                    $mandatorRegister_data = MandatorRegister::where('pan', $request->pan)->first();

                    $newUser = IcsMandator::updateOrCreate([
                        'at_user_id'   => $id,
                    ], [
                        'company_mandator_name' => $mandatorRegister_data->mandator_name ?? '',
                        'gst_number' => $mandatorRegister_data->gst_number ?? '',
                        'first_name' => !empty($mandatorRegister_data->contact_first_name) ? $mandatorRegister_data->contact_first_name : NULL,
                        'middle_name' => !empty($mandatorRegister_data->contact_middle_name) ? $mandatorRegister_data->contact_middle_name : NULL,
                        'last_name' => !empty($mandatorRegister_data->contact_last_name) ? $mandatorRegister_data->contact_last_name : NULL,
                        'email_id' => !empty($mandatorRegister_data->email) ? $mandatorRegister_data->email : NULL,
                        'mobile_no' => !empty($mandatorRegister_data->mobile) ? $mandatorRegister_data->mobile : NULL,
                        'address1' => !empty($mandatorRegister_data->address) ? $mandatorRegister_data->address : NULL,
                        'ref_village_id' => !empty($mandatorRegister_data->village_id) ? $mandatorRegister_data->village_id : NULL,
                        'ref_block_tehsil_id' => !empty($mandatorRegister_data->taluka_mandal_id) ? $mandatorRegister_data->taluka_mandal_id : NULL,
                        'ref_district_id' => !empty($mandatorRegister_data->district_id) ? $mandatorRegister_data->district_id : NULL,
                        'ref_state_id' => !empty($mandatorRegister_data->state_id) ? $mandatorRegister_data->state_id : NULL,
                        'pin_code' => !empty($mandatorRegister_data->pin_code) ? $mandatorRegister_data->pin_code : NULL,
                        'id_proof' => !empty($request->id_proof) ? $request->id_proof : NULL,
                        'id_proof_doc' => !empty($mandatorRegister_data->aadhar_no) ? $mandatorRegister_data->aadhar_no : NULL,
                        //'address_proof_of_office' => $mandatorRegister_data->address_proof_of_office,
                        'profile_photo' => $profile_photo ?? '',
                        'office_building_photo' => $office_building_photo ?? '',
                        'appointment_doc' => $appointment_doc ?? '',
                        //'address_proof_of_office_doc' => $address_proof_of_office_doc ?? '',
                        'mand_type' => !empty($user->managed_by) ? $user->managed_by : NULL,
                        'created_by' => Auth::guard('misadmin')->user()->id,
                        'updated_by' => Auth::guard('misadmin')->user()->id,
                        'is_registred' => $request->is_reg ?? '0',
                        'pan_card' => $mandatorRegister_data->pan ?? '',
                    ]);
                } else {


                    $newUser = IcsMandator::updateOrCreate([
                        'at_user_id'   => $id,
                    ], [
                        'company_mandator_name' => $request->company_mandator_name ?? '',
                        'gst_number' => $request->gst_number ?? '',
                        'first_name' => $request->first_name,
                        'middle_name' => $request->middle_name,
                        'last_name' => $request->last_name,
                        'email_id' => $request->email_id,
                        'mobile_no' => $request->mobile_no,
                        'address1' => $request->address,
                        // 'ref_village_id' => $request->village,
                        // 'ref_block_tehsil_id' => $request->taluka,
                        // 'ref_district_id' => $request->district,
                        // 'ref_state_id' => $request->state,
                        'pin_code' => $request->pincode,
                        'id_proof' => $request->id_proof,
                        'id_proof_doc' => $request->id_proof_doc,
                        //'address_proof_of_office' => $request->address_proof_of_office,
                        'profile_photo' => $profile_photo ?? '',
                        'office_building_photo' => $office_building_photo ?? '',
                        'appointment_doc' => $appointment_doc ?? '',
                        //'address_proof_of_office_doc' => $address_proof_of_office_doc ?? '',
                        'mand_type' => $user->managed_by,
                        'created_by' => Auth::guard('misadmin')->user()->id,
                        'updated_by' => Auth::guard('misadmin')->user()->id,
                        'is_registred' => $request->is_reg ?? '0',
                        'pan_card' => $request->pan ?? '',
                    ]);
                }
            }
            if ($request->roleid == 2) {
                Alert::success('Success', __('message.add_second_success'));
                return redirect()->route('superadmin.icsuser.step4', $user->id);
                //return redirect()->route('superadmin.icsuser.step3',$user->id)->with('success', __('message.add_second_success'));
            } else {
                Alert::success('Success', __('message.add_success'));
                return redirect()->back();
                //return redirect()->back()->with('success', __('message.add_success'));
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }


    public function step3($id)
    {
        // if(Auth::guard('misadmin')->user()->roles[0]->id == 2){
        $userdetails = User::with('getUserInspector')->where('id', $id)->first();
        $no_of_farmers = $userdetails->no_of_farmers;
        $inspectors = $userdetails->getUserInspector;
        if ($inspectors->isEmpty()) {
            Alert::info('Info', 'Please first add the details of the Inspector.');
            return redirect()->back(); 
        }
        $totalGroups = ceil($no_of_farmers / 60);
        $inspectorsForGroups = [];
        for ($i = 0; $i < $totalGroups; $i++) {
            $groupInspector = $inspectors[$i] ?? null;
            if ($groupInspector) {
                $inspectorsForGroups[] = [
                    'inspector_id' => $groupInspector->id,
                    'farmers_from' => $i * 60 + 1,
                    'farmers_to' => min(($i + 1) * 60, $no_of_farmers),
                ];
            }
        }

        // dd($inspectorsForGroups);
        $cbstate = User::where('id', $userdetails->created_by)->first();
        // dd(CBstateAssign($cbstate->id));
        $userfardetails = AtFarmerRegDetail::with('farmerLandDetail')->where('at_user_id', $id)->get();
        $states = RefState::orderBy('state_name', 'ASC')->get();
        $districts = RefDistrict::where('ref_state_id', $userdetails->ref_state_id)->orderBy('district_name', 'ASC')->get();
        $regions = RefRegion::where('ref_state_id', $userdetails->ref_state_id)->orderBy('block_tehsil_name', 'ASC')->get();
        $villages = RefVillage::where('ref_district_id', $userdetails->ref_district_id)->orderBy('village_name', 'ASC')->get();
        return view('admin.ics.icsstep3', compact('states', 'districts', 'regions', 'villages', 'userdetails', 'userfardetails', 'cbstate', 'inspectorsForGroups'));
        // }else{
        //     return view('admin.profile');
        // }
    }

    public function step3post(Request $request, $id)
    {
        //    dd($request->all());


        try {
            $request->validate([
                'farmer_name.*' => 'required',
                'mobile_no.*' => 'required',
                'email.*' => 'required',
                'address.*' => 'required',
                'village.*' => 'required',
                'taluka.*' => 'required',
                'state.*' => 'required',
                'district.*' => 'required',
                'pincode.*' => 'required',
                'land_address.*' => 'required',
                'aadhar_card.*' => 'mimes:jpeg,jpg,png,pdf|max:10000'
            ]);

            foreach ($request->farmer_name as $key => $name) {
                if (!empty($request->file('aadhar_card')[$key])) {
                    if (!empty($request->aadhar_card_edit[$key])) {
                        $imagePath = public_path('farmer/aadhar_card/') . $request->aadhar_card_edit[$key];
                        deleteOldImage($request->aadhar_card_edit[$key], $imagePath);
                    }
                    $documentRootPath = 'public/farmer/aadhar_card';
                    $file_path = time() . rand() . '.' . $request->file('aadhar_card')[$key]->getClientOriginalExtension();
                    $request->file('aadhar_card')[$key]->move($documentRootPath, $file_path);
                    $aadhar_card = $file_path;
                } else {
                    $aadhar_card = $request->aadhar_card_edit[$key];
                }



                $newUser = AtFarmerRegDetail::updateOrCreate(
                    [
                        'at_user_id' => $id,
                        'email_id' => $request->email[$key],
                        'mobile_no' => $request->mobile_no[$key],
                    ],
                    [
                        'at_user_id' => $id,
                        'farmer_first_name' => $name,
                        'email_id' => $request->email[$key],
                        'mobile_no' => $request->mobile_no[$key],
                        'farmer_address' => $request->address[$key],
                        'ref_village_id' => $request->village[$key],
                        'ref_block_tehsil_id' => $request->taluka[$key],
                        'ref_district_id' => $request->district[$key],
                        'ref_state_id' => $request->state[$key],
                        'pin' => $request->pincode[$key],
                        'aadhar_number' => $aadhar_card,
                        'landmark' => $request->land_address[$key],
                        // 'pan_card' => $pan_card,
                        // 'address_proof_of_office' => $request->address_proof_of_office,
                        // 'address_proof_of_office_doc' => $address_proof_of_office_doc,
                        // 'profile_photo' => $profile_photo,
                        // 'appointment_doc' => $appointment_doc,
                        'created_by' => Auth::guard('misadmin')->user()->id,
                        'updated_by' => Auth::guard('misadmin')->user()->id
                    ]
                );
            }

            User::where('id', Auth::guard('misadmin')->user()->id)->update(['status' => 0]);

            if ($request->roleid == 2) {
                Alert::success('Success', __('message.add_success'));
                return redirect()->route('superadmin.icsuser.preview', $id);
                //return redirect()->route('superadmin.icsuser.step4',$user->id)->with('success', __('message.add_third_success'));
            } else {
                Alert::success('Success', __('message.add_success'));
                return redirect()->back();
                //return redirect()->back()->with('success', __('message.add_success'));
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }
    public function step3postajax(Request $request)
    {
        // dd($request->all());
        $a = $request->all();
        // dd($a);
        $rules = [
            'aadhar_number.*' => 'required',
            'farmer_name.*' => 'required',
            'gender.*' => 'required',
            'father_flag.*' => 'required',
            'father_name.*' => 'required',
            'number_of_farm.*' => 'required',
            'total_Area.*' => 'required',
            'survey.*' => 'required',
            'mobile_no.*' => 'required',
            'email.*' => 'required',
            'address.*' => 'required',
            'village.*' => 'required',
            'taluka.*' => 'required',
            'state.*' => 'required',
            'district.*' => 'required',
            'pincode.*' => 'required',
            'land_address.*' => 'required'
        ];
        $validator = Validator::make($a, $rules);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 400);
        }

        try {

            foreach ($a['farmer_name'] as $key => $name) {


                $newUser = AtFarmerRegDetail::updateOrCreate(
                    [
                        'id' => !empty($a['at_farmer_reg_details_id'][$key]) ? $a['at_farmer_reg_details_id'][$key] : NULL,
                    ],
                    [
                        'at_user_id' => $a['userid'],
                        'at_ics_inspector_id' => $a['user_inspector_id'],
                        'farmer_first_name' => $name,
                        'land_holding_type' => $a['land_holding_type'][$key],
                        'email_id' => $a['email'][$key],
                        'mobile_no' => $a['mobile_no'][$key],
                        'farmer_address' => $a['address'][$key],
                        'ref_village_id' => $a['village'][$key],
                        'ref_block_tehsil_id' => $a['taluka'][$key],
                        'ref_district_id' => $a['district'][$key],
                        'ref_state_id' => $a['state'][$key],
                        'pin' => $a['pincode'][$key],
                        'aadhar_number' => $a['aadhar_number'][$key],
                        'landmark' => $a['land_address'][$key],
                        'gender' => $a['gender'][$key],
                        'father_husband_flag' => $a['father_flag'][$key],
                        'father_husband_first_name' => $a['father_name'][$key],
                        'no_of_farm' => $a['number_of_farm'][$key],
                        'created_by' => Auth::guard('misadmin')->user()->id,
                        'updated_by' => Auth::guard('misadmin')->user()->id
                    ]
                );
                $reg_no = getFarmerRegNo($newUser->id, $a['state'][$key]);
                AtFarmerRegDetail::where('id', $newUser->id)->update(['registration_no' => $reg_no, 'owner_farmerid' => $reg_no]);

                foreach ($a['survey'] as $key1 => $survey) {
                    $farm = AtFarmerLandDetail::updateOrCreate(
                        [
                            'at_farmer_reg_details_id' => $newUser->id,
                            'survay_no' => $survey
                        ],
                        [
                            'at_farmer_reg_details_id' => $newUser->id,
                            'survay_no' => $survey,
                            'ref_village_id' => $a['ref_village_id'][$key1],
                            'ref_block_tehsil_id' => $a['ref_block_tehsil_id'][$key1],
                            'ref_district_id' => $a['ref_district_id'][$key1],
                            'ref_state_id' => $a['ref_state_id'][$key1],
                            'pin' => $a['pin'][$key1],
                            'area_in_ha' => $a['total_Area'][$key1],
                            'total_area' => $a['total_Area'][$key1],
                            'created_by' => Auth::guard('misadmin')->user()->id,
                            'updated_by' => Auth::guard('misadmin')->user()->id
                        ]
                    );

                    $farmreg_no = getFarmRegNo($farm->id, $a['ref_state_id'][$key1]);
                    AtFarmerLandDetail::where('id', $farm->id)->update(['registration_no' => $farmreg_no, 'farm_no' => $farmreg_no]);
                }
            }
            return response()->json(['success' => 1], 200);
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function step4($id)
    {
        //dd('sfs');
        $userdetails = User::find($id);
        $cbstate = User::where('id', $userdetails->created_by)->first();


        $userinsdetail = UserInspector::where('at_user_id', $id)->get();

        // dd($userinsdetail);
        $states = RefState::orderBy('state_name', 'ASC')->get();
        $districts = RefDistrict::where('ref_state_id', $userdetails->ref_state_id)->orderBy('district_name', 'ASC')->get();
        $regions = RefRegion::where('ref_state_id', $userdetails->ref_state_id)->orderBy('block_tehsil_name', 'ASC')->get();
        $villages = RefVillage::where('ref_district_id', $userdetails->ref_district_id)->orderBy('village_name', 'ASC')->get();
        return view('admin.ics.icsstep4', compact('states', 'districts', 'regions', 'villages', 'userdetails', 'userinsdetail', 'cbstate'));
        // }else{
        //     return view('admin.profile');
        // }
    }

    public function step4post(Request $request, $id)
    {


        //  dd($request->all());
        try {

            $request->validate([
                'inspector_name' => 'required|array|',
                'email.*' => 'required|email',
                'mobile_no' => 'required|array|',
                'address' => 'required|array|',
                'village' => 'required|array|',
                'taluka' => 'required|array|',
                'state' => 'required|array|',
                'district' => 'required|array|',
                'pincode' => 'required|array|',
                'address' => 'required|array|',
                'qualification' => 'required|array|',
                // 'id_proof_doc' => 'required|array|',
                // 'aadhar_card' => 'mimes:jpeg,jpg,png,pdf,xlx,csv|max:10000',
                // 'pan_card' => 'mimes:jpeg,jpg,png,pdf,xlx,csv|max:10000',
                //'address_proof_of_office_doc' => 'mimes:jpeg,jpg,png,pdf,xlx,csv|max:10000',
                //'profile_photo' => 'mimes:jpeg,jpg,png,pdf,xlx,csv|max:10000',
                //'appointment_doc' => 'mimes:jpeg,jpg,png,pdf,xlx,csv|max:10000',

            ]);

            if (isset($request->inspector_name)) {


                $i = 0;
                $emails  = '';
                foreach ($request->inspector_name as $key => $inspector_name) {
                    $aadhar_card = $pan_card = $profile_photo = $appointment_doc = $address_proof_of_office_doc = '';
                    if (!empty($request->file('aadhar_card')[$key])) {
                        if (!empty($request->aadhar_card_edit[$key])) {
                            $imagePath = public_path('inspector/aadhar_card/') . $request->aadhar_card_edit[$key];
                            deleteOldImage($request->aadhar_card_edit[$key], $imagePath);
                        }
                        $documentRootPath = 'public/inspector/aadhar_card';
                        $file_path = time() . rand() . '.' . $request->file('aadhar_card')[$key]->getClientOriginalExtension();
                        $request->file('aadhar_card')[$key]->move($documentRootPath, $file_path);
                        $aadhar_card = $file_path;
                    } else {
                        if (!empty($request->aadhar_card_edit[$key]))
                            $aadhar_card = $request->aadhar_card_edit[$key];
                    }

                    if (!empty($request->file('pan_card')[$key])) {
                        if (!empty($request->pan_card_edit[$key])) {
                            $imagePath = public_path('inspector/pan_card/') . $request->pan_card_edit[$key];
                            deleteOldImage($request->pan_card_edit[$key], $imagePath);
                        }
                        $documentRootPath = 'public/inspector/pan_card';
                        $file_path = time() . rand() . '.' . $request->file('pan_card')[$key]->getClientOriginalExtension();
                        $request->file('pan_card')[$key]->move($documentRootPath, $file_path);
                        $pan_card = $file_path;
                    } else {
                        if (!empty($request->pan_card_edit[$key]))
                            $pan_card = $request->pan_card_edit[$key];
                    }

                    if (!empty($request->file('address_proof_of_office_doc')[$key])) {
                        if (!empty($request->address_proof_of_office_doc_edit[$key])) {
                            $imagePath = public_path('inspector/address_proof_of_office_doc/') . $request->address_proof_of_office_doc_edit[$key];
                            deleteOldImage($request->address_proof_of_office_doc_edit[$key], $imagePath);
                        }
                        $documentRootPath = 'public/inspector/address_proof_of_office_doc';
                        $file_path = time() . rand() . '.' . $request->file('address_proof_of_office_doc')[$key]->getClientOriginalExtension();
                        $request->file('address_proof_of_office_doc')[$key]->move($documentRootPath, $file_path);
                        $address_proof_of_office_doc = $file_path;
                    } else {
                        if (!empty($request->address_proof_of_office_doc_edit[$key]))
                            $address_proof_of_office_doc = $request->address_proof_of_office_doc_edit[$key];
                    }

                    if (!empty($request->file('profile_photo')[$key])) {
                        if (!empty($request->profile_photo_edit[$key])) {
                            $imagePath = public_path('inspector/profile_photo/') . $request->profile_photo_edit[$key];
                            deleteOldImage($request->profile_photo_edit[$key], $imagePath);
                        }
                        $documentRootPath = 'public/inspector/profile_photo';
                        $file_path = time() . rand() . '.' . $request->file('profile_photo')[$key]->getClientOriginalExtension();
                        $request->file('profile_photo')[$key]->move($documentRootPath, $file_path);
                        $profile_photo = $file_path;
                    } else {
                        if (!empty($request->profile_photo_edit[$key]))
                            $profile_photo = $request->profile_photo_edit[$key];
                    }

                    if (!empty($request->file('appointment_doc')[$key])) {
                        if (!empty($request->appointment_doc_edit[$key])) {
                            $imagePath = public_path('inspector/appointment_doc/') . $request->appointment_doc_edit[$key];
                            deleteOldImage($request->appointment_doc_edit[$key], $imagePath);
                        }
                        $documentRootPath = 'public/inspector/appointment_doc';
                        $file_path = time() . rand() . '.' . $request->file('appointment_doc')[$key]->getClientOriginalExtension();
                        $request->file('appointment_doc')[$key]->move($documentRootPath, $file_path);
                        $appointment_doc = $file_path;
                    } else {
                        if (!empty($request->appointment_doc_edit[$key]))
                            $appointment_doc = $request->appointment_doc_edit[$key];
                    }

                    if (!empty($request->file('id_proof_doc')[$key])) {
                        if (!empty($request->id_proof_doc_edit[$key])) {
                            $imagePath = public_path('inspector/id_proof_doc/') . $request->id_proof_doc_edit[$key];
                            deleteOldImage($request->id_proof_doc_edit[$key], $imagePath);
                        }
                        $documentRootPath = 'public/inspector/id_proof_doc';
                        $file_path = time() . rand() . '.' . $request->file('id_proof_doc')[$key]->getClientOriginalExtension();
                        $request->file('id_proof_doc')[$key]->move($documentRootPath, $file_path);
                        $id_proof_doc = $file_path;
                    } else {
                        if (!empty($request->id_proof_doc_edit[$key]))
                            $id_proof_doc = $request->id_proof_doc_edit[$key];
                    }



                    // foreach ($request->aadhaar_no as $key => $contactPersonAadharNumberEncoded) {
                    //     if (isValidBase64(urldecode($contactPersonAadharNumberEncoded))) {
                    //         $contactPersonAadharNumber = base64_decode(urldecode($contactPersonAadharNumberEncoded));
                    //         $aadharno[$key] = Crypt::encrypt($contactPersonAadharNumber);
                    //     } else {
                    //         return redirect()->back();
                    //     }
                    // }


                    $password = rand(100000, 999999);
                    $data = array(
                        'at_user_id'   => $id,
                        'name_of_inspector' => !empty($request->inspector_name[$key]) ? $request->inspector_name[$key] : NULL,
                        'email' => !empty($request->email[$key]) ? $request->email[$key] : NULL,
                        'mobile_no' => !empty($request->mobile_no[$key]) ? $request->mobile_no[$key] : NULL,
                        // 'password' => hash('sha256', '123456'),
                        'address' => !empty($request->address[$key]) ? $request->address[$key] : NULL,
                        'ref_village_id' => !empty($request->village[$key]) ? $request->village[$key] : NULL,
                        'ref_block_tehsil_id' => !empty($request->taluka[$key]) ? $request->taluka[$key] : NULL,
                        'ref_district_id' => !empty($request->district[$key]) ? $request->district[$key] : NULL,
                        'ref_state_id' => !empty($request->state[$key]) ? $request->state[$key] : NULL,
                        'pin' => !empty($request->pincode[$key]) ? $request->pincode[$key] : NULL,
                        'aadhaar_no' => !empty($request->aadhaar_no[$key]) ? $request->aadhaar_no[$key] : NULL,

                        // 'id_proof' => $request->id_proof[$key],
                        // 'id_proof_doc' => $id_proof_doc,
                        'address_proof_of_office' => !empty($request->address_proof_of_office[$key]) ? $request->address_proof_of_office[$key] : NULL,
                        'address_proof_of_office_doc' => !empty($address_proof_of_office_doc) ? $address_proof_of_office_doc : NULL,
                        'profile_photo' => !empty($profile_photo) ? $profile_photo : NULL,
                        'appointment_doc' => !empty($appointment_do) ? $appointment_do : NULL,
                        'qualification' => !empty($request->qualification[$key]) ? $request->qualification[$key] : NULL,
                        'created_by' => Auth::guard('misadmin')->user()->id,
                        'updated_by' => Auth::guard('misadmin')->user()->id

                    );

                    //dd($data);

                    if (!empty($request->row_id[$key])) {
                        $data['updated_at'] = date('Y-m-d H:i:s');
                        $data['updated_by'] = Auth::guard('misadmin')->user()->id;
                        UserInspector::where('id', $request->row_id[$key])->where('at_user_id', $id)->update($data);
                        // if($request->email[$key]!=$request->hidden_email[$key]){
                        if ($request->email[$key]) {

                            $apklink = url('public/apeda-tracenet-24022023.apk');
                            $emails = $request->email[$key];
                            $maildata  = ['send_message' => "<strong> Dear " . $request->inspector_name[$key] . "</strong><br> You have registered successfully.<br> Your Credentials has given below :- <br><strong> Username : " . $request->mobile_no[$key] . " <br> <br><strong> Email : " . $request->email[$key] . " <br> Password : " . $password . "</strong> <br> <a href=" . $apklink . ">Click here </a>for download mobile application for farmer registration. "];

                            Mail::send('mail.inspector_register', $maildata, function ($message) use ($emails) {  // use mail template in view/api folder
                                $message->subject("Apeda Inspector Register"); // Email subject body
                                $message->to($emails);
                            });
                            $data['password'] = hash('sha256', $password);
                            UserInspector::where('id', $request->row_id[$key])->where('at_user_id', $id)->update($data);
                            $results = UserInspector::where('id', $request->row_id[$key])->where('at_user_id', $id)->first();

                            if ($results) {
                                DB::commit();
                                sendLoginDetailsSms($results->mobile_no, $results->name_of_inspector, $results->email);
                            }
                        } else {
                            UserInspector::where('id', $request->row_id[$key])->where('at_user_id', $id)->update($data);
                        }
                    } else {
                        ////send mail

                        $apklink = url('public/apk.jpg');
                        $apklink = url('public/apeda-tracenet-24022023.apk');
                        $emails = $request->email[$key];
                        $maildata  = ['send_message' => "<strong> Dear " . $request->inspector_name[$key] . "</strong><br> You have registered successfully.<br> Your Credentials has given below :- <br><strong> Username : " . $request->mobile_no[$key] . " <br> <br><strong> Email : " . $request->email[$key] . " <br> Password : " . $password . "</strong> <br> <a href=" . $apklink . ">Click here </a>for download mobile application for farmer registration. "];

                        Mail::send('mail.inspector_register', $maildata, function ($message) use ($emails) {  // use mail template in view/api folder
                            $message->subject("Apeda Inspector Register"); // Email subject body
                            $message->to($emails);
                        });

                        $data['created_by'] = Auth::guard('misadmin')->user()->id;
                        $data['created_at'] = date('Y-m-d H:i:s');
                        $data['password'] = hash('sha256', $password);

                        $results = UserInspector::create($data);


                        if ($results) {
                            DB::commit();
                            sendLoginDetailsSms($results->mobile_no, $results->name_of_inspector, $request->email[$key]);
                        }
                    }
                }
            }

            if ($request->roleid == 2) {
                Alert::success('Success', __('message.add_fourth_success'));
                return redirect()->route('superadmin.icsuser.step5', $id);
                //return redirect()->route('superadmin.icsuser.step5',$user->id)->with('success', __('message.add_fourth_success'));
            } else {
                Alert::success('Success', __('message.add_success'));
                return redirect()->back();
                //return redirect()->back()->with('success', __('message.add_success'));
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function step5($id)
    {
        // if(Auth::guard('misadmin')->user()->roles[0]->id == 2){
        $userdetails = User::find($id);
        $cbstate = User::where('id', $userdetails->created_by)->first();
        $warehs = UserWarehouse::where('at_user_id', $id)->first();
        $states = RefState::orderBy('state_name', 'ASC')->get();
        $districts = getDistrictByStateID($warehs->ref_state_id ?? '');
        $regions = getBlockTehsilByDistrictID($warehs->ref_district_id ?? '');
        $villages = getVillageByBlock($warehs->ref_block_tehsil_id ?? '');
        $wmanager = UserWarehouseManagerOfficers::where('at_user_id', $id)->where('user_type', 'WM')->get();
        $pmanager = UserWarehouseManagerOfficers::where('at_user_id', $id)->where('user_type', 'PM')->get();
        $foanager = UserWarehouseManagerOfficers::where('at_user_id', $id)->where('user_type', 'FO')->get();
        $amanager = UserWarehouseManagerOfficers::where('at_user_id', $id)->where('user_type', 'AM')->get();
        return view('admin.ics.icsstep5', compact('states', 'districts', 'regions', 'villages', 'userdetails', 'warehs', 'wmanager', 'pmanager', 'foanager', 'amanager', 'cbstate'));
        // }else{
        //     return view('admin.profile');
        // }
    }

    public function step5post(Request $request, $id)
    {
        // dd($request->all());
        try {

            $request->validate([
                // 'no_warehouse' => 'required',
                'warehouse_lic_no' => 'required',
                'area_warehouse' => 'required',
                'capacity' => 'required',
                'address' => 'required',
                'village' => 'required',
                'district' => 'required',
                'taluka' => 'required',
                'state' => 'required',
                'pincode' => 'required',
                // 'address_proof_of_office' =>'required',
                //'no_field_officers' =>'required',
                //  'address_proof_of_office_doc' => 'mimes:jpeg,jpg,png,pdf|max:1024', // 1MB = 1024 KB
                //  'office_building_photo' => 'mimes:jpeg,jpg,png,pdf|max:1024', // 1MB = 1024 KB

            ]);

            if ($request->hasFile('address_proof_of_office_doc')) {
                if (!empty($request->address_proof_of_office_doc_edit)) {
                    $imagePath = public_path('warehouse/address_proof_of_office_doc/') . $request->address_proof_of_office_doc_edit;
                    deleteOldImage($request->address_proof_of_office_doc_edit, $imagePath);
                }
                $documentRootPath = 'public/warehouse/address_proof_of_office_doc';
                $file_path = time() . rand() . '.' . $request->file('address_proof_of_office_doc')->getClientOriginalExtension();
                $request->file('address_proof_of_office_doc')->move($documentRootPath, $file_path);
                $address_proof_of_office_doc = $file_path;
            } else {
                $address_proof_of_office_doc = $request->address_proof_of_office_doc_edit;
            }

            if ($request->hasFile('office_building_photo')) {
                if (!empty($request->office_building_photo_edit)) {
                    $imagePath = public_path('warehouse/office_building_photo/') . $request->office_building_photo_edit;
                    deleteOldImage($request->office_building_photo_edit, $imagePath);
                }
                $documentRootPath = 'public/warehouse/office_building_photo';
                $file_path = time() . rand() . '.' . $request->file('office_building_photo')->getClientOriginalExtension();
                $request->file('office_building_photo')->move($documentRootPath, $file_path);
                $office_building_photo = $file_path;
            } else {
                $office_building_photo = $request->office_building_photo_edit;
            }

            $user = User::find($id);
            if (isset($user)) {
                $warehous = UserWarehouse::updateOrCreate([
                    'at_user_id'   => $id,
                ], [
                    'warehouse_available' => !empty($request->warehouse_available) ? $request->warehouse_available : NULL,
                    'number_of_warehouse' => !empty($request->no_warehouse) ? $request->no_warehouse : NULL,
                    'number_of_warehouse' => !empty($request->no_warehouse) ? $request->no_warehouse : NULL,
                    'licence_number' => !empty($request->warehouse_lic_no) ? $request->warehouse_lic_no : NULL,
                    'warehouse_area' => !empty($request->area_warehouse) ? $request->area_warehouse : NULL,
                    'capacity' => !empty($request->capacity) ? $request->capacity : NULL,
                    'address' =>  !empty($request->address) ? $request->address : NULL,
                    'ref_village_id' => !empty($request->village) ? $request->village : NULL,
                    'ref_district_id' => !empty($request->district) ? $request->district : NULL,
                    'ref_block_tehsil_id' => !empty($request->taluka) ? $request->taluka : NULL,
                    'ref_state_id' => !empty($request->state) ? $request->state : NULL,
                    'pin_code' => !empty($request->pincode) ? $request->pincode : NULL,
                    'address_proof_of_office' => !empty($request->address_proof_of_office) ? $request->address_proof_of_office : NULL,
                    'office_building_photo' =>  !empty($office_building_photo) ? $office_building_photo : NULL,
                    'address_proof_of_office_doc' => !empty($address_proof_of_office_doc) ? $address_proof_of_office_doc : NULL,
                    'no_field_officer' => !empty($request->no_field_officers) ? $request->no_field_officers : NULL,
                    'warehouse_type' => !empty($request->warehouse_type) ? $request->warehouse_type  : NULL,
                    'created_by' => Auth::guard('misadmin')->user()->id,
                    'updated_by' => Auth::guard('misadmin')->user()->id
                ]);
            }
            if ($warehous->id != '') {
                if (isset($request->wm_first_name)) {
                    foreach ($request->wm_first_name as  $i => $wm) {

                        UserWarehouseManagerOfficers::updateOrCreate([
                            'id'   => $request->wm_id[$i] ?? 0,
                        ], [
                            "at_user_id" => $id,
                            "at_ics_warehouse_details_id" => $warehous->id,
                            "first_name" => !empty($wm) ? $wm : NULL,
                            "middle_name" => !empty($request->wm_middle_name[$i]) ? $request->wm_middle_name[$i] : NULL,
                            "last_name" => !empty($request->wm_last_name[$i]) ? $request->wm_last_name[$i] : NULL,
                            "aadhar_card_number" => Crypt::encrypt($request->wm_aadhar[$i]),
                            "contact_number" =>  !empty($request->wm_mobile_no[$i]) ?  $request->wm_mobile_no[$i] : NULL,
                            "status" => 0,
                            "user_type" => 'WM',
                            "created_by" => Auth::guard('misadmin')->user()->id,
                            "created_at" => date('Y-m-d H:i:s'),
                            "updated_by" => Auth::guard('misadmin')->user()->id,
                            "updated_at" => date('Y-m-d H:i:s')
                        ]);
                    }
                }
            }


            if ($request->roleid == 2) {
                Alert::success('Success', __('message.add_fourth_success'));
                return redirect()->route('superadmin.icsuser.step6', $id);
                //return redirect()->route('superadmin.icsuser.step5',$user->id)->with('success', __('message.add_fourth_success'));
            } else {
                Alert::success('Success', __('message.add_success'));
                return redirect()->back();
                //return redirect()->back()->with('success', __('message.add_success'));
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function step6($id)
    {
        // if(Auth::guard('misadmin')->user()->roles[0]->id == 2){
        $userdetails = User::find($id);
        $cbstate = User::where('id', $userdetails->created_by)->first();
        $warehs = UserWarehouse::where('at_user_id', $id)->first();
        if (empty($warehs)) {
            Alert::info('Info', 'Please fill in the Warehouse/Godown details first');
            return redirect()->back(); 
        }
        $states = RefState::orderBy('state_name', 'ASC')->get();
        $districts = RefDistrict::where('ref_state_id', $userdetails->ref_state_id)->orderBy('district_name', 'ASC')->get();
        $regions = RefRegion::where('ref_state_id', $userdetails->ref_state_id)->orderBy('block_tehsil_name', 'ASC')->get();
        $villages = RefVillage::where('ref_district_id', $userdetails->ref_district_id)->orderBy('village_name', 'ASC')->get();
        $pmanager = UserWarehouseManagerOfficers::where('at_user_id', $id)->where('user_type', 'PM')->get();
        $foanager = UserWarehouseManagerOfficers::where('at_user_id', $id)->where('user_type', 'FO')->get();
        $amanager = UserWarehouseManagerOfficers::where('at_user_id', $id)->where('user_type', 'AM')->first();
        return view('admin.ics.icsstep6', compact('states', 'districts', 'regions', 'villages', 'userdetails', 'warehs', 'pmanager', 'foanager', 'amanager', 'cbstate'));
        // }else{
        //     return view('admin.profile');
        // }
    }

    public function step6post(Request $request, $id)
    {
      
        try {
            if (!empty($request->at_ics_warehouse_details_id)) {

                // Processing PM data   pm_aadhar   Crypt::encrypt  pm_aadhar
                if (isset($request->pm_name) && is_array($request->pm_name)) {

                    foreach ($request->pm_name as  $i => $pm) {
                        if (!empty($request->pm_name[$i]) && !empty($request->pm_aadhar[$i]) && !empty($request->pm_mobile_no[$i])) {
                            UserWarehouseManagerOfficers::updateOrCreate([
                                'id'   => !empty($request->pm_id[$i]) ? $request->pm_id[$i] : null,  // Fix: set id to null if empty
                            ], [
                                "at_user_id" => $id,
                                "at_ics_warehouse_details_id" => $request->at_ics_warehouse_details_id,
                                "first_name" => $request->pm_name[$i],
                                "middle_name" => $request->pm_middle_name[$i] ?? null,
                                "last_name" => $request->pm_last_name[$i] ?? null,
                                "aadhar_card_number" => Crypt::encrypt($request->pm_aadhar[$i]),
                                "contact_number" => $request->pm_mobile_no[$i],
                                "status" => 0,
                                "user_type" => 'PM',
                                "created_by" => Auth::guard('misadmin')->user()->id,
                                "created_at" => now(),
                                "updated_by" => Auth::guard('misadmin')->user()->id,
                                "updated_at" => now(),
                            ]);
                        }
                    }
                }

                // Processing FO data
                if (isset($request->fo_name) && is_array($request->fo_name)) {
                    $i = 0;
                    foreach ($request->fo_name as $fo) {
                        if (!empty($request->fo_name[$i]) && !empty($request->fo_aadhar[$i]) && !empty($request->fo_mobile_no[$i])) {
                            UserWarehouseManagerOfficers::updateOrCreate([
                                'id'   => !empty($request->fo_id[$i]) ? $request->fo_id[$i] : null,   
                            ], [
                                "at_user_id" => $id,
                                "at_ics_warehouse_details_id" => $request->at_ics_warehouse_details_id,
                                "first_name" => $request->fo_name[$i],
                                "middle_name" => $request->fo_middle_name[$i] ?? null,
                                "last_name" => $request->fo_last_name[$i] ?? null,
                                "aadhar_card_number" => Crypt::encrypt($request->fo_aadhar[$i]),
                                "contact_number" => $request->fo_mobile_no[$i++],
                                "status" => 0,
                                "user_type" => 'FO',
                                "no_field_officer" => $request->no_field_officers ?? 0,
                                "created_by" => Auth::guard('misadmin')->user()->id,
                                "created_at" => now(),
                                "updated_by" => Auth::guard('misadmin')->user()->id,
                                "updated_at" => now(),
                            ]);
                        }
                    }
                }

                // Processing AM data
                if (!empty($request->am_id) || isset($request->am_id)) {
                    UserWarehouseManagerOfficers::updateOrCreate([
                        'id'   => !empty($request->am_id) ? $request->am_id : null,
                    ], [
                        "at_user_id" => $id,
                        "at_ics_warehouse_details_id" => $request->at_ics_warehouse_details_id,
                        "first_name" => !empty($request->am_name) ? $request->am_name : NULL,
                        "middle_name" => !empty($request->am_middle_name) ? $request->am_middle_name : NULL,
                        "last_name" => !empty($request->am_last_name) ? $request->am_last_name : NULL,
                        "email_id" => !empty($request->email_id) ? $request->email_id : NULL,
                        "am_aadhar_number" => !empty(Crypt::encrypt($request->am_aadhar)) ? $request->am_aadhar : NULL,
                        "contact_number" => !empty($request->am_mobile_no) ? $request->am_mobile_no : NULL,
                        "status" => 0,
                        "user_type" => 'AM',
                        "created_by" => Auth::guard('misadmin')->user()->id,
                        "created_at" => now(),
                        "updated_by" => Auth::guard('misadmin')->user()->id,
                        "updated_at" => now(),
                    ]);
                }

                // Handling new user creation if AM ID is not provided
                if (empty($request->am_id) && !empty($request->email_id)) {
                    if (User::where('email', $request->email_id)->count() > 0) {
                        $request->validate([
                            'email' => 'required|email|unique:at_user'
                        ]);
                        // Alert::info('Info', 'The email is already taken.');
                        return  back();
                    } else {
                        $data = [
                            'ref_operator_type_id' => '7',
                            'first_name' => $request->am_name,
                            'middle_name' => $request->am_middle_name ?? null,
                            'last_name' => $request->am_last_name ?? null,
                            'user_name' => $request->email_id,
                            'password' => hash('sha256', 123456),
                            'email' => $request->email_id,
                            'mobile_no' => $request->am_mobile_no,
                            'user_type' => 1,
                            'status' => 1,
                            'created_by' => Auth::guard('misadmin')->user()->id,
                        ];
                        $user = User::create($data);
                        if ($user) {
                            $user->roles()->attach('7');
                        }
                    }
                }

                Alert::success('Success', __('message.add_success'));
                return redirect()->route('superadmin.icsuser.step3', $id);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }




    public function icspreview(Request $request, $id)
    {
        $user = User::where('id', $id)->first();


        // if($user->status == 0){
        //     User::where('id',$id)->update(['status'=>1]);
        // }


        $icsmandator = IcsMandator::where('at_user_id', $id)->first();
        $userInsp = UserInspector::where('at_user_id', $id)->get();
        ///dd($userInsp);
        $warehs = UserWarehouse::where('at_user_id', $id)->first();

        $wmanager = UserWarehouseManagerOfficers::where('at_user_id', $id)->where('user_type', 'WM')->get();
        $pmanager = UserWarehouseManagerOfficers::where('at_user_id', $id)->where('user_type', 'PM')->get();
        $foanager = UserWarehouseManagerOfficers::where('at_user_id', $id)->where('user_type', 'FO')->get();
        $amanager = UserWarehouseManagerOfficers::where('at_user_id', $id)->where('user_type', 'AM')->first();
        $farmerDetails = AtFarmerRegDetail::where('at_user_id', $id)->get();
        // dd($farmerDetails);
        $states = RefState::orderBy('state_name', 'ASC')->get();

        return view('admin/ics/preview', compact('id', 'user', 'icsmandator', 'warehs', 'states', 'userInsp', 'wmanager', 'pmanager', 'foanager', 'amanager', 'farmerDetails'));
    }

    public function previewpost(Request $request)
    {
        try {
            //dd($request->all());
            if ($request->at_user_id != '') {

                User::where('id', $request->at_user_id)->update(['status' => 1]);
                //   Notification::create(

                //   );
            }
            Alert::success('Success', __('message.add_success'));
            return redirect()->back();
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }
    public function addIcs($id)
    {
        return view('admin/usermanagement/deptUser/addIcs', compact('id'));
    }
    public function deptUserEdit(Request $request, $id)
    {
        $user = User::where('id', $id)->first();
        return view('admin/usermanagement/deptUser/edit', compact('user'));
    }

    public function deptUserUpdate(Request $request, $id)
    {
        $request->validate([
            'first_name' => 'required',
            'middle_name' => 'required',
            'last_name' => 'required',
            // 'ref_office_id' => 'required',
            // 'status' => 'required',
        ]);
        try {
            $user = User::find($id);
            $user->first_name = $request->first_name;
            $user->middle_name = $request->middle_name;
            $user->last_name = $request->last_name;

            $user->contact_first_name = $request->contact_first_name;
            $user->contact_middle_name = $request->contact_middle_name;
            $user->contact_last_name = $request->contact_last_name;
            $user->address = $request->address;
            $user->village = $request->village;
            $user->taluka = $request->taluka;
            // $user->city = $request->city;
            $user->district = $request->district;
            $user->state = $request->state;
            $user->pin_code = $request->pin_code;

            $user->user_type = 1;
            $user->ref_office_id = $request->ref_office_id;
            // $user->status = $request->status;
            $user->created_by = Auth::guard('misadmin')->user()->id;
            $user->save();

            if ($user) {
                $user->roles()->attach($request->role_id);
            }
            Alert::success('Success', __('message.add_success'));
            return redirect()->back();
            // return redirect()->back()->with('success', __('message.add_success'));
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function deptUserDelete(Request $request)
    {
        try {
            $id = $request->id;
            $user = User::find($id);
            $user->is_deleted = 1;
            $user->deleted_at = date('Y-m-d H:i:s');
            $user->save();
            return json_encode(['message' => 'done']);
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }
    public function storeMedia(Request $request)
    {

        /*$validator = Validator::make($request->all(), [
                'file' => 'required|mimes:jpeg,jpg,png,pdf,doc,gif,docx,mp4,uvu,mp4s,avi
                          |mimetypes:image/jpeg,image/jpg,image/png,application/pdf,application/msword,image/gif,
                          application/vnd.openxmlformats-officedocument.wordprocessingml.document,video/vnd.uvvu.mp4,
                          application/mp4,video/mp4,video/x-msvideo',
        ]);

        if($validator->fails()){
            return Response::make($validator->errors()->first(), 400);
        }*/

        try {
            $path = 'public/research/uploads';
            if (!file_exists($path)) {
                mkdir($path, 0777, true);
            }

            $file = $request->file('file');
            $name = uniqid() . '_' . trim($file->getClientOriginalName());

            /*Custom Validation Vikash Chaudhary 17/11/2020*/

            $file_name = (isset($_FILES['file']['name']) && !empty($_FILES['file']['name'])) ? $_FILES['file']['name'] : "";
            $file_tmp_name = (isset($_FILES['file']['tmp_name']) && !empty($_FILES['file']['tmp_name'])) ? $_FILES['file']['tmp_name'] : "";

            $mime = $file->getMimeType();

            $file_array = array(
                'file_name' => $file_name,
                'file_tmp_name' => $file_tmp_name,
                'file_mime_type' => $mime,
            );
            $data = getimagesize($file_tmp_name);
            if ($data != false) {
                $width = $data[0];
                $height = $data[1];
            } else {
                $width = '';
                $height = '';
            }

            // $checkFileUpload = checkUploadFileContent($file_array);


            // if (!empty($checkFileUpload)) {
            //     if (isset($checkFileUpload['error']) && $checkFileUpload['error'] == 1) {
            //         return Response::make($checkFileUpload['message'], 400);
            //     }
            // }

            $file->move($path, $name);

            if (in_array($file->getClientOriginalExtension(), ['pdf', 'png', 'jpg', 'jpeg', 'PNG', 'JPG', 'JPEG', 'mp4', 'MP4'])) {
                $image = str_replace(asset('/'), '', $path . '/' . $name);
                $path = $path . '/' . $name;
                $image = str_replace('', '_', urldecode($image));

                $image = explode('/', $image);
                $name = end($image);

                # Generate thumbs of the images

                # Check image size
                if ($width != '') {
                    // $this->createThumb($path, $width, $height, str_replace('', '_', $name), false);
                }
                // slider
                // $this->createThumb($path, 378, 194, 'thumb_378X194_' . str_replace('', '_', $name), true); //campaign home page slider
                // $this->createThumb($path, 75, 76, 'thumb_511X341_' . str_replace('', '_', $name), true); //blog page slider home page
                // $this->createThumb($path, 931, 214, 'thumb_931X214_' . str_replace('', '_', $name), true); //Blog Page Details page
                // $this->createThumb($path, 511, 341, 'thumb_511X341_' . str_replace('', '_', $name), true); // Blog Listing Page
                // $this->createThumb($path, 267, 183, 'thumb_267X183_' . str_replace('', '_', $name), true); // Event Home page slider
                // $this->createThumb($path, 261, 251, 'thumb_261X251_' . str_replace('', '_', $name), true); // compatation winners home page
                // $this->createThumb($path, 369, 186, 'thumb_369X186_' . str_replace('', '_', $name), true); // AVCC Slider home page
            } else {
                dd('no');
            }

            return response()->json([
                'name' => $name,
                'original_name' => $file->getClientOriginalName(),
            ]);
        } catch (Exception $e) {
            Log::error($e);
            return Response::make('File not Uploaded', 400);
            // $flash = array('flag' => 'success', 'message' => );
            // return back()->with('flash', $flash);
        }
    }


    public function deletewarehousebyid(Request $request)
    {
        try {
            $id = $request->id;
            $user = UserWarehouseManagerOfficers::where('id', $id)->first();
            if ($user) {
                $user->delete();
                return json_encode(['message' => 'done']);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }
    public function uniqueEmailMobile(Request $request)
    {
        $email_id = $request->email_id;
        $mobile_no = $request->mobile;

        if (!empty($email_id)) {
            if (UserInspector::where('email', $email_id)->where('deleted_at', null)->count() > 0) {
                return 1;
            }
        }
        if (!empty($mobile_no)) {
            if (UserInspector::where('mobile_no', $mobile_no)->where('deleted_at', null)->count() > 0) {
                return 2;
            }
        }
    }

    public function deleteInspector(Request $request)
    {
        try {

            $user = UserInspector::where('id', $request->id)->delete();
            return 1;
        } catch (Exception $e) {
            Log::error($e->getMessage());
            \Log::error($e->getMessage());
            abort('404');
        }
    }

    public function inspectorList(Request $request)
    {
        $id = Auth::user()->id;


        // dd($id);
        //abort_unless(\Gate::allows('user_access'), 403);
        try {
            $userId = Auth::id();
            $user = User::where('id', $userId)->first();
            if (empty($user->registration_no && $user->status == '2')) {
                Alert::info('Info', 'Please! Complete your profile to Apply for the Schedule Registration / Inspector.');
                return redirect()->back();
            }
            if ($request->ajax()) {
                $totalData =  UserInspector::with('farmersRegSchedule')->where('at_user_id', $id)->get();
                //dd($totalData);
                return Datatables::of($totalData)
                    ->addIndexColumn()
                    ->addColumn('name', function ($row) {

                        return $row->name_of_inspector ?? '';
                    })
                    ->addColumn('email', function ($row) {
                        return $row->email ?? '';
                        // }) ->addColumn('mobile', function($row){
                        //      return $row->mobile_no ?? '';
                    })->addColumn('start_date', function ($row) {
                        $fromdate = 'N/A';
                        if (isset($row->farmersRegSchedule->schedule_period_from) && !empty($row->farmersRegSchedule->schedule_period_from)) {
                            $fromdate = date('d-m-Y', strtotime($row->farmersRegSchedule->schedule_period_from)) ?? '';
                        }
                        return $fromdate;
                    })->addColumn('end_date', function ($row) {
                        $todate = 'N/A';
                        if (isset($row->farmersRegSchedule->schedule_period_to) && !empty($row->farmersRegSchedule->schedule_period_to)) {
                            $todate = date('d-m-Y', strtotime($row->farmersRegSchedule->schedule_period_to)) ?? '';
                        }
                        return $todate;
                    })->addColumn('total', function ($row) {
                        $total = FarmersRegSchedule::where('at_ics_inspector_details_id', $row->id)->sum('number_of_farmer_reg');
                        if ($total > 0)
                            return $total;
                        else
                            return 'N/A';
                    })->addColumn('attempt', function ($row) {

                        $from = $row->farmersRegSchedule->schedule_period_from ?? '';
                        $to = $row->farmersRegSchedule->schedule_period_to ?? '';
                        $village = $row->farmersRegSchedule->ref_village_id ?? '';

                        $attempt = '0';
                        if ($from != '' && $to != '') {
                            $attempt = AtFarmerRegDetail::whereBetween('registration_date', [$from, $to])->where(['at_ics_inspector_id' => $row->id])->count();
                        }
                        if ($attempt > 0)
                            return $attempt;
                        else
                            return 'N/A';
                    })
                    ->addColumn('action', function ($row) {
                        $total = FarmersRegSchedule::where('at_ics_inspector_details_id', $row->id)->sum('number_of_farmer_reg');
                        $from = $row->farmersRegSchedule->schedule_period_from ?? '';
                        $to = $row->farmersRegSchedule->schedule_period_to ?? '';
                        $village = $row->farmersRegSchedule->ref_village_id ?? '';
                        $attempt = '0';
                        if ($from != '' && $to != '') {
                            $attempt = AtFarmerRegDetail::whereBetween('registration_date', [$from, $to])->where(['at_ics_inspector_id' => $row->id])->count();
                        }

                        $actionBtn = '';
                        $today = date('Y-m-d');
                        if (($total != $attempt) &&  ($today > $to)) {
                            $actionBtn = '<a href=' . route('superadmin.icsuser.inspectorSchedule', $row->id) . '>Re-Schedule</a>';
                        }
                        $actionBtn .= '
                            <a href=' . route('superadmin.icsuser.inspectorSchedule', $row->id) . '><span><i class="mdi mdi-plus-box text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Add Schedule"></i></span></a>
                            <a href=' . route('superadmin.icsuser.inspectorSchedule', $row->id) . '><span><i class="mdi mdi-pencil text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Edit/Update Schedule"></i></span></a>
                            <a href="JavaScript:void(0);" class="deletedata" onclick="confirmDelete_(' . $row->id . ')"
                            alt="Remove"><span><i class="mdi mdi-delete-circle text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Delete"></i></span></a>';
                        return $actionBtn;
                    })
                    ->rawColumns(['action'])
                    ->make(true);
            }
            return view('admin/ics/farmer-reg-schedule-list');
        } catch (Exception $e) {
            return redirect()->back();
        } catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
            return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
        }
    }


    public function inspectorSchedule($id)
    {
        $scheduleDetails = FarmersRegSchedule::where('at_ics_inspector_details_id', $id)->get();
        //dd($scheduleDetails);
        $inspId = Auth::guard('misadmin')->user()->id;
        $states = RefState::orderBy('state_name', 'ASC')->get();
        // $districts = RefDistrict::orderBy('district_name','ASC')->get();
        // $regions = RefRegion::orderBy('block_tehsil_name','ASC')->get();
        //$villages = RefVillage::orderBy('village_name','ASC')->limit(100)->get();
        return view('admin/ics/farmer-reg-schedule-add', compact('scheduleDetails', 'states', 'id', 'inspId'));
    }

    public function inspectorSchedulePost(Request $request)
    {
        $request->validate([
            'schedule_period_from' => 'required',
            'schedule_period_to' => 'required',
            'number_of_farmer_reg' => 'required',
            'ref_state_id' => 'required|array|',
            'ref_district_id' => 'required|array|',
            'ref_block_tehsil_id' => 'required|array|',
            'ref_village_id' => 'required|array|',
        ]);
        try {

            if (isset($request->ref_state_id)) {
                foreach ($request->ref_state_id as $key => $ref_state_id) {
                    $data = array(
                        'at_ics_inspector_details_id'   => $request->at_ics_inspector_details_id,
                        'at_user_id' => $request->at_user_id,
                        'schedule_period_from' => $request->schedule_period_from,
                        'schedule_period_to' => $request->schedule_period_to,
                        'number_of_farmer_reg' => $request->number_of_farmer_reg[$key],
                        'ref_state_id' => $request->ref_state_id[$key],
                        'ref_district_id' => $request->ref_district_id[$key],
                        'ref_block_tehsil_id' => $request->ref_block_tehsil_id[$key],
                        'ref_village_id' => $request->ref_village_id[$key],
                        'created_by' => Auth::guard('misadmin')->user()->id,
                        'updated_by' => Auth::guard('misadmin')->user()->id
                    );

                    if (!empty($request->row_id[$key])) {
                        $data['updated_at'] = date('Y-m-d H:i:s');
                        $data['updated_by'] = Auth::guard('misadmin')->user()->id;
                        FarmersRegSchedule::where('id', $request->row_id[$key])->where('at_user_id', $request->at_user_id)->update($data);
                    } else {
                        $data['created_by'] = Auth::guard('misadmin')->user()->id;
                        $data['created_at'] = date('Y-m-d H:i:s');
                        FarmersRegSchedule::create($data);
                    }
                }

                $villages = array();
                for ($i = 0; $i < count($request->ref_village_id); $i++) {
                    $villages[] = get_village_name_by_id($request->ref_village_id[$i]);
                }
                $village_name = implode(", ", $villages);

                $emails = getInspectorName($request->at_ics_inspector_details_id)->email ?? '';
                $maildata  = ['send_message' => "You have been scheduled for villages " . $village_name . " for the registration process of farmers."];

                // Mail::send('mail.inspector_register', $maildata, function ($message) use ($emails) {  // use mail template in view/api folder
                //     $message->subject("Apeda Inspector Farmers Registration Schedule"); // Email subject body
                //     $message->to($emails);
                // });

                Alert::success('Success', __('message.add_success'));
                return redirect()->route('superadmin.icsuser.inspectorList');
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function deleteSchedule(Request $request)
    {
        try {
            // dd($request->all());
            $user = FarmersRegSchedule::where('id', $request->id)->delete();
            return 1;
        } catch (Exception $e) {
            Log::error($e->getMessage());
            \Log::error($e->getMessage());
            abort('404');
        }
    }

    /////inspector schedule



    public function inspectorSchList(Request $request)
    {
        $id = Auth::user()->id;
        //abort_unless(\Gate::allows('user_access'), 403);
        $userSts = getUserById($id)->status ?? '';


        if ($request->ajax()) {
            $totalData =  UserInspector::with('farmersInspSchedule')->where('at_user_id', $id)->get();
            //dd($totalData);
            return Datatables::of($totalData)
                ->addIndexColumn()
                ->addColumn('name', function ($row) {

                    return $row->name_of_inspector ?? '';
                })
                ->addColumn('email', function ($row) {
                    return $row->email ?? '';
                })->addColumn('start_date', function ($row) {
                    $fromdate = 'N/A';
                    if (isset($row->farmersInspSchedule->schedule_period_from) && !empty($row->farmersInspSchedule->schedule_period_from)) {
                        $fromdate = date('d-m-Y', strtotime($row->farmersInspSchedule->schedule_period_from)) ?? '';
                    }
                    return $fromdate;
                })->addColumn('end_date', function ($row) {
                    $todate = 'N/A';
                    if (isset($row->farmersInspSchedule->schedule_period_to) && !empty($row->farmersInspSchedule->schedule_period_to)) {
                        $todate = date('d-m-Y', strtotime($row->farmersInspSchedule->schedule_period_to)) ?? '';
                    }
                    return $todate;
                })->addColumn('total', function ($row) {
                    $total = InspectionSchedule::where('at_ics_inspector_details_id', $row->id)->sum('number_of_farmers');
                    if ($total > 0)
                        return $total;
                    else
                        return 'N/A';
                })->addColumn('attempt', function ($row) {
                    $total = InspectionSchedule::where('at_ics_inspector_details_id', $row->id)->sum('total_attempt');
                    if ($total > 0)
                        return $total;
                    else
                        return 'N/A';
                })
                ->addColumn('action', function ($row) {
                    $total = InspectionSchedule::where('at_ics_inspector_details_id', $row->id)->sum('number_of_farmers');
                    $from = $row->farmersInspSchedule->schedule_period_from ?? '';
                    $to = $row->farmersInspSchedule->schedule_period_to ?? '';
                    $village = $row->farmersInspSchedule->ref_village_id ?? '';
                    $attempt = '';
                    if ($from != '' && $to != '') {
                        $attempt = AtFarmerRegDetail::whereBetween('registration_date', [$from, $to])->where(['at_ics_inspector_id' => $row->id])->count();
                    }
                    $actionBtn = '';
                    $today = date('Y-m-d');
                    if (($total != $attempt) &&  ($today > $to)) {
                        //$actionBtn = '<a href='.route('superadmin.icsuser.inspectorInspSchedule',$row->id).'>Re-Schedule</a>';
                    }
                    $user_Sts = getUserById($row->at_user_id)->status ?? '';
                    if ($user_Sts == 2) {
                        $actionBtn .= '
                        <a href=' . route('superadmin.icsuser.inspectorInspSchedule', $row->id) . '><span><i class="mdi mdi-plus-box text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Add Schedule"></i></span></a>
                        <a href=' . route('superadmin.icsuser.inspectorInspSchedule', $row->id) . '><span><i class="mdi mdi-pencil text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Edit/Update Schedule"></i></span></a>
                        <a href="JavaScript:void(0);" class="deletedata" onclick="confirmDelete_(' . $row->id . ')"
                        alt="Remove"><span><i class="mdi mdi-delete-circle text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Delete"></i></span></a>';
                    }
                    return $actionBtn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        return view('admin/ics/inspector-schedule-list', compact('userSts'));
    }


    public function inspectorInspSchedule($id)
    {
        $scheduleDetails = InspectionSchedule::where('at_ics_inspector_details_id', $id)->get();

        //$reg_villages = AtFarmerRegDetail::select('ref_village_id')->where('at_ics_inspector_id',$id)->get();
        $reg_villages = FarmersRegSchedule::select('ref_village_id')->where('at_ics_inspector_details_id', $id)->get();
        $user_id = Auth::guard('misadmin')->user()->id;
        $states = RefState::orderBy('state_name', 'ASC')->get();
        //$districts = RefDistrict::orderBy('district_name','ASC')->get();
        //$regions = RefRegion::orderBy('block_tehsil_name','ASC')->get();
        // $villages = RefVillage::orderBy('village_name','ASC')->limit(100)->get();
        return view('admin/ics/inspector-schedule-add', compact('scheduleDetails', 'states', 'id', 'user_id', 'reg_villages'));
    }

    public function inspSchedulePost(Request $request)
    {

        $request->validate([
            'schedule_period_from' => 'required',
            'schedule_period_to' => 'required',
            'number_of_farmers' => 'required',
            'ref_state_id' => 'required|array|',
            'ref_district_id' => 'required|array|',
            'ref_block_tehsil_id' => 'required|array|',
            'ref_village_id' => 'required|array|',
        ]);
        try {

            if (isset($request->number_of_farmers)) {
                foreach ($request->number_of_farmers as $key => $number_of_farmers) {
                    $data = array(
                        'at_ics_inspector_details_id'   => $request->at_ics_inspector_details_id,
                        'at_user_id' => Auth::guard('misadmin')->user()->id,
                        'schedule_period_from' => $request->schedule_period_from,
                        'schedule_period_to' => $request->schedule_period_to,
                        'number_of_farmers' => $request->number_of_farmers[$key],
                        'ref_state_id' => $request->ref_state_id[$key],
                        'ref_district_id' => $request->ref_district_id[$key],
                        'ref_block_tehsil_id' => $request->ref_block_tehsil_id[$key],
                        'ref_village_id' => $request->ref_village_id[$key],
                        'created_by' => Auth::guard('misadmin')->user()->id,
                        'updated_by' => Auth::guard('misadmin')->user()->id
                    );

                    if (!empty($request->row_id[$key])) {

                        $data['updated_at'] = date('Y-m-d H:i:s');
                        $data['updated_by'] = Auth::guard('misadmin')->user()->id;
                        InspectionSchedule::where('id', $request->row_id[$key])->update($data);
                    } else {

                        $data['created_by'] = Auth::guard('misadmin')->user()->id;
                        $data['created_at'] = date('Y-m-d H:i:s');
                        InspectionSchedule::create($data);
                    }
                }

                $villages = array();
                for ($i = 0; $i < count($request->ref_village_id); $i++) {
                    $villages[] = get_village_name_by_id($request->ref_village_id[$i]);
                }
                $village_name = implode(", ", $villages);

                $emails = getInspectorName($request->at_ics_inspector_details_id)->email ?? '';
                $maildata  = ['send_message' => "You have been scheduled for villages " . $village_name . " for the inspection process of farmers."];

                // Mail::send('mail.inspector_register', $maildata, function ($message) use ($emails) {  // use mail template in view/api folder
                //     $message->subject("Apeda Inspoctor Inspection"); // Email subject body
                //     $message->to($emails);
                // });

                Alert::success('Success', __('message.add_success'));
                //return redirect()->back();
                return redirect()->route('superadmin.icsuser.inspectorSchList');
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function deleteInspSchedule(Request $request)
    {
        try {
            //dd($request->all());
            $user = InspectionSchedule::where('id', $request->id)->delete();
            return 1;
        } catch (Exception $e) {
            Log::error($e->getMessage());
            \Log::error($e->getMessage());
            abort('404');
        }
    }
    /////inspector schedule

    public function farmerList(Request $request)
    {

        // dd($request->all);
        $id = Auth::user()->id;
        // abort_unless(\Gate::allows('farmer_access'), 403);

        $inspIds =  UserInspector::select('id')->where('at_user_id', $id)->orderBy('id', 'DESC')->get();


        if ($request->ajax()) {
            $totalData =  AtFarmerRegDetail::whereIn('at_ics_inspector_id', $inspIds)->get();
            //dd($totalData);

            return Datatables::of($totalData)
                ->addIndexColumn()
                ->addColumn('name', function ($row) {

                    return $row->farmer_first_name ?? '';
                })
                ->addColumn('email', function ($row) {
                    return $row->email_id ?? '';
                })->addColumn('mobile', function ($row) {
                    return $row->mobile_no ?? '';
                })->addColumn('address', function ($row) {

                    return $row->farmer_address ?? '';
                })->addColumn('insp_name', function ($row) {

                    return getInspectorName($row->at_ics_inspector_id)->name_of_inspector ?? '';
                })->addColumn('created_on', function ($row) {

                    return  date('d-m-Y', strtotime($row->created_at)) ?? '';
                })->addColumn('action', function ($row) {
                    $actionBtn = '

                    <a href=' . route('superadmin.icsuser.farmerDetail', $row->id) . '><span><i class="mdi mdi-eye text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="View Detail"></i></span></a>';

                    return $actionBtn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        return view('admin/ics/farmer-list');
    }

    public function farmerDetail($id)
    {

        $result = AtFarmerRegDetail::with(['farmerLandDetail', 'farmerBankDetail', 'farmerDocs', 'farmerOSPDetail'])->where('id', $id)->first();
        // dd($result);
        return view('admin/ics/farmer-detail', compact('result'));
    }




    public function icsfarmerdetails()
    {
        $userdetails = User::find(Auth::id());
        $states = RefState::orderBy('state_name', 'ASC')->get();
        // $districts = RefDistrict::orderBy('district_name','ASC')->get();
        // $regions = RefRegion::orderBy('block_tehsil_name','ASC')->get();
        // $villages = RefVillage::orderBy('village_name','ASC')->limit(100)->get();
        return view('admin/ics/icsFarmerDetails', compact('states', 'userdetails'));
    }


    public function storeIcsFarmerDetails(Request $request)
    {
        return $request;
        //     try {

        //         $request->validate([
        //             'farmer_name' => 'required',
        //             'email' => 'required',
        //             'mobile_no' => 'required',
        //             'address' => 'required',
        //             'village' => 'required',
        //             'taluka' => 'required',
        //             'state' => 'required',
        //             'district' => 'required',
        //             'pincode' => 'required',
        //             'land_address' => 'required',
        //             'aadhar_card' => 'mimes:jpeg,jpg,png,pdf,xlx,csv|max:10000',
        //             'pan_card' => 'mimes:jpeg,jpg,png,pdf,xlx,csv|max:10000',
        //             'address_proof_of_office_doc' => 'mimes:jpeg,jpg,png,pdf,xlx,csv|max:10000',
        //             'profile_photo' => 'mimes:jpeg,jpg,png,pdf,xlx,csv|max:10000',
        //             'appointment_doc' => 'mimes:jpeg,jpg,png,pdf,xlx,csv|max:10000',

        //         ]);

        //         if ($request->hasFile('aadhar_card')) {
        //             if (!empty($request->aadhar_card_edit)) {
        //                 $imagePath = public_path('farmer/aadhar_card/') . $request->aadhar_card_edit;
        //                 deleteOldImage($request->trader_photo_edit, $imagePath);
        //             }
        //             $documentRootPath = 'public/farmer/aadhar_card';
        //             $file_path = time() . rand() . '.' . $request->file('aadhar_card')->getClientOriginalExtension();
        //             $request->file('aadhar_card')->move($documentRootPath, $file_path);
        //             $aadhar_card = $file_path;
        //         } else {
        //             $aadhar_card = $request->aadhar_card_edit;
        //         }

        //         if ($request->hasFile('pan_card')) {
        //             if (!empty($request->pan_card_edit)) {
        //                 $imagePath = public_path('farmer/pan_card/') . $request->pan_card_edit;
        //                 deleteOldImage($request->pan_card_edit, $imagePath);
        //             }
        //             $documentRootPath = 'public/farmer/pan_card';
        //             $file_path = time() . rand() . '.' . $request->file('pan_card')->getClientOriginalExtension();
        //             $request->file('pan_card')->move($documentRootPath, $file_path);
        //             $pan_card = $file_path;
        //         } else {
        //             $pan_card = $request->pan_card_edit;
        //         }

        //         // if ($request->hasFile('address_proof_of_office_doc')) {
        //         // 	if (!empty($request->address_proof_of_office_doc_edit)) {
        //         // 		$imagePath = public_path('farmer/address_proof_of_office_doc/') . $request->address_proof_of_office_doc_edit;
        //         // 		deleteOldImage($request->address_proof_of_office_doc_edit, $imagePath);
        //         // 	}
        //         // 	$documentRootPath = 'public/farmer/address_proof_of_office_doc';
        //         // 	$file_path = time() . rand() . '.' . $request->file('address_proof_of_office_doc')->getClientOriginalExtension();
        //         // 	$request->file('address_proof_of_office_doc')->move($documentRootPath, $file_path);
        //         // 	$address_proof_of_office_doc = $file_path;
        //         // } else {
        //         // 	$address_proof_of_office_doc = $request->address_proof_of_office_doc_edit;
        //         // }

        //         if ($request->hasFile('profile_photo')) {
        //             if (!empty($request->profile_photo_edit)) {
        //                 $imagePath = public_path('farmer/profile_photo/') . $request->profile_photo_edit;
        //                 deleteOldImage($request->profile_photo_edit, $imagePath);
        //             }
        //             $documentRootPath = 'public/farmer/profile_photo';
        //             $file_path = time() . rand() . '.' . $request->file('profile_photo')->getClientOriginalExtension();
        //             $request->file('profile_photo')->move($documentRootPath, $file_path);
        //             $profile_photo = $file_path;
        //         } else {
        //             $profile_photo = $request->profile_photo_edit;
        //         }


        //         if ($request->hasFile('appointment_doc')) {
        //             if (!empty($request->appointment_doc_edit)) {
        //                 $imagePath = public_path('farmer/appointment_doc/') . $request->appointment_doc_edit;
        //                 deleteOldImage($request->appointment_doc_edit, $imagePath);
        //             }
        //             $documentRootPath = 'public/farmer/appointment_doc';
        //             $file_path = time() . rand() . '.' . $request->file('appointment_doc')->getClientOriginalExtension();
        //             $request->file('appointment_doc')->move($documentRootPath, $file_path);
        //             $appointment_doc = $file_path;
        //         } else {
        //             $appointment_doc = $request->appointment_doc_edit;
        //         }

        //         $user = User::find($id);
        //         if(isset($user)){
        //             $newUser = UserFarmer::updateOrCreate([
        //                 'ref_user_id'   => $id,
        //             ],[
        //             'name' => $request->farmer_name,
        //             'email' => $request->email,
        //             'mobile_no' => $request->mobile_no,
        //             'address' => $request->address,
        //             'village' => $request->village,
        //             'taluka' => $request->taluka,
        //             'district' => $request->district,
        //             'state' => $request->state,
        //             'pin_code' => $request->pincode,
        //             'aadhar_card' => $aadhar_card,
        //             'pan_card' => $pan_card,
        //             'address_proof_of_office' => $request->address_proof_of_office,
        //             'address_proof_of_office_doc' => $address_proof_of_office_doc,
        //             'profile_photo' => $profile_photo,
        //             'appointment_doc' => $appointment_doc,
        //             'land_address' => $request->land_address,
        //             'created_by' => Auth::guard('misadmin')->user()->id,
        //             'updated_by' => Auth::guard('misadmin')->user()->id
        //             ]);
        //         }



        //         if($request->roleid==2){
        //             Alert::success('Success', __('message.add_third_success'));
        //             return redirect()->route('superadmin.icsuser.step4',$user->id);
        //             //return redirect()->route('superadmin.icsuser.step4',$user->id)->with('success', __('message.add_third_success'));
        //         }else{
        //             Alert::success('Success', __('message.add_success'));
        //             return redirect()->back();
        //             //return redirect()->back()->with('success', __('message.add_success'));
        //         }

        // } catch (Exception $e) {
        //     Log::error($e->getMessage());
        //     abort('404');
        // }
    }
    public function abc()
    {

        // $data=AtFarmerRegDetail::get();
        // foreach($data as $d){
        //     $reg_no = getFarmerRegNo($d->id,$d->ref_state_id);
        //     AtFarmerRegDetail::where('id',$d->id)->update(['registration_no'=>$reg_no,'owner_farmerid'=>$reg_no]);
        // }

        dd('done');
    }
    public function listOfRegFarmer(Request $request, $id)
    {
        //    dd($id);
        $user = User::where('id', $id)->first();
        // if($user->status == 0){
        //     User::where('id',$id)->update(['status'=>1]);
        // }


        $icsmandator = IcsMandator::where('at_user_id', $id)->first();
        $userInsp = UserInspector::where('at_user_id', $id)->get();
        $warehs = UserWarehouse::where('at_user_id', $id)->first();

        $wmanager = UserWarehouseManagerOfficers::where('at_user_id', $id)->where('user_type', 'WM')->get();
        $pmanager = UserWarehouseManagerOfficers::where('at_user_id', $id)->where('user_type', 'PM')->get();
        $foanager = UserWarehouseManagerOfficers::where('at_user_id', $id)->where('user_type', 'FO')->get();
        $amanager = UserWarehouseManagerOfficers::where('at_user_id', $id)->where('user_type', 'AM')->first();
        $farmerDetails = AtFarmerRegDetail::where('at_user_id', $id)->get();
        // dd($farmerDetails);
        $states = RefState::orderBy('state_name', 'ASC')->get();

        return view('admin/ics/preview', compact('id', 'user', 'icsmandator', 'warehs', 'states', 'userInsp', 'wmanager', 'pmanager', 'foanager', 'amanager', 'farmerDetails'));
    }

    public function updateinspector(Request $request)
    {
        try {
            $inspector = UserInspector::find($request->row_id);

            if (!$inspector) {
                return redirect()->back()->with('error', 'Inspector not found.');
            }

            // Update basic fields
            $updateData = [
                'name_of_inspector' => $request->inspector_name,
                'email' => $request->email,
                'mobile_no' => $request->mobile_no,
                'address' => $request->address,
                'ref_village_id' => $request->ref_village_id,
                'ref_block_tehsil_id' => $request->ref_block_tehsil_id,
                'ref_district_id' => $request->ref_district_id,
                'ref_state_id' => $request->ref_state_id,
                'pin' => $request->pincode,
                'id_proof' => $request->id_proof,
                'qualification' => $request->qualification,
                'address_proof_of_office' => $request->address_proof_of_office,
                'updated_at' => now(), // Use Laravel's now() helper for current timestamp
            ];
            // dd($request->all());
            $fieldsWithFiles = [
                'profile_photo' => 'inspector/profile_photo',
                'appointment_doc' => 'inspector/appointment_doc',
                'id_proof_doc' => 'inspector/id_proof_doc',
                'address_proof_of_office_doc' => 'inspector/appointment_doc',
            ];

            foreach ($fieldsWithFiles as $field => $path) {
                if ($request->hasFile($field)) {
                    // Log file upload information
                    \Log::debug("File upload for $field", [
                        'file_name' => $request->file($field)->getClientOriginalName(),
                        'field' => $field
                    ]);

                    // Delete old file if it exists
                    if ($inspector->$field) {
                        $oldFilePath = public_path($path . '/' . $inspector->$field);
                        if (file_exists($oldFilePath)) {
                            unlink($oldFilePath); // Remove old file
                        }
                    }

                    // Store the new file
                    $fileName = time() . '_' . $request->file($field)->getClientOriginalName();
                    $request->file($field)->move(public_path($path), $fileName);
                    $inspector->$field = $fileName;
                }
            }

            // Log the inspector data after update
            \Log::debug('Inspector after update: ', $inspector->toArray());

            // Update the inspector model with new data
            foreach ($updateData as $key => $value) {
                $inspector->$key = $value;
            }

            if ($inspector->save()) {
                \Log::debug('Inspector updated successfully');
                return redirect()->back()->with('success', 'Inspector details updated successfully.');
            } else {
                return redirect()->back()->with('error', 'Failed to update inspector details.');
            }
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Failed to update inspector details. Please try again.');
        }
    }



    public function Addmorefrm(Request $request)
    {
        //   dd($request->all());
        $i =  $request->formcounts;
        $inspectorID = $request->InspId;
        $userdetails = User::with('getUserInspector')->where('id', $request->UserID)->first();
        $no_of_farmers = $userdetails->no_of_farmers;
        $inspectors = $userdetails->getUserInspector;
        $totalGroups = ceil($no_of_farmers / 60);
        $inspectorsForGroups = [];
        for ($group = 0; $group < $totalGroups; $group++) {
            $groupInspector = $inspectors[$group] ?? null;
            if ($groupInspector) {
                $inspectorsForGroups[] = [
                    'inspector_id' => $groupInspector->id,
                    'farmers_from' => $group * 60 + 1,
                    'farmers_to' => min(($group + 1) * 60, $no_of_farmers),
                ];
            }
        }
        if ($i >= 60) {
            $groupNumber = floor($i / 60);
            $inspectorID = $inspectorsForGroups[$groupNumber]['inspector_id'] ?? $inspectorsForGroups[0]['inspector_id'];
        }


        $cbstate = User::where('id', $userdetails->created_by)->first();
        return view('admin.ics.templateicsstep3', compact('cbstate', 'i', 'userdetails', 'inspectorID'))->render();
    }
}

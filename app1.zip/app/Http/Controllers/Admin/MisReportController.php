<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\AtOpCertificateStandardDetail;
use App\Models\AtProProcessingUnit;
use App\Models\AtOpTransactionCertificateEntry;
use App\Models\AtFarmerRegDetail;
use App\Models\AtIpFarmerRegDetail;
use App\Models\AtFarmDetails;
use App\Models\UserInspector;
use App\Models\UserWarehouse;
use App\Models\AtOpTransactionVsTransactionProduct;
use App\Models\User;
use Illuminate\Support\Facades\Validator;
use DB;
use DataTables;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;

class MisReportController extends Controller
{


    public function CountryWiseExports()
    {
        return view("admin.mis_report.country-wise-exports");
    }

    public function CountryWiseExportsSearch(Request $request)
    {


        //  $results = AtOpCertificateStandardDetail::where('ref_operator_type_id',$request->operatorType)
        //  ->where('scope_certificate_no','!=',null)
        //  ->where('scope_certificate_no','!=','NA')
        //  ->get();
        $results = AtOpTransactionVsTransactionProduct::query();

        if (!is_null($request->operatorType)) {
            $results->where('operator_type', $request->operatorType);
        }

        if (!is_null($request->from_date)) {
            $results->where('created_at', '>=', $request->from_date);
        }

        if (!is_null($request->to_date)) {
            $results->where('created_at', '<=', $request->to_date);
        }

        $results = $results->where('transaction_certificate_no', '!=', null)->where('transaction_certificate_no', '!=', 'NA')->get();

        
        $returnData = array();

        if (count($results) > 0) {

            foreach ($results as $key => $res) {
                $returnData[$key]['country_name'] = getCountryName($res->id);
                $returnData[$key]['operator_type'] = getOperatorTypeById($res->operator_type);
                $returnData[$key]['operator_name'] = user_name($res->created_by);
                $returnData[$key]['product'] = getHscodeProductName($res->product_code);
                $returnData[$key]['quantity'] = $res->total_qty;
                $returnData[$key]['start_date'] =  dateFormat($res->tc_date);


            }


            return response()->json(['msg' => 'success', 'data' => $returnData]);
        } else {
            return response()->json(['msg' => 'error', 'data' => 'No Record found.']);
        }
    }


    public function scopeissue()
    {

        return view("admin.mis_report.scope-issue");
    }


    public function scopeissuesearch(Request $request)
    {
        //dd("aaaaa",$request->all());

        // $results = AtOpCertificateStandardDetail::where('ref_operator_type_id',$request->operatorType)
        // ->where('scope_certificate_no','!=',null)
        // ->where('scope_certificate_no','!=','NA')
        // ->whereBetween('created_at', [$request->from_date, $request->to_date])
        // ->get();

        // $results = AtOpCertificateStandardDetail::query();

        // $results = User::whereHas('certificateStandardDetails')query();

        // if (!is_null($request->operatorType)) {
        //     $results->where('ref_operator_type_id', $request->operatorType);
        // }

        // if (!is_null($request->from_date)) {
        //     $results->where('created_at', '>=', $request->from_date);
        // }

        // if (!is_null($request->to_date)) {
        //     $results->where('created_at', '<=', $request->to_date);
        // }

        // $results = $results->where('scope_certificate_no', '!=', null)->where('scope_certificate_no', '!=', 'NA')->get();

        // $returnData = array();

        $results = User::whereHas('certificateStandardDetails', function($query) {
            // You can put conditions related to certificateStandardDetails here if needed
        })
        ->when(!is_null($request->operatorType), function($query) use ($request) {
            $query->where('ref_operator_type_id', $request->operatorType);
        })
        ->when(!is_null($request->from_date), function($query) use ($request) {
            $query->where('created_at', '>=', $request->from_date);
        })
        ->when(!is_null($request->to_date), function($query) use ($request) {
            $query->where('created_at', '<=', $request->to_date);
        })
        // ->whereNotNull('scope_certificate_no')
        // ->where('scope_certificate_no', '!=', 'NA')
        ->get();
        
        $returnData = $results->toArray();
        

        //dd($results);
        if (count($results) > 0) {

            foreach ($results as $key => $res) {

                $returnData[$key]['sc_no'] = $res->certificateStandardDetails[0]->scope_certificate_no ?? '';
                $returnData[$key]['app_no'] = '#'. $res->id;
                $returnData[$key]['reg_no'] =  $res->registration_no ;
                $returnData[$key]['operator_name'] =  $res->first_name;
                $returnData[$key]['operator_address'] =  $res->address;
                $returnData[$key]['ref_state_id'] = getStateName($res->ref_state_id);
                $returnData[$key]['ref_district_id'] = getDisName($res->ref_district_id);
                $returnData[$key]['operator_type'] = getOperatorTypeById($res->ref_operator_type_id);
                $returnData[$key]['start_date'] = date('d-m-Y', strtotime($res->certificateStandardDetails[0]->validity_start_date));
                $returnData[$key]['end_date'] = date('d-m-Y', strtotime($res->certificateStandardDetails[0]->validity_end_date));

            }

            //   dd( $returnData);
            return response()->json(['msg' => 'success', 'data' => $returnData]);
        } else {
            return response()->json(['msg' => 'error', 'data' => 'No Record found.']);
        }



    }

    public function listofregisteroperator()
    {
        return view("admin.mis_report.list-of-register-operator");
    }

    public function listofregisteroperatorsearch(Request $request)
    {
        $userId = Auth::id();

       // dd($userId);
        
        $results = User::whereHas('certificateStandardDetails', function($query) {
            // You can put conditions related to certificateStandardDetails here if needed
        })
        ->when(!is_null($request->operatorType), function($query) use ($request) {
            $query->where('ref_operator_type_id', $request->operatorType);
        })
        ->when(!is_null($request->from_date), function($query) use ($request) {
            $query->where('created_at', '>=', $request->from_date);
        })
        ->when(!is_null($request->to_date), function($query) use ($request) {
            $query->where('created_at', '<=', $request->to_date);
        })

        // ->whereNotNull('scope_certificate_no')
        // ->where('scope_certificate_no', '!=', 'NA')

        ->where('created_by', $userId)
        ->get();
        
        $returnData = $results->toArray();


              //dd($returnData);
         
        if (count($results) > 0) {

            foreach ($results as $key => $res) {
                $returnData[$key]['app_no'] = '#'. $res->id ?? '';
                $returnData[$key]['reg_no'] = $res->registration_no ?? '';
                $returnData[$key]['sc_no'] = $res->certificateStandardDetails[0]->scope_certificate_no ?? '';
                $returnData[$key]['address'] = $res->address;
                $returnData[$key]['ref_state_id'] = get_state_name($res->id);
                $returnData[$key]['agency_no'] = ($res->first_name);
                $returnData[$key]['ref_state_id'] = getStateName($res->ref_state_id);
                $returnData[$key]['ref_district_id'] = getDisName($res->ref_district_id);
                $returnData[$key]['operator_type'] = getOperatorTypeById($res->ref_operator_type_id);
                $returnData[$key]['start_date'] = date('d-m-Y', strtotime($res->certificateStandardDetails[0]->validity_start_date));
                $returnData[$key]['end_date'] =   date('d-m-Y', strtotime($res->certificateStandardDetails[0]->validity_end_date));
                $returnData[$key]['sc_status'] = ($res->certificateStandardDetails[0]->status == 1) ? 'Scope Issued' : 
                    (($res->certificateStandardDetails[0]->status == 0) ? 'Scope Applied' : 
                    (($res->certificateStandardDetails[0]->status == 2) ? 'Scope Rejected' : 'Scope Not Issued'));


            }

             //  dd( $returnData);
            return response()->json(['msg' => 'success', 'data' => $returnData]);
        } else {
            return response()->json(['msg' => 'error', 'data' => 'No Record found.']);
        }

    }

    public function stateWiseArea()
    {
        return view("admin.mis_report.state-wise-area");
    }

    public function stateWiseAreaSearch(Request $request)
    {

        // dd("aaaaa",$request->all());
        $results = AtOpCertificateStandardDetail::where('ref_operator_type_id', $request->operatorType)

            ->where('scope_certificate_no', '!=', null)
            ->where('scope_certificate_no', '!=', 'NA')
            ->get();
        $returnData = array();
        //    dd($results);

        if (count($results) > 0) {

            foreach ($results as $key => $res) {
                $returnData[$key]['state'] = $res->id;
                $returnData[$key]['org_area'] = 'NA' ;
                $returnData[$key]['conver_area'] = 'NA' ;


            }

            //dd( $returnData);
            return response()->json(['msg' => 'success', 'data' => $returnData]);
        } else {
            return response()->json(['msg' => 'error', 'data' => 'No Record found.']);
        }

    }

    public function totalFarmer()
    {
        return view("admin.mis_report.total-farmer");
    }



    // public function totalFarmerSearch(Request $request)
    // {



    //     $icsCount = AtFarmerRegDetail::where('ref_state_id', $request->state)->count();
    //     $ipCount = AtIpFarmerRegDetail::where('ref_state_id', $request->state)->count();

    //     $totalCount = $icsCount + $ipCount;

    //     $data = [

    //         'ics' => AtFarmerRegDetail::where('ref_state_id', $request->state)->count(),
    //         'ip' => AtIpFarmerRegDetail::where('ref_state_id', $request->state)->count(),
    //         'total_count' => $totalCount


    //     ];


    //     return response()->json($data);

    // }

    public function totalFarmerSearch(Request $request)
{

    // dd( $request->state);
    $validator = Validator::make($request->all(), [
        'state' => 'required' 
    ]);

    if ($validator->fails()) {
        return response()->json(['error' => $validator->errors()], 400);
    }

    $icsCount = AtFarmerRegDetail::where('ref_state_id', $request->state)->count();
    $ipCount = AtIpFarmerRegDetail::where('ref_state_id', $request->state)->count();
    $ics = AtFarmerRegDetail::select('at_user_id')->where('ref_state_id', $request->state)->count();
    $ip = AtIpFarmerRegDetail::select('at_user_id')->where('ref_state_id', $request->state)->count();
     $state = AtFarmerRegDetail::select('ref_state_id')
                                 ->where('ref_state_id', $request->state)
                                ->first();

    // dd($state);

    $totalCount = $icsCount + $ipCount;

    $data = [

         
        'state' => $state,
        'gg' => $ics,
        'ipp' => $ip,
        'ics' => $icsCount,
        'ip' => $ipCount,
        'total_count' => $totalCount
    ];

    return response()->json($data);
}

    public function listOfTc()
    {
        return view("admin.mis_report.list-of-tc");
    }

   

    public function listOfTcSearch(Request $request)
{
    // Start the query on the 'AtOpTransactionVsTransactionProduct' table
    $results = AtOpTransactionVsTransactionProduct::query();

    // Apply filters based on request parameters
    if (!is_null($request->operatorType)) {
        $results->where('operator_type', $request->operatorType);
    }

    if (!is_null($request->from_date)) {
        // Specify the table for 'created_at' to avoid ambiguity
        $results->where('at_op_transaction_vs_transaction_product.created_at', '>=', $request->from_date);
    }

    if (!is_null($request->to_date)) {
        // Specify the table for 'created_at' to avoid ambiguity
        $results->where('at_op_transaction_vs_transaction_product.created_at', '<=', $request->to_date);
    }

    // Perform a left join with 'at_op_transaction_certificate_entry' table
    // Select only the necessary columns
    $results = $results->leftJoin('at_op_transaction_certificate_entry', 'at_op_transaction_certificate_entry.at_op_transaction_vs_transaction_product_id', '=', 'at_op_transaction_vs_transaction_product.id')
        ->select(
            'at_op_transaction_vs_transaction_product.
            ',
            'at_op_transaction_vs_transaction_product.id',
            'at_op_transaction_vs_transaction_product.tc_date',
            'at_op_transaction_vs_transaction_product.total_qty',
            'at_op_transaction_certificate_entry.buyer_name',
            'at_op_transaction_certificate_entry.exporter_seller_name',
             'at_op_transaction_vs_transaction_product.value_inr',
            // 'at_op_transaction_vs_transaction_product.created_at',
             'at_op_transaction_certificate_entry.seller_at_op_certificate_standard_details_id' // add any columns from the joined table as needed
        )
        ->where('at_op_transaction_vs_transaction_product.transaction_certificate_no', '!=', null)
        ->where('at_op_transaction_vs_transaction_product.transaction_certificate_no', '!=', 'NA')
        ->get();

    // Prepare the response data
    $returnData = array();

    if (count($results) > 0) {
        foreach ($results as $key => $res) {
            // Accessing fields from both tables
            $returnData[$key]['tc_no'] = $res->transaction_certificate_no;
            $returnData[$key]['date_of_tc'] = dateFormat($res->tc_date);
            $returnData[$key]['buyer_name'] = $res->buyer_name ?? ''; // Assuming you fetch this elsewhere or need to join another table
            $returnData[$key]['seller_name'] = $res->exporter_seller_name ?? '';
            $returnData[$key]['country_name'] = getCountryName($res->id); // Custom helper to get country name
            $returnData[$key]['seller_no'] =  $res->seller_at_op_certificate_standard_details_id ; 
            $returnData[$key]['total_qunt'] = $res->total_qty;
            $returnData[$key]['value'] = $res->value_inr;
        }

        return response()->json(['msg' => 'success', 'data' => $returnData]);
    } else {
        return response()->json(['msg' => 'error', 'data' => 'No Record found.']);
    }
}


    public function listOfPtc()
    {
        return view("admin.mis_report.list-of-ptc");
    }

    public function listOfPtcSearch(Request $request)
{
    // Start the query on the 'AtOpTransactionVsTransactionProduct' table
    $results = AtOpTransactionVsTransactionProduct::query();

    // Apply filters based on request parameters
    if (!is_null($request->operatorType)) {
        $results->where('operator_type', $request->operatorType);
    }

    if (!is_null($request->from_date)) {
        // Specify the table for 'created_at' to avoid ambiguity
        $results->where('at_op_transaction_vs_transaction_product.created_at', '>=', $request->from_date);
    }

    if (!is_null($request->to_date)) {
        // Specify the table for 'created_at' to avoid ambiguity
        $results->where('at_op_transaction_vs_transaction_product.created_at', '<=', $request->to_date);
    }

    // Perform a left join with 'at_op_transaction_certificate_entry' table
    // Select only the necessary columns
    $results = $results->leftJoin('at_op_transaction_certificate_entry', 'at_op_transaction_certificate_entry.at_op_transaction_vs_transaction_product_id', '=', 'at_op_transaction_vs_transaction_product.id')
        ->select(
            'at_op_transaction_vs_transaction_product.transaction_certificate_no',
            'at_op_transaction_vs_transaction_product.id',
            'at_op_transaction_vs_transaction_product.tc_date',
            'at_op_transaction_vs_transaction_product.total_qty',
            'at_op_transaction_certificate_entry.buyer_name',
            'at_op_transaction_certificate_entry.exporter_seller_name',
             'at_op_transaction_vs_transaction_product.value_inr',
            // 'at_op_transaction_vs_transaction_product.created_at',
             'at_op_transaction_certificate_entry.seller_at_op_certificate_standard_details_id' // add any columns from the joined table as needed
        )
        ->where('at_op_transaction_vs_transaction_product.transaction_certificate_no', '!=', null)
        ->where('at_op_transaction_vs_transaction_product.transaction_certificate_no', '!=', 'NA')
        ->get();

    // Prepare the response data
    $returnData = array();

    if (count($results) > 0) {
        foreach ($results as $key => $res) {
            // Accessing fields from both tables
         


            $returnData[$key]['tc_no'] = $res->transaction_certificate_no;
            $returnData[$key]['date_of_tc'] = dateFormat($res->tc_date);
            $returnData[$key]['buyer_name'] = $res->buyer_name ?? ''; // Assuming you fetch this elsewhere or need to join another table
            $returnData[$key]['seller_name'] = $res->exporter_seller_name ?? '';
            $returnData[$key]['country_name'] = getCountryName($res->id); // Custom helper to get country name
            $returnData[$key]['seller_no'] =  $res->seller_at_op_certificate_standard_details_id ; 
            $returnData[$key]['total_qunt'] = $res->total_qty;
            $returnData[$key]['value'] = $res->value_inr;
        }

        return response()->json(['msg' => 'success', 'data' => $returnData]);
    } else {
        return response()->json(['msg' => 'error', 'data' => 'No Record found.']);
    }
}



    public function viewoperatorOsp()
    {
        return view("admin.mis_report.view-operator-osp");
    }

    public function viewoperatorOspSearch(Request $request)
    {

        // dd("aaaaa",$request->all());
        // $results = AtOpCertificateStandardDetail::where('ref_operator_type_id', $request->operatorType)

        //     ->where('scope_certificate_no', '!=', null)
        //     ->where('scope_certificate_no', '!=', 'NA')
        //     ->get();

        // $returnData = array();
        //    dd($results);


        $results = User::whereHas('certificateStandardDetails', function($query) {
            // You can put conditions related to certificateStandardDetails here if needed
        })
        ->when(!is_null($request->operatorType), function($query) use ($request) {
            $query->where('ref_operator_type_id', $request->operatorType);
        })
        ->when(!is_null($request->from_date), function($query) use ($request) {
            $query->where('created_at', '>=', $request->from_date);
        })
        ->when(!is_null($request->to_date), function($query) use ($request) {
            $query->where('created_at', '<=', $request->to_date);
        })

        // ->whereNotNull('scope_certificate_no')
        // ->where('scope_certificate_no', '!=', 'NA')
          ->get();
        
        $returnData = $results->toArray();

//dd($returnData);

        if (count($results) > 0) {

            foreach ($results as $key => $res) {
                $returnData[$key]['reg_no'] = $res->registration_no ?? '';
                $returnData[$key]['camp_name'] = $res->first_name ?? '';
                $returnData[$key]['state_name'] = getStateName($res->ref_state_id ?? '');
                // $user = User::where('ref_operator_type_id', $res->ref_operator_type_id)->first();

                // if ($user) {
                //     $returnData[$key]['address'] = $user->address;
                // } else {
                //     $returnData[$key]['address'] = 'NA';
                // }
                $returnData[$key]['country_name'] = ($res->id);
                $returnData[$key]['operator_name'] = getOperatorTypeById($res->ref_operator_type_id);
                $returnData[$key]['date_of_reg'] = dateFormat($res->created_at);
                $returnData[$key]['view'] = '<a href="' . route("ospview") . '">View OSP</a>';

            }

            //   dd( $returnData);
            return response()->json(['msg' => 'success', 'data' => $returnData]);
        } else {
            return response()->json(['msg' => 'error', 'data' => 'No Record found.']);
        }

    }


    public function ospview()
    {
        return view("admin.mis_report.osp-view");
    }

    public function scopePendingForRenewal()
    {
        return view("admin.mis_report.scope-pending-for-renewal");
    }

    public function scopePendingForRenewalSearch(Request $request)
    {
        //  dd("aaaaa",$request->all());
        //  $results = AtOpCertificateStandardDetail::where('ref_operator_type_id',$request->operatorType)

        //  ->where('scope_certificate_no','!=',null)
        //  ->where('scope_certificate_no','!=','NA')

        //  ->get();
        // $results = AtOpCertificateStandardDetail::query();

        // if (!is_null($request->operatorType)) {
        //     $results->where('ref_operator_type_id', $request->operatorType);
        // }

        // if (!is_null($request->from_date)) {
        //     $results->where('created_at', '>=', $request->from_date);
        // }

        // if (!is_null($request->to_date)) {
        //     $results->where('created_at', '<=', $request->to_date);
        // }

        // $results = $results->where('scope_certificate_no', '!=', null)->where('scope_certificate_no', '!=', 'NA')->get();


        // $returnData = array();
        // dd($results);

        $results = User::whereHas('certificateStandardDetails', function($query) {
            // You can put conditions related to certificateStandardDetails here if needed
        })
        ->when(!is_null($request->operatorType), function($query) use ($request) {
            $query->where('ref_operator_type_id', $request->operatorType);
        })
        ->when(!is_null($request->from_date), function($query) use ($request) {
            $query->where('created_at', '>=', $request->from_date);
        })
        ->when(!is_null($request->to_date), function($query) use ($request) {
            $query->where('created_at', '<=', $request->to_date);
        })

        // ->whereNotNull('scope_certificate_no')
        // ->where('scope_certificate_no', '!=', 'NA')
          ->get();
        
        $returnData = $results->toArray();
   //dd($returnData);

        if (count($results) > 0) {


            
            foreach ($results as $key => $res) {

                $validityEndDate = Carbon::parse($res->certificateStandardDetails[0]->validity_end_date);
                $futureDate = now()->addDays(90);
                
                $returnData[$key]['scope_no'] = $res->certificateStandardDetails[0]->scope_certificate_no ?? '';
                $returnData[$key]['app_no'] = '#'. ($res->id ?? '');
                $returnData[$key]['reg_no'] = ($res->registration_no ?? '');
                $returnData[$key]['opertor_name'] = ($res->first_name ?? '');
                $returnData[$key]['state'] = getStateName($res->ref_state_id);
                $returnData[$key]['operation_type'] = getOperatorTypeById($res->ref_operator_type_id);
                $returnData[$key]['effecting_date'] = ($res->created_at);
                $returnData[$key]['start_date'] =  date('d-m-Y', strtotime($res->certificateStandardDetails[0]->validity_start_date));
                $returnData[$key]['end_date'] =    date('d-m-Y', strtotime($res->certificateStandardDetails[0]->validity_end_date));
                $returnData[$key]['no_of_day'] = abs($validityEndDate->diffInDays($futureDate, false));



            }

            //   dd( $returnData);
            return response()->json(['msg' => 'success', 'data' => $returnData]);
        } else {
            return response()->json(['msg' => 'error', 'data' => 'No Record found.']);
        }


    }

    public function unitPendingForLicenseRenewal()
    {
        return view("admin.mis_report.unitPending-license");
    }

    public function unitPendingForLicenseRenewalSearch(Request $request)
    {

        //  dd("aaaaa",$request->all());
        $results = AtProProcessingUnit::where('id', $request->registration_no)

            ->where('fssai_license_number', '!=', null)
            ->where('fssai_license_number', '!=', 'NA')

            ->get();

        $returnData = array();


        // $results = User::whereHas('ProProcessingdDetails', function($query) {
        //     // You can put conditions related to certificateStandardDetails here if needed

            
        // })
        // ->when(!is_null($request->registration_no), function($query) use ($request) {
        //     $query->where('registration_no', $request->registration_no);
        // })
        
        // ->where('registration_no', '!=', null)
        // ->where('registration_no', '!=', 'NA')
        //   ->get();
        //   //dd($results);
        // $returnData = $results->toArray();

        if (count($results) > 0) {

            foreach ($results as $key => $res) {
                $returnData[$key]['reg_no'] = 'NA';
                $returnData[$key]['unit_name'] = $res->processing_units_name;
                $returnData[$key]['lice_no'] = $res->fssai_license_number;
                $returnData[$key]['lice_auth'] = 'NA';
                $returnData[$key]['start_date'] = date('d-m-Y', strtotime($res->created_at));
                $returnData[$key]['end_date'] = date('d-m-Y', strtotime($res->created_at));
                $returnData[$key]['install_cap'] = $res->installed_capacity_under_organic;
                $user = User::where('id', $res->id)->first();

                if ($user) {
                    $returnData[$key]['contact_detail'] = $user->mobile_no;
                } else {
                    $returnData[$key]['contact_detail'] = 'NA';
                }
                $returnData[$key]['no_of_day'] = 'NA';


            }

            //   dd( $returnData);
            return response()->json(['msg' => 'success', 'data' => $returnData]);
        } else {
            return response()->json(['msg' => 'error', 'data' => 'No Record found.']);
        }

    }
    public function viewProductDetails()
    {
        return view("admin.mis_report.view-product-details");
    }

    public function viewProductDetailsSearch(Request $request)
    {
        //  dd("aaaaa",$request->all());
        $results = AtOpCertificateStandardDetail::where('ref_operator_type_id', $request->operatorType)

            ->where('scope_certificate_no', '!=', null)
            ->where('scope_certificate_no', '!=', 'NA')

            ->get();

        $returnData = array();
        // dd($results);

        if (count($results) > 0) {

            foreach ($results as $key => $res) {
                $returnData[$key]['scope_no'] = 'ORG/' . date('m') . date('y') . '/' . str_pad($res->at_user_id, 5, '0', STR_PAD_LEFT);
                $returnData[$key]['opertor_name'] = user_name($res->at_user_id);
                $returnData[$key]['operator_type'] = getOperatorTypeById($res->ref_operator_type_id);
                $returnData[$key]['comp_name'] = user_name($res->at_user_id);
                $returnData[$key]['start_date'] =dateFormat($res->created_at);
                $returnData[$key]['no_of_prod'] = '11';
                $returnData[$key]['view'] = '<a href="' . route("ospview") . '">View Product</a>';
                $returnData[$key]['scope_cert'] = asset('scope_certificate/' . $res->file_name); 


            }

            //   dd( $returnData);
            return response()->json(['msg' => 'success', 'data' => $returnData]);
        } else {
            return response()->json(['msg' => 'error', 'data' => 'No Record found.']);
        }
    }
    public function scopeNearby()
    {
        return view("admin.mis_report.scope-nearby");
    }

    public function scopeNearbySearch(Request $request)
    {

        // dd("aaaaa",$request->all());

        // $results = AtOpCertificateStandardDetail::where('ref_operator_type_id',$request->operatorType)
        // ->where('scope_certificate_no','!=',null)
        // ->where('scope_certificate_no','!=','NA')
        // // ->whereBetween('validity_start_date', [$request->from_date, $request->to_date])
        // ->get();

        $results = AtOpCertificateStandardDetail::query();

        if (!is_null($request->operatorType)) {
            $results->where('ref_operator_type_id', $request->operatorType);
        }

        if (!is_null($request->from_date)) {
            $results->where('created_at', '>=', $request->from_date);
        }

        if (!is_null($request->to_date)) {
            $results->where('created_at', '<=', $request->to_date);
        }

        $results = $results->where('scope_certificate_no', '!=', null)->where('scope_certificate_no', '!=', 'NA')->get();



        $returnData = array();
        //    dd($results);
        if (count($results) > 0) {

            foreach ($results as $key => $res) {
                $returnData[$key]['sc_no'] = $res->scope_certificate_no;
                $returnData[$key]['operator_name'] = user_name($res->at_user_id);
                $returnData[$key]['state'] = get_state_name($res->id);
                $returnData[$key]['operator_type'] = getOperatorTypeById($res->ref_operator_type_id);
                $returnData[$key]['start_date'] = dateFormat($res->created_at);
                $returnData[$key]['end_date'] = dateFormat($res->created_at);
                $returnData[$key]['no_of_days'] = 'Na';

            }

            //   dd( $returnData);
            return response()->json(['msg' => 'success', 'data' => $returnData]);
        } else {
            return response()->json(['msg' => 'error', 'data' => 'No Record found.']);
        }

    }


    // public function history()
    // {
    //     return view("admin.mis_report.history");
    // }


    public function ActivityHistory(Request $request)
    {

        // dd('hgjh');
        abort_unless(\Gate::allows('user_access'), 403);

        $userId = Auth::id();


        if ($request->ajax()) {
            // dd($request->all());
            $query = User::where('ref_operator_type_id', 2)->orderBy('id', 'ASC');

            $users = $query->get();

            return Datatables::of($users)
                ->addIndexColumn()
                ->addColumn('ref_operator_type_id', function ($row) {
                    return $row->operatorType->operator_type ?? '';
                })
                ->addColumn('reg_no', function ($row) {
                    
                    return $row->registration_no ?? 'Not Alloted';
                })->addColumn('application_no', function ($row) {

                    return  '#' . str_pad($row->id, 5, "0", STR_PAD_LEFT);
                })->addColumn('name', function ($row) {
                    return $row->first_name ?? '';
                })
                ->addColumn('farmer', function ($row) {
                    $farmer = $row->no_of_farmers ?? '';
                    $addEditDetailButton = '';
                    if (Auth::guard('misadmin')->user()->roles[0]->id == 1) {
                        $addEditDetailButton .= '<a href="' . route('superadmin.farmer', $row->id) . '" class="viewdata" data-value="' . $row->id . '">';
                        // $addEditDetailButton .= '<span><i class="mdi mdi-eye-circle text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="view"></i></span>';
                        $addEditDetailButton .= $farmer; // Adding the data along with the icon
                        $addEditDetailButton .= '</a>';
                    }
                    return $addEditDetailButton;
                })
                
                ->addColumn('created_on', function ($row) {

                    return  date('d-m-Y', strtotime($row->created_at)) ?? '';
                })

                ->addColumn('action', function ($row) {
                    $oper_type = $row->ref_operator_type_id ?? '';
                    $addEditDetailButton = '';
                    if (Auth::guard('misadmin')->user()->roles[0]->id == 1) {
                        $addEditDetailButton .= '<a href="' . route('superadmin.viewData', $row->id) . '" class="viewdata" data-value="' . $row->id . '"><span><i class="mdi mdi-eye-circle text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="view"></i></span></a>';
                    }
                    return $addEditDetailButton;
                    
                })
                ->rawColumns(['action', 'role', 'farmer' ])
                ->make(true);
        }

        return view("admin.mis_report.history");
    }


    public function viewData(Request $request)
    {
        return view("admin.mis_report.view_data");
    }
    
    public function farmer()
    {

// dd('kshdf');
        $data = AtFarmerRegDetail::where('at_user_id', 342)->paginate(8);
        $farms = AtFarmDetails::where('created_by', 342)->paginate(4);
        $inspectors = UserInspector::get();
        $warehouse = UserWarehouse::select('warehouse_available', 'warehouse_type', 'number_of_warehouse', 'licence_number', 'warehouse_area', 'ref_state_id', 'ref_block_tehsil_id', 'pin_code', 'capacity', 'ref_district_id', 'ref_village_id', 'address')
        ->where('at_user_id', '342')->get();
        

        // dd($farms);
        return view("admin.mis_report.farmer", compact('data','farms', 'inspectors', 'warehouse'));
    }
}
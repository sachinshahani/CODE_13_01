<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\HistoryLogin;
use Auth;

class LoginHistory extends Controller
{
    public function loginhistory()
    {
        $userId = Auth::guard('misadmin')->user()->id;
        // dd($userId);

        $cblogindata = HistoryLogin::where('user_id',  $userId )
                               ->orderBy('id', 'desc')  
        ->limit(10)->get();
//    dd($cblogindata);


        return view('admin.login_details.cb', compact('cblogindata'));
    }
}

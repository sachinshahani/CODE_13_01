<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\RoleUser;
use App\Models\RefModule;
use App\Models\RefSubmodule;
use App\Models\Employee\EmployeeModule;
use App\Models\Employee\ModuleMapping;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;

class EmployeeRoleController extends Controller
{
    public function store(Request $request)
    {
        // Validate the incoming request data
        $validatedData = $request->validate([
            'emp_id' => 'required|integer|exists:at_user,id',
            'role_status' => 'required|boolean',
            'module' => 'required|array',
            'module.*' => 'integer|exists:module,id',
            'submodule' => 'nullable|array',
            'submodule.*' => 'integer|exists:sub_module,id',
            'submodules' => 'required|string', // Ensure submodules is required and is a string
            'submodules.*.id' => 'required|integer|exists:sub_module,id',
            'submodules.*.module_id' => 'required|integer|exists:module,id',
            'remark' => 'nullable|string',
        ]);
    
        // Decode the submodules JSON string
        $submodules = json_decode(html_entity_decode($validatedData['submodules']), true);
    
        // Check if JSON decode was successful
        if (json_last_error() !== JSON_ERROR_NONE) {
            return response()->json(['error' => 'Invalid submodules format.'], 422);
        }
    
        try {
            $employeeModule = EmployeeModule::create([
                'emp_id' => $validatedData['emp_id'],
                'status' => $validatedData['role_status'],
                'sub_module' => json_encode($submodules), // Encode back to JSON if needed
                'remark' => $validatedData['remark'],
                'created_by' => Auth::id(),
            ]);
    
            // Insert new module mappings
            foreach ($submodules as $submodule) {
                ModuleMapping::create([
                    'emp_id' => $employeeModule->emp_id,
                    'module_id' => $submodule['module_id'],
                    'sub_module_id' => $submodule['id'],
                ]);
            }
    
            $roleUser = RoleUser::firstOrNew(['user_id' => $employeeModule->emp_id]);
            $roleUser->role_id = 9; // Adjust role ID as necessary
            $roleUser->save();
        } catch (\Exception $e) {
            Alert::success('error', 'Risk Assessment Already Done.');
            return response()->json(['error' => $e->getMessage()], 500);
        }
    
        return redirect()->back()->with('success', 'Employee Module and mappings created successfully.');
    }
    public function edit($id)
    {
        $userId = Auth::id();
        if (!$userId) {
            abort(403, 'Unauthorized access - Please log in');
        }
        $employeeModule = EmployeeModule::with('user', 'moduleMappings')->findOrFail($id);

        $user = User::where(function ($query) {
            return $query->orWhere('ref_operator_type_id', '>', 7)
                ->orWhere('ref_operator_type_id', NULL);
        })
            ->where('created_by', $userId)
            ->orderBy('id', 'DESC')
            ->get();

        $existingEmpIds = EmployeeModule::pluck('emp_id')->toArray();
        $module = RefModule::all();
        $submodule = RefSubmodule::all();
        $existingSubmodules = json_decode($employeeModule->sub_module, true);


        return view('admin.usermanagement.employee.edit_role', compact('user', 'module', 'submodule', 'existingEmpIds', 'employeeModule', 'existingSubmodules'));
    }

    public function update(Request $request, $emp_id)
    {
        $validatedData = $request->validate([
            'role_status' => 'required|boolean',
            'module' => 'required|array',
            'module.*' => 'integer|exists:module,id',
            'submodule' => 'nullable|array',
            'submodule.*' => 'integer|exists:sub_module,id',
            'submodules' => 'required', // Ensure submodules is required
            'submodules.*.id' => 'required|integer|exists:sub_module,id',
            'submodules.*.module_id' => 'required|integer|exists:module,id',
            'remark' => 'nullable|string',
        ]);

        try {
            // Fetch the employee's module record
            $employeeModule = EmployeeModule::with('moduleMappings')
                ->where('emp_id', $emp_id)
                ->firstOrFail();

            // Update the employee module details
            $employeeModule->update([
                'remark' => $validatedData['remark'] ?? $employeeModule->remark, // Optional update for 'remark'
                'sub_module' => $validatedData['submodules'], // Store submodules as JSON
                'status' => $validatedData['role_status'],
                'remark' => $validatedData['remark'],
                'updated_by' => Auth::id(),
            ]);

            // Delete existing module mappings for this employee
            ModuleMapping::where('emp_id', $employeeModule->emp_id)->delete();
    
            $submodules = json_decode($validatedData['submodules'], true);

            // Insert new module mappings
            foreach ($submodules as $submodule) {
                ModuleMapping::create([
                    'emp_id' => $employeeModule->emp_id,
                    'module_id' => $submodule['module_id'],
                    'sub_module_id' => $submodule['id'],
                ]);
            }
    
            return redirect()->back()->with('success', 'Employee Module and mappings updated successfully.');
    
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'Employee Module not found'], 404);
        } catch (\Exception $e) {
            Log::error("Error updating employee module for emp_id {$emp_id}: {$e->getMessage()}");
            return response()->json(['error' => 'An error occurred while updating the module.'], 500);
        }
    }
    

    // Delete method
    public function destroy($id)
    {
        try {
            $employeeModule = EmployeeModule::findOrFail($id);

            ModuleMapping::where('emp_id', $employeeModule->emp_id)->delete();

            RoleUser::where('user_id', $employeeModule->emp_id)->delete();

            $employeeModule->delete();
        } catch (\Exception $e) {
            Alert::error('Error', 'Could not delete the role.');
            return response()->json(['error' => $e->getMessage()], 500);
        }
        Alert::success('success', 'Employee Module and mappings deleted successfully.');
        return redirect()->back()->with('success', 'Employee Module and mappings deleted successfully.');
    }
}

<?php

namespace App\Http\Controllers\Admin\purchase;

use App\Http\Controllers\Controller;
use App\Models\Permission;
use App\Models\Role;
use App\Models\RoleUser;
use App\Models\User;
use App\Models\RefBank;
use App\Models\AtPurchaseRequest;
use App\Models\AtPurchaseDetails;
use App\Models\AtOrderDetailsReceivedFromBuyer;
use App\Models\AtClosingStock;
use App\Models\AtOrderAccepted;
use App\Models\AtOrderRejected;
use App\Models\UserWarehouse;
use Exception;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;
use Illuminate\Support\Facades\DB;
use App\Models\AtOpTransactionVsTransactionProduct;
use App\Models\AtOpTransactionProductSourced;
use App\Models\AtOpTransactionPackingDetails;
use App\Models\AtOpTransactionCertificateEntry;
use App\Models\RefPackingMaster;
use App\Models\AtBatchDetail;
use DataTables;
use Validator;


class ProcessorPurchaseController extends Controller
{

    public function purchaseRequestList(Request $request)
    {

        $id = Auth::user()->id;

        if ($request->ajax()) {
            if (Auth::user()->roles[0]->title == "Processor" || Auth::user()->roles[0]->title == "Trader") {
                $totalData =  AtPurchaseRequest::where('created_by', Auth::user()->id)->get();
            } else {
                $totalData =  AtPurchaseRequest::where('at_user_id', Auth::user()->id)->get();
            }


            return Datatables::of($totalData)
                ->addIndexColumn()
                ->addColumn('user_name', function ($row) {
                    return user_name($row->at_user_id);
                })->addColumn('status', function ($row) {
                    return getRefOrganicStatusMasterByID($row->status);
                })->addColumn('quantity', function ($row) {
                    return $row->quantity;
                })->addColumn('Commodity', function ($row) {
                    return getRefProductById($row->commodity)->product_name ?? '';
                })->addColumn('no_of_packages', function ($row) {
                    return $row->no_of_packages;
                })
                ->addColumn('order_status', function ($row) {
                    if ($row->order_status == 1) {
                        $st = "Accepted";
                    } elseif ($row->order_status == 2) {
                        $st = "Rejected";
                    } else {
                        $st = "Pending";
                    }
                    return $st;
                })->addColumn('action', function ($row) {

                    $actionBtn = '<a href="' . route('superadmin.purchaseRequestView', [$row->id]) . '" class="btn btn-soft-primary"><span><i class="ri-shopping-bag-3-line" data-toggle="tooltip" title="Purchase Product"></i></span></a>';
                    if (Auth::user()->roles[0]->title == "Processor" || Auth::user()->roles[0]->title == "Trader") {
                    } else {
                        $actionBtn .= '<a href="' . route('superadmin.purchaseRequestView', [$row->id]) . '" class="btn btn-soft-primary ms-2"><span><i class="ri-eye-line" data-toggle="tooltip" title="View"></i></span></a>';
                    }
                    return $actionBtn;
                })
                ->rawColumns(['user_name', 'status', 'quantity', 'Commodity', 'no_of_packages', 'order_status', 'action'])
                ->make(true);
        }
        return view('admin/purchase/processor/purchase-request-list');
    }

    function purchaseRequestPage()
    {

           $sellers = AtPurchaseDetails::where('purchase_qty','!=',0)->get();
        $closingstockUserIds = AtClosingStock::selectRaw("at_user_id, COUNT(*) AS count")->groupBy("at_user_id")->get();
        // ->where('date', '>=', date('Y-m-d'));

        $operator = array();
        foreach ($closingstockUserIds as $val) {
            $data = User::select('id', 'ref_operator_type_id', 'registration_no')->where('created_by', auth()->user()->created_by)
                ->where('registration_no', '!=', '')->where('id', $val->at_user_id)->first();
            if (!empty($data)) {
                $operator[] = $data;
            }
        }

       // dd( $operator);
        return view('admin/purchase/processor/add-purchase-request', compact('operator', 'sellers' ));
    }


    public function addpurchaseRequest(Request $request)
    {

        $request->validate([
            // 'ics_name' => 'required',
            // 'commodity' => 'required',
            // 'status' => 'required',
            // 'quantity' => 'required',
            // 'upload_copy_of_performa_invoice' => 'required',
            // 'no_of_packages' => 'required',
        ]);
        try {

            $invoice = '';
            if (!empty($request->file('upload_copy_of_performa_invoice'))) {
                $documentRootPath = 'public/purchase/';
                $file_path = time() . rand() . '.' . $request->file('upload_copy_of_performa_invoice')->getClientOriginalExtension();
                $request->file('upload_copy_of_performa_invoice')->move($documentRootPath, $file_path);
                $invoice = $file_path;
            }
            $data = array(
                'at_user_id' => $request->ics_name,
                'commodity' => $request->commodity,
                'status' => $request->status,
                'quantity' => $request->quantity,
                'upload_copy_of_performa_invoice' => $invoice,
                'no_of_packages' => $request->no_of_packages,
                'ref_operator_type_id' => Auth::guard('misadmin')->user()->ref_operator_type_id,
                'created_by' => Auth::guard('misadmin')->user()->id,
                'created_at' => date('Y-m-d H:i:s')
            );
            AtPurchaseRequest::create($data);
            Alert::success('Success', "Purchase request has been submitted");
            return redirect()->route('superadmin.purchaseRequestList');
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    function checkRemainingQuantityInStock(Request $req)
    {

        $closingstock = AtClosingStock::where('at_user_id', $req->at_user_id)->get();
        $productData = array();
        foreach ($closingstock as $val) {
            $data = getProductAndStatus($val->id, $req->operator_type);
            if (!empty($data)) {
                $productData[] =  $data;
            }
        }
        return $productData;
    }

    function purchaseRequestView($id)
    {
        try {
            $data = AtPurchaseRequest::where('id', $id)->first();
            return view('admin/purchase/processor/purchase-request-view', compact('data'));
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function purchaseReqPost(Request $request)
    {
        $request->validate([
            'orderno' => 'required',
            'order_status' => 'required',
        ]);
        try {
            //dd($request->all());
            $req = AtPurchaseRequest::where('id', $request->orderno)
                // ->where('order_status',0)
                ->first();

            if ($req) {
                $data = array(
                    "at_purchase_request_id"  => $request->orderno,
                    "order_number"  => $request->orderno,
                    "quantity" => $req->quantity,
                    "ref_product_id" => $req->commodity,
                    "order_validity"  => $request->order_validity,
                    "order_status"   => $request->order_status,
                    'created_by' => Auth::guard('misadmin')->user()->id,
                    'created_at' => date('Y-m-d H:i:s')
                );
                $req->update(['order_status' => $request->order_status]);

                AtOrderDetailsReceivedFromBuyer::updateOrCreate([
                    'at_purchase_request_id' => $request->orderno,
                    'created_by' => Auth::guard('misadmin')->user()->id
                ], $data);

                if ($request->order_status == 1) {
                    Alert::success('Success', "Purchase Request has been approved Order No. #00" . $request->orderno);
                    return redirect()->route('superadmin.acceptPurchase', $request->orderno);
                } else {
                    Alert::success('Success', "Purchase Request has been rejected successfully");
                    return redirect()->route('superadmin.rejectPurchase', $request->orderno);
                }
            } else {
                Alert::error('Error', "Technical Issue");
                return redirect()->route('superadmin.purchaseRequestList');
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }


    public function acceptPurchase($id)
    {
//dd(Auth::user()->id);
        
        try {
            $warehouse = UserWarehouse::where('at_user_id', Auth::user()->id)->get();

           // dd($warehouse);
            $orderReqData = AtPurchaseRequest::where('id', $id)->first();
            $ordData = AtOrderDetailsReceivedFromBuyer::with('getOrderDetails')->where('at_purchase_request_id', $id)->get();
            return view('admin/purchase/processor/accept-purchase', compact('id', 'warehouse', 'orderReqData', 'ordData'));
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }
    public function afterOrderAcceptPost(Request $request)
    {

        $request->validate([
            'hid_order_id' => 'required',
            'seller_name' => 'required',
            'purchaser_name' => 'required',
            'quantity' => 'required',
            // 'at_ics_warehouse_details_id' => 'required',
            'rate' => 'required',
            'number_of_packages' => 'required',
            //'status' => 'required',
            //'commodity' => 'required',
            'mode_of_payment' => 'required',
            'bank_detail' => 'required',
            'if_bank_transaction_id' => 'required',
            'upload_cash_receipt' => 'required',
            'transport_date' => 'required',
            'transportation_mode' => 'required',
            'vehicle_number' => 'required',
            'place_of_dispatch' => 'required',
            'place_of_destination' => 'required',
        ]);
        try {

            $purchase_reg_id = AtOrderDetailsReceivedFromBuyer::where('at_purchase_request_id', $request->hid_order_id)->first();

            $data = array(
                'at_order_details_received_from_buyer_id' =>  !empty($purchase_reg_id->id) ? $purchase_reg_id->id : null,
                'seller_name' => !empty($request->seller_name) ? $request->seller_name : null,
                'purchaser_name' => !empty($request->purchaser_name) ? $request->purchaser_name : null,
                'quantity' => !empty($request->quantity) ? $request->quantity : null,
                'at_ics_warehouse_details_id' => !empty($request->at_ics_warehouse_details_id) ? $request->at_ics_warehouse_details_id : null,
                'rate' => !empty($request->rate) ? $request->rate : null,
                'number_of_packages' => !empty($request->number_of_packages) ? $request->number_of_packages : null,
                'status' => !empty($request->status) ? $request->status : null,
                'commodity' => !empty($request->commodity) ? $request->commodity : null,
                'mode_of_payment' => !empty($request->mode_of_payment) ? $request->mode_of_payment : null,
                'bank_detail' => !empty($request->bank_detail) ? $request->bank_detail : null,
                'if_bank_transaction_id' => !empty($request->if_bank_transaction_id) ? $request->if_bank_transaction_id : null,
                'upload_cash_receipt' => !empty($request->upload_cash_receipt) ? $request->upload_cash_receipt : null,
                'transport_date' => !empty($request->transport_date) ? $request->transport_date : null,
                'transportation_mode' => !empty($request->transportation_mode) ? $request->transportation_mode : null,
                'vehicle_number' => !empty($request->vehicle_number) ? $request->vehicle_number : null,
                'place_of_dispatch' => !empty($request->place_of_dispatch) ? $request->place_of_dispatch : null,
                'place_of_destination' => !empty($request->place_of_destination) ? $request->place_of_destination : null,
                'created_by' => Auth::guard('misadmin')->user()->id, // Always set
                'created_at' => date('Y-m-d H:i:s') // Always set
            );
            

            AtOrderAccepted::updateOrCreate(['at_order_details_received_from_buyer_id' => $purchase_reg_id->id], $data);

            $msg = "Details has been added successfully";
            Alert::success('Success', $msg);
            return redirect()->route('superadmin.purchaseRequestList');
        } catch (Exception $e) {
         dd($e->getMessage());
            Log::error($e->getMessage());
            abort('404');
        }
    }


    public function rejectPurchase($id)
    {
        try {
            $warehouse = UserWarehouse::where('at_user_id', Auth::user()->id)->get();
            return view('admin/purchase/processor/reject-purchase', compact('id', 'warehouse'));
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function afterOrderRejectPost(Request $request)
    {
        $request->validate([
            'hid_order_id' => 'required',
            'remark' => 'required'
        ]);
        try {
            $purchase_reg_id = AtOrderDetailsReceivedFromBuyer::where('at_purchase_request_id', $request->hid_order_id)->first();
            $data = array(
                'at_order_details_received_from_buyer_id' => $purchase_reg_id->id,
                'rejected_reason' => $request->remark,
                'created_by' => Auth::guard('misadmin')->user()->id,
                'created_at' => date('Y-m-d H:i:s')
            );

            $add = AtOrderRejected::updateOrCreate(
                ['at_order_details_received_from_buyer_id' => $purchase_reg_id->id],
                $data
            );

            $msg = "Details has been added successfully";
            Alert::success('Success', $msg);
            return redirect()->route('superadmin.purchaseRequestList');
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function domestictc(Request $request)
    {
        try {

            $user_id = Auth::guard('misadmin')->user()->id;
            $operator_type_id = Auth::guard('misadmin')->user()->ref_operator_type_id;

            $order_list2 = DB::select("select at_purchase_request.id, at_purchase_request.commodity, at_closing_stock.id as clsid,at_closing_stock.organic_status, at_closing_stock.closing_stock, at_purchase_request.quantity from at_purchase_request INNER join at_order_details_received_from_buyer as odrb on odrb.at_purchase_request_id = at_purchase_request.id inner join at_order_accepted on at_order_accepted.at_order_details_received_from_buyer_id = odrb.id inner join at_closing_stock on at_closing_stock.at_user_id = at_purchase_request.at_user_id and at_closing_stock.ref_product_id = at_purchase_request.commodity
            inner join at_farmer_standing_crop_details on at_farmer_standing_crop_details.id = at_closing_stock.at_farmer_standing_crop_details_id where at_purchase_request.at_user_id = $user_id and at_purchase_request.order_status = 1  group BY (at_purchase_request.commodity,at_purchase_request.id,at_closing_stock.organic_status,closing_stock,at_purchase_request.quantity,at_closing_stock.id)");


        $product = DB::table('at_batch_creation')->where('at_user_id', $user_id)->get();
        $batch_details = DB::table('at_batch_details')->where('at_user_id', $user_id)->first();
            return view('admin/processor/add', compact('product', 'batch_details'));
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function storeApplyForDomesticTC(Request $request)
    {
        $userId = Auth::user()->id;
        $batch_creation = DB::table('at_batch_creation')->where('at_user_id', $userId)->get();
        $batch_details = DB::table('at_batch_details')->where('at_user_id', $userId)->get();
        // dd($batch_creation[0]->batch_id);
        // dd($batch_details[0]->batch_id);

        try {

            $data = [
            'transaction_certificate_no' => $batch_creation[0]->scope_certificate_no,
            'tc_application_no' => $request->tc_application_no,
            'requested_tc_no' => $request->requested_tc_no,
            'seller_scn' => $request->seller_scn,
            'farm_no' => $request->farm_no,
            'total_qty' => $batch_details[0]->total_quantity,
            'tc_date' => $request->tc_date,
            'operator_type' => $request->operator_type,
            'quantity_for_tc' => $request->qtyFortc,
            'rem_qty' => $batch_creation[0]->quantity,
            'category_code' => $request->category_code,
            'product_code' => $batch_details[0]->product_code,
            'organic_status' => $batch_creation[0]->organic_status,
            'cn_code' => $request->cn_code,
            'batch_no' => $batch_details[0]->batch_id,
            'trade_name_of_product' => $request->trade_name_of_product,
            'lab_test_report' => $request->lab_test_report,
            'psc_report' => $request->psc_report,
            'economic_part' => $request->economic_part,
            'source_from' => $batch_creation[0]->source_from,
            'farm_harvest_year' => $request->farm_harvest_year,
            'nop_status' => 0,
            'qty_value' => $request->qty_value,
            'currency_type_id' => $request->currency_type_id,
            'total_value_currency_wise' => $request->total_value_currency_wise,
            'inr_rate' => $request->inr_rate,
            'eu_category' => $request->eu_category,
            'created_by' => Auth::id(),
            'updated_by' => Auth::id(),
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
            'is_deleted' => $request->is_deleted,
            'deleted_at' => $request->deleted_at,
            'value_inr' => $request->value_inr,
            'at_purchase_request_id' => $request->at_purchase_request_id,
            // Add more columns as needed
        ];

        $insert = AtOpTransactionVsTransactionProduct::create($data);

        return response()->json(['success' => true, 'message' => 'Products added successfully']);

        } catch (Exception $e) {

            Log::error($e->getMessage());
            abort('404');
        }
    }
    public function packingDetailDomesticTC($id)
    {
        $user = getUserById($id);
        $trans = AtOpTransactionVsTransactionProduct::where('created_by', $id)->get();
        $product = DB::table('at_batch_creation')->where('at_user_id', $id)->get();
        $batch_details = DB::table('at_batch_details')->where('at_user_id', $id)->get();
        // packing master list get
        // $packs = RefPackingMaster::get();
        //AtOpTransactionPackingDetails::where(['product_code'=>$trans[0]->ref_product_id,'crested_by',Auth::guard('misadmin')->user()->id])->get();
        //dd($packDet);

        return view('admin/processor/packing_detail_tc23-02-24', compact('trans','user','product','batch_details','id'));
    }

    public function packingDetailAddUpdate($id)
    {
        $user = getUserById($id);
        $trans = AtOpTransactionVsTransactionProduct::where('created_by', $id)->get();
        $product = DB::table('at_batch_creation')->where('at_user_id', $id)->get();
        $batch_details = DB::table('at_batch_details')->where('at_user_id', $id)->get();
        return view('admin/processor/packing_details_add_update', compact('trans','user','product','batch_details'));
    }

    public function domesticTcDetails(Request $request)
    {

        return view('admin/processor/domestic_tc_details');
    }

    public function domesticTcSaveData(Request $request)
    {
        $appData = AtOpTransactionVsTransactionProduct::all();
        return view('admin/processor/domestic_tc_list', compact('appData'));
    }

    public function packingDetailTC($id)
    {
        $trans = AtOpTransactionVsTransactionProduct::with('getTransProductSource')->where('id', $id)->get();
        $packs = RefPackingMaster::get();

        return view('admin/processor/packing_detail_tc', compact('trans', 'packs'));
    }
    public function storePackingDetailTC(Request $request)
    {

        $request->validate([
            'value_inr' => 'required',
            'trade_name_of_product' => 'required',
            'ref_packing_master_id.*' => 'required',
            'no_of_box.*' => 'required',
            'pack_size.*' => 'required',
            'total_qty_in_kg.*' => 'required',
        ]);
        // if(!empty($validator->fails())) {
        // 	return Redirect::back()->withErrors($validator);
        // }
        try {
            //dd($request->all());
            $operator_type_id = Auth::guard('misadmin')->user()->ref_operator_type_id;
            $edtVal = 0;
            if (!empty($request->at_op_transaction_product_sourced_id)) {
                foreach ($request->at_op_transaction_product_sourced_id as $key => $val) {

                    if (!empty($request->at_op_transaction_product_sourced_id[$key])) {
                        $data = array(
                            'at_op_transaction_product_sourced_id'   => $request->at_op_transaction_product_sourced_id[$key],
                            'ref_product_id'   => $request->ref_product_id,
                            'ref_packing_master_id'   => $request->ref_packing_master_id[$key],
                            'no_of_box'   => $request->no_of_box[$key],
                            'pack_size'   => $request->pack_size[$key],
                            'total_qty_in_kg'   => $request->total_qty_in_kg[$key],
                            'created_by' => Auth::guard('misadmin')->user()->id,
                            'updated_by' => Auth::guard('misadmin')->user()->id
                        );

                        $result = AtOpTransactionPackingDetails::updateOrCreate([
                            'id' => $request->row_id[$key],
                        ], $data);
                    }
                }

                if (!empty($result)) {
                    $updateData = array(
                        'value_inr' => $request->value_inr,
                        'trade_name_of_product' => $request->trade_name_of_product,
                    );
                    $res = AtOpTransactionVsTransactionProduct::where('id', $request->trans_id)->update($updateData);

                    //if(isset($request->row_id[0]) && $request->row_id[0]!=''){
                    Alert::success('Success', __('message.add_success'));
                    return redirect()->route('superadmin.TcDetail', $request->trans_id);
                    // }else{
                    // 	Alert::success('Success', __('message.add_success'));
                    // 	return redirect()->back();
                    // }

                }
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function TcDetail($id)
    {

        $data =  AtOpTransactionCertificateEntry::where('at_op_transaction_vs_transaction_product_id', $id)->first();
        return view('admin.batch.tc_details', compact('id', 'data'));
    }


    public function storeTcDetail(Request $request)
    {
        //dd($request->all());
        $request->validate([
            'invoice_no' => 'required',
            'invoice_date' => 'required',
            'invoice_value' => 'required',
            //'place_of_dispatch' => 'required',
            'lot_number' => 'required',
            'place_of_destination' => 'required',
            'marks_no' => 'required',
            'reference_no' => 'required',
        ]);
        // if(!empty($validator->fails())) {
        // 	return Redirect::back()->withErrors($validator);
        // }
        try {

            /// Date of Transport
            if (!empty($request->road_transport_date)) {
                $transport_date = date('Y-m-d H:i:s', strtotime($request->road_transport_date));
            } elseif (!empty($request->train_transport_date)) {
                $transport_date = date('Y-m-d H:i:s', strtotime($request->train_transport_date));
            } else {
                $transport_date = null;
            }


            // dd(date('Y-m-d H:i:s',strtotime($request->invoice_date[0])));
            $data = array(
                'exporter_seller_name'   => $request->exporter_seller_name ?? null,
                'seller_email'   => $request->seller_email ?? null,
                'seller_at_op_certificate_standard_details_id'   => $request->seller_at_op_certificate_standard_details_id ?? null,
                'exporter_seller_address'   => $request->exporter_seller_address ?? null,
                'buyer_id_proof'   => $request->buyer_id_proof ?? null,
                'buyer_name'   => $request->buyer_name ?? null,
                'buyer_address'   => $request->buyer_address ?? null,
                'buyer_at_op_certificate_standard_details_id'   => $request->buyer_at_op_certificate_standard_details_id ?? null,
                'buyer_ref_state_id'   => $request->buyer_ref_state_id ?? null,
                'buyer_email'   => $request->buyer_email ?? null,
                'invoice_no'   => $request->invoice_no[0] ?? null,
                'invoice_date'   => date('Y-m-d H:i:s', strtotime($request->invoice_date[0])) ?? null,
                'invoice_value'   => $request->invoice_value ?? null,
                //'place_of_dispatch'   => $request->place_of_dispatch ?? null,
                'place_of_destination'   => $request->place_of_destination ?? null,
                'marks_no'   => $request->marks_no ?? null,
                'reference_no'   => $request->reference_no ?? null,
                'transport_mode'   => $request->transport_mode ?? null,

                'container_no_road'   => $request->container_no_road ?? null,
                'transport_doc_no'   => $request->transport_doc_no ?? null,
                'transport_date'   => $transport_date ?? null,

                'train_no'   => $request->train_no ?? null,
                'wagon_no'   => $request->wagon_no ?? null,
                'train_transport_date'   => date('Y-m-d H:i:s', strtotime($request->train_transport_date)) ?? null,

                'flight_no'   => $request->flight_no ?? null,
                'flight_date'   => date('Y-m-d H:i:s', strtotime($request->flight_date)) ?? null,
                'airway_bill_no'   => $request->airway_bill_no ?? null,
                'airway_bill_date'   => date('Y-m-d H:i:s', strtotime($request->airway_bill_date)) ?? null,
                'container_no_air'   => $request->container_no_air ?? null,


                'ship_no'   => $request->ship_no ?? null,
                'ship_name'   => $request->ship_name ?? null,
                'vessel_date'   => $request->vessel_date ?? null,
                'bill_of_lading'   => $request->bill_of_lading ?? null,
                'date_of_lading'   => $request->date_of_lading ?? null,
                'container_no_ship'   => $request->container_no_ship ?? null,

                'gross_weight'   => $request->gross_weight ?? null,
                'created_by' => Auth::guard('misadmin')->user()->id,
                'updated_by' => Auth::guard('misadmin')->user()->id,
                'at_op_transaction_vs_transaction_product_id' => $request->at_op_transaction_vs_transaction_product_id,
                'lot_number' => $request->lot_number,
            );
            //dd($data);
            $saveData = AtOpTransactionCertificateEntry::updateOrCreate(['at_op_transaction_vs_transaction_product_id' => $request->at_op_transaction_vs_transaction_product_id], $data);

            Alert::success('Success', __('message.add_success'));
            return redirect()->route('superadmin.forwardToCB', $request->at_op_transaction_vs_transaction_product_id);
            // if(!empty($saveData)){
            // 	Alert::success('Success', __('message.add_success'));
            // 	return redirect()->route('superadmin.TcDetail',$request->at_op_transaction_vs_transaction_product_id);
            // }else{
            // 	Alert::success('Success', 'Something Went Wrong!');
            // 	return redirect()->back();
            // }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function domesticPendingTC(Request $request){

        $userId = Auth::id();
        abort_unless(\Gate::allows('user_access'), 403);
        if ($request->ajax()) {
            $tcData = AtOpTransactionVsTransactionProduct::with('getTransProductSource')->where('created_by', $userId)->get();

            return Datatables::of($tcData)
                ->addIndexColumn()

                 ->addColumn('tc_application_no', function ($row) {
                     return $row->tc_application_no ?? '';
                 })

                 ->addColumn('tc_date', function ($row) {
                     return $row->tc_date ?? '';
                 })

                 ->addColumn('seller_scn', function ($row) {
                     return $row->seller_scn ?? '';
                 })

                 ->addColumn('nop_status', function ($row) {
                     return $row->nop_status ?? '';
                 })

                 ->addColumn('tc_type', function ($row) {
                    $tc_type = 'Domestic';
                     return $tc_type ?? '';
                 })
                 ->addColumn('country', function ($row) {
                    $country = 'India';
                     return $country ?? '';
                 })

                 ->addColumn('action', function ($row) {
                     $oper_type = $row->nop_status ?? '';
                     $addEditDetailButton = '';
                         $addEditDetailButton .= '<a href="' . route('superadmin.viewTcApplication',$row->id) . '" class="viewdata"><span>View Application</span></a>';
                     return $addEditDetailButton;

                 })
                 ->rawColumns(['action', 'role', 'farmer' ])
                 ->make(true);
         }
         return view("admin.processor.pending_domestinc_tc");
    }

    public function viewTcApplication($id){

        $appData = AtOpTransactionVsTransactionProduct::where('id', $id)->first();

        return view("admin.usermanagement.pdf.tcCertificate", compact('appData'));
    }
}

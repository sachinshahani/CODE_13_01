<?php

namespace App\Http\Controllers\Admin\purchase;

use App\Http\Controllers\Controller;
use App\Models\Permission;
use App\Models\Role;
use App\Models\RoleUser;
use App\Models\User;
use App\Models\RefBank;
use App\Models\AtPurchaseDetails;
use App\Models\UserWarehouse;
use App\Models\UserWarehouseManagerOfficers;
use App\Models\AtStockTransportationDetails;
use App\Models\AtPurchaseStorageClosingStock;
use Exception;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;
use DataTables;

class ICSPurchaseController extends Controller
{

    public function purchaseList(Request $request){

        $id = Auth::user()->id;

        if ($request->ajax()) {
            $totalData =  AtPurchaseDetails::with('getClosingStockDetails')->where('at_user_id',Auth::user()->id)->get();
            return Datatables::of($totalData)
                ->addIndexColumn()
                ->addColumn('farm_number', function($row){
                    return getFarmDetailsByID($row->at_farm_details_id)->farm_no ?? '';
                })->addColumn('farmer_name', function($row){
                    return getFarmersByFarmID($row->at_farm_details_id);
                })->addColumn('date_of_purchase', function($row){
                    return ($row->date_of_purchase)?date('d-m-Y', strtotime($row->date_of_purchase??'')) :'N/A';
                })->addColumn('purchase_id', function($row){
                    return $row->purchase_id ?? '';
                })->addColumn('Commodity', function($row){
                    return getHscodeProductName($row->commodity) ?? 'N/A';
                })->addColumn('district_name', function($row){
                    return$row->ref_district_id ?? '';
                })->addColumn('state_name', function($row){
                    return $row->ref_state_id ?? '';
                })->addColumn('purchase_qty', function($row){
                    return $row->purchase_qty ?? '';
                })->addColumn('date_of_harvest', function($row){
                    return date('d-m-Y', strtotime($row->harvest_date))??'';
                })
                ->addColumn('action', function($row){

                    $actionBtn = '<a href="'.route('superadmin.purchaseProduct',[$row->id]).'" class="btn btn-soft-primary"><span><i class="ri-shopping-bag-3-line" data-toggle="tooltip" title="Purchase Product"></i></span></a><a href="JavaScript:void(0);" class="btn btn-soft-primary ms-1"><span><i class="ri-eye-line" data-toggle="tooltip" title="Purchase Product"></i></span></a>';
                    return $actionBtn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        return view('admin/purchase/ics/purchase-list');
	}



    public function purchaseProduct($id){

        $result = AtPurchaseDetails::where('id', $id)->first();
        $fid = getFarmDetailsByID($result->at_farm_details_id)->at_farmer_reg_details_id;
        return view('admin/purchase/ics/purchase-product',compact('id','fid','result'));
    }



    public function storePurchaseProduct(Request $request){

        $request->validate([
            'date_of_purchase' => 'required',
            'purchase_qty' => 'required',

        ]);
        try {
            $id = Auth::user()->id;

            if(empty($request->store_warehouse)){

                $data = array(
                    'date_of_purchase'   => $request->date_of_purchase??null,
                    'purchase_qty' => $request->purchase_qty??'null',
                    'created_by' => Auth::guard('misadmin')->user()->id,
                    'updated_by' => Auth::guard('misadmin')->user()->id
                );
                AtPurchaseDetails::where('id', $request->row_id)->update($data);
                return redirect()->back()->with('success', 'Added Successfully!');
            } else {

                if($request->store_warehouse==3){
                    $swdata = array(
                        'store_warehouse'   => $request->store_warehouse??null,
                        'updated_by' => Auth::guard('misadmin')->user()->id
                    );
                    AtPurchaseDetails::where('id', $request->row_id)->update($swdata);
                    return redirect()->back()->with('success', 'Added Successfully!');
                }else{
                    $whData = UserWarehouse::where('at_user_id',$id)->first();

                    if(!empty($whData)){

                        if($whData->capacity < $request->purchase_qty){
                            return redirect()->back()->with('error', 'Warehouse space not available.');
                        }else{
                            $swdata = array(
                                'store_warehouse'   => $request->store_warehouse??null,
                                'updated_by' => Auth::guard('misadmin')->user()->id
                            );
                            AtPurchaseDetails::where('id', $request->row_id)->update($swdata);
                        }
                    }else{
                        return redirect()->back()->with('error', 'Please Select another warehouse.');
                    }
                return redirect()->route('superadmin.storageStock',$request->row_id);
                }
            }

        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function storageStock($id){
        $result = AtPurchaseDetails::where('id', $id)->first();
        $stockTranDet =  AtStockTransportationDetails::where('at_purchase_details_id', $result->id)->first();
        $id = Auth::user()->id;
        $productData = getProductAndStatus($result->at_closing_stock_id,'ics');
        return view('admin/purchase/ics/storage-stock',compact('id','result','productData','stockTranDet'));
    }

    public function storeStorageStock(Request $request){

        $request->validate([
            'transportation_date' => 'required',
            'ref_transportation_mode_id' => 'required',
            'vehicle_number' => 'required',
            'purchased_qty' => 'required',
            'place_of_dispatch' => 'required',
            'place_of_destination' => 'required',

        ]);
        //dd($request->all());
        try {

            $data = array(
                'at_purchase_details_id'   => $request->at_purchase_details_id??null,
                'at_closing_stock_id' => $request->at_closing_stock_id??null,
                'transportation_date' => $request->transportation_date??null,
                'ref_transportation_mode_id' => $request->ref_transportation_mode_id??null,
                'vehicle_number' => $request->vehicle_number??null,
                'purchased_qty' => $request->purchased_qty??null,
                'place_of_dispatch' => $request->place_of_dispatch??null,
                'place_of_destination' => $request->place_of_destination??null,
                'mandator_address' => $request->mandator_address??null,
                'commodity' => $request->commodity??null,
                'status' => $request->status??null,
                'created_by' => Auth::guard('misadmin')->user()->id,
                'updated_by' => Auth::guard('misadmin')->user()->id
            );
            AtStockTransportationDetails::updateOrCreate([
                'at_purchase_details_id' => $request->at_purchase_details_id,
                'created_by' =>  Auth::guard('misadmin')->user()->id,
            ],$data);

            Alert::success('Success', __('message.add_success'));
            return redirect()->route('superadmin.closingOfStock',$request->at_purchase_details_id);

        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function closingOfStock($id){
        $result = AtPurchaseDetails::where('id', $id)->first();
        $user_id = Auth::user()->id;
        $productData = getProductAndStatus($result->at_closing_stock_id,'ics');
        $whmData = UserWarehouseManagerOfficers::where('at_user_id',$user_id)->get();
        $whData = UserWarehouse::where('at_user_id',$user_id)->first();
        $data = AtPurchaseStorageClosingStock::where('created_by',$user_id)->first();
        return view('admin/purchase/ics/closing-of-stock',compact('id','result','whmData','whData','data','productData'));
    }

    public function storeClosingOfStock(Request $request){
        $request->validate([
            // 'transportation_date' => 'required',
            // 'ref_transportation_mode_id' => 'required',
            // 'vehicle_number' => 'required',
            // 'purchased_qty' => 'required',
            // 'place_of_dispatch' => 'required',
            // 'place_of_destination' => 'required',

        ]);

        try {
            $id = Auth::user()->id;
            $whData = UserWarehouse::where('at_user_id',$id)->where('warehouse_available','ics')->first();

            $data = array(
                'at_purchase_details_id'   => $request->at_purchase_details_id??null,
                'at_ics_warehouse_details_id' => $whData->id??null,
                //'at_ics_purchase_manager_details_id' => $request->at_ics_purchase_manager_details_id??null,
                'at_ics_warehouse_manager_details_id' => $request->at_ics_warehouse_manager_details_id??null,
                'transport_date' => $request->transport_date??null,
                'status' => $request->status??null,
                'commodity' => $request->commodity??null,
                'qty' => $request->qty??null,
                'no_of_bags_packages' => $request->no_of_bags_packages??null,
                'weight' => $request->weight??null,
                'address' => $request->address??null,
                'date_of_storage' => $request->date_of_storage??null,
                'status' => $request->status??null,
                'created_by' => Auth::guard('misadmin')->user()->id,
                'updated_by' => Auth::guard('misadmin')->user()->id
            );
            //dd($data);
            AtPurchaseStorageClosingStock::updateOrCreate([
                'at_purchase_details_id' => $request->at_purchase_details_id,
                'created_by' =>  Auth::guard('misadmin')->user()->id,
            ],$data);

            Alert::success('Success', __('message.add_success'));
            return redirect()->back();

        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }



}





<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Permission;
use App\Models\Role;
use App\Models\RoleUser;
use App\Models\User;
use App\Models\RefBank;
use Yajra\DataTables\DataTables;
use App\Models\AtFarmerStandingCorpDetail;
use Exception;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;

class WildHarvestPurchaseController extends Controller
{

    public function purchaseList(Request $request){
        $user_id = Auth::guard('misadmin')->user()->id;
        dd($user_id);
		return view('admin.closing_stock.update_closing_stock_scope',compact('user_id'));
	}


	


}





<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Permission;
use App\Models\Role;
use App\Models\MandatorRegister;
use App\Models\RefState;
use App\Models\RefDistrict;
use App\Models\RefRegion;
use App\Models\RefVillage;
use DataTables;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;

use App\Services\FileService;

class MandatorManagementController extends Controller
{
    public function index(Request $request)
    {

        if ($request->ajax()) {

            // if (Auth::guard('misadmin')->user()->roles[0]->id==1) {
            //     $user = User::with('roles')->where('ref_operator_type_id',$id)->where('created_by',$userId)->orderBy('id', 'DESC')
            //         ->get();

            // } else {
            //     $user = User::with('roles')->where('id', Auth::guard('misadmin')->user()->id)->where('ref_operator_type_id',$id)->orderBy('id', 'DESC')
            //     ->get();
            // }
            $user = MandatorRegister::orderBy('id', 'DESC')->get();
            return Datatables::of($user)
                ->addIndexColumn()

                ->addColumn('id', function($row) {
                    // Get today's date in mY format (month and year)
                    $todayDate = now()->format('mY'); // 'm' is for month, 'Y' is for year
                
                    // Pad the ID to 5 digits
                    $paddedId = str_pad($row->id, 4, "0", STR_PAD_LEFT);
                
                    // Return the formatted string: ORG/today_date/id
                    return 'ORG/' . $todayDate . '/' . $paddedId;
                })
                
                
                ->addColumn('name', function ($row) {

                    // $first_name = $row->contact_first_name ?? '';
                    // $middle_name = $row->middle_name ?? '';
                    // $last_name = $row->last_name ?? '';
                    // return $first_name . ' ' . $middle_name . ' ' . $last_name;

                    $firstName = $row->mandator_name ?? '';
                    $lastName = $row->last_name ?? '';
                    $address = $row->address ?? '';
                    $gst = $row->gst_number ?? '';
                    $gst_state = get_state_name($row->gst_state_id ?? '');
                    $pan = $row->pan ?? '';
                    $pin = $row->pin_code ?? '';
                    $state = get_state_name($row->state_id ?? '');
                    
                    // Build the action button string with bold labels
                    $actionBtn = 
                        "<strong>PAN:</strong> " . $pan . "<br>" .
                        "<strong>Name:</strong> " . trim($firstName . ' ' . $lastName) . "<br>" .
                        "<strong>GST No:</strong> " . $gst . " - " . $gst_state . "<br>" .  // Corrected line
                        "<strong>Address:</strong> " . $address . "<br>" .
                        "<strong>State:</strong> " . $state . "<br>" .
                        "<strong>Pin:</strong> " . $pin;
                    
                    return $actionBtn;
                    




                })
                ->addColumn('contact_details', function ($row) {


                    $addhar = $row->aadhar_no ?? '';

                    if (preg_match('/^eyJpdiI6.*$/', $addhar)) {
                        try {
                            $addhar = Crypt::decrypt($addhar);
                        } catch (DecryptException $e) {
                            $addhar = 'Invalid Aadhaar No';
                        }
                    }
                        $actionBtn = 
                            "<strong>Name:</strong> "   . ($row->contact_first_name ?? '') . " " . ($row->contact_last_name ?? '') . "<br>" .
                            "<strong>Designation:</strong> " . ($row->contact_designation ?? '') . "<br>" .
                            "<strong>Mobile No:</strong> " . ($row->contact_mobile ?? '') . "<br>" .
                            "<strong>Email Id:</strong> " . ($row->contact_email ?? '') . "<br>" .
                            "<strong>Aadhaar No:</strong> " . (maskAadhaarNumber($addhar));

                        return $actionBtn;

                   // return $row->email ?? '';



                })->addColumn('doc', function ($row) {



                    $actionBtn = 
                    "<strong>Service Provider Resume:</strong> "  . 
                    "<a href='#' style='color: blue;'>View</a>" . "<br>" .
                    "<strong>Copy of Certificate of Registration under Companies Act:</strong> " . 
                    "<a href='#' style='color: blue;'>View</a>" . "<br>" .
                    "<strong>Upload Company Office Photo:</strong> " . 
                    "<a href='#' style='color: blue;'>View</a>" . "<br>";
                
                   return $actionBtn;
                

                    
                })->addColumn('created_on', function ($row) {

                    return  date('d-m-Y', strtotime($row->created_at)) ?? '';
                })
                // ->addColumn('status', function($row){
                //     $status='';
                //     if($row->status==1)
                //         return  '<span class="badge badge-soft-danger">Pending</span>';
                //     elseif($row->status==0)
                //         return  '<span class="badge badge-soft-primary">Profile Completed</span>';
                //     elseif($row->status==2)
                //         return  '<span class="badge badge-soft-success">Approved</span>';
                //     elseif($row->status==3)
                //         return  '<span class="badge badge-soft-danger">Rejected</span>';
                // })
                ->addColumn('action', function ($row) {
                    $oper_type = $row->ref_operator_type_id ?? '';
                    $addEditDetailButton = '';
                    // if($oper_type == 2){
                    //     $addEditDetailButton = '<a href='.route('superadmin.icsuser.step1', [$row->id]).'><span><i class="mdi mdi-pencil text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Edit Individual User"></i></span></a>';
                    // }else if($oper_type == 3){
                    //     $addEditDetailButton = '<a href='.route('superadmin.usermanagement.deptUser.individualUserAdd', [$row->id]).'><span><i class="mdi mdi-pencil text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Edit Individual User"></i></span></a>';
                    // }elseif($oper_type == 4){
                    //     $addEditDetailButton = '<a href='.route('superadmin.usermanagement.deptUser.wildHarvestUserAdd', [$row->id]).'><span><i class="mdi mdi-pencil text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Edit Individual User"></i></span></a>';
                    // }elseif($oper_type == 5){
                    //     $addEditDetailButton = '<a href='.route('superadmin.tradersUseredit', [$row->id]).'><span><i class="mdi mdi-pencil text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Edit Individual User"></i></span></a>';
                    // }elseif($oper_type == 6){
                    //     $addEditDetailButton = '<a href='.route('superadmin.processorUseredit', [$row->id]).'><span><i class="mdi mdi-pencil text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Edit Individual User"></i></span></a>';
                    // }
                    // if (Auth::guard('misadmin')->user()->roles[0]->id==1 && $row->status!=0) {
                    // $addEditDetailButton.= '<a href='.route('superadmin.usermanagement.deptUser.view', [$row->id]).' target="_blank"><span><i class="mdi mdi-eye text-muted fs-16 align-middle me-1" data-toggle="tooltip"  title="View User"></i></span></a>';
                    // }
                    if (Auth::guard('misadmin')->user()->roles[0]->id == 1) {
                        $addEditDetailButton .= '<a href=' . route('superadmin.mandatormanagement.edit', [$row->id]) . ' target="_blank"><span><i class="mdi mdi-pencil text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Edit Individual User"></i></span></a>';

                        $addEditDetailButton .= '<a href=' . route('superadmin.mandatormanagement.delete', [$row->id]) . ' ><span><i class="mdi mdi-delete-circle text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Edit Individual User"></i></span></a>';
                    }
                    return $addEditDetailButton;
                })
                ->rawColumns(['action', 'status', 'name', 'contact_details', 'doc'])
                ->make(true);
        }
        return view('admin/mandatormanagement/index');
    }

    public function create()
    {
        $states = RefState::orderBy('state_name', 'ASC')->get();
        $districts = RefDistrict::orderBy('district_name', 'ASC')->get();
        $regions = RefRegion::orderBy('block_tehsil_name', 'ASC')->get();
        $villages = RefVillage::orderBy('village_name', 'ASC')->limit(100)->get();

        return view('admin/mandatormanagement/create', compact('states', 'districts', 'regions', 'villages'));
    }


    public function edit($id)
    {
        $edit = MandatorRegister::where('id', $id)->first();
        $districts = RefDistrict::where('ref_state_id', $edit->state_id)->orderBy('district_name', 'ASC')->get();
        $regions = RefRegion::where('ref_district_id', $edit->district_id)->orderBy('block_tehsil_name', 'ASC')->get();
        $villages = RefVillage::where('ref_block_tehsil_id', $edit->taluka_mandal_id)->orderBy('village_name', 'ASC')->limit(100)->get();
        return view('admin/mandatormanagement/edit', compact('edit', 'districts', 'regions', 'villages'));
    }



    public function mandatorstore(Request $request, FileService $fileService)
    {

        // return $request;
        $request->validate([
            'mandator_name' => 'required',
            //'gst' => 'required',
            'contact_first_name' => 'required',
            'contact_last_name' => 'required',
            'mobile' => 'required',
            'email' => 'required',
            'aadhar_no' => 'required',
            'pan' => 'required|unique:mandator_register,pan',
            'state_id' => 'required',
            'district_id' => 'required',
            'taluka_mandal_id' => 'required',
            'village_id' => 'required',
            'pin_code' => 'required',
            'address' => 'required',
        ]);
       
        ///contact photo
        if (!empty($request->file('contact_photo'))) {
            if (!empty($request->contact_photo_edit)) {
                $imagePath = public_path('mandator/contact_photo/') . $request->contact_photo_edit;
                deleteOldImage($request->contact_photo_edit, $imagePath);
            }
            $documentRootPath = 'public/mandator/contact_photo/';
            $file_path = time() . rand() . '.' . $request->file('contact_photo')->getClientOriginalExtension();
            $request->file('contact_photo')->move($documentRootPath, $file_path);
            $contact_photo = $file_path;
        } else {
            if (!empty($request->contact_photo_edit))
                $contact_photo = $request->contact_photo_edit;
        }

        //ID proof
        if (!empty($request->file('id_proof'))) {
            if (!empty($request->id_proof_edit)) {
                $imagePath = public_path('mandator/id_proof/') . $request->id_proof_edit;
                deleteOldImage($request->id_proof_edit, $imagePath);
            }
            $documentRootPath = 'public/mandator/id_proof/';
            $file_path = time() . rand() . '.' . $request->file('id_proof')->getClientOriginalExtension();
            $request->file('id_proof')->move($documentRootPath, $file_path);
            $id_proof = $file_path;
        } else {
            if (!empty($request->id_proof_edit))
                $id_proof = $request->id_proof_edit;
        }

        //mandator resume
        
        if (!empty($request->file('mandator_resume'))) {
            if (!empty($request->mandator_resume_edit)) {
                $imagePath = public_path('mandator/mandator_resume/') . $request->mandator_resume_edit;
                deleteOldImage($request->mandator_resume_edit, $imagePath);
            }
            $documentRootPath = 'public/mandator/mandator_resume/';
            $file_path = time() . rand() . '.' . $request->file('mandator_resume')->getClientOriginalExtension();
            $request->file('mandator_resume')->move($documentRootPath, $file_path);
            $mandator_resume = $file_path;
        } else {
            if (!empty($request->mandator_resume_edit))
                $mandator_resume = $request->mandator_resume_edit;
        }

        $data = array(
            'mandator_name' => $request->mandator_name,
            'gst_number' => $request->gst_number,
            'gst_state_id' => $request->gst_state,
            'contact_first_name' => $request->contact_first_name,
            'contact_middle_name' => $request->contact_middle_name,
            'contact_last_name' => $request->contact_last_name,
            'mobile' => $request->mobile,
            'email' => $request->email,
            'aadhar_no' => $request->aadhar_no,
            'pan' => $request->pan,
            'state_id' => $request->state_id,
            'district_id' => $request->district_id,
            'user_name' => $request->email,
            'taluka_mandal_id' => $request->taluka_mandal_id,
            'village_id' => $request->village_id,
            'pin_code' => $request->pin_code,
            'address' => $request->address,
            'status' => 0,
            'created_by' => Auth::guard('misadmin')->user()->id,
            'contact_mobile' => $request->cp_mobile,
            'contact_email' => $request->cp_email,
            'contact_designation' => $request->contact_designation,
            'contact_photo' => $contact_photo,
            //'contact_aadhar_no'=> $contact_aadhar_no,
            'id_proof' => $id_proof,
            'mandator_resume' => $mandator_resume,
        );

     // dd($request->all(), $data);
        //dd($data);
        $user = MandatorRegister::create($data);
        return redirect()->back()->with('success', 'Registered Successfully.');
    }

  


    public function mandatorUpdate(Request $request)
    {

        try {
            //dd($request->all());
            ///contact photo
            if (!empty($request->file('contact_photo'))) {
                if (!empty($request->contact_photo_edit)) {
                    $imagePath = public_path('mandator/contact_photo/') . $request->contact_photo_edit;
                    deleteOldImage($request->contact_photo_edit, $imagePath);
                }
                $documentRootPath = 'public/mandator/contact_photo/';
                $file_path = time() . rand() . '.' . $request->file('contact_photo')->getClientOriginalExtension();
                $request->file('contact_photo')->move($documentRootPath, $file_path);
                $contact_photo = $file_path;
            } else {
                if (!empty($request->contact_photo_edit))
                    $contact_photo = $request->contact_photo_edit;
            }

            //ID proof
            if (!empty($request->file('id_proof'))) {
                if (!empty($request->id_proof_edit)) {
                    $imagePath = public_path('mandator/id_proof/') . $request->id_proof_edit;
                    deleteOldImage($request->id_proof_edit, $imagePath);
                }
                $documentRootPath = 'public/mandator/id_proof/';
                $file_path = time() . rand() . '.' . $request->file('id_proof')->getClientOriginalExtension();
                $request->file('id_proof')->move($documentRootPath, $file_path);
                $id_proof = $file_path;
            } else {
                if (!empty($request->id_proof_edit))
                    $id_proof = $request->id_proof_edit;
            }

            //mandator resume
            if (!empty($request->file('mandator_resume'))) {
                if (!empty($request->mandator_resume_edit)) {
                    $imagePath = public_path('mandator/mandator_resume/') . $request->mandator_resume_edit;
                    deleteOldImage($request->mandator_resume_edit, $imagePath);
                }
                $documentRootPath = 'public/mandator/mandator_resume/';
                $file_path = time() . rand() . '.' . $request->file('mandator_resume')->getClientOriginalExtension();
                $request->file('mandator_resume')->move($documentRootPath, $file_path);
                $mandator_resume = $file_path;
            } else {
                if (!empty($request->mandator_resume_edit))
                    $mandator_resume = $request->mandator_resume_edit;
            }


            $user = MandatorRegister::find($request->editId);
            $user->mandator_name = $request->mandator_name;
            $user->contact_first_name = $request->contact_first_name;
            $user->contact_middle_name = $request->contact_middle_name;
            $user->contact_last_name = $request->contact_last_name;
            $user->mobile = $request->mobile;
            $user->aadhar_no = $request->aadhar_no;
            $user->address = $request->address;
            $user->village_id = $request->village_id;
            $user->taluka_mandal_id = $request->taluka_mandal_id;
            $user->district_id = $request->district_id;
            $user->state_id = $request->state_id;
            $user->pin_code = $request->pin_code;
            $user->email = $request->email;
            $user->pan = $request->pan;
            $user->contact_mobile = $request->cp_mobile;
            $user->contact_email = $request->cp_email;
            $user->contact_designation = $request->contact_designation;
            $user->contact_photo = $contact_photo;
            $user->id_proof = $id_proof;
            $user->mandator_resume = $mandator_resume;

            $user->updated_by = Auth::guard('misadmin')->user()->id;
            $user->save();
            return redirect()->back()->with('success', "Update  Successfully.");
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function delete(Request $request)
    {
        try {
            //    return $request->id;
            // $id = $request->id;
            // $user = MandatorRegister::find($id);
            // $user->is_deleted = 1;
            // $user->deleted_at = date('Y-m-d H:i:s');
            // $user->save();

            MandatorRegister::where('id', $request->id)->delete();


            return redirect()->back()->with('success', "Deleted  Successfully.");
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }
}

<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\AtImportedProductMaster;
use App\Models\MandatorRegister;
use App\Models\AtFarmerRegDetail;
use App\Models\RefDistrict;
use App\Models\RefState;
use App\Models\AtOpCertificateStandardDetail;
use App\Models\AtOpTransactionVsTransactionProduct;
use App\Models\AtExternalInspection;
use App\Models\AtRiskAssessment;
use App\Models\AtFarmDetails;
use App\Models\AtBatchDetail;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class ApedaMisReportController extends Controller
{
    public function ActivCb()
    {

        return view('admin.apeda_mis_report.active-cb');
    }
    public function ListofOperator()
    {

        return view('admin.apeda_mis_report.list_of_operator');
    }
    public function ListofMandatator()
    {

        return view('admin.apeda_mis_report.list_of_mandatator');
    }
    public function FarmerCount()
    {

        return view('admin.apeda_mis_report.farmer_count');
    }
    public function WildCollectorsCount()
    {

        return view('admin.apeda_mis_report.Wild_collectors_count');
    }
    public function ScopeCertificateNPOP()
    {

        return view('admin.apeda_mis_report.ScopeCertificate');
    }
    public function AmmendmentAnnexure()
    {

        return view('admin.apeda_mis_report.AmmendmentAnnexure');
    }
    public function Detailsofoperators()
    {

        return view('admin.apeda_mis_report.Detailsofoperators');
    }
    public function OperatorNOCDetails()
    {

        return view('admin.apeda_mis_report.OperatorNOCDetails');
    }
    public function ApprovedInputs()
    {

        return view('admin.apeda_mis_report.ApprovedInputs');
    }
    public function Suspended()
    {

        return view('admin.apeda_mis_report.SuspendedTerminatedoperator');
    }
    public function TCLotBatchSelfConsumption()
    {

        return view('admin.apeda_mis_report.TCLotBatchSelfConsumption');
    }
    public function CertificationBodyActivity()
    {

        return view('admin.apeda_mis_report.CertificationBodyActivity');
    }
    public function FarmValueAddedProduct()
    {

        return view('admin.apeda_mis_report.FarmValueAddedProduct');
    }
    public function ProductWiseClosingStock()
    {

        return view('admin.apeda_mis_report.ProductWiseClosingStock');
    }
    public function SplitFarm()
    {

        return view('admin.apeda_mis_report.SplitFarm');
    }
    public function InspectorsOfCertificationBody()
    {

        return view('admin.apeda_mis_report.InspectorsOfCertificationBody');
    }
    public function ApprovedInputsManufacturer()
    {

        return view('admin.apeda_mis_report.ApprovedInputsManufacturer');
    }
    public function TracenetProductMaster()
    {

        return view('admin.apeda_mis_report.TracenetProductMaster');
    }
    public function DetailsOfOperatorsStock()
    {

        return view('admin.apeda_mis_report.DetailsOfOperatorsStock');
    }
    public function AddingINTC()
    {
        return view('admin.apeda_mis_report.AddingINTC');
    }
    public function INTCReport()
    {
        return view('admin.apeda_mis_report.INTCReport');
    }
    public function TraderWarehouseDetails()
    {
        return view('admin.apeda_mis_report.TraderWarehouseDetails');
    }

    //------------------Export Report-----------------------//
    public function StateWiseIncludingExporter()
    {
        return view('admin.apeda_mis_report.export_report.state_wise_include');
    }


    public function StateWiseIncludingExporterSearch(Request $request)
    {
        try {
            if ($request->ajax()) {


                $state = $request->input('state');
                $fromDate = $request->input('from_date');
                $toDate = $request->input('to_date');

                $query = AtImportedProductMaster::query()
                    ->leftJoin('at_imported_product_details', 'at_imported_product_master.id', '=', 'at_imported_product_details.id')
                    ->leftJoin('ref_product', 'at_imported_product_details.ref_product_id', '=', 'ref_product.id')
                    ->leftJoin('at_user', DB::raw('CAST(at_imported_product_master.created_by AS bigint)'), '=', 'at_user.id');

                // Apply filters to the query
                if ($state) {
                    $query->where('at_user.ref_state_id', $state);
                }

                if ($fromDate) {
                    $query->whereDate('at_imported_product_master.created_at', '>=', $fromDate);
                }

                if ($toDate) {
                    $query->whereDate('at_imported_product_master.updated_at', '<=', $toDate);
                }

                $finalData = $query->select([
                    'at_imported_product_master.*',
                    'at_imported_product_details.import_qty_in_mt',
                    'at_imported_product_details.ref_product_id',
                    'ref_product.ref_category_id',
                    'at_user.first_name',
                    'at_user.address',
                    'at_user.mobile_no',
                    'at_user.email',
                    'at_user.ref_state_id',
                ])->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()
                    ->addColumn('state', function ($row) {
                        return getStateNameById($row->ref_state_id ?? 'N/A');
                    })
                    ->addColumn('cbname', function ($row) {
                        return $row->first_name ?? '';
                    })
                    ->addColumn('exporter', function ($row) {
                        return $row->exporter_name ?? '';
                    })
                    ->addColumn('address', function ($row) {
                        return $row->address ?? 'address not found';
                    })
                    ->addColumn('mobile_no', function ($row) {
                        return $row->mobile_no ?? 'N/A';
                    })
                    ->addColumn('email', function ($row) {
                        return $row->email ?? 'email not found';
                    })
                    ->addColumn('category', function ($row) {
                        return getCategoryNameById($row->ref_category_id ?? 'N/A');
                    })
                    ->addColumn('product_name', function ($row) {
                        return $row->ref_product_id ?? 'N/A';
                    })
                    ->addColumn('hscode', function ($row) {
                        return $row->ref_product_id ?? 'N/A';
                    })
                    ->addColumn('country', function ($row) {
                        return getCountryName($row->ref_country_master_id ?? 'N/A');
                    })
                    ->addColumn('exported_qty', function ($row) {
                        return $row->import_qty_in_mt ?? 'N/A';
                    })
                    ->addColumn('total_value_in_lakh', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 100000) . ' lakh' : 'N/A';
                    })
                    ->addColumn('total_value_in_crore', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 10000000) . ' crore' : 'N/A';
                    })
                    ->addColumn('total_value_in_usd', function ($row) {
                        // Assuming a conversion rate, e.g., 1 INR = 0.013 USD
                        $conversionRate = 0.012;
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt * $conversionRate) . ' USD' : 'N/A';
                    })

                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    public function StateWiseOnly()
    {
        return view('admin.apeda_mis_report.export_report.StateWiseOnly');
    }


    public function StateWiseOnlySearch(Request $request)
    {
        try {
            if ($request->ajax()) {


                $state = $request->input('state');
                $fromDate = $request->input('from_date');
                $toDate = $request->input('to_date');

                $query = AtImportedProductMaster::query()
                    ->leftJoin('at_imported_product_details', 'at_imported_product_master.id', '=', 'at_imported_product_details.id')
                    ->leftJoin('ref_product', 'at_imported_product_details.ref_product_id', '=', 'ref_product.id')
                    ->leftJoin('at_user', DB::raw('CAST(at_imported_product_master.created_by AS bigint)'), '=', 'at_user.id');

                // Apply filters to the query
                if ($state) {
                    $query->where('at_user.ref_state_id', $state);
                }

                if ($fromDate) {
                    $query->whereDate('at_imported_product_master.created_at', '>=', $fromDate);
                }

                if ($toDate) {
                    $query->whereDate('at_imported_product_master.updated_at', '<=', $toDate);
                }

                $finalData = $query->select([
                    'at_imported_product_master.*',
                    'at_imported_product_details.import_qty_in_mt',
                    'at_imported_product_details.ref_product_id',
                    'ref_product.ref_category_id',
                    'at_user.first_name',
                    'at_user.address',
                    'at_user.mobile_no',
                    'at_user.email',
                    'at_user.ref_state_id',
                ])->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()
                    ->addColumn('state', function ($row) {
                        return getStateNameById($row->ref_state_id ?? 'N/A');
                    })
                    ->addColumn('exported_qty', function ($row) {
                        return $row->import_qty_in_mt ?? 'N/A';
                    })
                    ->addColumn('total_value_in_lakh', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 100000) . ' lakh' : 'N/A';
                    })
                    ->addColumn('total_value_in_crore', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 10000000) . ' crore' : 'N/A';
                    })
                    ->addColumn('total_value_in_usd', function ($row) {
                        // Assuming a conversion rate, e.g., 1 INR = 0.013 USD
                        $conversionRate = 0.012;
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt * $conversionRate) . ' USD' : 'N/A';
                    })

                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }
    public function CountryWiseExportIncluding()
    {
        return view('admin.apeda_mis_report.export_report.CountryWiseExportIncluding');
    }


    public function CountryWiseExportIncludingSearch(Request $request)
    {
        try {
            if ($request->ajax()) {


                $state = $request->input('state');
                $fromDate = $request->input('from_date');
                $toDate = $request->input('to_date');
                $operator = $request->input('operator');

                $query = AtImportedProductMaster::query()
                    ->leftJoin('at_imported_product_details', 'at_imported_product_master.id', '=', 'at_imported_product_details.id')
                    ->leftJoin('ref_product', 'at_imported_product_details.ref_product_id', '=', 'ref_product.id')
                    ->leftJoin('at_user', DB::raw('CAST(at_imported_product_master.created_by AS bigint)'), '=', 'at_user.id');

                // Apply filters to the query
                if ($state) {
                    $query->where('at_user.ref_state_id', $state);
                }

                if ($fromDate) {
                    $query->whereDate('at_imported_product_master.created_at', '>=', $fromDate);
                }

                if ($toDate) {
                    $query->whereDate('at_imported_product_master.updated_at', '<=', $toDate);
                }
                if ($operator) {
                    $query->where('at_user.ref_operator_type_id', $operator);
                }

                $finalData = $query->select([
                    'at_imported_product_master.*',
                    'at_imported_product_details.import_qty_in_mt',
                    'at_imported_product_details.ref_product_id',
                    'ref_product.ref_category_id',
                    'at_user.first_name',
                    'at_user.address',
                    'at_user.mobile_no',
                    'at_user.email',
                    'at_user.ref_state_id',
                    'at_user.ref_operator_type_id',
                ])->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()
                    ->addColumn('state', function ($row) {
                        return $row->ref_state_id ?? 'N/A';
                    })
                    ->addColumn('operator_type', function ($row) {
                        return getOperatorTypeById($row->ref_operator_type_id ?? '');
                    })
                    ->addColumn('exporter', function ($row) {
                        return $row->exporter_name ?? '';
                    })
                    ->addColumn('address', function ($row) {
                        return $row->address ?? 'address not found';
                    })
                    ->addColumn('mobile_no', function ($row) {
                        return $row->mobile_no ?? 'N/A';
                    })
                    ->addColumn('email', function ($row) {
                        return $row->email ?? 'email not found';
                    })
                    ->addColumn('category', function ($row) {
                        return getCategoryNameById($row->ref_category_id ?? 'N/A');
                    })
                    ->addColumn('product_name', function ($row) {
                        return getProductNameById1($row->ref_product_id ?? 'N/A');
                    })
                    ->addColumn('hscode', function ($row) {
                        return $row->ref_product_id ?? 'N/A';
                    })
                    ->addColumn('country', function ($row) {
                        return getCountryName($row->ref_country_master_id ?? 'N/A');
                    })
                    ->addColumn('exported_qty', function ($row) {
                        return $row->import_qty_in_mt ?? 'N/A';
                    })
                    ->addColumn('total_value_in_lakh', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 100000) . ' lakh' : 'N/A';
                    })
                    ->addColumn('total_value_in_crore', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 10000000) . ' crore' : 'N/A';
                    })
                    ->addColumn('total_value_in_usd', function ($row) {
                        // Assuming a conversion rate, e.g., 1 INR = 0.013 USD
                        $conversionRate = 0.012;
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt * $conversionRate) . ' USD' : 'N/A';
                    })

                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    public function CountryWiseOnly()
    {
        return view('admin.apeda_mis_report.export_report.CountryWiseOnly');
    }

    public function CountryWiseOnlySearch(Request $request)
    {
        try {
            if ($request->ajax()) {


                $state = $request->input('state');
                $fromDate = $request->input('from_date');
                $toDate = $request->input('to_date');
                $operator = $request->input('operator');

                $query = AtImportedProductMaster::query()
                    ->leftJoin('at_imported_product_details', 'at_imported_product_master.id', '=', 'at_imported_product_details.id')
                    ->leftJoin('ref_product', 'at_imported_product_details.ref_product_id', '=', 'ref_product.id')
                    ->leftJoin('at_user', DB::raw('CAST(at_imported_product_master.created_by AS bigint)'), '=', 'at_user.id');

                // Apply filters to the query
                if ($state) {
                    $query->where('at_user.ref_state_id', $state);
                }

                if ($fromDate) {
                    $query->whereDate('at_imported_product_master.created_at', '>=', $fromDate);
                }

                if ($toDate) {
                    $query->whereDate('at_imported_product_master.updated_at', '<=', $toDate);
                }
                if ($operator) {
                    $query->where('at_user.ref_operator_type_id', $operator);
                }

                $finalData = $query->select([
                    'at_imported_product_master.*',
                    'at_imported_product_details.import_qty_in_mt',
                    'at_imported_product_details.ref_product_id',
                    'ref_product.ref_category_id',
                    'at_user.first_name',
                    'at_user.address',
                    'at_user.mobile_no',
                    'at_user.email',
                    'at_user.ref_state_id',
                    'at_user.ref_operator_type_id',
                ])->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()
                    ->addColumn('country', function ($row) {
                        return getCountryName($row->ref_country_master_id ?? 'N/A');
                    })
                    ->addColumn('exported_qty', function ($row) {
                        return $row->import_qty_in_mt ?? 'N/A';
                    })
                    ->addColumn('total_value_in_lakh', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 100000) . ' lakh' : 'N/A';
                    })
                    ->addColumn('total_value_in_crore', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 10000000) . ' crore' : 'N/A';
                    })
                    ->addColumn('total_value_in_usd', function ($row) {
                        // Assuming a conversion rate, e.g., 1 INR = 0.013 USD
                        $conversionRate = 0.012;
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt * $conversionRate) . ' USD' : 'N/A';
                    })

                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }
    public function ProductWise()
    {
        return view('admin.apeda_mis_report.export_report.ProductWise');
    }
    public function ProductWiseSearch(Request $request)
    {
        try {
            if ($request->ajax()) {


                $state = $request->input('state');
                $fromDate = $request->input('from_date');
                $toDate = $request->input('to_date');
                $operator = $request->input('operator');

                $query = AtImportedProductMaster::query()
                    ->leftJoin('at_imported_product_details', 'at_imported_product_master.id', '=', 'at_imported_product_details.id')
                    ->leftJoin('ref_product', 'at_imported_product_details.ref_product_id', '=', 'ref_product.id')
                    ->leftJoin('at_user', DB::raw('CAST(at_imported_product_master.created_by AS bigint)'), '=', 'at_user.id');

                // Apply filters to the query
                if ($state) {
                    $query->where('at_user.ref_state_id', $state);
                }

                if ($fromDate) {
                    $query->whereDate('at_imported_product_master.created_at', '>=', $fromDate);
                }

                if ($toDate) {
                    $query->whereDate('at_imported_product_master.updated_at', '<=', $toDate);
                }
                if ($operator) {
                    $query->where('at_user.ref_operator_type_id', $operator);
                }

                $finalData = $query->select([
                    'at_imported_product_master.*',
                    'at_imported_product_details.import_qty_in_mt',
                    'at_imported_product_details.ref_product_id',
                    'ref_product.ref_category_id',
                    'at_user.first_name',
                    'at_user.address',
                    'at_user.mobile_no',
                    'at_user.email',
                    'at_user.ref_state_id',
                    'at_user.ref_operator_type_id',
                ])->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('category', function ($row) {
                        return getCategoryNameById($row->ref_category_id ?? 'N/A');
                    })
                    ->addColumn('product_name', function ($row) {
                        return $row->ref_product_id ?? 'N/A';
                    })
                    ->addColumn('hscode', function ($row) {
                        return $row->ref_product_id ?? 'N/A';
                    })
                    ->addColumn('exported_qty', function ($row) {
                        return $row->import_qty_in_mt ?? 'N/A';
                    })
                    ->addColumn('total_value_in_lakh', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 100000) . ' lakh' : 'N/A';
                    })
                    ->addColumn('total_value_in_crore', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 10000000) . ' crore' : 'N/A';
                    })
                    ->addColumn('total_value_in_usd', function ($row) {
                        // Assuming a conversion rate, e.g., 1 INR = 0.013 USD
                        $conversionRate = 0.012;
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt * $conversionRate) . ' USD' : 'N/A';
                    })

                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }


    public function CategoryWise()
    {
        return view('admin.apeda_mis_report.export_report.CategoryWise');
    }


    public function CategoryWiseSearch(Request $request)
    {
        try {
            if ($request->ajax()) {


                $state = $request->input('state');
                $fromDate = $request->input('from_date');
                $toDate = $request->input('to_date');
                $operator = $request->input('operator');

                $query = AtImportedProductMaster::query()
                    ->leftJoin('at_imported_product_details', 'at_imported_product_master.id', '=', 'at_imported_product_details.id')
                    ->leftJoin('ref_product', 'at_imported_product_details.ref_product_id', '=', 'ref_product.id')
                    ->leftJoin('at_user', DB::raw('CAST(at_imported_product_master.created_by AS bigint)'), '=', 'at_user.id');

                // Apply filters to the query
                if ($state) {
                    $query->where('at_user.ref_state_id', $state);
                }

                if ($fromDate) {
                    $query->whereDate('at_imported_product_master.created_at', '>=', $fromDate);
                }

                if ($toDate) {
                    $query->whereDate('at_imported_product_master.updated_at', '<=', $toDate);
                }
                if ($operator) {
                    $query->where('at_user.ref_operator_type_id', $operator);
                }

                $finalData = $query->select([
                    'at_imported_product_master.*',
                    'at_imported_product_details.import_qty_in_mt',
                    'at_imported_product_details.ref_product_id',
                    'ref_product.ref_category_id',
                    'at_user.first_name',
                    'at_user.address',
                    'at_user.mobile_no',
                    'at_user.email',
                    'at_user.ref_state_id',
                    'at_user.ref_operator_type_id',
                ])->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('category', function ($row) {
                        return getCategoryNameById($row->ref_category_id ?? 'N/A');
                    })

                    ->addColumn('exported_qty', function ($row) {
                        return $row->import_qty_in_mt ?? 'N/A';
                    })
                    ->addColumn('total_value_in_lakh', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 100000) . ' lakh' : 'N/A';
                    })
                    ->addColumn('total_value_in_crore', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 10000000) . ' crore' : 'N/A';
                    })
                    ->addColumn('total_value_in_usd', function ($row) {
                        // Assuming a conversion rate, e.g., 1 INR = 0.013 USD
                        $conversionRate = 0.012;
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt * $conversionRate) . ' USD' : 'N/A';
                    })

                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }



    public function CBWise()
    {
        return view('admin.apeda_mis_report.export_report.CBWise');
    }

    public function CBWiseSearch(Request $request)
    {
        try {
            if ($request->ajax()) {


                $state = $request->input('state');
                $fromDate = $request->input('from_date');
                $toDate = $request->input('to_date');
                $operator = $request->input('operator');

                $query = AtImportedProductMaster::query()
                    ->leftJoin('at_imported_product_details', 'at_imported_product_master.id', '=', 'at_imported_product_details.id')
                    ->leftJoin('ref_product', 'at_imported_product_details.ref_product_id', '=', 'ref_product.id')
                    ->leftJoin('at_user', DB::raw('CAST(at_imported_product_master.created_by AS bigint)'), '=', 'at_user.id');



                // Apply filters to the query
                if ($state) {
                    $query->where('at_user.ref_state_id', $state);
                }

                if ($fromDate) {
                    $query->whereDate('at_imported_product_master.created_at', '>=', $fromDate);
                }

                if ($toDate) {
                    $query->whereDate('at_imported_product_master.updated_at', '<=', $toDate);
                }
                if ($operator) {
                    $query->where('at_user.ref_operator_type_id', $operator);
                }

                $finalData = $query->select([
                    'at_imported_product_master.*',
                    'at_imported_product_details.import_qty_in_mt',
                    'at_imported_product_details.ref_product_id',
                    'ref_product.ref_category_id',
                    'at_user.first_name',
                    'at_user.address',
                    'at_user.mobile_no',
                    'at_user.email',
                    'at_user.ref_state_id',

                ])->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('name', function ($row) {
                        return $row->first_name ?? '';
                    })

                    ->addColumn('exported_qty', function ($row) {
                        return $row->import_qty_in_mt ?? 'N/A';
                    })
                    ->addColumn('total_value_in_lakh', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 100000) . ' lakh' : 'N/A';
                    })
                    ->addColumn('total_value_in_crore', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 10000000) . ' crore' : 'N/A';
                    })
                    ->addColumn('total_value_in_usd', function ($row) {
                        // Assuming a conversion rate, e.g., 1 INR = 0.013 USD
                        $conversionRate = 0.012;
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt * $conversionRate) . ' USD' : 'N/A';
                    })

                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }



    public function MonthlyComparativeStatement()
    {

        $currentYear = (int)date('Y');

        $financialYear = '';
        $currentMonth = date('m');

        if ($currentMonth < 4) {
            $financialYear = ($currentYear - 2) . '-' . substr($currentYear, 2, 2);
        } else {
            $financialYear = $currentYear . '-' . substr(($currentYear + 1), 2, 2);
        }

        $financialYears = [
            ($currentYear - 1) . '-' . substr($currentYear, 2, 2),
            $currentYear . '-' . substr(($currentYear + 1), 2, 2),
            ($currentYear + 1) . '-' . substr(($currentYear + 2), 2, 2)
        ];



        return view('admin.apeda_mis_report.export_report.MonthlyComparativeStatement', compact('financialYears', 'financialYear'));
    }

    public function MonthlyComparativeStatementSearch(Request $request)
    {
        try {
            if ($request->ajax()) {


                $country = $request->input('country');
                $financial = $request->input('financial');


                $query = AtImportedProductMaster::query()
                    ->leftJoin('at_imported_product_details', 'at_imported_product_master.id', '=', 'at_imported_product_details.id')
                    ->leftJoin('ref_product', 'at_imported_product_details.ref_product_id', '=', 'ref_product.id')
                    ->leftJoin('at_user', DB::raw('CAST(at_imported_product_master.created_by AS bigint)'), '=', 'at_user.id');



                // Apply filters to the query
                if ($country) {
                    $query->where('at_imported_product_master.ref_country_master_id', $country);
                }

                if ($financial) {
                    $query->whereDate('at_imported_product_master.bill_of_entry_date', $financial);
                }

                $finalData = $query->select([
                    'at_imported_product_master.*',
                    'at_imported_product_details.import_qty_in_mt',
                    'at_imported_product_details.ref_product_id',
                    'ref_product.ref_category_id',
                    'at_imported_product_master.bill_of_entry_date',
                    'at_user.address',
                    'at_user.mobile_no',
                    'at_user.email',
                    'at_user.ref_state_id',

                ])->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('month', function ($row) {
                        return monthFormat($row->bill_of_entry_date ?? '');
                    })

                    ->addColumn('exported_qty', function ($row) {
                        return $row->import_qty_in_mt ?? 'N/A';
                    })
                    ->addColumn('total_value_in_lakh', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 100000) . ' lakh' : 'N/A';
                    })
                    ->addColumn('total_value_in_crore', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 10000000) . ' crore' : 'N/A';
                    })
                    ->addColumn('total_value_in_usd', function ($row) {
                        // Assuming a conversion rate, e.g., 1 INR = 0.013 USD
                        $conversionRate = 0.012;
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt * $conversionRate) . ' USD' : 'N/A';
                    })
                    ->addColumn('Growth_Quantity', function ($row) {

                        $growthPercentage = (($row->import_qty_in_mt)) / 100;
                        return $growthPercentage . '%';
                    })
                    ->addColumn('Growth_Value', function ($row) {

                        $growthPercentage = ($row->import_qty_in_mt) / 100;
                        return $growthPercentage . ' USD' . '%';
                    })


                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    public function CategoryWiseComparative()
    {
        return view('admin.apeda_mis_report.export_report.CategoryWiseComparative');
    }

    public function CategoryWiseComparativeSearch(Request $request)
    {
        try {
            if ($request->ajax()) {


                $country = $request->input('country');
                $financial = $request->input('financial');
                $based = $request->input('based');


                $query = AtImportedProductMaster::query()
                    ->leftJoin('at_imported_product_details', 'at_imported_product_master.id', '=', 'at_imported_product_details.id')
                    ->leftJoin('ref_product', 'at_imported_product_details.ref_product_id', '=', 'ref_product.id')
                    ->leftJoin('at_user', DB::raw('CAST(at_imported_product_master.created_by AS bigint)'), '=', 'at_user.id');



                // Apply filters to the query
                if ($country) {
                    $query->where('at_imported_product_master.ref_country_master_id', $country);
                }

                if ($financial) {
                    $query->whereDate('at_imported_product_master.bill_of_entry_date', $financial);
                }
                if ($based) {
                    $query->whereDate('at_imported_product_master.is_approved', $based);
                }

                $finalData = $query->select([
                    'at_imported_product_master.*',
                    'at_imported_product_details.import_qty_in_mt',
                    'at_imported_product_details.ref_product_id',
                    'ref_product.ref_category_id',
                    'at_user.address',
                    'at_user.mobile_no',
                    'at_user.email',
                    'at_user.ref_state_id',

                ])->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('category', function ($row) {
                        return getCategoryNameById($row->ref_category_id ?? '');
                    })

                    ->addColumn('exported_qty', function ($row) {
                        return $row->import_qty_in_mt ?? 'N/A';
                    })
                    ->addColumn('total_value_in_lakh', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 100000) . ' lakh' : 'N/A';
                    })
                    ->addColumn('total_value_in_crore', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 10000000) . ' crore' : 'N/A';
                    })
                    ->addColumn('total_value_in_usd', function ($row) {
                        // Assuming a conversion rate, e.g., 1 INR = 0.013 USD
                        $conversionRate = 0.013;
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt * $conversionRate) . ' USD' : 'N/A';
                    })
                    ->addColumn('Growth_Quantity', function ($row) {

                        $growthPercentage = (($row->import_qty_in_mt)) / 100;
                        return $growthPercentage . '%';
                    })
                    ->addColumn('Growth_Value', function ($row) {

                        $growthPercentage = ($row->import_qty_in_mt) / 100;
                        return $growthPercentage . ' USD' . '%';
                    })


                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    public function CountryWiseComparative()
    {
        return view('admin.apeda_mis_report.export_report.CountryWiseComparative');
    }


    public function CountryWiseComparativeSearch(Request $request)
    {
        try {
            if ($request->ajax()) {


                $country = $request->input('country');
                $financial = $request->input('financial');
                $based = $request->input('based');


                $query = AtImportedProductMaster::query()
                    ->leftJoin('at_imported_product_details', 'at_imported_product_master.id', '=', 'at_imported_product_details.id')
                    ->leftJoin('ref_product', 'at_imported_product_details.ref_product_id', '=', 'ref_product.id')
                    ->leftJoin('at_user', DB::raw('CAST(at_imported_product_master.created_by AS bigint)'), '=', 'at_user.id');



                // Apply filters to the query
                if ($country) {
                    $query->where('at_imported_product_master.ref_country_master_id', $country);
                }

                if ($financial) {
                    $query->whereDate('at_imported_product_master.bill_of_entry_date', $financial);
                }
                if ($based) {
                    $query->whereDate('at_imported_product_master.is_approved', $based);
                }

                $finalData = $query->select([
                    'at_imported_product_master.*',
                    'at_imported_product_details.import_qty_in_mt',
                    'at_imported_product_details.ref_product_id',
                    'ref_product.ref_category_id',
                    'at_user.address',
                    'at_user.mobile_no',
                    'at_user.email',
                    'at_user.ref_state_id',

                ])->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('Country', function ($row) {
                        return getCountryNameById($row->ref_country_master_id ?? '');
                    })

                    ->addColumn('exported_qty', function ($row) {
                        return $row->import_qty_in_mt ?? 'N/A';
                    })
                    ->addColumn('total_value_in_lakh', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 100000) . ' lakh' : 'N/A';
                    })
                    ->addColumn('total_value_in_crore', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 10000000) . ' crore' : 'N/A';
                    })
                    ->addColumn('total_value_in_usd', function ($row) {
                        // Assuming a conversion rate, e.g., 1 INR = 0.013 USD
                        $conversionRate = 0.013;
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt * $conversionRate) . ' USD' : 'N/A';
                    })
                    ->addColumn('Growth_Quantity', function ($row) {

                        $growthPercentage = (($row->import_qty_in_mt)) / 100;
                        return $growthPercentage . '%';
                    })
                    ->addColumn('Growth_Value', function ($row) {

                        $growthPercentage = ($row->import_qty_in_mt) / 100;
                        return $growthPercentage . ' USD' . '%';
                    })


                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }
    public function ProductWiseComparative()
    {
        return view('admin.apeda_mis_report.export_report.ProductWiseComparative');
    }

    public function ProductWiseComparativeSearch(Request $request)
    {
        try {
            if ($request->ajax()) {


                $country = $request->input('country');
                $financial = $request->input('financial');
                $product = $request->input('product');


                $query = AtImportedProductMaster::query()
                    ->leftJoin('at_imported_product_details', 'at_imported_product_master.id', '=', 'at_imported_product_details.id')
                    ->leftJoin('ref_product', 'at_imported_product_details.ref_product_id', '=', 'ref_product.id')
                    ->leftJoin('at_user', DB::raw('CAST(at_imported_product_master.created_by AS bigint)'), '=', 'at_user.id');



                // Apply filters to the query
                if ($country) {
                    $query->where('at_imported_product_master.ref_country_master_id', $country);
                }

                if ($financial) {
                    $query->where('at_imported_product_master.bill_of_entry_date', $financial);
                }
                if ($product) {
                    $query->where('at_imported_product_details.ref_product_id', $product);
                }

                $finalData = $query->select([
                    'at_imported_product_master.*',
                    'at_imported_product_details.import_qty_in_mt',
                    'at_imported_product_details.ref_product_id',
                    'ref_product.ref_category_id',
                    'at_user.address',
                    'at_user.mobile_no',
                    'at_user.email',
                    'at_user.ref_state_id',

                ])->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('product', function ($row) {
                        return getProductNameById1($row->ref_product_id ?? '');
                    })

                    ->addColumn('exported_qty', function ($row) {
                        return $row->import_qty_in_mt ?? 'N/A';
                    })
                    ->addColumn('total_value_in_lakh', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 100000) . ' lakh' : 'N/A';
                    })
                    ->addColumn('total_value_in_crore', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 10000000) . ' crore' : 'N/A';
                    })
                    ->addColumn('total_value_in_usd', function ($row) {
                        // Assuming a conversion rate, e.g., 1 INR = 0.013 USD
                        $conversionRate = 0.013;
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt * $conversionRate) . ' USD' : 'N/A';
                    })
                    ->addColumn('Growth_Quantity', function ($row) {

                        $growthPercentage = (($row->import_qty_in_mt)) / 100;
                        return $growthPercentage . '%';
                    })
                    ->addColumn('Growth_Value', function ($row) {

                        $growthPercentage = ($row->import_qty_in_mt) / 100;
                        return $growthPercentage . ' USD' . '%';
                    })


                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }


    public function CategoryWise5Years()
    {
        return view('admin.apeda_mis_report.export_report.CategoryWise5Years');
    }

    public function CategoryWise5YearsSearch(Request $request)
    {
        try {
            if ($request->ajax()) {



                $financial = $request->input('financial');



                $query = AtImportedProductMaster::query()
                    ->leftJoin('at_imported_product_details', 'at_imported_product_master.id', '=', 'at_imported_product_details.id')
                    ->leftJoin('ref_product', 'at_imported_product_details.ref_product_id', '=', 'ref_product.id')
                    ->leftJoin('at_user', DB::raw('CAST(at_imported_product_master.created_by AS bigint)'), '=', 'at_user.id');



                // Apply filters to the query
                if ($financial) {
                    $query->where('at_imported_product_master.status', $financial);
                }


                $finalData = $query->select([
                    'at_imported_product_master.*',
                    'at_imported_product_details.import_qty_in_mt',
                    'at_imported_product_details.ref_product_id',
                    'ref_product.ref_category_id',
                    'at_user.address',
                    'at_user.mobile_no',
                    'at_user.email',
                    'at_user.ref_state_id',

                ])->limit(4)->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('category', function ($row) {
                        return getCategoryNameById($row->ref_category_id ?? '');
                    })

                    ->addColumn('exported_qty', function ($row) {
                        return $row->import_qty_in_mt ?? 'N/A';
                    })
                    ->addColumn('total_value_in_lakh', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 100000) . ' lakh' : 'N/A';
                    })
                    ->addColumn('total_value_in_crore', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 10000000) . ' crore' : 'N/A';
                    })
                    ->addColumn('total_value_in_usd', function ($row) {
                        // Assuming a conversion rate, e.g., 1 INR = 0.013 USD
                        $conversionRate = 0.012;
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt * $conversionRate) . ' USD' : 'N/A';
                    })
                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    public function CountryWise5Years()
    {
        return view('admin.apeda_mis_report.export_report.CountryWise5Years');
    }

    public function CountryWise5YearsSearch(Request $request)
    {
        try {
            if ($request->ajax()) {



                $financial = $request->input('financial');



                $query = AtImportedProductMaster::query()
                    ->leftJoin('at_imported_product_details', 'at_imported_product_master.id', '=', 'at_imported_product_details.id')
                    ->leftJoin('ref_product', 'at_imported_product_details.ref_product_id', '=', 'ref_product.id')
                    ->leftJoin('at_user', DB::raw('CAST(at_imported_product_master.created_by AS bigint)'), '=', 'at_user.id');



                // Apply filters to the query
                if ($financial) {
                    $query->where('at_imported_product_master.status', $financial);
                }


                $finalData = $query->select([
                    'at_imported_product_master.*',
                    'at_imported_product_details.import_qty_in_mt',
                    'at_imported_product_details.ref_product_id',
                    'ref_product.ref_category_id',
                    'at_user.address',
                    'at_user.mobile_no',
                    'at_user.email',
                    'at_user.ref_state_id',

                ])->limit(4)->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('country', function ($row) {
                        return getCountryNameById($row->ref_country_master_id ?? '');
                    })

                    ->addColumn('exported_qty', function ($row) {
                        return $row->import_qty_in_mt ?? 'N/A';
                    })
                    ->addColumn('total_value_in_lakh', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 100000) . ' lakh' : 'N/A';
                    })
                    ->addColumn('total_value_in_crore', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 10000000) . ' crore' : 'N/A';
                    })
                    ->addColumn('total_value_in_usd', function ($row) {
                        // Assuming a conversion rate, e.g., 1 INR = 0.013 USD
                        $conversionRate = 0.012;
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt * $conversionRate) . ' USD' : 'N/A';
                    })
                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    public function ProductWise5Years()
    {
        return view('admin.apeda_mis_report.export_report.ProductWise5Years');
    }
    public function ProductWise5YearsSearch(Request $request)
    {
        try {
            if ($request->ajax()) {



                $financial = $request->input('financial');



                $query = AtImportedProductMaster::query()
                    ->leftJoin('at_imported_product_details', 'at_imported_product_master.id', '=', 'at_imported_product_details.id')
                    ->leftJoin('ref_product', 'at_imported_product_details.ref_product_id', '=', 'ref_product.id')
                    ->leftJoin('at_user', DB::raw('CAST(at_imported_product_master.created_by AS bigint)'), '=', 'at_user.id');



                // Apply filters to the query
                if ($financial) {
                    $query->where('at_imported_product_master.status', $financial);
                }


                $finalData = $query->select([
                    'at_imported_product_master.*',
                    'at_imported_product_details.import_qty_in_mt',
                    'at_imported_product_details.ref_product_id',
                    'ref_product.ref_category_id',
                    'at_user.address',
                    'at_user.mobile_no',
                    'at_user.email',
                    'at_user.ref_state_id',

                ])->limit(4)->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('product', function ($row) {
                        return getProductNameById1($row->ref_product_id ?? '');
                    })

                    ->addColumn('exported_qty', function ($row) {
                        return $row->import_qty_in_mt ?? 'N/A';
                    })
                    ->addColumn('total_value_in_lakh', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 100000) . ' lakh' : 'N/A';
                    })
                    ->addColumn('total_value_in_crore', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 10000000) . ' crore' : 'N/A';
                    })
                    ->addColumn('total_value_in_usd', function ($row) {
                        // Assuming a conversion rate, e.g., 1 INR = 0.013 USD
                        $conversionRate = 0.012;
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt * $conversionRate) . ' USD' : 'N/A';
                    })
                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    public function StateWise5Years()
    {
        return view('admin.apeda_mis_report.export_report.StateWise5Years');
    }

    public function StateWise5YearsSearch(Request $request)
    {
        try {
            if ($request->ajax()) {



                $financial = $request->input('financial');



                $query = AtImportedProductMaster::query()
                    ->leftJoin('at_imported_product_details', 'at_imported_product_master.id', '=', 'at_imported_product_details.id')
                    ->leftJoin('ref_product', 'at_imported_product_details.ref_product_id', '=', 'ref_product.id')
                    ->leftJoin('at_user', DB::raw('CAST(at_imported_product_master.created_by AS bigint)'), '=', 'at_user.id');



                // Apply filters to the query
                if ($financial) {
                    $query->where('at_imported_product_master.status', $financial);
                }


                $finalData = $query->select([
                    'at_imported_product_master.*',
                    'at_imported_product_details.import_qty_in_mt',
                    'at_imported_product_details.ref_product_id',
                    'ref_product.ref_category_id',
                    'at_user.address',
                    'at_user.mobile_no',
                    'at_user.email',
                    'at_user.ref_state_id',

                ])->limit(4)->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('state', function ($row) {
                        return getStateNameById($row->ref_state_id ?? '');
                    })

                    ->addColumn('exported_qty', function ($row) {
                        return $row->import_qty_in_mt ?? 'N/A';
                    })
                    ->addColumn('total_value_in_lakh', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 100000) . ' lakh' : 'N/A';
                    })
                    ->addColumn('total_value_in_crore', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 10000000) . ' crore' : 'N/A';
                    })
                    ->addColumn('total_value_in_usd', function ($row) {
                        // Assuming a conversion rate, e.g., 1 INR = 0.013 USD
                        $conversionRate = 0.012;
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt * $conversionRate) . ' USD' : 'N/A';
                    })
                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    public function CBWise5Years()
    {
        return view('admin.apeda_mis_report.export_report.CBWise5Years');
    }

    public function CBWise5YearsSearch(Request $request)
    {
        try {
            if ($request->ajax()) {



                $financial = $request->input('financial');



                $query = AtImportedProductMaster::query()
                    ->leftJoin('at_imported_product_details', 'at_imported_product_master.id', '=', 'at_imported_product_details.id')
                    ->leftJoin('ref_product', 'at_imported_product_details.ref_product_id', '=', 'ref_product.id')
                    ->leftJoin('at_user', DB::raw('CAST(at_imported_product_master.updated_by AS bigint)'), '=', 'at_user.id');



                // Apply filters to the query
                if ($financial) {
                    $query->where('at_imported_product_master.status', $financial);
                }


                $finalData = $query->select([
                    'at_imported_product_master.*',
                    'at_imported_product_details.import_qty_in_mt',
                    'at_imported_product_details.ref_product_id',
                    'ref_product.ref_category_id',
                    // 'at_user.ref_operator_type_id',
                    'at_user.first_name',


                ])->limit(4)->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('cb_name', function ($row) {

                        return ($row->first_name ?? 'Not Found');
                    })

                    ->addColumn('exported_qty', function ($row) {
                        return $row->import_qty_in_mt ?? 'N/A';
                    })
                    ->addColumn('total_value_in_lakh', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 100000) . ' lakh' : 'N/A';
                    })
                    ->addColumn('total_value_in_crore', function ($row) {
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt / 10000000) . ' crore' : 'N/A';
                    })
                    ->addColumn('total_value_in_usd', function ($row) {
                        // Assuming a conversion rate, e.g., 1 INR = 0.013 USD
                        $conversionRate = 0.012;
                        return $row->import_qty_in_mt ? ($row->import_qty_in_mt * $conversionRate) . ' USD' : 'N/A';
                    })
                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }



    public function OrganicArea()
    {
        return view('admin.apeda_mis_report.export_report.OrganicArea');
    }

    public function OrganicAreaSearch(Request $request)
    {
        try {
            if ($request->ajax()) {


                $country = $request->input('country');
                $state = $request->input('state');
                $dist = $request->input('dist');
                $category = $request->input('category');


                $query = AtFarmDetails::query();


                // Apply filters to the query
                if ($country) {
                    $query->where('at_imported_product_master.ref_country_master_id', $country);
                }

                if ($state) {
                    $query->where('at_farm_details.ref_state_id', $state);
                }
                if ($dist) {
                    $query->where('at_farm_details.ref_district_id', $dist);
                }
                if ($category) {
                    $query->where('ref_product.ref_category_id', $category);
                }

                $finalData = $query->limit(10)->get();

                //dd($finalData);
                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('state', function ($row) {
                        return getStateNameById($row->ref_state_id ?? 'N/A');
                    })
                    ->addColumn('organic_area', function ($row) {
                        return $row->area_in_ha  ??  'Either Not Found or Null';
                    })
                    ->addColumn('conversion_area', function ($row) {
                        return ($row->area_organic_cultivation ?? 'N/A');
                    })
                    ->addColumn('total_area', function ($row) {

                        return $row->total_area ?? 'N/A';
                    })
                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    public function WildOrganicArea()
    {
        return view('admin.apeda_mis_report.export_report.WildOrganicArea');
    }

    public function WildOrganicAreaSearch(Request $request)
    {
        try {
            if ($request->ajax()) {



                $state = $request->input('state');
                $dist = $request->input('dist');

                $query = AtFarmDetails::query();


                // Apply filters to the query

                if ($state) {
                    $query->where('at_farm_details.ref_state_id', $state);
                }
                if ($dist) {
                    $query->where('at_farm_details.ref_district_id', $dist);
                }

                $finalData = $query->limit(10)->get();

                //dd($finalData);
                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('state', function ($row) {
                        return getStateNameById($row->ref_state_id ?? 'N/A');
                    })
                    ->addColumn('organic_area', function ($row) {
                        return $row->area_in_ha  ??  'Either Not Found or Null';
                    })

                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    public function Production()
    {
        return view('admin.apeda_mis_report.export_report.Production');
    }

    public function ProductionSearch(Request $request)
    {
        try {
            if ($request->ajax()) {



                $state = $request->input('state');
                $dist = $request->input('dist');
                $category = $request->input('category');
                $product = $request->input('product');

                $query = AtFarmDetails::query()
                    ->leftJoin('at_imported_product_details', 'at_farm_details.id', '=', 'at_imported_product_details.id')
                    ->leftJoin('ref_product', 'at_imported_product_details.ref_product_id', '=', 'ref_product.id');



                // Apply filters to the query

                if ($state) {
                    $query->where('at_farm_details.ref_state_id', $state);
                }
                if ($dist) {
                    $query->where('at_farm_details.ref_district_id', $dist);
                }
                if ($category) {
                    $query->where('ref_product.ref_category_id', $category);
                }
                if ($product) {
                    $query->where('ref_product.id', $product);
                }

                $finalData = $query->select([

                    'at_imported_product_details.ref_product_id',
                    'at_farm_details.ref_state_id',
                    'at_farm_details.area_organic_cultivation',
                    'at_farm_details.total_area',
                    'at_farm_details.area_in_ha',
                    'ref_product.product_name'


                ])->limit(5)->get();


                //dd($finalData);
                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('state', function ($row) {
                        return getStateNameById($row->ref_state_id ?? 'N/A');
                    })
                    ->addColumn('product_name', function ($row) {
                        return ($row->product_name  ??  'Either Not Found or Null');
                    })
                    ->addColumn('organic_production', function ($row) {
                        return ($row->area_organic_cultivation ?? 'N/A');
                    })
                    ->addColumn('conversion_production', function ($row) {
                        return $row->area_in_ha  ??  'Either Not Found or Null';
                    })
                    ->addColumn('total_production', function ($row) {
                        return $row->total_area  ??  'Either Not Found or Null';
                    })

                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    public function WildOrganicProduction()
    {
        return view('admin.apeda_mis_report.export_report.WildOrganicProduction');
    }
    public function WildOrganicProductionSearch(Request $request)
    {
        try {
            if ($request->ajax()) {



                $state = $request->input('state');
                $dist = $request->input('dist');
                $category = $request->input('category');
                $product = $request->input('product');

                $query = AtFarmDetails::query()
                    ->leftJoin('at_imported_product_details', 'at_farm_details.id', '=', 'at_imported_product_details.id')
                    ->leftJoin('ref_product', 'at_imported_product_details.ref_product_id', '=', 'ref_product.id');



                // Apply filters to the query

                if ($state) {
                    $query->where('at_farm_details.ref_state_id', $state);
                }
                if ($dist) {
                    $query->where('at_farm_details.ref_district_id', $dist);
                }
                if ($category) {
                    $query->where('ref_product.ref_category_id', $category);
                }
                if ($product) {
                    $query->where('ref_product.id', $product);
                }

                $finalData = $query->select([

                    'at_imported_product_details.ref_product_id',
                    'at_farm_details.ref_state_id',
                    'at_farm_details.area_organic_cultivation',
                    'at_farm_details.total_area',
                    'at_farm_details.area_in_ha',
                    'ref_product.product_name'


                ])->limit(5)->get();


                //dd($finalData);
                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('state', function ($row) {
                        return getStateNameById($row->ref_state_id ?? 'N/A');
                    })
                    ->addColumn('product_name', function ($row) {
                        return ($row->product_name  ??  'Either Not Found or Null');
                    })
                    ->addColumn('organic_production', function ($row) {
                        return ($row->area_organic_cultivation ?? 'N/A');
                    })
                    ->addColumn('conversion_production', function ($row) {
                        return $row->area_in_ha  ??  'Either Not Found or Null';
                    })
                    ->addColumn('total_production', function ($row) {
                        return $row->total_area  ??  'Either Not Found or Null';
                    })

                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }



    public function OrganicTrade()
    {
        return view('admin.apeda_mis_report.export_report.OrganicTrade');
    }

    public function OrganicTradeSearch(Request $request)
    {
        try {
            if ($request->ajax()) {


                $country = $request->input('country');
                $financial = $request->input('financial');
                $product = $request->input('product');


                $query = AtOpTransactionVsTransactionProduct::query()
                    ->leftJoin('at_op_transaction_certificate_entry', 'at_op_transaction_vs_transaction_product.id', '=', 'at_op_transaction_certificate_entry.id')
                    ->leftJoin('at_user', DB::raw('CAST(at_op_transaction_vs_transaction_product.created_by AS bigint)'), '=', 'at_user.id')
                    ->leftJoin('at_imported_product_master', 'at_op_transaction_vs_transaction_product.id', '=', 'at_imported_product_master.id')
                    ->leftJoin('at_imported_product_details', 'at_imported_product_master.id', '=', 'at_imported_product_details.id')
                    ->leftJoin('ref_product', 'at_imported_product_details.id', '=', 'ref_product.id');




                // Apply filters to the query
                // if ($country) {
                //     $query->where('at_imported_product_master.ref_country_master_id', $country);
                // }

                // if ($financial) {
                //     $query->where('at_imported_product_master.bill_of_entry_date', $financial);
                // }
                // if ($product) {
                //     $query->where('at_imported_product_details.ref_product_id', $product);
                // }



                $finalData = $query->select([
                    'at_op_transaction_vs_transaction_product.*',
                    'at_op_transaction_certificate_entry.exporter_seller_name',
                    'at_op_transaction_certificate_entry.seller_at_op_certificate_standard_details_id',
                    'at_op_transaction_certificate_entry.buyer_name',
                    'at_op_transaction_certificate_entry.buyer_at_op_certificate_standard_details_id',
                    'at_imported_product_master.*',
                    'at_imported_product_details.import_qty_in_mt',
                    'at_imported_product_details.ref_product_id',
                    'at_imported_product_master.ref_country_master_id',
                    'ref_product.ref_category_id',
                    'at_user.first_name',




                ])->limit(10)->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('tc_Application', function ($row) {
                        return ($row->tc_application_no ?? '');
                    })

                    ->addColumn('tc_no', function ($row) {
                        return $row->transaction_certificate_no ?? 'N/A';
                    })
                    ->addColumn('date', function ($row) {
                        return $row->created_at ?? 'N/A';
                    })
                    ->addColumn('tc_date', function ($row) {
                        return $row->tc_date ??  'N/A';
                    })
                    ->addColumn('tc_type', function ($row) {


                        return 'TC Type';
                    })

                    ->addColumn('cb_name', function ($row) {

                        return $row->first_name ??  'N/A';
                    })
                    ->addColumn('organic_status', function ($row) {

                        return $row->organic_status ??  'N/A';
                    })
                    ->addColumn('seller_name', function ($row) {

                        return $row->exporter_seller_name ??  'N/A';
                    })
                    ->addColumn('seller_reg_no', function ($row) {

                        return $row->seller_at_op_certificate_standard_details_id ??  'N/A';
                    })
                    ->addColumn('buyer_name', function ($row) {

                        return $row->buyer_name ??  'N/A';
                    })
                    ->addColumn('buyer_reg_no', function ($row) {

                        return $row->buyer_at_op_certificate_standard_details_id ??  'N/A';
                    })
                    ->addColumn('country', function ($row) {

                        return $row->ref_country_master_id ??  'N/A';
                    })
                    ->addColumn('category', function ($row) {

                        return $row->ref_category_id ??  'N/A';
                    })
                    ->addColumn('product', function ($row) {

                        return $row->ref_product_id ??  'N/A';
                    })
                    ->addColumn('quantity', function ($row) {

                        return $row->import_qty_in_mt ??  'N/A';
                    })
                    ->addColumn('value', function ($row) {

                        return $row->tc_date ??  'N/A';
                    })
                    ->addColumn('action', function ($row) {

                        return $row->tc_date ??  'N/A';
                    })


                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }
    public function ListIssuedTC()
    {
        return view('admin.apeda_mis_report.export_report.ListIssuedTC');
    }

    public function ListIssuedTCSearch(Request $request)
    {
        try {
            if ($request->ajax()) {


                $from_date = $request->input('from_date');
                $financial = $request->input('financial');
                $to_date = $request->input('to_date');
                $tc_application_no = $request->input('tc_application_no');


                $query = AtOpTransactionVsTransactionProduct::query()
                    ->leftJoin('at_op_transaction_certificate_entry', 'at_op_transaction_vs_transaction_product.id', '=', 'at_op_transaction_certificate_entry.at_op_transaction_vs_transaction_product_id')
                    ->leftJoin('at_user', DB::raw('CAST(at_op_transaction_certificate_entry.updated_by AS bigint)'), '=', 'at_user.id');

                // Apply filters to the query
                if ($from_date) {
                    $query->where('at_op_transaction_vs_transaction_product.tc_date', $from_date);
                }

                if ($financial) {
                    $query->where('at_op_transaction_vs_transaction_product.created_by', $financial);
                }
                if ($to_date) {
                    $query->where('at_op_transaction_vs_transaction_product.created_at', $to_date);
                }
                if ($tc_application_no) {
                    $query->where('at_op_transaction_certificate_entry.tc_type', $tc_application_no);
                }

                $finalData = $query->select([
                    'at_op_transaction_vs_transaction_product.*',
                    'at_op_transaction_certificate_entry.exporter_seller_name',
                    'at_op_transaction_certificate_entry.buyer_name',
                    'at_op_transaction_certificate_entry.tc_type',
                    'at_user.ref_state_id',
                    'at_user.ref_operator_type_id',
                    'at_user.first_name',


                ])->limit(10)->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('tc_application', function ($row) {
                        return ($row->tc_application_no ?? 'either not found or null');
                    })

                    ->addColumn('tc_no', function ($row) {
                        return $row->transaction_certificate_no ?? 'Not Found';
                    })
                    ->addColumn('tc_issue_date', function ($row) {
                        return $row->created_at ?? 'Not Found';
                    })
                    ->addColumn('tc_date', function ($row) {
                        return $row->tc_date ?? 'Not Found';
                    })
                    ->addColumn('tc_type', function ($row) {
                        if ($row->tc_type == 'TC') {
                            return 'TC';
                        } elseif ($row->tc_type == 'PTC') {
                            return 'PTC';
                        } else {
                            return 'Not Found';
                        }
                    })

                    ->addColumn('cb_name', function ($row) {
                        return $row->ref_operator_type_id == 1 ? ($row->first_name ?? 'Not Found') : 'Either Not Found or Null';
                    })
                    ->addColumn('seller_name', function ($row) {

                        return $row->exporter_seller_name ?? 'Not Found';
                    })
                    ->addColumn('buyer_name', function ($row) {

                        return $row->buyer_name ?? 'Not Found';
                    })
                    ->addColumn('state', function ($row) {

                        return getStateNameById($row->ref_state_id ?? 'Not Found');
                    })
                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }




    public function ProductionAndExport()
    {
        return view('admin.apeda_mis_report.export_report.ProductionAndExport');
    }

    public function ProductionAndExportSearch(Request $request)
    {
        try {
            if ($request->ajax()) {


                $country = $request->input('country');
                $state = $request->input('state');
                $product = $request->input('product');
                $category = $request->input('category');


                $query = AtImportedProductMaster::query()
                    ->leftJoin('at_imported_product_details', 'at_imported_product_master.id', '=', 'at_imported_product_details.id')
                    ->leftJoin('ref_product', 'at_imported_product_details.ref_product_id', '=', 'ref_product.id')
                    ->leftJoin('at_user', DB::raw('CAST(at_imported_product_master.at_user_id AS bigint)'), '=', 'at_user.id');



                // Apply filters to the query
                if ($country) {
                    $query->where('at_imported_product_master.ref_country_master_id', $country);
                }

                if ($state) {
                    $query->where('at_user.ref_state_id', $state);
                }
                if ($product) {
                    $query->where('at_imported_product_details.ref_product_id', $product);
                }
                if ($category) {
                    $query->where('ref_product.ref_category_id', $category);
                }

                $finalData = $query->select([
                    'at_imported_product_master.*',
                    'at_imported_product_details.import_qty_in_mt',
                    'at_imported_product_details.ref_product_id',
                    'ref_product.ref_category_id',
                    'at_user.ref_operator_type_id',
                    'at_user.ref_state_id',
                    'at_user.first_name',
                    'ref_product.product_name',
                    'ref_product.hs_code'

                ])->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('country', function ($row) {
                        return getCountryNameById($row->ref_country_master_id ?? '');
                    })

                    ->addColumn('state', function ($row) {
                        return getStateNameById($row->ref_state_id ?? 'N/A');
                    })
                    ->addColumn('cb_name', function ($row) {
                        return $row->ref_operator_type_id == 1 ? ($row->first_name ?? 'Not Found') : 'Either Not Found or Null';
                    })
                    ->addColumn('category', function ($row) {
                        return getCategoryNameById($row->ref_category_id ?? 'N/A');
                    })
                    ->addColumn('product_name', function ($row) {

                        return $row->product_name ?? 'N/A';
                    })
                    ->addColumn('hs_code', function ($row) {

                        return $row->hs_code ?? 'N/A';
                    })

                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    public function ExternalInspction()
    {
        return view('admin.apeda_mis_report.export_report.ExternalInspction');
    }

    public function ExternalInspctionSearch(Request $request)
    {
        try {
            if ($request->ajax()) {



                $financial = $request->input('financial');
                $operator = $request->input('operator');
                $cbname = $request->input('cbname');
                $from_Date = $request->input('from_Date');
                $to_Date = $request->input('to_Date');



                $financial = $request->input('financial');
                $operator = $request->input('operator');
                $cbname = $request->input('cbname');
                $from_Date = $request->input('from_date');
                $to_Date = $request->input('to_date');
                $Type = $request->input('Type');


                $query = AtExternalInspection::query()
                    ->leftJoin('at_external_inspection_observation', 'at_external_inspection.id', '=', 'at_external_inspection_observation.at_external_inspection_id')
                    ->leftJoin('at_op_certificate_standard_details', 'at_external_inspection.at_user_id', '=', 'at_op_certificate_standard_details.at_user_id')
                    ->leftJoin('at_user', DB::raw('CAST(at_external_inspection.at_user_id AS bigint)'), '=', 'at_user.id');

                // Apply filters to the query
                if ($financial) {
                    $query->where('at_external_inspection.created_by', $financial);
                }
                if ($operator) {
                    $query->where('at_user.ref_operator_type_id', $operator);
                }
                if ($cbname) {
                    $query->where('at_user.updated_by', $cbname);
                }
                if ($from_Date) {
                    $query->whereDate('at_external_inspection.created_at', '>=', $from_Date);
                }
                if ($to_Date) {
                    $query->whereDate('at_external_inspection.updated_at', '<=', $to_Date);
                }
                if ($Type) {
                    $query->where('at_external_inspection.status', $Type);
                }

                $finalData = $query->select([
                    'at_external_inspection.inspector_name',
                    'at_external_inspection.inspection_date',
                    'at_external_inspection.closure_remark',
                    'at_external_inspection_observation.description_of_observation',
                    'at_external_inspection_observation.grade',
                    'at_external_inspection_observation.closure_date',
                    'at_user.first_name',
                    'at_user.address',
                    'at_user.ref_state_id',
                    'at_user.registration_no',
                    'at_user.ref_operator_type_id',
                    'at_op_certificate_standard_details.scope_certificate_no',
                    'at_op_certificate_standard_details.at_user_id',

                ])->limit(10)->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('cb_name', function ($row) {

                        return ($row->first_name ?? 'Not Found');
                    })
                    ->addColumn('state_name', function ($row) {
                        return getStateNameById($row->ref_state_id ?? 'N/A');
                    })
                    ->addColumn('operator_reg', function ($row) {
                        return $row->registration_no ?? 'N/A';
                    })
                    ->addColumn('scope_name', function ($row) {
                        return $row->scope_certificate_no ?? 'N/A';
                    })
                    ->addColumn('operator_name', function ($row) {
                        return $row->first_name ?? 'N/A';
                    })
                    ->addColumn('operator_type', function ($row) {
                        return getOperatorTypeById($row->ref_operator_type_id ?? 'N/A');
                    })
                    ->addColumn('address', function ($row) {
                        return $row->address ?? 'N/A';
                    })
                    ->addColumn('type', function ($row) {
                        return $row->import_qty_in_mt ?? 'N/A';
                    })
                    ->addColumn('inspector_name', function ($row) {
                        return $row->inspector_name ?? 'N/A';
                    })

                    ->addColumn('date_of_inspection', function ($row) {
                        return $row->inspection_date ?? 'N/A';
                    })
                    ->addColumn('description_of_nc', function ($row) {
                        return $row->description_of_observation ?? 'N/A';
                    })

                    ->addColumn('nc_grade', function ($row) {
                        return $row->grade ?? 'N/A';
                    })
                    ->addColumn('date_of_closure', function ($row) {
                        return $row->closure_date ?? 'N/A';
                    })

                    ->addColumn('remark', function ($row) {
                        return $row->closure_remark ?? 'N/A';
                    })

                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }



    public function RiskAssessment()
    {
        return view('admin.apeda_mis_report.export_report.RiskAssessment');
    }

    public function RiskAssessmentSearch(Request $request)
    {
        try {
            if ($request->ajax()) {

                $operator = $request->input('operator');
                $cbname = $request->input('cbname');

                $query = AtRiskAssessment::query()
                    ->leftJoin('at_op_certificate_standard_details', 'at_risk_assessment.at_user_id', '=', 'at_op_certificate_standard_details.at_user_id')
                    ->leftJoin('at_user', DB::raw('CAST(at_risk_assessment.at_user_id AS bigint)'), '=', 'at_user.id');

                // Apply filters to the query
                if ($operator) {
                    $query->where('at_user.ref_operator_type_id', $operator);
                }
                if ($cbname) {
                    $query->where('at_user.updated_by');
                }

                $finalData = $query->select([
                    'at_risk_assessment.size_of_holding',
                    'at_risk_assessment.no_of_member',
                    'at_risk_assessment.risk_type',
                    'at_risk_assessment.joining_member',
                    'at_risk_assessment.local_hazards',
                    'at_risk_assessment.change_production_plan',
                    'at_risk_assessment.similarity_between_prod_vs_crop',
                    'at_risk_assessment.parallel_production',
                    'at_risk_assessment.split_production',
                    'at_user.first_name',
                    'at_user.address',
                    'at_user.ref_state_id',
                    'at_user.ref_operator_type_id',
                    'at_user.registration_no',
                    'at_user.updated_by',
                    'at_op_certificate_standard_details.scope_certificate_no',
                    'at_op_certificate_standard_details.at_user_id',


                ])->limit(5)->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()
                    ->addColumn('state_name', function ($row) {
                        return getStateNameById($row->ref_state_id ?? 'N/A');
                    })
                    ->addColumn('operator_reg', function ($row) {
                        return $row->registration_no ?? 'Registration Not Generate';
                    })
                    ->addColumn('scope_no', function ($row) {
                        return $row->scope_certificate_no ?? 'Scope Not Generate ';
                    })
                    ->addColumn('operator_name', function ($row) {

                        return ($row->first_name ?? 'Not Found');
                    })
                    ->addColumn('address', function ($row) {
                        return $row->address ?? 'N/A';
                    })
                    ->addColumn('operator_type', function ($row) {
                        return getOperatorTypeById($row->ref_operator_type_id ?? 'N/A');
                    })
                    ->addColumn('plan', function ($row) {
                        return $row->change_production_plan ?? 'N/A';
                    })
                    ->addColumn('contamination', function ($row) {
                        return $row->change_production_plan ?? 'N/A';
                    })
                    ->addColumn('Degree_Of_Similarity', function ($row) {
                        return $row->similarity_between_prod_vs_crop ?? 'N/A';
                    })
                    ->addColumn('Joining_Of_New_Members', function ($row) {
                        return $row->joining_member ?? 'N/A';
                    })
                    ->addColumn('Local_Hazards', function ($row) {
                        return $row->local_hazards ?? 'N/A';
                    })
                    ->addColumn('Number_Of_Members', function ($row) {
                        return $row->no_of_member ?? 'N/A';
                    })
                    ->addColumn('Parallel_Production', function ($row) {
                        return $row->parallel_production ?? 'N/A';
                    })
                    ->addColumn('Risk_Type', function ($row) {
                        return $row->risk_type ?? 'N/A';
                    })
                    ->addColumn('Size_Of_Holding', function ($row) {
                        return $row->size_of_holding ?? 'N/A';
                    })
                    ->addColumn('Split_Production', function ($row) {
                        return $row->split_production ?? 'N/A';
                    })
                    ->addColumn('Risk_ID', function ($row) {
                        return $row->risk_type ?? 'N/A';
                    })

                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }


    public function ActivCbList(Request $request)
    {
        try {
            if ($request->ajax()) {
                $query = User::query();

                $query->where('ref_operator_type_id', 1);
                $query->where('status', 2);
                if ($request->filled('state')) {
                    $query->where('ref_state_id', $request->state);
                }

                if ($request->filled('from_date')) {
                    $query->whereDate('created_at', '>=', $request->from_date);
                }

                if ($request->filled('to_date')) {
                    $query->whereDate('created_at', '<=', $request->to_date);
                }

                $finalData = $query->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()
                    ->addColumn('ref_operator_type_id', function ($row) {
                        return $row->first_name ?? '';
                    })
                    ->addColumn('at_user_id', function ($row) {
                        $year = date('Y'); // Get the current year
                        $month = date('m'); // Get the current month
                        return 'ACCR/' . $year . '/' . $month . '/' . ($row->id ?? '');
                    })
                    ->addColumn('created_at', function ($row) {
                        return $row->created_at ? $row->created_at->format('Y-m-d') : '';
                    })
                    ->addColumn('updated_at', function ($row) {
                        return $row->updated_at ? $row->updated_at->format('Y-m-d') : '';
                    })
                    ->addColumn('scope_of_accreditation', function ($row) {
                        return $row->scope_of_accreditation ?? 'N/A';
                    })
                    ->addColumn('past_history', function ($row) {
                        return $row->past_history ?? 'N/A';
                    })
                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    public function ReportOnOperatorList(Request $request)
    {
        try {
            if ($request->ajax()) {
                $query = User::join('at_op_certificate_standard_details as c', 'at_user.id', '=', 'c.at_user_id');

                if ($request->filled('state')) {
                    $query->where('at_user.ref_state_id', $request->state);
                }

                if (!is_null($request->operatorType)) {
                    $query->where('at_user.ref_operator_type_id', $request->operatorType);
                }

                if (!is_null($request->status)) {
                    $query->where('at_user.status', $request->status);
                }

                if (!is_null($request->active_cbf)) {
                    $query->where('at_user.ref_operator_type_id', $request->active_cbf);
                }


                $finalData = $query->select('at_user.*', 'c.scope_certificate_no', 'c.file_name')->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()
                    ->addColumn('ref_operator_type_id', function ($row) {
                        return $row->ref_operator_type_id ?? '';
                    })
                    ->addColumn('first_name', function ($row) {
                        return $row->first_name ?? '';
                    })
                    ->addColumn('registration_no', function ($row) {
                        return $row->registration_no ?? '';
                    })
                    ->addColumn('address', function ($row) {
                        return $row->address ?? '';
                    })
                    ->addColumn('ref_state_id', function ($row) {
                        return getStateNameById($row->ref_state_id) ?? '';
                    })
                    ->addColumn('mobile_no', function ($row) {
                        return $row->mobile_no ?? '';
                    })
                    ->addColumn('email', function ($row) {
                        return $row->email ?? '';
                    })
                    ->addColumn('contact_person_first_name', function ($row) {
                        return $row->contact_person_first_name ?? '';
                    })
                    ->addColumn('date_of_registration', function ($row) {
                        return $row->created_at ? $row->created_at->format('d-m-Y') : '';
                    })
                    ->addColumn('status', function ($row) {
                        return $row->status ?? '';
                    })
                    ->addColumn('scope_certificate_no', function ($row) {
                        return $row->scope_certificate_no ?? '';
                    })

                    /*->addColumn('file_name', function ($row) {
                       return $row->file_name ?? '';
                   })*/
                    ->addColumn('file_name', function ($row) {
                        if ($row->file_name) {
                            return '<a target="_BLANK" href="' . asset('public' . $row->file_name) . '"> Scope Certificate</a>';
                        } else {
                            return 'N/A';
                        }
                    })
                    ->addColumn('registration_certificate', function ($row) {
                        if ($row->registration_certificate) {
                            return '<a target="_BLANK" href="' . asset('public' . $row->registration_certificate) . '"> See Doc</a>';
                        } else {
                            return 'N/A';
                        }
                    })

                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    public function ReportOnMandatorList(Request $request)
    {
        try {
            if ($request->ajax()) {
                $query = MandatorRegister::query();

                $query->orderBy('id', 'ASC');

                if ($request->filled('state')) {
                    $query->where('state_id', $request->state);
                }

                $finalData = $query->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()
                    ->addColumn('cb_name', function ($row) {
                        return $row->cb_name ?? '';
                    })
                    ->addColumn('mandator_name', function ($row) {
                        return $row->mandator_name ?? '';
                    })
                    ->addColumn('registration_no', function ($row) {
                        $rno = '#0101010';
                        return $rno . ($row->id ?? '');
                    })
                    ->addColumn('address', function ($row) {
                        return $row->address ?? 'N/A';
                    })
                    ->addColumn('operator_type', function ($row) {
                        return $row->operator_type ?? 'N/A';
                    })
                    ->addColumn('state_id', function ($row) {
                        return getStateNameById($row->state_id ?? 'N/A');
                    })
                    ->addColumn('mobile', function ($row) {
                        return $row->mobile ?? 'N/A';
                    })
                    ->addColumn('email', function ($row) {
                        return $row->email ?? 'N/A';
                    })
                    ->addColumn('grower_grp_name', function ($row) {
                        return $row->grower_grp_name ?? 'N/A';
                    })
                    ->addColumn('scope_no_of_operators', function ($row) {
                        return $row->scope_no_of_operators ?? 'N/A';
                    })
                    /*->addColumn('id_proof', function ($row) {
                    return $row->id_proof ?? 'N/A';
                })*/
                    ->addColumn('id_proof', function ($row) {
                        if ($row->id_proof) {
                            return '<a target="_BLANK" href="' . asset('public/mandator/id_proof/' . $row->id_proof) . '"> See Doc</a>';
                        } else {
                            return 'N/A';
                        }
                    })
                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }
    public function getDistrictsByStateId(Request $request)
    {
        $stateId = $request->state_id;
        $districts = RefDistrict::where('ref_state_id', $stateId)->pluck('district_name', 'id');
        return response()->json($districts);
    }

    public function FarmerCountList(Request $request)
    {
        try {
            if ($request->ajax()) {
                $query = AtFarmerRegDetail::query();
                $stateCounts = [];
                $cbWiseCount = 0;

                if ($request->operatorType) {
                    $cbQuery = AtFarmerRegDetail::join('at_user', 'at_farmer_reg_details.at_user_id', '=', 'at_user.id')
                        ->where('at_user.id', $request->operatorType);
                    $cbWiseCount = $cbQuery->count();
                }

                if (!$request->filled('state')) {
                    $stateCounts = AtFarmerRegDetail::groupBy('ref_state_id')
                        ->select('ref_state_id', DB::raw('count(*) as count'))
                        ->pluck('count', 'ref_state_id')
                        ->toArray();
                }

                if ($request->filled('state')) {
                    $query->where('at_farmer_reg_details.ref_state_id', $request->state);
                    $stateCounts[$request->state] = $query->count();
                }

                if ($request->filled('district')) {
                    $query->where('at_farmer_reg_details.ref_district_id', $request->district);
                }

                $finalData = $query->get();
                $result = ['data' => [], 'stateCounts' => $stateCounts];
                $stateIds = $finalData->groupBy('ref_state_id');
                $index = 1;

                foreach ($stateIds as $stateId => $stateData) {
                    $stateName = RefState::where('id', $stateId)->pluck('state_name')->first();
                    $stateFarmerCount = $stateData->count();

                    if ($request->filled('district')) {
                        $districtIds = $stateData->groupBy('ref_district_id');
                        foreach ($districtIds as $districtId => $districtData) {
                            $districtName = RefDistrict::where('id', $districtId)->pluck('district_name')->first();
                            $districtFarmerCount = $districtData->count();

                            $result['data'][] = [
                                'DT_RowIndex' => $index++,
                                'state' => $stateName,
                                'state_count' => $stateCounts[$stateId] ?? '',
                                'district' => $districtName,
                                'district_count' => $districtFarmerCount,
                                'cb_wise' => $cbWiseCount
                            ];
                        }
                    } else {
                        $result['data'][] = [
                            'DT_RowIndex' => $index++,
                            'state' => $stateName,
                            'state_count' => $stateCounts[$stateId] ?? '',
                            'district' => '',
                            'district_count' => '',
                            'cb_wise' => $cbWiseCount
                        ];
                    }
                }

                return response()->json($result);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()], 500);
        }
    }

    public function WildCollectorsCountList(Request $request)
    {
        try {
            if ($request->ajax()) {
                $query = AtFarmerRegDetail::query();
                $stateCounts = [];
                $cbWiseCount = 0;

                if ($request->operatorType) {
                    $cbQuery = AtFarmerRegDetail::join('at_user', 'at_farmer_reg_details.at_user_id', '=', 'at_user.id')
                        ->where('at_user.id', $request->operatorType);
                    $cbWiseCount = $cbQuery->count();
                }

                if (!$request->filled('state')) {
                    $stateCounts = AtFarmerRegDetail::groupBy('ref_state_id')
                        ->select('ref_state_id', DB::raw('count(*) as count'))
                        ->pluck('count', 'ref_state_id')
                        ->toArray();
                }

                if ($request->filled('state')) {
                    $query->where('at_farmer_reg_details.ref_state_id', $request->state);
                    $stateCounts[$request->state] = $query->count();
                }

                if ($request->filled('district')) {
                    $query->where('at_farmer_reg_details.ref_district_id', $request->district);
                }

                $finalData = $query->get();
                $result = ['data' => [], 'stateCounts' => $stateCounts];
                $stateIds = $finalData->groupBy('ref_state_id');
                $index = 1;

                foreach ($stateIds as $stateId => $stateData) {
                    $stateName = RefState::where('id', $stateId)->pluck('state_name')->first();
                    $stateFarmerCount = $stateData->count();

                    if ($request->filled('district')) {
                        $districtIds = $stateData->groupBy('ref_district_id');
                        foreach ($districtIds as $districtId => $districtData) {
                            $districtName = RefDistrict::where('id', $districtId)->pluck('district_name')->first();
                            $districtFarmerCount = $districtData->count();

                            $result['data'][] = [
                                'DT_RowIndex' => $index++,
                                'state' => $stateName,
                                'state_count' => $stateCounts[$stateId] ?? '',
                                'district' => $districtName,
                                'district_count' => $districtFarmerCount,
                                'cb_wise' => $cbWiseCount
                            ];
                        }
                    } else {
                        $result['data'][] = [
                            'DT_RowIndex' => $index++,
                            'state' => $stateName,
                            'state_count' => $stateCounts[$stateId] ?? '',
                            'district' => '',
                            'district_count' => '',
                            'cb_wise' => $cbWiseCount
                        ];
                    }
                }

                return response()->json($result);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()], 500);
        }
    }


    public function ReportOnScopeCertificate(Request $request)
    {
        try {
            if ($request->ajax()) {
                $query = User::join('at_op_certificate_standard_details as c', 'at_user.id', '=', 'c.at_user_id');

                if ($request->filled('state')) {
                    $query->where('at_user.ref_state_id', $request->state);
                }

                if ($request->filled('operatorType')) {
                    $query->where('at_user.ref_operator_type_id', $request->operatorType);
                }

                if ($request->filled('from_date')) {
                    $query->whereDate('c.validity_start_date', '>=', \Carbon\Carbon::parse($request->from_date));
                }

                if ($request->filled('to_date')) {
                    $query->whereDate('c.validity_end_date', '<=', \Carbon\Carbon::parse($request->to_date));
                }

                if ($request->filled('active_cbf')) {
                    $query->where('c.at_user_id', $request->active_cbf)
                        ->where('at_user.ref_operator_type_id', 1);
                }

                $finalData = $query->select('at_user.*', 'c.scope_certificate_no', 'c.file_name', 'c.validity_start_date', 'c.validity_end_date', 'c.created_at as created_at')->get();
                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()
                    ->addColumn('scope_certificate_no', function ($row) {
                        return $row->scope_certificate_no ?? '';
                    })
                    ->addColumn('first_name', function ($row) {
                        return $row->first_name ?? '';
                    })
                    ->addColumn('registration_no', function ($row) {
                        return $row->registration_no ?? '';
                    })
                    ->addColumn('address', function ($row) {
                        return $row->address ?? '';
                    })
                    ->addColumn('ref_operator_type_id', function ($row) {
                        return getStateNameById($row->ref_operator_type_id) ?? '';
                    })
                    ->addColumn('file_name', function ($row) {
                        return $row->file_name ?? '';
                    })
                    ->addColumn('validity_start_date', function ($row) {
                        return $row->validity_start_date ? \Carbon\Carbon::parse($row->validity_start_date)->format('d-m-Y') : '';
                    })
                    ->addColumn('email', function ($row) {
                        return $row->email ?? '';
                    })
                    ->addColumn('validity_end_date', function ($row) {
                        return $row->validity_end_date ? \Carbon\Carbon::parse($row->validity_end_date)->format('d-m-Y') : '';
                    })
                    ->addColumn('date_of_registration', function ($row) {
                        return $row->created_at ? \Carbon\Carbon::parse($row->created_at)->format('d-m-Y') : '';
                    })
                    ->addColumn('created_at', function ($row) {
                        return $row->created_at ? \Carbon\Carbon::parse($row->created_at)->format('d-m-Y') : '';
                    })
                    ->addColumn('file_name', function ($row) {
                        if ($row->file_name) {
                            return '<a target="_BLANK" href="' . asset('public' . $row->file_name) . '"> Scope Certificate</a>';
                        } else {
                            return 'N/A';
                        }
                    })

                    ->addColumn('registration_certificate', function ($row) {
                        if ($row->registration_certificate) {
                            return '<a target="_BLANK" href="' . asset('public' . $row->registration_certificate) . '"> See Doc</a>';
                        } else {
                            return 'N/A';
                        }
                    })
                    ->rawColumns(['file_name', 'registration_certificate']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    public function Ammendment(Request $request)
    {
        try {
            if ($request->ajax()) {
                $query = AtOpCertificateStandardDetail::join('at_user', 'at_op_certificate_standard_details.at_user_id', '=', 'at_user.id');

                if ($request->filled('state')) {
                    $query->where('at_user.ref_state_id', $request->state);
                }

                if ($request->filled('operatorType')) {
                    $query->where('at_user.ref_operator_type_id', $request->operatorType);
                }

                if ($request->filled('from_date')) {
                    $query->whereDate('validity_start_date', '>=', $request->from_date);
                }

                if ($request->filled('to_date')) {
                    $query->whereDate('validity_end_date', '<=', $request->to_date);
                }

                if ($request->filled('active_cbf')) {
                    $query->where('at_user.id', $request->active_cbf);
                }

                $finalData = $query->select('at_op_certificate_standard_details.*', 'at_user.registration_no as reg_name', 'at_user.status as ustatus', 'at_user.ref_operator_type_id')->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()
                    ->addColumn('scope_certificate_no', function ($row) {
                        return $row->scope_certificate_no ?? '';
                    })
                    ->addColumn('registration_no', function ($row) {
                        return $row->reg_name ?? '';
                    })
                    ->addColumn('ref_operator_type', function ($row) {
                        switch ($row->ref_operator_type_id) {
                            case 2:
                                return 'Grower Group';
                            case 3:
                                return 'INDIVIDUAL PRODUCER';
                            case 4:
                                return 'WILD';
                            case 5:
                                return 'TRADER';
                            case 6:
                                return 'PROCESSOR';
                            default:
                                return '';
                        }
                    })
                    ->addColumn('created_at', function ($row) {
                        return $row->created_at ? $row->created_at->format('d-m-Y') : '';
                    })
                    ->addColumn('created_at', function ($row) {
                        return $row->created_at ? $row->created_at->format('d-m-Y') : '';
                    })
                    ->addColumn('validity_start_date', function ($row) {
                        return $row->validity_start_date ? \Carbon\Carbon::parse($row->validity_start_date)->format('d-m-Y') : '';
                    })
                    ->addColumn('validity_end_date', function ($row) {
                        return $row->validity_end_date ? \Carbon\Carbon::parse($row->validity_end_date)->format('d-m-Y') : '';
                    })
                    ->addColumn('status', function ($row) {
                        switch ($row->ustatus) {
                            case 2:
                                return 'Active';
                            case 0:
                                return 'Expired';
                            case 3:
                                return 'Reject';
                            default:
                                return '';
                        }
                    })
                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    public function IdProof(Request $request)
    {
        try {
            if ($request->ajax()) {
                $query = AtOpCertificateStandardDetail::join('at_user', 'at_op_certificate_standard_details.at_user_id', '=', 'at_user.id')
                    ->join('at_ics_mandator_registration_details', 'at_op_certificate_standard_details.at_user_id', '=', 'at_ics_mandator_registration_details.at_user_id');

                if ($request->filled('operatorType')) {
                    $query->where('at_user.ref_operator_type_id', $request->operatorType);
                }

                if ($request->filled('active_cbf')) {
                    $query->where('at_user.id', $request->active_cbf);
                }

                $finalData = $query->select('at_op_certificate_standard_details.*', 'at_user.registration_no as reg_name', 'at_user.status as status', 'at_user.status as ustatus', 'at_user.ref_operator_type_id as ref_operator_type', 'at_user.ref_operator_type_id as ref_operator_name', 'at_ics_mandator_registration_details.profile_photo as p_photo', 'at_user.first_name as f_name', 'at_user.date_of_registration as date_registration', 'at_ics_mandator_registration_details.address1 as address', 'at_ics_mandator_registration_details.mobile_no as mobile', 'at_ics_mandator_registration_details.mand_type as mand_type', 'at_ics_mandator_registration_details.profile_photo as photo')->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()
                    ->addColumn('first_name', function ($row) {
                        return $row->f_name ?? '';
                    })
                    ->addColumn('registration_no', function ($row) {
                        return $row->reg_name ?? '';
                    })
                    /* ->addColumn('ref_operator_type', function ($row) {
                    return $row->ref_operator_type ?? '';
                   })*/
                    ->addColumn('ref_operator_type', function ($row) {
                        switch ($row->ref_operator_type) {
                            case 2:
                                return 'Grower Group';
                            case 3:
                                return 'INDIVIDUAL PRODUCER';
                            case 4:
                                return 'WILD';
                            case 5:
                                return 'TRADER';
                            case 6:
                                return 'PROCESSOR';
                            default:
                                return '';
                        }
                    })
                    ->addColumn('scope_certificate_no', function ($row) {
                        return $row->scope_certificate_no ?? '';
                    })
                    ->addColumn('ref_operator_type_id', function ($row) {
                        return $row->ref_operator_name ?? '';
                    })
                    /* ->addColumn('date_of_registration', function ($row) {
                    return $row->date_registration ?? '';
                   })*/
                    ->addColumn('date_of_registration', function ($row) {
                        return $row->date_registration ? \Carbon\Carbon::parse($row->date_registration)->format('d-m-Y') : '';
                    })
                    ->addColumn('address1', function ($row) {
                        return $row->address ?? '';
                    })
                    ->addColumn('mobile', function ($row) {
                        return $row->mobile ?? '';
                    })
                    ->addColumn('mand_type', function ($row) {
                        return $row->mand_type ?? '';
                    })
                    /* ->addColumn('profile_photo', function ($row) {
                    return $row->photo ?? '';
                   })*/
                    ->addColumn('profile_photo', function ($row) {
                        if ($row->photo) {
                            return '<a target="_BLANK" href="' . asset('public' . $row->photo) . '"> Supporting Doc</a>';
                        } else {
                            return 'N/A';
                        }
                    })
                    ->rawColumns(['profile_photo'])
                    ->addColumn('status', function ($row) {
                        switch ($row->status) {
                            case 0:
                                return 'Pending';
                            case 1:
                                return 'Form Filled';
                            case 2:
                                return 'Approved';
                            case 3:
                                return 'Reject';
                            default:
                                return '';
                        }
                    })
                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    public function OperatorNoc(Request $request)
    {
        try {
            if ($request->ajax()) {
                $query = DB::table('at_op_certificate_standard_details')
                    ->join('at_user', 'at_op_certificate_standard_details.at_user_id', '=', 'at_user.id')
                    ->join('at_op_noc_details', 'at_op_certificate_standard_details.at_user_id', '=', 'at_op_noc_details.created_by');

                if ($request->filled('operatorType')) {
                    $query->where('at_user.ref_operator_type_id', $request->operatorType);
                }

                if ($request->filled('registration_no')) {
                    $query->where('at_user.registration_no', $request->registration_no);
                }

                if ($request->filled('from_date')) {
                    $query->whereDate('at_op_certificate_standard_details.validity_start_date', '>=', $request->from_date);
                }

                if ($request->filled('to_date')) {
                    $query->whereDate('at_op_certificate_standard_details.validity_end_date', '<=', $request->to_date);
                }

                if ($request->filled('active_cbf')) {
                    $query->where('at_user.id', $request->active_cbf);
                }

                $finalData = $query->select(
                    'at_op_certificate_standard_details.*',
                    'at_op_noc_details.noc_application_no',
                    'at_op_noc_details.pdf_file_name_noc as file_name_noc',
                    'at_user.ref_operator_type_id',
                    'at_user.registration_no',
                    'at_op_certificate_standard_details.scope_certificate_no',
                    'at_op_noc_details.applied_on',
                    'at_op_noc_details.approved_on',
                    'at_op_noc_details.noc_status',
                    'at_op_noc_details.created_at as C_date'
                )->get();

                // Debugging: Check the structure of the final data
                //  Log::debug('Final Data: ' . json_encode($finalData));

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()
                    ->addColumn('noc_application_no', function ($row) {
                        return $row->noc_application_no ?? '';
                    })
                    /*->addColumn('pdf_file_name_noc', function ($row) {
                       return $row->file_name_noc ?? '';
                   })*/
                    /* ->addColumn('ref_operator_type_id', function ($row) {
                       return $row->ref_operator_type_id ?? '';
                   })*/
                    ->addColumn('ref_operator_type_id', function ($row) {
                        switch ($row->ref_operator_type_id) {
                            case 2:
                                return 'Grower Group';
                            case 3:
                                return 'INDIVIDUAL PRODUCER';
                            case 4:
                                return 'WILD';
                            case 5:
                                return 'TRADER';
                            case 6:
                                return 'PROCESSOR';
                            default:
                                return '';
                        }
                    })
                    ->addColumn('registration_no', function ($row) {
                        return $row->registration_no ?? '';
                    })
                    ->addColumn('ref_operator_type_id', function ($row) {
                        return $row->ref_operator_type_id ?? '';
                    })
                    ->addColumn('registration_no', function ($row) {
                        return $row->registration_no ?? '';
                    })
                    ->addColumn('scope_certificate_no', function ($row) {
                        return $row->scope_certificate_no ?? '';
                    })
                    ->addColumn('applied_on', function ($row) {
                        return $row->applied_on ? \Carbon\Carbon::parse($row->applied_on)->format('d-m-Y') : '';
                    })
                    ->addColumn('approved_on', function ($row) {
                        return $row->approved_on ? \Carbon\Carbon::parse($row->approved_on)->format('d-m-Y') : '';
                    })
                    ->addColumn('noc_status', function ($row) {
                        return $row->noc_status ?? 'N/A';
                    })
                    ->addColumn('created_at', function ($row) {
                        return $row->C_date ? \Carbon\Carbon::parse($row->C_date)->format('d-m-Y') : '';
                    })
                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    public function Terminated(Request $request)
    {
        try {
            if ($request->ajax()) {
                $query = AtOpCertificateStandardDetail::join('at_user', 'at_op_certificate_standard_details.at_user_id', '=', 'at_user.id');

                if ($request->filled('operatorAction')) {
                    $query->where('at_user.operator_status', $request->operatorAction);
                }

                if ($request->filled('operatorType')) {
                    $query->where('at_user.ref_operator_type_id', $request->operatorType);
                }

                if ($request->filled('active_cbf')) {
                    $query->where('at_user.created_by', $request->active_cbf);
                }

                $finalData = $query->select('at_op_certificate_standard_details.*', 'at_user.registration_no as reg_name', 'at_user.status as ustatus', 'at_user.ref_operator_type_id', 'at_user.operator_status')->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()
                    ->addColumn('scope_certificate_no', function ($row) {
                        return $row->scope_certificate_no ?? '';
                    })
                    ->addColumn('registration_no', function ($row) {
                        return $row->reg_name ?? '';
                    })

                    ->addColumn('scope_certificate_no', function ($row) {
                        return $row->scope_certificate_no ?? '';
                    })
                    ->addColumn('operator_type', function ($row) {
                        switch ($row->ref_operator_type_id) {
                            case 2:
                                return 'Grower Group';
                            case 3:
                                return 'Individual Producer';
                            case 4:
                                return 'Wild';
                            case 5:
                                return 'Trader';
                            case 6:
                                return 'Processor';
                            default:
                                return '';
                        }
                    })
                    ->addColumn('ref_operator_type_id', function ($row) {
                        return $row->ref_operator_type_id ?? '';
                    })

                    ->addColumn('validity_start_date', function ($row) {
                        return $row->validity_start_date ? \Carbon\Carbon::parse($row->validity_start_date)->format('d-m-Y') : '';
                    })
                    ->addColumn('validity_end_date', function ($row) {
                        return $row->validity_end_date ? \Carbon\Carbon::parse($row->validity_end_date)->format('d-m-Y') : '';
                    })
                    ->addColumn('operator_status', function ($row) {
                        switch ($row->operator_status) {
                            case 0:
                                return 'All';
                            case 1:
                                return 'Suspend';
                            case 2:
                                return 'Terminate';
                            case 3:
                                return 'Withdrawal By CB';
                            case 4:
                                return 'Withdrawal By Operator';
                            case 5:
                                return 'De-registration';
                            default:
                                return '';
                        }
                    })
                    ->addColumn('from_date', function ($row) {
                        return $row->from_date ? \Carbon\Carbon::parse($row->from_date)->format('d-m-Y') : '';
                    })
                    ->addColumn('to_date', function ($row) {
                        return $row->to_date ? \Carbon\Carbon::parse($row->to_date)->format('d-m-Y') : '';
                    })
                    ->addColumn('cb_reg_remarks', function ($row) {
                        return $row->cb_reg_remarks ?? 'N/A';
                    })
                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    public function selfConsumption(Request $request)
    {
        try {
            if ($request->ajax()) {
                $query = AtBatchDetail::join('ref_procurement_entry', DB::raw('CAST(at_batch_details.at_user_id AS INTEGER)'), '=', DB::raw('CAST(ref_procurement_entry.created_by AS INTEGER)'))
                    ->join('at_tc_self_consumed', DB::raw('CAST(ref_procurement_entry.created_by AS INTEGER)'), '=', DB::raw('CAST(at_tc_self_consumed.created_by AS INTEGER)'))
                    ->join('at_user', DB::raw('CAST(at_batch_details.at_user_id AS INTEGER)'), '=', DB::raw('CAST(at_user.id AS INTEGER)'));
                if ($request->filled('operatorType')) {
                    $query->where('at_user.ref_operator_type_id', $request->operatorType);
                }
                if ($request->filled('active_cbf')) {
                    $query->where('at_user.created_by', $request->active_cbf);
                }

                $finalData = $query->select('at_batch_details.*', 'at_user.*', 'ref_procurement_entry.lot_number', 'ref_procurement_entry.quantity_source', 'at_tc_self_consumed.self_qty_consumed')
                    ->whereNull('ref_procurement_entry.is_deleted')
                    ->whereNull('at_batch_details.deleted_at')
                    ->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()
                    ->addColumn('lot_number', function ($row) {
                        return $row->lot_number ?? '';
                    })
                    ->addColumn('product_name', function ($row) {
                        return $row->product_name ?? '';
                    })
                    ->addColumn('source_from', function ($row) {
                        return $row->source_from ?? '';
                    })
                    ->addColumn('total_quantity', function ($row) {
                        return $row->total_quantity ?? '';
                    })
                    ->addColumn('quantity_source', function ($row) {
                        return $row->quantity_source ?? '';
                    })
                    ->addColumn('self_qty_consumed', function ($row) {
                        return $row->self_qty_consumed ?? '';
                    })
                    ->addColumn('used_quantity', function ($row) {
                        return $row->used_quantity ?? '';
                    })
                    ->addColumn('available_quantity', function ($row) {
                        return $row->available_quantity ?? '';
                    })
                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }
}

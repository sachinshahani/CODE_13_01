<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Permission;
use App\Models\Role;
use App\Models\RoleUser;
use App\Models\User;
use App\Models\UserSelf;
use App\Models\UserInspector;
use App\Models\UserWarehouse;
use App\Models\UserWarehouseManagerOfficers;
use App\Models\RefState;
use App\Models\RefDistrict;
use App\Models\RefVillage;
use App\Models\RefRegion;
use App\Models\WildHarvesterBankDetail;
use App\Models\WildHarvesterDetail;
use App\Models\RefBank;
use App\Models\WildHarvesterDocument;
use App\Models\WildHarvesterForestDetail;
use App\Models\WildHarvesterForestProductDetail;
use App\Models\WildHarvesterPermittedForestAreaDetail;
use App\Models\AtProProductsDetails;
use App\Models\CertificateStandardDetail;
use App\Models\BatchCreation;
use App\Models\AtOpTransactionVsTransactionProduct;
use App\Models\AtBatchDetail;
use App\Models\SourceDetails;
use App\Models\RefProduct;
use Yajra\DataTables\DataTables;
use Carbon\Carbon;

use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;

class WildHarvestController extends Controller
{
    public function wildHarvestUserAdd($id){

        $userdetails = User::find(Auth::guard('misadmin')->user()->id);
        $states = RefState::orderBy('state_name','ASC')->get();
        $harvester = User::with('getWildHarvesterDetail')->where('id',$id)->first();
        $districts = RefDistrict::where('ref_state_id',$harvester->ref_state_id)->orderBy('district_name','ASC')->get();
        $regions = RefRegion::where('ref_district_id',$harvester->ref_district_id)->orderBy('block_tehsil_name','ASC')->get();
        $villages = RefVillage::where('ref_district_id',$harvester->ref_district_id)->orderBy('village_name','ASC')->get();

        return view('admin.usermanagement.deptUser.wildHarvestDetail',compact('id','states','districts','regions','villages','userdetails','harvester'));
    }

    public function wildHarvestUserAddStep2($id){
        $userdetails = User::find(Auth::guard('misadmin')->user()->id);
        $states = RefState::orderBy('state_name','ASC')->get();
        $bankName = RefBank::all();
        $harvester = User::where('id',$id)->first();
        $bankDetail = WildHarvesterBankDetail::where('at_user_id',$id)->first();
         $districts = RefDistrict::where('ref_state_id',$userdetails->state)->orderBy('district_name','ASC')->get();
        $regions = RefRegion::where('ref_state_id',$userdetails->ref_district_id)->orderBy('block_tehsil_name','ASC')->get();
        $villages = RefVillage::where('ref_district_id',$userdetails->ref_district_id)->orderBy('village_name','ASC')->get();

        return view('admin.usermanagement.deptUser.wildHarvestDetail1',compact('id','states','bankName','harvester','districts','regions','villages','userdetails','bankDetail'));
    }

    public function wildHarvestUserAddStep3($id){
        $userdetails = User::find(Auth::guard('misadmin')->user()->id);
        $states = RefState::orderBy('state_name','ASC')->get();
        $harvester = User::where('id',$id)->first();
        $forestDetail = User::with('getWildHarvesterDetail')->where('id',$id)->first();
        $districts = RefDistrict::where('ref_state_id',$userdetails->state)->orderBy('district_name','ASC')->get();
        $regions = RefRegion::where('ref_state_id',$userdetails->state)->orderBy('block_tehsil_name','ASC')->get();
        $villages = RefVillage::where('ref_district_id',$userdetails->district)->orderBy('village_name','ASC')->get();

        return view('admin.usermanagement.deptUser.wildHarvestDetail2',compact('id','states','districts','regions','villages','userdetails','forestDetail','harvester'));
    }

    public function wildHarvestUserAddStep4($id){

        $userdetails = User::find(Auth::guard('misadmin')->user()->id);
        $harvester = User::where('id',$id)->first();
        $states = RefState::orderBy('state_name','ASC')->get();
        $permittedDetails = WildHarvesterDetail::where('at_user_id',$id)->get();
        $pfDetails = WildHarvesterPermittedForestAreaDetail::where('at_user_id',$id)->get();
        $districts = RefDistrict::where('ref_state_id',$userdetails->state)->orderBy('district_name','ASC')->get();
        $regions = RefRegion::where('ref_state_id',$userdetails->state)->orderBy('block_tehsil_name','ASC')->get();
        $villages = RefVillage::where('ref_district_id',$userdetails->district)->orderBy('village_name','ASC')->get();

        return view('admin.usermanagement.deptUser.wildHarvestDetail3',compact('harvester','id','states','districts','regions','villages','userdetails','permittedDetails','pfDetails'));
    }

    public function wildHarvestUserAddStep5($id){
        $userdetails = User::find(Auth::guard('misadmin')->user()->id);
        $harvester = User::where('id',$id)->first();
        $states = RefState::orderBy('state_name','ASC')->get();
        $permittedDetails = WildHarvesterDetail::where('at_user_id',$id)->get();
        //$productDetails = User::with('getForestProductDetail')->where('id',$id)->get();
        $productDetails = WildHarvesterForestProductDetail::where('at_user_id',$id)->get();
        $districts = RefDistrict::where('ref_state_id',$userdetails->state)->orderBy('district_name','ASC')->get();
        $regions = RefRegion::where('ref_state_id',$userdetails->state)->orderBy('block_tehsil_name','ASC')->get();
        $villages = RefVillage::where('ref_district_id',$userdetails->district)->orderBy('village_name','ASC')->get();
        $auth =  Auth::guard('misadmin')->user()->created_by;
        $cbID =  User::where('id',$auth)->first();
 

        return view('admin.usermanagement.deptUser.wildHarvestDetail4',compact('permittedDetails','harvester','id','states','districts','regions','villages','userdetails','productDetails','cbID'));
    }

    public function wildHarvestUserAddStep6($id){
        $userdetails = User::find(Auth::guard('misadmin')->user()->id);
        $harvester = User::where('id',$id)->first();
        $document = WildHarvesterDocument::where('at_user_id',$id)->first();
        $states = RefState::orderBy('state_name','ASC')->get();
        $districts = RefDistrict::where('ref_state_id',$userdetails->state)->orderBy('district_name','ASC')->get();
        $regions = RefRegion::where('ref_state_id',$userdetails->state)->orderBy('block_tehsil_name','ASC')->get();
        $villages = RefVillage::where('ref_district_id',$userdetails->district)->orderBy('village_name','ASC')->get();

        return view('admin.usermanagement.deptUser.wildHarvestDetail5',compact('harvester','id','states','districts','regions','villages','userdetails','document'));
    }

    public function wildHarvestUserStore(Request $request, $id)
    {

         $request->validate([
            "gender"=>'required',
            "state" =>  'required',
            "taluka" =>  'required',
            "district" =>  'required',
            "village" =>  'required',
            "pin_code" => 'required|numeric|digits:6',
            "address" => 'required',
            // "mobile_number" => 'required',
            // "aadhar_number" =>  'required',
            // "pan_number" => 'required',
            // "email_id" =>'required',
            "no_of_collectors" => 'required',
        ]);

        try {


            User::updateOrCreate(['id' => $id,], [
                'first_name' => $request->first_name,
                'middle_name' => $request->middle_name,
                'last_name' => $request->last_name,
                'gender' => $request->gender,
                'contact_person_mobile_number' => $request->mobile_number,
                'contact_person_pan_number' => $request->pan_number,
                'no_of_collectors' => $request->no_of_collectors,
				
				//'contact_person_email' => $request->email_id,
				// 'contact_person_aadhar_number' => $request->aadhar_number,
               // 'ref_state_id' => $request->state,
               // 'ref_block_tehsil_id' => $request->taluka,
               // 'ref_district_id' => $request->district,
               // 'ref_village_id' => $request->village,
			   
                'address' => $request->address,
                'pin' => $request->pin_code,
                'updated_at' => date('Y-m-d H:i:s'),
            ]);

            WildHarvesterDetail::updateOrCreate(['at_user_id' => $id,], [
                'at_user_id' => $id,
                'area_cultivation'=>$request->area_cultivation,
                'ref_operator_type_id'=> $request->ref_operator_type_id,
                'father_first_name' => $request->father_first_name,
                'father_middle_name' => $request->father_middle_name,
                'father_last_name' => $request->father_last_name,
                'created_at' =>date('Y-m-d H:i:s'),
            ]);

                Alert::success('Success', 'Record updated Successfully');

            if ($request->ref_operator_type_id == 4) {
                return redirect()->route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep2', $id)->with('success', __('message.add_first_success'));
            } else {
                return redirect()->back()->with('success', __('message.add_success'));
            }
        } catch (Exception $e) {
             Log::error($e->getMessage());
            abort('404');
        }
    }

    public function wildHarvestUserStoreStep2(Request $request, $id)
    { 
		
         $request->validate([
            'bank_name' => 'required',
            'account_number' => 'required',
            'ifsc_code' => 'required',
            'branch_name' => 'required',
            'bank_address' => 'required',
            'bank_pincode' => 'required',
         ]);

        try {
				
			$decodedAccountNumber = base64_decode($request->input('account_number')); 
            $check = WildHarvesterBankDetail::where('at_user_id', $id)->first();
            $harvester_photo = '';
            if (!empty($check)) {
                if ($request->hasFile('harvester_photo')) {
                    $documentRootPath = 'public/research/uploads';
                    $file_path = time() . rand() . '.' . $request->file('harvester_photo')->getClientOriginalExtension();
                    $request->file('harvester_photo')->move($documentRootPath, $file_path);
                    $harvester_photo = $file_path;
                } else {
                    $harvester_photo = $check->harvester_photo;
                }
            } else {
                if ($request->hasFile('harvester_photo')) {
                    $documentRootPath = 'public/research/uploads';
                    $file_path = time() . rand() . '.' . $request->file('harvester_photo')->getClientOriginalExtension();
                    $request->file('harvester_photo')->move($documentRootPath, $file_path);
                    $harvester_photo = $file_path;
                } else {
                    $harvester_photo = '';
                }
            }  
        


            $existingRecord = WildHarvesterBankDetail::where('at_user_id', $id)->first(); 

                if ($existingRecord) {
                    // Update the record
                    $existingRecord->update([
                        'ref_operator_type_id' => !empty($request->ref_operator_type_id) ? $request->ref_operator_type_id : NULL,
                        'ref_bank_id' => !empty($request->bank_name) ? $request->bank_name : NULL,
                        'account_number' => !empty($request->account_number) ? $request->account_number : NULL,
                        'ifsc_code' => !empty($request->ifsc_code) ? $request->ifsc_code : NULL,
                        'branch_name' => !empty($request->branch_name) ? $request->branch_name : NULL,
                        'bank_address' => !empty($request->bank_address) ? $request->bank_address : NULL,
                        'pincode' => !empty($request->bank_pincode) ? $request->bank_pincode : Null,
                    ]);
                } else {
                    // Create the record
                    WildHarvesterBankDetail::create([
                        'at_user_id' => $id,
                        'ref_operator_type_id' => !empty($request->ref_operator_type_id) ? $request->ref_operator_type_id : NULL,
                        'ref_bank_id' => !empty($request->bank_name) ? $request->bank_name : NULL,
                        'account_number' => !empty($request->account_number) ? $request->account_number : NULL,
                        'ifsc_code' => !empty($request->ifsc_code) ? $request->ifsc_code : NULL,
                        'branch_name' => !empty($request->branch_name) ? $request->branch_name : NULL,
                        'bank_address' => !empty($request->bank_address) ? $request->bank_address : NULL,
                        'pincode' => !empty($request->bank_pincode) ? $request->bank_pincode : NULL,
                    ]);
                }
           
            Alert::success('Success', 'Record updated Successfully..');
            if ($request->ref_operator_type_id == 4) {
                return redirect()->route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep3', $id)->with('success', __('message.add_second_success'));
            } else {
                return redirect()->back()->with('success', __('message.add_success'));
            }
            } catch (Exception $e) {
                Log::error($e->getMessage());
                abort('404');
            }
    }

    public function wildHarvestUserStoreStep3(Request $request, $id)
    {
        // $request->validate([
        //     'area_in_hectars' => 'required',
        //     'forest_permit_number' => 'required',
        //     'forest_permit_number_up_to' => 'required',
        //     'state' => 'required',
        //     'circle' => 'required',
        //     'division' => 'required',
        //     'sub_division' => 'required',
        //     'range' => 'required',
        //     'sub_range' => 'required',
        //     'beat' => 'required',
        //     'compartment_no' => 'required',
        //     'latitude' => 'required',
        //     'longitude' => 'required',
        // ]);
        try {

            WildHarvesterDetail::updateOrCreate(['at_user_id' => $id,], [
                'at_user_id' => $id,
                'area_cultivation' => $request->area_in_hectars,
                'mou_permit_no' => $request->mou_permit_no,
                'permit_no_valid_upto' => $request->forest_permit_number_up_to,
                'ref_state_id' => $request->state,
                'circle' => $request->circle,
                'division' => $request->division,
                'sub_division' => $request->sub_division,
                'range' => $request->range,
                'sub_range' => $request->sub_range,
                'beat' => $request->beat,
                'compartment_no' => $request->compartment_no,
                'latitude' => $request->latitude,
                'longitude' => $request->longitude,
            ]);
            Alert::success('Success', 'Record updated Successfully');
            if ($request->ref_operator_type_id == 4) {
               return redirect()->route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep4', $id)->with('success', __('message.add_second_success'));
            } else {
                 return redirect()->back()->with('success', __('message.add_success'));
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function wildHarvestUserStoreStep4(Request $request, $id)
{
    $request->validate([
        'at_wh_forest_details_id' => 'required',
        'geo_tagging_of_forest_land' => 'required',
        'total_area_of_forest' => 'required',
        'organic_cultivation' => 'required',
    ]);
    try {
        // dd($request->all());
        $land_id = $request->at_wh_forest_details_id;
        // dd($land_id);
        if (count($land_id) > 0) {
            foreach ($land_id as $key => $li) {
                if (!empty($li)) {
                    // Check if row_id[$key] exists and is not empty
                    if (!empty($request->row_id[$key])) {
                        $check = WildHarvesterPermittedForestAreaDetail::where('id', (int)$request->row_id[$key])->first();
                        $geo_taging_image = '';

                        // If the record is found
                        if (!empty($check)) {
                            // Handle file upload if it's present
                            if (!empty($request->file('geo_taging_image')[$key])) {
                                $documentRootPath = 'public/research/uploads';
                                $file_path = time() . rand() . '.' . $request->file('geo_taging_image')[$key]->getClientOriginalExtension();
                                $request->file('geo_taging_image')[$key]->move($documentRootPath, $file_path);
                                $geo_taging_image = $file_path;
                            } else {
                                // If no file uploaded, keep existing image
                                $geo_taging_image = $check->geo_taging_image;
                            }

                            // Update existing record
                            $check->at_user_id = $id;
                            $check->at_wh_forest_details_id = $li;
                            $check->image_after_tagging = $request->geo_tagging_of_forest_land[$key];
                            $check->total_forest_area_under_organic = $request->total_area_of_forest[$key];
                            $check->organic_cultivation = $request->organic_cultivation[$key];
                            $check->forest_farm_image = $geo_taging_image;
                            $check->save();
                        } else {
                            // If no record found, create a new one
                            if (!empty($request->file('geo_taging_image')[$key])) {
                                $documentRootPath = 'public/research/uploads';
                                $file_path = time() . rand() . '.' . $request->file('geo_taging_image')[$key]->getClientOriginalExtension();
                                $request->file('geo_taging_image')[$key]->move($documentRootPath, $file_path);
                                $geo_taging_image = $file_path;
                            } else {
                                // If no file uploaded, set image to empty
                                $geo_taging_image = '';
                            }

                            // Create new record
                            $standing = new WildHarvesterPermittedForestAreaDetail();
                            $standing->at_user_id = $id;
                            $standing->at_wh_forest_details_id = $li;
                            $standing->image_after_tagging = $request->geo_tagging_of_forest_land[$key];
                            $standing->total_forest_area_under_organic = $request->total_area_of_forest[$key];
                            $standing->organic_cultivation = $request->organic_cultivation[$key];
                            $standing->forest_farm_image = $geo_taging_image;
                            $standing->save();
                        }
                    } else {
                        // If row_id is empty, handle it by continuing to the next iteration
                        if (!empty($request->file('geo_taging_image')[$key])) {
                            $documentRootPath = 'public/research/uploads';
                            $file_path = time() . rand() . '.' . $request->file('geo_taging_image')[$key]->getClientOriginalExtension();
                            $request->file('geo_taging_image')[$key]->move($documentRootPath, $file_path);
                            $geo_taging_image = $file_path;
                        } else {
                            $geo_taging_image = '';
                        }

                        // Create new record since there's no row_id to update
                        $standing = new WildHarvesterPermittedForestAreaDetail();
                        $standing->at_user_id = $id;
                        $standing->at_wh_forest_details_id = $li;
                        $standing->image_after_tagging = $request->geo_tagging_of_forest_land[$key];
                        $standing->total_forest_area_under_organic = $request->total_area_of_forest[$key];
                        $standing->organic_cultivation = $request->organic_cultivation[$key];
                        $standing->forest_farm_image = $geo_taging_image;
                        $standing->save();
                    }
                    Alert::success('Success', 'Record updated Successfully');
                }
            }
        }

        // Redirect logic
        if ($request->ref_operator_type_id == 4) {
            return redirect()->route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep5', $id)->with('success', __('message.add_second_success'));
        } else {
            return redirect()->back()->with('success', __('message.add_success'));
        }
    } catch (Exception $e) {
        Log::error($e->getMessage());
        abort('404');
    }
}


    public function wildHarvestDeletePermittedForestArea(Request $request)
    {
        try {
            WildHarvesterPermittedForestAreaDetail::where('id', $request->id)->delete();

            return 1;
        } catch (Exception $e) {
            Alert::error('Error', $e->getMessage());
            \Log::error($e->getMessage());
            abort(404);
        } catch (\Illuminate\Database\QueryException $exception) {
            Alert::error('Error', $exception->getMessage());
            \Log::error($exception->getMessage());
            Alert::error('error', 'Query Exception');

            return redirect()->back();
        }
    }


    public function wildHarvestUserStoreStep5(Request $request, $id)
    {


        $request->validate([
            'forest_land_id' => 'required',
            'type_of_the_forest_product' => 'required',
            'name_of_the_forest_product' => 'required',
            'area_under_cultivation' => 'required',
        ]);
        try {
            //dd($request->all());
            $forest_land_id = $request->forest_land_id;
            if (count($forest_land_id) > 0) {
                foreach ($forest_land_id as $key => $fli) {
                    if (!empty($fli)) {
                        if (isset($request->row_id[$key])) {
                            $check = WildHarvesterForestProductDetail::where('at_user_id', $id)->first();
                            $photo_of_forest_product = '';
                            if (!empty($check)) {
                                if (!empty($request->file('photo_of_forest_product')[$key])) {
                                    $documentRootPath = 'public/research/uploads';
                                    $file_path = time() . rand() . '.' . $request->file('photo_of_forest_product')[$key]->getClientOriginalExtension();
                                    $request->file('photo_of_forest_product')[$key]->move($documentRootPath, $file_path);
                                    $photo_of_forest_product = $file_path;
                                } else {
                                    $photo_of_forest_product = $check->photo_of_forest_product;
                                }

                                $check->at_user_id = $id;
                                $check->at_wh_forest_details_id = $fli;
                                $check->type_of_the_forest_product = $request->type_of_the_forest_product[$key];
                                $check->name_of_the_forest_product = $request->name_of_the_forest_product[$key];
                                $check->area_under_cultivation = $request->area_under_cultivation[$key];
                                $check->forest_product_image = $photo_of_forest_product;
                                $check->organic_status = $request->details_organic_status[$key];
                                $check->save();
                            }else{
                                if (!empty($request->file('photo_of_forest_product')[$key])) {
                                    $documentRootPath = 'public/research/uploads';
                                    $file_path = time() . rand() . '.' . $request->file('photo_of_forest_product')[$key]->getClientOriginalExtension();
                                    $request->file('photo_of_forest_product')[$key]->move($documentRootPath, $file_path);
                                    $photo_of_forest_product = $file_path;
                                } else {
                                    $photo_of_forest_product = '';
                                }

                                $standing = new WildHarvesterForestProductDetail();
                                $standing->at_user_id = $id;
                                $standing->at_wh_forest_details_id = $fli;
                                $standing->type_of_the_forest_product = $request->type_of_the_forest_product[$key];
                                $standing->name_of_the_forest_product = $request->name_of_the_forest_product[$key];
                                $standing->area_under_cultivation = $request->area_under_cultivation[$key];
                                $standing->forest_product_image = $photo_of_forest_product;
                                $standing->organic_status = $request->details_organic_status[$key];
                                $standing->save();
                            }
                        } else {
                            if (!empty($request->file('photo_of_forest_product')[$key])) {
                                $documentRootPath = 'public/research/uploads';
                                $file_path = time() . rand() . '.' . $request->file('photo_of_forest_product')[$key]->getClientOriginalExtension();
                                $request->file('photo_of_forest_product')[$key]->move($documentRootPath, $file_path);
                                $photo_of_forest_product = $file_path;
                            } else {
                                $photo_of_forest_product = '';
                            }

                            $standing = new WildHarvesterForestProductDetail();
                            $standing->at_user_id = $id;
                            $standing->at_wh_forest_details_id = $fli;
                            $standing->type_of_the_forest_product = $request->type_of_the_forest_product[$key];
                            $standing->name_of_the_forest_product = $request->name_of_the_forest_product[$key];
                            $standing->area_under_cultivation = $request->area_under_cultivation[$key];
                            $standing->forest_product_image = $photo_of_forest_product;
                            $standing->organic_status = $request->details_organic_status[$key];
                            $standing->save();
                        }
                    }
                }
            }

            Alert::success('Success', 'Record updated Successfully');
            if (Auth::guard('misadmin')->user()->ref_operator_type_id == 4) {
                return redirect()->route('superadmin.usermanagement.deptUser.wildHarvestUserAddStep6', $id)->with('success', __('message.add_second_success'));
            } else {
                return redirect()->back()->with('success', __('message.add_success'));
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function wildHarvestDeleteForestProduct(Request $request)
    {
        try {
            WildHarvesterForestProductDetail::where('id', $request->id)->delete();

            return 1;
        } catch (Exception $e) {
            Alert::error('Error', $e->getMessage());
            \Log::error($e->getMessage());
            abort(404);
        } catch (\Illuminate\Database\QueryException $exception) {
            Alert::error('Error', $exception->getMessage());
            \Log::error($exception->getMessage());
            Alert::error('error', 'Query Exception');

            return redirect()->back();
        }
    }

    public function wildHarvestUserStoreStep6(Request $request, $id)
    {

        // $request->validate([
        //     'aadhar_card' => 'required',
        //     'pan_card' => 'required',
        //     'permit_document' => 'required',
        //     'bank_passbook' => 'required',
        //     'farmer_sign_thumb_Impression' => 'required',
        //     'live_signature_thumb_impression' => 'required',
        // ]);

        try {

            $permit_document = $aadhar_card = $pan_card = $bank_passbook =  $farmer_sign_thumb_Impression = $live_signature_thumb_impression = '';


            if (!empty($request->file('aadhar_card'))) {
                if (!empty($request->aadhar_card_edit)) {
                    $imagePath = public_path('research/uploads/') . $request->aadhar_card;
                    deleteOldImage($request->aadhar_card_edit, $imagePath);
                }
                $documentRootPath = 'public/research/uploads';
                $file_path = time() . rand() . '.' . $request->file('aadhar_card')->getClientOriginalExtension();
                $request->file('aadhar_card')->move($documentRootPath, $file_path);
                $aadhar_card = $file_path;
            } else {
                if (!empty($request->aadhar_card_edit))
                    $aadhar_card = $request->aadhar_card_edit;
            }

            if (!empty($request->file('permit_document'))) {
                if (!empty($request->permit_document_edit)) {
                    $imagePath = public_path('research/uploads/') . $request->permit_document;
                    deleteOldImage($request->permit_document_edit, $imagePath);
                }
                $documentRootPath = 'public/research/uploads';
                $file_path = time() . rand() . '.' . $request->file('permit_document')->getClientOriginalExtension();
                $request->file('permit_document')->move($documentRootPath, $file_path);
                $permit_document = $file_path;
            } else {
                if (!empty($request->permit_document_edit))
                    $permit_document = $request->permit_document_edit;
            }

            if (!empty($request->file('pan_card'))) {
                if (!empty($request->pan_card_edit)) {
                    $imagePath = public_path('research/uploads/') . $request->pan_card;
                    deleteOldImage($request->pan_card_edit, $imagePath);
                }
                $documentRootPath = 'public/research/uploads';
                $file_path = time() . rand() . '.' . $request->file('pan_card')->getClientOriginalExtension();
                $request->file('pan_card')->move($documentRootPath, $file_path);
                $pan_card = $file_path;
            } else {
                if (!empty($request->pan_card_edit))
                    $pan_card = $request->pan_card_edit;
            }

            if (!empty($request->file('bank_passbook'))) {
                if (!empty($request->bank_passbook_edit)) {
                    $imagePath = public_path('research/uploads/') . $request->bank_passbook;
                    deleteOldImage($request->bank_passbook_edit, $imagePath);
                }
                $documentRootPath = 'public/research/uploads';
                $file_path = time() . rand() . '.' . $request->file('bank_passbook')->getClientOriginalExtension();
                $request->file('bank_passbook')->move($documentRootPath, $file_path);
                $bank_passbook = $file_path;
            } else {
                if (!empty($request->bank_passbook_edit))
                    $bank_passbook = $request->bank_passbook_edit;
            }

            if (!empty($request->file('farmer_sign_thumb_Impression'))) {
                if (!empty($request->farmer_sign_thumb_Impression_edit)) {
                    $imagePath = public_path('research/uploads/') . $request->farmer_sign_thumb_Impression;
                    deleteOldImage($request->farmer_sign_thumb_Impression_edit, $imagePath);
                }
                $documentRootPath = 'public/research/uploads';
                $file_path = time() . rand() . '.' . $request->file('farmer_sign_thumb_Impression')->getClientOriginalExtension();
                $request->file('farmer_sign_thumb_Impression')->move($documentRootPath, $file_path);
                $farmer_sign_thumb_Impression = $file_path;
            } else {
                if (!empty($request->farmer_sign_thumb_Impression_edit))
                    $farmer_sign_thumb_Impression = $request->farmer_sign_thumb_Impression_edit;
            }


            if (!empty($request->file('live_signature_thumb_impression'))) {
                if (!empty($request->live_signature_thumb_impression_edit)) {
                    $imagePath = public_path('research/uploads/') . $request->live_signature_thumb_impression;
                    deleteOldImage($request->live_signature_thumb_impression_edit, $imagePath);
                }
                $documentRootPath = 'public/research/uploads';
                $file_path = time() . rand() . '.' . $request->file('live_signature_thumb_impression')->getClientOriginalExtension();
                $request->file('live_signature_thumb_impression')->move($documentRootPath, $file_path);
                $live_signature_thumb_impression = $file_path;
            } else {
                if (!empty($request->live_signature_thumb_impression_edit))
                    $live_signature_thumb_impression = $request->live_signature_thumb_impression_edit;
            }

            $data = WildHarvesterDocument::updateOrCreate(['at_user_id' => $id], [
                'at_user_id' => $id,
                'aadhar_card_image_path' => $aadhar_card,
                'pan_card_image_path' => $pan_card,
                'land_documents_image_path' => $permit_document,
                'passbook_image_path' => $bank_passbook,
                'contact_person_sign_image_path' => $farmer_sign_thumb_Impression,
                'live_signature_image_path' => $live_signature_thumb_impression,
                'updated_at' => date('Y-m-d H:i:s'),
                'updated_by' => Auth::guard('misadmin')->user()->id,
            ]);

            Alert::success('Success', 'Record updated Successfully.');
            if (Auth::guard('misadmin')->user()->ref_operator_type_id == 4) {
                return redirect()->route('superadmin.wildHarvest.preview', $id);
            } else {
                return redirect()->back()->with('success', __('message.add_success'));
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

	public function wildHarvestPreview(Request $request,$id)
    {
        // dd('hi');
        $user = User::where('id',$id)->first();
        $wh_details = WildHarvesterDetail::where('at_user_id',$id)->first();
        //dd($wh_details);
        $wh_bankDetail = WildHarvesterBankDetail::where('at_user_id', $id)->first();
        $wh_docs = WildHarvesterDocument::where('at_user_id',$id)->first();
        $wh_forest_details = WildHarvesterPermittedForestAreaDetail::where('at_user_id',$id)->get();
        $wh_product_details = WildHarvesterForestProductDetail::where('at_user_id',$id)->get();
        $states = RefState::orderBy('state_name','ASC')->get();
        //dd($wh_product_details);

        $eMSignedModuleResult = '';
        $hostName = '';
        $eMSignedModuleAlow = getUserDigitalSignatureModules(Auth::id(),'SC');
        if($eMSignedModuleAlow['status'] == 'success' && $eMSignedModuleAlow['isAllowed'] == '1'){
            $hostName = request()->getSchemeAndHttpHost();
            $checkSignedPDf = getDigitalSignedPdf(Auth::id(),basename($user->registration_certificate));
            if ($checkSignedPDf['status'] == 'success') {
                $eMSignedModuleResult = [
                    'signedPath' => $checkSignedPDf['signedPath'],
                    'status' => 'success',
                ];
            } else {
                $eMSignedModuleResult = [
                    'signedPath' => '', 
                    'status' => 'failed',
                ];
            }            
            
        }

        return view('admin/usermanagement/deptUser/wild_harvest_preview', compact('id','user','wh_details','states','wh_docs','wh_forest_details','wh_product_details','wh_bankDetail','eMSignedModuleAlow','eMSignedModuleResult','hostName'));
    }

    public function whbatchCreationindex(Request $request, $at_user_id)
    {
         
        $atusrID = CertificateStandardDetail::where('at_user_id', $at_user_id)->first();
        if (empty($atusrID->scope_certificate_no)) {
            Alert::warning('First apply for the scope certificate');

            return redirect()->back();
        }
        
        $product_details = WildHarvesterForestProductDetail::where('at_user_id',$at_user_id)->get();
        // dd($product_details);
     
        return view('admin.wildharvest.batch_add', compact('product_details'));
    }

    public function whbatchCreation(Request $request, $at_user_id, $hscode = null)
    {
        if (empty($hscode)) {
            return redirect()->back()->with('error', 'HS Code is NULL.');
        }
        $list = CertificateStandardDetail::where('at_user_id', $at_user_id)->first();
        $org_st = WildHarvesterForestProductDetail::where('at_user_id', $at_user_id)->first();
        $user = User::where('id', $at_user_id)->first();
        $gethscode  = RefProduct::where('id', $hscode)->first();
        // dd($gethscode);
    
        return view('admin/wildharvest/create_batch', compact('list', 'org_st', 'user', 'gethscode'));
    }
    

   /* public function batchCreationsave(Request $request)
    {
        // $request->validate([
        //     'scope_certificate_no' => 'required',
        //     'hs_code' => 'required',
        //     'product' => 'required',
        // ]);


        $formData = new BatchCreation;

        $formData->scope_certificate_no = $request->input('scope_certificate_no');
        $formData->unit_name = $request->input('unit_name');
        $formData->hs_code = $request->input('hs_code');
        $formData->product = $request->input('product');
        $formData->organic_status = $request->input('organic_status');
        $formData->quantity = $request->input('quantity');
        $formData->percentage = $request->input('percentage');
        $formData->processing_date = $request->input('processing_date');
        $formData->expiry_date = $request->input('expiry_date');
        $formData->by_product = $request->input('byProduct');
        $formData->created_at = date('Y-m-d H:i:s');
        $formData->updated_at = date('Y-m-d H:i:s');
        $formData->created_by = Auth::guard('misadmin')->user()->id;
        $formData->updated_by = Auth::guard('misadmin')->user()->id;
        $formData->at_user_id = Auth::guard('misadmin')->user()->id;

        $formData->save();
        // dd($formData);


        return redirect()->route('superadmin.whbatchCreationsouceDetails');
    }*/

    public function batchCreationsave(Request $request)
    {   
    // Create a new BatchCreation instance and populate its fields
    $formData = new BatchCreation;
    $formData->scope_certificate_no = $request->input('scope_certificate_no');
    $formData->unit_name = $request->input('unit_name');
    $formData->hs_code = $request->input('hs_code');
    $formData->product = $request->input('product');
    $formData->organic_status = $request->input('organic_status');
    $formData->quantity = $request->input('quantity');
    $formData->percentage = $request->input('percentage');
    $formData->processing_date = $request->input('processing_date');
    $formData->expiry_date = $request->input('expiry_date');
    $formData->by_product = $request->input('byProduct');
    $formData->created_at = now();
    $formData->updated_at = now();
    $formData->created_by = Auth::guard('misadmin')->user()->id;
    $formData->updated_by = Auth::guard('misadmin')->user()->id;
    $formData->at_user_id = Auth::guard('misadmin')->user()->id;
    $mmyy = Carbon::now()->format('mY');
    $formData->id_of_batch = $mmyy.Auth::guard('misadmin')->user()->id;

    // Save the BatchCreation record
    $formData->save();

    // Retrieve the id of the newly created BatchCreation record
    $batchCreationId = $formData->id;

    $atBatchDetail = new AtBatchDetail;
    $atBatchDetail->batch_id = $batchCreationId;
    $atBatchDetail->product_code =  $request->input('hs_code');
    $atBatchDetail->product_name =  $request->input('product');
    $atBatchDetail->total_quantity =  $request->input('quantity');
    $atBatchDetail->created_at = now();
    $atBatchDetail->updated_at = now();
    $atBatchDetail->created_by = Auth::guard('misadmin')->user()->id;
    $atBatchDetail->updated_by = Auth::guard('misadmin')->user()->id;
    $atBatchDetail->at_user_id = Auth::guard('misadmin')->user()->id;
    $mmyy = Carbon::now()->format('mY');
    $atBatchDetail->id_of_batch = $mmyy.Auth::guard('misadmin')->user()->id;
    $atBatchDetail->save();

    // Redirect the user to the desired route after successful insertion
    //return redirect()->route('superadmin.ipbatchCreationsouceDetails');
    return redirect()->route('superadmin.whbatchCreationsouceDetails' , auth()->user()->id);

    }

    public function WhbatchCreationsouceDetails($at_user_id)
    {
        // dd(auth()->user()->id);
        $batchId = BatchCreation::where('at_user_id', $at_user_id)->first();
        $batchDetailsId = AtBatchDetail::where('at_user_id', $at_user_id)->get();
        $data =  SourceDetails::where('at_user_id', $at_user_id)->whereNull('at_source_details.deleted_at')->get();
        
        return view('admin/wildharvest/source_detail', compact('batchId', 'batchDetailsId', 'data'));
    }

    public function Search(Request $request)
    {
        try {
            // Check if the request is an AJAX request
            if ($request->ajax()) {

                $userId = Auth::id();
                $query = AtOpTransactionVsTransactionProduct::
                 leftjoin('at_batch_creation as bcr','bcr.at_user_id','=','at_op_transaction_vs_transaction_product.created_by')
                ->whereNotNull('transaction_certificate_no')->whereNotNull('product_code')
                ->where('transaction_certificate_no', '!=', '')
                ->where('product_code', '!=', '');
                
                if (!empty($request->registration_no)) {
                    $query->where('product_code', $request->registration_no);
                }
                $finalData = $query->get();
               
                

                // Use DataTables to format the data
                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()
                    ->addColumn('tc_no', function ($row) {
                        return $row->transaction_certificate_no;
                    })
                    ->addColumn('product_name', function ($row) {
                        return !empty($row->product_code) ? getHscodeProductName($row->product_code) : 'N/A';
                    })
                    ->addColumn('organic_status', function ($row) {
                        return !empty($row->organic_status) ? getRefOrganicStatuscodeByname($row->organic_status) : 'N/A';
                    })
                    ->addColumn('total_qnt', function ($row) {
                        return $row->total_qty;
                    })
                    ->addColumn('used_qnt', function ($row) {
                        return $row->quantity_for_tc;
                    })
                    ->addColumn('available_qnt', function ($row) {
                        return $row->rem_qty;
                    })
                    ->addColumn('qnt_source', function ($row) {

                        $uniqueId = 'qnt_source_' . $row->id;
                        return sprintf(
                            '<input type="text" class="form-control qnt_sourceX" id="qnt_source' . $row->id . '"  name="qnt_source" value="">',
                            $uniqueId,
                            $row->id,
                            $row->qnt_source
                        );
                    })
                    ->addColumn('action', function ($row) {

                        return '<a href="javascript:;" class="saveButton" data-id="' . $row->id . '" data-tcno="' . $row->transaction_certificate_no .'" data-procode="' . $row->product_code . '" data-id_of_batch="' . $row->id_of_batch . '" data-qty ="' . $row->total_qty . '" data-usedqty ="' . $row->quantity_for_tc . '" data-available_qnt="' . $row->rem_qty . '">Add</a>';
                    })
                    ->rawColumns(['qnt_source', 'action']);


                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            // Handle exceptions and log errors
            Log::error($e);
            Alert::error('Error', 'Something went wrong, please try again later.');
            return redirect()->back();
        }
    }

    public function saveQuantitySource(Request $request)
    {
        // dd($request->all());
        $at_user_id = Auth::guard('misadmin')->user()->id;
        $rowId = $request->input('row_id');
        $tcNo = $request->input('tc_no');
        $procode = $request->input('pro_code');
        $qty = $request->input('total_quantity');
        $usedqty = $request->input('used_quantity');
        $available_qnt = $request->input('available_qnt');
        $qntSourceValue = $request->input('qnt_source');
        // $batch_id = $request->input('row_id');
        $batchId = $request->input('batch_id');
        $id_of_batch = $request->input('id_of_batch');


        $record = new SourceDetails;

        if ($record) {

            // $record->at_user_id = $at_user_id;
            // $record->product_code = $procode;
            // $record->tc_no = $tcNo;
            // // $record->organic_status = $organic_statusValue;
            // $record->total_quantity = $qty;
            // $record->source_from = 'TC';
            // $record->used_quantity =   $usedqty;
            // $record->available_quantity = $available_qnt;
            // $record-> expiry_date = $request->input('expiry_date');
            // $record->quantity_source = $qntSourceValue;
            // $record->batch_id = $batch_id;

            $record->at_user_id = $at_user_id;
            $record->product_code = $procode;
            $record->batch_id =  $batchId;
            // $record->batchdetails_id =  $batchDetailsId; 
            $record->tc_no = $tcNo;
            $record->used_quantity =  $usedqty;
            $record->available_quantity =  $available_qnt;
            $record->quantity_source =  $qntSourceValue;
            $record->id_of_batch =  $id_of_batch;


            $record->save();


            return response()->json(['success' => true, 'message' => 'Saved successfully','data'=>$record]);
        } else {

            return response()->json(['success' => false, 'message' => 'Record not found'], 404);
        }
    }

    public function batchCreationPreviewDetails($at_user_id)
	{

		$data = BatchCreation::where('at_user_id', $at_user_id)->first();
        $Sourcedata = SourceDetails::where('at_user_id', $at_user_id)->whereNull('at_source_details.deleted_at')->get();
		

		return view('admin/wildharvest/preview_detail', compact('data', 'Sourcedata'));
	}

    public function batchCreationPreviewDetailssave(Request $request)
    {

        return redirect()->route('superadmin.WhDetails',  auth()->user()->id);
    }

    public function Details($at_user_id)
    {

        $data = SourceDetails::
            select('at_source_details.*',
            'at_batch_details.product_code',
            'at_batch_details.product_name',
            'at_batch_details.total_quantity',
            'at_batch_details.created_at'
            ) 
            ->LeftJoin('at_batch_details', 'at_source_details.batch_id', '=', 'at_batch_details.batch_id')
            ->whereNull('at_source_details.deleted_at') 
            ->orderby('at_source_details.id', 'desc')
            ->paginate(10);

    //    dd($data);
        return view('admin/wildharvest/batch_detail', compact('data'));
    }

    public function History()
    {
        $atusrID = CertificateStandardDetail::where('at_user_id', Auth()->user()->id)->first();
 
        $data = SourceDetails::select('at_source_details.*', 'at_batch_details.product_code','at_batch_details.product_name', 'at_batch_details.total_quantity', 'at_batch_details.created_at') // Select 
            ->LeftJoin('at_batch_details', 'at_source_details.batch_id', '=', 'at_batch_details.batch_id')
            ->whereNull('at_source_details.deleted_at') 
            ->orderby('at_source_details.id', 'desc')
            ->get();
          
        if (empty($atusrID->scope_certificate_no)) {
            Alert::warning('First apply for the scope certificate');

            return redirect()->back();
        }
                
        return view('admin.wildharvest.history', compact('data'));
    }

}





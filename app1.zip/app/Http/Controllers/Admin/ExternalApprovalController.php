<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\RefState;
use App\Models\RefDistrict;
use App\Models\RefRegion;
use App\Models\RefVillage;
use App\Models\RoleUser;
use App\Models\UserInspector;
use App\Models\AtFarmerRegDetail;
use App\Models\IndividualProducerFarmerDetail;
use App\Models\WildHarvesterDetail;
use App\Models\ProcessorBasicDetail;
use App\Models\TradersBasicDetail;
use App\Models\AtRiskAssessment;
use App\Models\AtExternalInspection;
use App\Models\AtExternalInspectionObservation;
use App\Models\FarmersRegSchedule;
use App\Models\UserWarehouseManagerOfficers;
use App\Models\AtFarmerInspectionDetail;
use App\Models\AtFarmerInspectionPlotDetails;
use App\Models\AtFarmerChecklist;
use App\Models\AtInspectionNonConformity;
use App\Models\AtInspectionApprovalInternalInspector;
use App\Models\InspectionSchedule;
use Illuminate\Support\Facades\Mail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;
use Validator;
use DataTables;
use Carbon\Carbon;
use DB;


class ExternalApprovalController extends Controller
{
    //


    public function inspectionSchedule($id)
    {
        $scheduleDetails = InspectionSchedule::where('at_ics_inspector_details_id', $id)->get();

        //$reg_villages = AtFarmerRegDetail::select('ref_village_id')->where('at_ics_inspector_id',$id)->get();
        $reg_villages = FarmersRegSchedule::select('ref_village_id')->where('at_ics_inspector_details_id', $id)->get();
        $user_id = Auth::guard('misadmin')->user()->id;
        $states = RefState::orderBy('state_name', 'ASC')->get();
        //$districts = RefDistrict::orderBy('district_name','ASC')->get();
        //$regions = RefRegion::orderBy('block_tehsil_name','ASC')->get();
        // $villages = RefVillage::orderBy('village_name','ASC')->limit(100)->get();

        return view('admin/external_approval/inspection-Schedule', compact('scheduleDetails', 'states', 'id', 'user_id', 'reg_villages'));
    }

    public function inspectionScheduleSave(Request $request) {}


    public function inspectionList(Request $request)
    {
        if ($request->ajax()) {
            $totalData = User::where('ref_operator_type_id', '!=', '1')->where('ref_operator_type_id', '!=', '7')->where('ref_operator_type_id', '!=', '102')->where('ref_operator_type_id', '!=', '103')->where('ref_operator_type_id', '!=', '9')
                ->whereRaw('( CASE 
                         WHEN ref_operator_type_id = 2 THEN risk_assessment = 1 
                         WHEN ref_operator_type_id != 2 THEN risk_assessment = 0  
                        END)')
                ->orderby('id', 'DESC')->get();

            // WHEN ref_operator_type_id = 2 THEN inspection_status = 1 
            return Datatables::of($totalData)
                ->addIndexColumn()
                ->addColumn('reg_no', function ($row) {
                    // return '#/'.getRolesTitle($row->ref_operator_type_id).'/'.$row->id??'';

                    if (empty($row->registration_no) || $row->registration_no == 'NULL::character varying') {
                        $m = date('m', strtotime($row->created_at));
                        $y = substr(date('Y', strtotime($row->created_at)), -2);
                        $lst = str_pad($row->id, 5, "0", STR_PAD_LEFT);
                        $st = "ORG/" . $m . $y . "/" . $lst;
                        return $st;
                    } else {
                        return $row->registration_no;
                    }
                })
                ->addColumn('name', function ($row) {
                    return $row->first_name ?? '';
                })
                ->addColumn('operator_type', function ($row) {
                    return getRolesTitle($row->ref_operator_type_id);
                })
                ->addColumn('action', function ($row) {
                    $actionBtn = '';


                    // $actionBtn .= '<a href="' . route('superadmin.external.inspectionSchedule', $row->id) . '"><span>Inspection Schedule</span></a><br>';

                    if ($row->external_inspection == 0) {
                        $actionBtn .= '<a href="' . route('superadmin.external.inspectionForm', $row->id) . '"><span>Enter External Inspection Details</span></a><br>';
                    } else {
                        $actionBtn .= '<a href="javascript:void(0)" style="color:green"><i class="ri-check-double-line"></i> External Inspection Done </a><br>';
                    }

                    if ($row->external_inspection == 0) {
                        $actionBtn .= '<a href="javascript:void(0)" onclick="ConfirmInspection()"><span>Enter Inspection Closure</span></a><br>';
                    } elseif ($row->external_inspection == 1) {
                        $actionBtn .= '<a href="' . route('superadmin.external.inspectionClosureForm', $row->id) . '"><span>Enter Inspection Closure</span></a><br>';
                    } else {
                        $actionBtn .= '<a href="' . route('superadmin.external.inspectionClosureForm', $row->id) . '" style="color:green"><span><i class="ri-check-double-line"></i>View Inspection Closure</span></a><br>';
                    }

                    if ($row->ref_operator_type_id == 2) {
                        $actionBtn .= '<a href="' . route('superadmin.external.viewInspectionList', ['fid' => $row->id]) . '"><span>View Internal Inspection Details</span></a><br>';
                    }

                    return $actionBtn;
                })

                ->rawColumns(['action'])
                ->make(true);
        }
        return view('admin/external_approval/inspection-list');
    }


    public function extRiskAssesmentList(Request $request)
    {

        $user_id = Auth::user()->id;

        //$inspIds =  UserInspector::select('id')->where('at_user_id',$user_id)->get();
        //$inspData =  AtFarmerRegDetail::select('at_ics_inspector_id')->where('inspection_status',1)->distinct()->get();
        //$approveData =  AtFarmerRegDetail::select('at_ics_inspector_id')->where('approval_flag',1)->distinct()->get();

        $inspIds =  UserInspector::select('id')->where('at_user_id', Auth::user()->id)->get();

        if ($request->ajax()) {

            $totalData = User::where('ref_operator_type_id', 2)
                ->when($request->operator, function ($q) use ($request) {
                    return $q->where('first_name', $request->operator)
                        ->orWhere('last_name', $request->operator);
                })->orderBy('id', 'desc')->get();

            return Datatables::of($totalData)
                ->addIndexColumn()
                ->addColumn('reg_no', function ($row) {
                    //return $row->id ?? '';
                    if (empty($row->registration_no) || $row->registration_no == 'NULL::character varying') {
                        $m = date('m', strtotime($row->created_at));
                        $y = substr(date('Y', strtotime($row->created_at)), -2);
                        $lst = str_pad($row->id, 5, "0", STR_PAD_LEFT);
                        $st = "ORG/" . $m . $y . "/" . $lst;
                        return $st;
                    } else {
                        return $row->registration_no;
                    }
                })
                ->addColumn('name', function ($row) {
                    return $row->first_name . ' ' . ($row->last_name ?? '');
                })->addColumn('address', function ($row) {
                    return $row->address ?? '';
                })->addColumn('reg_type', function ($row) {

                    return "";
                })->addColumn('operator_type', function ($row) {

                    return  'Grower Group';
                })->addColumn('action', function ($row) {
                    if ($row->risk_assessment == 0) {
                        $actionBtn = '<a href=' . route('superadmin.external.extRiskAssesmentDetail', $row->id) . '><i class="ri-mark-pen-fill"></i> Initiate Risk Assessment</a>';
                    } else {
                        $actionBtn = '<a href="javascript:void(0)" style="color:green"><i class="ri-check-double-line"></i> Done </a>';
                    }


                    return $actionBtn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        return view('admin/external_approval/RiskAssesment-list');
    }

    public function extRiskAssesmentDetail($id)
    {
        $regDetail = User::where('id', $id)->where('risk_assessment', 0)->first();
        if ($regDetail) {
            return view('admin/external_approval/risk-form', compact('regDetail'));
        } else {
            // risk assessment already done
            Alert::success('error', 'Risk Assessment Already Done.');
            return redirect()->back();
        }
    }


    public function inspectionDetail(Request $request)
    {
        // $fid = $request->fid;
        // $insid = $request->insid;
        // $regDetail = AtFarmerRegDetail::with(['farmerLandDetail','farmerBankDetail','farmerDocs','farmerOSPDetail'])->where('id',$fid)->first();
        // $farInspDetail = AtFarmerInspectionDetail::where('at_farmer_reg_details_id',$fid)->where('at_inspector_id',$insid)->first();
        // $farInspDetail = AtFarmerInspectionDetail::where('at_farmer_reg_details_id',$fid)->where('at_inspector_id',$insid)->first();
        // $farPlotDetail = AtFarmerInspectionPlotDetails::where('at_farmer_reg_details_id',$fid)->where('at_inspector_id',$insid)->get();
        // $farCheckList = AtFarmerChecklist::where('at_farmer_reg_details_id',$fid)->where('at_inspector_id',$insid)->get();
        // $nonConDetail = AtInspectionNonConformity::where('at_farmer_reg_details_id',$fid)->where('at_inspector_id',$insid)->get();
        // $appInspDetail = AtInspectionApprovalInternalInspector::where('at_farmer_reg_details_id',$fid)->where('at_ics_inspector_details_id',$insid)->first();


        // return view('admin/external_approval/inspection-detail',compact('regDetail','farInspDetail','farPlotDetail','farCheckList','nonConDetail','appInspDetail'));
        $id = $request->fid;
        abort_unless(\Gate::allows('farmer_access'), 403);

        $inspIds =  UserInspector::select('id')->where('at_user_id', $id)->orderBy('id', 'DESC')->get();

        if ($request->ajax()) {
            $totalData =  AtFarmerRegDetail::whereIn('at_ics_inspector_id', $inspIds)->get();
            return Datatables::of($totalData)
                ->addIndexColumn()
                ->addColumn('name', function ($row) {

                    return $row->farmer_first_name ?? '';
                })
                ->addColumn('email', function ($row) {
                    return $row->email_id ?? '';
                })->addColumn('mobile', function ($row) {
                    return $row->mobile_no ?? '';
                })->addColumn('address', function ($row) {

                    return $row->farmer_address ?? '';
                })->addColumn('insp_name', function ($row) {

                    return getInspectorName($row->at_ics_inspector_id)->name_of_inspector ?? '';
                })->addColumn('created_on', function ($row) {

                    return  date('d/m/Y', strtotime($row->created_at)) ?? '';
                })->addColumn('action', function ($row) {
                    $actionBtn = '
                  
                    <a href=' . route('superadmin.icsuser.farmerDetail', $row->id) . '><span><i class="mdi mdi-eye text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="View Detail"></i></span></a>';

                    return $actionBtn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        return view('admin/ics/farmer-list');
    }

    public function extRiskFormPost(Request $request)
    {
        try {
            $request->validate([
                'reg_no'  => 'required',
                'ics_name' => 'required',
                'size_of_holding' => 'required',
                'no_of_member' => 'required',
                'similarity_between_prod_vs_crop' => 'required',
                'inter_mingling' => 'required',
                'parallel_production' => 'required',
                'split_production' => 'required',
                'local_hazards' => 'required',
                'change_production_plan' => 'required',
                'joining_member' => 'required',
                'risk_type' => 'required',
            ]);
            $data = array(
                'reg_no'  => $request->reg_no,
                'ics_name' => $request->ics_name,
                'size_of_holding' => $request->size_of_holding,
                'no_of_member' => $request->no_of_member,
                'similarity_between_prod_vs_crop' => $request->similarity_between_prod_vs_crop,
                'inter_mingling' => $request->inter_mingling,
                'parallel_production' => $request->parallel_production,
                'split_production' => $request->split_production,
                'local_hazards' => $request->local_hazards,
                'change_production_plan' => $request->change_production_plan,
                'joining_member' => $request->joining_member,
                'risk_type' => $request->risk_type
            );

            if (!empty($request->reg_no)) {
                AtRiskAssessment::updateOrCreate(
                    ['at_user_id' => $request->at_user_id],
                    $data
                );

                User::where('id', $request->at_user_id)->update(['risk_assessment' => 1]);


                Alert::success('Success', __('Data save successfully.'));
                return redirect()->route('superadmin.external.extRiskAssesmentList');
            } else {
                Alert::success('error', 'Something went wrong.');
                return redirect()->back();
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }
    public function approvalPost(Request $request)
    {
        $request->validate([
            'cb_status' => 'required',
            'cb_remarks' => 'required',
        ]);

        try {

            $data = array(
                'cb_status' => $request->cb_status,
                'cb_remarks' =>  $request->cb_remarks ?? '',
            );


            if (!empty($request->fid)) {
                $data['updated_at'] = date('Y-m-d H:i:s');
                $data['updated_by'] = Auth::user()->id;
                AtFarmerRegDetail::where('id', $request->fid)->update($data);

                Alert::success('Success', 'Data save successfully.');
                return redirect()->back();
            } else {
                Alert::success('error', 'Something went wrong.');
                return redirect()->back();
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function inspectionForm($id)
    {
        $regDetail = User::where('id', $id)->first();
        $authsign = User::whereHas('roles', function ($q) {
            return $q->where('title', 'Authorized Signatory');
        })
            ->where('created_by', Auth::id())
            ->get();


        return view('admin/external_approval/inspection-form', compact('regDetail', 'authsign'));
    }

    public function extInspectionPost(Request $request)
    {
        try {

            $request->validate([
                'reg_no'  => 'required',
                'submission_of_inspection' => 'required',
                'inspection_date' => 'required',
                'ins_name' => 'required',
                'ins_contact' => 'required',
                'des_observation.*' => 'required',
                'grade.*' => 'required',
                'date_corrective_action.*' => 'required',
                'remark' => 'required'
            ]);

            $data = array(
                'at_user_id'  => $request->reg_no,
                'submission_of_inspection_report' => $request->submission_of_inspection,
                'inspection_date' => $request->inspection_date,
                'inspector_name' => $request->ins_name,
                'inspector_contact' => $request->ins_contact,
                'created_by' => Auth::user()->id,
                'status' => 0,
                'remark' => $request->remark,

            );

            $res = AtExternalInspection::create($data);

            if ($res) {
                $i = 0;
                foreach ($request->des_observation as $key => $obs) {
                    $data1 = array(
                        'at_external_inspection_id' => $res->id,
                        'description_of_observation' => $obs,
                        'grade' => $request->grade[$i],
                        'corrective_date' => $request->date_corrective_action[$i],
                        'status' => 0,
                        'created_by' => Auth::user()->id,
                        'created_at' => date('Y-m-d'),
                    );
                    AtExternalInspectionObservation::create($data1);
                    $i++;
                }

                User::where('id', $request->reg_no)->update(['external_inspection' => 1]);
                Alert::success('Success', __('Data save successfully.'));
                // return redirect()->route('superadmin.external.extRiskAssesmentList');
                return redirect()->route('superadmin.external.inspectionList');
            } else {
                Alert::success('error', 'Something went wrong.');
                return redirect()->back();
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }


    public function inspectionClosureForm($id)
    {
        $regDetail = User::where('id', $id)->first();
        $inspDetail = AtExternalInspection::with('ObservationDetail')->where('at_user_id', $id)->first();

        return view('admin/external_approval/inspection-closure-form', compact('regDetail', 'inspDetail'));
    }
    public function extInspectionClosurePost(Request $request)
    {
        try {
            $request->validate([
                'closure_date.*' => 'required',
                'closure_remark.*' => 'required',
                'remark' => 'required'
            ]);

            if (count($request->all()) > 1) {
                foreach ($request->rowid as $key => $val) {
                    $data = array(
                        'closure_date' => $request['closure_date'][$key],
                        'closure_remark' => $request['closure_remark'][$key],
                        'status' => 1,
                        'updated_by' => Auth::user()->id,
                        'updated_at' => date('Y-m-d'),
                    );
                    AtExternalInspectionObservation::where('id', $request['rowid'][$key])->update($data);
                }
                AtExternalInspection::where('at_user_id', $request->at_user_id)->update(['closure_remark' => $request->remark]);

                User::where('id', $request->at_user_id)->update(['external_inspection' => 2]);
                Alert::success('Success', __('Data save successfully.'));
                // return redirect()->route('superadmin.external.extRiskAssesmentList');
                return redirect()->route('superadmin.external.inspectionList');
            } else {
                Alert::success('error', 'Something went wrong.');
                return redirect()->back();
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }


    public function viewInspectionList(Request $request)
    {

        //dd($inspIds);
        if ($request->ajax()) {

            $user_id = $request->fid;
            $inspIds = array();

            $inspIds =  UserInspector::select('id')->where('at_user_id', $user_id)->get();

            $totalData =  AtFarmerRegDetail::whereIn('at_ics_inspector_id', $inspIds)->where('inspection_status', 1)->where('approval_flag', 1)->get();

            return Datatables::of($totalData)
                ->addIndexColumn()
                ->addColumn('name', function ($row) {
                    return $row->farmer_first_name ?? '';
                })
                ->addColumn('email', function ($row) {
                    return $row->email_id ?? '';
                })->addColumn('mobile', function ($row) {
                    return $row->mobile_no ?? '';
                })->addColumn('address', function ($row) {

                    return $row->farmer_address ?? '';
                })->addColumn('insp_name', function ($row) {

                    return getInspectorName($row->at_ics_inspector_id)->name_of_inspector ?? '';
                })->addColumn('created_on', function ($row) {

                    return  date('d/m/Y', strtotime($row->created_at)) ?? '';
                })->addColumn('status', function ($row) {
                    if ($row->approval_flag == 1) {
                        return "Approved";
                    }
                    if ($row->cancellation_flag == 1) {
                        return "Rejected";
                    }
                    //return  date('d/m/Y', strtotime($row->created_at))??'' ;
                })->addColumn('action', function ($row) {
                    $actionBtn = '
                  
                    <a href=' . route('superadmin.inspectionDetail',) . '?fid=' . $row->id . '&insid=' . $row->at_ics_inspector_id . '><span><i class="mdi mdi-eye text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="View Detail"></i></span></a>';

                    return $actionBtn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        return view('admin/external_approval/view-inspection-list');
    }






    // external  ------- inspectionList  ------Reports





    public function externalinspectionListReports(Request $request)
    {


        $totalData = DB::table('at_inspection_checklist_individual_farmer')
            // ->rightJoin('at_inspection_checklist_individual_farmer as invfrm', 'invfrm.inspector_id', '=', 'at_user.id')
            // ->select(
            //     'at_user.*',  
            //     DB::raw("CASE WHEN invfrm.operator_id IS NOT NULL THEN 1 ELSE 0 END as invfrm_join")
            // )
            // ->when(!empty($request->status), function ($query) use ($request) {
            //     $query->where('invfrm.operator_id', $request->status); 
            // })
            ->where('operator_id', 3)
            ->get()
            ->toArray();
        $totalData1 = DB::table('at_inspection_checklist_trader')
            // ->rightJoin('at_inspection_checklist_trader as tdr', 'tdr.inspector_id', '=', 'at_user.id')
            // ->select(
            //     'at_user.*',  
            //     DB::raw("CASE WHEN tdr.operator_id IS NOT NULL THEN 1 ELSE 0 END as tdr_join")
            // )
            ->when(!empty($request->status), function ($query) use ($request) {
                $query->where('operator_id', $request->status);
            })
            ->where('operator_id', 5)
            ->get()
            ->toArray();

        $totalData2 = DB::table('at_inspection_checklist_wild_collection_harvest')
            // ->rightJoin('at_inspection_checklist_wild_collection_harvest as wild', 'wild.inspector_id', '=', 'at_user.id')
            // ->select(
            //     'at_user.*',  
            //     DB::raw("CASE WHEN wild.operator_id IS NOT NULL THEN 1 ELSE 0 END as wild_join")
            // )
            ->when(!empty($request->status), function ($query) use ($request) {
                $query->where('operator_id', $request->status);
            })
            ->where('operator_id', 4)
            ->get()
            ->toArray();



        $mergedData = array_merge($totalData, $totalData1, $totalData2);
        $mergedData = array_unique($mergedData, SORT_REGULAR);

        if ($request->ajax()) {
            // WHEN ref_operator_type_id = 2 THEN inspection_status = 1 
            return Datatables::of($mergedData)
                ->addIndexColumn()
                ->addColumn('reg_no', function ($row) {
                    // return '#/'.getRolesTitle($row->ref_operator_type_id).'/'.$row->id??'';

                    if (empty($row->registration_no) || $row->registration_no == 'NULL::character varying') {
                        $m = date('m', strtotime($row->created_at));
                        $y = substr(date('Y', strtotime($row->created_at)), -2);
                        $lst = str_pad($row->id, 5, "0", STR_PAD_LEFT);
                        $st = "ORG/" . $m . $y . "/" . $lst;
                        return $st;
                    } else {
                        return $row->registration_no;
                    }
                })
                // ->addColumn('name', function ($row) {
                //     return $row->first_name ?? '';
                // })
                ->addColumn('operator_type', function ($row) {
                    return getRolesTitle($row->operator_id);
                })
                ->addColumn('action', function ($row) {
                    $actionBtn = '';
                    //$actionBtn .= '<a target="_BLANK" href="#"><span><i class="ri-eye-fill align-bottom text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="View Document"></i>View</span></a>';
                    $actionBtn .= '<a target="_BLANK" href="' . route('superadmin.inspectionReportIdBy', ['id' => $row->id,$row->operator_id]) . '">
                            <span>
                            <i class="ri-eye-fill align-bottom text-muted fs-16 align-middle me-1" 
                                data-toggle="tooltip" 
                                title="View Document"></i>View
                            </span>
                        </a>';

                    return $actionBtn;
                })

                ->rawColumns(['action'])
                ->make(true);
        }
        return view('admin.external_approval.inspection_list_report');
    }

    public function inspectionReportIdBy($id, $opertype)
    {  
         
        $data['atInspectionCheck'] = DB::table('at_inspection_checklist_individual_farmer')->where('id', $id)->first();
        $data['famrmar_detail'] = User::where('created_by',$data['atInspectionCheck']->operator_id)->first();
       


        // $data['inspector_detail'] = User::where('id',$data['famrmar_detail']->inspector_id)->first();
        
        if ($opertype == 2) {
            $data['opertype_label'] = 'GROWER GROUP';
        } elseif ($opertype == 3) {
            $data['opertype_label'] = 'INDIVIDUAL PRODUCER';
        } elseif ($opertype == 4) {
            $data['opertype_label'] = 'WILD HARVESTER';
        } elseif ($opertype == 5) {
            $data['opertype_label'] = 'TRADER';
        } else {
            $data['opertype_label'] = 'Unknown';  
        }
    
       
        $data['opertype'] = $opertype;
        return view('admin.external_approval.IP_Inspection_report',$data );
        // return view('admin.external_approval.trader_Inspection_report',$data);
        
    }
}

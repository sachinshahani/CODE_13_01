<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\CertificateStandardDetail;
use App\Models\AtBatchDetail;
use App\Models\AtInternalStockTransferPackingDetails;
use App\Models\AtOpTransactionVsTransactionProduct;
use App\Models\AtOpTransactionProductSourced;
use App\Models\AtOpTransactionPackingDetails;
use App\Models\AtInternalStockTransfe;
use App\Models\RefPackingMaster;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\AtBatchCreation;
use Yajra\DataTables\DataTables;

class InternalStockTransferController extends Controller
{

    public function applyforinternalstocktransfer()
    {
        $userId = Auth::id();
        $user = User::where('id', $userId)->get();
        $list = CertificateStandardDetail::where('at_user_id', $userId)->get();
        // dd($userId);
        return view('admin/internal_stock_transfer/apply_for_internal_stock', compact('user', 'list'));
    }

    public function pendingforinternalstocktransfer()
    {
        return view('admin/internal_stock_transfer/pending_for_internal_stock');
    }


    public function SearchST(Request $request)
    {
        try {
            // Check if the request is an AJAX request
            if ($request->ajax()) {

                $userId = Auth::id();

                $query = AtInternalStockTransfe::query()
                    ->where('created_by', $userId);

                $finalData = $query->get();
                // dd($finalData);

                // Use DataTables to format the data
                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()
                    ->addColumn('st_no', function ($row) {
                        return $row->transferee_scope_certification_no;
                    })
                    ->addColumn('date_app', function ($row) {
                        return $row->date_of_internal_transfer;
                    })
                    ->addColumn('transfer', function ($row) {
                        return $row->transfer_name;
                    })
                    ->addColumn('transferee', function ($row) {
                        return $row->transferee_name;
                    })
                    ->addColumn('status', function ($row) {
                        return $row->quantity_for_tc;
                    })
                    ->addColumn('days_left', function ($row) {
                        return $row->rem_qty;
                    })
                    ->addColumn('action', function ($row) {

                        return '<a href="' . route('superadmin.viewApplication', $row->id) . '">View Application</a>';
                    })
                    ->rawColumns(['action']);


                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            // Handle exceptions and log errors
            Log::error($e);
            Alert::error('Error', 'Something went wrong, please try again later.');
            return redirect()->back();
        }
    }

    public function listforinternalstocktransfer()
    {

        $tcIssueList = AtInternalStockTransfe::all();

        return view('admin/internal_stock_transfer/list_for_internal_stock', ['tcIssueList' =>  $tcIssueList]);
    }

    // public function AddProduct(Request $request, $id)
    // {
    //     $userId = Auth::id();
    //     $product = AtOpTransactionVsTransactionProduct::where('created_by', $userId)->get();
    //     $batch_details = AtBatchDetail::where('at_user_id', $userId)->get();
    //     //  dd( $batch_details);
    //     return view('admin/internal_stock_transfer/add_product', compact('product', 'data', 'id'));
    // }

    public function AddProduct(Request $request, $id)
    {
        $userId = Auth::id();
       
        //  $data = AtBatchCreation::with('batchDetails')->withsum('batchDetails', 'total_quantity', )->withsum('batchDetails', 'quantity_source', )->withsum('batchDetails', 'available_quantity', )->where('created_by', $userId)->get();

         $data = AtBatchCreation::with('batchDetails')->withsum('batchDetails', 'total_quantity', )->where('created_by', $userId)->get();
        //  dd( $batch_details);
        return view('admin/internal_stock_transfer/add_product', compact('data', 'id'));
    }

    public function saveProduct(Request $request)
    {
        // dd($request->all());
        $data = [

            // 'at_user_id' => $request->at_user_id,
            // 'batch_details_id' => $request->batch_id,
            'qty_in_mt' =>  $request->quantity,
            // 'organic_status' => $request->organic_status,
            'created_by' => Auth::id(),
            'updated_by' => Auth::id(),
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
            // Add more columns as needed
        ];

        $insert = AtOpTransactionProductSourced::create($data);

        return response()->json(['success' => true, 'message' => 'Products added successfully']);
    }

    public function PackingDetail(Request $request, $id)

    {
        $user_id =  Auth::guard('misadmin')->user()->id;
        $packingData = AtOpTransactionVsTransactionProduct::where('created_by', $user_id)->get();

        // dd($packingData);

        return view('admin/internal_stock_transfer/packing_details', compact('id', 'packingData'));
    }

    public function PackingDetailAddUpdate($id)
    {
        // $user_id =  Auth::guard('misadmin')->user()->created_by;
        $packingData = AtOpTransactionVsTransactionProduct::where('id', $id)->get();
        $packingType = RefPackingMaster::all();
        $trans = AtOpTransactionVsTransactionProduct::where('id', $id)->get();


        //  dd($trans);
        return view('admin/internal_stock_transfer/packing_details_addupdate',  compact('packingData', 'packingType', 'trans', 'id'));
    }

    public function PackingDetailSave(Request $request, $id)
    {

        $request->validate([
            // 'ref_product_id' => 'required|integer',
            'ref_packing_master_id' => 'required|integer',
            'no_of_box' => 'required|integer',
            'pack_size' => 'required|numeric',
            'total_qty_in_kg' => 'required|numeric',

        ]);


        $at_user_id = Auth::guard('misadmin')->user()->id;


        $record = new AtOpTransactionPackingDetails();
        // $record->ref_product_id = $request->input('ref_product_id');
        $record->trade_name_of_product =$request->input('trade_name_of_product');
        $record->value_inr =$request->input('value_inr');
        $record->ref_packing_master_id = $request->input('ref_packing_master_id');
        $record->no_of_box = $request->input('no_of_box');
        $record->pack_size = $request->input('pack_size');
        $record->total_qty_in_kg = $request->input('total_qty_in_kg');
        $record->created_by = $at_user_id;
        $record->updated_by = $at_user_id;
       // $record->at_op_transaction_product_sourced_id = $request->input('at_op_transaction_product_sourced_id');
        $record->save();
       // dd($record);


        return redirect()->route('superadmin.InternalStockDetail', $id);
    }

    public function InternalStockDetail($id)
    {
        return view('admin/internal_stock_transfer/internal_stock_details', compact('id'));
    }
    public function InternalStockDetail1($id)
    {
        return view('admin/internal_stock_transfer/internal_stock_details1', compact('id'));
    }

    public function viewApplication($id)
    {

        $user_id = Auth::guard('misadmin')->user()->id;
        $packing = AtOpTransactionPackingDetails::where('created_by', $user_id)->first();
        $st = AtInternalStockTransfe::where('created_by', $user_id)->first();

        // dd($packing );

        return view('admin/internal_stock_transfer/viewApplication', compact('id', 'packing', 'st'));
    }

    public function viewCBApplication($id)
    {

        $user_id = Auth::guard('misadmin')->user()->id;
        $packing = AtOpTransactionPackingDetails::where('id', $id)->get();
        $st = AtInternalStockTransfe::where('id', $id)->first();

        // dd( $st);

        return view('admin/internal_stock_transfer/viewCBApplication', compact('id', 'packing', 'st'));
    }



    // public function InternalStockDetailSave(Request $request, $id)
    // {
    //     // dd($request->all());


    //     // $request->validate([
    //     //     // 'ref_product_id' => 'required|integer',
    //     //     'ref_packing_master_id' => 'required|integer',
    //     //     'no_of_box' => 'required|integer',
    //     //     'pack_size' => 'required|numeric',
    //     //     'total_qty_in_kg' => 'required|numeric',
    //     //     'at_op_transaction_product_sourced_id' => 'required|integer',
    //     // ]);


    //     $at_user_id = Auth::guard('misadmin')->user()->id;


    //     $record = new AtInternalStockTransfe();
    //     // $record->ref_product_id = $request->input('ref_product_id');
    //     $record->producer_name = $request->input('producer_name');
    //     $record->address1 = $request->input('address1');
    //     $record->scope_certification_no = $request->input('scope_certification_no');
    //     $record->seller_id_proof = $request->input('seller_id_proof');
    //     $record->email_id = $request->input('email_id');
    //     $record->address2 = $request->input('address2');
    //     $record->transferee_scope_certification_no = $request->input('transferee_scope_certification_no');
    //     $record->transfer_name = $request->input('transfer_name');
    //     $record->transferee_name = $request->input('transferee_name');
    //     $record->ref_state_id = $request->input('ref_state_id');
    //     $record->transferee_id_proof = $request->input('transferee_id_proof');
    //     $record->transferee_address = $request->input('transferee_address');
    //     $record->transferee_email_id = $request->input('transferee_email_id');
    //     $record->internal_transfer_no = $request->input('internal_transfer_no');
    //     $record->date_of_internal_transfer = $request->input('date_of_internal_transfer');
    //     $record->transfer_value = $request->input('transfer_value');
    //     $record->lot_no = $request->input('lot_no');
    //     $record->marks_and_no = $request->input('marks_and_no');
    //     $record->place_of_dispatch = $request->input('place_of_dispatch');
    //     $record->place_of_destination = $request->input('place_of_destination');
    //     $record->reference_no = $request->input('reference_no');
    //     $record->transportation_mode = $request->input('transportation_mode');
    //     $record->vehicle_no = $request->input('vehicle_no');
    //     $record->transport_document_no = $request->input('transport_document_no');
    //     $record->date_of_transport = $request->input('date_of_transport');
    //     $record->gross_weight = $request->input('gross_weight');
    //     $record->created_by = $at_user_id;
    //     $record->updated_by = $at_user_id;
    //     // $record->at_op_transaction_product_sourced_id = $request->input('at_op_transaction_product_sourced_id');

    //     $record->save();

    //    dd($record);

    //    return redirect()->route('superadmin.InternalStockDetail1', $id);
    // }

    public function InternalStockDetailSave(Request $request, $id)
    {
        // Retrieve the existing record from the database using the provided ID
        $record = AtInternalStockTransfe::find($id);

        // If the record is not found, create a new instance
        if (!$record) {
            $record = new AtInternalStockTransfe();
        }

        // Update or set the record's fields based on the form data
        $record->producer_name = $request->input('producer_name');
        $record->address1 = $request->input('address1');
        $record->scope_certification_no = $request->input('scope_certification_no');
        $record->seller_id_proof = $request->input('seller_id_proof');
        $record->email_id = $request->input('email_id');
        $record->address2 = $request->input('address2');
        $record->transferee_scope_certification_no = $request->input('transferee_scope_certification_no');
        $record->transfer_name = $request->input('transfer_name');
        $record->transferee_name = $request->input('transferee_name');
        $record->ref_state_id = $request->input('ref_state_id');
        $record->transferee_id_proof = $request->input('transferee_id_proof');
        $record->transferee_address = $request->input('transferee_address');
        $record->transferee_email_id = $request->input('transferee_email_id');
        $record->internal_transfer_no = $request->input('internal_transfer_no');
        $record->date_of_internal_transfer = $request->input('date_of_internal_transfer');
        $record->transfer_value = $request->input('transfer_value');
        $record->lot_no = $request->input('lot_no');
        $record->marks_and_no = $request->input('marks_and_no');
        $record->place_of_dispatch = $request->input('place_of_dispatch');
        $record->place_of_destination = $request->input('place_of_destination');
        $record->reference_no = $request->input('reference_no');
        $record->transportation_mode = $request->input('transportation_mode');
        $record->vehicle_no = $request->input('vehicle_no');
        $record->transport_document_no = $request->input('transport_document_no');
        $record->date_of_transport = $request->input('date_of_transport');
        $record->gross_weight = $request->input('gross_weight');

        // Set metadata fields for a new record or an update
        $userId = Auth::guard('misadmin')->user()->id;
        $record->created_by = $record->created_by ?? $userId; // Set created_by only for a new record
        $record->updated_by = $userId; // Always update updated_by

        // Save the record to the database
        $record->save();

        // Redirect back to the appropriate route with the provided ID
        return redirect()->route('superadmin.InternalStockDetail1', $id);
    }



    public function forwadToCb(Request $request)
    {

        return view('admin/internal_stock_transfer/internal_stock_details1');
    }
    public function forwadToCbSave(Request $request)
    {



        return redirect()->route('superadmin.pendingforinternalstocktransfer');
    }
}

<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AtFarmDetails;
use App\Models\CertificateStandardDetail;
use Illuminate\Http\Request;
use App\Services\NotificationService;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Notification;

use App\Notifications\CropWiseAreaIncreaseNotification;
use App\Notifications\CertificationAreaIncreaseNotification;

class NotificationController extends Controller
{
    protected $notificationService;

    public function __construct(NotificationService $notificationService)
    {
        $this->notificationService = $notificationService;
    }

    public function checkCertificationAreaIncrease($cbId, $newAreaValue)
    {
        $cb = User::find(Auth::guard('misadmin')->user());

        $oldArea = $cb->area_certified;
        $percentageIncrease = (($newAreaValue - $oldArea) / $oldArea) * 100;

        if ($percentageIncrease > 20) {
            $this->notificationService->notifySuperAdmins(
                new CertificationAreaIncreaseNotification($cb->name, $percentageIncrease)
            );
        }
    }

    public function notify()
    {
        if ((Auth::guard('misadmin')->user())) {
            $user = User::find(3);
            auth()->user()->notify(new CertificationAreaIncreaseNotification($user));
        }
        dd('done');
    }

    public function index(Request $request)
    {
        return view('admin.notification.index');
    }

    public function notificationsave(Request $request)
    {

       // dd($request->all());
        $user = User::find(3);

        $data = New AtFarmDetails;
        $data->farm_name=$request->farm_name;
        $data->total_area=$request->total_area;

        $data->save();

        Notification::send($user, New CropWiseAreaIncreaseNotification($request->total_area, $request->farm_name ));


    }

    // public function notificationsave(Request $request)
    // {

    //     $user = User::find(3);


    //     $existingData = AtFarmDetails::where('id', 513)->first();


    //     if ($existingData) {
    //         $currentArea = $existingData->total_area;
    //         $newArea = $request->total_area;


    //         $percentageIncrease = (($newArea - $currentArea) / $currentArea) * 100;


    //         if ($percentageIncrease > 20) {

    //             Notification::send($user, new CropWiseAreaIncreaseNotification($newArea, $request->farm_name));
    //         }
    //     }


    //     $data = new AtFarmDetails;
    //     $data->farm_name = $request->farm_name;
    //     $data->total_area = $newArea;

    //     $data->save();
    // }



    public function markAsRead($id)
    {
        $notification = auth()->user()->notifications()->find($id);
        if ($notification) {
            $notification->markAsRead();
        }
        return redirect()->back();
    }
}

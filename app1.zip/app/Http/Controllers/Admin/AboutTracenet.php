<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\RefOperatorType;
use App\Models\Announcement;

class AboutTracenet extends Controller
{

    public function OrganicDivision()
    {

        return view('admin.about.contact');
    }

    public function TechnicalSupport()
    {

        return view('admin.about.TechnicalSupport');
    }
    public function Announcement()
    {
        $operators = RefOperatorType::whereIn('id', [2,3,4,5,6])->orderby('id', 'asc')->get();
        $announcements = Announcement::orderBy('created_at', 'desc')->get();


      //  dd($operators);

        return view('admin.about.Announcements', compact('operators', 'announcements'));
    }

    public function Announcementstore(Request $request)
    {
        $request->validate([
            'type' => 'required',
            'title' => 'required',
            'content' => 'required',
            'published_date' => 'required',
            'related_link' => 'required',
           
        ]);
       
        ///contact photo
        if (!empty($request->file('attachment'))) {
            if (!empty($request->contact_photo_edit)) {
                $imagePath = public_path('attachment/attachment/') . $request->contact_photo_edit;
                deleteOldImage($request->contact_photo_edit, $imagePath);
            }
            $documentRootPath = 'public/attachment/attachment/';
            $file_path = time() . rand() . '.' . $request->file('attachment')->getClientOriginalExtension();
            $request->file('attachment')->move($documentRootPath, $file_path);
            $contact_photo = $file_path;
        } else {
            if (!empty($request->contact_photo_edit))
                $contact_photo = $request->contact_photo_edit;
        }

    
        $data = array(
            'ref_operator_type_id' => $request->ref_operator_type_id,
            'type' => $request->type,
            'title' => $request->title,
            'content' => $request->content,
            'published_date' => $request->published_date,
            'related_link' => $request->related_link,
            'attachment' => $contact_photo
           
        );

       // dd($request->all(), $data);
        //dd($data);
        $user = Announcement::create($data);
        return redirect()->back()->with('success', 'Announcement Create Successfully.');
    }
    
}

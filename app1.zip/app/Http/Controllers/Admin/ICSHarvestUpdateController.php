<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Permission;
use App\Models\Role;
use App\Models\RoleUser;
use App\Models\User;
use App\Models\UserSelf;
use App\Models\UserInspector;
use App\Models\UserWarehouse;
use App\Models\UserWarehouseManagerOfficers;
use App\Models\RefState;
use App\Models\RefDistrict;
use App\Models\RefVillage;
use App\Models\RefRegion;
use App\Models\AtFarmerRegDetail;
use App\Models\AtFarmDetails;
use App\Models\RefBank;
use App\Models\AtClosingStock;

use App\Models\AtFarmerStandingCorpDetail;
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;

class ICSHarvestUpdateController extends Controller
{

	public function updateIcsActualYield(Request $request)
    {
        $user_id = Auth::guard('misadmin')->user()->id;
        return view('admin.harvest_update.ics.update_actual_yield');
    }


	public function updateIcsActualYieldScope(Request $request){

		$user_id = Auth::guard('misadmin')->user()->id;
		$harvester = User::find(Auth::guard('misadmin')->user()->id);
		$FarmerRegDetail = AtFarmerRegDetail::where('at_user_id',$user_id)->get();
		//dd($FarmerRegDetail);
		return view('admin.harvest_update.ics.update_actual_yield_scope',compact('harvester','FarmerRegDetail'));
	}


	public function updateIcsActualYieldFarmsdetails(Request $request,$id){

		$user_id = Auth::guard('misadmin')->user()->id;
		$harvester = User::find(Auth::guard('misadmin')->user()->id);
		$FarmerRegDetail = AtFarmerRegDetail::where('at_user_id',$user_id)->first();
		$farm_details = AtFarmDetails::where('at_farmer_reg_details_id',$id)->get();
		// dd($farm_details);
		return view('admin.harvest_update.ics.update_actual_yield_farmsdetails',compact('id','FarmerRegDetail','harvester','farm_details'));
	}



	public function updateIcsActualYieldProducts(Request $request,$id,$farm_id){
		$user_id = Auth::guard('misadmin')->user()->id;
		$harvester = User::find(Auth::guard('misadmin')->user()->id);
		$FarmerRegDetail = AtFarmerRegDetail::where('at_user_id',$user_id)->first();
		$farm_details = AtFarmDetails::where('at_farmer_reg_details_id',$id)->first();

		$product_details = AtFarmerStandingCorpDetail::where('at_farm_details_id',$farm_id)->get();
		return view('admin.harvest_update.ics.update_actual_yield_products',compact('id','farm_id','FarmerRegDetail','harvester','farm_details','product_details'));
	}


	 public function editIcsHarvestProduct(Request $request)
		{

				$product_detail = AtFarmerStandingCorpDetail::where('id',$request->product_id)->first();

			return  view('admin.harvest_update.ics.tpl_edit_product',compact('product_detail'))->render();
		}

	public function storeIcsHarvestProduct(Request $request)
	{
		
		$validator = \Validator::make($request->all(), [
            'actual_yield' => 'required',
            'harvest_date' => 'required',
            'sowing_date' => 'required',
            'product_id' => 'required',
        ]);

        if ($validator->fails())
        {
            return response()->json(['errors'=>$validator->errors()->all()]);
        }

		try {
			
			$insertData = array(
				'actual_yield' =>  $request->actual_yield,
				'harvest_date' => date('Y-m-d',strtotime($request->harvest_date)),
				'sowing_date' => date('Y-m-d',strtotime($request->sowing_date)),
				'updated_at' => date('Y-m-d H:i:s'),
				'updated_by' => Auth::guard('misadmin')->user()->id,
			);

			AtFarmerStandingCorpDetail::where('id',$request->product_id)->update($insertData);
			$input_approval = AtFarmerStandingCorpDetail::where('id',$request->product_id)->first();

			$insert_closing_stock = array(
				'at_farmer_standing_crop_details_id' => $input_approval->id,
				'ref_operator_type_id' => Auth::guard('misadmin')->user()->ref_operator_type_id,
				'at_user_id' => Auth::guard('misadmin')->user()->id,
				'organic_status' => $input_approval->organic_status,
				'ref_product_id' => $request->product_id,
				'date_of_harvest' => date('Y-m-d',strtotime($input_approval->harvest_date)),
				'harvest_year' => date('Y'),
			);
			//dd($insert_closing_stock);
			$result = AtClosingStock::create($insert_closing_stock);
			
			if(!empty($result)){
				return response()->json(['status'=>1,'data'=>$input_approval,'msg'=>'Data is successfully added.']);
			}else{
				return response()->json(['status'=>2,'data'=>$input_approval,'msg'=>'Something went wrong.']);
			}
			

		} catch (Exception $e) {
            Log::error($e->getMessage());
           // abort('404');
        }
	}



}





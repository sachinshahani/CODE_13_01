<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Permission;
use App\Models\Role;
use App\Models\RoleUser;
use App\Models\User;
use App\Models\UserSelf;
use App\Models\UserInspector;
use App\Models\UserWarehouse;
use App\Models\UserWarehouseManagerOfficers;
use App\Models\RefState;
use App\Models\RefDistrict;
use App\Models\RefVillage;
use App\Models\RefRegion;
use App\Models\ProcessorBasicDetail;
use App\Models\WildHarvesterBankDetail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;
use Validator;
use Yajra\DataTables\DataTables;
use App\Models\GeoTaggingProcessorDetail;
use App\Models\ProcessorProductDetail;
use App\Models\ProcessorDocument;
use App\Models\AtProProductsDetails;
use App\Models\BatchCreation;
use App\Models\AtBatchDetail;
use App\Models\SourceDetails;
use App\Models\AtTcDetails;
use App\Models\CertificateStandardDetail;
use App\Models\AtOpTransactionVsTransactionProduct;
use App\Models\RefProduct;

use DB;

use function Ramsey\Uuid\v1;

class ProcessorUserController extends Controller
{
    //

    public function processorDeptUserEdit(Request $request, $user_id)
    {
        try {
            $userdetails = User::find($user_id);
            //dd($userdetails);
            //$bankDetail = RefBank::get();
            return view('admin/processor/proessorDetail', compact('userdetails'));
        } catch (Exception $e) {
            return redirect()->back();
        } catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
            return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
        }
    }

    public function processorEditStepSave(Request $request, $user_id)
    {
        try {

            $request->validate([
                // 'date_of_registration' => 'required',
               // 'processor_first_name' => 'required',
                //'processor_photo' => 'required',
                // 'processor_state_id' => 'required',
                // 'processor_district_id' => 'required',
                // 'processor_block_tehsil_id' => 'required',
                // 'processor_village_id' => 'required',
                // 'processor_pin' => 'required|numeric|digits:6',
                // 'processor_address' => 'required',

            ]);

            if ($request->hasFile('processor_photo')) {
                if (!empty($request->processor_photo_edit)) {
                    $imagePath = public_path('processor_photo/') . $request->processor_photo_edit;
                    deleteOldImage($request->processor_photo_edit, $imagePath);
                }
                $documentRootPath = 'public/processor_photo';
                $file_path = time() . rand() . '.' . $request->file('processor_photo')->getClientOriginalExtension();
                $request->file('processor_photo')->move($documentRootPath, $file_path);
                $processor_photo = $file_path;
            } else {
                $processor_photo = $request->processor_photo_edit;
            }

            if ($request->hasFile('contact_person_photo')) {
                if (!empty($request->contact_person_photo_edit)) {
                    $imagePath = public_path('contact_person_photo/') . $request->contact_person_photo_edit;
                    deleteOldImage($request->contact_person_photo_edit, $imagePath);
                }
                $documentRootPath = 'public/contact_person_photo';
                $file_path = time() . rand() . '.' . $request->file('contact_person_photo')->getClientOriginalExtension();
                $request->file('contact_person_photo')->move($documentRootPath, $file_path);
                $contact_person_photo = $file_path;
            } else {
                $contact_person_photo = $request->contact_person_photo_edit;
            }

            $user = User::find($user_id);
            $user->date_of_registration = date('Y-m-d', strtotime($request->date_of_registration));
        //     $user->first_name = $request->processor_first_name;
        //     $user->processor_photo = $processor_photo;
        //     $user->processor_state_id = $request->processor_state_id;
        //     $user->processor_district_id = $request->processor_district_id;
        //     $user->processor_block_tehsil_id = $request->processor_block_tehsil_id;
        //     $user->processor_village_id = $request->processor_village_id;
        //     $user->processor_pin = $request->processor_pin;
        //     $user->processor_address = $request->processor_address;
        //     $user->contact_person_first_name = $request->contact_person_first_name;
        //     $user->contact_person_middle_name = $request->contact_person_middle_name;
        //     $user->contact_person_last_name = $request->contact_person_last_name;
        //     $user->contact_person_gender = $request->contact_person_gender;
        //     $user->contact_person_mobile_number = $request->contact_person_mobile;
        //     $user->contact_person_pan_number = $request->pan_number;
        //    // $user->contact_person_aadhar_number = $request->contact_person_aadhar_number;
        //     $user->contact_person_photo = $contact_person_photo;
        //     $user->contact_person_email = $request->contact_person_email;
        //     $user->ref_state_id = $request->ref_state_id;
        //     $user->ref_district_id = $request->ref_district_id;
        //     $user->ref_block_tehsil_id = $request->ref_block_tehsil_id;
        //     $user->ref_village_id = $request->ref_village_id;
        //     $user->pin = $request->pin;
        //     $user->address = $request->address;


        if (!empty($request->processor_first_name)) {
            $user->first_name = $request->processor_first_name;
        }
        if (!empty($processor_photo)) {
            $user->processor_photo = $processor_photo;
        }
        if (!empty($request->processor_state_id)) {
            $user->processor_state_id = $request->processor_state_id;
        }
        if (!empty($request->processor_district_id)) {
            $user->processor_district_id = $request->processor_district_id;
        }
        if (!empty($request->processor_block_tehsil_id)) {
            $user->processor_block_tehsil_id = $request->processor_block_tehsil_id;
        }
        if (!empty($request->processor_village_id)) {
            $user->processor_village_id = $request->processor_village_id;
        }
        if (!empty($request->processor_pin)) {
            $user->processor_pin = $request->processor_pin;
        }
        if (!empty($request->processor_address)) {
            $user->processor_address = $request->processor_address;
        }
        if (!empty($request->contact_person_first_name)) {
            $user->contact_person_first_name = $request->contact_person_first_name;
        }
        if (!empty($request->contact_person_middle_name)) {
            $user->contact_person_middle_name = $request->contact_person_middle_name;
        }
        if (!empty($request->contact_person_last_name)) {
            $user->contact_person_last_name = $request->contact_person_last_name;
        }
        if (!empty($request->contact_person_gender)) {
            $user->contact_person_gender = $request->contact_person_gender;
        }
        if (!empty($request->contact_person_mobile)) {
            $user->contact_person_mobile_number = $request->contact_person_mobile;
        }
        if (!empty($request->pan_number)) {
            $user->contact_person_pan_number = $request->pan_number;
        }
        // if (!empty($request->contact_person_aadhar_number)) {
        //     $user->contact_person_aadhar_number = $request->contact_person_aadhar_number;
        // }
        if (!empty($contact_person_photo)) {
            $user->contact_person_photo = $contact_person_photo;
        }
        if (!empty($request->contact_person_email)) {
            $user->contact_person_email = $request->contact_person_email;
        }
        if (!empty($request->ref_state_id)) {
            $user->ref_state_id = $request->ref_state_id;
        }
        if (!empty($request->ref_district_id)) {
            $user->ref_district_id = $request->ref_district_id;
        }
        if (!empty($request->ref_block_tehsil_id)) {
            $user->ref_block_tehsil_id = $request->ref_block_tehsil_id;
        }
        if (!empty($request->ref_village_id)) {
            $user->ref_village_id = $request->ref_village_id;
        }
        if (!empty($request->pin)) {
            $user->pin = $request->pin;
        }
        if (!empty($request->address)) {
            $user->address = $request->address;
        }

            $user->save();

            if (isset($user)) {

                $newUser = WildHarvesterBankDetail::updateOrCreate([
                    'at_user_id'   => $user_id,
                ], [
                    'at_user_id'   => $user_id,
                    'ref_operator_type_id'   => 6,
                    'ref_bank_id' => !empty($request->ref_bank_id) ? $request->ref_bank_id : Null,
                    'account_number' => !empty($request->account_number) ? $request->account_number : Null,
                    'ifsc_code' => !empty($request->ifsc_code) ? $request->ifsc_code : Null,
                    'branch_name' => !empty($request->branch_name) ? $request->branch_name : Null,
                    'bank_address' => !empty($request->bank_address) ? $request->bank_address : Null,
                    'pincode' => !empty($request->pincode) ? $request->pincode : Null,

                ]);
            }

            //pr($request->all());

            //return redirect()->route('superadmin.processorUseredit.step1',$user_id);
            Alert::success('Success', 'Record updated Successfully.');
            return redirect()->route('superadmin.processorUseredit.step1', $user_id);
        } catch (Exception $e) {
            return redirect()->back();
        } catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
            return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
        }
    }

    public function processorEditStep1(Request $request, $user_id)
    {
        try {

            $userdetails = User::with('GeoTaggingProcessorDetail')->find($user_id);
            $GeoTaggingProcessorDetails = $userdetails->GeoTaggingProcessorDetail;

            //$states = RefState::orderBy('state_name','ASC')->get();
            //$districts = RefDistrict::where('ref_state_code',$userdetails->state)->orderBy('district_name','ASC')->get();

            //$regions = RefRegion::where('state_code',$userdetails->state)->orderBy('region_name','ASC')->get();
            //$villages = RefVillage::where('ref_district_code',$userdetails->district)->orderBy('village_name','ASC')->get();

            return view('admin/processor/geo_tagging_processor_detail', compact('userdetails', 'GeoTaggingProcessorDetails'));
        } catch (Exception $e) {
            return redirect()->back();
        } catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
            return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
        }
    }



    public function processorEditStep1Save(Request $request, $user_id)
    {
        try {
            //dd($request->all());
            $request->validate([
                'number_of_processing_unit' => 'required',
                'processing_unit_id' => 'required|array|',
                'processing_units_name' => 'required|array|',
                'fssai_license_number' => 'required|array|',
                'license_validity_from' => 'required|array|',
                // 'license_validity_to' => 'required|array|',
                'agreement_status' => 'required|array|',
                'number_of_product' => 'required|array|',
                'geo_tagging_processing_unit' => 'required|array|',
                'total_capacity' => 'required|array|',
                'installed_capacity_under_organic' => 'required|array|',

            ]);

            foreach ($request->processing_unit_id as $key => $processing_unit_id) {

                $license_document = $additional_certificate = $image_after_tagging = $processing_unit_image = '';
                if (!empty($request->file('license_document')[$key])) {
                    if (!empty($request->license_document_edit[$key])) {
                        $imagePath = public_path('processor/license_document/') . $request->license_document[$key];
                        deleteOldImage($request->license_document_edit[$key], $imagePath);
                    }
                    $documentRootPath = 'public/processor/license_document';
                    $file_path = time() . rand() . '.' . $request->file('license_document')[$key]->getClientOriginalExtension();
                    $request->file('license_document')[$key]->move($documentRootPath, $file_path);
                    $license_document = $file_path;
                } else {
                    if (!empty($request->license_document_edit[$key]))
                        $license_document = $request->license_document_edit[$key];
                }



                if (!empty($request->file('additional_certificate')[$key])) {
                    if (!empty($request->additional_certificate_edit[$key])) {
                        $imagePath = public_path('processor/additional_certificate/') . $request->additional_certificate[$key];
                        deleteOldImage($request->additional_certificate_edit[$key], $imagePath);
                    }
                    $documentRootPath = 'public/processor/additional_certificate';
                    $file_path = time() . rand() . '.' . $request->file('additional_certificate')[$key]->getClientOriginalExtension();
                    $request->file('additional_certificate')[$key]->move($documentRootPath, $file_path);
                    $additional_certificate = $file_path;
                } else {
                    if (!empty($request->additional_certificate_edit[$key]))
                        $additional_certificate = $request->additional_certificate_edit[$key];
                }

                if (!empty($request->file('image_after_tagging')[$key])) {
                    if (!empty($request->image_after_tagging_edit[$key])) {
                        $imagePath = public_path('processor/image_after_tagging/') . $request->image_after_tagging[$key];
                        deleteOldImage($request->image_after_tagging_edit[$key], $imagePath);
                    }
                    $documentRootPath = 'public/processor/image_after_tagging';
                    $file_path = time() . rand() . '.' . $request->file('image_after_tagging')[$key]->getClientOriginalExtension();
                    $request->file('image_after_tagging')[$key]->move($documentRootPath, $file_path);
                    $image_after_tagging = $file_path;
                } else {
                    if (!empty($request->image_after_tagging_edit[$key]))
                        $image_after_tagging = $request->image_after_tagging_edit[$key];
                }
                if (!empty($request->file('processing_unit_image')[$key])) {
                    if (!empty($request->processing_unit_image_edit[$key])) {
                        $imagePath = public_path('processor/processing_unit_image/') . $request->processing_unit_image[$key];
                        deleteOldImage($request->processing_unit_image_edit[$key], $imagePath);
                    }
                    $documentRootPath = 'public/processor/processing_unit_image';
                    $file_path = time() . rand() . '.' . $request->file('processing_unit_image')[$key]->getClientOriginalExtension();
                    $request->file('processing_unit_image')[$key]->move($documentRootPath, $file_path);
                    $processing_unit_image = $file_path;
                } else {
                    if (!empty($request->processing_unit_image_edit[$key]))
                        $processing_unit_image = $request->processing_unit_image_edit[$key];
                }

                $st = 'NA';
                $us = User::select('created_at', 'id')->where('id', $user_id)->where('status', 0)->first();
                if ($us) {
                    $m = date('m', strtotime($us->created_at));
                    $y = substr(date('Y', strtotime($us->created_at)), -2);
                    $lst = str_pad($us->id, 0, "0", STR_PAD_LEFT);
                    $st = "ORG/PR/" . $y . $m . "/" . $lst;
                }

                $data = array(
                    'number_of_processing_unit' => !empty($request->number_of_processing_unit) ? $request->number_of_processing_unit : null,
                    'at_user_id' => $user_id,
                    'processing_unit_id' => !empty($st) ? $st : null,
                    'processing_units_name' => !empty($request->processing_units_name[$key]) ? $request->processing_units_name[$key] : null,
                    'fssai_license_number' => !empty($request->fssai_license_number[$key]) ? $request->fssai_license_number[$key] : null,
                    'license_validity_from' => !empty($request->license_validity_from[$key]) ? date('Y-m-d', strtotime($request->license_validity_from[$key])) : null,
                    'license_validity_to' => !empty($request->license_validity[$key]) ? date('Y-m-d', strtotime($request->license_validity[$key])) : null,
                    'no_of_processing_lines' => !empty($request->no_of_processing_lines[$key]) ? $request->no_of_processing_lines[$key] : null,
                    'address' => !empty($request->address[$key]) ? $request->address[$key] : null,
                    'agreement_status' => !empty($request->agreement_status[$key]) ? $request->agreement_status[$key] : null,
                    'number_of_product' => !empty($request->number_of_product[$key]) ? $request->number_of_product[$key] : null,
                    'geo_tagging_processing_unit' => !empty($request->geo_tagging_processing_unit[$key]) ? $request->geo_tagging_processing_unit[$key] : null,
                    'total_capacity' => !empty($request->total_capacity[$key]) ? $request->total_capacity[$key] : null,
                    'installed_capacity_under_organic' => !empty($request->installed_capacity_under_organic[$key]) ? $request->installed_capacity_under_organic[$key] : null,
                    'license_document' => !empty($license_document) ? $license_document : null,
                    'additional_certificate' => !empty($additional_certificate) ? $additional_certificate : null,
                    'reflect_farm' => !empty($request->reflect_farm[$key]) ? $request->reflect_farm[$key] : null,
                    'image_after_tagging' => !empty($image_after_tagging) ? $image_after_tagging : null,
                    'daily_processing_capacity' => !empty($request->daily_processing_capacity[$key]) ? $request->daily_processing_capacity[$key] : null,
                    'processing_type' => !empty($request->processing_type[$key]) ? $request->processing_type[$key] : null,
                    'processing_unit_image' => !empty($processing_unit_image) ? $processing_unit_image : null,
                );
                
                if (!empty($request->row_id[$key])) {
                    $data['updated_at'] = date('Y-m-d H:i:s');
                    $data['updated_by'] = Auth::guard('misadmin')->user()->id;
                    GeoTaggingProcessorDetail::where('id', $request->row_id[$key])->where('at_user_id', $user_id)->update($data);
                } else {
                    $data['created_by'] = Auth::guard('misadmin')->user()->id;
                    $data['created_at'] = date('Y-m-d H:i:s');
                    GeoTaggingProcessorDetail::create($data);
                }
                
            }


            Alert::success('Success', 'Record updated Successfully.');
            return redirect()->route('superadmin.processorUseredit.step2', $user_id);
        } catch (Exception $e) {
            return redirect()->back();
        } catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
            return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
        }
    }

    public function processorEditStep2(Request $request, $user_id)
    {

        try {

            $userdetails = User::with('ProcessorProductDetails')->find($user_id);
            $processor_product_details = $userdetails->ProcessorProductDetails;
            $auth =  Auth::guard('misadmin')->user()->created_by;
            $cbID =  User::where('id',$auth)->first();
        
            return view('admin/processor/product_detail', compact('userdetails', 'processor_product_details','cbID'));
        } catch (Exception $e) {
            return redirect()->back();
        } catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
            return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
        }
    }


    public function processorEditStep2Save(Request $request, $user_id)
    {
        //dd(123);
        try {

            $request->validate([
                'processing_unit_id' => 'required|array|',
                'ref_hscode_id' => 'required|array|',
                'product_description' => 'required|array|',
                'ref_product_id' => 'required|array|',
                'product_processor_name' => 'required|array|',
                'organic_status' => 'required|array|',
                //'product_image' => 'required|array|',
            ]);

            foreach ($request->processing_unit_id as $key => $processing_unit_id) {
                $product_photo = $aadhar_card = $pan_card = $bank_copy_passbook =  $contact_person_sign_thumb_Impression = $live_signature_thumb_impression = '';
                if (!empty($request->file('product_image')[$key])) {
                    if (!empty($request->product_image_edit[$key])) {
                        $imagePath = public_path('processor/product_photo/') . $request->product_image[$key];
                        deleteOldImage($request->product_image_edit[$key], $imagePath);
                    }
                    $documentRootPath = 'public/processor/product_photo';
                    $file_path = time() . rand() . '.' . $request->file('product_image')[$key]->getClientOriginalExtension();
                    $request->file('product_image')[$key]->move($documentRootPath, $file_path);
                    $product_photo = $file_path;
                } else {
                    if (!empty($request->product_image_edit[$key]))
                        $product_photo = $request->product_image_edit[$key];
                }



                $data = array(
                    'at_user_id' => $user_id,
                    'processing_unit_id' => $request->processing_unit_id[$key],
                    'ref_hscode_id' => $request->ref_hscode_id[$key],
                    'product_description' => $request->product_description[$key],
                    'ref_product_id' => $request->ref_product_id[$key],
                    'product_processor_name' => $request->product_processor_name[$key],
                    'organic_status' => $request->organic_status[$key],
                    'product_image' => $product_photo,
                );

                if (!empty($request->row_id[$key])) {
                    $data['updated_at'] = date('Y-m-d H:i:s');
                    $data['updated_by'] = Auth::guard('misadmin')->user()->id;
                    ProcessorProductDetail::where('id', $request->row_id[$key])->where('at_user_id', $user_id)->update($data);
                } else {
                    $data['created_by'] = Auth::guard('misadmin')->user()->id;
                    $data['created_at'] = date('Y-m-d H:i:s');
                    ProcessorProductDetail::create($data);
                }
            }

            Alert::success('Success', 'Record updated Successfully.');
            return redirect()->route('superadmin.processorUseredit.step3', $user_id);
        } catch (Exception $e) {
            return redirect()->back();
        } catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
            return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
        }
    }

    public function processorEditStep3(Request $request, $user_id)
    {
        try {
            //dd($user_id);
            $userdetails = User::with('ProcessorDocuments')->find($user_id);
            $processor_document = $userdetails->ProcessorDocuments;
            return view('admin/processor/list_of_document', compact('userdetails', 'processor_document'));
        } catch (Exception $e) {
            return redirect()->back();
        } catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
            return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
        }
    }

    public function processorEditFinalSave(Request $request, $user_id)
    {
        try {

            if (empty($request->row_id)) {
                $request->validate([
                    // 'aadhar_card_image_path' => 'required',
                    // 'pan_card_image_path' => 'required',
                    // 'passbook_image_path' => 'required',
                    // 'contact_person_sign_image_path' => 'required',
                    // 'live_signature_image_path' => 'required',
                ]);
            }

            $product_photo = $aadhar_card = $pan_card = $bank_copy_passbook =  $contact_person_sign_thumb_Impression = $live_signature_thumb_impression = '';


            if (!empty($request->file('aadhar_card_image_path'))) {
                if (!empty($request->aadhar_card_image_path_edit)) {
                    $imagePath = public_path('processor/documents/aadhar_card/') . $request->aadhar_card_image_path;
                    deleteOldImage($request->aadhar_card_image_path_edit, $imagePath);
                }
                $documentRootPath = 'public/processor/documents/aadhar_card';
                $file_path = time() . rand() . '.' . $request->file('aadhar_card_image_path')->getClientOriginalExtension();
                $request->file('aadhar_card_image_path')->move($documentRootPath, $file_path);
                $aadhar_card = $file_path;
            } else {
                if (!empty($request->aadhar_card_image_path_edit))
                    $aadhar_card = $request->aadhar_card_image_path_edit;
            }

            if (!empty($request->file('pan_card_image_path'))) {
                if (!empty($request->pan_card_image_path_edit)) {
                    $imagePath = public_path('processor/documents/pan_card/') . $request->pan_card_image_path;
                    deleteOldImage($request->pan_card_image_path_edit, $imagePath);
                }
                $documentRootPath = 'public/processor/documents/pan_card';
                $file_path = time() . rand() . '.' . $request->file('pan_card_image_path')->getClientOriginalExtension();
                $request->file('pan_card_image_path')->move($documentRootPath, $file_path);
                $pan_card = $file_path;
            } else {
                if (!empty($request->pan_card_image_path_edit))
                    $pan_card = $request->pan_card_image_path_edit;
            }

            if (!empty($request->file('passbook_image_path'))) {
                if (!empty($request->passbook_image_path_edit)) {
                    $imagePath = public_path('processor/documents/bank_copy_passbook/') . $request->passbook_image_path;
                    deleteOldImage($request->passbook_image_path_edit, $imagePath);
                }
                $documentRootPath = 'public/processor/documents/bank_copy_passbook';
                $file_path = time() . rand() . '.' . $request->file('passbook_image_path')->getClientOriginalExtension();
                $request->file('passbook_image_path')->move($documentRootPath, $file_path);
                $bank_copy_passbook = $file_path;
            } else {
                if (!empty($request->passbook_image_path_edit))
                    $bank_copy_passbook = $request->passbook_image_path_edit;
            }

            if (!empty($request->file('contact_person_sign_image_path'))) {
                if (!empty($request->contact_person_sign_image_path_edit)) {
                    $imagePath = public_path('processor/documents/contact_person_sign_thumb_impression/') . $request->contact_person_sign_image_path;
                    deleteOldImage($request->contact_person_sign_image_path_edit, $imagePath);
                }
                $documentRootPath = 'public/processor/documents/contact_person_sign_thumb_impression';
                $file_path = time() . rand() . '.' . $request->file('contact_person_sign_image_path')->getClientOriginalExtension();
                $request->file('contact_person_sign_image_path')->move($documentRootPath, $file_path);
                $contact_person_sign_thumb_Impression = $file_path;
            } else {
                if (!empty($request->contact_person_sign_image_path_edit))
                    $contact_person_sign_thumb_Impression = $request->contact_person_sign_image_path_edit;
            }


            if (!empty($request->file('live_signature_image_path'))) {
                if (!empty($request->live_signature_image_path_edit)) {
                    $imagePath = public_path('processor/documents/live_signature_thumb_impression/') . $request->live_signature_image_path;
                    deleteOldImage($request->live_signature_image_path_edit, $imagePath);
                }
                $documentRootPath = 'public/processor/documents/live_signature_thumb_impression';
                $file_path = time() . rand() . '.' . $request->file('live_signature_image_path')->getClientOriginalExtension();
                $request->file('live_signature_image_path')->move($documentRootPath, $file_path);
                $live_signature_thumb_impression = $file_path;
            } else {
                if (!empty($request->live_signature_image_path_edit))
                    $live_signature_thumb_impression = $request->live_signature_image_path_edit;
            }


            $data = array(
                'at_user_id' => $user_id,
                'aadhar_card_image_path' => $aadhar_card,
                'pan_card_image_path' => $pan_card,
                'passbook_image_path' => $bank_copy_passbook,
                'contact_person_sign_image_path' => $contact_person_sign_thumb_Impression,
                'live_signature_image_path' => $live_signature_thumb_impression,

            );

            $processor_document = ProcessorDocument::find($request->row_id);

            if (!empty($processor_document)) {
                $data['updated_at'] = date('Y-m-d H:i:s');
                $data['updated_by'] = Auth::guard('misadmin')->user()->id;
                $processor_document->where('id', $request->row_id)->where('at_user_id', $user_id)->update($data);
            } else {
                $data['created_by'] = Auth::guard('misadmin')->user()->id;
                $data['created_at'] = date('Y-m-d H:i:s');
                ProcessorDocument::create($data);
            }


            Alert::success('Success', 'Record updated Successfully.');

            return redirect()->route('superadmin.usermanagement.deptUser.proview', $user_id);
        } catch (Exception $e) {
            return redirect()->back();
        } catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
            return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
        }
    }



    public function deptUserDelete(Request $request)
    {
        try {
            $id = $request->id;
            $user = User::find($id);
            $user->is_deleted = 1;
            $user->deleted_at = date('Y-m-d H:i:s');
            $user->save();


            return json_encode(['message' => 'done']);
        } catch (Exception $e) {
            return redirect()->back();
        } catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
            return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
        }
    }
    public function storeMedia(Request $request)
    {

        /*$validator = Validator::make($request->all(), [
                'file' => 'required|mimes:jpeg,jpg,png,pdf,doc,gif,docx,mp4,uvu,mp4s,avi
                          |mimetypes:image/jpeg,image/jpg,image/png,application/pdf,application/msword,image/gif,
                          application/vnd.openxmlformats-officedocument.wordprocessingml.document,video/vnd.uvvu.mp4,
                          application/mp4,video/mp4,video/x-msvideo',
        ]);

        if($validator->fails()){
                return Response::make($validator->errors()->first(), 400);
            }*/

        try {
            $path = 'public/research/uploads';
            if (!file_exists($path)) {
                mkdir($path, 0777, true);
            }

            $file = $request->file('file');
            $name = uniqid() . '_' . trim($file->getClientOriginalName());

            /*Custom Validation Vikash Chaudhary 17/11/2020*/

            $file_name = (isset($_FILES['file']['name']) && !empty($_FILES['file']['name'])) ? $_FILES['file']['name'] : "";
            $file_tmp_name = (isset($_FILES['file']['tmp_name']) && !empty($_FILES['file']['tmp_name'])) ? $_FILES['file']['tmp_name'] : "";

            $mime = $file->getMimeType();

            $file_array = array(
                'file_name' => $file_name,
                'file_tmp_name' => $file_tmp_name,
                'file_mime_type' => $mime,
            );
            $data = getimagesize($file_tmp_name);
            if ($data != false) {
                $width = $data[0];
                $height = $data[1];
            } else {
                $width = '';
                $height = '';
            }

            // $checkFileUpload = checkUploadFileContent($file_array);


            // if (!empty($checkFileUpload)) {
            //     if (isset($checkFileUpload['error']) && $checkFileUpload['error'] == 1) {
            //         return Response::make($checkFileUpload['message'], 400);
            //     }
            // }

            $file->move($path, $name);

            if (in_array($file->getClientOriginalExtension(), ['pdf', 'png', 'jpg', 'jpeg', 'PNG', 'JPG', 'JPEG', 'mp4', 'MP4'])) {
                $image = str_replace(asset('/'), '', $path . '/' . $name);
                $path = $path . '/' . $name;
                $image = str_replace('', '_', urldecode($image));

                $image = explode('/', $image);
                $name = end($image);

                # Generate thumbs of the images

                # Check image size
                if ($width != '') {
                    // $this->createThumb($path, $width, $height, str_replace('', '_', $name), false);
                }
                // slider
                // $this->createThumb($path, 378, 194, 'thumb_378X194_' . str_replace('', '_', $name), true); //campaign home page slider
                // $this->createThumb($path, 75, 76, 'thumb_511X341_' . str_replace('', '_', $name), true); //blog page slider home page
                // $this->createThumb($path, 931, 214, 'thumb_931X214_' . str_replace('', '_', $name), true); //Blog Page Details page
                // $this->createThumb($path, 511, 341, 'thumb_511X341_' . str_replace('', '_', $name), true); // Blog Listing Page
                // $this->createThumb($path, 267, 183, 'thumb_267X183_' . str_replace('', '_', $name), true); // Event Home page slider
                // $this->createThumb($path, 261, 251, 'thumb_261X251_' . str_replace('', '_', $name), true); // compatation winners home page
                // $this->createThumb($path, 369, 186, 'thumb_369X186_' . str_replace('', '_', $name), true); // AVCC Slider home page
            } else {
                dd('no');
            }

            return response()->json([
                'name' => $name,
                'original_name' => $file->getClientOriginalName(),
            ]);
        } catch (Exception $e) {
            return redirect()->back();
        } catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
            return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
        }
    }

    public function deleteGeoTaggingProcessor(Request $request)
    {
        try {
            GeoTaggingProcessorDetail::where('id', $request->id)->delete();

            return 1;
        } catch (Exception $e) {
            Alert::error('Error', $e->getMessage());
            \Log::error($e->getMessage());
            abort(404);
        } catch (\Illuminate\Database\QueryException $exception) {
            Alert::error('Error', $exception->getMessage());
            \Log::error($exception->getMessage());
            Alert::error('error', 'Query Exception');

            return redirect()->back();
        }
    }
    public function deleteProductProcessor(Request $request)
    {
        try {
            ProcessorProductDetail::where('id', $request->id)->delete();

            return 1;
        } catch (Exception $e) {
            Alert::error('Error', $e->getMessage());
            \Log::error($e->getMessage());
            abort(404);
        } catch (\Illuminate\Database\QueryException $exception) {
            Alert::error('Error', $exception->getMessage());
            \Log::error($exception->getMessage());
            Alert::error('error', 'Query Exception');

            return redirect()->back();
        }
    }

    public function getHscodeProduct(Request $request)
    {

        $product = DB::table('ref_product')->where('ref_hscode_id', $request->hscode)->get();
        $selected = '';
        $sel_hscode = '';
        $option = '<option value="">Select Product</option>';
        if (count($product) > 0) {
            foreach ($product as $key => $value) {
                if ($sel_hscode == $value->id) {
                    $selected = 'selected';

                    $option .= '<option value="' . $value->id . '"  selected="' . $selected . '">' . $value->product_type . '</option>';
                } else {
                    $option .= '<option value="' . $value->id . '">' . $value->product_type . '</option>';
                }
            }
        } else {
            $option .= '<option value="">No record found.</option>';
        }
        return response()->json($option);
    }


    public function batchCreation(Request $request, $at_user_id)
    {

        $product_details = AtProProductsDetails::where('at_user_id', $at_user_id)->get();

        return view('admin.processor.batch_add', compact('product_details'));
    }
    // public function History()
    // {

    //     // $data = AtBatchDetail::get();

    //     $data = SourceDetails::select('at_source_details.*', 'at_batch_details.product_code','at_batch_details.product_name', 'at_batch_details.total_quantity', 'at_batch_details.created_at') // Select 
    //     ->LeftJoin('at_batch_details', 'at_source_details.batch_id', '=', 'at_batch_details.batch_id')
    //     ->whereNull('at_source_details.deleted_at') 
    //     ->orderby('at_source_details.id', 'desc')
    //     ->get();
        
    //     return view('admin.processor.history', compact('data'));
    // }

    public function History()
    {
       
        $data = SourceDetails::select('at_source_details.*', 'at_batch_details.product_code', 'at_batch_details.product_name', 'at_batch_details.total_quantity', 'at_batch_details.created_at') 
            ->leftJoin('at_batch_details', 'at_source_details.batch_id', '=', 'at_batch_details.batch_id')
            ->whereNull('at_source_details.deleted_at')
            ->orderBy('at_source_details.id', 'desc')
            ->paginate(10); // paginate with 10 items per page

        return view('admin.processor.history', compact('data'));
    }



    public function batchCreationindex(Request $request, $at_user_id)
    {

        $list = CertificateStandardDetail::where('at_user_id', $at_user_id)->first();
        $org_st = ProcessorProductDetail::where('at_user_id', $at_user_id)->first();
        $user = User::where('id', $at_user_id)->first();
        $hscd = AtProProductsDetails::where('at_user_id', $at_user_id)->first();

         return view('admin/processor/create_batch', compact('list', 'org_st', 'hscd', 'user'));
    }


    public function batchCreationsave(Request $request)
    {
       // dd($request->all());
        
        // Create a new BatchCreation instance and populate its fields
        $formData = new BatchCreation;
        $formData->scope_certificate_no = $request->input('scope_certificate_no');
        $formData->unit_name = $request->input('unit_name');      
        $formData->hs_code = $request->input('hs_code');
        $formData->product = $request->input('product');
        $formData->organic_status = $request->input('organic_status');
        $formData->quantity = $request->input('quantity');
        $formData->percentage = $request->input('percentage');
        $formData->processing_date = $request->input('processing_date');
        $formData->expiry_date = $request->input('expiry_date');
        $formData->by_product = $request->input('byProduct');
        $formData->created_at = now();
        $formData->updated_at = now();
        $formData->created_by = Auth::guard('misadmin')->user()->id;
        $formData->updated_by = Auth::guard('misadmin')->user()->id;
        $formData->at_user_id = Auth::guard('misadmin')->user()->id;
        $formData->id_of_batch = date('mY') . Auth::guard('misadmin')->user()->id;

        // Save the BatchCreation record
        $formData->save();

        // Retrieve the id of the newly created BatchCreation record
        $batchCreationId = $formData->id;

        $atBatchDetail = new AtBatchDetail;
        $atBatchDetail->batch_id = $batchCreationId;
        $atBatchDetail->product_code =  $request->input('hs_code');
        $atBatchDetail->product_name =  $request->input('product');
        $atBatchDetail->total_quantity =  $request->input('quantity');
        $atBatchDetail->created_at = now();
        $atBatchDetail->updated_at = now();
        $atBatchDetail->created_by = Auth::guard('misadmin')->user()->id;
        $atBatchDetail->updated_by = Auth::guard('misadmin')->user()->id;
        $atBatchDetail->at_user_id = Auth::guard('misadmin')->user()->id;
        $atBatchDetail->id_of_batch = date('mY') . Auth::guard('misadmin')->user()->id;
        $atBatchDetail->save();


        return redirect()->route('superadmin.batchCreationsouceDetails', auth()->user()->id);
    }

    public function batchCreationsouceDetails($at_user_id)
    {
        //dd($at_user_id);
        $batchId = BatchCreation::where('at_user_id', $at_user_id)->latest()->first();
        $batchDetailsId = AtBatchDetail::where('at_user_id', $at_user_id)->get();

        $Sourcedata =  SourceDetails::where('at_user_id', $at_user_id)->get();
       
        return view('admin/processor/source_detail', compact('batchId', 'batchDetailsId','Sourcedata'));
    }


    // public function Search(Request $request)
    // {
    //     try {
    //         // Check if the request is an AJAX request
    //         if ($request->ajax()) {

    //             $userId = Auth::id();

    //             $query = AtOpTransactionVsTransactionProduct::whereNotNull('transaction_certificate_no')->whereNotNull('product_code')
    //                 ->where('transaction_certificate_no', '!=', '')
    //                 ->where('product_code', '!=', '')
    //                 ->get();


    //             if (!empty($request->registration_no)) {
    //                 $query->where('product_code', $request->registration_no);
    //             }
    //             //   $finalData = $query->get();
    //             //  dd($finalData);

    //             // Use DataTables to format the data
    //             $dataTable = DataTables::of($query)
    //                 ->addIndexColumn()
    //                 ->addColumn('tc_no', function ($row) {
    //                     return !empty($row->transaction_certificate_no) ? $row->transaction_certificate_no : 'N/A';
    //                 })
    //                 ->addColumn('product_name', function ($row) {
    //                     return !empty($row->product_code) ? getHscodeProductName($row->product_code) : 'N/A';
    //                 })
    //                 ->addColumn('organic_status', function ($row) {
    //                     return !empty($row->organic_status) ? getRefOrganicStatuscodeByname($row->organic_status) : 'N/A';
    //                 })
    //                 ->addColumn('total_qnt', function ($row) {
    //                     return !empty($row->total_qty) ? $row->total_qty : '0';
    //                 })
    //                 ->addColumn('used_qnt', function ($row) {
    //                     return !empty($row->quantity_for_tc) ? $row->quantity_for_tc : '0';
    //                 })
    //                 ->addColumn('available_qnt', function ($row) {
    //                     return !empty($row->rem_qty) ? $row->rem_qty : '0';
    //                 })
    //                 ->addColumn('qnt_source', function ($row) {

    //                     $uniqueId = 'qnt_source_' . $row->id;
    //                     return sprintf(
    //                         '<input type="text" class="form-control" id="qnt_source' . $row->id . '"  name="qnt_source" value="">',
    //                         $uniqueId,
    //                         $row->id,
    //                         $row->qnt_source
    //                     );
    //                 })
    //                 ->addColumn('action', function ($row) {

    //                     return '<a href="javascript:;" class="saveButton" data-id="' . $row->id . '" data-tcno="' . $row->transaction_certificate_no . '" data-procode="' . $row->product_code . '" data-qty ="' . $row->total_qty . '" data-usedqty ="' . $row->quantity_for_tc . '" data-available_qnt="' . $row->rem_qty . '">Add</a>';
    //                 })
    //                 ->rawColumns(['qnt_source', 'action']);


    //             return $dataTable->make(true);
    //         }

    //         return response()->json(['msg' => 'success']);
    //     } catch (Exception $e) {
    //         // Handle exceptions and log errors
    //         Log::error($e);
    //         Alert::error('Error', 'Something went wrong, please try again later.');
    //         return redirect()->back();
    //     }
    // }


    public function Search(Request $request)
{
    try {
        // Check if the request is an AJAX request
        if ($request->ajax()) {

            $userId = Auth::id();

            $query = AtOpTransactionVsTransactionProduct::whereNotNull('transaction_certificate_no')
                ->whereNotNull('product_code')
                ->where('transaction_certificate_no', '!=', '')
                ->where('product_code', '!=', '')
                ->get();
         
            if (!empty($request->registration_no)) {
                $query->where('product_code', $request->registration_no);
            }

            // Use DataTables to format the data
            $dataTable = DataTables::of($query)
                ->addIndexColumn()
                ->addColumn('tc_no', function ($row) {
                    return !empty($row->transaction_certificate_no) ? $row->transaction_certificate_no : 'N/A';
                })
                ->addColumn('product_name', function ($row) {
                    return !empty($row->product_code) ? getHscodeProductName($row->product_code) : 'N/A';
                })
                ->addColumn('organic_status', function ($row) {
                    return !empty($row->organic_status) ? getRefOrganicStatuscodeByname($row->organic_status) : 'N/A';
                })
                ->addColumn('total_qnt', function ($row) {
                    return !empty($row->total_qty) ? $row->total_qty : '0';
                })
                ->addColumn('used_qnt', function ($row) {
                    return !empty($row->quantity_for_tc) ? $row->quantity_for_tc : '0';
                })
                ->addColumn('available_qnt', function ($row) {
                    return !empty($row->rem_qty) ? $row->rem_qty : '0';
                })
                ->addColumn('qnt_source', function ($row) {
                    $uniqueId = 'qnt_source' . $row->id;
                    $remQty = $row->rem_qty;  // Get available quantity
                    return sprintf(
                        '<input type="number" class="form-control numbersonly" id="%s" name="qnt_source" data-available="%d" value="" oninput="validateQuantity(this)">',
                        $uniqueId,
                        $remQty
                    );
                })
                ->addColumn('action', function ($row) {
                    return '<a href="javascript:;" class="saveButton" data-id="' . $row->id . '" data-tcno="' . $row->transaction_certificate_no . '" data-procode="' . $row->product_code . '" data-qty ="' . $row->total_qty . '" data-usedqty ="' . $row->quantity_for_tc . '" data-available_qnt="' . $row->rem_qty . '">Add</a>';
                })
                ->rawColumns(['qnt_source', 'action']);

            return $dataTable->make(true);
        }

        return response()->json(['msg' => 'success']);
    } catch (Exception $e) {
        // Handle exceptions and log errors
        Log::error($e);
        Alert::error('Error', 'Something went wrong, please try again later.');
        return redirect()->back();
    }
}



    public function saveQuantitySource(Request $request)
    {
        //dd($request->all());
        
        $at_user_id = Auth::guard('misadmin')->user()->id;
        $rowId = $request->input('row_id');
        $tcNo = $request->input('tc_no');
        $procode = $request->input('pro_code');
        $qty = $request->input('total_quantity');
        $usedqty = $request->input('used_quantity');
        $available_qnt = $request->input('available_qnt');
        $qntSourceValue = $request->input('qnt_source'); 
        $batchId = $request->input('batch_id');
        // $batchDetailsId = $request->input('batch_details_id');
        // $batch_id = $request->input('row_id');


        $record = new SourceDetails;

        if ($record) {

            //     $record->at_user_id = $at_user_id;
            //     $record->product_code = $procode;
            //     $record->tc_no = $tcNo;
            //     // $record->organic_status = $organic_statusValue;
            //     $record->total_quantity = $qty;
            //     $record->source_from = 'TC';
            //     $record->used_quantity =   $usedqty;
            //     $record->available_quantity = $available_qnt;
            //     $record-> expiry_date = $request->input('expiry_date');
            //     $record->quantity_source = $qntSourceValue;
            //   //  $record->batch_id = $batch_id;

            $record->at_user_id = $at_user_id;
            $record->product_code = $procode;
            $record->batch_id =  $batchId;
            // $record->batchdetails_id =  $batchDetailsId; 
            $record->tc_no = $tcNo;
            $record->used_quantity =  $usedqty;
            $record->available_quantity =  $available_qnt;
            $record->quantity_source =  $qntSourceValue;


            $record->save();


            return response()->json(['success' => true, 'message' => 'Saved successfully']);
        } else {

            return response()->json(['success' => false, 'message' => 'Record not found'], 404);
        }
    }

    public function batchCreationPreviewDetails($at_user_id)
    {
        //dd($at_user_id);
        $data = BatchCreation::where('at_user_id', $at_user_id)->first();
        $Sourcedata = SourceDetails::where('at_user_id', $at_user_id)->get();
        //dd($Sourcedata);


        return view('admin/processor/preview_detail', compact('data', 'Sourcedata'));
    }



    public function batchCreationPreviewDetailssave(Request $request)
    {


        return redirect()->route('superadmin.Details',  auth()->user()->id);
    }

    // public function Details($at_user_id)
    // {
        
    //     // $data = SourceDetails::where('at_user_id', $at_user_id)->orderby('id', 'desc')->get();

    //     $data = SourceDetails::select('at_source_details.*',  'at_batch_details.id_of_batch', 'at_batch_details.product_code','at_batch_details.product_name', 'at_batch_details.total_quantity', 'at_batch_details.created_at') // Select 
    //         ->LeftJoin('at_batch_details', 'at_source_details.batch_id', '=', 'at_batch_details.batch_id')
    //         ->whereNull('at_source_details.deleted_at') 
    //         ->orderby('at_source_details.id', 'desc')
    //         ->get();


    //     //dd($data);
    //     return view('admin/processor/batch_detail', compact('data'));
    // }

        public function Details($at_user_id)
    {

        
        $data = SourceDetails::select(
                'at_source_details.*',  
                'at_batch_details.id_of_batch', 
                'at_batch_details.product_code', 
                'at_batch_details.product_name', 
                'at_batch_details.total_quantity', 
                'at_batch_details.created_at'
            ) 
            ->leftJoin('at_batch_details', 'at_source_details.batch_id', '=', 'at_batch_details.batch_id')
            ->whereNull('at_source_details.deleted_at') 
            ->orderby('at_source_details.id', 'desc')
            ->paginate(10);  // This will paginate the result, showing 10 records per page

        return view('admin/processor/batch_detail', compact('data'));
    }



    public function batchDelete(Request $request)
    {
        try {
            $id = $request->id;
            $user = SourceDetails::find($id);
            $user->deleted_at = date('Y-m-d H:i:s');
            $user->save();


            return json_encode(['message' => 'done']);
        } catch (Exception $e) {
            return redirect()->back();
        } catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
            return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
        }
    }
}

<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use RobRichards\XMLSecLibs\XMLSecurityDSig;
use RobRichards\XMLSecLibs\XMLSecurityKey;
use Illuminate\Http\Request;
use App\Http\Requests;
use Imagick;
use RealRashid\SweetAlert\Facades\Alert;
use App\Models\AtOpCertificateStandardDetail;
use Auth;
use Str;
use App\Models\User;



class EsignController extends Controller
{


	public function getesignapprove(Request $request)
	{

		$user_id = Auth::guard('misadmin')->user()->id;
		$opr_id = Auth::guard('misadmin')->user()->ref_operator_type_id;
		$user_full_name = user_name($user_id);
		$token = Str::random(64);
		DB::table('esign_redirects')->insert([
			'user_id' => $user_id,
			'token' => $token,
			'created_at' => now(),
			'redirect_url' => $request->redirect_url
		]);

		$FILE_NAME = 'download.pdf';
		$project_path = base_path('esign/');
		$tmp_path = $project_path . 'cert/';
//dd($tmp_path);
		$ASPID = 'APED-900';
		
		$RESPONSE_URL = route('getesignreturnapprove', [$opr_id, $user_id, $token]);
		
		$PRIVATEKEY = base_path("esign/cert/apeda_in_new.pem");
		$ESIGN_URL = 'https://es-staging.cdac.in/esignlevel2/2.1/form/signdoc';

		function print_pdf($name, $file)
		{
			header('Content-Type: application/pdf');
			header('Cache-Control: private, must-revalidate, post-check=0, pre-check=0, max-age=1');
			header('Pragma: public');
			header('Expires: Sat, 26 Jul 1997 05:00:00 GMT'); 
			header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT');
			header('Content-Disposition: inline; filename="' . basename($name) . '"');
			header('Content-Length: ' . strlen($file));
			echo $file;
		}



		$file_name_array = explode('.', $FILE_NAME);

		$ext = end($file_name_array);
		unset($file_name_array[count($file_name_array) - 1]);
		$file_name_wo_ext = implode('.', $file_name_array);

		

	

		require 'esign/TCPDF/tcpdf.php';
		$pdf = new \TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// dd($pdf);

		$imagick = new Imagick();
		$imagick->setBackgroundColor(new \ImagickPixel('transparent'));
		$imagick->setResolution(288, 288);
		echo exec('gswin64 -dNOPAUSE -sDEVICE=pdfwrite -sOUTPUTFILE=D:\php8\htdocs\apeda\esign/cert/testfile.pdf -dBATCH ');
		


		$imagick->readImage($project_path . 'cert/' . $FILE_NAME); 

		

		$num_pages = $imagick->getNumberImages();
	
		for ($i = 0; $i < $num_pages; $i++) {
			$imagick->setIteratorIndex($i);
			$imagick->setImageFormat('jpeg');
			$imagick->stripImage();
			$imagick->writeImage($tmp_path . $file_name_wo_ext . '-' . $i . '.jpg');
		}
		$imagick->destroy();
		
		$info = array();
		
		$pdf->my_set_sign('', '', '', '', 2, $info); 

		
		for ($i = 0; $i < $num_pages; $i++) {
			$pdf->AddPage();
			$pdf->Image($tmp_path . $file_name_wo_ext . '-' . $i . '.jpg');
		}
		
		$bMargin = $pdf->getBreakMargin();
	
		$auto_page_break = $pdf->getAutoPageBreak();
	
		$pdf->SetAutoPageBreak(false, 0);
		

		//$pdf->SetAlpha(0.5);

		$pdf->SetAutoPageBreak($auto_page_break, $bMargin);
		
		$pdf->setPageMark();
		
		$pdf->setSignatureAppearance(140, 255, 60, 17); 

		$pdf->SetFont('times', '', 8);
		$pdf->setCellPaddings(1, 2, 1, 1);
		$pdf->MultiCell(40, 10, 'Digitally Signed by: ' . $user_full_name  . "\n" . 'Date: ' . date('d-m-Y') . "\n" . date('h:i a'), 0, '', 0, 1, 157, 255, true);

		$doc_path = $tmp_path . 'signed-' . $file_name_wo_ext . '.pdf';
	
		//dd($doc_path);

		$file = $pdf->my_output($doc_path, 'F'); 
		$pdf_byte_range = $pdf->pdf_byte_range;
		$pdf->_destroy();

		$file_hash = hash_file('sha256', $doc_path);

		//dd($file_hash );
		
		for ($i = 0; $i < $num_pages; $i++) {
			unlink($tmp_path . $file_name_wo_ext . '-' . $i . '.jpg'); 
		}
		$doc = new \DOMDocument();

		
		$txn = rand(111111111111, 999999999999) . '----' . $pdf_byte_range; 

		$ts = date('Y-m-d\TH:i:s');

		$doc_info = $FILE_NAME;

		//dd($doc_info);

		$xmlstr = '<Esign AuthMode="1" aspId="' . $ASPID . '" ekycId="" ekycIdType="A" responseSigType="PKCS7" responseUrl="' . $RESPONSE_URL . '" sc="y" ts="' . $ts . '" txn="' . $txn . '" ver="2.1"><Docs><InputHash docInfo="' . $txn . '" hashAlgorithm="SHA256" id="1">' . $file_hash . '</InputHash></Docs></Esign>';

		$doc->loadXML($xmlstr); //parser

		
		$objDSig = new XMLSecurityDSig();
		
		$objDSig->setCanonicalMethod(XMLSecurityDSig::C14N);
		
		$objDSig->addReference(
			$doc,
			XMLSecurityDSig::SHA1,
			array('http://www.w3.org/2000/09/xmldsig#enveloped-signature'),
			array('force_uri' => true)
		);

		
		$objKey = new XMLSecurityKey(XMLSecurityKey::RSA_SHA1, array('type' => 'private'));

	
		$objKey->passphrase = '';

	//dd($objKey);
		$objKey->loadKey($PRIVATEKEY, TRUE);

		$objDSig->sign($objKey);
		
		$objDSig->appendSignature($doc->documentElement);

		$signXML = $doc->saveXML();

		
		$signXML = str_replace('<?xml version="1.0"?>', '', $signXML);

		//dd($signXML);
		ob_end_clean();



		echo 	'<form action="https://es-staging.cdac.in/esignlevel2/2.1/form/signdoc" method="post" id="formid">
				<input type="hidden" id="eSignRequest" name="eSignRequest" value=\'' . $signXML . '\' />
				<input type="hidden" id="aspTxnID" name="aspTxnID" value="' . $txn . '"/>
				<input type="hidden" id="Content-Type" name="Content-Type" value="application/xml"/>
			</form>
			<script>

				document.getElementById("formid").submit();
			</script>';
	}


	public function getesignreturnapprove(Request $request, $operator_type_id, $user_id, $token)
	{

		$check_token = DB::table('esign_redirects')
			->where([
				'user_id' => $user_id,
				'token' => $token
			])
			->first();

		if (!$check_token) {
			return redirect()->route('login')->withInput()->with('error', 'Invalid token!');
		}
		Auth::guard('misadmin')->loginUsingId($user_id);


		$esign_data = DB::table('esign_redirects')->where('user_id', $user_id)->get();

		dd($esign_data);

		 $redirect_url = $esign_data[0]->redirect_url;

		// dd($redirect_url);
		
		 $esign_auth  = User::where('id',$user_id)->update(['esign_authentication'=>1]);

		 DB::table('esign_redirects')->where(['user_id' => $user_id])->delete();




		$xmldata = (array) simplexml_load_string(filter_input(INPUT_POST, 'eSignResponse')) or die("Failed to load");
		$txn = $xmldata["@attributes"]["txn"];
		$txn_array = explode('----', $txn);
		$pdf_byte_range = $txn_array[1];

		$pkcs7 = (array) $xmldata['Signatures'];
		$pkcs7_value = $pkcs7['DocSignature'];
		$cer_value = $xmldata['UserX509Certificate'];

		$beginpem = "-----BEGIN CERTIFICATE-----\n";

		$endpem = "-----END CERTIFICATE-----\n";
		$pemdata = $beginpem . trim($cer_value) . "\n" . $endpem;

		$cert_data = openssl_x509_parse($pemdata);

		$state = $cert_data['subject']['ST'] ?? null;
		$organization = $cert_data['subject']['O'] ?? null;
		$common_name = $cert_data['subject']['CN'] ?? null;
		$postal_code = $cert_data['subject']['postalCode'] ?? null;

		// Save the extracted data to the database
		DB::table('esign_subject_data')->insert([
			'user_id' => $user_id,
			'state' => $state,
			'organization' => $organization,
			'common_name' => $common_name,
			'postal_code' => $postal_code,
			'created_at' => now(),
			'updated_at' => now(),
		]);


		 Alert::success('Success', "You Are Now verified!.");
		 return redirect($redirect_url);
		// return response('Data saved successfully');



		// echo '<pre>';
		// print_r($cert_data['subject']);
	}


	public function pancard(Request $request)
	{
		//dd($request->all());
		// $validator = Validator::make($request->all(), [
		// 	'pan_no' => 'required'
		// ]);

		// if ($validator->fails()) {
		// 	return response(array(
		// 	'message' => 'parameters missing',
		// 	'missing_parameters' => $validator->errors()
		// 	), 400);
		// }

		$pan_no = $request->input('pan_no');

		//$pan_no='AMXPP6546K';
		// PAN Verification api call
		$file_name = 'pan_request/oupt' . strtotime(date("Y-m-d") . date("H:i:s")) . '.sig';
		$pan_user = 'V0272501';
		$pan_password = 'nsdl@1234';


		//$pan_user = config('pan.pan_user'); //V0139201
		//$pan_password = config('pan.pan_password'); //nsdl@1234
		// To generate oupt.sig file
		shell_exec('cd pan/deliverable; java pkcs7gen oupt.jks ' . $pan_password . ' ' . $pan_user . '^' . $pan_no . ' ' . $file_name);
		shell_exec('cd pan; javac APIBased.java');
		$output = shell_exec('cd pan; java APIBased ' . $pan_user . '^' . $pan_no . ' ' . $file_name);
		dd("asasa" . $output);
		$panArray = explode("^", $output);

		if ($output) {
			if ($panArray[0] != 1) {
				return response()->json(['errmessage' => 'PAN Verification Not Successful'], 400);
			} else {
				return response()->json(['message' => 'PAN Verification Successful'], 200);
			}
		} else {
			return response()->json(['errmessage' => 'PAN Verification Not Successful'], 400);
		}
	}
}

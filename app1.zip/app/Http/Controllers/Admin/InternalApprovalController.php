<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\RefState;
use App\Models\RefDistrict;
use App\Models\RefRegion;
use App\Models\RefVillage;
use App\Models\RoleUser;
use App\Models\UserInspector;
use App\Models\AtFarmerRegDetail;
use App\Models\UserWarehouseManagerOfficers;
use App\Models\AtFarmerInspectionDetail;
use App\Models\AtFarmerInspectionPlotDetails;
use App\Models\AtFarmerChecklist;
use App\Models\AtInspectionNonConformity;
use App\Models\AtInspectionApprovalInternalInspector;
use App\Models\RefOperatorType;
use App\Models\AtExternalSchedule;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;
use Validator;
use DataTables;
use Carbon\Carbon;
use Barryvdh\DomPDF\Facade as PDF;


class InternalApprovalController extends Controller
{
    //

    public function inspectionList(Request $request)
    {
        $oper_type = Auth::user()->ref_operator_type_id;
        $email = Auth::user()->user_name;
        if ($oper_type == 2) {
            $user_id = Auth::user()->id;
        } else {
            $user_id = UserWarehouseManagerOfficers::where('email_id', $email)->where('user_type', 'AM')->first()->at_user_id ?? '';
        }

        $inspIds =  UserInspector::select('id')->where('at_user_id', $user_id)->get();


        if ($request->ajax()) {

            $totalData =  AtFarmerRegDetail::whereIn('at_ics_inspector_id', $inspIds)->get();
            //dd($totalData);
            return Datatables::of($totalData)
                ->addIndexColumn()
                ->addColumn('name', function ($row) {
                    return $row->farmer_first_name ?? '';
                })
                ->addColumn('email', function ($row) {
                    return $row->email_id ?? '';
                })->addColumn('mobile', function ($row) {
                    return $row->mobile_no ?? '';
                })->addColumn('address', function ($row) {

                    return $row->farmer_address ?? '';
                })->addColumn('insp_name', function ($row) {

                    return getInspectorName($row->at_ics_inspector_id)->name_of_inspector ?? '';
                })->addColumn('created_on', function ($row) {

                    return  date('d/m/Y', strtotime($row->created_at)) ?? '';
                })->addColumn('action', function ($row) {
                    $actionBtn = '
                  <a href=' . route('superadmin.inspectionDetail',) . '?fid=' . $row->id . '&insid=' . $row->at_ics_inspector_id . '><span><i class="mdi mdi-eye text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="View Detail"></i></span></a>';

                    return $actionBtn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        return view('admin/internal_approval/inspection-list');
    }


    public function inspectionCompleteList(Request $request)
    {



        if ($request->ajax()) {

            $totalData =  AtFarmerRegDetail::where('approval_flag', 1)
                ->orderBy('id', 'desc')
                ->get();
            //dd($totalData);
            return Datatables::of($totalData)
                ->addIndexColumn()
                ->addColumn('name', function ($row) {
                    return $row->farmer_first_name ?? '';
                })
                ->addColumn('email', function ($row) {
                    return $row->email_id ?? '';
                })->addColumn('mobile', function ($row) {
                    return $row->mobile_no ?? '';
                })->addColumn('address', function ($row) {

                    return $row->farmer_address ?? '';
                })->addColumn('insp_name', function ($row) {

                    return getInspectorName($row->at_ics_inspector_id)->id ?? '';
                })->addColumn('created_on', function ($row) {

                    return  date('d-m-Y', strtotime($row->created_at)) ?? '';
                })->addColumn('action', function ($row) {
                    $viewDetailUrl = route('superadmin.inspectionCompleteDetail') . '?fid=' . $row->id;
                 

                    $actionBtn = '

                
                    <a href="' . $viewDetailUrl . '">
                        <span><i class="mdi mdi-eye text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="View Detail"></i></span>
                    </a>';

                   

                    return $actionBtn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }

        return view('admin/internal_approval/inspection-list-complete');
    }


    public function scheduleExternalInspectionIndex(Request $request)
    {

        // if ($request->ajax()) {

        //     $totalData = AtExternalSchedule::query()
        //     ->leftJoin('at_user', 'at_external_schedule.cb_id', '=', 'at_user.id'); // Corrected join
        //      // Added -> for method chaining
           
        //     $finalData = $totalData->select(
        //         'at_external_schedule.*',
        //         'at_user.email',
        //         'at_user.mobile_no'
        //     )
        //         ->orderBy('id', 'desc')

        //         ->get();

        //   //  dd( $finalData);
        //     return Datatables::of($finalData)
        //         ->addIndexColumn()
        //         ->addColumn('insp_name', function ($row) {
        //             return $row->inspector_name ?? '';
        //         })
        //         ->addColumn('opert_name', function ($row) {
        //             return $row->operator_type ?? '';
        //         })
        //         ->addColumn('email', function ($row) {
        //             return $row->email ?? '';

        //         })
        //         ->addColumn('mobile', function ($row) {
        //             return $row->mobile_no ?? '';

        //         })
        //         ->addColumn('fdate', function ($row) {
        //             return date('d-m-Y', strtotime($row->from_date ?? ''));

        //         })
        //         ->addColumn('tdate', function ($row) {
        //             return date('d-m-Y', strtotime($row->to_date ?? ''));

        //         })
                
        //        ->addColumn('created_on', function ($row) {

        //             return  date('d-m-Y', strtotime($row->created_at)) ?? '';
        //         })->addColumn('action', function ($row) {
        //             $viewDetailUrl = route('superadmin.inspectionCompleteDetail') . '?fid=' . $row->id;
                 

        //             $actionBtn = '

                
        //             <a href="' . $viewDetailUrl . '">
        //                 <span><i class="mdi mdi-eye text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="View Detail"></i></span>
        //             </a>';

                   

        //             return $actionBtn;
        //         })
        //         ->rawColumns(['action'])
        //         ->make(true);
        // }

        if ($request->ajax()) {
            $totalData = User::where('created_by',Auth::id())->where('ref_operator_type_id', '!=', '1')->where('ref_operator_type_id', '!=', '7')->where('ref_operator_type_id', '!=', '102')->where('ref_operator_type_id', '!=', '103')->where('ref_operator_type_id', '!=', '9')
                ->whereRaw('( CASE 
                         WHEN ref_operator_type_id = 2 THEN risk_assessment = 1 
                         WHEN ref_operator_type_id != 2 THEN risk_assessment = 0  
                        END)')
                ->orderby('id', 'DESC')->get();
          
            // WHEN ref_operator_type_id = 2 THEN inspection_status = 1 
            return Datatables::of($totalData)
                ->addIndexColumn()
                ->addColumn('reg_no', function ($row) {
                    // return '#/'.getRolesTitle($row->ref_operator_type_id).'/'.$row->id??'';

                    if (empty($row->registration_no) || $row->registration_no == 'NULL::character varying') {
                        $m = date('m', strtotime($row->created_at));
                        $y = substr(date('Y', strtotime($row->created_at)), -2);
                        $lst = str_pad($row->id, 5, "0", STR_PAD_LEFT);
                        $st = "ORG/" . $m . $y . "/" . $lst;
                        return $st;
                    } else {
                        return $row->registration_no;
                    }
                })
                ->addColumn('name', function ($row) {
                    return $row->first_name ?? '';
                })
                ->addColumn('operator_type', function ($row) {
                    return getRolesTitle($row->ref_operator_type_id);
                 
                })
                ->addColumn('action', function ($row) {
                    $actionBtn = '';


                    // $actionBtn .= '<a href="' . route('superadmin.external.inspectionSchedule', $row->id) . '"><span>Inspection Schedule</span></a><br>';

                    if ($row->external_inspection == 0) {
                        $actionBtn .= '<a href="' . route('superadmin.ext.inspectionForm', $row->id) . '"><span>Add Schedule </span></a><br>';
                    } else {
                        $actionBtn .= '<a href="javascript:void(0)" style="color:green"><i class="ri-check-double-line"></i> External Inspection Done </a><br>';
                    }

                    // if ($row->external_inspection == 0) {
                    //     $actionBtn .= '<a href="javascript:void(0)" onclick="ConfirmInspection()"><span>Enter Inspection Closure</span></a><br>';
                    // } elseif ($row->external_inspection == 1) {
                    //     $actionBtn .= '<a href="' . route('superadmin.external.inspectionClosureForm', $row->id) . '"><span>Enter Inspection Closure</span></a><br>';
                    // } else {
                    //     $actionBtn .= '<a href="' . route('superadmin.external.inspectionClosureForm', $row->id) . '" style="color:green"><span><i class="ri-check-double-line"></i>View Inspection Closure</span></a><br>';
                    // }

                    // if ($row->ref_operator_type_id == 2) {
                    //     $actionBtn .= '<a href="' . route('superadmin.external.viewInspectionList', ['fid' => $row->id]) . '"><span>View Internal Inspection Details</span></a><br>';
                    // }

                    return $actionBtn;
                })

                ->rawColumns(['action'])
                ->make(true);
        }


    
        return view('admin/internal_approval/external_inspector_schedule_index');
    }

    public function ExtinspectionForm($id)
    {
        $regDetail = User::where('id', $id)->first();

       // dd($regDetail);
        $authsign = User::whereHas('roles', function ($q) {
            return $q->where('title', 'Inspector');
        })
            ->where('created_by', Auth::id())
            ->get();


        return view('admin/internal_approval/inspection-schedule', compact('regDetail', 'authsign'));
    }

    public function schedulestore(Request $request)
    {
     //  dd($request->all());
       

            $request->validate([
                'reg_no'  => 'required',
                'submission_of_inspection' => 'required',
                'inspection_date' => 'required',
                'ins_name' => 'required',
                'ins_contact' => 'required',
                
            ]);

            $data = array(
                'at_user_id'  => $request->at_user_id,
                'reg_no'  => $request->reg_no,
                'submission_of_inspection_report' => $request->submission_of_inspection ?? '',
                'inspection_date' => $request->inspection_date ?? '',
                'inspector_name' => $request->ins_name ?? '',
                'inspector_contact' => $request->ins_contact ?? '',
                'operator_type' => $request->operator_type ?? '',
                'operator_type_id' => $request->operator_type_id ?? '',
                'operator_name' => $request->operator_name ?? '',
                'operator_mobile' => $request->operator_mobile ?? '',
                'operator_email' => $request->operator_email ?? '',
                'operator_address' => $request->address ?? '',
                'inspector_contact' => $request->ins_contact ?? '',
                'created_by' => Auth::user()->id,
                
            );
           // dd($request->all(), $data);
            $user = AtExternalSchedule::create($data);
           Alert::success('Success', "Schedule Successfully.");
        //    return redirect()->route('superadmin.scheduleExternalInspection');
           return redirect()->back();
           
       
    }


    public function scheduleAdd(Request $request)
    {
          $userId = Auth::id();

          //dd($userId);
        
          $user = User::where(function ($query) {
            return $query->orWhere('ref_operator_type_id', '>', 7)
                ->orWhere('ref_operator_type_id', NULL);
        })->where('created_by', $userId)->orderBy('id', 'DESC')
            ->get();


            $operator = RefOperatorType::whereIn('id',[2,3,4,5,6])->get();

        return view('admin/internal_approval/external_inspector_schedule', compact('user', 'operator', 'userId'));
    }
//     public function schedulestore(Request $request)
//     {
//         //dd($request->all());
       
//         $request->validate([

//             'inspector_name' => 'required',
//             'operator_type' => 'required',
//             'from_date' => 'required',
//             'to_date' => 'required',
     
//         ]);
       
       
//         $data = array(
//             'inspector_name' => $request->inspector_name,
//             'operator_type' => $request->operator_type,
//             'from_date' => $request->from_date,
//             'to_date' => $request->to_date,
//             'comments' => $request->comments,
//             'cb_id' => $request->id,
            
//         );

//    //   dd($request->all(), $data);
//         //dd($data);
//         $user = AtExternalSchedule::create($data);
//         Alert::success('Success', "Schedule Successfully.");
//         return redirect()->route('superadmin.scheduleExternalInspection');
//     }



    public function scheduleInspector(Request $request)
    {
        $userId = Auth::id();
          $farmerId = $request->query('fid');

          $user = User::where(function ($query) {
            return $query->orWhere('ref_operator_type_id', '>', 7)
                ->orWhere('ref_operator_type_id', NULL);
        })->where('created_by', $userId)->orderBy('id', 'DESC')
            ->get();
      
//dd($user );
        return view('admin/internal_approval/external_inspector_schedule', compact('farmerId', 'user'));
    }


    public function generatePdf(Request $request, $id)
    {
        $fid = $id;
        $insid = $request->insid;
        $oper_type = Auth::user()->ref_operator_type_id;
        $regDetail = AtFarmerRegDetail::with(['farmerLandDetail', 'farmerBankDetail', 'farmerDocs', 'farmerOSPDetail'])->where('id', $fid)->first();
        $farInspDetail = AtFarmerInspectionDetail::where('at_farmer_reg_details_id', $fid)->where('at_inspector_id', $insid)->first();
        //$farInspDetail = AtFarmerInspectionDetail::where('at_farmer_reg_details_id',$fid)->where('at_inspector_id',$insid)->first();
        $farPlotDetail = AtFarmerInspectionPlotDetails::where('at_farmer_reg_details_id', $fid)->get();
        $farCheckList = AtFarmerChecklist::where('at_farmer_reg_details_id', $fid)->get();
        $nonConDetail = AtInspectionNonConformity::where('at_farmer_reg_details_id', $fid)->get();
        $appInspDetail = AtInspectionApprovalInternalInspector::where('at_farmer_reg_details_id', $fid)->first();

        $pdf = PDF::loadView('admin.internal_approval.inspection-compelete-detail-download', compact('oper_type', 'regDetail', 'farInspDetail', 'farPlotDetail', 'farCheckList', 'nonConDetail', 'appInspDetail','fid'));
        
        return $pdf->download('inspection-compelete-detail-download.pdf');
    }


    public function inspectionCompleteDetail(Request $request)
    {
        
        $fid = $request->fid;
        $insid = $request->insid;
        $oper_type = Auth::user()->ref_operator_type_id;
        $regDetail = AtFarmerRegDetail::with(['farmerLandDetail', 'farmerBankDetail', 'farmerDocs', 'farmerOSPDetail'])->where('id', $fid)->first();
        $farInspDetail = AtFarmerInspectionDetail::where('at_farmer_reg_details_id', $fid)->where('at_inspector_id', $insid)->first();
        //$farInspDetail = AtFarmerInspectionDetail::where('at_farmer_reg_details_id',$fid)->where('at_inspector_id',$insid)->first();
        $farPlotDetail = AtFarmerInspectionPlotDetails::where('at_farmer_reg_details_id', $fid)->get();
        $farCheckList = AtFarmerChecklist::where('at_farmer_reg_details_id', $fid)->get();
        $nonConDetail = AtInspectionNonConformity::where('at_farmer_reg_details_id', $fid)->get();
        $appInspDetail = AtInspectionApprovalInternalInspector::where('at_farmer_reg_details_id', $fid)->first();


        return view('admin/internal_approval/inspection-compelete-detail', compact('oper_type', 'regDetail', 'farInspDetail', 'farPlotDetail', 'farCheckList', 'nonConDetail', 'appInspDetail','fid'));
    }

    public function inspectionDetail(Request $request)
    {
        $fid = $request->fid;
        $insid = $request->insid;
        $oper_type = Auth::user()->ref_operator_type_id;
        $userData = Auth::user();

        //dd($userData);

        $cb_name= User::select('email', 'first_name', 'mobile_no', 'address')->where('id', Auth::user()->created_by)->first();

      
        $regDetail = AtFarmerRegDetail::with(['farmerLandDetail', 'farmerBankDetail', 'farmerDocs', 'farmerOSPDetail'])->where('id', $fid)->first();
       // dd($regDetail);
        $farInspDetail = AtFarmerInspectionDetail::where('at_farmer_reg_details_id', $fid)->where('at_inspector_id', $insid)->first();
        //$farInspDetail = AtFarmerInspectionDetail::where('at_farmer_reg_details_id',$fid)->where('at_inspector_id',$insid)->first();
        $farPlotDetail = AtFarmerInspectionPlotDetails::where('at_farmer_reg_details_id', $fid)->get();
        $farCheckList = AtFarmerChecklist::where('at_farmer_reg_details_id', $fid)->get();
        $nonConDetail = AtInspectionNonConformity::where('at_farmer_reg_details_id', $fid)->get();
        $appInspDetail = AtInspectionApprovalInternalInspector::where('at_farmer_reg_details_id', $fid)->first();


        //dd($oper_type);
        return view('admin/internal_approval/inspection-detail', compact('oper_type', 'regDetail', 'farInspDetail', 'farPlotDetail', 'farCheckList', 'nonConDetail', 'appInspDetail','userData', 'cb_name'));
    }

    public function approvalPost(Request $request)
    {

        // dd($request->all());
        $request->validate([
            'status' => 'required',
            'approved_remark' => 'required',
        ]);

        try {
            $email = Auth::user()->email;

            $user_id =  UserWarehouseManagerOfficers::where('email_id', $email)->where('user_type', 'AM')->first()->at_user_id ?? '';
            // dd($user_id);
            $inspIds =  UserInspector::select('id')->where('at_user_id', $user_id)->get();


            //dd($inspIds);



            $data = array(
                'approved_remark' => $request->approved_remark,
                'approval_flag' =>  $request->status == 'approved' ? '1' : '',
                'cancellation_flag' => $request->status == 'rejected' ? '1' : '',
                'approved_by' => Auth::user()->id,
                'approval_date' => date('Y-m-d H:i:s'),
            );

            //dd($data );
            if (!empty($request->fid)) {
                $data['updated_at'] = date('Y-m-d H:i:s');
                $data['updated_by'] = Auth::user()->id;
                AtFarmerRegDetail::where('id', $request->fid)->update($data);

                $inspectData =  AtFarmerRegDetail::whereIn('at_ics_inspector_id', $inspIds)->where('inspection_status', 1)->count();
                $approvalData =  AtFarmerRegDetail::whereIn('at_ics_inspector_id', $inspIds)->where('approval_flag', 1)->count();

                if ($inspectData == $approvalData) {

                    User::where('id', $user_id)->update(['internal_inspection' => 1]);
                }

                Alert::success('Success', 'Data save successfully.');
                return redirect()->back();
            } else {
                Alert::success('error', 'Something went wrong.');
                return redirect()->back();
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }


    //     public function approvalPost(Request $request)
    // {
    //     // Validate the request inputs
    //     $request->validate([
    //         'status' => 'required',
    //         'approved_remark' => 'required',
    //     ]);

    //     try {
    //         // Get the email of the authenticated user
    //         $email = Auth::user()->user_name;

    //         // Fetch the user ID or set it to null if not found
    //         $user_id = UserWarehouseManagerOfficers::where('email_id', $email)
    //                     ->where('user_type', 'AM')
    //                     ->first()->at_user_id ?? null;


    //         // Ensure $user_id is not null or empty
    //         if (is_null($user_id)) {
    //             Alert::error('Error', 'User not found or invalid user.');
    //             return redirect()->back();
    //         }

    //         // Get the inspector IDs related to the user
    //         $inspIds = UserInspector::select('id')
    //                     ->where('at_user_id', 155)
    //                     ->get()
    //                     ->pluck('id')  // Get only the 'id' values
    //                     ->toArray();   // Convert the collection to an array

    //         // Prepare the data for the update
    //         $data = [
    //             'approved_remark' => $request->approved_remark,
    //             'approval_flag' => $request->status == 'approved' ? '1' : '',
    //             'cancellation_flag' => $request->status == 'rejected' ? '1' : '',
    //             'approved_by' => Auth::user()->id,
    //             'approval_date' => now(),
    //         ];

    //         // Update or handle the approval process if fid is provided
    //         if (!empty($request->fid)) {
    //             $data['updated_at'] = now();
    //             $data['updated_by'] = Auth::user()->id;

    //             // Update the farmer registration detail
    //             AtFarmerRegDetail::where('id', $request->fid)->update($data);

    //             // Check for inspection and approval completion
    //             $inspectData = AtFarmerRegDetail::whereIn('at_ics_inspector_id', $inspIds)
    //                             ->where('inspection_status', 1)
    //                             ->count();

    //             $approvalData = AtFarmerRegDetail::whereIn('at_ics_inspector_id', $inspIds)
    //                              ->where('approval_flag', 1)
    //                              ->count();

    //             // If all inspections are approved, mark internal inspection as complete
    //             if ($inspectData == $approvalData) {
    //                 User::where('id', $user_id)->update(['internal_inspection' => 1]);
    //             }

    //             Alert::success('Success', 'Data saved successfully.');
    //             return redirect()->back();
    //         } else {
    //             Alert::error('Error', 'Something went wrong.');
    //             return redirect()->back();
    //         }

    //     } catch (Exception $e) {
    //         // Log the error and abort with a 404
    //         Log::error($e->getMessage());
    //         abort(404);
    //     }
    // }

}

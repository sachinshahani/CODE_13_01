<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AtFarmerStandingCorpDetail;
use App\Models\User;
use App\Models\UserSelf;
use App\Models\UserInspector;
use App\Models\UserWarehouse;
use App\Models\UserWarehouseManagerOfficers;
use App\Models\RefState;
use App\Models\RefDistrict;
use App\Models\RefVillage;
use App\Models\RefRegion;
use App\Models\AtFarmerRegDetail;
use App\Models\AtFarmDetails;
use App\Models\RefBank;
use App\Models\AtClosingStock;
use App\Models\IndividualProducerFarmerDetail;
use App\Models\IndividualProducerFarmDetail;
use App\Models\IndividualProducerDetailOfStandingCorp;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;
use Exception;

class IPHarvestUpdateController extends Controller
{
    public function updateIPActualYield()
    {
        $user_id = Auth::guard('misadmin')->user()->id;
        return view('admin.harvest_update.ip.update_actual_yield');
    }



    public function updateIPActualYieldScope(Request $request)
    {

        $user_id = Auth::guard('misadmin')->user()->id;
        $harvester = User::find(Auth::guard('misadmin')->user()->id);
        //$FarmerRegDetail = AtFarmerRegDetail::where('at_user_id',$user_id)->get();
        $FarmerRegDetail = IndividualProducerFarmerDetail::where('at_user_id', $user_id)->get();
        //dd($harvester);
        return view('admin.harvest_update.ip.update_actual_yield_scope', compact('harvester', 'FarmerRegDetail'));
    }


    public function updateIPActualYieldFarmsdetails(Request $request, $id)
    {

        $user_id = Auth::guard('misadmin')->user()->id;
        $harvester = User::find(Auth::guard('misadmin')->user()->id);
        $FarmerRegDetail = IndividualProducerFarmerDetail::where('at_user_id', $user_id)->first();
        $farm_details = IndividualProducerFarmDetail::where('at_farmer_reg_details_id', $id)->get();
        // dd($farm_details);
        return view('admin.harvest_update.ip.update_actual_yield_farmsdetails', compact('id', 'FarmerRegDetail', 'harvester', 'farm_details'));
    }



    public function updateIPActualYieldProducts(Request $request, $id, $farm_id)
    {
        $user_id = Auth::guard('misadmin')->user()->id;
        $harvester = User::find(Auth::guard('misadmin')->user()->id);
        $FarmerRegDetail = IndividualProducerFarmerDetail::where('at_user_id', $user_id)->first();
        $farm_details = IndividualProducerFarmDetail::where('at_farmer_reg_details_id', $id)->first();
        $product_details = IndividualProducerDetailOfStandingCorp::where('at_ip_farm_details_id', $farm_id)->get();
        return view('admin.harvest_update.ip.update_actual_yield_products', compact('id', 'farm_id', 'FarmerRegDetail', 'harvester', 'farm_details', 'product_details'));
    }


    public function editIPHarvestProduct(Request $request)
    {

        $product_detail = IndividualProducerDetailOfStandingCorp::where('id', $request->product_id)->first();

        return  view('admin.harvest_update.ip.tpl_edit_product', compact('product_detail'))->render();
    }



    public function storeIPHarvestProduct(Request $request)
    {
        $validator = \Validator::make($request->all(), [
            'actual_yield' => 'required',
            'harvest_date' => 'required',
            'sowing_date' => 'required',
            'product_id' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()->all()]);
        }

        try {
            $insertData = array(
                'actual' =>  $request->actual_yield,
                'harvest_date' => date('Y-m-d', strtotime($request->harvest_date)),
                'sowing_date' => date('Y-m-d', strtotime($request->sowing_date)),
                'updated_at' => date('Y-m-d H:i:s'),
            );

            //dd($request->product_id,$request->harvest_date,$request->sowing_date);
            $update = IndividualProducerDetailOfStandingCorp::where('id', $request->product_id)->update($insertData);

            $input_approval = IndividualProducerDetailOfStandingCorp::where('id', $request->product_id)->first();

            $insert_closing_stock = array(
                'at_ip_details_standing_crop_id' => $input_approval->id,
                'ref_operator_type_id' => Auth::guard('misadmin')->user()->ref_operator_type_id,
                'at_user_id' => Auth::guard('misadmin')->user()->id,
                'organic_status' => $input_approval->organic_status,
                'date_of_harvest' => date('Y-m-d', strtotime($input_approval->harvest_date)),
                'harvest_year' => date('Y'),
                'ref_product_id' => $request->product_id,
            );
            //  dd($insert_closing_stock);
            $updateAt =   AtClosingStock::create($insert_closing_stock);

            return response()->json(['data' => $input_approval, 'success' => 'Data is successfully added']);
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }
}

<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Permission;
use App\Models\Role;
use App\Models\RoleUser;
use App\Models\User;
use App\Models\CertificateStandardDetail;
use App\Models\AtFarmerRegDetail;
use App\Models\AtFarmerLandDetail;
use App\Models\AtOpNocDetails;
use Exception;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;

class NOCController extends Controller
{
	
    public function checkSpopeValidation($userId){
        $scopeData = CertificateStandardDetail::where('at_user_id',$userId)->first();
        $days = 0;
        if(!empty($scopeData)){
            $date1 = strtotime(date('Y-m-d'));
            $date2 = strtotime($scopeData->validity_end_date);
            
            $diff = $date2 - $date1;
            $days = floor($diff / (60 * 60 * 24));
        }
        
        return $days;

    }
	public function applyNOC(){
        $userId = Auth::guard('misadmin')->user()->id;
        $currentCB = Auth::guard('misadmin')->user()->created_by;
        //dd($currentCB);
        $scopeValidity = $this->checkSpopeValidation($userId);
        if($scopeValidity < 7){
            Alert::success('','NOC can only be applied within the validity of scope certification.');
        }
        $scopeData = CertificateStandardDetail::where('at_user_id',$userId)->first();
        $farmerDetails = AtFarmerRegDetail::where('at_user_id',$userId)->get();
        $checkApply = AtOpNocDetails::where('at_user_id',$userId)->first();
        return view('admin.noc.applynoc',compact('scopeData','farmerDetails','userId','currentCB','checkApply','scopeValidity'));
    }

    public function saveApplyNOC(Request $request){
        try
        {
            //dd($request->all());
            $userId = Auth::guard('misadmin')->user()->id;
            //$currentCB = Auth::guard('misadmin')->user()->created_by;
            //$scopeValidity = $this->checkSpopeValidation($userId);
            $emails = 'ritu.singh@velocis.co.in';
            $maildata  = ['send_message' => "Your Application sent for NOC."];

            $m = date('m');
            $y = date('Y');
            $lst = rand('1000000','99999999');
            $app_no = "NOCAP".$y.$m."".$lst;

            if($request->noc_type=='Whole'){
                
                $data = array(
                    'at_user_id'=>$userId,
                    'noc_type'=>$request->noc_type,
                    'noc_application_no'=>$app_no,
                    'reason'=>$request->reason ?? null,
                    'ref_operator_type_id'=>Auth::guard('misadmin')->user()->ref_operator_type_id,
                    'noc_status'=>'Pending',
                    'created_by'=>$userId,
                    'applied_by'=>$userId,
                    'created_at'=>date('Y-m-d H:i:s'),
                    'applied_on'=>date('Y-m-d H:i:s'),
                );

                $saveData = AtOpNocDetails::create($data);
               //dd($saveData);
                Mail::send('mail.inspector_register', $maildata, function ($message) use ($emails) {  // use mail template in view/api folder
                    $message->subject("Apply NOC Application"); // Email subject body
                    $message->to('ritu.singh@velocis.co.in');
                });
                Alert::success('Success', __('message.add_success'));
            }else{
                
                if(!empty($request->lots)){
                    foreach($request->lots as $key=>$lot){
                   
                        if($request->lots[$key]!=''){
                            
                            $data = array(
                                'at_user_id'=>$userId,
                                'noc_type'=>$request->noc_type,
                                'noc_application_no'=>$app_no,
                                'reason'=>$request->remarks[$key] ?? null,
                                'ref_operator_type_id'=>Auth::guard('misadmin')->user()->ref_operator_type_id,
                                'at_farmer_reg_details_id'=>$request->at_ip_farmer_reg_details_id[$key] ?? null,
                                'noc_status'=>'Pending',
                                'created_by'=>$userId,
                                'applied_by'=>$userId,
                                'created_at'=>date('Y-m-d H:i:s'),
                                'applied_on'=>date('Y-m-d H:i:s'),
                            );
                            $saveData = AtOpNocDetails::create($data); 
                        }
                       
                    }
                    Mail::send('mail.inspector_register', $maildata, function ($message) use ($emails) {  // use mail template in view/api folder
                        $message->subject("Apply NOC Application"); // Email subject body
                        $message->to($emails);
                    });
                }
                Alert::success('Success', __('message.add_success'));
               
            }

            // $scopeData = CertificateStandardDetail::where('at_user_id',$userId)->first();
            // $farmerDetails = AtFarmerRegDetail::where('at_user_id',$userId)->get();
            return redirect()->route('superadmin.applyNOC');
           // return view('admin.noc.applynoc',compact('userId','currentCB','scopeData','farmerDetails','scopeValidity'));
           
		 }
        catch (Exception $e)
        {
            //dd($e->getMessage());
            Log::error($e->getMessage());
            abort('404');
        }
      
    }
	public function splitNOC(){
        $userId = Auth::guard('misadmin')->user()->id;
        $scopeValidity = $this->checkSpopeValidation($userId);
        if($scopeValidity < 7){
            Alert::success('','NOC can only be applied within the validity of scope certification.');
        }
        return view('admin.noc.splitnoc',compact('scopeValidity'));
    }

	public function nocSpltFarmer(Request $request){
        $userId = Auth::guard('misadmin')->user()->id;
        $farmerId = AtFarmerRegDetail::where('at_user_id',$userId)->where('registration_no',$request->regno)->first();
        $data = array();
        if(!empty($farmerId)){
            $farmDetails = AtFarmerLandDetail::where('at_farmer_reg_details_id',$farmerId->id)->get();
            if(!empty($farmDetails)){
                foreach($farmDetails as $key => $farm){
                    $data[$key]['id']= $farm->id;
                    $data[$key]['registration_no']= $farm->registration_no;
                    $data[$key]['farm_name']= $farm->farm_name;
                    $data[$key]['address']= getAddress('at_farm_details','id',$farm->id);
                    $data[$key]['area']= $farm->total_area;
                    $data[$key]['farmer_id']= $farm->at_farmer_reg_details_id;
                }
                return json_encode(['status' => 1,'data'=> $data]);
            }else{
                return json_encode(['status' => 0,'data'=> 'No Farm Found.']);
            }
        }else{
            return json_encode(['status' => 0,'data'=> 'No Farmer Found.']);
        }
    }

    public function nocSpltFarmStore(Request $request){
        //dd($request->all());
        $request->validate([
            'split_farmer_name.*' => 'required',
            'split_farmer_area.*' => 'required',
            'split_remark.*' => 'required',
        ]);

        try{
            $userId = Auth::guard('misadmin')->user()->id;
            
            $emails = 'ritu.singh@velocis.co.in';
            $maildata  = ['send_message' => "Mail have been sent successfully."];

            $m = date('m');
            $y = date('Y');
            $lst = rand('1000000','99999999');
            $app_no = "NOCAP".$y.$m."".$lst;

            foreach($request->split_farmer_name as $key=>$val){
                   
                if($request->split_farmer_name[$key]!=''){
                    
                    $data = array(
                        'at_user_id'=>$userId,
                        'noc_type'=>$request->noc_type,
                        'noc_application_no'=>$app_no,
                        //'reason'=>$request->remarks[$key] ?? null,
                        'split_farmer_name'=>$request->split_farmer_name[$key],
                        'split_farmer_area'=>$request->split_farmer_area[$key],
                        'split_remark'=>$request->split_remark[$key],
                        //'ref_operator_type_id'=>$request->ref_operator_type_id ?? 1,
                        'at_farmer_reg_details_id'=>$request->at_farmer_reg_details_id ?? null,
                        'at_farm_details_id'=>$request->at_farm_details_id ?? null,
                        'noc_status'=>'Pending',
                        'created_by'=>$userId,
                        'applied_by'=>$userId,
                        'created_at'=>date('Y-m-d H:i:s'),
                        'applied_on'=>date('Y-m-d H:i:s'),
                    );
                     echo "<pre>";
                     print_r($data);
                    //$saveData = AtOpNocDetails::create($data); 
                }
                
            }
            //dd('asdasasas');
            Mail::send('mail.inspector_register', $maildata, function ($message) use ($emails) {  // use mail template in view/api folder
                $message->subject("Apeda Split Farm"); // Email subject body
                $message->to($emails);
            });
            Alert::success('Success', __('message.add_success'));
            return redirect()->back();
        } catch (Exception $e) {
            dd($e->getMessage());
            Log::error($e->getMessage());
            abort('404');
        }
    }

}





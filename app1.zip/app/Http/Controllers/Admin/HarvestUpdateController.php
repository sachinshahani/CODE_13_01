<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Permission;
use App\Models\Role;
use App\Models\RoleUser;
use App\Models\User;
use App\Models\UserSelf;
use App\Models\UserInspector;
use App\Models\UserWarehouse;
use App\Models\UserWarehouseManagerOfficers;
use App\Models\RefState;
use App\Models\RefDistrict;
use App\Models\RefVillage;
use App\Models\RefRegion;
use App\Models\WildHarvesterBankDetail;
use App\Models\WildHarvesterDetail;
use App\Models\RefBank;
use App\Models\WildHarvesterDocument;
use App\Models\WildHarvesterForestDetail;
use App\Models\WildHarvesterForestProductDetail;
use App\Models\WildHarvesterPermittedForestAreaDetail;
use App\Models\AtClosingStock;
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;

class HarvestUpdateController extends Controller
{
    public function updateActualYield(Request $request)
	{

		$user_id = Auth::guard('misadmin')->user()->id;
        return view('admin.harvest_update.wh.update_actual_yield');
    }



    public function updateActualYieldScope(Request $request){
		$user_id = Auth::guard('misadmin')->user()->id;
        $harvester = User::find(Auth::guard('misadmin')->user()->id);
        $forest_details = WildHarvesterDetail::where('at_user_id',$user_id)->get();
        return view('admin.harvest_update.wh.update_actual_yield_scope',compact('harvester','forest_details'));
    }


	public function updateActualYieldProduct(Request $request,$id){
		$user_id = Auth::guard('misadmin')->user()->id;
        $harvester = User::find(Auth::guard('misadmin')->user()->id);
        $forest_detail = WildHarvesterDetail::where('id',$id)->first();
		$product_details = WildHarvesterForestProductDetail::where('at_wh_forest_details_id',$id)->get();
		//dd($product_details);
        return view('admin.harvest_update.wh.update_actual_yield_products',compact('id','harvester','forest_detail','product_details'));
    }

	public function updateActualYieldHarvestHistory(Request $request){
		$user_id = Auth::guard('misadmin')->user()->id;
        $harvester_history = User::join('at_wh_forest_details','at_wh_forest_details.at_user_id','at_user.id')
		->join('at_wh_forest_product_details','at_wh_forest_product_details.at_wh_forest_details_id','at_wh_forest_details.id')
		->get();
        //$forest_detail = WildHarvesterDetail::where('id',$id)->first();
		//$product_details = WildHarvesterForestProductDetail::where('at_wh_forest_details_id',$id)->get();
        return view('admin.harvest_update.wh.update_actual_yield_harvest_history',compact('harvester_history'));
    }

     public function editHarvestProduct(Request $request)
	{

			$product_detail = WildHarvesterForestProductDetail::where('id',$request->product_id)->first();

		return  view('admin.harvest_update.wh.tpl_edit_product',compact('product_detail'))->render();
	}

	public function storeHarvestProduct(Request $request)
	{
		$validator = \Validator::make($request->all(), [
            'actual_harvest_yield' => 'required',
            'harvest_date' => 'required',
            'product_id' => 'required',
        ]);

        if ($validator->fails())
        {
            return response()->json(['errors'=>$validator->errors()->all()]);
        }

		try {
				 $insertData = array(
					'actual_harvest_yield' =>  $request->actual_harvest_yield,
					'harvest_date' => date('Y-m-d',strtotime($request->harvest_date)),
				 );
				 $insertData['updated_at'] = date('Y-m-d H:i:s');
				 $insertData['updated_by'] = Auth::guard('misadmin')->user()->id;

				 $product_detail = WildHarvesterForestProductDetail::find($request->product_id);
				 $product_detail->where('id',$request->product_id)->update($insertData);
				 $input_approval = WildHarvesterForestProductDetail::where('id',$request->product_id)->first();

				$insert_closing_stock = array(
					'at_wh_forest_product_details_id' => $input_approval->id,
					'ref_operator_type_id' => Auth::guard('misadmin')->user()->ref_operator_type_id,
					'at_user_id' => Auth::guard('misadmin')->user()->id,
					'organic_status' => $input_approval->organic_status,
					'economic_part' => $input_approval->economic_part,
					'date_of_harvest' => date('Y-m-d',strtotime($input_approval->harvest_date)),
					'harvest_year' => date('Y'),
				);
				AtClosingStock::create($insert_closing_stock);

			return response()->json(['data'=>$input_approval,'success'=>'Data is successfully added']);

		} catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
	}







}





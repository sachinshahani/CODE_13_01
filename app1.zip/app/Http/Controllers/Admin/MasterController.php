<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\RefState;
use App\Models\RefDistrict;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use DataTables;
use DB;
use Exception;
use RealRashid\SweetAlert\Facades\Alert;
use Validator;


class MasterController extends Controller
{
    public function index(Request $request){

        $state = RefState::orderBy('created_at', 'asc')->get();
        if($request->ajax()){

            return DataTables::of($state)
            ->addIndexColumn()
            ->addColumn('action', function($data){
                $btn = '<a href='.route('superadmin.master.stateedit', [$data->id]).'><span><i class="mdi mdi-account-edit text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Edit User"></i></span></a><a href="JavaScript:void(0);" data-href="'.route('superadmin.master.statedelete',[$data->id]).'" class="deletedata" data-value="'.$data->id.'"><span><i class="mdi mdi-delete-circle text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Delete"></i></span></a>';
                return $btn;
            })
            ->editColumn('state_code', function ($data) {
                return $data->state_code ?? '';
             })

             ->editColumn('state_short_name', function ($data) {
                return $data->state_short_name ?? '';
             })
             ->editColumn('state_name', function ($data) {
                return $data->state_name ?? '';
             })

            ->rawColumns(['action'])
            ->make(true);

        }
            return view('admin\master\state\index');

    }

    public function create(Request $request)
    {
    abort_unless(\Gate::allows('user_access'), 403);
    return view('admin\master\state\create');
    }

    public function store(Request $request)
    {
        // dd($request);
        $request->validate([
            'state_code' => 'required',
            'state_short_name' => 'required',
            'state_name' => 'required'
        ]);
        try
        {
                $data = array(
                    'state_code' => $request->state_code,
                    'state_short_name' => $request->state_short_name,
                    'state_name' => $request->state_name,
                    'created_by' => Auth::guard('misadmin')->user()->id
                );

                RefState::create($data);
                Alert::success('Success', 'Successfully Inserted');
                return redirect()->back();
            }
            catch (Exception $e)
            {
                Log::error($e->getMessage());
                abort('404');
             }
        }


    public function edit($id)
    {
        abort_unless(\Gate::allows('user_access'), 403);
        $data = RefState::where('id',$id)->first();
        return view('admin\master\state\edit',compact('data'));
        }


    public function update(Request $request, $id)
    {
        abort_unless(\Gate::allows('user_access'), 403);

            try
            {
            $updateData = array(
                'state_code' => $request->state_code,
                'state_short_name' => $request->state_short_name,
                'state_name' => $request->state_name,
                'updated_by' =>Auth::guard('misadmin')->user()->id
            );

            RefState::where('id',$id)->update($updateData);
            Alert::success('Success', 'Update Successfully');
            return redirect()->back();
            }
            catch (Exception $e)
            {
            Log::error($e->getMessage());
            abort('404');
            }
            }

    public function delete(Request $request){
        RefState::where('id',$request->id)->delete();
        return 1;
    }



   public function districtList(Request $request)
   {
    $district = RefDistrict::orderBy('created_at', 'asc')->get();
    // dd($district);
    if($request->ajax()){

        return DataTables::of($district)
        ->addIndexColumn()
        ->addColumn('action', function($row){
            $btn = '<a href='.route('superadmin.master.districtedit', [$row->id]).'><span><i
            class="mdi mdi-account-edit text-muted fs-16 align-middle me-1" data-toggle="tooltip"
            title="Edit User"></i></span></a><a href="JavaScript:void(0);"
            data-href="'.route('superadmin.master.districtdelete',[$row->id]).'" class="deletedata"
            data-value="'.$row->id.'"><span><i class="mdi mdi-delete-circle text-muted fs-16 align-middle me-1"
            data-toggle="tooltip" title="Delete"></i></span></a>';
            return $btn;
        })
        ->editColumn('district_code', function ($row) {
            return $row->district_code ?? '';
         })

         ->editColumn('ref_state_id', function ($row) {
            return getStateName($row->ref_state_id ?? '');
         })
         ->editColumn('district_name', function ($row) {
            return $row->district_name ?? '';
         })

        ->rawColumns(['action'])
        ->make(true);

   }
    return view('admin\master\district\index');



   }

   public function districtcreate(Request $request)
   {
   abort_unless(\Gate::allows('user_access'), 403);
   $state = RefState::get();
   return view('admin\master\district\create',compact('state'));

   }



   public function districtStore(Request $request)
   {
    // dd($request);

            $request->validate([
                'district_code' => 'required',
                'ref_state_id' => 'required',
                'district_name' => 'required'
            ]);
            try
            {
                    $data = array(
                        'district_code' => $request->district_code,
                        'ref_state_id' => $request->ref_state_id,
                        'district_name' => $request->district_name,
                        'created_by' => Auth::guard('misadmin')->user()->id
                    );

                    RefDistrict::create($data);
                    Alert::success('Success', 'Successfully Inserted');
                    return redirect()->back();
                }
                catch (Exception $e)
                {
                    Log::error($e->getMessage());
                    abort('404');
                }
            }

    public function districtedit($id)
    {
        abort_unless(\Gate::allows('user_access'), 403);
        $states = RefState::get();
        $district = RefDistrict::where('id',$id)->first();
        return view('admin\master\district\edit',compact('district','states'));
        }




    public function districtupdate(Request $request, $id)
    {
        // dd($request);
        try
        {
        $updateData = array(
            'state_code' => $request->state_code,
            'state_short_name' => $request->state_short_name,
            'state_name' => $request->state_name,
            'updated_by' =>Auth::guard('misadmin')->user()->id
        );

        RefDistrict::where('id',$id)->update($updateData);
        Alert::success('Success', 'Update Successfully');
        return redirect()->back();
        }
        catch (Exception $e)
        {
        Log::error($e->getMessage());
        abort('404');
        }


    }

   public function districtdelete(Request $request){
    RefDistrict::where('id',$request->id)->delete();
    return 1;
}



}

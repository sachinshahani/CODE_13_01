<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Mail\RecordDeletedMail;
use App\Models\Permission;
use App\Models\Role;
use App\Models\User;
use App\Models\RefState;
use App\Models\CBStatewiseRestriction;
use App\Models\AtOrganicOperator;
use App\Models\RefDistrict;
use App\Models\RefVillage;
use App\Models\RefRegion;
use App\Models\RoleUser;
use App\Models\UserInspector;
use App\Models\IcsMandator;
use App\Models\MandatorRegister;
use App\Models\AtFarmerRegDetail;
use App\Models\UserWarehouse;
use App\Models\UserWarehouseManagerOfficers;
use App\Models\FarmersRegSchedule;
use App\Models\IndividualProducerFarmerDetail;
use App\Models\GeoTaggingProcessorDetail;
use App\Models\ProcessorProductDetail;
use App\Models\ProcessorDocument;
use App\Models\AtOpNocDetails;
use App\Models\CertificateStandardDetail;
use App\Models\AtOspIcsIndividual;
use App\Models\AtFarmerLandDetail;
use App\Models\DeletionLog;
use App\Models\AtBatchDetail;
use App\Models\AtInternalStockTransfe;
use App\Models\AtOpTransactionVsTransactionProduct;
use App\Models\AtOpTransactionCertificateEntry;
use App\Models\AtOpCertificateStandardDetail;
use Yajra\DataTables\DataTables;
use RealRashid\SweetAlert\Facades\Alert;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\DB;
use App\Exports\DeptUserExport;
use App\Models\AtBatchCreation;
use App\Models\SourceDetails;
use App\Models\UserVerification;
use App\Models\RefDesignation;
use Illuminate\Support\Facades\Log;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\File;
use Mpdf\Mpdf;
use PDF;
use QrCode;
use Exception;
use Illuminate\Support\Facades\Notification;
use App\Notifications\ScopeAmendedNotification;
use App\Notifications\OperatorSuspensionTerminationNotification;
//use Carbon;
use Carbon\Carbon;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Crypt;
use App\Models\Employee\EmployeeModule;
use App\Models\Employee\ModuleMapping;
use App\Models\RefModule;
use App\Models\RefSubmodule;
use App\Models\RefQualification;
use App\Models\AtUserLoginDetails;
use App\Models\AtAccrediationCertificationBody;
use App\Models\AtUserRegistrationDetails;
use App\Models\AtCertificationBodyEmployeeDetails;
use App\Models\IndividualProducerDocument;
use App\Models\IndividualProducerFarmDetail;
use App\Models\IndividualProducerGeoTagging;
use App\Models\IndividualProducerDetailOfStandingCorp;
use App\Models\IndividualProducerDetailOfProposedCorp;




class UserManagementController extends Controller
{
    //
    public function rolesList(Request $request)
    {
        // abort_unless(\Gate::allows('role_access'), 403);
        if ($request->ajax()) {
            $columns = [
                0 => 'id',
                1 => 'zone_name',
                2 => 'zone_code',
            ];
            $totalData = Role::count();
            $totalFiltered = $totalData;
            $limit = $request->input('length');
            $start = $request->input('start');
            $order = $columns[$request->input('order.0.column')];
            $dir = $request->input('order.0.dir');
            // DB::enableQueryLog();
            if (empty($request->input('search.value'))) {
                $role = Role::with('permissions')->offset($start)
                    ->limit($limit)
                    ->orderBy($order, $dir)
                    ->get();
            } else {
                $search = $request->input('search.value');
                $role = Role::with('permissions')->where(function ($query) use ($search) {
                    $query->where('title', 'LIKE', "%{$search}%");
                })
                    ->offset($start)
                    ->limit($limit)
                    ->orderBy($order, $dir)
                    ->get();
                $totalFiltered = Role::where(function ($query) use ($search) {
                    $query->where('title', 'LIKE', "%{$search}%");
                })
                    ->count();
            }



            // print_r(DB::getQueryLog());die();

            $data = [];
            if (!empty($role)) {
                $count = 0;
                foreach ($role as $key => $rolevalue) {
                    //dd($rolevalue->permissions);
                    $nestedData['id'] = $count + $start + 1;
                    $nestedData['title'] = $rolevalue->title;
                    $nestedData['action'] = '<a href=' . route('superadmin.usermanagement.permissionEdit', $rolevalue->id) . '><span><i class="mdi mdi-pencil text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Edit Role"></i></span></a>';
                    $data[] = $nestedData;
                    $count++;
                }
            }
            $json_data = [
                'draw' => intval($request->input('draw')),
                'recordsTotal' => intval($totalData),
                'recordsFiltered' => intval($totalFiltered),
                'data' => $data,
            ];
            echo json_encode($json_data);
            exit;
        }

        return view('admin/usermanagement/roles/rolesList');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function createRole()
    {
        // abort_unless(\Gate::allows('role_create'), 403);
        $permission = Permission::get();
        return view('admin/usermanagement/roles/create', compact('permission'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function storeRole(Request $request)
    {
        // abort_unless(\Gate::allows('role_create'), 403);
        $this->validate($request, [
            'title' => 'required|unique:roles,title',
            'permission.*' => 'required',
        ]);


        $role = Role::create(['title' => $request->input('title')]);
        //$role->syncPermissions($request->input('permission'));
        $role->permissions()->sync($request->input('permissions', []));


        return redirect()->route('superadmin.usermanagement.roles')
            ->with('success', 'Role created successfully');
    }

    public function rolesPermissionEdit(Role $role)
    {
        $permissions = Permission::get();
        $role->load('permissions');

        return view('admin/usermanagement/roles/edit', compact('permissions', 'role'));
    }

    public function roleupdate(Request $request, Role $role)
    {
        //pr($request->all());
        $role->update($request->all());
        $role->permissions()->sync($request->input('permissions', []));

        return redirect()->route('superadmin.usermanagement.roles');
    }

    public function permission(Request $request)
    {
        // abort_unless(\Gate::allows('permission_access'), 403);
        if ($request->ajax()) {
            $columns = [
                0 => 'id',
                1 => 'title',
            ];
            $totalData = Permission::count();
            $totalFiltered = $totalData;
            $limit = $request->input('length');
            $start = $request->input('start');
            $order = $columns[$request->input('order.0.column')];
            $dir = $request->input('order.0.dir');
            // DB::enableQueryLog();
            if (empty($request->input('search.value'))) {
                $permission = Permission::offset($start)
                    ->limit($limit)
                    ->orderBy($order, $dir)
                    ->get();
            } else {
                $search = $request->input('search.value');
                $permission = Permission::where(function ($query) use ($search) {
                    $query->where('title', 'LIKE', "%{$search}%");
                })
                    ->offset($start)
                    ->limit($limit)
                    ->orderBy($order, $dir)
                    ->get();
                $totalFiltered = Permission::where(function ($query) use ($search) {
                    $query->where('title', 'LIKE', "%{$search}%");
                })
                    ->count();
            }
            // print_r(DB::getQueryLog());die();
            $data = [];
            if (!empty($permission)) {
                $count = 0;
                foreach ($permission as $key => $permissionvalue) {
                    //dd($rolevalue->permissions);
                    $nestedData['id'] = $count + $start + 1;
                    $nestedData['permission'] = $permissionvalue->title;
                    //$nestedData['action'] = '<a href='.route('superadmin.usermanagement.permissionEdit', $permissionvalue->id).'><span><i class="mdi mdi-pencil text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Edit Permission"></i></span></a>';
                    $data[] = $nestedData;
                    $count++;
                }
            }
            $json_data = [
                'draw' => intval($request->input('draw')),
                'recordsTotal' => intval($totalData),
                'recordsFiltered' => intval($totalFiltered),
                'data' => $data,
            ];
            echo json_encode($json_data);
            exit;
        }

        return view('admin/usermanagement/permission/permission');
    }

    public function deptUser(Request $request, $id)
    {
        //  dd(Auth::user()->roles);
        abort_unless(\Gate::allows('user_access'), 403);

        $userId = Auth::id();
        if ($request->ajax()) {
            // dd($request->all());

            if ($request->status != '' && $request->status != 'all') {
                $user = User::with('roles')->where('ref_operator_type_id', $id)->where('created_by', $userId)->where('status', $request->status)->orderBy('id', 'DESC')->get();
            } else {
                $user = User::with('roles')->where('ref_operator_type_id', $id)->where('created_by', $userId)->orderBy('id', 'DESC')
                    ->get();
            }
            //    dd($user);
            return Datatables::of($user)
                ->addIndexColumn()
                ->addColumn('name', function ($row) {
                    // $first_name = $row->first_name ?? '';
                    // $middle_name = $row->middle_name ?? '';
                    // $last_name = $row->last_name ?? '';
                    // return $first_name . ' ' . $middle_name . ' ' . $last_name;


                    $firstName = $row->first_name ?? '';
                    $lastName = $row->last_name ?? '';
                    $address = $row->address ?? '';
                    $pan = $row->user_name ?? '';
                    $pin = $row->pin ?? '';
                    $state = get_state_name($row->ref_state_id ?? '');

                    $actionBtn =
                        "<strong>PAN:</strong> " . $pan . "<br>" .
                        "<strong>Name:</strong> " . trim($firstName . ' ' . $lastName) . "<br>" .
                        "<strong>Address:</strong> " . $address . "<br>" .
                        "<strong>State:</strong> " . $state . "<br>" .
                        "<strong>Pin:</strong> " . $pin;



                    return $actionBtn;
                })
                ->addColumn('reg_no', function ($row) {
                    // if($row->ref_operator_type_id == 2 && $row->status==2){
                    //$st = getRegno($row->id,$row->ref_operator_type_id);
                    // }else{
                    // $st ="NA";
                    // }

                    $actionBtn =
                        "<strong>Reg No:</strong> " . ($row->registration_no ?? 'Not Allotted') . "<br>";

                    if ($row->registration_no === null || $row->registration_no === '') {
                        // If registration number is not allotted, also set Reg Date and Reg By as Not Allotted
                        $actionBtn .= "<strong>Reg Date:</strong> Not Allotted" . "<br>";
                        $actionBtn .= "<strong>Reg By:</strong> " . (getcbNameById($row->created_by ?? 'Not Available')) . "<br>";
                    } else {
                        // Otherwise, display the Reg Date and Reg By
                        $actionBtn .= "<strong>Reg Date:</strong> " . date('d-m-Y', strtotime($row->updated_at ?? '')) . "<br>";
                        $actionBtn .= "<strong>Reg By:</strong> " . (getcbNameById($row->created_by ?? 'Not Available')) . "<br>";
                    }

                    return $actionBtn;
                })->addColumn('application_no', function ($row) {



                    $actionBtn =
                        "<strong>App No:</strong> #" . str_pad($row->id, 5, "0", STR_PAD_LEFT) . "<br>" .
                        "<strong>App Date:</strong> " . date('d-m-Y', strtotime($row->created_at ?? '')) . "<br>" .
                        "<strong>App Time:</strong> " . ($row->created_at ?? '')->format('h:i:s A');


                    return $actionBtn;


                    //   return  '#' . str_pad($row->id, 5, "0", STR_PAD_LEFT);



                })->addColumn('contact_details', function ($row) {
                    $atExpire = $row->at_expire ? Carbon::parse($row->at_expire) : null;
                    $remainingTime = null;
                    if ($atExpire) {
                        $remainingTime = Carbon::now()->diffInSeconds($atExpire, false);
                    }
                    $certificateExists = AtOpCertificateStandardDetail::where('at_user_id', $row->id)->first();
                    if ($atExpire && Carbon::now()->greaterThanOrEqualTo($atExpire) && !$certificateExists && $row->login_status != 2) {
                        User::where('id', $row->id)->update(['login_status' => 2]);
                        $row->login_status = 2;
                    }

                    $addhar = $row->contact_person_aadhar_number;
                    if (preg_match('/^eyJpdiI6.*$/', $addhar)) {
                        try {
                            $addhar = Crypt::decrypt($addhar);
                        } catch (DecryptException $e) {
                            $addhar = 'Invalid Aadhar No';
                        }
                    }

                    $actionBtn =
                        "<strong>Name:</strong> " . ($row->contact_person_first_name ?? '') . " " . ($row->contact_person_last_name ?? '') . "<br>" .
                        "<strong>Designation:</strong> " . ($row->contact_designation ?? '') . "<br>" .
                        "<strong>Mobile No:</strong> " . ($row->contact_person_mobile_number ?? '') . "<br>" .
                        "<strong>Email Id:</strong> " . ($row->email ?? '') . "<br>";
                    //  "<strong>Aadhar No:</strong> " . maskAadhaarNumber($addhar). "<br>" .
                    //"<strong>Aadhaar No:</strong> " . maskAadhaarNumber($addhar);
                    //  "<strong>Remaining Time:</strong> <span class='remaining-time' data-seconds='{$remainingTime}'>" . gmdate("H:i:s", $remainingTime) . "</span>";

                    return $actionBtn;
                })
                ->addColumn('mobile', function ($row) {
                    return $row->contact_person_mobile_number ?? '';
                })

                ->addColumn('created_on', function ($row) {

                    return  date('d-m-Y', strtotime($row->created_at)) ?? '';
                })
                ->addColumn('ref_state_id', function ($row) {

                    return get_state_name($row->ref_state_id);
                })


                ->addColumn('status', function ($row) {
                    $status = '';
                    if ($row->status == 0)
                        return  '<span class="badge badge-soft-danger">Profile Incomplete</span>';
                    elseif ($row->status == 1)
                        return  '<span class="badge badge-soft-primary">Profile Completed</span>';
                    elseif ($row->status == 2)
                        return  '<span class="badge badge-soft-success">Approved</span>';
                    elseif ($row->status == 3)
                        return  '<span class="badge badge-soft-info">Rejected</span>';
                    elseif ($row->status == 4)
                        return  '<span class="badge badge-soft-warning">Review</span>';
                })
                ->addColumn('action', function ($row) use ($id) {
                    $oper_type = $row->ref_operator_type_id ?? '';
                    $addEditDetailButton = '';
                    // if($oper_type == 2){
                    //     $addEditDetailButton = '<a href='.route('superadmin.icsuser.step1', [$row->id]).'><span><i class="mdi mdi-pencil text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Edit Individual User"></i></span></a>';
                    // }else if($oper_type == 3){
                    //     $addEditDetailButton = '<a href='.route('superadmin.usermanagement.deptUser.individualUserAdd', [$row->id]).'><span><i class="mdi mdi-pencil text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Edit Individual User"></i></span></a>';
                    // }elseif($oper_type == 4){
                    //     $addEditDetailButton = '<a href='.route('superadmin.usermanagement.deptUser.wildHarvestUserAdd', [$row->id]).'><span><i class="mdi mdi-pencil text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Edit Individual User"></i></span></a>';
                    // }elseif($oper_type == 5){
                    //     $addEditDetailButton = '<a href='.route('superadmin.tradersUseredit', [$row->id]).'><span><i class="mdi mdi-pencil text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Edit Individual User"></i></span></a>';
                    // }elseif($oper_type == 6){
                    //     $addEditDetailButton = '<a href='.route('superadmin.processorUseredit', [$row->id]).'><span><i class="mdi mdi-pencil text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Edit Individual User"></i></span></a>';
                    // }
                    if (Auth::guard('misadmin')->user()->roles[0]->id == 1 && $row->status != 0) {
                        //if ics
                        if ($id == 2 && $row->status != 0) {
                            $addEditDetailButton .= '<a href=' . route('superadmin.usermanagement.deptUser.view', [$row->id]) . ' target="_blank"><span><i class="mdi mdi-eye text-muted fs-16 align-middle me-1" data-toggle="tooltip"  title="View User"></i></span></a>';
                        } else if ($id == 3 && $row->status != 0) {
                            $addEditDetailButton .= '<a href=' . route('superadmin.individualProducer.preview', [$row->id]) . ' target="_blank"><span><i class="mdi mdi-eye text-muted fs-16 align-middle me-1" data-toggle="tooltip"  title="View User"></i></span></a>';
                        } else if ($id == 4 && $row->status != 0) {
                            $addEditDetailButton .= '<a href=' . route('superadmin.wildHarvest.preview', [$row->id]) . ' target="_blank"><span><i class="mdi mdi-eye text-muted fs-16 align-middle me-1" data-toggle="tooltip"  title="View User"></i></span></a>';
                        } else if ($id == 5 && $row->status != 0) {
                            $addEditDetailButton .= '<a href=' . route('superadmin.traders.preview', [$row->id]) . ' target="_blank"><span><i class="mdi mdi-eye text-muted fs-16 align-middle me-1" data-toggle="tooltip"  title="View User"></i></span></a>';

                            // if trader
                        } else if ($id == 6 && $row->status != 0) {
                            // if processor

                            $addEditDetailButton .= '<a href=' . route('superadmin.usermanagement.deptUser.proview', [$row->id]) . ' target="_blank"><span><i class="mdi mdi-eye text-muted fs-16 align-middle me-1" data-toggle="tooltip"  title="View User"></i></span></a>';
                        } else {

                            $addEditDetailButton .= '<a href=' . route('superadmin.usermanagement.deptUser.view', [$row->id]) . ' target="_blank"><span><i class="mdi mdi-eye text-muted fs-16 align-middle me-1" data-toggle="tooltip"  title="View User"></i></span></a>';
                        }
                    }
                    if (Auth::guard('misadmin')->user()->roles[0]->id == 1) {
                        // $addEditDetailButton.= '<a href='.route('superadmin.usermanagement.deptUser.deptUserEdit', [$row->id]).' target="_blank"><span><i class="mdi mdi-pencil text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Edit Individual User"></i></span></a>';
                        $addEditDetailButton .= '<a href="JavaScript:void(0);" class="deletedata" data-value="' . $row->id . '"><span><i class="mdi mdi-delete-circle text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Delete User"></i></span></a>';
                    }
                    return $addEditDetailButton;
                })
                ->rawColumns(['action', 'role', 'status', 'contact_details', 'application_no', 'reg_no', 'name'])
                ->make(true);
        }

        return view('admin/usermanagement/deptUser/index', compact('id'));
    }

    //     public function export(Request $request, $id, $type)
    //     {
    //         $userId = Auth::id();

    //         // dd($userId );

    //         if ($request->status != '' && $request->status != 'all') {
    //             $user = User::with('roles')
    //                 ->where('ref_operator_type_id', $id)
    //                 ->where('created_by', $userId)
    //                 ->where('status', $request->status)
    //                 ->orderBy('id', 'DESC')
    //                 ->get();
    //         } else {
    //             $user = User::with('roles')
    //                 ->where('ref_operator_type_id', $id)
    //                 ->where('created_by', $userId)
    //                 ->orderBy('id', 'DESC')
    //                 ->get();
    //         }

    //         $export = new DeptUserExport($user);
    // dd($export);
    //         if ($type === 'excel') {
    //             return Excel::download($export, 'dept_users.xlsx');
    //         } elseif ($type === 'pdf') {
    //             return $export->download('dept_users.pdf', \Maatwebsite\Excel\Excel::MPDF);
    //         }
    //     }


    public function deptUserView(Request $request, $id)
    {

        $user = User::where('id', $id)->first();

        $icsmandator = IcsMandator::where('at_user_id', $id)->first();
        $userInsp = UserInspector::where('at_user_id', $id)->get();
        $warehs = UserWarehouse::where('at_user_id', $id)->first();
        $wmanager = UserWarehouseManagerOfficers::where('at_user_id', $id)->where('user_type', 'WM')->get();
        $pmanager = UserWarehouseManagerOfficers::where('at_user_id', $id)->where('user_type', 'PM')->get();
        $foanager = UserWarehouseManagerOfficers::where('at_user_id', $id)->where('user_type', 'FO')->get();
        $amanager = UserWarehouseManagerOfficers::where('at_user_id', $id)->where('user_type', 'AM')->first();
        $farmerDetails = AtFarmerRegDetail::where('at_user_id', $id)->get();

        $states = RefState::orderBy('state_name', 'ASC')->get();
        $districts = RefDistrict::orderBy('district_name', 'ASC')->get();

        //eMSigned Digital Signature Allow
        $eMSignedModuleResult = [
            'signedPath' => '',
            'status' => 'not_attempted',
        ];

        $hostName = request()->getSchemeAndHttpHost();

        $eMSignedModuleAlow = getUserDigitalSignatureModules(Auth::id(), 'SC');
        if ($eMSignedModuleAlow['status'] == 'success' && $eMSignedModuleAlow['isAllowed'] == '1') {
            $hostName = request()->getSchemeAndHttpHost();
            $checkSignedPDf = getDigitalSignedPdf(Auth::id(), basename($user->registration_certificate));
            if ($checkSignedPDf['status'] == 'success') {
                $eMSignedModuleResult = [
                    'signedPath' => $checkSignedPDf['signedPath'],
                    'status' => 'success',
                ];
            } else {
                $eMSignedModuleResult = [
                    'signedPath' => '',
                    'status' => 'failed',
                ];
            }
        }


        return view('admin/usermanagement/deptUser/view', compact('id', 'user', 'icsmandator', 'warehs', 'states', 'userInsp', 'wmanager', 'pmanager', 'foanager', 'amanager', 'districts', 'farmerDetails', 'eMSignedModuleResult', 'eMSignedModuleResult', 'hostName', 'eMSignedModuleAlow'));
    }



    public function previewpost(Request $request)
    {


        try {
            $user = User::where('id', $request->at_user_id)->first();
            // pra($user); die;
         
            $CBdata1 = AtAccrediationCertificationBody::where('at_user_id',Auth::guard('misadmin')->user()->id)->first();
           
            if ($request->status == 2) {
                $m = date('m', strtotime($user->created_at));
                $y = substr(date('Y', strtotime($user->created_at)), -2);
                $lst = str_pad($user->id, 5, "0", STR_PAD_LEFT);
                $st = "ORG/" . $m . $y . "/" . $lst;
                
                $flname = '/registration_certificate/' . $request->at_user_id . '_' . time() . '.pdf';

                $url =  asset('public/'.$flname);
                $qrcode = base64_encode(QrCode::format('svg')->size(200)->errorCorrection('H')->generate($url));
                // certificate issue 9 ;
                // $currentCount = User::whereNotNull('registration_no')->count();
                // $currentCount = User::where('status',2)->count();
                // $certificate_no = $currentCount + 1;
                // $autcbrnd = $certificate_no >= 10000 ? (string)$certificate_no : str_pad($certificate_no, 4, '0', STR_PAD_LEFT);

                $certificateNo = DB::select("SELECT public.generate_certificate_no() AS certificate_no");
                $generatedCertificateNo = $certificateNo[0]->certificate_no;
                $data = [
                    'reg_no' => !empty($st) ? $st : NULL,
                    'name' => !empty($user->first_name) ? $user->first_name : NULL,
                    'address' => !empty($user->address) ? $user->address : NULL,
                    'opr_type' => getOperatorTypeById($user->ref_operator_type_id),
                    'opr_type_id' => !empty($user->ref_operator_type_id) ? $user->ref_operator_type_id : NULL,
                    'status' => !empty($user->status) ? $user->status : 0,
                    'date_of_reg' => Carbon::parse($user->created_at)->format('d-m-Y'),
                    'contact' => !empty($user->mobile_no) ? $user->mobile_no : NULL,
                    'email' => !empty($user->email) ? $user->email : NULL,
                    'pan' => !empty($user->user_name) ? $user->user_name : NULL,
                    'cb_name' => Auth::guard('misadmin')->user()->first_name,
                    'cb_address' => Auth::guard('misadmin')->user()->address,
                    'issued_on' => date('d/m/Y'),
                    'qr_code' => $qrcode,
                    'cb_logo_path' => !empty($user->cb_logo_path) ? $user->cb_logo_path : NULL,
                    'randomnumber' => $generatedCertificateNo,
                    'accrediation' => !empty($CBdata1) ? $CBdata1 : NULL,
                ];
                


                $mpdf = new \Mpdf\Mpdf(['tempDir' => sys_get_temp_dir().DIRECTORY_SEPARATOR.'mpdf','default_font' => 'serif', 'format' => 'A4-P']);
                $mpdf->autoScriptToLang = true;
                $mpdf->autoLangToFont = true;
                $html = view('admin.usermanagement.pdf.regCertificate', $data)->render();
                $mpdf->WriteHTML($html);
                $mpdf->Output(public_path($flname));   
                //return $mpdf->Output();
                // return  view('admin.usermanagement.pdf.regCertificate', $data);
                User::where('id', $request->at_user_id)->update(['status' => $request->status, 'cb_reg_remarks' => $request->cb_remarks, 'registration_no' => $st, 'registration_certificate' => $flname,'certificate_no'=>$generatedCertificateNo]);

                // User::where('id',$request->at_user_id)->update(['registration_certificate'=>'/registration_certificate/'.$flname]);

            } else if ($request->status == 4) {
                // disable login
                User::where('id', $request->at_user_id)->update(['status' => $request->status, 'cb_reg_remarks' => $request->cb_remarks, 'login_status' => 0]);
            } else {
                User::where('id', $request->at_user_id)->update(['status' => $request->status, 'cb_reg_remarks' => $request->cb_remarks]);
            }
            Alert::success('Success', __('message.add_success'));
            return redirect()->route('superadmin.usermanagement.deptUser', $request->id);
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }



    // public function previewpost(Request $request)
    // {


    //     try {
    //         $user = User::where('id', $request->at_user_id)->first();
    //         //dd($user);
    //         if ($request->status == 2) {
    //             $m = date('m', strtotime($user->created_at));
    //             $y = substr(date('Y', strtotime($user->created_at)), -2);
    //             $lst = str_pad($user->id, 5, "0", STR_PAD_LEFT);
    //             $st = "ORG/" . $m . $y . "/" . $lst;
    //             $flname = '/registration_certificate/' . $request->at_user_id . '_' . time() . '.pdf';
    //             $flnamehindi = '/registration_certificate/registration_certificate_hindi/' . $request->at_user_id . '_' . time() . '.pdf';
    //             $qrcode = base64_encode(QrCode::format('svg')->size(200)->errorCorrection('H')->generate($flname));
    //             $autcbrnd = '00' . Auth::guard('misadmin')->user()->id;

    //             $data = [
    //                 'reg_no' => $st,
    //                 'name' => $user->first_name,
    //                 'address' => $user->address,
    //                 'opr_type' => getOperatorTypeById($user->ref_operator_type_id),
    //                 'status' => $user->status,
    //                 'date_of_reg' => $user->created_at,
    //                 'contact' => $user->mobile_no,
    //                 'email' => $user->email,
    //                 'pan' => $user->user_name,
    //                 'cb_name' => Auth::guard('misadmin')->user()->first_name,
    //                 'cb_address' => Auth::guard('misadmin')->user()->address,
    //                 'issued_on' => date('d/m/Y'),
    //                 'qr_code' => $qrcode,
    //                 'cb_logo_path' => $user->cb_logo_path,
    //                 'randomnumber' => $autcbrnd,
    //             ];

    //             // return  view('admin/usermanagement/pdf/regCertificateHindi', $data);
    //             $pdfhindi = PDF::loadView('admin/usermanagement/pdf/regCertificateHindi', $data)->setOptions(['font' => 'Noto Sans Devanagari']);
    //             $pdf = PDF::loadView('admin/usermanagement/pdf/regCertificate', $data);
    //             $pdf->save(public_path($flname));
    //             $pdfhindi->save(public_path($flnamehindi));


    //             User::where('id', $request->at_user_id)->update(['status' => $request->status, 'cb_reg_remarks' => $request->cb_remarks, 'registration_no' => $st, 'registration_certificate' => $flname, 'hindi_registration_certificate' => $flnamehindi]);

    //             // User::where('id',$request->at_user_id)->update(['registration_certificate'=>'/registration_certificate/'.$flname]);

    //         } else if ($request->status == 4) {
    //             // disable login
    //             User::where('id', $request->at_user_id)->update(['status' => $request->status, 'cb_reg_remarks' => $request->cb_remarks, 'login_status' => 0]);
    //         } else {
    //             User::where('id', $request->at_user_id)->update(['status' => $request->status, 'cb_reg_remarks' => $request->cb_remarks]);
    //         }
    //         Alert::success('Success', __('message.add_success'));
    //         return redirect()->route('superadmin.usermanagement.deptUser', $request->id);
    //     } catch (Exception $e) {
    //         Log::error($e->getMessage());
    //         abort('404');
    //     }
    // }

    public function deptUseradd(Request $request, $id)
    {

        $module_title = 'deptUseradd';
        $module_name = 'deptUseradd';

        $cbId =  Auth::guard('misadmin')->user()->id;
        $CBstateAssign = CBStatewiseRestriction::leftjoin('ref_state', 'ref_state.id', 'cb_statewise_restriction.ref_state_id')
            ->select('ref_state.id as refStateId', 'ref_state.state_name', 'cb_statewise_restriction.*')
            ->where('cb_id', $cbId)
            ->orderBy('ref_state_id', 'ASC')
            ->get();

        $states = RefState::orderBy('state_name', 'ASC')->get();


        $districts = RefDistrict::orderBy('district_name', 'ASC')->get();
        $regions = RefRegion::orderBy('block_tehsil_name', 'ASC')->get();
        $villages = RefVillage::orderBy('village_name', 'ASC')->limit(100)->get();

        return view('admin/usermanagement/deptUser/add', compact('id', 'states', 'districts', 'regions', 'villages', 'CBstateAssign', 'cbId'));
    }

    // public function deptUserstore(Request $request)
    // {
    //      //dd($request->all());
    //     $request->validate([
    //         'first_name' => 'required|max:50',
    //         // 'middle_name' => 'required',
    //         //'last_name' => 'required',
    //         'user_name' => 'required|unique:at_user',
    //         // 'password' => 'required',
    //         // 'confirm_password' => 'required',
    //         'contact_first_name' => 'required|max:25',
    //         'email' => 'required|email|unique:at_user',
    //         'contact_last_name' => 'required|max:25',
    //         //'mobile' => 'required|numeric|unique:at_user,contact_person_mobile_number',
    //         'address' => 'required',
    //         'district' => 'required',
    //         'village' => 'required',
    //         'taluka' => 'required',
    //         'state' => 'required',
    //         'pin_code' => 'required|numeric|digits:6',
    //         'entity_firm' => 'required',
    //         // 'ref_office_id' => 'required',
    //         'role_id' => 'required',
    //          'contact_person_aadhar_number' => 'required|numeric|digits:12|unique:at_user,contact_person_aadhar_number',


    //     ]);

    //     $roleID  = $request->role_id;
    //     $aadharno = Crypt::encrypt(base64_decode(urldecode($request->contact_person_aadhar_number)));

    //     if (User::where('ref_operator_type_id', $roleID)->where('email', $request->email)->count() > 0) 
    //     {
    //         // $request->validate([
    //         //     'email' => 'required|email|unique:at_user'

    //         // ]);
    //         // return back();

    //     }
    //     else if(User::where('ref_operator_type_id',$roleID)->where('mobile_no',$request->mobile_number)->count() > 0)
    //     {
    //         // $request->validate([
    //         //     'mobile' => 'required|unique:at_user,mobile_no'
    //         // ]);
    //         // return back();
    //     }

    //     else {
    //         try {
    //             $password = '';
    //             if ($request->role_id != 2) {
    //                 // $password = rand(100000,999999);
    //                 $password = 123456;
    //             } else {
    //                 $password = 123456;
    //             }

    //             // if ($request->password == $request->confirm_password) {
    //             $data = array(
    //                 'ref_operator_type_id' => $request->role_id,
    //                 'first_name' => $request->first_name,
    //                 'user_name' => $request->user_name,
    //                 'middle_name' => $request->middle_name,
    //                 'last_name' => $request->last_name,
    //                 'contact_person_first_name' => $request->contact_first_name,
    //                 'contact_person_middle_name' => $request->contact_middle_name,
    //                 'contact_person_last_name' => $request->contact_last_name,
    //                 'contact_person_mobile_number' => $request->mobile_number,
    //                 'contact_person_email' => $request->email,
    //                 'contact_person_aadhar_number' => $aadharno,
    //                 'email' => $request->email,
    //                 'password' => hash('sha256', $password),
    //                 'email' => $request->email,
    //                 'mobile_no' => $request->mobile_number,
    //                 'address' => $request->address,
    //                 'ref_village_id' => $request->village,
    //                 'ref_block_tehsil_id' => $request->taluka,
    //                 'ref_district_id' => $request->district,
    //                 'ref_state_id' => $request->state,
    //                 'standerd_type' => $request->standerd_type ?? '',
    //                 'contact_designation' => $request->contact_designation,
    //                 'entity_firm' => $request->entity_firm,
    //                 'contact_gender' => $request->contact_gender,
    //                 'contact_person_gender' => $request->contact_gender,
    //                 'pin' => $request->pin_code,
    //                 'user_type' => 1,
    //                 'status' => 0,
    //                 'created_by' => Auth::guard('misadmin')->user()->id
    //             );
    //             $user = User::create($data);

    //            // dd($request->all(), $user);
    //           // dd($user);
    //             if ($user) {
    //                 $user->roles()->attach($request->role_id);
    //             }

    //             $emails = $request->email;
    //             $maildata = array();

    //             if ($request->role_id != 2) {
    //                 $apklink = url('public/apeda-processor.apk');
    //                 $maildata  = ['send_message' => "<strong> Dear " . $user->first_name . " " . $user->last_name . "</strong><br>  We are delighted to welcome you to TraceNet - Organic Traceability System, an online platform designed to streamline operations and enhance efficiency specifically for organic product traceability. To begin utilizing the platform's benefits fully, we kindly request you to complete your profile and ensure compliance with the guidelines set by the National Program for Organic Production (NPOP).<br> Completing your profile accurately is crucial as it ensures precise representation of your organic business within our network. This information facilitates seamless communication, enhances collaboration, and enables us to register in the TraceNet system.<br> <br> To complete your profile and ensure compliance with NPOP guidelines,.<br> Your Credentials has given below :- <br><strong> Username : " . $request->mobile . " <br> <br><strong> Email : " . $request->email . " <br> Password : " . $password . "</strong> <br> <a href=" . $apklink . ">Click here </a>for download mobile application for farmer registration. "];
    //             } else {
    //                 $maildata  = ['send_message' => "Dear <strong> $request->first_name,</strong><br><br> We are delighted to welcome you to TraceNet - Organic Traceability System, an online platform designed to streamline operations and enhance efficiency specifically for organic product traceability. To begin utilizing the platform's benefits fully, we kindly request you to complete your profile and ensure compliance with the guidelines set by the National Program for Organic Production (NPOP).<br><br> Completing your profile accurately is crucial as it ensures precise representation of your organic business within our network. This information facilitates seamless communication, enhances collaboration, and enables us to register in the TraceNet system.<br> <br> To complete your profile and ensure compliance with NPOP guidelines, please follow these steps:<br><br> USER ID <strong> is your registered PAN </strong> card and <strong> Password : 123456 </strong> <br> <strong> Temporary Reg. No. ORG/0124/00" . $user->id . " </strong> <br> <strong> Registered Date: " . date('d-M-Y', strtotime($user->created_at)) . " </strong><br><br>
    //                     <br>
    //                     1. Log in to the TraceNet - Organic Traceability System using the credentials provided during registration.
    //                     <br>
    //                     2. Navigate to the profile section.
    //                     <br>
    //                     3. Fill in all the required fields with accurate information. Ensure that the details provided are up-to-date and comprehensive.
    //                     <br>
    //                     4. Familiarize yourself with the guidelines outlined by the National Program for Organic Production (NPOP). Please visit APEDA website : https://apeda.gov.in or https://apeda.gov.in/apedawebsite/organic/ORGANIC_CONTENTS/National_Programme_for_Organic_Production.htm

    //                     <br>
    //                     5. Ensure that your profile information aligns with the NPOP guidelines, especially regarding organic production, processing, and labeling standards.
    //                     <br>
    //                     6. Once you have reviewed and verified the information, submit your profile for approval.
    //                     <br>
    //                     Upon submission, our team will promptly review your profile and verify its compliance with NPOP guidelines. Approval will grant you access to the full range of features and functionalities offered by TraceNet - Organic Traceability System.
    //                     <br>
    //                     <br>

    //                     Should you encounter any difficulties during the registration process, require assistance, or need clarification regarding NPOP guidelines, please do not hesitate to contact CB <strong>" . Auth::guard('misadmin')->user()->first_name . "</strong>. We are here to assist you every step of the way.
    //                     <br>
    //                     <br>
    //                     Note: This is an automated email. Please do not reply.

    //                     <br>
    //                     <br>

    //                     Regards/-
    //                     <br>
    //                     <br>

    //                     APEDA - TraceNet - Organic Traceability System"];
    //             }
    //             // dd($maildata);
    //             switch ($user->ref_operator_type_id) {
    //                 case 2:
    //                     $regNum = 'ICS00' . $user->id;
    //                     break;
    //                 case 3:
    //                     $regNum = 'IP00' . $user->id;
    //                     break;
    //                 case 4:
    //                     $regNum = 'WH00' . $user->id;
    //                     break;
    //                 case 5:
    //                     $regNum = 'TRA00' . $user->id;
    //                     break;
    //                 case 6:
    //                     $regNum = 'PRO00' . $user->id;
    //                     break;
    //                 default:
    //                     $regNum = '';
    //             }
    //             Mail::send('mail.inspector_register', $maildata, function ($message) use ($emails) {  // use mail template in view/api folder
    //                 $message->subject("Registration in TraceNet - Organic Traceability System - Complete Your Profile and Follow NPOP Guidelines"); // Email subject body
    //                 $message->to($emails);
    //             });


    //             // Send SMS with user credentials

    //             $this->sendLoginDetailsSms($request->mobile_number, $request->first_name, $request->user_name);

    //             Alert::success('Success', "$regNum Registered Successfully.");
    //             return redirect()->route('superadmin.usermanagement.deptUser', $user->ref_operator_type_id);
    //         } catch (Exception $e) {
    //             Log::error($e->getMessage());
    //             abort('404');
    //         }
    //     }
    // }

    public function deptUserstore(Request $request)
    {
        $checkPanUser = User::where('ref_operator_type_id', $request->role_id)->where('status', '!=', 3)->where('user_name', $request->user_name)->first();
        if (isset($checkPanUser)) {
            Alert::Warning('Warning', "Already user PAN Number");
            return redirect()->back();
        }

        DB::beginTransaction();
        try {
            $request->validate([
                'first_name' => 'required',
                'contact_first_name' => 'required',
                'contact_last_name' => 'required',
                'address' => 'required',
                'district' => 'required',
                'village' => 'required',
                'taluka' => 'required',
                'state' => 'required',
                'pin_code' => 'required',
                'entity_firm' => 'required',
                'role_id' => 'required',
                // 'user_name' => 'required|unique:at_user,user_name',
                // 'middle_name' => 'required',
                //'last_name' => 'required',
                // 'password' => 'required',
                // 'confirm_password' => 'required',
                // 'ref_office_id' => 'required',
                // 'mobile' => 'required',
            ]);

            $roleID  = $request->role_id;
            // if ($roleID >= 2 && $roleID <= 5) { 
            //     $existingRegistration = User::where('user_name',$request->user_name)
            //               ->Where('fssai_licence', $request->fssai_licence)
            //               ->Where('ayush_licence', $request->ayush_licence)
            //               ->Where('forest_licence', $request->forest_licence)
            //               ->first();

            //             //   dd($existingRegistration);

            //     if ($existingRegistration) {
            //         Alert::error('error', "You cannot register with the same PAN or FSSAI/AYUSH/Forest License.");
            //         return redirect()->back();
            //     }

            //    } elseif ($roleID == 6) {  
            //     $existingFSSAI = User::where('fssai_licence', $request->fssai_licence)->first();
            //     $existingAYUSH = User::where('ayush_licence', $request->ayush_licence)->first();
            //     if ($existingFSSAI) {
            //         Alert::error('error', "FSSAI license must be unique. This FSSAI is already registered.");
            //         return redirect()->back();
            //     }
            //     if ($existingAYUSH) {
            //         Alert::error('error', "AYUSH license must be unique. This AYUSH is already registered.");
            //         return redirect()->back();
            //     }
            // }

            // Forest License No.   Case When will be new user Add this work Roles =  4 Only
            $forestdocpath =  NULL;
            $IECODE_details_path =  NULL;
            $ayushlicensefile =  NULL;
            switch ($roleID) {
                case 4:

                    //    $result12 =  $request->validate([
                    //         'forest_licence' => 'required',
                    //         'forest_doc_path' => 'required'

                    //     ]);

                    //     if ($result12) {
                    //         Alert::warning('Warning', "forest licence & forest_doc required.");
                    //         return redirect()->back();
                    //     }
                    $documentRootPath = public_path('forest_licence_detail/Doc');
                    if (!file_exists($documentRootPath)) {
                        mkdir($documentRootPath, 0777, true);
                    }
                    if ($request->hasFile('forest_doc_path')) {
                        $file_path = time() . rand() . '.' . $request->file('forest_doc_path')->getClientOriginalExtension();
                        $request->file('forest_doc_path')->move($documentRootPath, $file_path);
                        $forestdocpath = $file_path;
                    } else {
                        $forestdocpath = '';
                    }
                    break;

                case 5:

                    // $result13 = $request->validate([
                    //     //'fssai_licence' => 'required|unique:at_user,fssai_licence',
                    //     'fssai_validity' => 'required',
                    //     // 'iecode' => 'required',
                    //     'icode_attachment' => 'required|file|mimes:pdf,png,jpg,jpeg|max:2048',

                    // ]);

                    // if ($result13) {
                    //     Alert::warning('Warning', "Fssai licence required.");
                    //     return redirect()->back();
                    // }

                    $documentRootPath = public_path('IECODE_details/Doc');
                    if (!file_exists($documentRootPath)) {
                        mkdir($documentRootPath, 0777, true);
                    }
                    if ($request->hasFile('icode_attachment')) {
                        $file_path = time() . rand() . '.' . $request->file('icode_attachment')->getClientOriginalExtension();
                        $request->file('icode_attachment')->move($documentRootPath, $file_path);
                        $IECODE_details_path = $file_path;
                    } else {
                        $IECODE_details_path = '';
                    }
                    break;

                case 6:
                    $documentRootPath = public_path('ayush_licence_path/Doc');
                    if (!file_exists($documentRootPath)) {
                        mkdir($documentRootPath, 0777, true);
                    }
                    if ($request->hasFile('ayush_license_file')) {
                        $file_path = time() . rand() . '.' . $request->file('ayush_license_file')->getClientOriginalExtension();
                        $request->file('ayush_license_file')->move($documentRootPath, $file_path);
                        $ayushlicensefile = $file_path;
                    } else {
                        $ayushlicensefile = '';
                    }

                    break;
            }

            // addhar encrpt funtion
            $aadharno = Crypt::encrypt($request->contact_person_aadhar_number);
            // $contactPersonAadharNumberEncoded = $request->contact_person_aadhar_number;
            // if (isValidBase64(urldecode($contactPersonAadharNumberEncoded))) {
            //     $contactPersonAadharNumber = base64_decode(urldecode($contactPersonAadharNumberEncoded));
            //     $aadharno = Crypt::encrypt($contactPersonAadharNumber);
            // } else {
            //     return redirect()->back();
            // }
            //end addhar encrpt funtion



            if (User::where('ref_operator_type_id', $roleID)->where('email', $request->email)->count() > 0) {
                Alert::Warning('Warning', "Email already taken");
                return redirect()->back();
            } else {
                $password = '';
                if ($request->role_id != 2) {
                    // $password = rand(100000,999999);
                    $password = 123456;
                } else {
                    $password = 123456;
                }
                $data = array(
                    'ref_operator_type_id' => !empty($request->role_id) ? $request->role_id : NULL,
                    'first_name' => !empty($request->first_name) ? $request->first_name : NULL,
                    'middle_name' => !empty($request->middle_name) ? $request->middle_name : NULL,
                    'last_name' => !empty($request->last_name) ? $request->last_name : NULL,
                    'contact_person_first_name' => !empty($request->contact_first_name) ? $request->contact_first_name : NULL,
                    'contact_person_middle_name' => !empty($request->contact_middle_name) ? $request->contact_middle_name : NULL,
                    'contact_person_last_name' => !empty($request->contact_last_name) ? $request->contact_last_name : NULL,
                    'contact_person_mobile_number' => !empty($request->mobile_number) ? $request->mobile_number : NULL,
                    'contact_person_email' => !empty($request->email) ? $request->email : NULL,
                    'contact_person_aadhar_number' => !empty($aadharno) ? $aadharno : NULL,
                    'user_name' => !empty($request->user_name) ? $request->user_name : NULL,
                    'password' => hash('sha256', $password),
                    'email' => !empty($request->email) ? $request->email : NULL,
                    'mobile_no' => !empty($request->mobile) ? $request->mobile : NULL,
                    'address' => !empty($request->address) ? $request->address : NULL,
                    'ref_village_id' => !empty($request->village) ? $request->village : NULL,
                    'ref_block_tehsil_id' => !empty($request->taluka) ? $request->taluka : NULL,
                    'ref_district_id' => !empty($request->district) ? $request->district : NULL,
                    'ref_state_id' => !empty($request->state) ? $request->state : NULL,
                    'standerd_type' => !empty($request->standerd_type) ? $request->standerd_type : NULL,
                    'contact_designation' => !empty($request->contact_designation) ? $request->contact_designation : NULL,
                    'entity_firm' => !empty($request->entity_firm) ? $request->entity_firm : NULL,
                    'contact_gender' => !empty($request->contact_gender) ? $request->contact_gender : NULL,
                    'contact_person_gender' => !empty($request->contact_gender) ? $request->contact_gender : NULL,
                    'pin' => !empty($request->pin_code) ? $request->pin_code : NULL,
                    'created_at' => now(),
                    'at_expire' => Carbon::now()->addDays(180),

                    'forest_licence' => !empty($request->forest_licence) ? $request->forest_licence : NULL,
                    'forest_doc_path' => !empty($forestdocpath) ? $forestdocpath : NULL,


                    'fssai_licence' => !empty($request->fssai_licence) ? $request->fssai_licence : NULL,
                    'fssai_validity' => !empty($request->fssai_validity) ? $request->fssai_validity : NULL,
                    'iecode' => !empty($request->iecode) ? $request->iecode : NULL,
                    'icode_attachment' => !empty($IECODE_details_path) ? $IECODE_details_path : NULL,

                    'ayush_licence' => !empty($request->ayush_licence) ? $request->ayush_licence : NULL,
                    'ayush_validity' => !empty($request->ayush_validity) ? $request->ayush_validity : NULL,
                    'ayush_doc_path' => !empty($ayushlicensefile) ? $ayushlicensefile : NULL,

                    'user_type' => 1,
                    'status' => 0,
                    'created_by' => Auth::guard('misadmin')->user()->id //must required don't replace  created_by  Nahi to error marge login ke time isko har jgah add kro must important variables
                );
                $user = User::create($data);

                $user_id = User::latest()->first();
                $atuserloginDetailsData = [
                    'at_user_id' => !empty($user->id) ? $user->id : NULL,
                    'ref_operator_type_id' => !empty($request->role_id) ? $request->role_id : NULL,
                    'user_name' => !empty($request->user_name) ? $request->user_name : NULL,
                    'password' => hash('sha256', $password),
                    'user_type' => 1,
                    'status' => 0,
                    'created_at' => now(),
                    'created_by' => Auth::guard('misadmin')->user()->id,
                ];
                AtUserLoginDetails::create($atuserloginDetailsData);
                $atUserLoginDetails_id = AtUserLoginDetails::latest()->first();
                $atUserLoginDetails = [
                    'at_user_id' => !empty($atUserLoginDetails_id->at_user_id) ? $atUserLoginDetails_id->at_user_id : NULL,
                    'at_user_login_details_id' => !empty($atUserLoginDetails_id->id) ? $atUserLoginDetails_id->id : NULL,
                    'ref_operator_type_id' => !empty($request->role_id) ? $request->role_id : NULL,
                    'first_name' => !empty($request->first_name) ? $request->first_name : NULL,
                    'middle_name' => !empty($request->middle_name) ? $request->middle_name : NULL,
                    'last_name' => !empty($request->last_name) ? $request->last_name : NULL,
                    'mobile_no' => !empty($request->mobile) ? $request->mobile : NULL,
                    'email' => !empty($request->email) ? $request->email : NULL,
                    'address' => !empty($request->address) ? $request->address : NULL,
                    'ref_block_tehsil_id' => !empty($request->taluka) ? $request->taluka : NULL,
                    'ref_district_id' => !empty($request->district) ? $request->district : NULL,
                    'ref_state_id' => !empty($request->state) ? $request->state : NULL,
                    'pin' => !empty($request->pin_code) ? $request->pin_code : NULL,
                    'ref_village_id' => !empty($request->village) ? $request->village : NULL,
                    'contact_person_first_name' => !empty($request->contact_first_name) ? $request->contact_first_name : NULL,
                    'contact_person_middle_name' => !empty($request->contact_middle_name) ? $request->contact_middle_name : NULL,
                    'contact_person_last_name' => !empty($request->contact_last_name) ? $request->contact_last_name : NULL,
                    'contact_person_mobile_number' => !empty($request->mobile_number) ? $request->mobile_number : NULL,
                    'contact_person_gender' => !empty($request->contact_gender) ? $request->contact_gender : NULL,
                    'contact_person_aadhar_number' => !empty($aadharno) ? $aadharno : NULL,
                    'contact_person_email' => !empty($request->email) ? $request->email : NULL,
                    'standerd_type' => !empty($request->standerd_type) ? $request->standerd_type : NULL,
                    'contact_designation' => !empty($request->contact_designation) ? $request->contact_designation : NULL,
                    'contact_gender' => !empty($request->contact_gender) ? $request->contact_gender : NULL,
                    'aadhar_number' => !empty($aadharno) ? $aadharno : NULL,
                    'entity_firm' => !empty($request->entity_firm) ? $request->entity_firm : NULL,
                    'fssai_licence' => !empty($request->fssai_licence) ? $request->fssai_licence : NULL,
                    'ayush_licence' => !empty($request->ayush_licence) ? $request->ayush_licence : NULL,
                    'ayush_validity' => !empty($request->ayush_validity) ? $request->ayush_validity : NULL,
                    'forest_licence' => !empty($request->forest_licence) ? $request->forest_licence : NULL,
                    'iecode' => !empty($request->iecode) ? $request->iecode : NULL,
                    'fssai_validity' => !empty($request->fssai_validity) ? $request->fssai_validity : NULL,
                ];
                AtUserRegistrationDetails::create($atUserLoginDetails);
                $atUserRegistrationDetails_id = AtUserRegistrationDetails::latest()->first();

                if ($user) {
                    DB::commit();
                    if ($user) {
                        $user->roles()->attach($request->role_id);
                    }
                    $emails = $request->email;
                    $maildata = array();
                    if ($request->role_id != 2) {
                        $apklink = url('public/apeda-processor.apk');
                        $maildata  = ['send_message' => "<strong> Dear " . $user->first_name . " " . $user->last_name . "</strong><br>  We are delighted to welcome you to TraceNet - Organic Traceability System, an online platform designed to streamline operations and enhance efficiency specifically for organic product traceability. To begin utilizing the platform's benefits fully, we kindly request you to complete your profile and ensure compliance with the guidelines set by the National Program for Organic Production (NPOP).<br> Completing your profile accurately is crucial as it ensures precise representation of your organic business within our network. This information facilitates seamless communication, enhances collaboration, and enables us to register in the TraceNet system.<br> <br> To complete your profile and ensure compliance with NPOP guidelines,.<br> Your Credentials has given below :- <br><strong> Username : " . $request->mobile . " <br> <br><strong> Email : " . $request->email . " <br> Password : " . $password . "</strong> <br> <a href=" . $apklink . ">Click here </a>for download mobile application for farmer registration. "];
                    } else {
                        $maildata  = ['send_message' => "Dear <strong> $request->first_name,</strong><br><br> We are delighted to welcome you to TraceNet - Organic Traceability System, an online platform designed to streamline operations and enhance efficiency specifically for organic product traceability. To begin utilizing the platform's benefits fully, we kindly request you to complete your profile and ensure compliance with the guidelines set by the National Program for Organic Production (NPOP).<br><br> Completing your profile accurately is crucial as it ensures precise representation of your organic business within our network. This information facilitates seamless communication, enhances collaboration, and enables us to register in the TraceNet system.<br> <br> To complete your profile and ensure compliance with NPOP guidelines, please follow these steps:<br><br> USER ID <strong> is your registered PAN </strong> card and <strong> Password : 123456 </strong> <br> <strong> Temporary Reg. No. ORG/0124/00" . $user->id . " </strong> <br> <strong> Registered Date: " . date('d-M-Y', strtotime($user->created_at)) . " </strong><br><br>
                        <br>
                        1. Log in to the TraceNet - Organic Traceability System using the credentials provided during registration.
                        <br>
                        2. Navigate to the profile section.
                        <br>
                        3. Fill in all the required fields with accurate information. Ensure that the details provided are up-to-date and comprehensive.
                        <br>
                        4. Familiarize yourself with the guidelines outlined by the National Program for Organic Production (NPOP). Please visit APEDA website : https://apeda.gov.in or https://apeda.gov.in/apedawebsite/organic/ORGANIC_CONTENTS/National_Programme_for_Organic_Production.htm

                        <br>
                        5. Ensure that your profile information aligns with the NPOP guidelines, especially regarding organic production, processing, and labeling standards.
                        <br>
                        6. Once you have reviewed and verified the information, submit your profile for approval.
                        <br>
                        Upon submission, our team will promptly review your profile and verify its compliance with NPOP guidelines. Approval will grant you access to the full range of features and functionalities offered by TraceNet - Organic Traceability System.
                        <br>
                        <br>

                        Should you encounter any difficulties during the registration process, require assistance, or need clarification regarding NPOP guidelines, please do not hesitate to contact CB <strong>" . Auth::guard('misadmin')->user()->first_name . "</strong>. We are here to assist you every step of the way.
                        <br>
                        <br>
                        Note: This is an automated email. Please do not reply.

                        <br>
                        <br>

                        Regards/-
                        <br>
                        <br>

                        APEDA - TraceNet - Organic Traceability System"];
                    }

                    switch ($user->ref_operator_type_id) {
                        case 2:
                            $regNum = 'Grower-Group' . $user->id;
                            break;
                        case 3:
                            $regNum = 'IP00' . $user->id;
                            break;
                        case 4:
                            $regNum = 'WH00' . $user->id;
                            break;
                        case 5:
                            $regNum = 'TRA00' . $user->id;
                            break;
                        case 6:
                            $regNum = 'PRO00' . $user->id;
                            break;
                        default:
                            $regNum = '';
                    }

                    Mail::send('mail.inspector_register', $maildata, function ($message) use ($emails) {  
                        $message->subject("Apeda Register"); 
                        $message->to($emails);
                    });

                    $this->sendLoginDetailsSms($request->mobile_number, $request->first_name, $request->user_name);
                    Alert::success('Success', "$regNum Registered Successfully.");
                    return redirect()->route('superadmin.usermanagement.deptUser', $user->ref_operator_type_id);
                }
            }
        } catch (Exception $e) {
            DB::rollback();
            \Log::error('General Error: ' . $e->getMessage());
            // Alert::error('Error', 'An unexpected error occurred. Please try again later.');
            Alert::info('Information', 'Some required fields are missing. Please fill them out.');
            return redirect()->back()->with('loader', true);
        } catch (\Illuminate\Database\QueryException $exception) {
            DB::rollback();
            \Log::error('Database Error: ' . $exception->getMessage());
            Alert::error('Error', 'A database error occurred. Please check your input and try again.');
            return redirect()->back()->with('loader', true);
        } catch (\Swift_TransportException $e) {
            DB::rollback();
            \Log::error('Mail Sending Error: ' . $e->getMessage());
            Alert::error('Error', 'There was a problem sending the email. Please check your email settings.');
        }
    }

    // public function deptUserstore(Request $request)
    // {   


    //     // Validate the request data
    //     $request->validate([
    //         'first_name' => 'required|max:25',
    //         'contact_first_name' => 'required|max:25',
    //         'contact_last_name' => 'required|max:25',
    //         'address' => 'required',
    //         'district' => 'required',
    //         'village' => 'required',
    //         'taluka' => 'required',
    //         'state' => 'required',
    //         'pin_code' => 'required|numeric|digits:6',
    //         'entity_firm' => 'required',
    //         'role_id' => 'required',
    //     ]);

    //     $roleID = $request->role_id;
    //     $aadharno = Crypt::encrypt(base64_decode(urldecode($request->contact_person_aadhar_number)));
    //     if ($roleID == 4) {
    //         $request->validate([
    //             'forest_licence' => 'required|unique:at_user,forest_licence',
    //             'forest_doc_path' => 'required|file|mimes:pdf,png,jpg,jpeg|max:2048',
    //         ], [
    //             'forest_licence.required' => 'Forest Licence is required.',
    //             'forest_licence.unique' => 'Forest Licence has already been taken.',
    //             'forest_doc_path.required' => 'Forest document is required.',
    //             'forest_doc_path.mimes' => 'Forest document must be a file of type: pdf, png, jpg, jpeg.',
    //             'forest_doc_path.max' => 'Forest document size should not exceed 2MB.',
    //         ]);

    //     } elseif ($roleID == 5 || $roleID == 6) {
    //         $request->validate([
    //             'fssai_licence' => 'required|unique:at_user,fssai_licence',
    //             'fssai_doc_path' => 'required|file|mimes:pdf,png,jpg,jpeg|max:2048',

    //             'ayush_licence' => 'required|unique:at_user,ayush_licence',
    //             'ayush_validity' => 'required|date',
    //             'ayush_doc_path' => 'required|file|mimes:pdf,png,jpg,jpeg|max:2048',

    //             'iecode' => 'required|unique:at_user,iecode'
    //         ], [
    //             'fssai_licence.required' => 'FSSAI License is required.',
    //             'fssai_licence.unique' => 'FSSAI License has already been taken.',
    //             'fssai_doc_path.required' => 'FSSAI document is required.',
    //             'fssai_doc_path.mimes' => 'FSSAI document must be a file of type: pdf, png, jpg, jpeg.',
    //             'fssai_doc_path.max' => 'FSSAI document size should not exceed 2MB.',

    //             'ayush_licence.required' => 'AYUSH License is required.',
    //             'ayush_licence.unique' => 'AYUSH License has already been taken.',
    //             'ayush_validity.date' => 'AYUSH Validity must be a valid date.',

    //             'ayush_doc_path.required' => 'AYUSH document is required.',
    //             'ayush_doc_path.mimes' => 'AYUSH document must be a file of type: pdf, png, jpg, jpeg.',
    //             'ayush_doc_path.max' => 'AYUSH document size should not exceed 2MB.',

    //             'iecode.required' => 'IEC Code is required.',
    //             'iecode.unique' => 'IEC Code has already been taken.'
    //         ]);
    //     }

    //     try {
    //         // Handle file uploads for ayush_doc_path and forest_doc_path
    //         $ayushDocPath = null;
    //         $forestDocPath = null;
    //         $fssaiDocPath = null;

    //         // If ayush_doc_path is provided and valid, upload the file to 'ayush_licence' directory
    //         if ($request->hasFile('ayush_doc_path')) {
    //             $ayushDoc = $request->file('ayush_doc_path');

    //             // Sanitize the file name
    //             $ayushDocName = 'ayush_licence_' . preg_replace('/[^A-Za-z0-9_\-]/', '_', $request->ayush_licence) . '_' . time() . '.' . $ayushDoc->getClientOriginalExtension();

    //             // Create a directory for fssai_licence under the fssai_licence number
    //             $ayushDir = 'public/operator/ayush_licence/' . $request->ayush_licence;
    //             if (!\File::exists($ayushDir)) {
    //                 \File::makeDirectory($ayushDir, 0755, true);
    //             }

    //             // Store the file in the created directory
    //             try {
    //                 $ayushDocPath = $ayushDoc->move($ayushDir, $ayushDocName)->getPathname();

    //             } catch (\Exception $e) {
    //                 Log::error('File upload error: ' . $e->getMessage());
    //                 return back()->withErrors(['ayush_doc_path' => 'File upload failed.']);
    //             }

    //             // Optionally: You can log or further use $forestDocPath as the full path of the saved file
    //             Log::info('File uploaded successfully: ' . $ayushDocPath);
    //         }

    //         // If fssai_licence is provided and valid, handle the file upload similarly
    //         if ($request->hasFile('fssai_doc_path')) {
    //             $fssaiDoc = $request->file('fssai_doc_path');

    //             // Sanitize the file name
    //             $fssaiDocName = 'fssai_licence_' . preg_replace('/[^A-Za-z0-9_\-]/', '_', $request->fssai_licence) . '_' . time() . '.' . $fssaiDoc->getClientOriginalExtension();

    //             // Create a directory for fssai_licence under the fssai_licence number
    //             $fssaiDir = 'public/operator/fssai_licence/' . $request->fssai_licence;
    //             if (!\File::exists($fssaiDir)) {
    //                 \File::makeDirectory($fssaiDir, 0755, true);
    //             }

    //             // Store the file in the created directory
    //             try {
    //                 $fssaiDocPath = $fssaiDoc->move($fssaiDir, $fssaiDocName)->getPathname();

    //             } catch (\Exception $e) {
    //                 Log::error('File upload error: ' . $e->getMessage());
    //                 return back()->withErrors(['fssai_doc_path' => 'File upload failed.']);
    //             }

    //             // Optionally: You can log or further use $forestDocPath as the full path of the saved file
    //             Log::info('File uploaded successfully: ' . $fssaiDocPath);
    //         }
    //         // If forest_doc_path is provided and valid, upload the file to 'forest_licence' directory
    //         if ($request->hasFile('forest_doc_path')) {
    //             $forestDoc = $request->file('forest_doc_path');

    //             // Sanitize the file name
    //             $forestDocName = 'forest_licence_' . preg_replace('/[^A-Za-z0-9_\-]/', '_', $request->forest_licence) . '_' . time() . '.' . $forestDoc->getClientOriginalExtension();

    //             // Create a directory for forest_licence under the forest_licence number
    //             $forestDir = 'public/operator/forest_licence/' . $request->forest_licence;
    //             if (!\File::exists($forestDir)) {
    //                 \File::makeDirectory($forestDir, 0755, true);
    //             }

    //             // Store the file in the created directory
    //             try {
    //                 $forestDocPath = $forestDoc->move($forestDir, $forestDocName)->getPathname();

    //             } catch (\Exception $e) {
    //                 Log::error('File upload error: ' . $e->getMessage());
    //                 return back()->withErrors(['forest_doc_path' => 'File upload failed.']);
    //             }

    //             // Optionally: You can log or further use $forestDocPath as the full path of the saved file
    //             Log::info('File uploaded successfully: ' . $forestDocPath);
    //         }




    //         // Prepare data to be saved
    //         $data = [
    //             'ref_operator_type_id' => $request->role_id,
    //             'first_name' => $request->first_name,
    //             'user_name' => $request->user_name,
    //             'middle_name' => $request->middle_name,
    //             'last_name' => $request->last_name,
    //             'contact_person_first_name' => $request->contact_first_name,
    //             'contact_person_middle_name' => $request->contact_middle_name,
    //             'contact_person_last_name' => $request->contact_last_name,
    //             'contact_person_mobile_number' => $request->mobile_number,
    //             'contact_person_email' => $request->email,
    //             'contact_person_aadhar_number' => $aadharno,
    //             'email' => $request->email,
    //             'password' => hash('sha256', '123456'), // Default password as per previous logic
    //             'address' => $request->address,
    //             'ref_village_id' => $request->village,
    //             'ref_block_tehsil_id' => $request->taluka,
    //             'ref_district_id' => $request->district,
    //             'ref_state_id' => $request->state,
    //             'standerd_type' => $request->standerd_type ?? '',
    //             'contact_designation' => $request->contact_designation,
    //             'entity_firm' => $request->entity_firm,
    //             'contact_gender' => $request->contact_gender,
    //             'contact_person_gender' => $request->contact_gender,
    //             'pin' => $request->pin_code,
    //             'user_type' => 1,
    //             'status' => 0,
    //             'created_by' => Auth::guard('misadmin')->user()->id,
    //             'fssai_licence' => $request->fssai_licence ?? '',
    //             'fssai_doc_path' => $fssaiDocPath ?? '',
    //             'ayush_licence' => $request->ayush_licence ?? '',
    //             'ayush_validity' => $request->ayush_validity ?? '',
    //             'ayush_doc_path' => $ayushDocPath ?? '',
    //             'iecode' => $request->iecode ?? '',
    //             'forest_licence' => $request->standerd_type ?? '',
    //             'forest_doc_path' => $forestDocPath ?? '', // Correctly set the forest document path

    //         ];
    //         //print_r($data); die;
    //         // Save the user data to the database
    //         $user = User::create($data);

    //         // Attach the role to the user
    //         if ($user) {
    //             $user->roles()->attach($request->role_id);
    //         }
    //          $password = 123456;
    //         // Step 7: Send Email based on role
    //         $emails = $request->email;
    //         $maildata = $this->prepareEmailData($user, $request->role_id, $password);

    //         // Uncomment if you are ready to send emails
    //         Mail::send('mail.inspector_register', $maildata, function ($message) use ($emails) {
    //           $message->subject("Registration in TraceNet - Organic Traceability System");
    //           $message->to($emails);
    //         });

    //         // Step 8: Send SMS with user credentials
    //         $this->sendLoginDetailsSms($request->mobile_number, $request->first_name, $request->user_name);

    //         // Step 9: Generate and display registration number
    //         $regNum = $this->generateRegistrationNumber($user);

    //         Alert::success('Success', 'User registered successfully.');
    //         return redirect()->route('superadmin.usermanagement.deptUser', $user->ref_operator_type_id);
    //     } catch (Exception $e) {
    //         Log::error($e->getMessage());
    //         abort(404);
    //     }
    // }

    // private function prepareEmailData($user, $role_id, $password,)
    // {
    //     if ($role_id != 2) {
    //         $apklink = url('public/apeda-processor.apk');
    //         return ['send_message' => "<strong> Dear " . $user->first_name . " " . $user->last_name . "</strong><br>  We are delighted to welcome you to TraceNet - Organic Traceability System, an online platform designed to streamline operations and enhance efficiency specifically for organic product traceability. To begin utilizing the platform's benefits fully, we kindly request you to complete your profile and ensure compliance with the guidelines set by the National Program for Organic Production (NPOP).<br> Completing your profile accurately is crucial as it ensures precise representation of your organic business within our network. This information facilitates seamless communication, enhances collaboration, and enables us to register in the TraceNet system.<br> <br> To complete your profile and ensure compliance with NPOP guidelines,.<br> Your Credentials has given below :- <br><strong> Username : " . $request->mobile . " <br> <br><strong> Email : " . $request->email . " <br> Password : " . $password . "</strong> <br> <a href=" . $apklink . ">Click here </a>for download mobile application for farmer registration. "];
    //     } else {
    //         return ['send_message' => "Dear <strong> $request->first_name,</strong><br><br> We are delighted to welcome you to TraceNet - Organic Traceability System, an online platform designed to streamline operations and enhance efficiency specifically for organic product traceability. To begin utilizing the platform's benefits fully, we kindly request you to complete your profile and ensure compliance with the guidelines set by the National Program for Organic Production (NPOP).<br><br> Completing your profile accurately is crucial as it ensures precise representation of your organic business within our network. This information facilitates seamless communication, enhances collaboration, and enables us to register in the TraceNet system.<br> <br> To complete your profile and ensure compliance with NPOP guidelines, please follow these steps:<br><br> USER ID <strong> is your registered PAN </strong> card and <strong> Password : 123456 </strong> <br> <strong> Temporary Reg. No. ORG/0124/00" . $user->id . " </strong> <br> <strong> Registered Date: " . date('d-M-Y', strtotime($user->created_at)) . " </strong><br><br>
    //         <br>
    //         1. Log in to the TraceNet - Organic Traceability System using the credentials provided during registration.
    //         <br>
    //         2. Navigate to the profile section.
    //         <br>
    //         3. Fill in all the required fields with accurate information. Ensure that the details provided are up-to-date and comprehensive.
    //         <br>
    //         4. Familiarize yourself with the guidelines outlined by the National Program for Organic Production (NPOP). Please visit APEDA website : https://apeda.gov.in or https://apeda.gov.in/apedawebsite/organic/ORGANIC_CONTENTS/National_Programme_for_Organic_Production.htm

    //         <br>
    //         5. Ensure that your profile information aligns with the NPOP guidelines, especially regarding organic production, processing, and labeling standards.
    //         <br>
    //         6. Once you have reviewed and verified the information, submit your profile for approval.
    //         <br>
    //         Upon submission, our team will promptly review your profile and verify its compliance with NPOP guidelines. Approval will grant you access to the full range of features and functionalities offered by TraceNet - Organic Traceability System.
    //         <br>
    //         <br>

    //         Should you encounter any difficulties during the registration process, require assistance, or need clarification regarding NPOP guidelines, please do not hesitate to contact CB <strong>" . Auth::guard('misadmin')->user()->first_name . "</strong>. We are here to assist you every step of the way.
    //         <br>
    //         <br>
    //         Note: This is an automated email. Please do not reply.

    //         <br>
    //         <br>

    //         Regards/-
    //         <br>
    //         <br>

    //         APEDA - TraceNet - Organic Traceability System"];
    //     }
    // }

    // private function generateRegistrationNumber($user)
    // {
    //     switch ($user->ref_operator_type_id) {
    //         case 2:
    //             return 'ICS00' . $user->id;
    //         case 3:
    //             return 'IP00' . $user->id;
    //         case 4:
    //             return 'WH00' . $user->id;
    //         case 5:
    //             return 'TRA00' . $user->id;
    //         case 6:
    //             return 'PRO00' . $user->id;
    //         default:
    //             return '';
    //     }
    // }


    public function testSms()
    {
        $mobileNumber = '8756413330';
        $otp = 1234;
        $username = 'TestUser';
        $email = 'test@example.com';
        $password = 'Test@1234';

        $response = $this->sendLoginDetailsSms($mobileNumber, $username, $email, $password);


        $apiUrl = 'https://apeda.gov.in/apedaMobile/api/apedawebsite/sendNicOTP';
        $data = [
            'txtmessage' => "Your OTP for APEDA online registration is : $otp",
            'senderID' => 'APEDAI',
            'mobilenumber' => $mobileNumber,
            'templateID' => '1707160681109422053',
        ];

        $ch = curl_init($apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
        ]);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

        $response = curl_exec($ch);
        if (curl_errno($ch)) {
            return ['error' => curl_error($ch)];
        }
        curl_close($ch);
        //dd($response);
        return json_decode($response, true);
        //  dd($response);

        return response()->json($response);
    }

    private  function sendLoginDetailsSms($mobileNumber, $username, $email, $password = '123456')
    {

        $apiUrl = 'https://apeda.gov.in/apedaMobile/api/apedawebsite/sendNicOTP';

        $message = "Your Login details to access Tracenet are  Name : $username , User ID :$email and  Password  : $password , More details at www.apeda.gov.in";

        // dd($message );
        $data = [
            'txtmessage' => $message,
            'senderID' => 'APEDAI',
            'mobilenumber' => $mobileNumber,
            'templateID' => '1707161761984762652',
        ];

        $ch = curl_init($apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
        ]);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

        $response = curl_exec($ch);
        if (curl_errno($ch)) {
            Log::error('SMS sending failed: ' . curl_error($ch));
        }
        curl_close($ch);


        return json_decode($response, true);
    }



    public function addIcs($id)
    {
        return view('admin/usermanagement/deptUser/addIcs', compact('id'));
    }
    public function deptUserEdit(Request $request, $id)
    {

        $user = User::where('id', $id)->first();
        $farmerDetails = IndividualProducerFarmerDetail::where('at_user_id', $id)->first();
        return view('admin/usermanagement/deptUser/edit', compact('user', 'id', 'farmerDetails'));
    }

    public function deptUserUpdate(Request $request, $id)
    {

        $request->validate([
            'first_name' => 'required',
            'entity_firm' => 'required',
            //'last_name' => 'required',
            // 'ref_office_id' => 'required',
            // 'status' => 'required',
        ]);
        try {
            $user = User::find($id);
            $user->first_name = $request->first_name;
            $user->middle_name = $request->middle_name;
            $user->last_name = $request->last_name;

            $user->contact_person_first_name = $request->contact_first_name;
            $user->contact_person_middle_name = $request->contact_middle_name;
            $user->contact_person_last_name = $request->contact_last_name;
            $user->contact_person_aadhar_number = $request->contact_person_aadhar_number;
            $user->address = $request->address;
            $user->ref_village_id = $request->village;
            $user->ref_block_tehsil_id = $request->taluka;
            $user->ref_district_id = $request->district;
            $user->ref_state_id = $request->state;
            $user->pin = $request->pin_code;
            $user->entity_firm = $request->entity_firm;
            $user->user_name = $request->email;
            $user->mobile_no = $request->mobile;

            $user->standerd_type = $request->standerd_type;
            $user->contact_designation = $request->contact_designation;
            $user->contact_person_gender = $request->contact_gender;
            $user->contact_gender = $request->contact_gender;

            $user->user_type = 1;
            //$user->ref_office_id = $request->ref_office_id;
            // $user->status = $request->status;
            $user->updated_by = Auth::guard('misadmin')->user()->id;
            $user->save();

            if ($user) {
                $user->roles()->attach($request->role_id);
            }
            switch ($user->ref_operator_type_id) {
                case 2:
                    $regNum = 'ICS00' . $user->id;
                    break;
                case 3:
                    $regNum = 'IP00' . $user->id;
                    break;
                case 4:
                    $regNum = 'WH00' . $user->id;
                    break;
                case 5:
                    $regNum = 'TRA00' . $user->id;
                    break;
                case 6:
                    $regNum = 'PRO00' . $user->id;
                    break;
                default:
                    $regNum = '';
            }
            Alert::success('Success', "$regNum Updated Successfully.");
            return redirect()->back();
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    // public function deptUserDelete(Request $request){
    //     try {

    //         $id = $request->id;
    //         $user = User::find($id);
    //         $user->is_deleted = 1;
    //         $user->deleted_at = date('Y-m-d H:i:s');
    //         $user->save();

    //         UserInspector::where('at_user_id',$id)->delete();


    //         return json_encode(['message' => 'done']);

    //     } catch (Exception $e) {
    //         Log::error($e->getMessage());
    //         abort('404');
    //     }
    // }

    public function deptUserDelete(Request $request)
    {
        try {
            $id = $request->id;
            $deletionReason = $request->deletionReason;



            $user = User::find($id);

            // Ensure the user exists before attempting to delete
            if ($user) {
                $user->is_deleted = 1;
                $user->deleted_at = now();
                $user->save();

                UserInspector::where('at_user_id', $id)->delete();

                DeletionLog::create([
                    'record_id' => $id,
                    'reason' => $deletionReason,
                ]);

                // dd('DeletionLog record created:', ['record_id' => $id, 'reason' => $deletionReason]);
                // Send email
                //Mail::to('kumar.gaurav@velocis.co.in')->send(new RecordDeletedMail($user, $deletionReason));


                return json_encode(['message' => 'done']);
            } else {
                return json_encode(['message' => 'User not found']);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }



    public function getDistrict(Request $request)
    {

        // dd($request->all());
        $city = $request->city_id;
        $data = RefDistrict::where("ref_state_id", $request->state_id)
            ->orderBy('district_name')->get();
        $selected = '';
        // dd($data);
        $option = '<option value="">-Select District-</option>';
        if (count($data) > 0) {
            foreach ($data as $key => $value) {
                if ($city == $value->id) {
                    $selected = 'selected';

                    $option .= '<option value="' . $value->id . '"  selected="' . $selected . '">' . $value->district_name . '</option>';
                } else {
                    $option .= '<option value="' . $value->id . '">' . $value->district_name . '</option>';
                }
            }
        } else {

            $option .= '<option value="">No record found.</option>';
        }
        return response()->json($option);
    }

    public function getBlockTehsil(Request $request)
    {
        $city = $request->city_id;
        $data = RefRegion::where("ref_district_id", $request->district_id)
            ->orderBy('block_tehsil_name')->get();
        $selected = '';

        $option = '<option value="">-Select Taluka/Mandal-</option>';
        if (count($data) > 0) {
            foreach ($data as $key => $value) {
                if ($city == $value->id) {
                    $selected = 'selected';

                    $option .= '<option value="' . $value->id . '"  selected="' . $selected . '">' . $value->block_tehsil_name . '</option>';
                } else {
                    $option .= '<option value="' . $value->id . '">' . $value->block_tehsil_name . '</option>';
                }
            }
        } else {

            $option .= '<option value="">No record found.</option>';
        }
        return response()->json($option);
    }

    public function getVillage(Request $request)
    {

        $city = $request->city_id;
        $insid = $request->insid;
        $data = RefVillage::where("ref_block_tehsil_id", $request->block_tehsil_id)
            ->orderBy('village_name')->get();
        //only for schedule
        $disable = '';
        $disvill = array();
        if ($insid) {

            $disable = FarmersRegSchedule::select('ref_village_id')->where('at_ics_inspector_details_id', $insid)->get();
            foreach ($disable as $disval) {
                $disvill[] = $disval->ref_village_id;
            }
        }


        //only for schedule
        $selected = '';

        $option = '<option value="">-Select Village-</option>';
        if (count($data) > 0) {
            foreach ($data as $key => $value) {
                if ($city == $value->id) {
                    $selected = 'selected';

                    $option .= '<option value="' . $value->id . '"  selected="' . $selected . '">' . $value->village_name . '</option>';
                } else {

                    if (in_array($value->id, $disvill)) {

                        $option .= '<option value="' . $value->id . '" disabled >' . $value->village_name . '</option>';
                    } else {

                        $option .= '<option value="' . $value->id . '">' . $value->village_name . '</option>';
                    }
                }
            }
        } else {
            $option .= '<option value="">No record found.</option>';
        }
        return response()->json($option);
    }



    public function archive(Request $request)
    {
        abort_unless(\Gate::allows('user_access'), 403);

        if ($request->ajax()) {

            $user = UserInspector::onlyTrashed()->get();

            return Datatables::of($user)
                ->addIndexColumn()
                ->addColumn('name', function ($row) {

                    return $row->name_of_inspector ?? '';
                })
                ->addColumn('email', function ($row) {
                    return $row->email ?? '';
                })->addColumn('mobile', function ($row) {
                    return $row->mobile_no ?? '';
                })->addColumn('created_on', function ($row) {

                    return  date('d/m/Y', strtotime($row->created_at)) ?? '';
                })
                ->addColumn('action', function ($row) {

                    $addEditDetailButton =  '<a href=' . route('superadmin.usermanagement.archive.edit', [$row->id]) . '><span><i class="mdi mdi-pencil text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Edit Individual User"></i></span></a>';

                    return $addEditDetailButton;
                })
                ->rawColumns(['action', 'role'])
                ->make(true);
        }

        return view('admin/usermanagement/deptUser/archive');
    }

    public function editArchive(Request $request, $id)
    {
        $user = UserInspector::where('id', $id)->withTrashed()->first();

        return view('admin/usermanagement/deptUser/archiveEdit', compact('user'));
    }

    public function updateArchive(Request $request, $id)
    {

        $request->validate([
            'mobile' => 'required',
            'email' => 'required',
        ]);
        try {

            $data = array(
                'email' => $request->email,
                'mobile_no' => $request->mobile,
                'updated_by' => Auth::guard('misadmin')->user()->id,
            );

            $user = UserInspector::where('id', $id)->withTrashed()->update($data);

            if ($user) {
                return redirect()->back()->with('success', "Data Update Successfully.");
            } else {
                return redirect()->back()->with('error', "Something went wrong.");
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }



    public function emailMobileOTP(Request $request)
    {
        try {
            // if (isset($request->user_mobile)) {
            //     $user_mobile = $request->user_mobile;
            //     session(['user_mobile' => $user_mobile]);
            //     $mobileOTP = rand('1000', '9999');
            //     //$mobileOTP = 1234;
            //     session(['mobileOTP' => $mobileOTP]);
            //     $msg = "Your OTP for login is $mobileOTP. Regards, Rashtrapati Bhavan.";
            //     $dlt_template_id = '1107161534668346421';
            //     send_otp($user_mobile, $msg, $dlt_template_id);
            //     echo 1;
            // } else

            // if (User::where('email', $request->email)->count() > 0) {
            //     return response()->json([
            //         'status' => 'error',
            //         'message' => 'Email already taken'
            //     ], 400);
            // }


            if (isset($request->user_email)) {
                $user_email = $request->user_email;
                session(['user_email' => $user_email]);
                $emailOTP = rand('1000', '9999');
                session(['emailOTP' => $emailOTP]);
                $emails = $user_email;
                $maildata = array();
                $maildata  = ['send_message' => "Dear User <br><br>Your OTP for validating Email address " . $emailOTP . " <br><br>Regards, <br>Apeda Team"];
                Mail::send('mail.inspector_register', $maildata, function ($message) use ($emails) {
                    $message->subject("Apeda OTP"); // Email subject body
                    $message->to($emails);
                });
                echo 1;
            }
        } catch (Exception $e) {
            Log::error($e);
        }
    }


    public function emailMobileOTPcheck(Request $request)
    {
        try {
            // if (isset($request->mobile_otp)) {
            //     $mobile_otp = $request->mobile_otp;
            //     $mobileOTP = session('mobileOTP');
            //     if ($mobile_otp == $mobileOTP) {
            //         echo 1;
            //         session(['validmobileOTP' => 1]);
            //     } else {
            //         echo 0;
            //     }
            // } else
            if (isset($request->email_otp)) {
                $email_otp = $request->email_otp;
                $emailOTP = session('emailOTP');
                if ($email_otp == $emailOTP) {
                    echo 1;
                    session(['validemailOTP' => 1]);
                } else {
                    echo 0;
                }
                // echo session('emailOTP');
            }
        } catch (Exception $e) {
            Log::error($e);
        }
    }


    public function getMandatorDetail(Request $request)
    {
        try {

            $data = MandatorRegister::where('pan', $request->pan)->first();
            // dd($data);
            if ($data) {
                $data['state'] = getStateName($data->state_id ?? '');
                $data['district'] = getDisName($data->district_id ?? '');
                $data['taluka'] = getTalukName($data->taluka_mandal_id ?? '');
                $data['village'] = getVillName($data->village_id ?? '');
                $data['aadhar_no'] = maskAadhaarNumber($data->aadhar_no ?? '');
                return response()->json($data);
            } else {
                return 0;
            }
        } catch (Exception $e) {
            Log::error($e);
        }
    }

    public function userCreate(Request $request)
    {
        $states = RefState::orderBy('state_name', 'ASC')->get();
        $districts = RefDistrict::orderBy('district_name', 'ASC')->get();
        $regions = RefRegion::orderBy('block_tehsil_name', 'ASC')->get();
        $villages = RefVillage::orderBy('village_name', 'ASC')->limit(100)->get();
        $qualification = RefQualification::all();
        $des = RefDesignation::all();
        return view('admin/usermanagement/employee/add', compact('states', 'districts', 'regions', 'villages', 'qualification', 'des'));
    }



    public function userCreateStore(Request $request)
    {
        // dd($request->all());
        $request->validate([
            'username' => 'required',
            'mobile' => 'required',
            'remark' => 'required',
            'higher_qual' => 'required',
            'designation' => 'required',
            'aadhar_number' => 'required',
            // 'employee_code' => 'required',
            'email' => 'required',
            // 'pan' => 'required|regex:/[A-Z]{5}[0-9]{4}[A-Z]{1}/',
        ]);
        if (!empty($request->file('upload_biodata'))) {
            if (!empty($request->upload_biodata_edit)) {
                $imagePath = public_path('cb/employee_bio_data/') . $request->upload_biodata_edit;
                deleteOldImage($request->upload_biodata_edit, $imagePath);
            }

            $documentRootPath = public_path('cb/employee_bio_data/');
            if (!file_exists($documentRootPath)) {
                mkdir($documentRootPath, 0755, true);
            }
            $file_path = time() . rand() . '.' . $request->file('upload_biodata')->getClientOriginalExtension();
            $request->file('upload_biodata')->move($documentRootPath, $file_path);
            $mandator_resume = $file_path;
        } else {
            if (!empty($request->upload_biodata_edit)) {
                $mandator_resume = $request->upload_biodata_edit;
            }
        }
        try {
            $password = 123456;
            $data = array(
                'ref_operator_type_id' => 9,
                'first_name' => !empty($request->username) ? $request->username : NULL,
                'employee_id' => !empty($request->employee_id) ? $request->employee_id : NULL,
                'employee_type' => !empty($request->emp_type) ? $request->emp_type : NULL,
                'join_date'  => !empty($request->join_date) ? $request->join_date : NULL,
                'password' => hash('sha256', $password),
                'user_name' => !empty($request->email) ? $request->email : NULL,
                'email' => !empty($request->email) ? $request->email : NULL,
                'mobile_no' => !empty($request->mobile) ? $request->mobile : NULL,
                'standerd_type' => !empty($request->standerd_type) ? $request->standerd_type : NULL,
                'status' => 0,
                'remark' => !empty($request->remark) ? $request->remark : NULL,
                'gender' => !empty($request->gender) ? $request->gender : NULL,
                'qualification' =>  !empty($request->higher_qual) ? $request->higher_qual : NULL,
                'designation' =>  !empty($request->designation) ? $request->designation : NULL,
                'aadhar_number' =>  !empty($request->aadhar_number) ? $request->aadhar_number : NULL,
                'resourse_type' => !empty($request->resourse_type) ? $request->resourse_type : NULL,
                'din' => !empty($request->din) ? $request->din : NULL,
                'pan' => !empty($request->pan) ? $request->pan : NULL,
                'user_type' => !empty($request->status) ? $request->status : NULL,
                'total_experience' => !empty($request->experience) ? $request->experience : NULL,
                'training' => !empty($request->trainings) ? $request->trainings : NULL,
                'upload_biodata' => $mandator_resume,
                'created_by' => Auth::guard('misadmin')->user()->id
            );
            $user = User::create($data);
            $atUserLoginDetailsData = [
                'at_user_id' => !empty($user->id) ? $user->id : NULL,
                'ref_operator_type_id' => 9,
                'user_name' => !empty($request->email) ? $request->email : NULL,
                'password' => hash('sha256', $password),
                'user_type' => !empty($request->status) ? $request->status : NULL,
                'status' => 0,
                'created_by' => Auth::guard('misadmin')->user()->id,
            ];

            $auLoginDetial_id = AtUserLoginDetails::create($atUserLoginDetailsData);
            $auRegdetaislData = [
                'at_user_id' => !empty($user->id) ? $user->id : NULL,
                'at_user_login_details_id' => !empty($auLoginDetial_id->id) ? $auLoginDetial_id->id : NULL,
                'ref_operator_type_id' => 9,
                'first_name' => !empty($request->username) ? $request->username : NULL,
                'mobile_no' => !empty($request->mobile) ? $request->mobile : NULL,
                'email' => !empty($request->email) ? $request->email : NULL,
            ];
            AtUserRegistrationDetails::create($auRegdetaislData);
            $atCbEmployeeDetailData = [
                'at_user_id' => !empty($user->id) ? $user->id : NULL,
                'at_user_login_details_id' => !empty($auLoginDetial_id->id) ? $auLoginDetial_id->id : NULL,
                'ref_operator_type_id' => 9,
                'first_name' => !empty($request->username) ? $request->username : NULL,
                'mobile_no' => !empty($request->mobile) ? $request->mobile : NULL,
                'email' => !empty($request->email) ? $request->email : NULL,
                'user_type' => !empty($request->status) ? $request->status : NULL,
                'status' => 0,
                'aadhar_number' => !empty($request->aadhar_number) ? $request->aadhar_number : NULL,
                'designation' => !empty($request->designation) ? $request->designation : NULL,
                'remark' => !empty($request->remark) ? $request->remark : NULL,
                'employee_id' => !empty($request->employee_id) ? $request->employee_id : NULL,
                'join_date' => !empty($request->join_date) ? $request->join_date : NULL,
                'total_experience' => !empty($request->experience) ? $request->experience : NULL,
                'training' => !empty($request->trainings) ? $request->trainings : NULL,
                'employee_type' => !empty($request->emp_type) ? $request->emp_type : NULL,
                'resourse_type' => !empty($request->resourse_type) ? $request->resourse_type : NULL,
                'pan' => !empty($request->pan) ? $request->pan : NULL,
                'din' => !empty($request->din) ? $request->din : NULL,
                'upload_biodata' => $mandator_resume,
                'gender' => !empty($request->gender) ? $request->gender : NULL,
                'created_by' => Auth::guard('misadmin')->user()->id,
            ];
            AtCertificationBodyEmployeeDetails::create($atCbEmployeeDetailData);
            $emails = $request->email;
            $maildata = array();
            $maildata  = ['send_message' => "<strong> Dear " . $request->user_name . "</strong><br> You have been registered in tranceNet system by certification bodies.<br> Your Credentials has given below :- <br><strong> Username : " . $request->email . " <br><strong> Password : 123456 <br> </strong> <br> <a href=" . url('/') . ">Click here </a> for login "];
            switch ($user->ref_operator_type_id) {
                case 2:
                    $regNum = 'ICS00' . $user->id;
                    break;
                case 3:
                    $regNum = 'IP00' . $user->id;
                    break;
                case 4:
                    $regNum = 'WH00' . $user->id;
                    break;
                case 5:
                    $regNum = 'TRA00' . $user->id;
                    break;
                case 6:
                    $regNum = 'PRO00' . $user->id;
                    break;
                default:
                    $regNum = 'EMP00' . $user->id;
            }
            Mail::send('mail.inspector_register', $maildata, function ($message) use ($emails) {
                $message->subject("Apeda Registration");
                $message->to($emails);
            });
            Alert::success('Success', "$regNum.'  Registered Successfully.'");
            return redirect()->route('superadmin.usermanagement.usercreatelist');
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
        // }
    }

    public function assignRoleToUser(Request $request)
    {
        $request->validate([
            'role_id' => 'required'
        ]);

        try {
            $password = 123456;
            $data = array(
                'first_name' => $request->username,
                'password' => hash('sha256', $password),
                'user_name' => $request->email,
                'email' => $request->email,
                'mobile_no' => $request->mobile,
                'standerd_type' => $request->standerd_type ?? '',
                'user_type' => 1,
                'remark' => $request->remark,
                'qualification' =>  $request->higher_qual,
                'designation' =>  $request->designation,
                'aadhar_number' =>  $request->aadhar_number,
                'status' => 0,
                'created_by' => Auth::guard('misadmin')->user()->id
            );
            $user = User::create($data);
            $emails = $request->email;
            $maildata = array();
            $maildata  = ['send_message' => "<strong> Dear " . $request->user_name . "</strong><br> You have successfully registered.<br> Your Credentials has given below :- <br><strong> Username : " . $request->email . " <br><strong> Password : 123456 <br> </strong> <br> <a href=" . url('/') . ">Click here </a> for login "];
            switch ($user->ref_operator_type_id) {
                case 2:
                    $regNum = 'ICS00' . $user->id;
                    break;
                case 3:
                    $regNum = 'IP00' . $user->id;
                    break;
                case 4:
                    $regNum = 'WH00' . $user->id;
                    break;
                case 5:
                    $regNum = 'TRA00' . $user->id;
                    break;
                case 6:
                    $regNum = 'PRO00' . $user->id;
                    break;
                default:
                    $regNum = 'EMP00' . $user->id;
            }
            Mail::send('mail.inspector_register', $maildata, function ($message) use ($emails) {  // use mail template in view/api folder
                $message->subject("Apeda Registration"); // Email subject body
                $message->to($emails);
            });
            Alert::success('Success', "$regNum.'  Registered Successfully.'");
            return redirect()->route('superadmin.usermanagement.usercreatelist');
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }


    public function emprolelist()
    {
        // Get the employee modules along with the associated module and submodule
        $userModules = EmployeeModule::with(['moduleMappings.module', 'moduleMappings.subModule', 'user'])->get();
        // print_r($userModules); die;
        // Pass the data to the view
        return view('admin.usermanagement.employee.rolelist', compact('userModules'));
    }

    // public function emprolelist()
    // {
    //     return view('admin/usermanagement/employee/rolelist');
    // }

    public function rolecreate()
    {
        $userId = Auth::id();

        // Fetch users based on your criteria
        $user = User::where(function ($query) {
            return $query->orWhere('ref_operator_type_id', '>', 7)
                ->orWhere('ref_operator_type_id', NULL);
        })
            ->where('created_by', $userId)
            ->orderBy('id', 'DESC')
            ->get();

        // Get the emp_ids that already exist in the employee_module table
        $existingEmpIds = EmployeeModule::pluck('emp_id')->toArray();

        // Fetch all modules and submodules
        $module = RefModule::all();
        $submodule = RefSubmodule::all();

        // Pass the data to the view
        return view('admin.usermanagement.employee.add_role', compact('user', 'module', 'submodule', 'existingEmpIds'));
    }


    public function usercreatelist(Request $request)
    {
        abort_unless(\Gate::allows('user_access'), 403);
        $userId = Auth::id();
        
        $user = User::where(function ($query) { 
            return $query->orWhere('ref_operator_type_id', '>', 7)
                ->orWhere('ref_operator_type_id', NULL);
        })->where('created_by', $userId)->orderBy('id', 'DESC')->get();
        if ($request->ajax()) {
            return Datatables::of($user)
                ->addIndexColumn()
                ->addColumn('name', function ($row) {
                    return !empty($row->first_name) ? $row->first_name : NULL;
                })
                ->addColumn('emp_typ', function ($row) {
                    return !empty($row->employee_type) ? $row->employee_type : NULL;
                })

                ->addColumn('aadhaar_no', function ($row) {
                    $number = !empty($row->aadhar_number) ? $row->aadhar_number : NULL;
                    $count = strlen((string)abs($number));
                    if ($count == 12) {
                       $aadhaar_number =  maskAadhaarNumber($row->aadhar_number ?? '');
                    }else{
                        $aadhaar_number = 'Invalid Aadhaar Number';
                    }
                    return $aadhaar_number;
                })
                ->addColumn('Trainings', function ($row) {
                    return !empty($row->training) ? $row->training : NULL;
                })
                ->addColumn('experience', function ($row) {
                    return !empty($row->total_experience) ? $row->total_experience : NULL;
                })
                ->addColumn('application_no', function ($row) {
                    return  '#EMP' . str_pad($row->id, 5, "0", STR_PAD_LEFT);
                })->addColumn('email', function ($row) {
                    return !empty($row->email) ? $row->email : NULL;
                })->addColumn('emp_id', function ($row) {
                    return !empty($row->employee_id) ?  $row->employee_id : NULL;
                })->addColumn('join_date', function ($row) {
                    return date('d-m-Y', strtotime($row->join_date)  ?? '');
                })
                ->addColumn('gender', function ($row) {
                    return (!empty($row->gender)) ? getGenderNameByID($row->gender) : '';
                })
                ->addColumn('mobile', function ($row) {
                    return !empty($row->mobile_no) ? $row->mobile_no : NULL;
                })

                ->addColumn('biodata', function ($row) {
                    if (!empty($row->upload_biodata)) {
                        return '<a target="_BLANK" href="' . asset('public/cb/employee_bio_data/' . $row->upload_biodata) . '" class="text-decoration-underline">
                                    <img src="' . asset('public/assets/images/pdf-icon.png') . '" alt="" class="pdf-img-icon" style="height: 30px; width: 30px;" title="Bio Data">
                                </a>';
                    } else {
                        return 'Not Available';
                    }
                })


                ->addColumn('designation', function ($row) {
                    return getDesibationById($row->designation ?? '');
                    // return 'dsfd';
                })
                ->addColumn('higher_qualification', function ($row) {
                    return !empty($row->qualification) ?  $row->qualification : NULL;
                })

                ->addColumn('created_on', function ($row) {
                    return date('d-m-Y H:i:s', strtotime($row->created_at ?? '')  ); //($row->created_at) ?? '';
                })->addColumn('status', function ($row) {
                    $status = '';
                    if ($row->user_type == 1)
                        return  '<span class="badge badge-soft-success">Active</span>';
                    else
                        return  '<span class="badge badge-soft-danger">Inactive</span>';
                })
                ->addColumn('action', function ($row) {
                    $addEditDetailButton = '';
                    if (Auth::guard('misadmin')->user()->roles[0]->id == 1) {
                        $addEditDetailButton .= '<a href=' . route('superadmin.usermanagement.usercreate.role', $row->id) . '><span><i class="mdi mdi-plus-box text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Assign Role"></i></span></a>';

                        $addEditDetailButton .= '<a href=' . route('superadmin.usermanagement.usercreate.edit', $row->id) . ' style="margin-left:10px"><span><i class="mdi mdi-pencil text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Edit  User"></i></span></a>';
                    }
                    return $addEditDetailButton;
                })
                ->rawColumns(['action', 'status', 'biodata'])
                ->make(true);
        }
        return view('admin/usermanagement/employee/index');
    }

    public function userCreateEdit($id)
    {
        $user = User::where('id', $id)->first();
        return view('admin/usermanagement/employee/edit', compact('user', 'id'));
    }

    public function usercreateUpdate(Request $request, $id)
    {
        $request->validate([
            // 'employee_code' => 'required',
            //'username' => 'required',
            //'designation' => 'required',
            //'higher_qual' => 'required',
            'email' => 'required',
            // 'gender' => 'required',
            'mobile' => 'required',
            // 'aadhar_number' => 'required',
        ]);
        try {
            $user = User::find($id);
            // $user->first_name = $request->username;
            // $user->designation = $request->designation;
            // $user->qualification = $request->higher_qual;
            $user->mobile_no = $request->mobile;
            // $user->gender = $request->gender;
            // $user->aadhar_number = $request->aadhar_number;
            $user->user_type = $request->status;
            $user->remark = $request->remark;
            $user->updated_by = Auth::guard('misadmin')->user()->id;
            $user->save();


            $atUserLoginDetailsData = [
                'at_user_id' => !empty($id) ? $id : NULL,
                'ref_operator_type_id' => 9,
                'updated_by' => Auth::guard('misadmin')->user()->id,
            ];
            AtUserLoginDetails::where('at_user_id', $id)->update($atUserLoginDetailsData);
            $auLoginDetial_id = AtUserLoginDetails::where('at_user_id', $id)->first();
            $auRegdetaislData = [
                'at_user_id' => !empty($id) ? $id : NULL,
                'at_user_login_details_id' => !empty($auLoginDetial_id->id) ? $auLoginDetial_id->id : NULL,
                'ref_operator_type_id' => 9,
                // 'first_name' => !empty($request->username) ? $request->username : NULL,
                'mobile_no' => !empty($request->mobile) ? $request->mobile : NULL,
                'updated_by' => Auth::guard('misadmin')->user()->id,
            ];
            AtUserRegistrationDetails::where('at_user_id', $id)->update($auRegdetaislData);
            $atCbEmployeeDetailData = [
                'at_user_id' => !empty($id) ? $id : NULL,
                'at_user_login_details_id' => !empty($auLoginDetial_id->id) ? $auLoginDetial_id->id : NULL,
                'ref_operator_type_id' => 9,
                'mobile_no' => !empty($request->mobile) ? $request->mobile : NULL,
                'user_type' => !empty($request->status) ? $request->status : NULL,
                'remark' => !empty($request->remark) ? $request->remark : NULL,
                'updated_by' => Auth::guard('misadmin')->user()->id,
            ];
            AtCertificationBodyEmployeeDetails::where('at_user_id', $id)->update($atCbEmployeeDetailData);
            Alert::success('Success', __('Update  Successfully.'));
            return redirect()->back();
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    function userCreateRole($id)
    {
        $role = Role::where('id', '>', 7)->get();
        $user = User::find($id);
        $userrole = $user->roles->pluck("title")->first();


        return view('admin/usermanagement/employee/assignrole', compact('role', 'userrole', 'id'));
    }
    function getPermissionByRole(Request $request)
    {
        $role = Role::get(); //where('id','>',7)->get();
        return view('admin/usermanagement/employee/assignrole', compact('role', 'id'));
    }
    function usercreateUpdateRole(Request $request, $id)
    {
        $request->validate([
            'role_id' => 'required',
        ]);
        try {
            $user = User::find($id);

            if ($user->roles->pluck("title")->first() == NULL) {
                User::where('id', $id)->update(['user_type' => 1]);
                $user->roles()->attach($request->role_id);
                Alert::success('Success', __('Role has been Assigned Successfully.'));
                return redirect()->back();
            } else {
                Alert::error('Error', __('Role already assigned to user.'));
                return redirect()->back();
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }



    public function processorView(Request $request, $id)
    {
        $user = User::with('bankDetails')->where('id', $id)->first();
        $gtDetail = GeoTaggingProcessorDetail::where('at_user_id', $id)->get();
        $ppDetail = ProcessorProductDetail::where('at_user_id', $id)->get();
        $pDocument = ProcessorDocument::where('at_user_id', $id)->first();
        $eMSignedModuleAlow = getUserDigitalSignatureModules(Auth::id(), 'RC');
        $hostName = request()->getSchemeAndHttpHost();
        if ($eMSignedModuleAlow['status'] == 'success' && $eMSignedModuleAlow['isAllowed'] == '1') {

            $checkSignedPDf = getDigitalSignedPdf(Auth::id(), basename($user->registration_certificate));
            if ($checkSignedPDf['status'] == 'success') {
                $eMSignedModuleResult = [
                    'signedPath' => $checkSignedPDf['signedPath'],
                    'status' => 'success',
                ];
            } else {
                $eMSignedModuleResult = [
                    'signedPath' => '',
                    'status' => 'failed',
                ];
            }
        } else
            $eMSignedModuleResult = [
                'signedPath' => '',
                'status' => 'failed',
            ];


        

       
        $farmerDetails = IndividualProducerFarmerDetail::where('at_user_id', $id)->get();
        $producer_docs = IndividualProducerDocument::where('at_user_id', $id)->get();

        $producer_farm_detail = IndividualProducerFarmDetail::with(['state', 'district', 'blockTehsil'])
            ->where('at_user_id', $id) 
            ->get();
     
        $farm_detail = IndividualProducerFarmDetail::where('at_user_id', $id)->first();        
        if (!empty($farm_detail)) {
            $geo_taggings = IndividualProducerGeoTagging::where('at_ip_farmer_reg_details_id', $farm_detail->at_farmer_reg_details_id)->where('at_ip_farm_details_id', $farm_detail->id)->get();
        } else {
            $geo_taggings = ""; 
        }


        $producer_standing_corp = IndividualProducerDetailOfStandingCorp::where('at_user_id', $id)->get();
        $producer_proposed_corp = IndividualProducerDetailOfProposedCorp::where('at_user_id', $id)->get();
        $states = RefState::orderBy('state_name', 'ASC')->get();
        

        return view('admin/usermanagement/deptUser/processorView', compact('id', 'user', 'gtDetail', 'ppDetail', 'pDocument', 'eMSignedModuleAlow', 'eMSignedModuleResult', 'hostName','farmerDetails','producer_docs','producer_farm_detail','geo_taggings','producer_standing_corp','producer_proposed_corp'));
    }

    public function getNOCDetailList(Request $request)
    {
        $userId = Auth::id();

        if ($request->ajax()) {
            $nocList = AtOpNocDetails::where('noc_status', 'Pending')->get();
            //dd($nocList);
            return Datatables::of($nocList)
                ->addIndexColumn()
                ->addColumn('noc_application_no', function ($row) {
                    return $row->noc_application_no ?? '';
                })
                ->addColumn('reg_no', function ($row) {
                    $st = getSingleTableRecordById('at_user', 'id', $row->applied_by)->registration_no ?? '';
                    return $st ?? '';
                })
                ->addColumn('company_name', function ($row) {
                    return user_name($row->applied_by);
                })
                ->addColumn('noc_applied_on', function ($row) {
                    return date('d-m-Y', strtotime($row->applied_on)) ?? '';
                })
                ->addColumn('noc_type', function ($row) {
                    return $row->noc_type ?? '';
                })
                ->addColumn('action', function ($row) {
                    $action_btn = '<a href="' . route("superadmin.icsuser.nocProcessAproval", [$row->id, $row->at_user_id]) . '" target="_blank" class=""><span>Process</span></a>';
                    return $action_btn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }

        return view('admin/usermanagement/noc/noclist', compact('userId'));
    }

    public function nocProcessAproval(Request $request, $id, $at_user_id)
    {
        $userId = Auth::guard('misadmin')->user()->id;
        $authsign = User::whereHas('roles', function ($q) {
            return $q->where('title', 'Authorized Signatory');
        })->where('created_by', Auth::id())->get();
        //dd($at_user_id);
        $atopcer = AtOpCertificateStandardDetail::where('updated_by',  $userId)->orwhere('created_by',  $at_user_id)->first();

        $nocData = AtOpNocDetails::where('id', $id)->first();
        return view('admin/usermanagement/noc/noc-process-approval', compact('id', 'authsign', 'nocData', 'atopcer'));
    }

    public function nocProcessAprovalStore(Request $request)
    {
        // dd($request->all());
        $request->validate([
            'noccb_comment' => 'required',
            'status' => 'required',
            'authorised' => 'required',

        ]);

        $nocList = AtOpNocDetails::where('id', $request->row_id)->first();
        $scopeData = CertificateStandardDetail::where('at_user_id', $nocList->applied_by)->first();

        $pdf = PDF::loadView('admin/usermanagement/pdf/nocCertificate', compact('nocList', 'scopeData'));
        $file_name = 'noc_' . time() . '.pdf';
        $filePath = public_path('/noc_application/' . $file_name);
        $directoryPath = dirname($filePath);
        if (!File::exists($directoryPath)) {
            File::makeDirectory($directoryPath, 0777, true);
        }
        $pdf->save($filePath);




        try {

            $data = array();
            $msg = '';
            if ($request->status == 'Approved') {
                $data = array(
                    'noccb_comment' => $request->noccb_comment,
                    'approvalflag' => 1,
                    'noc_status' => 'Approved',
                    'approved_by' => Auth::id(),
                    'approved_on' => date('Y-m-d H:i:s'),
                    'authorised' => $request->authorised,
                    'file_path' => $file_name,
                );
                $msg = 'Your NOC application has been approved.';
            } else {
                $data = array(
                    'noccb_comment' => $request->noccb_comment,
                    'cancellation_flag' => 1,
                    'noc_status' => 'Rejected',
                    'cancelled_by' => Auth::id(),
                    'cancellation_on' => date('Y-m-d H:i:s'),
                    'authorised' => $request->authorised,
                    'file_path' => $file_name,
                );
                $msg = 'Your NOC application has been rejected.';
            }

            $nocData = AtOpNocDetails::where('id', $request->row_id)->update($data);

            Alert::success('Success', $msg);
            return redirect()->back();
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    // public function getNOCDetailListStatusWise(Request $request)
    // {

    //     $userId = Auth::id();
    //     // $nocList = AtOpNocDetails::where('noc_status','!=','Pending')->get();
    //     // dd($nocList);
    //     if ($request->ajax()) {

    //         $nocList = AtOpNocDetails::where('noc_status', '!=', 'Pending')->get();

    //         return Datatables::of($nocList)
    //             ->addIndexColumn()
    //             ->addColumn('noc_application_no', function ($row) {
    //                 return $row->noc_application_no ?? '';
    //             })
    //             ->addColumn('reg_no', function ($row) {

    //                 $st = getSingleTableRecordById('at_user', 'id', $row->applied_by)->registration_no ?? '';

    //                 return $st ?? '';
    //             })->addColumn('company_name', function ($row) {

    //                 return  user_name($row->applied_by);
    //             })->addColumn('noc_applied_on', function ($row) {
    //                 return date('d-m-Y', strtotime($row->applied_on)) ?? '';
    //             })
    //             ->addColumn('noc_type', function ($row) {
    //                 return $row->noc_type ?? '';
    //             })->addColumn('noc_status', function ($row) {

    //                 return $row->noc_status ?? '';
    //             })
    //             ->addColumn('action', function ($row) {

    //                 if ($row->approvalflag == 1)
    //                     $action_btn = '<a href=' . route('superadmin.icsuser.nocCertificate', [$row->id]) . ' target="_blank" class=""><span>View NOC Certificate</span></a>';
    //                 else
    //                     $action_btn = '';


    //                 return $action_btn;
    //             })
    //             ->rawColumns(['action'])
    //             ->make(true);
    //     }

    //     return view('admin/usermanagement/noc/noclist-status-wise', compact('userId'));
    // }
    // public function getNOCDetailListStatusWise(Request $request)
    // {


    //     $userId = Auth::id();
    //     if ($request->ajax()) {
    //         $nocList = AtOpNocDetails::with('certificateDetails')
    //             ->where('noc_status', '!=', 'Pending')
    //             ->orderBy('id','DESC')->get();
    //         //  dd($nocList);
    //         return Datatables::of($nocList)
    //             ->addIndexColumn()
    //             ->addColumn('noc_application_no', function ($row) {
    //                 return $row->noc_application_no ?? '';
    //             })
    //             ->addColumn('reg_no', function ($row) {
    //                 $st = getSingleTableRecordById('at_user', 'id', $row->applied_by)->registration_no ?? '';
    //                 return $st ?? '';
    //             })
    //             ->addColumn('company_name', function ($row) {
    //                 return user_name($row->applied_by);
    //             })
    //             ->addColumn('noc_applied_on', function ($row) {
    //                 return date('d-m-Y', strtotime($row->applied_on)) ?? '';
    //             })
    //             ->addColumn('noc_type', function ($row) {
    //                 return $row->noc_type ?? '';
    //             })
    //             ->addColumn('noc_status', function ($row) {
    //                 return $row->noc_status ?? '';
    //             })
    //             ->addColumn('scope_certificate_no', function ($row) {
    //                 return $row->certificateDetails->scope_certificate_no ?? '';
    //             })
    //             ->addColumn('validity_start_date', function ($row) {
    //                 return date('d-m-Y', strtotime($row->certificateDetails->validity_start_date)) ?? '';
    //             })
    //             ->addColumn('validity_end_date', function ($row) {
    //                 return date('d-m-Y', strtotime($row->certificateDetails->validity_end_date)) ?? '';
    //             })
    //             ->addColumn('action', function ($row) {
    //                     if(isset($row->file_path)){
    //                         $button = '<a href=' . route('superadmin.icsuser.nocCertificate', [$row->id]) . ' target="_blank" class=""><span>View NOC Certificate</span></a> &nbsp; <a download href="'.asset('public/noc_application/').'/'.$row->file_path.'"><i class="mdi mdi-file-certificate text-info fs-24 align-middle me-1 ss-6" data-toggle="tooltip" title="Download Internal Stock"></i></a>';

    //                         //eMSigned Digital Signature Allow
    //                         $result = getUserDigitalSignatureModules(Auth::id(),'NOC');
    //                         $module = $result['status'] == 'success' && $result['isAllowed'] == '1' ? '1' : '0';
    //                         $embutton = '';
    //                         if ($module == '1') {
    //                             $hostName = request()->getSchemeAndHttpHost();
    //                             $checkSignedPDf = getDigitalSignedPdf(Auth::id(),$row->file_path);
    //                             if($checkSignedPDf['status'] == 'success'){
    //                                 $publicPath = str_replace('var/www/html/apeda/', '', $checkSignedPDf['signedPath']);
    //                                 $embutton .= '<a class="btn btn-success btn-sm" download href='.$hostName .$publicPath.'>Signed PDF</a>';
    //                             }else{
    //                                 $embutton .= '<button type="button" class="btn btn-primary btn-sm" id="generateDigitalSign" data-fileName="' . $row->file_path . '" data-path="/noc_application/" data-fileStored="public" data-certificate="NOC">Digital Sign</button>';
    //                             }

    //                         }

    //                     }else{
    //                         $button = '<a href=' . route('superadmin.icsuser.nocCertificate', [$row->id]) . ' target="_blank" class=""><span>View NOC Certificate</span></a>';
    //                     }
    //                 if ($row->approvalflag == 1)
    //                     $action_btn = $button;
    //                     $embutton = $embutton;
    //                 else
    //                     $action_btn = '';
    //                 return $action_btn;
    //             })
    //             ->rawColumns(['action'])
    //             ->make(true);
    //     }

    //     return view('admin/usermanagement/noc/noclist-status-wise', compact('userId'));
    // }
    public function getNOCDetailListStatusWise(Request $request)
    {
        $userId = Auth::id();
        if ($request->ajax()) {
            $nocList = AtOpNocDetails::with('certificateDetails')
                ->where('noc_status', '!=', 'Pending')
                ->orderBy('id', 'DESC')->get();

            return Datatables::of($nocList)
                ->addIndexColumn()
                ->addColumn('noc_application_no', function ($row) {
                    return $row->noc_application_no ?? '';
                })
                ->addColumn('reg_no', function ($row) {
                    $st = getSingleTableRecordById('at_user', 'id', $row->applied_by)->registration_no ?? '';
                    return $st ?? '';
                })
                ->addColumn('company_name', function ($row) {
                    return user_name($row->applied_by);
                })
                ->addColumn('noc_applied_on', function ($row) {
                    return date('d-m-Y', strtotime($row->applied_on)) ?? '';
                })
                ->addColumn('noc_type', function ($row) {
                    return $row->noc_type ?? '';
                })
                ->addColumn('noc_status', function ($row) {
                    return $row->noc_status ?? '';
                })
                ->addColumn('scope_certificate_no', function ($row) {
                    return $row->certificateDetails->scope_certificate_no ?? '';
                })
                ->addColumn('validity_start_date', function ($row) {
                    return date('d-m-Y', strtotime($row->certificateDetails->validity_start_date)) ?? '';
                })
                ->addColumn('validity_end_date', function ($row) {
                    return date('d-m-Y', strtotime($row->certificateDetails->validity_end_date)) ?? '';
                })
                ->addColumn('digital_sign', function ($row) {
                    // Check if Digital Signature is allowed
                    if (isset($row->file_path)) {
                        $result = getUserDigitalSignatureModules(Auth::id(), 'NOC');
                        $module = $result['status'] == 'success' && $result['isAllowed'] == '1' ? '1' : '0';
                        if ($module == '1') {
                            $hostName = request()->getSchemeAndHttpHost();
                            $checkSignedPdf = getDigitalSignedPdf(Auth::id(), $row->file_path);
                            if ($checkSignedPdf['status'] == 'success') {
                                $publicPath = str_replace('var/www/html/apeda/', '', $checkSignedPdf['signedPath']);
                                return '<a class="btn btn-success btn-sm" download href="' . $hostName . $publicPath . '">Signed PDF</a>';
                            } else {
                                return '<button type="button" class="btn btn-primary btn-sm" id="generateDigitalSign" data-fileName="' . $row->file_path . '" data-path="/noc_application/" data-fileStored="public" data-certificate="NOC">Digital Sign</button>';
                            }
                        }
                    }
                    return 'Not Available';
                })
                ->addColumn('action', function ($row) {
                    if (isset($row->file_path)) {
                        $button = '<a href=' . route('superadmin.icsuser.nocCertificate', [$row->id]) . ' target="_blank" class=""><span>View NOC Certificate</span></a> &nbsp; <a download href="' . asset('public/noc_application/') . '/' . $row->file_path . '"><i class="mdi mdi-file-certificate text-info fs-24 align-middle me-1 ss-6" data-toggle="tooltip" title="Download Internal Stock"></i></a>';
                    } else {
                        $button = '<a href=' . route('superadmin.icsuser.nocCertificate', [$row->id]) . ' target="_blank" class=""><span>View NOC Certificate</span></a>';
                    }

                    return $row->approvalflag == 1 ? $button : '';
                })
                ->rawColumns(['digital_sign', 'action'])
                ->make(true);
        }

        return view('admin/usermanagement/noc/noclist-status-wise', compact('userId'));
    }




    public function nocCertificate($id)
    {

        $nocList = AtOpNocDetails::where('id', $id)->first();
        $scopeData = CertificateStandardDetail::where('at_user_id', $nocList->applied_by)->first();

        // return view('admin/usermanagement/pdf/nocCertificate',compact('nocList','scopeData'));

        //$customPaper = array(0,0,800.00,730.80);

        $pdf = PDF::loadView('admin/usermanagement/pdf/nocCertificate', compact('nocList', 'scopeData'));
        //$rand = str_pad(mt_rand(1, 99999999), 8, '0', STR_PAD_LEFT);
        return $pdf->stream('NOC-Certificate' . '.pdf');
    }
    public function nocRegister()
    {

        return view('admin/usermanagement/noc/noc-register');
    }
    public function scopeRenewal()
    {
        $userid = Auth::user()->id;
        $scopeData = CertificateStandardDetail::where('at_user_id', $userid)->first();
        $remainDays = '';
        if (!empty($scopeData)) {
            $now = time(); // or your date as well
            $validity = strtotime($scopeData->validity_end_date);
            $datediff = $validity - $now;

            $remainDays = round($datediff / (60 * 60 * 24));
        }
        //dd($scopeData->scope_certificate_no??'aaa');



        return view('admin/usermanagement/scope_renewal/scope-renewal', compact('remainDays', 'scopeData'));
    }

    public function registrationDetail()
    {
        $userid = Auth::user()->id;
        $user  = User::where('id', $userid)->first();
        $states = RefState::orderBy('state_name', 'ASC')->get();

        return view('admin/usermanagement/scope_renewal/registration-detail', compact('states', 'user'));
    }


    public function registrationDetailUpdate(Request $request, $id)
    {
        try {
            // dd($request->all());
            $this->validate(
                $request,
                [
                    'email' => 'required',
                    'mobile_no' => 'required',
                    'pin' => 'required',
                    'address' => 'required',
                    'address_2' => 'required',
                    'contact_person_first_name' => 'required',
                    'contact_designation' => 'required',
                    'contact_person_email' => 'required',
                    'contact_person_mobile_number' => 'required',
                ],
                // [
                //     'airport_name.required' => 'Airport Name required',
                //     'state_sno.required' => 'State Name is required'
                // ]
            );

            $updateData = array(
                'first_name' => $request->first_name,
                'email' => $request->email,
                'fax' => $request->fax,
                'mobile_no' => $request->mobile_no,
                'address'     => $request->address,
                'address_2'     => $request->address_2,
                'pin'     => $request->pin,
                'contact_person_first_name'     => $request->contact_person_first_name,
                'designation'     => $request->contact_designation,
                'contact_person_email'     => $request->contact_person_email,
                'contact_person_mobile_number'  => $request->contact_person_mobile_number,
                'updated_by' => Auth::guard('misadmin')->user()->id
            );

            User::where('id', $id)->update($updateData);
            Alert::success('Success', 'Updated Successfully');
            return redirect()->route('superadmin.icsuser.scopeFarmerDetail');
        } catch (Exception $e) {
            Alert::error('Error', $e->getMessage());
            \Log::error($e->getMessage());
            abort(404);
        } catch (\Illuminate\Database\QueryException $exception) {
            Alert::error('Error', $exception->getMessage());
            \Log::error($exception->getMessage());
            Alert::error('error', "Query Exception");
            return redirect()->back()->with('loader', true);
        }
    }



    public function scopeFarmerDetail()
    {
        $userid = Auth::user()->id;
        $user  = User::where('id', $userid)->first();
        $scopeCerDet = CertificateStandardDetail::where('at_user_id', $userid)->first();
        //dd($scopeCerDet);
        return view('admin/usermanagement/scope_renewal/farmer-detail', compact('user', 'scopeCerDet'));
    }

    public function searchFarmer(Request $request)
    {
        // dd($request->all());
        $userId = Auth::guard('misadmin')->user()->id;

        $farmerDet = AtFarmerRegDetail::where(function ($query) use ($request) {
            $query->where('registration_no', $request->farmer_name)
                ->orWhere('farmer_first_name', 'like', $request->farmer_name . '%');
        })->where(function ($query) use ($userId) {
            $query->where('at_user_id', $userId);
        })->get();
        $data = array();
        if (count($farmerDet) > 0) {
            foreach ($farmerDet as $key => $far) {
                $data[$key]['id'] = $far->id;
                $data[$key]['registration_no'] = $far->registration_no ?? '';
                $data[$key]['farmer_name'] = $far->farmer_first_name ?? '';
                $data[$key]['reg_date'] = date('d-m-Y', strtotime($far->registration_date));
                $data[$key]['address'] = getAddress('at_farmer_reg_details', 'id', $far->id);
                $data[$key]['status'] = $far->farmer_reg_status == 1 ? 'Active' : 'Pending';
            }
            return json_encode(['status' => 1, 'data' => $data]);
        } else {
            return json_encode(['status' => 0, 'data' => 'No Farmer Found.']);
        }
    }

    public function farmListByFarmer($fid)
    {

        $userid = Auth::user()->id;
        $farmDet  = AtFarmerLandDetail::where('at_farmer_reg_details_id', $fid)->get();
        return view('admin/usermanagement/scope_renewal/farm_list', compact('farmDet', 'userid', 'fid'));
    }

    public function addFarmerbyScopeRenewal(Request $request, $type = '')
    {
        $farmDet = '';
        $noc_no = '';

        if (!empty($type) && $type == 'noc') {
            if ($request->method() == 'POST') {
                $result  = AtOpNocDetails::with('farmernDetail')->where('noc_application_no', $request->noc_no)->first();
                if (!empty($result->farmernDetail)) {
                    $farmDet = $result->farmernDetail;
                    //dd($farmDet);
                    $noc_no = $request->noc_no;
                } else {
                    Alert::error('', 'No farmer found.');
                    return redirect()->back();
                }
            }
        }
        return view('admin/usermanagement/scope_renewal/add-farmer', compact('type', 'farmDet', 'noc_no'));
    }
    public function storeFarmerbyScopeRenewal(Request $request)
    {

        try {
            //dd($request->all());
            $request->validate([
                'aadhar_number' => 'required',
                'farmer_name' => 'required',
                'gender' => 'required',
                'father_flag' => 'required',
                'father_name' => 'required',
                'mobile_no' => 'required',
                'email' => 'required',
                'address' => 'required',
                'state' => 'required',
                'district' => 'required',
                'taluka' => 'required',
                'village' => 'required',
                'pincode' => 'required',
                'land_address' => 'required',
                'number_of_farm' => 'required',
                'total_Area.*' => 'required',
                'survey.*' => 'required',
            ]);

            $data = array(
                'at_user_id' => Auth::guard('misadmin')->user()->id,
                'farmer_first_name' => $request->farmer_name,
                'registration_date' => date('Y-m-d'),
                'email_id' => $request->email,
                'mobile_no' => $request->mobile_no,
                'farmer_address' => $request->address,
                'ref_village_id' => $request->village,
                'ref_block_tehsil_id' => $request->taluka,
                'ref_district_id' => $request->district,
                'ref_state_id' => $request->state,
                'pin' => $request->pincode,
                'aadhar_number' => $request->aadhar_number,
                'landmark' => $request->land_address,
                'gender' => $request->gender,
                'father_husband_flag' => $request->father_flag,
                'father_husband_first_name' => $request->father_name,
                'no_of_farm' => $request->number_of_farm,
                'created_by' => Auth::guard('misadmin')->user()->id,
                'updated_by' => Auth::guard('misadmin')->user()->id

            );
            $farmer = AtFarmerRegDetail::create($data);

            $reg_no = getFarmerRegNo($farmer->id, $request->state);
            AtFarmerRegDetail::where('id', $farmer->id)->update(['registration_no' => $reg_no, 'owner_farmerid' => $reg_no]);

            foreach ($request->survey as $key => $val) {

                $data1 = array(
                    'at_farmer_reg_details_id' => $farmer->id,
                    'survay_no' => $request->survey[$key],
                    'area_in_ha' => $request->total_Area[$key],
                    'total_area' => $request->total_Area[$key],
                    'created_by' => Auth::guard('misadmin')->user()->id,
                    'updated_by' => Auth::guard('misadmin')->user()->id
                );


                $farm = AtFarmerLandDetail::create($data1);
                $farmreg_no = getFarmRegNo($farm->id, $request->state);
                AtFarmerLandDetail::where('id', $farm->id)->update(['registration_no' => $farmreg_no, 'farm_no' => $farmreg_no]);
            }
            Alert::success('Success', 'Farmer add successfully. You can add another farmer.');
            return redirect()->back();
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }


    public function storeFarmbyScopeRenewal(Request $request)
    {

        try {
            $request->validate([

                'number_of_farm' => 'required',
                'total_Area.*' => 'required',
                'survey.*' => 'required',
            ]);

            $farmer = AtFarmerRegDetail::where('id', $request->farmer_id)->first();

            foreach ($request->survey as $key => $val) {

                $data = array(
                    'at_farmer_reg_details_id' => $request->farmer_id,
                    'survay_no' => $request->survey[$key],
                    'area_in_ha' => $request->total_Area[$key],
                    'total_area' => $request->total_Area[$key],
                    'created_by' => Auth::guard('misadmin')->user()->id,
                    'updated_by' => Auth::guard('misadmin')->user()->id
                );


                $farm = AtFarmerLandDetail::create($data);
                $farmreg_no = getFarmRegNo($farm->id, $farmer->ref_state_id);
                AtFarmerLandDetail::where('id', $farm->id)->update(['registration_no' => $farmreg_no, 'farm_no' => $farmreg_no]);
            }
            Alert::success('Success', 'Farm(s) add successfully.');
            return redirect()->back();
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function deleteFarmer(Request $request)
    {
        try {

            $id = $request->id;
            $user = AtFarmerRegDetail::find($id);
            $user->deleted_at = date('Y-m-d H:i:s');
            $user->save();

            UserInspector::where('at_user_id', $id)->delete();
            return json_encode(['message' => 'done']);
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function internalInspection()
    {

        $userid = Auth::user()->id;
        $farInsComplete = AtFarmerRegDetail::where(['at_user_id' => $userid, 'inspection_status' => 1])->get();
        // $farInsPending = AtFarmerRegDetail::where('at_user_id',$userid)->where('inspection_status',0)->orWhere('inspection_status',null)->get();

        $farInsPending = AtFarmerRegDetail::where(function ($query) {
            $query->where('inspection_status', 0)
                ->orWhere('inspection_status', null);
        })->where(function ($query) use ($userid) {
            $query->where('at_user_id', $userid);
        })->get();

        return view('admin/usermanagement/scope_renewal/internal-inspection', compact('farInsComplete', 'farInsPending'));
    }

    public function ospDetail($fid)
    {
        $farDet = AtFarmerRegDetail::where('id', $fid)->first();
        $ospDet = AtOspIcsIndividual::where('at_farmer_reg_details_id', $fid)->first();
        //dd($ospDet);

        return view('admin/usermanagement/scope_renewal/osp-details', compact('farDet', 'ospDet', 'fid'));
    }
    public function storeOspDetail(Request $request)
    {
        //dd($request->all());
        $fid = $request->fid;
        $newUser = AtOspIcsIndividual::updateOrCreate([
            'at_farmer_reg_details_id' => $request->fid,

        ], [
            "source_of_organic_system_plan" => $request->source_of_organic_system_plan,
            "cropping_pattern" => $request->cropping_pattern,
            "covered_area_main_corp" => $request->covered_area_main_corp,
            "covered_area_inter_corp" => $request->covered_area_inter_corp,
            "off_farm" => $request->off_farm,
            "on_farm" => $request->on_farm,
            "at_farmer_reg_details_id" => $request->fid,
            "created_by" => Auth::guard('misadmin')->user()->id
        ]);


        Alert::success('Success', 'Data save successfully.');
        return redirect()->route('superadmin.icsuser.scopeRenewalForwardToCB', $fid);
    }

    public function scopeRenewalForwardToCB($fid)
    {
        $userid = Auth::user()->id;
        return view('admin/usermanagement/scope_renewal/scope-renewal-forword-cb', compact('userid', 'fid'));
    }
    public function storeScopeRenewalForwardToCB(Request $request)
    {
        $userid = Auth::user()->id;
        $fid = $request->farmer_id;
        $getFarmer = AtFarmerRegDetail::where(['at_user_id' => $userid])->get();
        $chkInspDet = array();
        $chkOsppDet = array();
        $errors = array();
        foreach ($getFarmer as $k => $val) {
            $chkInspDet[] .= AtFarmerRegDetail::where(['id' => $val->id, 'inspection_status' => 1])->count();
            $chkOsppDet[] .= AtOspIcsIndividual::where('at_farmer_reg_details_id', $val->id)->count();
        }
        //dd($chkInspDet, $chkOsppDet);

        if (in_array(0, $chkInspDet)) {
            $errors['insp'] = "Incomplete internal Inspection.";
        }
        if (in_array(0, $chkOsppDet)) {
            $errors['osp'] = "OSP Details are required.";
        }

        // if(!empty($errors)){

        //     return view('admin/usermanagement/scope_renewal/scope-renewal-forword-cb',compact('userid','fid','errors'));
        // }
        return redirect()->route('superadmin.icsuser.previewApplication', $fid);
    }

    public function previewApplication($fid)
    {
        $userid = Auth::user()->id;
        $regDet = User::where('id', $userid)->first();
        $farmerDet = AtFarmerRegDetail::where(['at_user_id' => $userid])->get();
        $ospDet =  AtOspIcsIndividual::where('at_farmer_reg_details_id', $fid)->first();
        return view('admin/usermanagement/scope_renewal/preview-application', compact('userid', 'fid', 'regDet', 'farmerDet', 'ospDet'));
    }

    public function applicationForwardToCB(Request $request)
    {
        $admin = User::find(3);
        $userid = Auth::user()->id;
        $opertor_name = Auth::user()->first_name;
        $name_cb  =  getcbNameById(Auth::user()->created_by);

        //$fid = $request->farmer_id;
        $result = CertificateStandardDetail::where(['at_user_id' => $userid])->update(['is_renewed' => 1, 'status' => 0]);
        //dd($result);
        Notification::send($admin, new ScopeAmendedNotification($opertor_name,  $name_cb));

        if ($result) {
            Alert::success('success', 'Application forword to CB Successfully.');
            return redirect()->back();
        }
    }
    public function panalty(Request $request)
    {

        // dd(auth()->user()->first_name);
        $stateId =  $request->state_id;

        abort_unless(\Gate::allows('user_access'), 403);

        $userId = Auth::id();
        // dd($userId);
        $states = RefState::orderBy('state_name', 'ASC')->get();
        // $operator = User::select('ref_operator_type_id', 'first_name', 'user_name')->where('created_by',  $userId)->first();

        $operator = User::where('id', 383)->first();


        $validity = CertificateStandardDetail::where(['at_user_id' => 455])->first();

        if ($request->ajax()) {
            // dd($request->all());

            $query = User::with(['operatorType', 'certificateStandardDetails'])
                ->where('ref_operator_type_id', '!=', '1')
                ->where('created_by', $userId)
                ->where('status', 2)
                ->whereHas('certificateStandardDetails', function ($query) {
                    $query->where('status', 1);
                })
                ->when(!empty($stateId), function ($query) use ($stateId) {
                    $query->where('ref_state_id', $stateId);
                })
                ->orderBy('id', 'DESC');


            if ($request->has('operator_status') && $request->input('operator_status') !== '0') {
                $query->where('operator_status', $request->input('operator_status'));
            }

            $users = $query->get();

            return Datatables::of($users)
                ->addIndexColumn()
                ->addColumn('ref_operator_type_id', function ($row) {
                    return $row->operatorType->operator_type ?? '';
                })->addColumn('application_no', function ($row) {



                    $actionBtn =
                        "<strong>App No:</strong> #" . str_pad($row->id, 5, "0", STR_PAD_LEFT) . "<br>" .
                        "<strong>App Date:</strong> " . date('d-m-Y', strtotime($row->created_at ?? '')) . "<br>" .
                        "<strong>App Time:</strong> " . ($row->created_at ?? '')->format('h:i:s A');


                    return $actionBtn;
                })->addColumn('reg_no', function ($row) {
                    // if($row->ref_operator_type_id == 2 && $row->status==2){
                    //$st = getRegno($row->id,$row->ref_operator_type_id);
                    // }else{
                    // $st ="NA";
                    // }

                    $actionBtn =
                        "<strong>Reg No:</strong> " . ($row->registration_no ?? 'Not Allotted') . "<br>";

                    if ($row->registration_no === null || $row->registration_no === '') {
                        // If registration number is not allotted, also set Reg Date and Reg By as Not Allotted
                        $actionBtn .= "<strong>Reg Date:</strong> Not Allotted" . "<br>";
                        $actionBtn .= "<strong>Reg By:</strong> " . (getcbNameById($row->created_by ?? 'Not Available')) . "<br>";
                    } else {
                        // Otherwise, display the Reg Date and Reg By
                        $actionBtn .= "<strong>Reg Date:</strong> " . date('d-m-Y', strtotime($row->updated_at ?? '')) . "<br>";
                        $actionBtn .= "<strong>Reg By:</strong> " . (getcbNameById($row->created_by ?? 'Not Available')) . "<br>";
                    }

                    return $actionBtn;
                })
                ->addColumn('operator_name', function ($row) {

                    $firstName = $row->first_name ?? '';
                    $lastName = $row->last_name ?? '';
                    $address = $row->address ?? '';
                    $pan =    $row->user_name ?? '';
                    $state = getStateName($row->ref_state_id) ?? '';

                    $actionBtn =
                        "PAN: "   . $pan . "<br>" .
                        "Name: " . trim($firstName . ' ' . $lastName) . "<br>" .
                        "Address: " . $address . "<br>" .
                        "State : "  . $state;

                    return $actionBtn;

                    //return user_name($row->id);
                })
                // ->addColumn('reg_no', function ($row) {

                //     return $row->registration_no ?? '';
                // })
                ->addColumn('scp_no', function ($row) {
                    // Check if the relationship is not empty and then concatenate the values
                    $scopeCertificateNo = $row->certificateStandardDetails[0]->scope_certificate_no ?? '';
                    $validityStartDate = date('d-m-Y', strtotime($row->certificateStandardDetails[0]->validity_start_date ?? ''));
                    $validityEndDate = date('d-m-Y', strtotime($row->certificateStandardDetails[0]->validity_end_date ?? ''));

                    // Concatenate the values
                    return   $scopeCertificateNo . '<br>'  . "Start Date: "  . $validityStartDate . '<br>'  . "End Date: "  . $validityEndDate;
                })

                ->addColumn('contact_details', function ($row) {
                    // return $row->email ?? '';


                    $actionBtn =
                        "Name: " . ($row->contact_person_first_name ?? '') . " " . ($row->contact_person_last_name ?? '') . "<br>" .
                        "Mobile No: " . ($row->mobile_no ?? '') . "<br>" .
                        "Email Id: " . ($row->email ?? '');
                    //   "Aadhar No: " . ($row->contact_person_aadhar_number ?? '');

                    return $actionBtn;
                })
                ->addColumn('ref_state_id', function ($row) {
                    return getStateName($row->ref_state_id) ?? '';
                })
                ->addColumn('mobile', function ($row) {
                    return $row->mobile_no ?? '';
                })

                ->addColumn('created_on', function ($row) {

                    return  date('d-m-Y', strtotime($row->created_at)) ?? '';
                })->addColumn('operator_status', function ($row) {
                    // Set the default operator status as ""
                    $operator_status = '<span class="badge badge-soft-success">Self Register</span>'; // Default valueSelf Register

                    // Now, check for specific statuses and override if applicable
                    if ($row->operator_status == 1) {
                        $operator_status = '<span class="badge badge-soft-danger">Risky Operator</span>';
                    } elseif ($row->operator_status == 2) {
                        $operator_status = '<span class="badge badge-soft-primary">High Risk Product</span>';
                    } elseif ($row->operator_status == 3) {
                        $operator_status = '<span class="badge badge-soft-primary">Withdrawal By CB</span>';
                    } elseif ($row->operator_status == 4) {
                        $operator_status = '<span class="badge badge-soft-primary">Withdrawal By Operator</span>';
                    } elseif ($row->operator_status == 5) {
                        $operator_status = '<span class="badge badge-soft-primary">De Registered</span>';
                    }

                    return $operator_status;
                })
                ->addColumn('action', function ($row) {
                    $oper_type = $row->ref_operator_type_id ?? '';
                    $addEditDetailButton = '';
                    if (Auth::guard('misadmin')->user()->roles[0]->id == 1) {
                        $addEditDetailButton .= '<div class="input-group statusdata">
                        <select class="form-control"  data-value="' . $row->id . '" onChange="getModelSTWWDR(' . $row->id . ',this.value)">
                                <option selected disabled>-Select-</option>
                                <option value="1">Suspend</option>
                                <option value="2">Terminate</option>
                                <option value="3">Withdrawal By CB</option>
                                <option value="4">Withdrawal By Operator</option>
                                <option value="5">De Register</option>

                            </select>
                        </div>
                        ';
                        // $addEditDetailButton .= '<a href=' . route('superadmin.usermanagement.panaltyview', [$row->id]) . ' target="_blank"><span><i class="mdi mdi-eye text-muted fs-16 align-middle me-1" data-toggle="tooltip"  title="View User"></i></span></a>';
                        // Delete button
                        $addEditDetailButton .= '<a href="JavaScript:void(0);" class="deletedata" data-value="' . $row->id . '"><span><i class="mdi mdi-delete-circle text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Delete User"></i></span></a>';
                    }
                    return $addEditDetailButton;
                })
                ->rawColumns(['action', 'role', 'operator_status', 'contact_details', 'scp_no', 'operator_name', 'application_no', 'reg_no'])
                ->make(true);
        }

        return view('admin/usermanagement/deptUser/panalty', compact('operator', 'validity'));
    }


    public function panaltyTemplate(Request $request)
    {

        $userId = Auth::id();
        $selectval =  $request->selectVal;
        $query = User::with(['operatorType', 'certificateStandardDetails'])
            ->where('ref_operator_type_id', '!=', '1')
            ->where('created_by', $userId)
            ->where('id', $request->user_id)
            ->whereHas('certificateStandardDetails', function ($query) {
                $query->where('status', 1);
            })
            ->orderBy('id', 'DESC');
        $users = $query->first();

        return view('admin.usermanagement.deptUser.templatemodelicsprofile', compact('users', 'selectval'))->render();
    }

    public function discon(Request $request)
    {
        $userId = Auth::id();

        if ($request->ajax()) {
            $query = User::whereHas('certificateStandardDetails', function ($query) {
                $query->where('validity_end_date', '<', now());
            })
                ->orderBy('id', 'DESC');

            $users = $query->get();

            return Datatables::of($users)
                ->addIndexColumn()
                ->addColumn('ref_operator_type_id', function ($row) {
                    return $row->operatorType->operator_type ?? ''; // Safely handle missing operatorType
                })
                ->addColumn('app_no', function ($row) {
                    $actionBtn =
                        "App No: " . "#" . ($row->id ?? '') . "<br>" .
                        "App Date: " . (isset($row->created_at) ? date('d-m-Y', strtotime($row->created_at)) : 'N/A') . "<br>" .
                        "App Time: " . (isset($row->created_at) ? $row->created_at->format('h:i:s A') : 'N/A');
                    return $actionBtn;
                })
                ->addColumn('reg_details', function ($row) {
                    $actionBtn =
                        "<strong>Reg No:</strong> " . ($row->registration_no ?? 'Not Allotted') . "<br>";

                    if (empty($row->registration_no)) {
                        $actionBtn .= "<strong>Reg Date:</strong> Not Allotted" . "<br>";
                        $actionBtn .= "<strong>Reg By:</strong> " . (getcbNameById($row->created_by) ?? 'Not Available') . "<br>";
                    } else {
                        $actionBtn .= "<strong>Reg Date:</strong> " . (isset($row->updated_at) ? date('d-m-Y', strtotime($row->updated_at)) : 'Not Available') . "<br>";
                        $actionBtn .= "<strong>Reg By:</strong> " . (getcbNameById($row->created_by) ?? 'Not Available') . "<br>";
                    }
                    return $actionBtn;
                })
                ->addColumn('opr_details', function ($row) {
                    $firstName = $row->first_name ?? '';
                    $lastName = $row->last_name ?? '';
                    $address = $row->address ?? '';
                    $pan = $row->user_name ?? '';
                    $pin = $row->pin ?? '';
                    $state = get_state_name($row->ref_state_id ?? '');

                    $actionBtn =
                        "<strong>PAN:</strong> " . ($pan ?? '') . "<br>" .
                        "<strong>Name:</strong> " . trim($firstName . ' ' . $lastName) . "<br>" .
                        "<strong>Address:</strong> " . ($address ?? '') . "<br>" .
                        "<strong>State:</strong> " . ($state ?? '') . "<br>" .
                        "<strong>Pin:</strong> " . ($pin ?? '');

                    return $actionBtn;
                })
                ->addColumn('scp_no', function ($row) {
                    return $row->certificateStandardDetails[0]->scope_certificate_no ?? ''; // Safe check for certificateStandardDetails
                })
                ->addColumn('contact_details', function ($row) {
                    $actionBtn =
                        "Name: " . (($row->contact_person_first_name ?? '') . " " . ($row->contact_person_last_name ?? '')) . "<br>" .
                        "Mobile No: " . ($row->mobile_no ?? '') . "<br>" .
                        "Email Id: " . ($row->email ?? '');
                    return $actionBtn;
                })
                ->addColumn('ref_state_id', function ($row) {
                    return getStateName($row->ref_state_id) ?? ''; // Safe check for missing ref_state_id
                })
                ->addColumn('mobile', function ($row) {
                    return $row->mobile_no ?? ''; // Safe check for missing mobile number
                })
                ->addColumn('created_on', function ($row) {
                    return isset($row->created_at) ? date('d-m-Y', strtotime($row->created_at)) : ''; // Safe check for created_at
                })
                ->addColumn('action', function ($row) {
                    // Add your action column logic here
                })
                ->rawColumns(['action', 'role', 'operator_status', 'contact_details', 'app_no', 'reg_details', 'opr_details'])
                ->make(true);
        }

        return view('admin/usermanagement/deptUser/discon_list');
    }


    public function nocoperator(Request $request)
    {


        $userId = Auth::id();
        if ($request->ajax()) {
            // dd($request->all());

            // $query = User::where('ref_operator_type_id', '!=', '1')
            //     ->where('created_by', $userId)
            //     ->whereIn('operator_status', [1, 2, 3, 4, 5])
            //     ->whereHas('certificateStandardDetails', function ($query) {
            //         $query->where('status', 1);
            //     })
            //     ->orderBy('id', 'DESC');

            // $users = $query->get();

            $query = User::whereIn('operator_status', [1, 2, 3, 4, 5])
                ->whereHas('certificateStandardDetails', function ($query) {
                    $query->where('status', 1);
                })
                ->orderBy('id', 'DESC');

            $users = $query->get();

            if ($request->has('operator_status') && $request->input('operator_status') !== '0') {
                $query->where('operator_status', $request->input('operator_status'));
            }


            return Datatables::of($users)
                ->addIndexColumn()
                ->addColumn('ref_operator_type_id', function ($row) {

                    $firstName = $row->first_name ?? '';
                    $lastName = $row->last_name ?? '';
                    $address = $row->address ?? '';
                    $pan = $row->user_name ?? '';
                    $pin = $row->pin ?? '';
                    $type = $row->operatorType->operator_type ?? '';
                    $state = get_state_name($row->ref_state_id ?? '');

                    $actionBtn =
                        "<strong>PAN:</strong> " . $pan . "<br>" .
                        "<strong>Name:</strong> " . trim($firstName . ' ' . $lastName) . "<br>" .
                        "<strong>Opertor Type:</strong> " . $type . "<br>" .
                        "<strong>Address:</strong> " . $address . "<br>" .
                        "<strong>State:</strong> " . $state . "<br>" .
                        "<strong>Pin:</strong> " . $pin;



                    return $actionBtn;


                    //  return $row->operatorType->operator_type ?? '';

                })



                ->addColumn('operator_name', function ($row) {

                    return user_name($row->id);
                })

                ->addColumn('noc_no', function ($row) {



                    $actionBtn =
                        "<strong>NOC No:</strong> #" . str_pad($row->id, 5, "0", STR_PAD_LEFT) . "<br>" .
                        "<strong>NOC Date:</strong> " . date('d-m-Y', strtotime($row->created_at ?? '')) . "<br>" .
                        "<strong>NOC Certificate No:</strong> NOC/ " . ($row->id ?? '');


                    return $actionBtn;
                })
                ->addColumn('application_no', function ($row) {



                    $actionBtn =
                        "<strong>App No:</strong> #" . str_pad($row->id, 5, "0", STR_PAD_LEFT) . "<br>" .
                        "<strong>App Date:</strong> " . date('d-m-Y', strtotime($row->created_at ?? '')) . "<br>" .
                        "<strong>App Time:</strong> " . ($row->created_at ?? '')->format('h:i:s A');


                    return $actionBtn;
                })

                ->addColumn('reg_no', function ($row) {
                    // if($row->ref_operator_type_id == 2 && $row->status==2){
                    //$st = getRegno($row->id,$row->ref_operator_type_id);
                    // }else{
                    // $st ="NA";
                    // }

                    $actionBtn =
                        "<strong>Reg No:</strong> " . ($row->registration_no ?? 'Not Allotted') . "<br>";

                    if ($row->registration_no === null || $row->registration_no === '') {
                        // If registration number is not allotted, also set Reg Date and Reg By as Not Allotted
                        $actionBtn .= "<strong>Reg Date:</strong> Not Allotted" . "<br>";
                        $actionBtn .= "<strong>Reg By:</strong> " . (getcbNameById($row->created_by ?? 'Not Available')) . "<br>";
                    } else {
                        // Otherwise, display the Reg Date and Reg By
                        $actionBtn .= "<strong>Reg Date:</strong> " . date('d-m-Y', strtotime($row->updated_at ?? '')) . "<br>";
                        $actionBtn .= "<strong>Reg By:</strong> " . (getcbNameById($row->created_by ?? 'Not Available')) . "<br>";
                    }

                    return $actionBtn;
                })


                // ->addColumn('scp_no', function ($row) {


                //     return $row->certificateStandardDetails[0]->scope_certificate_no ?? '';
                // })

                ->addColumn('scp_no', function ($row) {
                    // Check if the relationship is not empty and then concatenate the values
                    $scopeCertificateNo = $row->certificateStandardDetails[0]->scope_certificate_no ?? '';
                    $validityStartDate = date('d-m-Y', strtotime($row->certificateStandardDetails[0]->validity_start_date ?? ''));
                    $validityEndDate = date('d-m-Y', strtotime($row->certificateStandardDetails[0]->validity_end_date ?? ''));

                    // Concatenate the values
                    return   $scopeCertificateNo . '<br>'  . "Start Date: "  . $validityStartDate . '<br>'  . "End Date: "  . $validityEndDate;
                })
                ->addColumn('contact_details', function ($row) {
                    // return $row->email ?? '';


                    $actionBtn =
                        "Name: " . ($row->contact_person_first_name ?? '') . " " . ($row->contact_person_last_name ?? '') . "<br>" .
                        "Mobile No: " . ($row->mobile_no ?? '') . "<br>" .
                        "Email Id: " . ($row->email ?? '');
                    //   "Aadhar No: " . ($row->contact_person_aadhar_number ?? '');

                    return $actionBtn;
                })
                ->addColumn('ref_state_id', function ($row) {
                    return getStateName($row->ref_state_id) ?? '';
                })
                ->addColumn('mobile', function ($row) {
                    return $row->mobile_no ?? '';
                })

                ->addColumn('created_on', function ($row) {

                    return  date('d-m-Y', strtotime($row->created_at)) ?? '';
                })->addColumn('operator_status', function ($row) {
                    $operator_status = '';
                    if ($row->operator_status == 1)
                        return  '<span class="badge badge-soft-danger">Suspended</span>';
                    elseif ($row->operator_status == 2)
                        return  '<span class="badge badge-soft-primary">Terminated</span>';
                    elseif ($row->operator_status == 3)
                        return  '<span class="badge badge-soft-primary">Withdrawal By CB</span>';
                    elseif ($row->operator_status == 4)
                        return  '<span class="badge badge-soft-primary">Withdrawal By Operator</span>';
                    elseif ($row->operator_status == 5)
                        return  '<span class="badge badge-soft-primary">De Registered</span>';
                })
                ->addColumn('action', function ($row) {

                    // $oper_type = $row->ref_operator_type_id ?? '';
                    // $addEditDetailButton = '';
                    // if (Auth::guard('misadmin')->user()->roles[0]->id == 1) {
                    //     $addEditDetailButton .= '<div class="input-group mt-2 statusdata">
                    //     <select class="form-control"  data-value="' . $row->id . '">
                    //             <option selected disabled>-Select-</option>
                    //             <option value="1">Suspend</option>
                    //             <option value="2">Terminate</option>
                    //             <option value="3">Withdrawal By CB</option>
                    //             <option value="4">Withdrawal By Operator</option>
                    //             <option value="5">De Register</option>

                    //         </select>
                    //     </div>
                    //     ';
                    //     // $addEditDetailButton .= '<a href=' . route('superadmin.usermanagement.panaltyview', [$row->id]) . ' target="_blank"><span><i class="mdi mdi-eye text-muted fs-16 align-middle me-1" data-toggle="tooltip"  title="View User"></i></span></a>';
                    //     // Delete button
                    //     $addEditDetailButton .= '<a href="JavaScript:void(0);" class="deletedata" data-value="' . $row->id . '"><span><i class="mdi mdi-delete-circle text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Delete User"></i></span></a>';
                    // }
                    // return $addEditDetailButton;
                })
                ->rawColumns(['action', 'role', 'operator_status', 'contact_details', 'application_no', 'reg_no', 'ref_operator_type_id', 'scp_no', 'noc_no'])
                ->make(true);
        }

        return view('admin/usermanagement/deptUser/noc_register_list');
    }


    public function discontinued(Request $request)
    {

        $userId = Auth::id();
        if ($request->ajax()) {
            // dd($request->all());

            // $query = User::where('ref_operator_type_id', '!=', '1')
            //     ->where('created_by', $userId)
            //     ->whereIn('operator_status', [1, 2, 3, 4, 5])
            //     ->whereHas('certificateStandardDetails', function ($query) {
            //         $query->where('status', 1);
            //     })
            //     ->orderBy('id', 'DESC');

            // $users = $query->get();

            $query = User::whereIn('operator_status', [1, 2, 3, 4, 5])
                ->whereHas('certificateStandardDetails', function ($query) {
                    $query->where('status', 1);
                })
                ->orderBy('id', 'DESC');

            $users = $query->get();

            if ($request->has('operator_status') && $request->input('operator_status') !== '0') {
                $query->where('operator_status', $request->input('operator_status'));
            }


            return Datatables::of($users)
                ->addIndexColumn()
                ->addColumn('ref_operator_type_id', function ($row) {

                    $firstName = $row->first_name ?? '';
                    $lastName = $row->last_name ?? '';
                    $address = $row->address ?? '';
                    $pan = $row->user_name ?? '';
                    $pin = $row->pin ?? '';
                    $type = $row->operatorType->operator_type ?? '';
                    $state = get_state_name($row->ref_state_id ?? '');

                    $actionBtn =
                        "<strong>PAN:</strong> " . $pan . "<br>" .
                        "<strong>Name:</strong> " . trim($firstName . ' ' . $lastName) . "<br>" .
                        "<strong>Opertor Type:</strong> " . $type . "<br>" .
                        "<strong>Address:</strong> " . $address . "<br>" .
                        "<strong>State:</strong> " . $state . "<br>" .
                        "<strong>Pin:</strong> " . $pin;



                    return $actionBtn;


                    //  return $row->operatorType->operator_type ?? '';

                })



                ->addColumn('operator_name', function ($row) {

                    return user_name($row->id);
                })


                ->addColumn('application_no', function ($row) {



                    $actionBtn =
                        "<strong>App No:</strong> #" . str_pad($row->id, 5, "0", STR_PAD_LEFT) . "<br>" .
                        "<strong>App Date:</strong> " . date('d-m-Y', strtotime($row->created_at ?? '')) . "<br>" .
                        "<strong>App Time:</strong> " . ($row->created_at ?? '')->format('h:i:s A');


                    return $actionBtn;
                })

                ->addColumn('reg_no', function ($row) {
                    // if($row->ref_operator_type_id == 2 && $row->status==2){
                    //$st = getRegno($row->id,$row->ref_operator_type_id);
                    // }else{
                    // $st ="NA";
                    // }

                    $actionBtn =
                        "<strong>Reg No:</strong> " . ($row->registration_no ?? 'Not Allotted') . "<br>";

                    if ($row->registration_no === null || $row->registration_no === '') {
                        // If registration number is not allotted, also set Reg Date and Reg By as Not Allotted
                        $actionBtn .= "<strong>Reg Date:</strong> Not Allotted" . "<br>";
                        $actionBtn .= "<strong>Reg By:</strong> " . (getcbNameById($row->created_by ?? 'Not Available')) . "<br>";
                    } else {
                        // Otherwise, display the Reg Date and Reg By
                        $actionBtn .= "<strong>Reg Date:</strong> " . date('d-m-Y', strtotime($row->updated_at ?? '')) . "<br>";
                        $actionBtn .= "<strong>Reg By:</strong> " . (getcbNameById($row->created_by ?? 'Not Available')) . "<br>";
                    }

                    return $actionBtn;
                })


                // ->addColumn('scp_no', function ($row) {


                //     return $row->certificateStandardDetails[0]->scope_certificate_no ?? '';
                // })

                ->addColumn('scp_no', function ($row) {
                    // Check if the relationship is not empty and then concatenate the values
                    $scopeCertificateNo = $row->certificateStandardDetails[0]->scope_certificate_no ?? '';
                    $validityStartDate = date('d-m-Y', strtotime($row->certificateStandardDetails[0]->validity_start_date ?? ''));
                    $validityEndDate = date('d-m-Y', strtotime($row->certificateStandardDetails[0]->validity_end_date ?? ''));

                    // Concatenate the values
                    return   $scopeCertificateNo . '<br>'  . "Start Date: "  . $validityStartDate . '<br>'  . "End Date: "  . $validityEndDate;
                })
                ->addColumn('contact_details', function ($row) {
                    // return $row->email ?? '';


                    $actionBtn =
                        "Name: " . ($row->contact_person_first_name ?? '') . " " . ($row->contact_person_last_name ?? '') . "<br>" .
                        "Mobile No: " . ($row->mobile_no ?? '') . "<br>" .
                        "Email Id: " . ($row->email ?? '');
                    //   "Aadhar No: " . ($row->contact_person_aadhar_number ?? '');

                    return $actionBtn;
                })
                ->addColumn('ref_state_id', function ($row) {
                    return getStateName($row->ref_state_id) ?? '';
                })
                ->addColumn('mobile', function ($row) {
                    return $row->mobile_no ?? '';
                })

                ->addColumn('created_on', function ($row) {

                    return  date('d-m-Y', strtotime($row->created_at)) ?? '';
                })->addColumn('operator_status', function ($row) {
                    $operator_status = '';
                    if ($row->operator_status == 1)
                        return  '<span class="badge badge-soft-danger">Suspended</span>';
                    elseif ($row->operator_status == 2)
                        return  '<span class="badge badge-soft-primary">Terminated</span>';
                    elseif ($row->operator_status == 3)
                        return  '<span class="badge badge-soft-primary">Withdrawal By CB</span>';
                    elseif ($row->operator_status == 4)
                        return  '<span class="badge badge-soft-primary">Withdrawal By Operator</span>';
                    elseif ($row->operator_status == 5)
                        return  '<span class="badge badge-soft-primary">De Registered</span>';
                })
                ->addColumn('action', function ($row) {

                    // $oper_type = $row->ref_operator_type_id ?? '';
                    // $addEditDetailButton = '';
                    // if (Auth::guard('misadmin')->user()->roles[0]->id == 1) {
                    //     $addEditDetailButton .= '<div class="input-group mt-2 statusdata">
                    //     <select class="form-control"  data-value="' . $row->id . '">
                    //             <option selected disabled>-Select-</option>
                    //             <option value="1">Suspend</option>
                    //             <option value="2">Terminate</option>
                    //             <option value="3">Withdrawal By CB</option>
                    //             <option value="4">Withdrawal By Operator</option>
                    //             <option value="5">De Register</option>

                    //         </select>
                    //     </div>
                    //     ';
                    //     // $addEditDetailButton .= '<a href=' . route('superadmin.usermanagement.panaltyview', [$row->id]) . ' target="_blank"><span><i class="mdi mdi-eye text-muted fs-16 align-middle me-1" data-toggle="tooltip"  title="View User"></i></span></a>';
                    //     // Delete button
                    //     $addEditDetailButton .= '<a href="JavaScript:void(0);" class="deletedata" data-value="' . $row->id . '"><span><i class="mdi mdi-delete-circle text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Delete User"></i></span></a>';
                    // }
                    // return $addEditDetailButton;
                })
                ->rawColumns(['action', 'role', 'operator_status', 'contact_details', 'application_no', 'reg_no', 'ref_operator_type_id', 'scp_no'])
                ->make(true);
        }




        return view('admin/usermanagement/deptUser/discontinued_list');
    }

    public function operatorhome(Request $request)
    {

        $userId = Auth::id();
        $query = User::select([
            'ref_operator_type_id',
            'first_name',
            'mobile_no',
            'email',
            'address',
            'registration_no',
            'contact_person_first_name',
            'created_at',
            'updated_at',
            'contact_person_pan_number',
            'contact_person_aadhar_number',
            'contact_person_gender',
            'id',
            'user_name',
            'pin',
            'ref_state_id',
            'contact_designation',
        ])->where(function ($query) use ($userId) {
            $query->where('created_by', $userId);
        })->where(function ($query) {
            $query->whereNotNull('contact_person_pan_number');
        })->orderBy('id', 'DESC')->get();

        if ($request->ajax()) {
            return Datatables::of($query)
                ->addIndexColumn()
                ->addColumn('ref_no', function ($row) {
                    $actionBtn =
                        "<strong>App No:</strong> " . ($row->contact_person_pan_number ?? '') . "<br>" .
                        "<strong>App Time:</strong> " . ($row->created_at ?? '')->format('h:i:s A') . "<br>" .
                        "<strong>App Date:</strong> " . date('d-m-Y', strtotime($row->created_at ?? ''));
                    return $actionBtn;
                })
                ->addColumn('operator_type', function ($row) {
                    return in_array($row->ref_operator_type_id, [2, 3, 4, 5, 6]) ? getOperatorTypeById($row->ref_operator_type_id ?? 'Not Found') : '';
                })
                ->addColumn('operator_name', function ($row) {
                    $firstName = $row->first_name ?? '';
                    $lastName = $row->last_name ?? '';
                    $address = $row->address ?? '';
                    $pan = $row->user_name ?? '';
                    $pin = $row->pin ?? '';
                    $state = get_state_name($row->ref_state_id ?? '');
                    $actionBtn =
                        "<strong>PAN:</strong> " . $pan . "<br>" .
                        "<strong>Name:</strong> " . trim($firstName . ' ' . $lastName) . "<br>" .
                        "<strong>Address:</strong> " . $address . "<br>" .
                        "<strong>State:</strong> " . $state . "<br>" .
                        "<strong>Pin:</strong> " . $pin;
                    return $actionBtn;
                })
                ->addColumn('reg_no', function ($row) {
                    $actionBtn =
                        "<strong>Reg No:</strong> " . ($row->registration_no ?? 'Not Allotted') . "<br>";
                    if ($row->registration_no === NULL || $row->registration_no === '') {
                        // If registration number is not allotted, also set Reg Date and Reg By as Not Allotted
                        $actionBtn .= "<strong>Reg Date:</strong> Not Allotted" . "<br>";
                    } else {
                        // Otherwise, display the Reg Date and Reg By
                        $actionBtn .= "<strong>Reg Date:</strong> " . date('d-m-Y', strtotime($row->updated_at ?? '')) . "<br>";
                        $actionBtn .= "<strong>Reg By:</strong> " . (getcbNameById($row->created_by ?? 'Not Available')) . "<br>";
                    }
                    return $actionBtn;
                })
                ->addColumn('cont_details', function ($row) {
                    $addhar = $row->contact_person_aadhar_number ?? '';
                    if (preg_match('/^eyJpdiI6.*$/', $addhar)) {
                        try {
                            $addhar = Crypt::decrypt($addhar);
                        } catch (DecryptException $e) {
                            $addhar = 'Invalid Aadhaar No';
                        }
                    }
                    $count = strlen((string) $addhar);
                    if ($count == 12) {
                        $aadhaarNumber =  maskAadhaarNumber($addhar ?? '');
                    } else {
                        $aadhaarNumber = '';
                    }

                    $actionBtn =
                        "<strong>Name:</strong> " . ($row->contact_person_first_name ?? '') . " " . ($row->contact_person_last_name ?? '') . "<br>" .
                        "<strong>Designation:</strong> " . ($row->contact_designation ?? '') . "<br>" .
                        "<strong>Mobile No:</strong> " . ($row->mobile_no ?? '') . "<br>" .
                        "<strong>Email Id:</strong> " . ($row->email ?? '') . "<br>" .
                        "<strong>Aadhaar No:</strong> " . ($aadhaarNumber);

                    return $actionBtn;
                })
                ->addColumn('created_on', function ($row) {

                    return date('d-m-Y', strtotime($row->created_at ?? null)) ?: 'N/A';
                })
                ->addColumn('action', function ($row) {

                    // $route = '';
                    // switch ($row->ref_operator_type_id) {
                    //     case 2:
                    //         $route = route('superadmin.usermanagement.deptUser', 2);
                    //         break;
                    //     case 3:
                    //         $route = route('superadmin.usermanagement.deptUser', 3);
                    //         break;
                    //     case 4:
                    //         $route = route('superadmin.usermanagement.deptUser', 4);
                    //         break;
                    //     case 5:
                    //         $route = route('superadmin.usermanagement.deptUser', 5);
                    //         break;
                    //     case 6:
                    //         $route = route('superadmin.usermanagement.deptUser', 6);
                    //         break;
                    //         // default:
                    //         //     $route = route('superadmin.usermanagement.deptUser');
                    //         //     break;
                    // }

                    // $button = '<a href="' . $route . '" target="_blank"><span><i class="mdi text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Process">Process</i></span></a>';

                    $button = '<a href=' . route('superadmin.usermanagement.operatorhomeview', $row->id) . ' target="_blank" class=""><span>Process</span></a>';
                    return $button;
                })
                ->rawColumns(['action', 'cont_details', 'ref_no', 'reg_no', 'operator_name'])
                ->make(true);
        }
        return view('admin.usermanagement.deptUser.organic_operator');
    }


    public function operatorhomeview(Request $request, $id)
    {

        $cbId =  Auth::guard('misadmin')->user()->id;
        $data =  User::where('id', $id)->first();

        //dd($data);

        return view('admin.usermanagement.deptUser.operatorhomeview', compact('data', 'cbId'));
    }




    public function panaltyview(Request $request, $id)
    {


        $user = User::where('id', $id)->first();

        $icsmandator = IcsMandator::where('at_user_id', $id)->first();
        $userInsp = UserInspector::where('at_user_id', $id)->get();
        $warehs = UserWarehouse::where('at_user_id', $id)->first();
        $wmanager = UserWarehouseManagerOfficers::where('at_user_id', $id)->where('user_type', 'WM')->get();
        $pmanager = UserWarehouseManagerOfficers::where('at_user_id', $id)->where('user_type', 'PM')->get();
        $foanager = UserWarehouseManagerOfficers::where('at_user_id', $id)->where('user_type', 'FO')->get();
        $amanager = UserWarehouseManagerOfficers::where('at_user_id', $id)->where('user_type', 'AM')->first();
        $farmerDetails = AtFarmerRegDetail::where('at_user_id', $id)->get();

        $states = RefState::orderBy('state_name', 'ASC')->get();
        $districts = RefDistrict::orderBy('district_name', 'ASC')->get();


        return view('admin.usermanagement.deptUser.panaltyview', compact('id', 'user', 'icsmandator', 'warehs', 'states', 'userInsp', 'wmanager', 'pmanager', 'foanager', 'amanager', 'districts', 'farmerDetails'));
    }




    public function pendingApplicationStockTransfer()
    {


        return view('admin/usermanagement/internal_stock_transfer/pending_application');
    }

    public function SearchSTN(Request $request)
    {
        try {
            // Check if the request is an AJAX request
            if ($request->ajax()) {

                $userId = Auth::id();


                $query = AtInternalStockTransfe::query()
                    ->orderBy('created_at', 'desc')
                    ->get();


                $finalData = $query;

                // dd($finalData);


                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()
                    ->addColumn('st_no', function ($row) {
                        return $row->transferee_scope_certification_no;
                    })
                    ->addColumn('date_app', function ($row) {
                        return date('d-m-Y', strtotime($row->date_of_internal_transfer ?? ''));
                    })
                    ->addColumn('transfer', function ($row) {
                        return $row->transfer_name;
                    })
                    ->addColumn('transferee', function ($row) {
                        return $row->transferee_name;
                    })
                    ->addColumn('status', function ($row) {
                        return $row->quantity_for_tc;
                    })
                    ->addColumn('days_left', function ($row) {
                        return $row->rem_qty;
                    })
                    ->addColumn('action', function ($row) {
                        // Define the View Application link
                        $viewLink = '<a href="' . route('superadmin.viewCBApplication', $row->id) . '">View Application</a>';

                        // Define the Process link
                        $processLink = '<a href="' . route('superadmin.ProccessApplication', $row->id) . '">Process Application</a>';

                        // Combine both links with a space or other separator
                        return $viewLink . ' | ' . $processLink;
                    })
                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            // Handle exceptions and log errors
            Log::error($e);
            Alert::error('Error', 'Something went wrong, please try again later.');
            return redirect()->back();
        }
    }

    public function ProccessApplication($id)
    {

        // $row = AtOpTransactionCertificateEntry::where('at_op_transaction_vs_transaction_product_id',$id)->first();
        $user_id = Auth::id();



        $data = AtInternalStockTransfe::where('id', $id)->first();

        $productdata = AtOpTransactionVsTransactionProduct::where('created_by', $user_id)->orderby('id', 'desc')->get();

        // dd($user_id);
        $authsign = User::whereHas('roles', function ($q) {
            return $q->where('title', 'Authorized Signatory');
        })->where('created_by', Auth::id())->get();
        return view('admin/usermanagement/internal_stock_transfer/proccess_application', compact('data', 'productdata', 'authsign'));
    }

    public function storeProccessApplication(Request $request)
    {
        $request->validate([

            'total_qty' => 'required',
            'signatory_code' => 'required',

        ]);
        try {
            $id = $request->cre_id;
            $data = array(
                'order_contract_no'   => $request->order_contract_no ?? null,
                'total_qty'   => $request->total_qty ?? null,
                'country_origin'   => $request->country_origin ?? null,
                'signatory_code'   => $request->signatory_code ?? null,
                'updated_by' => Auth::guard('misadmin')->user()->id
            );

            $saveData = AtOpTransactionCertificateEntry::where('id', $request->row_id)->create($data);

            // dd($saveData);

            if (!empty($saveData)) {
                Alert::success('Success', __('message.add_success'));
                return redirect()->route('superadmin.strequestCbcertificatepreviewst', ['tcid' => $request->tcid, 'userid' => $request->row_id]);
            } else {
                Alert::success('Success', 'Something Went Wrong!');
                return redirect()->back();
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function previewSt(Request $request, $tcid, $userid)
    {

        return view('admin.usermanagement.internal_stock_transfer.previewst', compact('tcid', 'userid'));
    }

    public function viewSTApplication($tcid, $userid)
    {

        $trans = AtOpTransactionVsTransactionProduct::with('getTransProductSource')->where('id', $tcid)->get();
        $data =  AtOpTransactionCertificateEntry::where('at_op_transaction_vs_transaction_product_id', $tcid)->first();

        return view('admin.usermanagement.internal_stock_transfer.viewApplication', compact('tcid', 'userid', 'trans', 'data'));
    }

    public function StViewApplication($id)
    {

        $tcIssueList = AtOpTransactionVsTransactionProduct::where('id', $id)->first();
        $stdata = AtInternalStockTransfe::where('id', $id)->first();

        $authsign = AtOpTransactionCertificateEntry::where('id', $id)->first();

        // dd($authsign);

        return view('admin.usermanagement.internal_stock_transfer.cbStviewApplication', compact('tcIssueList', 'stdata', 'authsign'));
    }

    public function StViewApplicationPdf($id)
    {

        $tcIssueList = AtOpTransactionVsTransactionProduct::where('id', $id)->first();
        $stdata = AtInternalStockTransfe::where('id', $id)->first();

        $authsign = AtOpTransactionCertificateEntry::where('id', $id)->first();
        $pdf = PDF::loadView('admin.usermanagement.internal_stock_transfer.cbStviewApplication', ['tcIssueList' => $tcIssueList, 'stdata' => $stdata, 'authsign' => $authsign]);
        return $pdf->download('Internal_Stock.pdf');
        // dd($authsign);

        // return view('admin.usermanagement.internal_stock_transfer.cbStviewApplication', compact('tcIssueList', 'stdata', 'authsign'));
    }



    //     public function pdfStApplication($tcid=43 ,$userid=208){

    //         $user =  User::where('id',Auth::user()->id)->first();
    //         $trans = AtOpTransactionVsTransactionProduct::with('getTransProductSource')->where('id',$tcid)->get();
    //         $data =  AtOpTransactionCertificateEntry::where('at_op_transaction_vs_transaction_product_id',$tcid)->first();
    //         //$customPaper = array(0,0,800.00,730.80);

    //         //echo view('admin/usermanagement/pdf/tcCertificate', compact('user','trans','data','userid'))->render();
    //         $pdf = PDF::loadView('admin/usermanagement/pdf/stCertificate', compact('user','trans','data','userid'));
    //         $rand = str_pad(mt_rand(1, 99999999), 8, '0', STR_PAD_LEFT);
    //         return $pdf->stream($rand.'.pdf');
    //         //$pdf->save(public_path($flname));
    //         // $pdf = PDF::loadView('member/cpdvideo/transaction_pdf', compact('template'))->setPaper($customPaper, 'landscape');
    //         //     $rand = str_pad(mt_rand(1, 99999999), 8, '0', STR_PAD_LEFT);
    //         //     return $pdf->download($rand.'.pdf');

    //    }

    public function generateST(Request $request)
    {
        $tcid = $request->tcid;
        $data = AtOpTransactionVsTransactionProduct::where('id', $tcid)->first();
        if ($data) {
            $m = date('m', strtotime($data->created_at));
            $y = date('y', strtotime($data->created_at));
            $lst = str_pad($data->id, 4, "0", STR_PAD_LEFT);

            $app_no = "ORG/ST/" . $y . $m . "/" . $lst;
        }
        $upData = array(
            'transaction_certificate_no' => $app_no,

        );

        $res =  AtOpTransactionVsTransactionProduct::where('id', $tcid)->update($upData);

        if ($res > 0) {
            Alert::success('Success', 'Internal Stock Transfer Generated.');
            return redirect()->route('superadmin.usermanagement.listApplicationStockTransfer');
        } else {
            Alert::error('', 'Something went Wrong.');
            return redirect()->back();
        }
    }
    // public function Status($id)
    // {
    //     $data = AtInternalStockTransfe::find($id);

    //     $data->status = 'approved';
    //     $data->save();

    //     return redirect()->route('admin/usermanagement/internal_stock_transfer/pending_application')->with('susccess', 'approved successfully');

    // }

    public function listApplicationStockTransfer()
    {
        $user_id = Auth::guard('misadmin')->user()->id;
        $List = AtInternalStockTransfe::orderBy('id', 'desc')->get();
        //print_r($List); die;

        $eMSignedModuleAlow = getUserDigitalSignatureModules(Auth::id(), 'IST');

        return view('admin/usermanagement/internal_stock_transfer/application_list', compact('List', 'eMSignedModuleAlow'));
    }


    public function listApplicationStockTransferPdf()
    {
        $user_id = Auth::guard('misadmin')->user()->id;
        $List = AtInternalStockTransfe::orderBy('id', 'desc')->get();
        // dd( $List);
        return view('admin/usermanagement/internal_stock_transfer/application_list', compact('List'));
    }


    public function panaltyDelete(Request $request)
    {
        try {
            $id = $request->id;
            $deletionReason = $request->deletionReason;



            $user = User::find($id);

            // Ensure the user exists before attempting to delete
            if ($user) {
                $user->is_deleted = 1;
                $user->deleted_at = now();
                $user->save();

                UserInspector::where('at_user_id', $id)->delete();

                DeletionLog::create([
                    'record_id' => $id,
                    'reason' => $deletionReason,
                ]);

                // dd('DeletionLog record created:', ['record_id' => $id, 'reason' => $deletionReason]);
                // Send email
                //  Mail::to('kumar.gaurav@velocis.co.in')->send(new RecordDeletedMail($user, $deletionReason));


                return json_encode(['message' => 'done']);
            } else {
                return json_encode(['message' => 'User not found']);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function updateUserStatus(Request $request)
    {

        //dd();
        $from_data = Carbon::parse($request->from_date)->format('Y-m-d');
        $to_date = Carbon::parse($request->to_date)->format('Y-m-d');

        $admin =  User::find(3);
        $cbname = auth()->user()->first_name;
        $useids = $request->user_id;
        $user = User::where('id', $useids)->first();
        $opertor_name = $user->first_name;
        $user->operator_status = $request->status;
        $user->from_date = $from_data;
        $user->to_date = $to_date;
        $user->to_years = $request->to_years;
        $user->remark = $request->remark;
        $user->save();

        //  dd($user-> first_name);
        Notification::send($admin, new OperatorSuspensionTerminationNotification($request->status, $request->remark, $cbname, $opertor_name));
        return response()->json(['message' => 'Operator status updated successfully'], 200);
    }


    public function editbatch()
    {

        return view('admin/usermanagement/batch/edit_batch');
    }



    public function BatchSearch(Request $request)
    {
        try {

            if ($request->ajax()) {

                $query = User::query()
                    ->whereNotNull('registration_no')
                    ->where('registration_no', '!=', '');

                $finalData = $query->select(
                    'id',
                    'registration_no',
                    'first_name',
                    'ref_operator_type_id',
                    'created_at'
                )
                    ->orderBy('created_at', 'desc')
                    ->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()
                    ->addColumn('reg_no', function ($row) {
                        return $row->registration_no ?? 'Not Alloted';
                    })
                    ->addColumn('operator_name', function ($row) {
                        return in_array($row->ref_operator_type_id, [3, 4, 5, 6]) ? ($row->first_name ?? 'Not Found') : '';
                    })
                    ->addColumn('operator_type', function ($row) {
                        return in_array($row->ref_operator_type_id, [3, 4, 5, 6]) ? getOperatorTypeById($row->ref_operator_type_id ?? 'Not Found') : '';
                    })
                    ->addColumn('reg_date', function ($row) {
                        return date('d-m-Y', strtotime($row->created_at ?? ''));
                    })
                    ->addColumn('action', function ($row) {
                        return '<a href="' . route('superadmin.usermanagement.editDetails', $row->id) . '">Process</a>';
                    })
                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            Alert::error('Error', 'Something went wrong, please try again later.');
            return redirect()->back();
        }
    }



    public function ProceedBatch($id)
    {

        $operator = User::query()
            ->leftJoin('at_batch_creation', 'at_user.id', '=', 'at_batch_creation.at_user_id')
            ->where('at_user.id', $id)
            ->select('at_user.registration_no', 'at_user.first_name as operator_name', 'at_user.ref_operator_type_id as operator_type')
            ->first();

        return view('admin.usermanagement.batch.batch_details', compact('operator'));
    }

    public function BatchProceed(Request $request)
    {
        try {

            $userId = auth()->user()->id;

            //   dd($userId);

            if ($request->ajax()) {


                $query = User::query()
                    ->leftJoin('at_batch_creation', 'at_user.id', '=', 'at_batch_creation.at_user_id')
                    ->leftJoin('at_batch_details', 'at_batch_creation.id', '=', 'at_batch_details.batch_id');


                //     $query = AtBatchCreation::query()
                //     ->leftJoin('at_batch_details', 'at_batch_creation.id', '=', 'at_batch_details.batch_id')
                //    ->leftJoin('at_user', 'at_batch_creation.at_user_id', '=', 'at_user.id');

                $finalData = $query->select(
                    'at_user.*',
                )
                    ->orderBy('id', 'desc')

                    ->get();


                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('batch_id', function ($row) {
                        return $row->product_code ?? '';
                    })

                    ->addColumn('created_on', function ($row) {
                        return dateFormat($row->created_at ?? '');
                    })

                    ->addColumn('organic_status', function ($row) {
                        return ($row->organic_status ?? '');
                    })
                    ->addColumn('imported_product', function ($row) {
                        return 'NO';
                    })
                    ->addColumn('by_product', function ($row) {
                        return ($row->by_product ?? '');
                    })
                    ->addColumn('Source', function ($row) {
                        return ($row->quantity_source ?? '');
                    })
                    ->addColumn('Remaining', function ($row) {
                        return ($row->available_quantity ?? '');
                    })
                    ->addColumn('date', function ($row) {
                        return dateFormat($row->expiry_date ?? '');
                    })
                    ->addColumn('Quantity', function ($row) {
                        return ($row->total_quantity ?? '');
                    })

                    ->addColumn('action', function ($row) {
                        return '<a href="' . route('superadmin.usermanagement.editDetails', $row->id) . '">Edit Details</a>';
                    })
                    ->rawColumns(['action']);


                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {

            Log::error($e);
            Alert::error('Error', 'Something went wrong, please try again later.');
            return redirect()->back();
        }
    }

    public function editDetails($at_user_id)
    {

        // $data = SourceDetails::where('at_user_id', $at_user_id)->get();

        // $data = SourceDetails::select('at_source_details.*', 'at_batch_details.product_code', 'at_batch_details.product_name', 'at_batch_details.total_quantity', 'at_batch_details.created_at') // Select 
        //     ->LeftJoin('at_batch_details', 'at_source_details.batch_id', '=', 'at_batch_details.batch_id')
        //     ->whereNull('at_source_details.deleted_at')
        //     ->where('at_user_id', $at_user_id)
        //     ->orderby('at_source_details.id', 'desc')
        //     ->get();

        $data = SourceDetails::where('at_user_id', $at_user_id)->get();
        $batchdata = AtBatchCreation::where('created_by', $at_user_id)->first();

        //dd($batchdata->quantity);

        return view('admin/usermanagement/batch/edit_details', compact('data', 'batchdata'));
    }





    // public function batchDetailsSave(Request $request)
    // {
    //     $request->validate([

    //         'expiry_date' => 'required|date',
    //         'quantity' => 'required|numeric',
    //     ]);


    //     $batch_id = $request->input('batch_id');
    //     $expiry_date = $request->input('expiry_date');
    //     $quantity = $request->input('product_name');


    //     $batch = AtBatchCreation::find($batch_id);
    //     //dd($batch);

    //     if ($batch) {

    //         if ($batch->expiry_date !== $expiry_date || $batch->quantity !== $quantity) {

    //             $batch->update([
    //                 'expiry_date' => $expiry_date,
    //                 'quantity' => $quantity,
    //                 'updated_at' => now(),
    //             ]);
    //             Alert::success('Success', "Batch details Updated/Approved successfully.");
    //         } else {

    //             Alert::info('Info', "No changes were made to the batch details.");
    //         }
    //     } else {

    //         Alert::error('Error', "Batch not found.");
    //     }

    //     return redirect()->back();
    // }

    public function batchDetailsSave(Request $request)
    {
        // dd($request->all());

        $batchId = $request->input('batch_id');
        $expiryDate = $request->input('expiry_date');
        $quantity = $request->input('quantity');


        $batch = AtBatchCreation::find($batchId);
        //dd($batch);

        if ($batch) {

            if ($batch->expiry_date !== $expiryDate || $batch->quantity != $quantity) {
                $batch->update([
                    'expiry_date' => $expiryDate,
                    'quantity' => $quantity,
                    'updated_at' => now(),
                ]);


                Alert::success('Success', "Batch details updated successfully.");
            } else {
                Alert::info('Info', "No fields were updated as no new values were provided.");
            }
        } else {
            Alert::error('Error', "Batch not found.");
        }

        // Redirect back after processing
        return redirect()->back();
    }







    public function sendOtp(Request $request)
    {
        $request->validate([
            'mobile_number' => 'required|digits:10',
        ]);

        $mobileNumber = $request->input('mobile_number');
        $otp = rand(1000, 9999);


        $response = sendOtpHelp($mobileNumber, $otp);


        $otpCount = 1;
        $sendComOTP = UserVerification::updateOrCreate(
            ['mobile_no' => $mobileNumber],
            ['otp' => $otp, 'otp_count' => $otpCount, 'created_on' => now(), 'updated_on' => now()]
        );


        if ($sendComOTP) {
            return response()->json(['status' => 'success', 'message' => 'OTP sent successfully']);
        } else {
            return response()->json(['status' => 'error', 'message' => 'Failed to send OTP']);
        }
    }

    public function verifyOtp(Request $request)
    {
        $request->validate([
            'mobile_number' => 'required|digits:10',
            'otp' => 'required|digits:4',
        ]);

        $mobileNumber = $request->input('mobile_number');
        $otp = $request->input('otp');

        // Check if the OTP is correct
        $verification = UserVerification::where('mobile_no', $mobileNumber)
            ->where('otp', $otp)
            ->first();

        if ($verification) {
            // Update the verify_status to 1 after OTP is verified
            $verification->verify_status = 1;
            $verification->save();

            return response()->json(['status' => 'success', 'message' => 'OTP verified successfully']);
        } else {
            return response()->json(['status' => 'error', 'message' => 'Invalid OTP']);
        }
    }

    public function SurveyList(Request $request)
    {

        $id = Auth::user()->id;

        //  dd($id);

        if ($request->ajax()) {
            $totalData =  User::where('created_by', $id)->get();
            // dd($totalData);
            return Datatables::of($totalData)
                ->addIndexColumn()
                ->addColumn('name', function ($row) {

                    return $row->first_name ?? '';
                })
                ->addColumn('email', function ($row) {
                    return $row->email ?? '';
                    // }) ->addColumn('mobile', function($row){
                    //      return $row->mobile_no ?? '';
                })->addColumn('start_date', function ($row) {
                    $fromdate = 'N/A';
                    if (isset($row->farmersRegSchedule->schedule_period_from) && !empty($row->farmersRegSchedule->schedule_period_from)) {
                        $fromdate = date('d-m-Y', strtotime($row->farmersRegSchedule->schedule_period_from)) ?? '';
                    }
                    return $fromdate;
                })->addColumn('end_date', function ($row) {
                    $todate = 'N/A';
                    if (isset($row->farmersRegSchedule->schedule_period_to) && !empty($row->farmersRegSchedule->schedule_period_to)) {
                        $todate = date('d-m-Y', strtotime($row->farmersRegSchedule->schedule_period_to)) ?? '';
                    }
                    return $todate;
                })->addColumn('total', function ($row) {
                    $total = FarmersRegSchedule::where('at_ics_inspector_details_id', $row->id)->sum('number_of_farmer_reg');
                    if ($total > 0)
                        return $total;
                    else
                        return 'N/A';
                })->addColumn('attempt', function ($row) {

                    $from = $row->farmersRegSchedule->schedule_period_from ?? '';
                    $to = $row->farmersRegSchedule->schedule_period_to ?? '';
                    $village = $row->farmersRegSchedule->ref_village_id ?? '';

                    $attempt = '0';
                    if ($from != '' && $to != '') {
                        $attempt = AtFarmerRegDetail::whereBetween('registration_date', [$from, $to])->where(['at_ics_inspector_id' => $row->id])->count();
                    }
                    if ($attempt > 0)
                        return $attempt;
                    else
                        return 'N/A';
                })
                ->addColumn('action', function ($row) {
                    $total = FarmersRegSchedule::where('at_ics_inspector_details_id', $row->id)->sum('number_of_farmer_reg');
                    $from = $row->farmersRegSchedule->schedule_period_from ?? '';
                    $to = $row->farmersRegSchedule->schedule_period_to ?? '';
                    $village = $row->farmersRegSchedule->ref_village_id ?? '';
                    $attempt = '0';
                    if ($from != '' && $to != '') {
                        $attempt = AtFarmerRegDetail::whereBetween('registration_date', [$from, $to])->where(['at_ics_inspector_id' => $row->id])->count();
                    }

                    $actionBtn = '';
                    $today = date('Y-m-d');
                    if (($total != $attempt) &&  ($today > $to)) {
                        $actionBtn = '<a href=' . route('superadmin.icsuser.inspectorSchedule', $row->id) . '>Re-Schedule</a>';
                    }
                    $actionBtn .= '
                    <a href=' . route('superadmin.icsuser.inspectorSchedule', $row->id) . '><span><i class="mdi mdi-plus-box text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Add Schedule"></i></span></a>
                    <a href=' . route('superadmin.icsuser.inspectorSchedule', $row->id) . '><span><i class="mdi mdi-pencil text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Edit/Update Schedule"></i></span></a>
                    <a href="JavaScript:void(0);" class="deletedata" onclick="confirmDelete_(' . $row->id . ')"
                    alt="Remove"><span><i class="mdi mdi-delete-circle text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Delete"></i></span></a>';
                    return $actionBtn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }


        return view('admin/cb/inspector_schedule');
    }

    public function GetPanDetail(Request $request)
    {
        $result = User::where('user_name', $request->PanID)->first();
        if ($result) {
            return response()->json([
                'status' => true,
                'html' => view('admin.usermanagement.deptUser.templateGetPanDetails', compact('result'))->render()
            ]);
        } else {
            return response()->json([
                'status' => false,
                'message' => 'No user found with this PanID.'
            ]);
        }
    }


    public function ValidationCheck(Request $request)
    {
        // dd($request->role_id);
        $checkPanUser = User::where('ref_operator_type_id', $request->role_id)->where('user_name', $request->user_name)->first();
        if (isset($checkPanUser)) {
            Alert::Warning('Warning', "Operator Already Registered With this PAN");
            return response()->json([
                'status' => false,
                'message' => 'Operator Already Registered With this PAN.'
            ]);
        }
    }
}

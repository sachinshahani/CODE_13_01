<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Permission;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\AtImportedProductMaster;
use App\Models\AtImportedProductDetails;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;
use Validator;
use DataTables;
use DB;
use Gate;

class ImportedIngredientController extends Controller
{
	public function ImportIngredientList(Request $request)
	{

		$userId = Auth::id();

	    $user = User::where('id',$userId)->first();

       //dd($user);
		try {
			if ($request->ajax()) {
            // $totalData = AtImportedProductMaster::with('importProductDetails');
				$totalData = AtImportedProductMaster::with('importProductDetails');
            if(!Gate::check('imported_approve')){
            	$totalData->where('at_user_id',Auth::id());
            }
            $list = $totalData->get();

          // dd($totalData);

            return Datatables::of($list)
                ->addIndexColumn()
                // ->addColumn('application_no', function($row){
                //     return $row->bill_of_entry_no??'';
                // })
                ->addColumn('application_date', function($row){
                    return date('d-m-Y',strtotime($row->created_at));
                })
                ->addColumn('bill_of_entry_no', function($row){
                    return $row->bill_of_entry_no??'';
                })
                ->addColumn('bill_of_entry_date', function($row){
                    $fromdate = date('d-m-Y', strtotime($row->bill_of_entry_date )) ?? '';
                    return $fromdate;
                })
                ->addColumn('ref_country_master_id', function($row){
                    return getCountryName($row->ref_country_master_id);
                })
                ->addColumn('exporter_name', function($row){
                    return $row->exporter_name;
                })
                ->addColumn('status', function($row){
                    $st='';
                    if($row->is_approved==NULL && $row->is_rejected==NULL){ $st='<span class="badge badge-soft-primary">Pending</span>';}
                    elseif($row->is_approved==1){ $st='<span class="badge badge-soft-success">Approved</span>';}
                    else{ $st='<span class="badge badge-soft-danger">Rejected</span>'; }
                    return $st;
                })
                ->addColumn('action', function($row){
                	$actionBtn='';
                	// if(Gate::check('imported_approve')){
            			$actionBtn .= '<a href='.route('superadmin.previewImportIngredient',$row->id).'><span><i class="mdi mdi-eye text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="View"></i></span></a>';
            		// }
            		if(($row->is_approved==NULL && $row->is_rejected==NULL) || ($row->is_rejected==1)){
                    $actionBtn .= '<a href='.route('superadmin.editapplyImportIngredient',$row->id).'><span><i class="mdi mdi-pencil text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Edit/Update"></i></span></a>';
                    }
                    if(Gate::check('imported_delete')){
                    $actionBtn .= '<a href="JavaScript:void(0);" class="deletedata" onclick="confirmDelete_('.$row->id .')" alt="Remove"><span><i class="mdi mdi-delete-circle text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Delete"></i></span></a>';
                	}
                    return $actionBtn;
                })
                ->rawColumns(['action','status'])
                ->make(true);
        }
        return view('admin/imported_ingredient/imported_ingredient_list', compact('user'));


		} catch (Exception $e) {
			return redirect()->back();
		}
	}



	public function applyImportIngredient(Request $request)
	{
		try {
			$userId = Auth::id();

			//dd($userId);
			$user = User::where('id',$userId)->first();
			$importDetail = AtImportedProductMaster::with('importProductDetails')->where('at_user_id',$userId)->first();

			return view('admin/imported_ingredient/apply_imported_ingredient', compact('user','importDetail'));

		} catch (Exception $e) {
			return redirect()->back();
		} catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
			return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
		}
	}

	public function editImportIngredient($id)
	{
		try {
			$importDetail = AtImportedProductMaster::with('importProductDetails')->where('id',$id)->first();
			return view('admin/imported_ingredient/edit_apply_imported_ingredient', compact('importDetail'));

		} catch (Exception $e) {
			return redirect()->back();
		}
	}

	public function previewImportIngredient($id)
	{
		try {
		   $importDetail=AtImportedProductMaster::with('importProductDetails')->where('id',$id)->first();
		   return view('admin/imported_ingredient/preview_apply_imported_ingredient', compact('importDetail'));

		} catch (Exception $e) {
			return redirect()->back();
		}
	}

	public function applyImportIngredientSave(Request $request)
	{
		try {
			$request->validate([
				'bill_of_entry_no' => 'required',
				'bill_of_entry_date' => 'required',
				'ref_country_master_id' => 'required',
				'exporter_name' => 'required',
				'nop_certificate_no' => 'required',
				'nop_certified_by' => 'required',

			]);

			if ($request->hasFile('bill_of_entry_file')) {
				if (!empty($request->bill_of_entry_file_edit)) {
					$imagePath = public_path('importIngredient/') . $request->bill_of_entry_file_edit;
					deleteOldImage($request->bill_of_enbill_of_entry_file_edittry_file, $imagePath);
				}
				$documentRootPath = 'public/importIngredient';
				$file_path = time() . rand() . '.' . $request->file('bill_of_entry_file')->getClientOriginalExtension();
				$request->file('bill_of_entry_file')->move($documentRootPath, $file_path);
				$bill_of_entry_file = $file_path;
			} else {
				$bill_of_entry_file = $request->bill_of_entry_file_edit;
			}

			if ($request->hasFile('exporter_certification_details_issued_by_exporting_country')) {
				if (!empty($request->exporter_certification_details_issued_by_exporting_country_edit)) {
					$imagePath = public_path('importIngredient/') . $request->exporter_certification_details_issued_by_exporting_country_edit;
					deleteOldImage($request->exporter_certification_details_issued_by_exporting_country_edit, $imagePath);
				}
				$documentRootPath = 'public/importIngredient';
				$file_path = time() . rand() . '.' . $request->file('exporter_certification_details_issued_by_exporting_country')->getClientOriginalExtension();
				$request->file('exporter_certification_details_issued_by_exporting_country')->move($documentRootPath, $file_path);
				$exporter_certification = $file_path;
			} else {
				$exporter_certification = $request->exporter_certification_details_issued_by_exporting_country_edit;
			}

			if ($request->hasFile('contract_invoice_of_operator_with_exporter')) {
				if (!empty($request->contract_invoice_of_operator_with_exporter_edit)) {
					$imagePath = public_path('importIngredient/') . $request->contract_invoice_of_operator_with_exporter_edit;
					deleteOldImage($request->contract_invoice_of_operator_with_exporter_edit, $imagePath);
				}
				$documentRootPath = 'public/importIngredient';
				$file_path = time() . rand() . '.' . $request->file('contract_invoice_of_operator_with_exporter')->getClientOriginalExtension();
				$request->file('contract_invoice_of_operator_with_exporter')->move($documentRootPath, $file_path);
				$contract_invoice = $file_path;
			} else {
				$contract_invoice = $request->contract_invoice_of_operator_with_exporter_edit;
			}


			$data = array(
                'at_user_id' =>Auth::id(),
				'bill_of_entry_no'=>$request->bill_of_entry_no,
				'bill_of_entry_date'=>$request->bill_of_entry_date,
				'ref_country_master_id'=>$request->ref_country_master_id,
				'exporter_name'=>$request->exporter_name,
				'nop_certificate_no'=>$request->nop_certificate_no,
				'nop_certified_by'=>$request->nop_certified_by,
				'bill_of_entry_file'=>$bill_of_entry_file??null,
				'exporter_certification_details_issued_by_exporting_country'=>$exporter_certification??null,
				'contract_invoice_of_operator_with_exporter'=>$contract_invoice??null,
				'created_by' => Auth::guard('misadmin')->user()->id,
				'created_at' => date('Y-m-d H:i:s'),
				// 'updated_by' => Auth::guard('misadmin')->user()->id,
				// 'updated_at' => date('Y-m-d H:i:s'),

			);
			//dd($data);
			$saveData = AtImportedProductMaster::updateOrCreate([
				'at_user_id'   => Auth::id(),
				'bill_of_entry_no'=>$request->bill_of_entry_no,
				'bill_of_entry_date'=>$request->bill_of_entry_date,
			],$data);
			//dd($saveData->id);
			if(!empty($saveData)){
				if(!empty($request->ref_product_id)){
					$i=0;
					foreach($request->ref_product_id as $key=> $val)
					{
					    $impdata=array(
                            'at_imported_product_master_id'=>$saveData->id,
							'ref_product_id'=>$request->ref_product_id[$i],
							'import_qty_in_mt'=>$request->import_qty_in_mt[$i],
                        );
						$i++;

						if (!empty($request->row_id[$i])) {
							$impdata['updated_at'] = date('Y-m-d H:i:s');
							$impdata['updated_by'] = Auth::id();
							AtImportedProductDetails::where('id', $request->row_id[$i])->update($impdata);
						} else {
							$impdata['created_by'] = Auth::id();
							$impdata['created_at'] = date('Y-m-d H:i:s');
							AtImportedProductDetails::create($impdata);
						}
					}
				}
			}
			Alert::success('Success', "Data Save Successfully.");
			return redirect()->route('superadmin.importIngredientList');

		} catch (Exception $e) {
			return redirect()->back();
		} catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
			return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
		}
	}



	public function applyImportIngredientUpdate(Request $request,$id)
	{
		try {
			$request->validate([
				'bill_of_entry_no' => 'required',
				'bill_of_entry_date' => 'required',
				'ref_country_master_id' => 'required',
				'exporter_name' => 'required',
				'nop_certificate_no' => 'required',
				'nop_certified_by' => 'required',

			]);

			if ($request->hasFile('bill_of_entry_file')) {
				if (!empty($request->bill_of_entry_file_edit)) {
					$imagePath = public_path('importIngredient/') . $request->bill_of_entry_file_edit;
					deleteOldImage($request->bill_of_enbill_of_entry_file_edittry_file, $imagePath);
				}
				$documentRootPath = 'public/importIngredient';
				$file_path = time().rand().'.'.$request->file('bill_of_entry_file')->getClientOriginalExtension();
				$request->file('bill_of_entry_file')->move($documentRootPath, $file_path);
				$bill_of_entry_file = $file_path;
			} else {
				$bill_of_entry_file = $request->bill_of_entry_file_edit;
			}

			if ($request->hasFile('exporter_certification_details_issued_by_exporting_country')) {
				if (!empty($request->exporter_certification_details_issued_by_exporting_country_edit)) {
					$imagePath = public_path('importIngredient/') . $request->exporter_certification_details_issued_by_exporting_country_edit;
					deleteOldImage($request->exporter_certification_details_issued_by_exporting_country_edit, $imagePath);
				}
				$documentRootPath = 'public/importIngredient';
				$file_path = time() . rand() . '.' . $request->file('exporter_certification_details_issued_by_exporting_country')->getClientOriginalExtension();
				$request->file('exporter_certification_details_issued_by_exporting_country')->move($documentRootPath, $file_path);
				$exporter_certification = $file_path;
			} else {
				$exporter_certification = $request->exporter_certification_details_issued_by_exporting_country_edit;
			}

			if ($request->hasFile('contract_invoice_of_operator_with_exporter')) {
				if (!empty($request->contract_invoice_of_operator_with_exporter_edit)) {
					$imagePath = public_path('importIngredient/') . $request->contract_invoice_of_operator_with_exporter_edit;
					deleteOldImage($request->contract_invoice_of_operator_with_exporter_edit, $imagePath);
				}
				$documentRootPath = 'public/importIngredient';
				$file_path = time().rand().'.'.$request->file('contract_invoice_of_operator_with_exporter')->getClientOriginalExtension();
				$request->file('contract_invoice_of_operator_with_exporter')->move($documentRootPath, $file_path);
				$contract_invoice=$file_path;
			} else {
				$contract_invoice=$request->contract_invoice_of_operator_with_exporter_edit;
			}


			$data = array(
                'at_user_id' =>Auth::id(),
				'bill_of_entry_no'=>$request->bill_of_entry_no,
				'bill_of_entry_date'=>$request->bill_of_entry_date,
				'ref_country_master_id'=>$request->ref_country_master_id,
				'exporter_name'=>$request->exporter_name,
				'nop_certificate_no'=>$request->nop_certificate_no,
				'nop_certified_by'=>$request->nop_certified_by,
				'bill_of_entry_file'=>$bill_of_entry_file??null,
				'exporter_certification_details_issued_by_exporting_country'=>$exporter_certification??null,
				'contract_invoice_of_operator_with_exporter'=>$contract_invoice??null,
				'is_rejected'=>null,
				'updated_by' => Auth::guard('misadmin')->user()->id,
				'updated_at' => date('Y-m-d H:i:s'),

			);
			$saveData = AtImportedProductMaster::where('id',$id)->update($data);
			//dd($request->all());
			if(!empty($saveData)){
				if(!empty($request->ref_product_id)){
					$i=0;
					foreach($request->ref_product_id as $key=> $val)
					{
					    $impdata=array(
                            'at_imported_product_master_id'=>$id,
							'ref_product_id'=>$request->ref_product_id[$i],
							'import_qty_in_mt'=>$request->import_qty_in_mt[$i],
                        );


						if (!empty($request->row_id[$i])) {
							$impdata['updated_at'] = date('Y-m-d H:i:s');
							$impdata['updated_by'] = Auth::id();
							AtImportedProductDetails::where('id', $request->row_id[$i])->update($impdata);
						} else {
							$impdata['created_by'] = Auth::id();
							$impdata['created_at'] = date('Y-m-d H:i:s');
							AtImportedProductDetails::create($impdata);
						}
						$i++;
					}
				}
			}
			Alert::success('Success', "Data Save Successfully.");
			return redirect()->back();

		} catch (Exception $e) {
			return redirect()->back();
		} catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
			return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
		}
	}


	public function ImportIngredientStatusUpdate(Request $request,$id)
	{
		try {
			$request->validate([
				'inspection_date' => 'required',
				'inspected_by' => 'required',
				'status' => 'required',
			]);

			$data = array(
                'is_approved'=>($request->status==1?"1":NULL),
                'is_rejected'=>($request->status==2?"1":NULL),
                'approved_on'=>$request->inspection_date,
				'approved_by'=>$request->inspected_by,
				'remarks'=>$request->cb_remarks,
				'updated_by' => Auth::guard('misadmin')->user()->id,
				'updated_at' => date('Y-m-d H:i:s'),

			);
			$saveData = AtImportedProductMaster::where('id',$id)->update($data);

			Alert::success('Success', "Status Changed Successfully.");
			return redirect()->back();

		} catch (Exception $e) {
			return redirect()->back();
		} catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
			return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
		}
	}

}

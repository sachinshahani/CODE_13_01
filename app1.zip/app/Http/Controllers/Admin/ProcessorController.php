<?php

namespace App\Http\Controllers\Admin;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\AtBatchDetail;
use App\Models\AtBatchCreation;
use App\Models\AtOpTransactionVsTransactionProduct;
use App\Models\AtOpTransactionProductSourced;
use App\Models\RefPackingMaster;
use App\Models\AtFarmerStandingCorpDetail;
use App\Models\AtClosingStock;
use App\Models\AtOpTransactionPackingDetails;
use App\Models\AtOpTransactionCertificateEntry;
use App\Models\User;

use RealRashid\SweetAlert\Facades\Alert;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ProcessorController extends Controller
{
   
    public function applyForDomesticTC($id = NULL)
    {

        $user_id = Auth::guard('misadmin')->user()->id;
//dd($user_id);
        $operator_type_id = Auth::guard('misadmin')->user()->ref_operator_type_id;
        // $order_list2 = AtPurchaseRequest::select('at_purchase_request.*')
        // ->join('at_order_details_received_from_buyer as odrb','odrb.at_purchase_request_id','at_purchase_request.id')
        // ->join('at_order_accepted','at_order_accepted.at_order_details_received_from_buyer_id','odrb.id')
        // ->join('at_closing_stock','at_closing_stock.at_user_id','at_purchase_request.at_user_id')
        // ->join('at_farmer_standing_crop_details','at_farmer_standing_crop_details.id','at_closing_stock.at_farmer_standing_crop_details_id')
        // ->where('at_purchase_request.at_user_id',$user_id)
        // ->orderBy('at_purchase_request.created_at', 'asc')
        // ->get();

        // $order_list2 = DB::select("select abc.id, abc.commodity, at_closing_stock.id as clsid,at_closing_stock.organic_status, at_closing_stock.closing_stock, abc.quantity from at_batch_creation as abc INNER join at_order_details_received_from_buyer as odrb on odrb.at_purchase_request_id = abc.id inner join at_order_accepted on at_order_accepted.at_order_details_received_from_buyer_id = odrb.id inner join at_closing_stock on at_closing_stock.at_user_id = abc.at_user_id and at_closing_stock.ref_product_id = abc.commodity
        // inner join at_farmer_standing_crop_details on at_farmer_standing_crop_details.id = at_closing_stock.at_farmer_standing_crop_details_id where abc.at_user_id = $user_id and abc.order_status = 1  group BY (abc.commodity,abc.id,at_closing_stock.organic_status,closing_stock,abc.quantity,at_closing_stock.id)");
        $order_list2 = DB::select("select * from at_batch_creation where at_user_id = $user_id");
        $order = array();
        $j = 0;

        foreach ($order_list2 as $key => $vls) {
            $order['purchase_list'][$key] = $vls;
            $purchases = AtBatchDetail::where('batch_id', $vls->id)->get();
            $order['purchase_list'][$key]->mypurchase = $purchases;
        }

        //$data = AtBatchCreation::with('batchDetails')->where('created_by', $user_id)->get();
        $data = AtBatchCreation::with(['batchDetails','sourceDetails'])->where('created_by', $user_id)->get();
        //dd($data);        

        return view('admin.processor.processortc.apply_for_domestic_tc', compact('order', 'data'));
    }

    public function storeApplyForDomesticTCT(Request $request)
    {
        //dd($request->all());
        
        $request->validate([
            
        ]);
        try {
            $operator_type_id = Auth::guard('misadmin')->user()->ref_operator_type_id;
            foreach ($request->lots as $key => $val) {
                if (!empty($request->lots[$key])) {
                    // Ensure the necessary fields are not empty
                    $data = array(
                        'farm_no'   => isset($request->farm_no[$key]) ? $request->farm_no[$key] : NULL,
                        'total_qty' => isset($request->total_qty[$key]) ? $request->total_qty[$key] : NULL,
                        'tc_date'   => date('Y-m-d'),
                        'operator_type' => isset($operator_type_id) ? $operator_type_id : NULL,
                        'rem_qty'   => isset($request->rem_qty[$key]) ? $request->rem_qty[$key] : NULL,
                        'product_code' => isset($request->product_code[$key]) ? $request->product_code[$key] : NULL,
                        'organic_status' => isset($request->organic_status[$key]) ? $request->organic_status[$key] : NULL,
                        'created_by' => Auth::guard('misadmin')->user()->id,
                        'updated_by' => Auth::guard('misadmin')->user()->id
                    );
                    
                    // Ensure all necessary fields are not null or empty
                    if ($data['total_qty']) {

                        $result = AtOpTransactionVsTransactionProduct::updateOrCreate([
                            'id' => $request->row_id[$key],
                        ], $data);
            
                        if (!empty($result)) {
                            foreach ($request->pur_lots[$key] as $k => $val1) {
                                if (!empty($request->pur_lots[$key])) {
                                    // Ensure all fields are not null before creating or updating
                                    $data1 = array(
                                        'at_op_transaction_vs_transaction_product_id' => $result->id,
                                        'ref_product_id' => isset($result->product_code) ? $result->product_code : NULL,
                                       // 'at_closing_stock_id' => isset($request->at_closing_stock_id[$key][$k]) ? $request->at_closing_stock_id[$key][$k] : NULL,
                                       // 'at_purchase_details_id' => isset($request->at_purchase_details_id[$key][$k]) ? $request->at_purchase_details_id[$key][$k] : NULL,
                                        'organic_status' => isset($result->organic_status) ? $result->organic_status : NULL,
                                        'qty_in_mt' => isset($request->used_quantity[$key][$k]) ? $request->used_quantity[$key][$k] : NULL,
                                        'source_date' => date('Y-m-d'),
                                        'created_by' => Auth::guard('misadmin')->user()->id,
                                        'updated_by' => Auth::guard('misadmin')->user()->id
                                    );
            
                                              
                                    // Ensure all required fields are not null before attempting to create/update
                                    // if ($data1['ref_product_id'] && $data1['at_closing_stock_id'] && $data1['at_purchase_details_id'] && $data1['qty_in_mt']) {
                                        $result1 = AtOpTransactionProductSourced::updateOrCreate([
                                            'id' => $request->rows_id[$key][$k],
                                        ], $data1);
                                    // }
                                }
                            }
            
                            if (!empty($result1->id)) {
                                Alert::success('Success', __('message.add_success'));
                                return redirect()->route('superadmin.P-trader.packingDetailTC', [$result->id]);
                            } else {
                                Alert::success('Success', 'Something went wrong.');
                                return redirect()->back();
                            }
                        }
                    } else {
                        Alert::error('Error', 'Required fields cannot be empty.');
                        return redirect()->back();
                    }
                }
            }
            
            
        } catch (Exception $e) {

            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function packingDetailTC($id)
    {
      
        $trans = AtOpTransactionVsTransactionProduct::with('getTransProductSource')->where('id', $id)->get();        
        $packs = RefPackingMaster::get();
        //AtOpTransactionPackingDetails::where(['product_code'=>$trans[0]->ref_product_id,'crested_by',Auth::guard('misadmin')->user()->id])->get();
        //dd($packDet);

        return view('admin.processor.processortc.packing_detail_tc', compact('trans', 'packs'));
    }

    public function storeIcsHarvestProduct(Request $request)
	{
		
		$validator = \Validator::make($request->all(), [
            'actual_yield' => 'required',
            'harvest_date' => 'required',
            'sowing_date' => 'required',
            'product_id' => 'required',
        ]);

        if ($validator->fails())
        {
            return response()->json(['errors'=>$validator->errors()->all()]);
        }

		try {
			
			$insertData = array(
				'actual_yield' =>  $request->actual_yield,
				'harvest_date' => date('Y-m-d',strtotime($request->harvest_date)),
				'sowing_date' => date('Y-m-d',strtotime($request->sowing_date)),
				'updated_at' => date('Y-m-d H:i:s'),
				'updated_by' => Auth::guard('misadmin')->user()->id,
			);

			AtFarmerStandingCorpDetail::where('id',$request->product_id)->update($insertData);
			$input_approval = AtFarmerStandingCorpDetail::where('id',$request->product_id)->first();

			$insert_closing_stock = array(
				'at_farmer_standing_crop_details_id' => $input_approval->id,
				'ref_operator_type_id' => Auth::guard('misadmin')->user()->ref_operator_type_id,
				'at_user_id' => Auth::guard('misadmin')->user()->id,
				'organic_status' => $input_approval->organic_status,
				'ref_product_id' => $request->product_id,
				'date_of_harvest' => date('Y-m-d',strtotime($input_approval->harvest_date)),
				'harvest_year' => date('Y'),
			);
			//dd($insert_closing_stock);
			$result = AtClosingStock::create($insert_closing_stock);
			
			if(!empty($result)){
				return response()->json(['status'=>1,'data'=>$input_approval,'msg'=>'Data is successfully added.']);
			}else{
				return response()->json(['status'=>2,'data'=>$input_approval,'msg'=>'Something went wrong.']);
			}
			

		} catch (Exception $e) {
            Log::error($e->getMessage());
           // abort('404');
        }
	}

    // public function storePackingDetailTC(Request $request)
    // {
    //     //dd($request->all());

    //     $request->validate([
    //         'value_inr' => 'required',
    //         'trade_name_of_product' => 'required',
    //         'ref_packing_master_id.*' => 'required',
    //         'no_of_box.*' => 'required',
    //         'pack_size.*' => 'required',
    //         'total_qty_in_kg.*' => 'required',
    //     ]);
    //     // if(!empty($validator->fails())) {
    //     // 	return Redirect::back()->withErrors($validator);
    //     // }
    //     try {
    //         //dd($request->all());
    //         $operator_type_id = Auth::guard('misadmin')->user()->ref_operator_type_id;
           
    //         $edtVal = 0;


    //         if (!empty($request->at_op_transaction_product_sourced_id)) {

               
    //             foreach ($request->at_op_transaction_product_sourced_id as $key => $val) {

    //                 if (!empty($request->at_op_transaction_product_sourced_id[$key])) {
    //                     $data = array(
    //                         'at_op_transaction_product_sourced_id'   => $request->at_op_transaction_product_sourced_id[$key],
    //                         'ref_product_id'   => $request->ref_product_id,
    //                         'ref_packing_master_id'   => $request->ref_packing_master_id[$key],
    //                         'no_of_box'   => $request->no_of_box[$key],
    //                         'pack_size'   => $request->pack_size[$key],
    //                         'total_qty_in_kg'   => $request->total_qty_in_kg[$key],
    //                         'created_by' => Auth::guard('misadmin')->user()->id,
    //                         'updated_by' => Auth::guard('misadmin')->user()->id
    //                     );

    //                     $result = AtOpTransactionPackingDetails::updateOrCreate([
    //                         'id' => $request->row_id[$key],
    //                     ], $data);
    //                 }
    //             }

    //             if (!empty($result)) {
    //                 $updateData = array(
    //                     'value_inr' => $request->value_inr,
    //                     'trade_name_of_product' => $request->trade_name_of_product,
    //                 );
    //                 $res = AtOpTransactionVsTransactionProduct::where('id', $request->trans_id)->update($updateData);

    //                 //if(isset($request->row_id[0]) && $request->row_id[0]!=''){
    //                 Alert::success('Success', __('message.add_success'));
    //                 return redirect()->route('superadmin.P-trader.TcDetail', $request->trans_id);
    //                 // }else{
    //                 // 	Alert::success('Success', __('message.add_success'));
    //                 // 	return redirect()->back();
    //                 // }

    //             }
    //         }
    //        // dd('L');
    //     } catch (Exception $e) {
    //         Log::error($e->getMessage());
    //         abort('404');
    //     }
    // }


    public function storePackingDetailTC(Request $request)
    {      
        //dd($request->all());
       
        $request->validate([
            'value_inr' => 'required',
            'trade_name_of_product' => 'required',
            'ref_packing_master_id.*' => 'required',
            'no_of_box.*' => 'required',
            'pack_size.*' => 'required',
            'total_qty_in_kg.*' => 'required',
        ]);
        
        try {
          
            $operator_type_id = Auth::guard('misadmin')->user()->ref_operator_type_id;

          
            $data = [
                'at_op_transaction_product_sourced_id' => $request->at_op_transaction_product_sourced_id ?? '',
               'ref_product_id' => $request->ref_product_id ?? '',
                'ref_packing_master_id' => $request->ref_packing_master_id ?? '',
                'no_of_box' => $request->no_of_box ?? '',
                'pack_size' => $request->pack_size ?? '',
                'total_qty_in_kg' => $request->total_qty_in_kg ?? '',
                'created_by' => Auth::guard('misadmin')->user()->id,
                'updated_by' => Auth::guard('misadmin')->user()->id
            ];
           
            $result = AtOpTransactionPackingDetails::create($data);

            // if ($request->row_id) {
            //     $result = AtOpTransactionPackingDetails::where('id', $request->row_id)->update($data);
            // } else {
            //     $result = AtOpTransactionPackingDetails::create($data);
            // }

           
            if ($result) {
                
                $updateData = [
                    'value_inr' => $request->value_inr,
                    'trade_name_of_product' => $request->trade_name_of_product,
                ];
                $res = AtOpTransactionVsTransactionProduct::where('id', $request->trans_id)->update($updateData);

                
                Alert::success('Success', __('message.add_success'));
                return redirect()->route('superadmin.P-trader.TcDetail', $request->trans_id);
            }

        } catch (Exception $e) {
            
            Log::error($e->getMessage());
            abort(404);
        }
    }


    public function TcDetail($id)
    {        

        $data =  AtOpTransactionCertificateEntry::where('at_op_transaction_vs_transaction_product_id', $id)->first();
        return view('admin.processor.processortc.tc_details', compact('id', 'data'));
    }

    public function storeTcDetail(Request $request)
    {
        //dd($request->all());
        $request->validate([
            'invoice_no' => 'required',
            'invoice_date' => 'required',
            'invoice_value' => 'required',
            //'place_of_dispatch' => 'required',
            'lot_number' => 'required',
            'place_of_destination' => 'required',
            'marks_no' => 'required',
            'reference_no' => 'required',
        ]);
        // if(!empty($validator->fails())) {
        // 	return Redirect::back()->withErrors($validator);
        // }
        try {

            /// Date of Transport
            if (!empty($request->road_transport_date)) {
                $transport_date = date('Y-m-d H:i:s', strtotime($request->road_transport_date));
            } elseif (!empty($request->train_transport_date)) {
                $transport_date = date('Y-m-d H:i:s', strtotime($request->train_transport_date));
            } else {
                $transport_date = null;
            }


            // dd(date('Y-m-d H:i:s',strtotime($request->invoice_date[0])));
            $data = array(
                'exporter_seller_name'   => !empty($request->exporter_seller_name) ? $request->exporter_seller_name : Null,
                'seller_email'   => !empty($request->seller_email) ? $request->seller_email : Null,
                'seller_at_op_certificate_standard_details_id'   => !empty($request->seller_at_op_certificate_standard_details_id) ? $request->seller_at_op_certificate_standard_details_id : Null,
                'exporter_seller_address'   => !empty($request->exporter_seller_address) ? $request->exporter_seller_address : Null,
                'buyer_id_proof'   => !empty($request->buyer_id_proof) ? $request->buyer_id_proof : Null,
                'buyer_name'   => !empty($request->buyer_name) ? $request->buyer_name : Null,
                'buyer_address'   => !empty($request->buyer_address) ? $request->buyer_address : Null,
                'buyer_at_op_certificate_standard_details_id'   => !empty($request->buyer_at_op_certificate_standard_details_id) ? $request->buyer_at_op_certificate_standard_details_id : Null,
                'buyer_ref_state_id'   => !empty($request->buyer_ref_state_id) ? $request->buyer_ref_state_id : Null,
                'buyer_email'   => !empty($request->buyer_email) ? $request->buyer_email : Null,
                'invoice_no'   => !empty($request->invoice_no[0]) ? $request->invoice_no[0] : Null,
                'invoice_date'   => !empty($request->invoice_date[0]) ? date('Y-m-d H:i:s', strtotime($request->invoice_date[0])) : Null,
                'invoice_value'   => !empty($request->invoice_value) ? $request->invoice_value : Null,
                //'place_of_dispatch'   => !empty($request->place_of_dispatch) ? $request->place_of_dispatch : Null,
                'place_of_destination'   => !empty($request->place_of_destination) ? $request->place_of_destination : Null,
                'marks_no'   => !empty($request->marks_no) ? $request->marks_no : Null,
                'reference_no'   => !empty($request->reference_no) ? $request->reference_no : Null,
                'transport_mode'   => !empty($request->transport_mode) ? $request->transport_mode : Null,
            
                'container_no_road'   => !empty($request->container_no_road) ? $request->container_no_road : Null,
                'transport_doc_no'   => !empty($request->transport_doc_no) ? $request->transport_doc_no : Null,
                'transport_date'   => !empty($transport_date) ? $transport_date : Null,
            
                'train_no'   => !empty($request->train_no) ? $request->train_no : Null,
                'wagon_no'   => !empty($request->wagon_no) ? $request->wagon_no : Null,
                'train_transport_date'   => !empty($request->train_transport_date) ? date('Y-m-d H:i:s', strtotime($request->train_transport_date)) : Null,
            
                'flight_no'   => !empty($request->flight_no) ? $request->flight_no : Null,
                'flight_date'   => !empty($request->flight_date) ? date('Y-m-d H:i:s', strtotime($request->flight_date)) : Null,
                'airway_bill_no'   => !empty($request->airway_bill_no) ? $request->airway_bill_no : Null,
                'airway_bill_date'   => !empty($request->airway_bill_date) ? date('Y-m-d H:i:s', strtotime($request->airway_bill_date)) : Null,
                'container_no_air'   => !empty($request->container_no_air) ? $request->container_no_air : Null,
            
                'ship_no'   => !empty($request->ship_no) ? $request->ship_no : Null,
                'ship_name'   => !empty($request->ship_name) ? $request->ship_name : Null,
                'vessel_date'   => !empty($request->vessel_date) ? $request->vessel_date : Null,
                'bill_of_lading'   => !empty($request->bill_of_lading) ? $request->bill_of_lading : Null,
                'date_of_lading'   => !empty($request->date_of_lading) ? $request->date_of_lading : Null,
                'container_no_ship'   => !empty($request->container_no_ship) ? $request->container_no_ship : Null,
            
                'gross_weight'   => !empty($request->gross_weight) ? $request->gross_weight : Null,
                'created_by' => Auth::guard('misadmin')->user()->id,
                'updated_by' => Auth::guard('misadmin')->user()->id,
                'at_op_transaction_vs_transaction_product_id' => !empty($request->at_op_transaction_vs_transaction_product_id) ? $request->at_op_transaction_vs_transaction_product_id : Null,
                'lot_number' => !empty($request->lot_number) ? $request->lot_number : Null,
            );
            
            //dd($data);
            $saveData = AtOpTransactionCertificateEntry::updateOrCreate(['at_op_transaction_vs_transaction_product_id' => $request->at_op_transaction_vs_transaction_product_id], $data);

            Alert::success('Success', __('message.add_success'));
            return redirect()->route('superadmin.P-forwardToCB', $request->at_op_transaction_vs_transaction_product_id);
            // if(!empty($saveData)){
            // 	Alert::success('Success', __('message.add_success'));
            // 	return redirect()->route('superadmin.TcDetail',$request->at_op_transaction_vs_transaction_product_id);
            // }else{
            // 	Alert::success('Success', 'Something Went Wrong!');
            // 	return redirect()->back();
            // }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function forwardToCB($id){

        return view('admin.processor.processortc.forwardToCB',compact('id'));
    }

    public function whpackingDetailTC($id)
    {
        $trans = AtOpTransactionVsTransactionProduct::with('getTransProductSource')->where('id', $id)->get();
        $packs = RefPackingMaster::get();

        return view('admin/processor/processortc/wh_packing_detail_tc', compact('trans', 'packs'));
    }

    public function postForwardToCB(Request $request){
        //dd($request->all());
		try {
			$data = AtOpTransactionVsTransactionProduct::select('created_at','id')->where('id',$request->row_id)->first();
			if($data){
				$m = date('m',strtotime($data->created_at));
				$y = date('y',strtotime($data->created_at));
				$lst = str_pad($data->id, 4, "0", STR_PAD_LEFT);
				$app_no = "TC-".$y.$m.$lst;

			}
			$upData = array(
				'tc_application_no'=>$app_no,
				'tc_date'=>date('Y-m-d'),
				'nop_status'=>'Pending',
			);

			$res = AtOpTransactionVsTransactionProduct::where('id',$request->row_id)->update($upData);

            if($res > 0){
				Alert::success('Success', __('message.add_success'));
				return redirect()->route('superadmin.P-listOfTransCertificate');
			}else{
				Alert::error('', 'Something went Wrong.');
				return redirect()->back();
			}


		} catch (Exception $e) {
			//dd($e->getMessage());
			Log::error($e->getMessage());
			abort('404');
		}
    }

    public function listOfTransCertificate(Request $request){

        $id = Auth::guard('misadmin')->user()->id;
		if ($request->ajax()) {
			$totalData = AtOpTransactionVsTransactionProduct::where('created_by',$id)->get();
            return Datatables::of($totalData)
                ->addIndexColumn()
                ->addColumn('tc_application_no', function($row){
                    return$row->tc_application_no;
                })->addColumn('tc_date', function($row){
                    return date('d-m-Y', strtotime($row->tc_date));
                })->addColumn('seller', function($row){
                    return $row->quantity;
                })->addColumn('buyer', function($row){
                    return getHscodeProductName($row->commodity) ?? '';
                })->addColumn('country', function($row){
                    return 'INDIA';
                })->addColumn('status', function($row){
                   return  $row->nop_status ?? '';
                })->addColumn('tc_type', function($row){
					return  'Domestic';
				})->addColumn('action', function($row){

                    $actionBtn= '<a href="'.route('superadmin.viewTCApplication',[$row->id]).'" class="btn btn-soft-primary ms-2"><span><i class="ri-file-edit-fill" data-toggle="tooltip" title="Apply for domestic TC" ></i></span></a>';

                    return $actionBtn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        return view('admin.processor.processortc.listOfTransCertificate');

	}

    public function viewTCApplication($id)
    {
        
	    $trans = AtOpTransactionVsTransactionProduct::with('getTransProductSource')->where('id',$id)->get();
       
		//$packs = RefPackingMaster::get();
		//dd($trans[0]->getTransProductSource);
		$data =  AtOpTransactionCertificateEntry::where('at_op_transaction_vs_transaction_product_id',$id)->first();
        return view('admin.processor.processortc.viewApplication',compact('id','trans','data'));
    }

    public function tsIssueList(){
        $tcIssueList = AtOpTransactionVsTransactionProduct::whereNotNull('tc_application_no')->get();

        return view('admin.processor.processortc.tc_issue_list',['tcIssueList' =>  $tcIssueList]);
    
    }

    public function TcViewApplication($id){

        $user =  User::where('id',Auth::user()->id)->first();
//dd($user);
        $tcIssueList = AtOpTransactionVsTransactionProduct::where('id', $id)->get();
        $data =  AtOpTransactionCertificateEntry::where('at_op_transaction_vs_transaction_product_id',$id)->first();

      ///  dd($data);
        return view('admin.processor.processortc.cbTcviewApplication',compact('tcIssueList' , 'user' , 'data'));
    
    }
}

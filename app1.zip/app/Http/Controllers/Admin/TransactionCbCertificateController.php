<?php

namespace App\Http\Controllers\Admin;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Yajra\DataTables\DataTables;
use App\Models\AtFarmerStandingCorpDetail;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;
use App\Models\AtOpTransactionVsTransactionProduct;
use App\Models\AtOpTransactionCertificateEntry;
use App\Models\AtOpTransactionProductSourced;
use App\Models\AtOrgSampleRtnDtl;
use App\Models\AtCbTestParameterEntry;
use App\Models\AtBatchCreation;
use App\Models\AtInternalStockTransfe;
use App\Models\AtOpTransactionPackingDetails;
use App\Models\RefProduct;
use Exception;
use Illuminate\Support\Facades\File;
use Mpdf\Mpdf;
use PDF;
use Illuminate\Support\Str;
use Validator;
use DB;
use QrCode;



class TransactionCbCertificateController extends Controller
{
    // public function index(Request $request){

    //     $userId = Auth::id();

    //     abort_unless(\Gate::allows('user_access'), 403);
    //     if ($request->ajax()) {
    //         $tcData = AtOpTransactionVsTransactionProduct::with('getTransProductSource')->get();
    //         return Datatables::of($tcData)
    //             ->addIndexColumn()

    //              ->addColumn('tc_application_no', function ($row) {
    //                  return $row->tc_application_no ?? '';
    //              })

    //              ->addColumn('tc_date', function ($row) {
    //                  return $row->tc_date ?? '';
    //              })

    //              ->addColumn('seller_scn', function ($row) {
    //                  return $row->seller_scn ?? '';
    //              })

    //              ->addColumn('nop_status', function ($row) {
    //                  return $row->nop_status ?? '';
    //              })

    //              ->addColumn('tc_type', function ($row) {
    //                 $tc_type = 'Domestic';
    //                  return $tc_type ?? '';
    //              })
    //              ->addColumn('country', function ($row) {
    //                 $country = 'India';
    //                  return $country ?? '';
    //              })

    //              ->addColumn('action', function ($row) {

    //                     $viewApplication = '';
    //                     $viewApplication .= '<a href="' . route('superadmin.viewTcApplication',$row->id) . '" class="viewdata"><span>View Application</span></a>';

    //                     $process = '';
    //                     $process .= '<a href="' . route('superadmin.saveDataCbGenerateTc',$row->id) . '" class="viewdata"><span>Process</span></a>';

    //                     $traceApplication = '';
    //                     $traceApplication .= '<a href="' . route('superadmin.viewTcApplication',$row->id) . '" class="viewdata"><span>Trace Application</span></a>';

    //                     $sendForLabTest = '';
    //                     $sendForLabTest .= '<a href="' . route('superadmin.viewTcApplication',$row->id) . '" class="viewdata"><span>Send for Lab Test</span></a>';

    //                     $cancelRejectApplication = '';
    //                     $cancelRejectApplication .= '<a href="' . route('superadmin.viewTcApplication',$row->id) . '" class="viewdata"><span>Cancel/Reject Application</span></a>';


    //                      $action = $viewApplication."<br>".$process."<br>".$traceApplication."<br>".$sendForLabTest."<br>".$cancelRejectApplication;

    //                      return $action;

    //              })

    //              ->rawColumns(['action', 'role', 'farmer' ])
    //              ->make(true);
    //      }

    //    return view('admin.transaction_Cb_certificate.index');

    // }




    public function index(Request $request)
    {

        $id = Auth::user()->id;
        $results = AtOpTransactionVsTransactionProduct::where('tc_application_no', 'LIKE', 'TC%')->orderBy('created_at', 'asc')
            ->where('transaction_certificate_no', NULL)
            ->get();
        if ($request->ajax()) {

            return DataTables::of($results)

                ->addIndexColumn()
                ->addColumn('tc_application_no', function ($row) {
                    return $row->tc_application_no ?? '';
                })->addColumn('tc_date', function ($row) {

                    return date("d-m-Y", strtotime($row->tc_date)) ?? '';
                })->addColumn('seller_scn', function ($row) {
                    return $row->seller_scn ?? '';
                    // })->addColumn('tc_application_no', function($row){
                    //     return $row->tc_application_no ?? '';
                    // })->addColumn('tc_application_no', function($row){
                    //     return $row->tc_application_no ?? '';
                    // })->addColumn('tc_application_no', function($row){
                    //     return $row->tc_application_no ?? '';
                    // })->addColumn('tc_application_no', function($row){
                    //     return $row->tc_application_no ?? '';
                    //
                })->addColumn('action', function ($row) {
                    $btn = '<a href="' . route("superadmin.cb.viewTCApplication", ['tcid' => $row->id, 'userid' => $row->created_by]) . '">1.View Application</a><br>
        <a href="' . route("superadmin.tcrequestCbcertificateprocess", [$row->id]) . '">2.process</a><br>
        <a href="#">3.Trace Application</a><br>
        <a href="' . route("superadmin.tcrequestCbcertificateSendforLabTest", [$row->id]) . '">4.Send for Lab Test</a><br>
        <a href="' . route("superadmin.tcrequestCbcertificateprocess", [$row->id]) . '">5.Cancel/Reject Application</a>';

                    return $btn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }

        return view('admin.transaction_Cb_certificate.index');
    }



    public function processDemoesticTc(Request $request, $id)
    {
        $authsign = User::whereHas('roles', function ($q) {
            return $q->where('title', 'Authorized Signatory');
        })->where('created_by', Auth::id())->get();

        $productdetails = AtOpTransactionVsTransactionProduct::where('id', $id)->get();


        $data = AtOpTransactionCertificateEntry::where('at_op_transaction_vs_transaction_product_id', $id)->first();
        //dd($result);
        return view('admin.transaction_Cb_certificate.processDomestictc', compact('id', 'productdetails', 'authsign', 'data'));
    }

    public function saveDataCbGenerateTc(Request $request)
    {

        if ($request->formData == "formData") {

            $formData = Auth::id();

            return view('admin.transaction_Cb_certificate.processDomestictc', compact('formData'));
        } else {
            $ajaxData = $request->cbGenerateTc;
            // dd($data);
            return response()->json(['status' => 'success', 'message' => 'The Domestic Transaction Certificate has been generated Successfully']);
        }
    }

    public function process(Request $request, $id)
    {

        $authsign = User::whereHas('roles', function ($q) {
            return $q->where('title', 'Authorized Signatory');
        })->where('created_by', Auth::id())->get();

        $productdetails = AtOpTransactionVsTransactionProduct::with('getTransProductSource')->where('id', $id)->get();
        // dd($productdetails);
        $data = AtOpTransactionCertificateEntry::where('at_op_transaction_vs_transaction_product_id', $id)->first();

        return view('admin.transaction_Cb_certificate.process', compact('id', 'productdetails', 'authsign', 'data'));
    }


    public function tcrequestcertificatepreview(Request $request, $id)
    {

        try {

            $result = AtOpTransactionCertificateEntry::where('created_by', $id)->first();

            // $data = array(
            //     'updated_by' => Auth::guard('misadmin')->user()->id,
            //     'updated_at' => date('Y-m-d H:i:s'),

            // );

            // $saveData = AtOpTransactionCertificateEntry::where('created_by',$request->id)->update($data);

            return redirect()->route('superadmin.tcrequestCbcertificatepreviewtc', $request->id)->with('loader', true);
        } catch (Exception $e) {
            return redirect()->back();
        } catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
            return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
        }
    }

    public function storeTcrequestcertificatepreview(Request $request)
    {
        // dd($request->all());
        $request->validate([
            'order_contract_no' => 'required',
            'total_qty' => 'required',
            'country_origin' => 'required',
            'signatory_code' => 'required',
        ]);

        try {
            $id = $request->cre_id;
            $data = array(
                'order_contract_no'   => $request->order_contract_no ?? null,
                'total_qty'   => $request->total_qty ?? null,
                'country_origin'   => $request->country_origin ?? null,
                'signatory_code'   => $request->signatory_code ?? null,
                'updated_by' => Auth::guard('misadmin')->user()->id
            );
            $saveData = AtOpTransactionCertificateEntry::where('id', $request->row_id)->update($data);

            if (!empty($saveData)) {
                Alert::success('Success', __('message.add_success'));
                return redirect()->route('superadmin.tcrequestCbcertificatepreviewtc', ['tcid' => $request->tcid, 'userid' => $id]);
            } else {
                Alert::success('Success', 'Something Went Wrong!');
                return redirect()->back();
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }


    public function previewTc(Request $request, $tcid, $userid)
    {

        return view('admin.transaction_Cb_certificate.previewtc', compact('tcid', 'userid'));
    }


    public function SendforLabTest(Request $request, $id)
    {
        $data = AtOpTransactionProductSourced::where('at_op_transaction_vs_transaction_product_id', $id)->get();
        $tranEntry = AtOpTransactionCertificateEntry::where('at_op_transaction_vs_transaction_product_id', $id)->first();
        $tcno = AtOpTransactionVsTransactionProduct::where('id', $id)->first();
        return view('admin.transaction_Cb_certificate.sendforlabtest', compact('data', 'tranEntry', 'id', 'tcno'));
    }



    public function producttestinformation(Request $request, $id)
    {

        $data = AtOpTransactionProductSourced::where('at_op_transaction_vs_transaction_product_id', $id)->first();


        $tranEntry = AtOpTransactionCertificateEntry::where('at_op_transaction_vs_transaction_product_id', $id)->first();

        $tcno = AtOpTransactionVsTransactionProduct::where('id', $id)->first();
        return view('admin.transaction_Cb_certificate.producttestinformation', compact('id', 'data', 'tranEntry', 'tcno'));
    }

    public function producttestinformationStore(Request $request)
    {


        try {
            $today = date('Y-m-d');
            $data = array(
                'at_op_transaction_certificate_entry_id' => $request->at_op_transaction_certificate_entry_id,
                'ref_product_id' => $request->ref_product_id,
                'category_for_testing' => implode(',', $request->category_for_testing),
                'sample_rtn_at_exp' => $request->sample_rtn_at_exp,
                'sample_rtn_at_cb' => $request->sample_rtn_at_cb,
                'sample_rtn_at_lab' => $request->sample_rtn_at_lab,
                'sample_rtn_last_dt_exp' => date('Y-m-d', strtotime("+" . $request->sample_rtn_last_dt_exp . "month", strtotime($today))),
                'sample_rtn_last_dt_cb' => date('Y-m-d', strtotime("+" . $request->sample_rtn_last_dt_cb . " month", strtotime($today))),
                'sample_rtn_last_dt_lab' => date('Y-m-d', strtotime("+" . $request->sample_rtn_last_dt_lab . " month", strtotime($today))),
                'ref_laboratory_master_id' => $request->ref_laboratory_master_id,
                'created_by' => Auth::guard('misadmin')->user()->id,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_by' => Auth::guard('misadmin')->user()->id,
                'updated_at' => date('Y-m-d H:i:s'),
                'tc_no' => $request->tc_application_no,
                'operator_type' => $request->operator_type,
                'transaction_certificate_no' => $request->transaction_certificate_no,
                'operator_user_id' => $request->operator_user_id,
                'product_code' => $request->product_code,
                'size_of_composite_sample' => $request->size_of_composite_sample,

            );

            $dd = AtOrgSampleRtnDtl::create($data);

            if (!empty($request->ref_cb_test_parameter_master_id)) {
                foreach ($request->ref_cb_test_parameter_master_id as $key => $val) {

                    if (!empty($request->ref_cb_test_parameter_master_id[$key])) {
                        $data1 = array(
                            'at_op_transaction_certificate_entry_id'   => $request->at_op_transaction_certificate_entry_id,
                            'ref_cb_test_parameter_master_id'   => $request->ref_cb_test_parameter_master_id[$key],
                            'ref_product_id'   => $request->ref_product_id,
                            'created_by' => Auth::guard('misadmin')->user()->id,
                            'updated_by' => Auth::guard('misadmin')->user()->id
                        );

                        $result = AtCbTestParameterEntry::create($data1);
                    }
                }
            }

            Alert::success('Success', __('message.add_success'));
            return redirect()->back();
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
        return view('admin.transaction_Cb_certificate.producttestinformation', compact('id', 'data', 'tranEntry'));
    }



    public function pdfTcApplication($tcid = 43, $userid = 208)
    {

        $user =  User::where('id', Auth::user()->id)->first();
        $trans = AtOpTransactionVsTransactionProduct::with('getTransProductSource')->where('id', $tcid)->get();
        $data =  AtOpTransactionCertificateEntry::where('at_op_transaction_vs_transaction_product_id', $tcid)->first();
        //$customPaper = array(0,0,800.00,730.80);

        //echo view('admin/usermanagement/pdf/tcCertificate', compact('user','trans','data','userid'))->render();
        $pdf = PDF::loadView('admin/usermanagement/pdf/tcCertificate', compact('user', 'trans', 'data', 'userid'));
        $rand = str_pad(mt_rand(1, 99999999), 8, '0', STR_PAD_LEFT);
        return $pdf->stream($rand . '.pdf');
        //$pdf->save(public_path($flname));
        // $pdf = PDF::loadView('member/cpdvideo/transaction_pdf', compact('template'))->setPaper($customPaper, 'landscape');
        //     $rand = str_pad(mt_rand(1, 99999999), 8, '0', STR_PAD_LEFT);
        //     return $pdf->download($rand.'.pdf');

    }

    public function generateTC(Request $request)
    {
        $tcid = $request->tcid;
        $data = AtOpTransactionVsTransactionProduct::where('id', $tcid)->first();
        if ($data) {
            $m = date('m', strtotime($data->created_at));
            $y = date('y', strtotime($data->created_at));
            $lst = str_pad($data->id, 4, "0", STR_PAD_LEFT);
            $app_no = "ORG/TC/" . $y . $m . "/" . $lst;


            $user =  User::where('id', Auth::user()->id)->first();
            $tcIssueList = AtOpTransactionVsTransactionProduct::with('getTransProductSource')->where('id', $tcid)->get();
            $data = AtOpTransactionCertificateEntry::where('at_op_transaction_vs_transaction_product_id', $tcid)->first();
            $sourced_id = AtOpTransactionProductSourced::where('at_op_transaction_vs_transaction_product_id', $tcIssueList[0]->getTransProductSource[0]->at_op_transaction_vs_transaction_product_id)->first();
            $pack = AtOpTransactionPackingDetails::where('at_op_transaction_product_sourced_id', $sourced_id->id)->first();
            $ref_product_hs_code = RefProduct::where('id', $tcIssueList[0]->getTransProductSource[0]->ref_product_id)->first();
            $pdf = PDF::loadView('admin.transaction_Cb_certificate.cbTcviewApplication', compact('tcIssueList', 'user', 'data', 'pack', 'ref_product_hs_code'));
            $file_name = 'tc_' . time() . '.pdf';
            $filePath = public_path('/tc/' . $file_name);
            $directoryPath = dirname($filePath);
            if (!File::exists($directoryPath)) {
                File::makeDirectory($directoryPath, 0777, true);
            }
            $pdf->save($filePath);
        }
        $upData = array(
            'transaction_certificate_no' => $app_no,
            'file_path' => $file_name

        );

        $res =  AtOpTransactionVsTransactionProduct::where('id', $tcid)->update($upData);

        if ($res > 0) {
            Alert::success('Success', 'TC Generate Successfully.');
            return redirect()->back();
        } else {
            Alert::error('', 'Something went Wrong.');
            return redirect()->back();
        }
    }

    public function tsIssueList()
    {
        $userId = Auth::id();


        $tcIssueList = AtOpTransactionVsTransactionProduct::whereNotNull('tc_application_no')
            ->orderBy('id', 'desc')
            ->get();

        //print_r($tcIssueList); die;

        // dd($tcIssueList);

        $eMSignedModuleAlow = getUserDigitalSignatureModules(Auth::id(), 'TC');

        return view('admin.transaction_Cb_certificate.tc_issue_list', ['tcIssueList' =>  $tcIssueList, 'eMSignedModuleAlow' =>  $eMSignedModuleAlow]);
    }

    public function viewTCApplication($tcid, $userid)
    {

        $trans = AtOpTransactionVsTransactionProduct::with('getTransProductSource')->where('id', $tcid)->get();
        $data =  AtOpTransactionCertificateEntry::where('at_op_transaction_vs_transaction_product_id', $tcid)->first();
        // dd($trans);
        return view('admin.transaction_Cb_certificate.viewApplication', compact('tcid', 'userid', 'trans', 'data'));
    }

    public function TcViewApplication($id)
    {
        $user =  User::where('id', Auth::user()->id)->first();
        $batchdata =  AtBatchCreation::where('id', $id)->first();
        $tcIssueList = AtOpTransactionVsTransactionProduct::with('getTransProductSource')->where('id', $id)->get();
        $data = AtOpTransactionCertificateEntry::where('at_op_transaction_vs_transaction_product_id', $id)->first();

        $sourced_id = AtOpTransactionProductSourced::where('at_op_transaction_vs_transaction_product_id', $tcIssueList[0]->getTransProductSource[0]->at_op_transaction_vs_transaction_product_id)->first();
        $pack = AtOpTransactionPackingDetails::where('at_op_transaction_product_sourced_id', $sourced_id->id)->first();
        $ref_product_hs_code = RefProduct::where('id', $tcIssueList[0]->getTransProductSource[0]->ref_product_id)->first();
        // dd($pack->pack_size);
        return view('admin.transaction_Cb_certificate.cbTcviewApplication', compact('tcIssueList', 'user', 'data', 'pack', 'ref_product_hs_code'));
    }



    public function TcViewApplicationPdf($id)
    {
        $user =  User::where('id', Auth::user()->id)->first();
        $batchdata =  AtBatchCreation::where('id', $id)->first();
        $tcIssueList = AtOpTransactionVsTransactionProduct::with('getTransProductSource')->where('id', $id)->get();
        $data = AtOpTransactionCertificateEntry::where('at_op_transaction_vs_transaction_product_id', $id)->first();

        $sourced_id = AtOpTransactionProductSourced::where('at_op_transaction_vs_transaction_product_id', $tcIssueList[0]->getTransProductSource[0]->at_op_transaction_vs_transaction_product_id)->first();
        $pack = AtOpTransactionPackingDetails::where('at_op_transaction_product_sourced_id', $sourced_id->id)->first();
        $ref_product_hs_code = RefProduct::where('id', $tcIssueList[0]->getTransProductSource[0]->ref_product_id)->first();


        return  view('admin.transaction_Cb_certificate.cbTcviewApplicationpdf', compact('tcIssueList', 'user', 'data', 'pack', 'ref_product_hs_code'));
        // $pdf = PDF::loadView('admin.transaction_Cb_certificate.cbTcviewApplicationpdf', compact('tcIssueList', 'user', 'data', 'pack','ref_product_hs_code'));
        // return $pdf->download('tc_issue.pdf');
        // return view('admin.transaction_Cb_certificate.cbTcviewApplication', compact('tcIssueList', 'user', 'data', 'pack'));
    }



    public function ptcindex(Request $request)
    {


        $id = Auth::user()->id;
        $results = AtOpTransactionVsTransactionProduct::where('tc_application_no', 'LIKE', 'PTC%')->orderBy('created_at', 'asc')->get();

        if ($request->ajax()) {

            return DataTables::of($results)

                ->addIndexColumn()
                ->addColumn('tc_application_no', function ($row) {
                    return $row->tc_application_no ?? '';
                })->addColumn('tc_date', function ($row) {
                    return date("d-m-Y", strtotime($row->tc_date)) ?? '';
                })->addColumn('seller_scn', function ($row) {
                    return $row->seller_scn ?? '';
                    // })->addColumn('tc_application_no', function($row){
                    //     return $row->tc_application_no ?? '';
                    // })->addColumn('tc_application_no', function($row){
                    //     return $row->tc_application_no ?? '';
                    // })->addColumn('tc_application_no', function($row){
                    //     return $row->tc_application_no ?? '';
                    // })->addColumn('tc_application_no', function($row){
                    //     return $row->tc_application_no ?? '';
                    //
                })->addColumn('action', function ($row) {
                    $btn = '<a href="' . route("superadmin.cb.viewPTCApplication", ['ptcid' => $row->id, 'userid' => $row->created_by]) . '">View Application</a><br>
        <a href="' . route("superadmin.ptcrequestCbcertificateprocess", [$row->id]) . '">process</a><br>
        <a href="' . route("superadmin.traceApplication", [$row->id]) . '">Trace Application</a><br>
        <a href="' . route("superadmin.ptcCancelApplication", [$row->id]) . '">Send for Lab Test Cancel/Reject Application</a><br>';

                    return $btn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }



        return view('admin.transaction_Cb_certificate.ptc_application.index');
    }

    public function viewPTCApplication($tcid, $userid)
    {

        $trans = AtOpTransactionVsTransactionProduct::with('getTransProductSource')->where('id', $tcid)->get();
        $data =  AtOpTransactionCertificateEntry::where('at_op_transaction_vs_transaction_product_id', $tcid)->first();

        return view('admin.transaction_Cb_certificate.ptc_application.viewApplication', compact('tcid', 'userid', 'trans', 'data'));
    }

    public function ptcprocess(Request $request, $id)
    {

        $authsign = User::whereHas('roles', function ($q) {
            return $q->where('title', 'Authorized Signatory');
        })->where('created_by', Auth::id())->get();

        $productdetails = AtOpTransactionVsTransactionProduct::where('id', $id)->get();
        $data = AtOpTransactionCertificateEntry::where('at_op_transaction_vs_transaction_product_id', $id)->first();
        //dd($result);
        return view('admin.transaction_Cb_certificate.ptc_application.process', compact('id', 'productdetails', 'authsign', 'data'));
    }

    public function storePTCProcess(Request $request)
    {

        $request->validate([
            'order_contract_no' => 'required',
            'total_qty' => 'required',
            'gross_weight' => 'required',
            'country_origin' => 'required',
            'signatory_code' => 'required',

        ]);

        try {

            $id = $request->cre_id;
            $data = array(
                'order_contract_no'   => $request->order_contract_no ?? null,
                'total_qty'   => $request->total_qty ?? null,
                'gross_weight'   => $request->gross_weight ?? null,
                'country_origin'   => $request->country_origin ?? null,
                'signatory_code'   => $request->signatory_code ?? null,
                'updated_by' => Auth::guard('misadmin')->user()->id
            );

            $saveData = AtOpTransactionCertificateEntry::where('id', $request->row_id)->update($data);

            if (!empty($saveData)) {
                Alert::success('Success', __('message.add_success'));
                return redirect()->route('superadmin.ptcView', $request->tcid);
            } else {
                Alert::success('Success', 'Something Went Wrong!');
                return redirect()->back();
            }
        } catch (Exception $e) {
            //dd($e->getMessage());
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function ptcCancelApplication(Request $request, $id)
    {
        //dd($id);
        $data = AtOpTransactionProductSourced::where('at_op_transaction_vs_transaction_product_id', $id)->get();
        $tranEntry = AtOpTransactionCertificateEntry::where('at_op_transaction_vs_transaction_product_id', $id)->first();
        return view('admin.transaction_Cb_certificate.ptc_application.rejectApplication', compact('data', 'tranEntry', 'id'));
    }

    public function ptcCancelApplicationPost(Request $request, $id)
    {
        $request->validate([
            'cb_remarks' => 'required',
        ]);
        // dd($request->all());
        try {
            $id = $request->at_op_transaction_vs_transaction_product_id ?? '';
            $data = array(
                'ptc_rejected_flag' => $request->ptc_rejected_flag,
                'cb_remarks' => $request->cb_remarks,

            );

            $result = AtOpTransactionCertificateEntry::where('at_op_transaction_vs_transaction_product_id', $id)->update($data);
            if ($result == 1) {
                Alert::success('success', "Application Reject Successfully.");
                return redirect()->back();
            } else {
                Alert::success('error', "Something went wrong.");
                return redirect()->route('superadmin.ptcrequestCbcertificate');
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function ptcView($id)
    {

        return view('admin.transaction_Cb_certificate.ptc_application.ptcView', compact('id'));
    }

    public function traceApplication($id)
    {

        $tranEntry = AtOpTransactionCertificateEntry::where('at_op_transaction_vs_transaction_product_id', $id)->first();
        //dd($tranEntry);
        return view('admin.transaction_Cb_certificate.ptc_application.trace_application', compact('id', 'tranEntry'));
    }
}

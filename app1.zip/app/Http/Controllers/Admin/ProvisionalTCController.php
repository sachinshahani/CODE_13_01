<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Permission;
use App\Models\Role;
use App\Models\RoleUser;
use App\Models\User;
use App\Models\AtClosingStock;
use App\Models\UserInspector;
use App\Models\UserWarehouse;
use App\Models\WildHarvesterForestProductDetail;
use App\Models\RefState;
use App\Models\RefDistrict;
use App\Models\RefVillage;
use App\Models\IndividualProducerFarmerDetail;
use App\Models\IndividualProducerFarmDetail;
use App\Models\AtFarmerRegDetail;
use App\Models\AtFarmDetails;
use App\Models\AtOrderAccepted;
use App\Models\WildHarvesterDetail;
use App\Models\IndividualProducerDetailOfStandingCorp;
use App\Models\AtOpTransactionVsTransactionProduct;
use App\Models\AtOpTransactionCertificateEntry;
use App\Models\AtOpTransactionProductSourced;
use App\Models\AtOpTransactionPackingDetails;
use Yajra\DataTables\DataTables;
use App\Models\AtFarmerStandingCorpDetail;
use App\Models\AtPurchaseDetails;
use App\Models\AtPurchaseRequest;
use App\Models\AtOrderDetailsReceivedFromBuyer;
use App\Models\RefPackingMaster;
use App\Models\CertificateStandardDetail;
use Exception;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;
use Illuminate\Support\Facades\DB;

class ProvisionalTCController extends Controller
{
	

	public function applyForProvisionalTC()
	{
		$user_id=Auth::user()->id;
		$scope= CertificateStandardDetail::where('at_user_id',$user_id)->first();
		$tcEntry= AtOpTransactionCertificateEntry::where('created_by',$user_id)->first();
		
		return view('admin.provisionalTC.apply_for_provisional_tc',compact('scope','tcEntry'));
	}
	public function applyForProvisionalTCStore(Request $request)
	{
		//dd($request->all());
		$user_id=Auth::user()->id;
		// $request->validate([
		// 	'ie_code' => 'required',
		// 	'country_origin' => 'required',
			
		// ]);
		try
        {
			$data=array(
				'seller_at_op_certificate_standard_details_id' => $request->seller_at_op_certificate_standard_details_id,
				'country_origin' => $request->country_origin,
				'ie_code' => $request->ie_code,
				'created_by' => $user_id
			);
			$result = AtOpTransactionCertificateEntry::updateOrCreate(['created_by'=>$user_id],$data);
			
			if(!empty($result->id)){
				Alert::success('Success', 'Data add Successfully.');
				return redirect()->route('superadmin.step2');
			}else{
				Alert::success('Success','Something went wrong.');
				return redirect()->back();
			}
		}
		catch (Exception $e)
		{
			Log::error($e->getMessage());
			abort('404');
		}
	}

	public function addProduct()
	{
		
		$user_id = Auth::guard('misadmin')->user()->id;
		$operator_type_id = Auth::guard('misadmin')->user()->ref_operator_type_id;

		// $order_list2 = DB::select("select at_purchase_request.id, at_purchase_request.commodity, at_closing_stock.id as clsid,at_closing_stock.organic_status, at_closing_stock.closing_stock, at_purchase_request.quantity from at_purchase_request INNER join at_order_details_received_from_buyer as odrb on odrb.at_purchase_request_id = at_purchase_request.id inner join at_order_accepted on at_order_accepted.at_order_details_received_from_buyer_id = odrb.id inner join at_closing_stock on at_closing_stock.at_user_id = at_purchase_request.at_user_id and at_closing_stock.ref_product_id = at_purchase_request.commodity
        // inner join at_farmer_standing_crop_details on at_farmer_standing_crop_details.id = at_closing_stock.at_farmer_standing_crop_details_id where at_purchase_request.created_by = '$user_id' and at_purchase_request.order_status = 1  group BY (at_purchase_request.commodity,at_purchase_request.id,at_closing_stock.organic_status,closing_stock,at_purchase_request.quantity,at_closing_stock.id)");

		$order_list2 = DB::select("select at_purchase_request.id, at_purchase_request.commodity, at_closing_stock.id as clsid,at_closing_stock.organic_status, at_closing_stock.closing_stock, at_purchase_request.quantity from at_purchase_request INNER join at_order_details_received_from_buyer as odrb on odrb.at_purchase_request_id = at_purchase_request.id inner join at_order_accepted on at_order_accepted.at_order_details_received_from_buyer_id = odrb.id inner join at_closing_stock on at_closing_stock.at_user_id = at_purchase_request.at_user_id and at_closing_stock.ref_product_id = at_purchase_request.commodity
        inner join at_farmer_standing_crop_details on at_farmer_standing_crop_details.id = at_closing_stock.at_farmer_standing_crop_details_id where at_purchase_request.created_by = '$user_id' and at_purchase_request.order_status = 1  group BY (at_purchase_request.commodity,at_purchase_request.id,at_closing_stock.organic_status,closing_stock,at_purchase_request.quantity,at_closing_stock.id) LIMIT 1");

        $order=array();
        $j=0;
		
        foreach($order_list2 as $key => $vls){
            $order['purchase_list'][$key] = $vls;
            $purchases = AtPurchaseDetails::where('at_closing_stock_id',$vls->clsid)->get();
            $order['purchase_list'][$key]->mypurchase = $purchases;
        }
		
		$data = AtOpTransactionVsTransactionProduct::with('getTransProductSource')->where('created_by',Auth::guard('misadmin')->user()->id)->get();
		
		return view('admin.provisionalTC.add_product',compact('order', 'data'));
	}

	public function addProductStore(Request $request)
	{
		//dd($request->all());
		try {
			//dd($request->all());
			$operator_type_id = Auth::guard('misadmin')->user()->ref_operator_type_id;

			foreach ($request->lots as $key => $val) {

				if(!empty($request->lots[$key])){
					$data = array(
						'farm_no'   => $request->farm_no[$key],
						'total_qty'   => $request->total_qty[$key],
						'tc_date'   => date('Y-m-d'),
						'operator_type'   => $operator_type_id,
						'rem_qty'   => $request->rem_qty[$key],
                        'quantity_for_tc'   => $request->req_qty[$key],
						'product_code' =>$request->product_code[$key],
						'organic_status' =>$request->organic_status[$key],
						//'quantity_for_tc'   => $request->quantity_for_tc[$key],
						'created_by' => Auth::guard('misadmin')->user()->id,
						'updated_by' => Auth::guard('misadmin')->user()->id
					);

					$result = AtOpTransactionVsTransactionProduct::updateOrCreate([
						'id'   => $request->row_id[$key],
						//'created_by' =>  Auth::guard('misadmin')->user()->id,
					],$data);
					
					if(!empty($result)){
						foreach ($request->pur_lots[$key]  as $k => $val1) {

							if(!empty($request->pur_lots[$key])){
								$data1 = array(
									'at_op_transaction_vs_transaction_product_id'   => $result->id,
									'ref_product_id'   => $request->ref_product_id[$key][$k],
									'at_closing_stock_id'   => $request->at_closing_stock_id[$key][$k],
									'at_purchase_details_id'   => $request->at_purchase_details_id[$key][$k],
									// 'product_code' =>'',
									'organic_status' =>$request->op_organic_status[$key][$k],
								    'qty_in_mt' =>$request->qty_in_mt[$key][$k],
									'source_date'   => date('Y-m-d'),
									'created_by' => Auth::guard('misadmin')->user()->id,
									'updated_by' => Auth::guard('misadmin')->user()->id
								);
								$result1 = AtOpTransactionProductSourced::updateOrCreate([
									'id'   => $request->rows_id[$key][$k],
								],$data1);
							}
						}
						
						if(!empty($result1->id)){
							Alert::success('Success', 'Data add Successfully.');
							return redirect()->route('superadmin.step3',[$result->id]);
						}else{
							Alert::success('Success','Something went wrong.');
							return redirect()->back();
						}
					}
				}
			}

        } catch (Exception $e) {

            Log::error($e->getMessage());
            abort('404');
        }
	}

	public function packingDetails($id)
	{
		$trans = AtOpTransactionVsTransactionProduct::with('getTransProductSource')->where('id',$id)->get();
	
        $packs = RefPackingMaster::get();

		return view('admin.provisionalTC.packing_detail',compact('trans','packs'));
	}

	public function storePackingDetail(Request $request){

        $request->validate([
            'value_inr' => 'required',
            'trade_name_of_product' => 'required',
            'ref_packing_master_id.*' => 'required',
            'no_of_box.*' => 'required',
            'pack_size.*' => 'required',
            'total_qty_in_kg.*' => 'required',
        ]);
		// if(!empty($validator->fails())) {
		// 	return Redirect::back()->withErrors($validator);
		// }
        try {
			//dd($request->all());
			$operator_type_id = Auth::guard('misadmin')->user()->ref_operator_type_id;
			$edtVal = 0;
			if(!empty($request->at_op_transaction_product_sourced_id)){
				foreach ($request->at_op_transaction_product_sourced_id as $key => $val) {

					if(!empty($request->at_op_transaction_product_sourced_id[$key])){
						$data = array(
							'at_op_transaction_product_sourced_id'   => $request->at_op_transaction_product_sourced_id[$key],
							// 'ref_product_id'   => $request->ref_product_id,
							'ref_packing_master_id'   => $request->ref_packing_master_id[$key],
							'no_of_box'   => $request->no_of_box[$key],
							'pack_size'   => $request->pack_size[$key],
							'total_qty_in_kg'   => $request->total_qty_in_kg[$key],
							'created_by' => Auth::guard('misadmin')->user()->id,
							'updated_by' => Auth::guard('misadmin')->user()->id
						);
	
						$result = AtOpTransactionPackingDetails::updateOrCreate([
							'id' => $request->row_id[$key],
						],$data);

				
						
					}
				}
				
				if(!empty($result)){
					$updateData= array(
						'value_inr'=>$request->value_inr,
						'cn_code'=>$request->cn_code,
						'currency_type_id'=>$request->currency_type_id,
						'trade_name_of_product'=>$request->trade_name_of_product,
					);
					$res = AtOpTransactionVsTransactionProduct::where('id',$request->trans_id)->update($updateData);
					
					Alert::success('Success', 'Data add Successfully.');
					return redirect()->route('superadmin.step4',$request->trans_id);
					
				}
			}

        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }


	public function TCDetails($id)
	{
		$data =  AtOpTransactionCertificateEntry::where('at_op_transaction_vs_transaction_product_id',$id)->first();
		return view('admin.provisionalTC.tc_details',compact('id','data'));
	}

	public function storeTcDetail(Request $request){
		//dd($request->all());
        $request->validate([
            'invoice_no.*' => 'required',
            'invoice_date.*' => 'required',
            //'invoice_value.*' => 'required',
            //'place_of_dispatch' => 'required',
            'lot_number' => 'required',
            'place_of_destination' => 'required',
            'marks_no' => 'required',
            'reference_no' => 'required',
        ]);
	
        try {
			
			/// Date of Transport
			if(!empty($request->road_transport_date)){
				$transport_date = date('Y-m-d H:i:s',strtotime($request->road_transport_date));
			}elseif(!empty($request->train_transport_date)){
				$transport_date = date('Y-m-d H:i:s',strtotime($request->train_transport_date));
			}else{
				$transport_date = null;
			}



			$data = array(
				'exporter_seller_name'   => $request->exporter_seller_name ?? null,
				'seller_email'   => $request->seller_email ?? null,
				'seller_at_op_certificate_standard_details_id'   => $request->seller_at_op_certificate_standard_details_id ?? null,
				'exporter_seller_address'   => $request->exporter_seller_address ?? null,
				'buyer_id_proof'   => $request->buyer_id_proof ?? null,
				'buyer_name'   => $request->buyer_name ?? null,
				'buyer_address'   => $request->buyer_address ?? null,
				'buyer_at_op_certificate_standard_details_id'   => $request->buyer_at_op_certificate_standard_details_id ?? null,
				'buyer_ref_state_id'   => $request->buyer_ref_state_id ?? null,
				'buyer_email'   => $request->buyer_email ?? null,
				'consignee_name'   => $request->consignee_name ?? null,
				'destination_address'   => $request->destination_address ?? null,
				'eu_country_consignee'   => $request->eu_country_consignee ?? null,
				'consignee_email'   => $request->consignee_email ?? null,
				// 'invoice_no'   => $request->invoice_no ?? null,
				// 'invoice_date'   => date('Y-m-d H:i:s',strtotime($request->invoice_date)) ?? null,
				// 'invoice_value'   => $request->invoice_value ?? null,
				//'place_of_dispatch'   => $request->place_of_dispatch ?? null,
				'place_of_destination'   => $request->place_of_destination ?? null,
				'marks_no'   => $request->marks_no ?? null,
				'reference_no'   => $request->reference_no ?? null,
				'transport_mode'   => $request->transport_mode ?? null,

				'container_no_road'   => $request->container_no_road ?? null,
                'transport_doc_no'   => $request->transport_doc_no ?? null,
				'transport_date'   => $transport_date ?? null,

				'train_no'   => $request->train_no ?? null,
				'wagon_no'   => $request->wagon_no ?? null,
				'train_transport_date'   => date('Y-m-d H:i:s',strtotime($request->train_transport_date)) ?? null,
				
				'flight_no'   => $request->flight_no ?? null,
				'flight_date'   => date('Y-m-d H:i:s',strtotime($request->flight_date)) ?? null,
				'airway_bill_no'   => $request->airway_bill_no ?? null,
				'airway_bill_date'   => date('Y-m-d H:i:s',strtotime($request->airway_bill_date)) ?? null,
				'container_no_air'   => $request->container_no_air ?? null,

				
				'ship_no'   => $request->ship_no ?? null,
				'ship_name'   => $request->ship_name ?? null,
				'vessel_date'   => $request->vessel_date ?? null,
				'bill_of_lading'   => $request->bill_of_lading ?? null,
				'date_of_lading'   => $request->date_of_lading ?? null,
				'container_no_ship'   => $request->container_no_ship ?? null,

				'gross_weight'   => $request->gross_weight ?? null,
				'created_by' => Auth::guard('misadmin')->user()->id,
				'updated_by' => Auth::guard('misadmin')->user()->id,
				'at_op_transaction_vs_transaction_product_id'=>$request->at_op_transaction_vs_transaction_product_id,
				'lot_number'=>$request->lot_number,
			);
			
			$saveData = AtOpTransactionCertificateEntry::updateOrCreate(['at_op_transaction_vs_transaction_product_id'=>$request->at_op_transaction_vs_transaction_product_id],$data);
			Alert::success('Success', __('message.add_success'));
			return redirect()->route('superadmin.ptcForwardToCB',$request->at_op_transaction_vs_transaction_product_id);
		
		} catch (Exception $e) {
			Log::error($e->getMessage());
            abort('404');
        }
    }

	public function ptcForwardToCB($id){
		
        return view('admin.provisionalTC.ptcforwardToCB',compact('id'));
    }

	public function viewPTCApplication($id){

	    $trans = AtOpTransactionVsTransactionProduct::with('getTransProductSource')->where('id',$id)->get();
		$data =  AtOpTransactionCertificateEntry::where('at_op_transaction_vs_transaction_product_id',$id)->first();
        return view('admin.provisionalTC.viewPTCApplication',compact('id','trans','data'));
    }

	public function postForwardToCB(Request $request){
       //dd($request->all());
		try {
			$data = AtOpTransactionVsTransactionProduct::select('created_at','id')->where('id',$request->row_id)->first();
			if($data){
				$d = date('d',strtotime($data->created_at));
				$m = date('m',strtotime($data->created_at));
				$y = date('Y',strtotime($data->created_at));
				$lst = str_pad($data->id, 4, "0", STR_PAD_LEFT);
				$app_no = "PTCTC-".$y.$m.$d.$lst;
				
			}
			$upData = array(
				'tc_application_no'=>$app_no,
				'tc_date'=>date('Y-m-d'),
				'nop_status'=>'Pending',
			);
			
			$res = AtOpTransactionVsTransactionProduct::where('id',$request->row_id)->update($upData);
			
            if($res > 0){
				Alert::success('Success', __('message.add_success'));
				return redirect()->route('superadmin.listOfPTC');
			}else{
				Alert::error('', 'Something went Wrong.');
				return redirect()->back();
			}
		

		} catch (Exception $e) {
			Log::error($e->getMessage());
			abort('404');
		}
    }

	public function listOfPTC(Request $request){
        $id = Auth::guard('misadmin')->user()->id;
		$result = AtOpTransactionVsTransactionProduct::where('created_by',$id)->get();
		
        return view('admin.provisionalTC.listOfPTC',compact('result'));
		
	}

}





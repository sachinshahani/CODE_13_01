<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\RefState;
use Auth;
use Crypt;
use DB;
use Exception;
use Illuminate\Http\Request;
use RealRashid\SweetAlert\Facades\Alert;
use Validator;

class MasterManagements extends Controller
{
    //


    /**
     * list statelist
     */
    public function statelist(Request $request)
    {
        abort_unless(\Gate::allows('state_list'), 403);

        if ($request->ajax()) {
            $columns = [
                0 => 'id',
                1 => 'zone_name',
                2 => 'state_name',
            ];
            $totalData = RefState::where('is_deleted', 0)->count();
            $totalFiltered = $totalData;
            $limit = $request->input('length');
            $start = $request->input('start');
            $order = $columns[$request->input('order.0.column')];
            $dir = $request->input('order.0.dir');
            $search = $request->input('search.value');
            $locQry = DB::table('ref_state as loc')
                ->LeftJoin('ref_zone as zone', 'zone.id', '=', 'loc.ref_zone_id')
                ->select('loc.*')
                ->where('loc.is_deleted', 0);
            if (isset($search) && $search != '') {
                $locQry = $locQry->where(function ($query) use ($search) {
                    $query->where('zone.zone_name', 'LIKE', "%{$search}%")
                        ->orWhere('loc.state_name', 'LIKE', "%{$search}%");
                });
            }
            if (isset($search) && $search != '') {
                $totalFiltered = $locQry->count();
            } else {
                $totalFiltered = $totalData;
            }

            $locality = $locQry->offset($start)->limit($limit)->orderBy($order, $dir)->get();

            $data = [];
            if (! empty($locality)) {
                $count = 0;
                foreach ($locality as $key => $localityvalue) {
                    $nestedData['id'] = $count + $start + 1;
                    $nestedData['state_name'] = $localityvalue->state_name ?? '';
                    $nestedData['zone_name'] = Zone::where('id', '=', $localityvalue->ref_zone_id)->where('is_deleted', '=', 0)->first()->zone_name ?? '';
                    $nestedData['updated_at'] = isset($localityvalue->updated_at) ? dateFormat($localityvalue->updated_at) : '';
                    $data[] = $nestedData;
                    $count++;
                }
            }
            $json_data = [
                'draw' => intval($request->input('draw')),
                'recordsTotal' => intval($totalData),
                'recordsFiltered' => intval($totalFiltered),
                'data' => $data,
            ];
            echo json_encode($json_data);
            exit;
        }

        return view('admin/master/state/index');
    }


    public function statedropdownlist(Request $request)
    {
        $zone_id = $request->zone_id;
        $statelist = getState($zone_id);

        return json_encode(['data' => $statelist]);
    }




	public function getBlock(Request $request){
        $stateCode = $request->state_code;
        $districtCode = $request->district_code;

        $blocks = RefBlock::where('state_code',$stateCode)->where('disct_code',$districtCode)->get();
        $html = '<option value="">Please Select Block</option>';
        foreach ($blocks as $block){
            $html .= '<option value="'.$block->block_code.'">'.$block->block_name.'</option>';
        }

        return $html;
    }

    public function getVillage(Request $request){
        $stateCode = $request->state_code;
        $districtCode = $request->district_code;

        $villages = RefVillage::where('ref_state_code',$stateCode)->where('ref_district_code',$districtCode)->get();
        $html = '<option value="">Please Select Village</option>';
        foreach ($villages as $village){
            $html .= '<option value="'.$village->village_code.'">'.$village->village_name.'</option>';
        }

        return $html;
    }



    public function zonedropdownlist(Request $request)
    {
        $member_id = $request->member_id;
        $memberslist = getZoneByMember($member_id);

        return json_encode(['data' => $memberslist]);
    }

    public function zonedropdownlistAll(Request $request)
    {
        $memberslist = getZone();

        return json_encode(['data' => $memberslist]);
    }

    public function statedropdownlistAll(Request $request)
    {
        $statelist = getLocality($zone_id = null);
        return json_encode(['data' => $statelist]);
    }


}

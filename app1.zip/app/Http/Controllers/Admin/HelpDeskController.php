<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AtHelpDeskDetail;
use App\Models\RefSubIssueType;
use App\Models\RefSubIssue;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Validator;
use GuzzleHttp\Client;
use Yajra\DataTables\DataTables;

use DB;

class HelpDeskController extends Controller
{

   public function index()
   {

      /*$user = User::select('email', 'first_name', 'mobile_no', 'address', 'operator_name', 'contact_person_first_name', 'contact_person_mobile_number', 'registration_no')
         ->where('created_by', Auth::user()->id)
         ->first();*/
      $user = User::select('email', 'first_name', 'mobile_no', 'address', 'contact_person_first_name', 'contact_person_mobile_number', 'registration_no')->where('id', Auth::user()->id)->first();

      //........if login user has operator type (2,3,4,5,6)..........//

      if (Auth::user()->ref_operator_type_id == 2 || Auth::user()->ref_operator_type_id == 3 || Auth::user()->ref_operator_type_id == 4 || Auth::user()->ref_operator_type_id == 5 || Auth::user()->ref_operator_type_id == 6) {
         $user = User::select('email', 'first_name', 'mobile_no', 'address', 'contact_person_first_name', 'contact_person_mobile_number', 'registration_no')->where('id', Auth::user()->created_by)->first();
      } else {
         $user = User::select('email', 'first_name', 'mobile_no', 'address',  'contact_person_first_name', 'contact_person_mobile_number', 'registration_no')->where('id', Auth::user()->id)->first();
      }

      return view("admin.help_desk.index", compact("user"));
   }
   public function myHelpdesktickets(Request $request)
   { {
         // $all_cb_users_id = User::where('ref_operator_type_id', 1)->distinct()->pluck('id');
         // $query = AtHelpDeskDetail::whereIn('at_user_id', $all_cb_users_id)->orderBy('id', 'DESC')->get();

         //    $query = AtHelpDeskDetail::where('at_user_id', $userId)->get();  
         //    // $data =  AtHelpDeskDetail::whereIn('at_user_id', $all_cb_users_id)->get();
         //   dd($query);
         // dd(Auth::id());
         $query = AtHelpDeskDetail::where('at_user_id', Auth::id())->orderBy('id', 'DESC')->get();
         // dd($query);
         if ($request->ajax()) {
            $dataTable = DataTables::of($query)
               ->addIndexColumn()
               ->addColumn('issue_id', function ($row) {
                  return $row->issue_id ?? '';
               })
               // ->addColumn('registration_number', function ($row) {
               //    return $row->registration_number ? $row->registration_number : ($row->registration_number ? $row->registration_number : '-');
               // })
               ->addColumn('issue_related_to', function ($row) {
                  return strtoupper($row->issue_related_to ?? '');
               })

               // ->addColumn('at_user_id', function ($row) {
               //    $all_user = User::where('id', $row->at_user_id)->first();
               //    return $all_user->first_name ?? '';
               // })
               ->addColumn('ref_issue_type_id', function ($row) {
                  return getIssueTypeByID($row->ref_issue_type_id ?? '');
               })

               ->addColumn('ref_sub_issue_type_id', function ($row) {
                  return getSubIssueTypeByID($row->ref_sub_issue_type_id ?? '');
               })

               ->addColumn('status', function ($row) {
                  return $row->status == 1 ? 'Open' : ($row->status == 2 ? 'Closed' : '');
               })
               ->addColumn('from_date', function ($row) {
                  return date('d-m-Y', strtotime($row->from_date ?? '')).' '.date('H:i:s', strtotime($row->created_at ?? ''));
               })
               ->addColumn('action', function ($row) {
                  $actionButton =  $actionButton =  '<a href="' . route('superadmin.ticket', $row->id) . '"><span><i class="mdi mdi-eye-circle text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="view ticket"></i></span></a>';
                  return $actionButton;
               })
               ->rawColumns(['action']);
            return $dataTable->make(true);
         }
         return view('admin.help_desk.my_help_desk');
      }
   }
   public function search(Request $request)
   {
      $res = AtHelpDeskDetail::where('id', Auth::id())->first();
      $user = User::where('id', Auth::user()->id)->first();
      return view("admin.help_desk.search", compact('res', 'user'));
   }

   public function helpdesktickets_OLD()
   {
      $data = AtHelpDeskDetail::all();
      return view("admin.help_desk.apeda-help-desk", compact('data'));
   }

   public function helpdesktickets()
   {
      $all_cb_users_id = User::where('ref_operator_type_id', 1)->distinct()->pluck('id');
      $data = AtHelpDeskDetail::whereIn('at_user_id', $all_cb_users_id)->get();
      $table_date = AtHelpDeskDetail::get();
      // dd($data);  
      return view("admin.help_desk.apeda-help-desk", compact('data','table_date'));
   }

   public function ticket($id)
   {
      $res = AtHelpDeskDetail::where('id', $id)->first();
      //dd($res);
      $user = User::where('id', Auth::user()->id)->first();
      return view('admin.help_desk.apedaviewticket', compact('res', 'user'));
   }


   public function searchstore(Request $request)
   {
      //   dd($request->all());

      //    $rules = [
      //       'registration_no' => 'nullable|numeric', 
      //       'from_date' => 'nullable|date',
      //       'to_date' => 'nullable|date|after_or_equal:from_date',
      //       'status' => 'nullable|in:your,valid,status,options', 
      //   ];

      //   // Validate the request
      //   $validator = Validator::make($request->all(), $rules);

      //   if ($validator->fails()) {
      //       return response()->json(['msg' => 'error', 'data' => $validator->errors()->first()]);
      //   }

      $landings = AtHelpDeskDetail::query();

      if ($request->registration_no != '') {
         $landings->where("registration_number", $request->registration_no);
      }

      if (!is_null($request->from_date)) {
         $landings->where('from_date', '>=', $request->from_date);
      }

      if (!is_null($request->to_date)) {
         $landings->where('to_date', '<=', $request->to_date);
      }
      if (!is_null($request->status)) {
         $landings->where('status', $request->status);
      }
      $res = $landings->get();


      $returnData = array();

      if (count($res) > 0) {

         foreach ($res as $key => $res) {
            $returnData[$key]['registration_no'] = $res->registration_number;
            $returnData[$key]['issue_related_to'] = $res->issue_related_to;
            $returnData[$key]['description'] = $res->description;
            $returnData[$key]['status'] = $res->status;
         }


         return response()->json(['msg' => 'success', 'data' => $returnData]);
      } else {
         return response()->json(['msg' => 'error', 'data' => 'No Record found.']);
      }
   }

   public function cbhelpdesksave(Request $request)
   {
      // Generate unique key and issue ID
      $uniqueKey = uniqid('TIC/');
      $issue_id = $request->user()->id;
      $month = date('m');
      $val = $uniqueKey . "/" .  $issue_id;

      // Check if the document file is uploaded
      $document_upload_photo = '';
      if ($request->hasFile('document_upload') && !empty($request->file('document_upload'))) {
         $documentRootPath = 'public/helpDesk';
         $file_path = time() . rand() . '.' . $request->file('document_upload')->getClientOriginalExtension();
         $request->file('document_upload')->move($documentRootPath, $file_path);
         $document_upload_photo = $file_path;
      }

      // Determine ref_issue_type_id based on issue_related_to and ensure it is not empty
      $ref_issue_type_id = '';
      if ($request->issue_related_to == 'cb' && !empty($request->ref_issue_type_id)) {
         $ref_issue_type_id = $request->ref_issue_type_id;
      } elseif ($request->issue_related_to == 'operator' && !empty($request->ope_ref_issue_type_id)) {
         $ref_issue_type_id = $request->ope_ref_issue_type_id;
      }

      // Check if other required inputs are not empty before saving
      // if (!empty($ref_issue_type_id) && !empty($request->input('ref_sub_issue_type_id')) && !empty($request->input('registration_number'))) {
      if (!empty($ref_issue_type_id) && !empty($request->input('ref_sub_issue_type_id'))) {
         $data = new AtHelpDeskDetail;
         $data->ref_issue_type_id = $ref_issue_type_id;
         $data->issue_id = $val;
         $data->ref_sub_issue_type_id = $request->input('ref_sub_issue_type_id');
         $data->issue_related_to = $request->input('issue_related_to');
         $data->registration_number = $request->input('registration_number');
         $data->status = 1;
         $data->description = $request->input('description');
         // $data->ref_document_id = $request->input('ref_document_id');
         $data->from_date = date('Y-m-d');
         $data->to_date = date('Y-m-d');
         $data->document_upload = $document_upload_photo;
         $data->at_user_id = $request->user()->id;
         $data->save();

         return redirect()->back()->with('success', 'Data stored successfully.');
      } else {
         return redirect()->back()->with('error', 'Some required fields are empty. Please check your input.');
      }
   }

   public function getSubIssueType(Request $request)
   {
      $id = $request->id;
     
      //$data =  DB::table('ref_sub_issue_type')->where('ref_issue_type_id', $request->id)->get();
      $data = DB::table('ref_sub_issue_type')
               ->where('ref_issue_type_id', $request->id)
               ->where('id', '!=', 7) 
               ->get();

      $selected = '';

      $option = '<option value="">-Select-</option>';
      if (count($data) > 0) {
         foreach ($data as $key => $value) {
            if ($id == $value->id) {
               $selected = 'selected';

               $option .= '<option value="' . $value->id . '"  selected="' . $selected . '">' . $value->sub_issue_name . '</option>';
            } else {
               $option .= '<option value="' . $value->id . '">' . $value->sub_issue_name . '</option>';
            }
         }
      } else {

         $option .= '<option value="">No record found.</option>';
      }
      return response()->json($option);
   }

   // public function getReqDoc(Request $request){

   //    //dd($request->all());
   //    $id=$request->id;
   //    $data =  DB::table('ref_sub_issue_type')->where('ref_issue_type_id',$request->id)->get();
   //    $selected='';

   //    $option='<option value="">-Select-</option>';
   //    if(count($data)>0){
   //       foreach ($data as $key => $value) {
   //          if($id==$value->id){
   //                $selected = 'selected';

   //                $option.='<option value="'.$value->id.'"  selected="'.$selected.'">'.$value->sub_issue_name.'</option>';
   //             }else{
   //                $option.='<option value="'.$value->id.'">'.$value->sub_issue_name.'</option>';
   //             }

   //       }
   //    }else{

   //       $option.='<option value="">No record found.</option>';
   //    }
   //    return response()->json($option);
   //    }

   public function ticketlist_OLD()
   {
      // $data = AtHelpDeskDetail::whereIn('ref_issue_type_id', [5, 6])->where('id', Auth::user()->id)->get();
      $data = AtHelpDeskDetail::where('at_user_id', Auth::user()->id)->get();
      return view('admin.help_desk.ticket-list', compact('data'));
   }

   public function ticketlist()
   {
      //......For ref_operator_type 1 (CB).....//
      $users_createdby_CB = User::where('created_by', Auth::user()->id)->distinct()->pluck('id');
      $data = AtHelpDeskDetail::whereIn('at_user_id', $users_createdby_CB)->get();

      return view('admin.help_desk.ticket-list', compact('data'));
   }
   public function getTicketlistCb(Request $request)
   {

      $users_createdby_CB = User::where('created_by', Auth::user()->id)->distinct()->pluck('id');
      $query = AtHelpDeskDetail::whereIn('at_user_id', $users_createdby_CB)->orderBy('id', 'DESC')->get();

      if ($request->ajax()) {


         $dataTable = DataTables::of($query)
            ->addIndexColumn()

            ->addColumn('registration_number', function ($row) {
               return ($row->registration_number ?? '');
            })
            ->addColumn('issue_related_to', function ($row) {
               return strtoupper($row->issue_related_to ?? '');
            })

            ->addColumn('at_user_id', function ($row) {
               $all_user = User::where('id', $row->at_user_id)->first();
               return $all_user->first_name ?? '';
            })
            ->addColumn('ref_issue_type_id', function ($row) {
               return getIssueTypeByID($row->ref_issue_type_id ?? '');
            })

            ->addColumn('ref_sub_issue_type_id', function ($row) {
               return getSubIssueTypeByID($row->ref_sub_issue_type_id ?? '');
            })
            ->addColumn('issue_id', function ($row) {
               return $row->issue_id ?? '';
            })
            ->addColumn('status', function ($row) {
               return getHelpstatusdata($row->status ?? '');
            })
            ->addColumn('from_date', function ($row) {
               return date('d-m-Y', strtotime($row->from_date ?? '')).' '.date('H:i:s', strtotime($row->created_at ?? ''));

            })
            ->addColumn('action', function ($row) {
               if ($row->status == 1) {
                  $actionButton =  '<a href="' . route('superadmin.ticket', $row->id) . '"><span><i class="mdi mdi-eye-circle text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="view ticket"></i></span></a>
                   <a href="' . route('getSuperadmin.helpdesktickets.edit', $row->id) . '">
                     <span><i class="mdi mdi-pencil-circle text-muted fs-16 align-middle me-1 text-primary" data-toggle="tooltip" title="pencil ticket"></i></span>
                     </a>';
               } else {
                  $actionButton =  $actionButton =  '<a href="' . route('superadmin.ticket', $row->id) . '"><span><i class="mdi mdi-eye-circle text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="view ticket"></i></span></a>';
               }
               return $actionButton;
            })
            ->rawColumns(['action']);
         return $dataTable->make(true);
      }

      return view('admin.help_desk.ticket-list');
   }

   public function viewticket($id)
   {
      $res = AtHelpDeskDetail::where('id', $id)->first();

      $user = User::where('registration_no', $res->registration_number)->first();
      //dd($user);
      return view('admin.help_desk.view-ticket', compact('res', 'user'));
   }

   public function getTicketList(Request $request)
   {
      $data = AtHelpDeskDetail::where('issue_related_to', $request->issue_related_to)->get();
      //dd($data);
      if (count($data) > 0) {
         foreach ($data as $key => $res) {
            if ($request->issue_related_to == 'operator') {
               $returnData[$key]['reg_no'] = $res->registration_number;
            }
            $returnData[$key]['issue_id'] = $res->issue_id;
            $returnData[$key]['ref_issue_type_id'] = getIssueTypeByID($res->ref_issue_type_id);
            $returnData[$key]['ref_sub_issue_type_id'] = getSubIssueTypeByID($res->ref_sub_issue_type_id);
            $returnData[$key]['description'] = $res->description;
            $returnData[$key]['document_upload'] = $res->document_upload;
         }
         return response()->json(['msg' => 'success', 'data' => $returnData]);
      } else {
         return response()->json(['msg' => 'error', 'data' => 'No Record found.']);
      }
      return response()->json(['data' => $data]);
   }

   public function downloadFile($filePath)
   {
      $file = storage_path('public/helpDesk/' . $filePath);
      return Response::download($file);
   }


   //--------------------pan api testing code-------------------//
   public function pansendRequestindex(Request $request)
   {
      return view('admin.help_desk.pan_view');
   }

   public function sendRequest(Request $request)
   {
      $validator = Validator::make($request->all(), [
         'pan_no' => 'required'
      ]);

      if ($validator->fails()) {
         return response()->json([
            'message' => 'Parameters missing',
            'missing_parameters' => $validator->errors()
         ], 400);
      }

      $pan_no = $request->input('pan_no');

      $panDetails = $this->getPanDetails($pan_no);

      if (isset($panDetails['error'])) {
         return response()->json(['error' => $panDetails['error']], 400);
      }

      return response()->json($panDetails, 200);
   }

   private function getPanDetails($pan_no)
   {
      // API endpoint URL
      $apiUrl = 'https://14.140.81.154/TIN/PanInquiryBackEnd';

      // Request data
      $requestData = [
         'data' => $pan_no
      ];

      // Path to your certificate file
      $certificatePath = storage_path('app/APEDA_DSC.pfx');


      $options = [
         'cert' => $certificatePath,
         'ssl_key' => $certificatePath,
         'pass' => '@@Apeda##2023#@!',
         'verify' => false, // Disable SSL verification temporarily (for testing)
      ];

      $client = new \GuzzleHttp\Client();

      try {
         $response = $client->post($apiUrl, [
            'form_params' => $requestData,
            'cert' => $options['cert'],
            'ssl_key' => $options['ssl_key'],
            'pass' => $options['pass'],
            'verify' => $options['verify']
         ]);

         $panDetails = $response->getBody()->getContents();

         return json_decode($panDetails, true);
      } catch (\Exception $e) {
         return ['error' => $e->getMessage()];
      }
   }



   public function ticketClose(Request $request)
   {
      // dd($request->all());

      $ticket = AtHelpDeskDetail::find($request->query_id);

      if ($ticket) {
         $ticket->status = $request->status; // Mark the ticket as closed
         $ticket->remarks = $request->close_remark; // Set the close remark field
         $ticket->save(); // Save the ticket

         return redirect()->back()->with('success', 'Ticket Closed successfully.');
      } else {
         return redirect()->back()->with('error', 'Ticket Not Closed successfully.');
      }
   }


   public function ticketIP(Request $request)
   {

      $userId = Auth::id();

      $query = AtHelpDeskDetail::where('at_user_id', $userId)->get();

      // dd($query);

      if ($request->ajax()) {


         $dataTable = DataTables::of($query)

            ->addIndexColumn()

            ->addColumn('ticket_no', function ($row) {
               return ($row->issue_id ?? '');
            })
            ->addColumn('issue_type', function ($row) {
               return getIssueTypeByID($row->ref_issue_type_id ?? '');
            })

            ->addColumn('sub_issue', function ($row) {
               return getSubIssueTypeByID($row->ref_sub_issue_type_id ?? '');
            })

            ->addColumn('status', function ($row) {
               return $row->status == 1 ? 'Open' : ($row->status == 2 ? 'Close' : '');
            })

            ->addColumn('ticket_date', function ($row) {
               return date('d-m-Y', strtotime($row->from_date ?? ''));
            })
            ->addColumn('action', function ($row) {

               if ($row->status == 1) {
                  $actionButton =  '<a href="' . route('superadmin.ticket', $row->id) . '"><span><i class="mdi mdi-eye-circle text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="view ticket"></i></span></a>';
               } else {
                  $actionButton =  $actionButton =  '<a href="' . route('superadmin.ticket', $row->id) . '"><span><i class="mdi mdi-eye-circle text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="view ticket"></i></span></a>';
               }
               return $actionButton;
            })

            ->rawColumns(['action']);

         return $dataTable->make(true);
      }

      return view('admin.help_desk.ip_ticket');
   }


   public function getHelpdesktickets(Request $request)
   {
      $su_admin = Auth::user()->ref_operator_type_id;
      // $all_cb_users_id = User::where('ref_operator_type_id', 1)->distinct()->pluck('id');
      // $query = AtHelpDeskDetail::whereIn('at_user_id', $all_cb_users_id)->orderBy('id', 'DESC')->get();

      //    $query = AtHelpDeskDetail::where('at_user_id', $userId)->get();  
      //    // $data =  AtHelpDeskDetail::whereIn('at_user_id', $all_cb_users_id)->get();
      //   dd($query);
      // dd($request->all());

      if ($request->operator_status != '' && $request->operator_status != 'all') {
         $query = AtHelpDeskDetail::orderBy('id', 'DESC')->where('status', $request->operator_status)->get();
      }else {
         $query = AtHelpDeskDetail::orderBy('id', 'DESC')->get();
      }
      if ($request->ajax()) {
         $dataTable = DataTables::of($query)
            ->addIndexColumn()
            ->addColumn('registration_number', function ($row) {
               return $row->registration_number ? $row->registration_number : ($row->registration_number ? $row->registration_number : '-');
            })
            ->addColumn('issue_related_to', function ($row) {
               return strtoupper($row->issue_related_to ?? '');
            })
            ->addColumn('at_user_id', function ($row) {
               $all_user = User::where('id', $row->at_user_id)->first();
               return $all_user->first_name ?? '';
            })
            ->addColumn('ref_issue_type_id', function ($row) {
               return getIssueTypeByID($row->ref_issue_type_id ?? '');
            })
            ->addColumn('ref_sub_issue_type_id', function ($row) {
               return getSubIssueTypeByID($row->ref_sub_issue_type_id ?? '');
            })
            ->addColumn('issue_id', function ($row) {
               return $row->issue_id ?? '';
            })
            ->addColumn('status', function ($row) {
               return getHelpstatusdata($row->status ?? '');
            })
            ->addColumn('from_date', function ($row) {
               return date('d-m-Y', strtotime($row->from_date ?? ''));
            })
            ->addColumn('action', function ($row) {
               if ($row->status == 2) {
                  $actionButton =  $actionButton =  '<a href="' . route('superadmin.ticket', $row->id) . '"><span><i class="mdi mdi-eye-circle text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="view ticket"></i></span></a>';
               } else {
                  $actionButton =  '<a href="' . route('superadmin.ticket', $row->id) . '"><span><i class="mdi mdi-eye-circle text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="view ticket"></i></span></a>
                   <a href="' . route('getSuperadmin.helpdesktickets.edit', $row->id) . '">
                     <span><i class="mdi mdi-pencil-circle text-muted fs-16 align-middle me-1 text-primary" data-toggle="tooltip" title="pencil ticket"></i></span>
                     </a>';
               }
               return $actionButton;
            })
            ->rawColumns(['action']);
         return $dataTable->make(true);
      }
      return view('admin.help_desk.apeda-help');
   }

   public function editHelpdesktickets($id)
   {
      $res = AtHelpDeskDetail::where('id', $id)->first();
      $user = User::where('id', Auth::user()->id)->first();
      return view('admin.help_desk.view-ticket', compact('res', 'user'));
   }


   // public function ticketClose(Request $request)
   // {
   //     // dd($request->all());

   //     $ticket = AtHelpDeskDetail::find($request->query_id);

   //     if ($ticket) {
   //         $ticket->status = 2; // Mark the ticket as closed
   //         $ticket->remarks = $request->close_remark; // Set the close remark field
   //         $ticket->save(); // Save the ticket

   //         // Redirect to the ticket list page with success message
   //         return redirect()->route('superadmin.ticketlist')->with('success', 'Ticket Closed successfully.');
   //     } else {
   //         // If ticket is not found, redirect back with error message
   //         return redirect()->route('superadmin.ticketlist')->with('error', 'Ticket Not Closed successfully.');
   //     }
   // }

   //--------------------pan api testing code-------------------//
}

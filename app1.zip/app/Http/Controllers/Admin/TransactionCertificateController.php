<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Permission;
use App\Models\Role;
use App\Models\RoleUser;
use App\Models\User;
use App\Models\AtClosingStock;
use App\Models\UserInspector;
use App\Models\UserWarehouse;
use App\Models\WildHarvesterForestProductDetail;
use App\Models\RefState;
use App\Models\RefDistrict;
use App\Models\RefVillage;
use App\Models\IndividualProducerFarmerDetail;
use App\Models\IndividualProducerFarmDetail;
use App\Models\AtFarmerRegDetail;
use App\Models\AtFarmDetails;
use App\Models\AtOrderAccepted;
use App\Models\WildHarvesterDetail;
use App\Models\IndividualProducerDetailOfStandingCorp;
use App\Models\AtOpTransactionVsTransactionProduct;
use App\Models\AtOpTransactionCertificateEntry;
use App\Models\AtOpTransactionProductSourced;
use App\Models\AtOpTransactionPackingDetails;
use Yajra\DataTables\DataTables;
use App\Models\AtFarmerStandingCorpDetail;
use App\Models\AtPurchaseDetails;
use App\Models\AtPurchaseRequest;
use App\Models\AtOrderDetailsReceivedFromBuyer;
use App\Models\RefPackingMaster;
use Exception;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;
use Illuminate\Support\Facades\DB;

class TransactionCertificateController extends Controller
{
	public function index(Request $request)
    {
        // $order_list = AtOrderAccepted::orderBy('created_at', 'asc')->get();
        // if ($request->ajax()) {
        //     return Datatables::of($order_list)
        //             ->addIndexColumn()
        //             ->editColumn('product', function ($row) {
		// 					return getbyOperatornameRegNo($row->at_user_id);
        //              })
		// 			 ->editColumn('status', function ($row) {
        //                 return user_name($row->at_user_id);
        //              })
		// 			  ->addColumn('tot_qty', function ($row) {
        //                 return getOperatorTypeById($row->ref_operator_type_id);
        //              })
		// 			 ->addColumn('qty_sourced', function ($row) {
        //                 return $row->quantity;
        //              })
        //              ->addColumn('qty_avail', function ($row) {
        //                 return Carbon::parse($row->created_at)->format('d/M/Y');
        //              })
        //             ->rawColumns(['action'])
        //             ->make(true);
        // }



        if ($request->ajax()) {
            if(Auth::user()->roles[0]->title == "Processor" || Auth::user()->roles[0]->title == "Trader"){
                $totalData =  AtPurchaseRequest::where('created_by',Auth::user()->id)->get();
            }else{
                $totalData =  AtPurchaseRequest::where('at_user_id',Auth::user()->id)->where('order_status',1)->get();
            }


            return Datatables::of($totalData)
                ->addIndexColumn()
                ->addColumn('user_name', function($row){
                    return user_name($row->at_user_id);
                })->addColumn('status', function($row){
                    return $row->status;
                })->addColumn('quantity', function($row){
                    return $row->quantity;
                })->addColumn('Commodity', function($row){
                    return getHscodeProductName($row->commodity) ?? '';
                })->addColumn('no_of_packages', function($row){
                    return $row->no_of_packages;
                })
                ->addColumn('order_status', function($row){
                    if($row->order_status==1){
                        $st = "Accepted";
                    }elseif($row->order_status==2){
                        $st = "Rejected";
                    }else{
                        $st = "Pending";
                    }
                    return $st;
                })->addColumn('action', function($row){
                    $actionBtn = '<a href="" class="btn btn-soft-primary"><span><i class="ri-shopping-bag-3-line" data-toggle="tooltip" title="Purchase Product"></i></span></a>';
                    if(Auth::user()->roles[0]->title == "Processor" || Auth::user()->roles[0]->title == "Trader"){

                    }else{
                        $actionBtn .= '<a href="'.route('superadmin.applyForDomesticTC',[$row->id]).'" class="btn btn-soft-primary ms-2"><span><i class="ri-file-edit-fill" data-toggle="tooltip" title="Apply for domestic TC" ></i></span></a>';
                    }
                    return $actionBtn;
                })
                ->rawColumns(['user_name','status','quantity','Commodity','no_of_packages','order_status','action'])
                ->make(true);
        }
        return view('admin.transaction_certificate.approved_purchase_list');
    }


	public function applyForDomesticTC($id = NULL)
	{

		$user_id = Auth::guard('misadmin')->user()->id;

        $operator_type_id = Auth::guard('misadmin')->user()->ref_operator_type_id;

        // $order_list2 = AtPurchaseRequest::select('at_purchase_request.*')
        // ->join('at_order_details_received_from_buyer as odrb','odrb.at_purchase_request_id','at_purchase_request.id')
		// ->join('at_order_accepted','at_order_accepted.at_order_details_received_from_buyer_id','odrb.id')
        // ->join('at_closing_stock','at_closing_stock.at_user_id','at_purchase_request.at_user_id')
        // ->join('at_farmer_standing_crop_details','at_farmer_standing_crop_details.id','at_closing_stock.at_farmer_standing_crop_details_id')
		// ->where('at_purchase_request.at_user_id',$user_id)
		// ->orderBy('at_purchase_request.created_at', 'asc')
		// ->get();

        $order_list2 = DB::select("select at_purchase_request.id, at_purchase_request.commodity, at_closing_stock.id as clsid,at_closing_stock.organic_status, at_closing_stock.closing_stock, at_purchase_request.quantity from at_purchase_request INNER join at_order_details_received_from_buyer as odrb on odrb.at_purchase_request_id = at_purchase_request.id inner join at_order_accepted on at_order_accepted.at_order_details_received_from_buyer_id = odrb.id inner join at_closing_stock on at_closing_stock.at_user_id = at_purchase_request.at_user_id and at_closing_stock.ref_product_id = at_purchase_request.commodity
        inner join at_farmer_standing_crop_details on at_farmer_standing_crop_details.id = at_closing_stock.at_farmer_standing_crop_details_id where at_purchase_request.at_user_id = $user_id and at_purchase_request.order_status = 1  group BY (at_purchase_request.commodity,at_purchase_request.id,at_closing_stock.organic_status,closing_stock,at_purchase_request.quantity,at_closing_stock.id)");

        $order=array();
        $j=0;

        foreach($order_list2 as $key => $vls){
            $order['purchase_list'][$key] = $vls;
            $purchases = AtPurchaseDetails::where('at_closing_stock_id',$vls->clsid)->get();
            $order['purchase_list'][$key]->mypurchase = $purchases;
        }

		$data = AtOpTransactionVsTransactionProduct::with('getTransProductSource')->where('created_by',Auth::guard('misadmin')->user()->id)->get();
		
		//dd($order);
		//dd($data);

       //$data= array();
        // here aaproved purchase req from trader/processor should be display here
		// $order_list = AtClosingStock::with('getPurchaseDetails')
		// ->when($operator_type_id == 2, function($q) {
		// 	$q->with('getFarmerStandingCorpDetail');
		// })
		/* ->when($operator_type_id == 3, function($q) {
			$q->with('IPDetailOfStandingCorp');
		})
		->when($operator_type_id == 4, function($q) {
			$q->with('getwhproducts');
		})	 */
		// ->where('at_user_id',$user_id)
		// ->orderBy('created_at', 'asc')
		// ->get();
		// pra($order_list);
		return view('admin.transaction_certificate.apply_for_domestic_tc',compact('order', 'data'));
	}




	public function storeApplyForDomesticTC(Request $request){

        $request->validate([
            //'transportation_date' => 'required',


        ]);
    //    dd($request->all());
        try {
			//dd($request->all());
			$operator_type_id = Auth::guard('misadmin')->user()->ref_operator_type_id;

			foreach ($request->lots as $key => $val) {

				if(!empty($request->lots[$key])){
					$data = array(
						'farm_no'   => $request->farm_no[$key],
						'total_qty'   => $request->total_qty[$key],
						'tc_date'   => date('Y-m-d'),
						'operator_type'   => $operator_type_id,
						'rem_qty'   => $request->rem_qty[$key],
                        'quantity_for_tc'   => $request->req_qty[$key],
						'product_code' =>$request->product_code[$key],
						'organic_status' =>$request->organic_status[$key],
						//'quantity_for_tc'   => $request->quantity_for_tc[$key],
						'created_by' => Auth::guard('misadmin')->user()->id,
						'updated_by' => Auth::guard('misadmin')->user()->id
					);

					$result = AtOpTransactionVsTransactionProduct::updateOrCreate([
						'id' => !empty($request->row_id[$key]) ? $request->row_id[$key] : NULL,
					], $data);

					if(!empty($result)){
						foreach ($request->pur_lots[$key]  as $k => $val1) {

							if(!empty($request->pur_lots[$key])){
								$data1 = array(
									'at_op_transaction_vs_transaction_product_id'   => $result->id,
									'ref_product_id'   => $request->ref_product_id[$key][$k],
									'at_closing_stock_id'   => $request->at_closing_stock_id[$key][$k],
									'at_purchase_details_id'   => $request->at_purchase_details_id[$key][$k],
									// 'product_code' =>'',
									'organic_status' =>$request->op_organic_status[$key][$k],
								    'qty_in_mt' =>$request->qty_in_mt[$key][$k],
									'source_date'   => date('Y-m-d'),
									'created_by' => Auth::guard('misadmin')->user()->id,
									'updated_by' => Auth::guard('misadmin')->user()->id
								);
								$result1 = AtOpTransactionProductSourced::updateOrCreate([
									'id'   => $request->rows_id[$key][$k],
								],$data1);
							}
						}

						if(!empty($result1->id)){
							Alert::success('Success', __('message.add_success'));
							return redirect()->route('superadmin.packingDetailTC',[$result->id]);
						}else{
							Alert::success('Success','Something went wrong.');
							return redirect()->back();
						}
					}
				}
			}

        } catch (Exception $e) {

            Log::error($e->getMessage());
            abort('404');
        }
    }


	public function packingDetailTC($id){
        $trans = AtOpTransactionVsTransactionProduct::with('getTransProductSource')->where('id',$id)->get();
		//dd($trans);
		// packing master list get
        $packs = RefPackingMaster::get();
		//AtOpTransactionPackingDetails::where(['product_code'=>$trans[0]->ref_product_id,'crested_by',Auth::guard('misadmin')->user()->id])->get();
        //dd($packDet);

        return view('admin.transaction_certificate.packing_detail_tc',compact('trans','packs'));
    }


    public function storePackingDetailTC(Request $request){

        $request->validate([
            'value_inr' => 'required',
            'trade_name_of_product' => 'required',
            'ref_packing_master_id.*' => 'required',
            'no_of_box.*' => 'required',
            'pack_size.*' => 'required',
            'total_qty_in_kg.*' => 'required',
        ]);
		// if(!empty($validator->fails())) {
		// 	return Redirect::back()->withErrors($validator);
		// }
        try {
			//dd($request->all());
			$operator_type_id = Auth::guard('misadmin')->user()->ref_operator_type_id;
			$edtVal = 0;
			if(!empty($request->at_op_transaction_product_sourced_id)){
				foreach ($request->at_op_transaction_product_sourced_id as $key => $val) {

					if(!empty($request->at_op_transaction_product_sourced_id[$key])){
						$data = array(
							'at_op_transaction_product_sourced_id'   => $request->at_op_transaction_product_sourced_id[$key],
							'ref_product_id'   => $request->ref_product_id,
							'ref_packing_master_id'   => $request->ref_packing_master_id[$key],
							'no_of_box'   => $request->no_of_box[$key],
							'pack_size'   => $request->pack_size[$key],
							'total_qty_in_kg'   => $request->total_qty_in_kg[$key],
							'created_by' => Auth::guard('misadmin')->user()->id,
							'updated_by' => Auth::guard('misadmin')->user()->id
						);

						$result = AtOpTransactionPackingDetails::updateOrCreate([
							'id' => $request->row_id[$key],
						],$data);

					}
				}

				if(!empty($result)){
					$updateData= array(
						'value_inr'=>$request->value_inr,
						'trade_name_of_product'=>$request->trade_name_of_product,
					);
					$res = AtOpTransactionVsTransactionProduct::where('id',$request->trans_id)->update($updateData);

					//if(isset($request->row_id[0]) && $request->row_id[0]!=''){
						Alert::success('Success', __('message.add_success'));
						return redirect()->route('superadmin.TcDetail',$request->trans_id);
					// }else{
					// 	Alert::success('Success', __('message.add_success'));
					// 	return redirect()->back();
					// }

				}
			}

        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

	public function TcDetail($id){

		$data =  AtOpTransactionCertificateEntry::where('at_op_transaction_vs_transaction_product_id',$id)->first();
		//dd($data);
        return view('admin.transaction_certificate.tc_details',compact('id','data'));
    }


	// public function storeTcDetail(Request $request)
	// {
		
    //     $request->validate([
    //         'invoice_no' => 'required',
    //         'invoice_date' => 'required',
    //         'invoice_value' => 'required',
    //         //'place_of_dispatch' => 'required',
    //         'lot_number' => 'required',
    //         'place_of_destination' => 'required',
    //         'marks_no' => 'required',
    //         'reference_no' => 'required',
    //     ]);
		
    //     try {
			

	// 		/// Date of Transport
	// 		if(!empty($request->road_transport_date)){
	// 			$transport_date = date('Y-m-d H:i:s',strtotime($request->road_transport_date));
	// 		}elseif(!empty($request->train_transport_date)){
	// 			$transport_date = date('Y-m-d H:i:s',strtotime($request->train_transport_date));
	// 		}else{
	// 			$transport_date = null;
	// 		}
			

	// 		// dd(date('Y-m-d H:i:s',strtotime($request->invoice_date[0])));
	// 		$data = array(
	// 			'exporter_seller_name'   => $request->exporter_seller_name ?? null,
	// 			'seller_email'   => $request->seller_email ?? null,
	// 			'seller_at_op_certificate_standard_details_id'   => $request->seller_at_op_certificate_standard_details_id ?? null,
	// 			'exporter_seller_address'   => $request->exporter_seller_address ?? null,
	// 			'buyer_id_proof'   => $request->buyer_id_proof ?? null,
	// 			'buyer_name'   => $request->buyer_name ?? null,
	// 			'buyer_address'   => $request->buyer_address ?? null,
	// 			'buyer_at_op_certificate_standard_details_id'   => $request->buyer_at_op_certificate_standard_details_id ?? null,
	// 			'buyer_ref_state_id'   => $request->buyer_ref_state_id ?? null,
	// 			'buyer_email'   => $request->buyer_email ?? null,
	// 			'invoice_no'   => $request->invoice_no[0] ?? null,
	// 			'invoice_date'   => date('Y-m-d H:i:s',strtotime($request->invoice_date[0])) ?? null,
	// 			'invoice_value'   => $request->invoice_value ?? null,
	// 			//'place_of_dispatch'   => $request->place_of_dispatch ?? null,
	// 			'place_of_destination'   => $request->place_of_destination ?? null,
	// 			'marks_no'   => $request->marks_no ?? null,
	// 			'reference_no'   => $request->reference_no ?? null,
	// 			'transport_mode'   => $request->transport_mode ?? null,

	// 			'container_no_road'   => $request->container_no_road ?? null,
    //             'transport_doc_no'   => $request->transport_doc_no ?? null,
	// 			'transport_date'   => $transport_date ?? null,

	// 			'train_no'   => $request->train_no ?? null,
	// 			'wagon_no'   => $request->wagon_no ?? null,
	// 			'train_transport_date'   => date('Y-m-d H:i:s',strtotime($request->train_transport_date)) ?? null,

	// 			'flight_no'   => $request->flight_no ?? null,
	// 			'flight_date'   => date('Y-m-d H:i:s',strtotime($request->flight_date)) ?? null,
	// 			'airway_bill_no'   => $request->airway_bill_no ?? null,
	// 			'airway_bill_date'   => date('Y-m-d H:i:s',strtotime($request->airway_bill_date)) ?? null,
	// 			'container_no_air'   => $request->container_no_air ?? null,


	// 			'ship_no'   => $request->ship_no ?? null,
	// 			'ship_name'   => $request->ship_name ?? null,
	// 			'vessel_date'   => $request->vessel_date ?? null,
	// 			'bill_of_lading'   => $request->bill_of_lading ?? null,
	// 			'date_of_lading'   => $request->date_of_lading ?? null,
	// 			'container_no_ship'   => $request->container_no_ship ?? null,

	// 			'gross_weight'   => $request->gross_weight ?? null,
	// 			'created_by' => Auth::guard('misadmin')->user()->id,
	// 			'updated_by' => Auth::guard('misadmin')->user()->id,
	// 			'at_op_transaction_vs_transaction_product_id'=>$request->at_op_transaction_vs_transaction_product_id,
	// 			'lot_number'=>$request->lot_number,
	// 		);
	// 		//dd($data);
	// 		$saveData = AtOpTransactionCertificateEntry::updateOrCreate(['at_op_transaction_vs_transaction_product_id'=>$request->at_op_transaction_vs_transaction_product_id],$data);
			
	// 		if($saveData){
	// 			Alert::success('Success', __('message.add_success'));
	// 			return redirect()->route('superadmin.forwardToCB',$request->at_op_transaction_vs_transaction_product_id);
				
	// 		}
			
	// 	} catch (Exception $e) {
			
    //         Log::error($e->getMessage());
    //         abort('404');
    //     }
    // }

	public function storeTcDetail(Request $request)
{
    // Validate the incoming request
    $request->validate([
        'invoice_no' => 'required',
        'invoice_date' => 'required|date',
        'invoice_value' => 'required|numeric',
        'lot_number' => 'required',
        'place_of_destination' => 'required',
        'marks_no' => 'required',
        'reference_no' => 'required',
    ]);

    try {
        // Set transport date based on the provided transport dates
        $transport_date = null;

        if (!empty($request->road_transport_date)) {
            $transport_date = date('Y-m-d H:i:s', strtotime($request->road_transport_date));
        } elseif (!empty($request->train_transport_date)) {
            $transport_date = date('Y-m-d H:i:s', strtotime($request->train_transport_date));
        } elseif (!empty($request->airway_bill_date)) {
            $transport_date = date('Y-m-d H:i:s', strtotime($request->airway_bill_date));
        }

        // Prepare data for saving or updating
        $data = [
            'exporter_seller_name' => $request->exporter_seller_name ?? null,
            'seller_email' => $request->seller_email ?? null,
            'seller_at_op_certificate_standard_details_id' => $request->seller_at_op_certificate_standard_details_id ?? null,
            'exporter_seller_address' => $request->exporter_seller_address ?? null,
            'buyer_id_proof' => $request->buyer_id_proof ?? null,
            'buyer_name' => $request->buyer_name ?? null,
            'buyer_address' => $request->buyer_address ?? null,
            'buyer_at_op_certificate_standard_details_id' => $request->buyer_at_op_certificate_standard_details_id ?? null,
            'buyer_ref_state_id' => $request->buyer_ref_state_id ?? null,
            'buyer_email' => $request->buyer_email ?? null,
            'invoice_no' => $request->invoice_no[0] ?? null,
            'invoice_date' => isset($request->invoice_date[0]) ? date('Y-m-d H:i:s', strtotime($request->invoice_date[0])) : null,
            'invoice_value' => $request->invoice_value ?? null,
            'place_of_destination' => $request->place_of_destination ?? null,
            'marks_no' => $request->marks_no ?? null,
            'reference_no' => $request->reference_no ?? null,
            'transport_mode' => $request->transport_mode ?? null,
            'container_no_road' => $request->container_no_road ?? null,
            'transport_doc_no' => $request->transport_doc_no ?? null,
            'transport_date' => $transport_date,
            'train_no' => $request->train_no ?? null,
            'wagon_no' => $request->wagon_no ?? null,
            'train_transport_date' => isset($request->train_transport_date) ? date('Y-m-d H:i:s', strtotime($request->train_transport_date)) : null,
            'flight_no' => $request->flight_no ?? null,
            'flight_date' => isset($request->flight_date) ? date('Y-m-d H:i:s', strtotime($request->flight_date)) : null,
            'airway_bill_no' => $request->airway_bill_no ?? null,
            'airway_bill_date' => isset($request->airway_bill_date) ? date('Y-m-d H:i:s', strtotime($request->airway_bill_date)) : null,
            'container_no_air' => $request->container_no_air ?? null,
            'ship_no' => $request->ship_no ?? null,
            'ship_name' => $request->ship_name ?? null,
            'vessel_date' => $request->vessel_date ?? null,
            'bill_of_lading' => $request->bill_of_lading ?? null,
            'date_of_lading' => $request->date_of_lading ?? null,
            'container_no_ship' => $request->container_no_ship ?? null,
            'gross_weight' => $request->gross_weight ?? null,
            'created_by' => Auth::guard('misadmin')->user()->id,
            'updated_by' => Auth::guard('misadmin')->user()->id,
            'at_op_transaction_vs_transaction_product_id' => $request->at_op_transaction_vs_transaction_product_id,
            'lot_number' => $request->lot_number,
        ];

        // Save or update the record
        $saveData = AtOpTransactionCertificateEntry::updateOrCreate(
            ['at_op_transaction_vs_transaction_product_id' => $request->at_op_transaction_vs_transaction_product_id],
            $data
        );

		//dd($saveData);
        // Check if the save was successful
        if ($saveData) {
            Alert::success('Success', __('message.add_success'));
            return redirect()->route('superadmin.forwardToCB', $request->at_op_transaction_vs_transaction_product_id);
        }

    } catch (Exception $e) {
        // Log the error and abort with a 404
        Log::error($e->getMessage());
        abort(404);
    }
}


	public function forwardToCB($id){

        return view('admin.transaction_certificate.forwardToCB',compact('id'));
    }

	public function viewTCApplication($id){

	    $trans = AtOpTransactionVsTransactionProduct::with('getTransProductSource')->where('id',$id)->get();
        //dd($trans);
		$data =  AtOpTransactionCertificateEntry::where('at_op_transaction_vs_transaction_product_id',$id)->first();
		$packDet =  AtOpTransactionPackingDetails::where('at_op_transaction_product_sourced_id',$id)->get();
		
        return view('admin.transaction_certificate.viewApplication',compact('id','trans','data'));
    }

	public function postForwardToCB(Request $request){
        //dd($request->all());
		try {
			$data = AtOpTransactionVsTransactionProduct::select('created_at','id')->where('id',$request->row_id)->first();
			if($data){
				$m = date('m',strtotime($data->created_at));
				$y = date('y',strtotime($data->created_at));
				$lst = str_pad($data->id, 4, "0", STR_PAD_LEFT);
				$app_no = "TC-".$y.$m.$lst;

			}
			$upData = array(
				'tc_application_no'=>$app_no,
				'tc_date'=>date('Y-m-d'),
				'nop_status'=>'Pending',
			);

			$res = AtOpTransactionVsTransactionProduct::where('id',$request->row_id)->update($upData);

            if($res > 0){
				Alert::success('Success', __('message.add_success'));
				return redirect()->route('superadmin.listOfTransCertificate');
			}else{
				Alert::error('', 'Something went Wrong.');
				return redirect()->back();
			}


		} catch (Exception $e) {
			//dd($e->getMessage());
			Log::error($e->getMessage());
			abort('404');
		}
    }

	public function listOfTransCertificate(Request $request){

        $id = Auth::guard('misadmin')->user()->id;
		if ($request->ajax()) {
			$totalData = AtOpTransactionVsTransactionProduct::where('created_by',$id)->orderBy('id','DESC')->get();
            return Datatables::of($totalData)
                ->addIndexColumn()
                ->addColumn('tc_application_no', function($row){
                    return$row->tc_application_no;
                })->addColumn('tc_date', function($row){
                    return date('d-m-Y', strtotime($row->tc_date));
                })->addColumn('seller', function($row){
                    return $row->quantity;
                })->addColumn('buyer', function($row){
                    return getHscodeProductName($row->commodity) ?? '';
                })->addColumn('country', function($row){
                    return 'INDIA';
                })->addColumn('status', function($row){
                   return  $row->nop_status ?? '';
                })->addColumn('tc_type', function($row){
					return  'Domestic';
				})->addColumn('action', function($row){

                    $actionBtn= '<a href="'.route('superadmin.viewTCApplication',[$row->id]).'" class="btn btn-soft-primary ms-2"><span><i class="ri-file-edit-fill" data-toggle="tooltip" title="Apply for domestic TC" ></i></span></a>';

                    return $actionBtn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        return view('admin.transaction_certificate.listOfTransCertificate');

	}

}





<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Permission;
use App\Models\Role;
use App\Models\User;
use App\Models\RefState;
use App\Models\RefDistrict;
use App\Models\RefVillage;
use App\Models\RefRegion;
use App\Models\RoleUser;
use App\Models\UserInspector;
use App\Models\IcsMandator;

use App\Models\AtProudctUse;
use App\Models\AtInputApprovalInspectionDetail;
use App\Models\AtInputApprovalInspectionMaster;
use App\Models\AtInputApprovalProductIngredientDetail;
use App\Models\AtInputApprovalProductBatchDetail;
use App\Models\AtInputApprovalProductDetail;
use App\Models\AtInputApprovalProudctMode;
use App\Models\AtInputProductCategory;
use App\Models\AtInputProductSubCategory;
use App\Models\AtInputApprovalRegDetail;
use App\Models\AtInputApprovalUnitRegDetail;
use DataTables;
use RealRashid\SweetAlert\Facades\Alert;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use PDF;

class InputApprovalController extends Controller
{
    //
	public function registrationList(Request $request)
	{
		$list=AtInputApprovalUnitRegDetail::with('getCompanyList')->get();

        if ($request->ajax()) {

             return Datatables::of($list)
                    ->addIndexColumn()
                    ->addColumn('action', function($row){
						$btn = '<a href="'.route("superadmin.addProduct",[$row->id,'']).'">Add Product</a>';

                        return $btn;
                    })
					->editColumn('company_name', function ($row) {
						if(!empty($row->getCompanyList))
						{
							return $row->getCompanyList->company_name;
						}else{
							return '';
						}
                     })
					 ->editColumn('unit_name', function ($row) {
                        return $row->unit_name;
                     })
					  ->addColumn('unit_reg_no', function ($row) {
                        return $row->unit_reg_number;
                     })
					 ->addColumn('unit_address', function ($row) {
                        return $row->address;
                     })
					  ->addColumn('unit_city', function ($row) {
                        return $row->city ?? '';
                     })
					  ->addColumn('unit_state', function ($row) {
                        return get_state_name($row->ref_state_id);
                     })


                    ->rawColumns(['action'])
                    ->make(true);
        }
		 return view('admin.inputapproval.registration_list',compact('list'));
	}
    public function newRegistration()
    {

        return view('admin.inputapproval.registration');

    }

	public function storeNewRegistration(Request $request)
	{

		$request->validate([
			'registration_date' => 'required',
            'company_name' => 'required',
            'address' => 'required',
            'ref_state_id' => 'required',
            'ref_district_id' => 'required',
            'ref_block_tehsil_id' => 'required',
            'pincode' => 'required',
            'producer_name' => 'required',
            'phone' => 'required',
            'pan_number' => 'required',
            'email_id' => 'required',
            'mobile' => 'required',
            'validity_start_from' => 'required',
            'validity_end' => 'required',
            'unit_registration.*.unit_name' => 'required',
            'unit_registration.*.license_no' => 'required',

        ]);
		 try {


			 $insertData = array(
				'registration_date' => \Carbon\Carbon::createFromFormat('d/m/Y', $request->registration_date)->format('Y-m-d'),
				'company_name' => $request->company_name,
				'address' => $request->address,
				'ref_state_id' => $request->ref_state_id,
				'ref_district_id' => $request->ref_district_id,
				'ref_block_tehsil_id' => $request->ref_block_tehsil_id,
				'pincode' => $request->pincode,
				'producer_name' => $request->producer_name,
				'phone' => $request->phone,
				'pan_number' => $request->pan_number,
				'email_id' => $request->email_id,
				'mobile' => $request->mobile,
				'validity_start_from' => $request->validity_start_from,
				'validity_end' => $request->validity_end,
				'created_at' => date('Y-m-d H:i:s'),
				'created_by' => Auth::guard('misadmin')->user()->id,

			 );

			 $input_approval = AtInputApprovalRegDetail::create($insertData);
			 $registration_no =  'IA-'.date('Y').'-'.str_pad($input_approval->id,5,"0",STR_PAD_LEFT);
			 AtInputApprovalRegDetail::where('id',$input_approval->id)->update(['registration_no' => $registration_no]);
			 if(!empty($request->unit_registration))
			 {
				 foreach($request->unit_registration as $key=> $value)
				 {

					  $insertUnitData = array(
							'at_input_approval_reg_details_id' => $input_approval->id,
							'unit_reg_number' => $registration_no.'-'.$key+1,
							'unit_name' => $value['unit_name'],
							'license_no' => $value['license_no'],
							'license_validity_upto' => $value['license_validity_upto'],
							'additional_certification' => implode(',',$value['additional_certification']),
							'installed_capacity' => $value['installed_capacity'],
							'estimated_production_in_mt' => $value['estimated_production_in_mt'],
							'address' => $value['address'],
							'city' => $value['ref_district_id'],
							'ref_state_id' => $value['ref_state_id'],
							'created_at' => date('Y-m-d H:i:s'),
							'created_by' => Auth::guard('misadmin')->user()->id,
						 );
						 AtInputApprovalUnitRegDetail::create($insertUnitData);
				 }
			 }

			Alert::success('Success', 'New registration-input Approval inserted successfully');
			return redirect()->route('superadmin.registrationList')->with('loader',true);

		} catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
	}


	public function productList(Request $request)
	{
		$list=AtInputApprovalProductDetail::with('getUnitsDetails')->get();

        if ($request->ajax()) {

             return Datatables::of($list)
                    ->addIndexColumn()
                    ->addColumn('action', function($row){
						$btn = '<a href="'.route("superadmin.addBatch",$row->id).'">View Batch Details</a> |
						<a href="'.route("superadmin.addIngredients",$row->id).'">Add Ingrediants</a> | <a href="'.route("superadmin.addProduct",[$row->id,'']).'">Delete</a>';

                        return $btn;
                    })
					->editColumn('unit_name', function ($row) {
						return $row->getUnitsDetails->unit_name;
                     })
					 ->editColumn('unit_reg_no', function ($row) {
						return $row->getUnitsDetails->unit_reg_number;
                     })
					->editColumn('category_name', function ($row) {
						return get_product_cat_name($row->at_input_product_category_id);
                     })

					 ->editColumn('sub_category_name', function ($row) {
                        return get_product_subcat_name($row->at_input_sub_product_category_id);
                     })
					  ->addColumn('brand_name', function ($row) {
                        return ucfirst($row->product_name);
                     })


                    ->rawColumns(['action'])
                    ->make(true);
        }
		 return view('admin.inputapproval.product_list',compact('list'));
	}

	public function addProduct(Request $request,$unit_id,$renew=NULL)
	{
		$result = AtInputApprovalUnitRegDetail::join('at_input_approval_reg_details','at_input_approval_reg_details.id','at_input_approval_unit_reg_details.at_input_approval_reg_details_id')
				->where('at_input_approval_unit_reg_details.id',$unit_id)->first();

		$categories = AtInputProductCategory::get();
		$product_modes = AtInputApprovalProudctMode::get();
		$use_of_products = AtProudctUse::get();
		return view('admin.inputapproval.add_product',compact('result','categories','product_modes','unit_id','renew','use_of_products'));
	}

	public function getSubcategory(Request $request)
	{
		$categories = AtInputProductSubCategory::where('at_input_product_category_id',$request->cat_id)->get();
		return json_encode(['data' => $categories]);
	}

	public function storeProduct(Request $request)
	{
		//pr($request->all());
		$request->validate([
			'unit_id' => 'required',
            'reg_id' => 'required',
            'at_input_product_category_id' => 'required',
            'at_input_sub_product_category_id' => 'required',
            'product_name' => 'required',
            'self_life' => 'required',
           // 'at_proudct_use_id' => 'required',
            'at_input_approval_proudct_mode_id' => 'required',
            'product_desc' => 'required',
        ]);
		try {

			 $insertData = array(
				'at_input_approval_reg_details_id' =>  $request->reg_id,
				'at_input_approval_unit_reg_detail_id' => $request->unit_id,
				'at_input_product_category_id' => $request->at_input_product_category_id,
				'at_input_sub_product_category_id' => $request->at_input_sub_product_category_id,
				'product_name' => $request->product_name,
				'self_life' => $request->self_life,
				'at_proudct_use_id' => $request->at_proudct_use_id ?? NULL,
				'at_input_approval_proudct_mode_id' => $request->at_input_approval_proudct_mode_id,
				'product_desc' => $request->product_desc,
				'created_at' => date('Y-m-d H:i:s'),
				'created_by' => Auth::guard('misadmin')->user()->id,

			 );
			 $input_approval = AtInputApprovalProductDetail::create($insertData);

			 Alert::success('Success', 'Product inserted successfully');
			 if($request->renew == 'renew')
			 {
				 return redirect()->route('superadmin.applicationRenewalProcess',$request->reg_id)->with('loader',true);
			 }else{
				return redirect()->route('superadmin.productList')->with('loader',true);
			 }

		} catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
	}

	public function deleteProduct(Request $request)
	{
		AtInputApprovalProductDetail::where('id',$request->id)->delete();
    	return 1;
	}



	// Add Batch start
	public function addBatch(Request $request,$id)
	{
		$result = AtInputApprovalProductDetail::with('getUnitsDetails','getRegistrationDetails')
				->where('id',$id)->first();
		 $batch_list = AtInputApprovalProductBatchDetail::get();
		return view('admin.inputapproval.add_batch',compact('result','id','batch_list'));
	}

	public function addEditbatch(Request $request)
	{
		$batch_detail = '';
		$result = AtInputApprovalProductDetail::with('getUnitsDetails','getRegistrationDetails')
				->where('at_input_approval_reg_details_id',$request->reg_id)
				->where('at_input_approval_unit_reg_detail_id',$request->unit_id)
				->first();
		if(!empty($request->batch_id))
		{
			$batch_detail = AtInputApprovalProductBatchDetail::where('id',$request->batch_id)->first();
		}

		return  view('admin.inputapproval.tpl_add_batch',compact('result','batch_detail'))->render();
	}

	public function storeBatch(Request $request)
	{
		$validator = \Validator::make($request->all(), [
           'at_input_approval_unit_reg_detail_id' => 'required',
            'at_input_approval_reg_details_id' => 'required',
			'product_name' => 'required',
            'batch_no' => 'required',
            'batch_date' => 'required',
            'batch_qty_mt' => 'required',
        ]);

        if ($validator->fails())
        {
            return response()->json(['errors'=>$validator->errors()->all()]);
        }

		try {

			 $insertData = array(
				'at_input_approval_reg_details_id' =>  $request->at_input_approval_reg_details_id,
				'at_input_approval_unit_reg_detail_id' => $request->at_input_approval_unit_reg_detail_id,
				'at_input_product_category_id' => $request->at_input_product_category_id,
				'at_input_sub_product_category_id' => $request->at_input_sub_product_category_id,
				'product_name' => $request->product_name,
				'batch_no' => $request->batch_no,
				'batch_date' => $request->batch_date,
				'batch_qty_mt' => $request->batch_qty_mt,
				'product_id' => $request->product_id,


			 );
			 if(empty($request->batch_id))
			 {
				 $insertData['created_at'] = date('Y-m-d H:i:s');
				 $insertData['created_by'] = Auth::guard('misadmin')->user()->id;
				$input_approval = AtInputApprovalProductBatchDetail::create($insertData);
			 }else{
				 $insertData['updated_at'] = date('Y-m-d H:i:s');
				 $insertData['updated_by'] = Auth::guard('misadmin')->user()->id;
				  AtInputApprovalProductBatchDetail::where('id',$request->batch_id)->update($insertData);
				 $input_approval = AtInputApprovalProductBatchDetail::where('id',$request->batch_id)->first();
			 }

			 $data_html = '<tr id="row_'.$input_approval->id.'">
					<td>'.$input_approval->batch_no.'</td>
					<td>'.$input_approval->batch_date.'</td>
					<td>'.$input_approval->batch_qty_mt.'</td>
					<td><a href="javascript:void(0);" class="deletedata" data-value="'.$input_approval->id.'" data-href="'.route('superadmin.deleteBatch',$input_approval->id).'">Delete</a>
					| <a href="javascript:void(0)" onclick="showAddBatch('.$input_approval->id.')">Edit</a>
					</td>
				</tr>';

			return response()->json(['data'=>$data_html,'success'=>'Data is successfully added']);

		} catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
	}


	public function deleteBatch(Request $request)
	{
		AtInputApprovalProductBatchDetail::where('id',$request->id)->delete();
    	return 1;
	}


	// ADD ingredients

	public function addIngredients(Request $request,$id)
	{
		$result = AtInputApprovalProductDetail::with('getUnitsDetails','getRegistrationDetails')
				->where('id',$id)->first();
		 $batch_list = AtInputApprovalProductIngredientDetail::get();
		return view('admin.inputapproval.add_ingredients',compact('result','id','batch_list'));
	}

	public function addEditIngredients(Request $request)
	{
		$batch_detail = '';
		$result = AtInputApprovalProductDetail::with('getUnitsDetails','getRegistrationDetails')
				->where('at_input_approval_reg_details_id',$request->reg_id)
				->where('at_input_approval_unit_reg_detail_id',$request->unit_id)
				->first();
		if(!empty($request->ingredient_id))
		{
			$batch_detail = AtInputApprovalProductIngredientDetail::where('id',$request->ingredient_id)->first();
		}

		return  view('admin.inputapproval.tpl_add_ingredients',compact('result','batch_detail'))->render();
	}

	public function storeIngredients(Request $request)
	{
		$validator = \Validator::make($request->all(), [
           'at_input_approval_unit_reg_detail_id' => 'required',
            'at_input_approval_reg_details_id' => 'required',
            'ingredient_name' => 'required',
            'percentage' => 'required',
        ]);

        if ($validator->fails())
        {
            return response()->json(['errors'=>$validator->errors()->all()]);
        }

		try {

			 $insertData = array(
				'at_input_approval_reg_details_id' =>  $request->at_input_approval_reg_details_id,
				'at_input_approval_unit_reg_detail_id' => $request->at_input_approval_unit_reg_detail_id,
				'at_input_product_category_id' => $request->at_input_product_category_id,
				'at_input_sub_product_category_id' => $request->at_input_sub_product_category_id,
				'ingredient_name' => $request->ingredient_name,
				'percentage' => $request->percentage,
				'product_id' => $request->product_id,

			 );
			 if(empty($request->ingredient_id))
			 {
				 $insertData['created_at'] = date('Y-m-d H:i:s');
				 $insertData['created_by'] = Auth::guard('misadmin')->user()->id;
				$input_approval = AtInputApprovalProductIngredientDetail::create($insertData);
			 }else{
				 $insertData['updated_at'] = date('Y-m-d H:i:s');
				 $insertData['updated_by'] = Auth::guard('misadmin')->user()->id;
				  AtInputApprovalProductIngredientDetail::where('id',$request->ingredient_id)->update($insertData);
				 $input_approval = AtInputApprovalProductIngredientDetail::where('id',$request->ingredient_id)->first();
			 }

			 $data_html = '<tr id="row_'.$input_approval->id.'">
					<td>'.$input_approval->ingredient_name.'</td>
					<td>'.$input_approval->percentage.'</td>
					<td><a href="javascript:void(0);" class="deletedata" data-value="'.$input_approval->id.'" data-href="'.route('superadmin.deleteBatch',$input_approval->id).'">Delete</a>
					| <a href="javascript:void(0)" onclick="showAddBatch('.$input_approval->id.')">Edit</a>
					</td>
				</tr>';

			return response()->json(['data'=>$data_html,'success'=>'Data is successfully added']);

		} catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
	}


	public function deleteIngredients(Request $request)
	{
		AtInputApprovalProductIngredientDetail::where('id',$request->id)->delete();
    	return 1;
	}



	public function applicationInspectionList(Request $request)
	{
		$list=AtInputApprovalRegDetail::get();

        if ($request->ajax()) {

             return Datatables::of($list)
                    ->addIndexColumn()
                    ->addColumn('action', function($row){
						$btn = '<a href="'.route("superadmin.newInspection",$row->id).'">Add Inspection</a>'
								.'<br/><a href="'.route("superadmin.viewInspection",$row->id).'">Edit/View Inspection</a>';

                        return $btn;
                    })
					  ->addColumn('registration_no', function ($row) {
                        return $row->registration_no;
                     })
					->editColumn('company_name', function ($row) {
							return $row->company_name;
                     })
					 ->editColumn('unit_name', function ($row) {
                        return $row->unit_name;
                     })

					 ->addColumn('address', function ($row) {
                        return $row->address.'<br>City: '.getDistrictID($row->ref_district_id)->district_name.'<br>State: '.get_state_name($row->ref_state_id).'<br>Pincode: '.$row->pincode;
                     })
					  ->addColumn('validity_end', function ($row) {
                        return date('d/m/Y', strtotime($row->validity_end)) ?? '';
                     })

                    ->rawColumns(['action','address'])
                    ->make(true);
        }
		 return view('admin.inputapproval.application_inspection_list',compact('list'));
	}


	public function newInspection(Request $request,$id)
	{
		$data = AtInputApprovalRegDetail::where('id',$id)->first();
		return view('admin.inputapproval.add_inspection',compact('data','id'));
	}

	public function storeNewInspection(Request $request,$id)
	{
		$request->validate([
			'registration_no' => 'required',
            'company_name' => 'required',
            'area_dept' => 'required',
            'auditor_name' => 'required',
            'ins_from_date' => 'required',
            'ins_to_date' => 'required',
            'observations' => 'required',
            'unit_registration.*.grade' => 'required',
            'unit_registration.*.dead_line_date' => 'required',
        ]);
		 try {

			 $insertData = array(
				'registration_no' => $request->registration_no,
				'registration_id' => $id,
				'ins_from_date' => \Carbon\Carbon::createFromFormat('Y-m-d', $request->ins_from_date)->format('Y-m-d'),
				'ins_to_date' => \Carbon\Carbon::createFromFormat('Y-m-d', $request->ins_to_date)->format('Y-m-d'),
				'area_dept' => $request->area_dept,
				'observations' => $request->observations,
				'auditor_name' => $request->auditor_name,
				'created_at' => date('Y-m-d H:i:s'),
				'created_by' => Auth::guard('misadmin')->user()->id,
			 );

			 $input_approval = AtInputApprovalInspectionMaster::create($insertData);

			 $registration_no =  date('Y').date('m').date('d').'-'.str_pad($input_approval->id,5,"0",STR_PAD_LEFT);
			 AtInputApprovalInspectionMaster::where('id',$input_approval->id)->update(['inspection_no' => $registration_no]);

			 if(!empty($request->unit_registration))
			 {
				 foreach($request->unit_registration as $key=> $value)
				 {
					  $insertUnitData = array(
							'at_input_approval_reg_details_id' => $id,
							'at_input_approval_inspection_master_id' => $input_approval->id,
							'grade' => $value['grade'],
							'description' => $value['description'],
							'dead_line_date' => $value['dead_line_date'],
							'created_at' => date('Y-m-d H:i:s'),
							'created_by' => Auth::guard('misadmin')->user()->id,
						 );
						 AtInputApprovalInspectionDetail::create($insertUnitData);
				 }
			 }

			Alert::success('Success', 'New Application inspection inserted successfully');
			return redirect()->route('superadmin.applicationInspectionList')->with('loader',true);
		} catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
	}


	public function viewInspection(Request $request,$id)
	{
		$data = AtInputApprovalRegDetail::with('getInspectionMaster')->where('id',$id)->first();
		return view('admin.inputapproval.view_inspection',compact('data','id'));
	}


	public function viewInspectionClosure(Request $request,$id,$master_id)
	{
		$data = AtInputApprovalRegDetail::with(['getInspectionMaster' => function ($query) use ($id,$master_id) {
				$query->where('registration_id', $id)
				->where('id', $master_id);
		}])
		->where('id',$id)->first();
		return view('admin.inputapproval.view_inspection_closure',compact('data','id'));
	}


	public function applicationGenerateCertificateList(Request $request)
	{
		$list=AtInputApprovalRegDetail::get();

        if ($request->ajax()) {

             return Datatables::of($list)
                    ->addIndexColumn()
                    ->addColumn('action', function($row){
						$btn = '<a href="'.route("superadmin.applicationGenerateCertificateview",$row->id).'">Generate Certificate</a>';
                        return $btn;
                    })
					  ->addColumn('registration_no', function ($row) {
                        return $row->registration_no;
                     })
					->editColumn('company_name', function ($row) {
							return $row->company_name;
                     })
					 ->editColumn('unit_name', function ($row) {
                        return $row->unit_name;
                     })

					 ->addColumn('address', function ($row) {
                        return $row->address.'<br>City: '.getDistrictID($row->ref_district_id)->district_name.'<br>State: '.get_state_name($row->ref_state_id).'<br>Pincode: '.$row->pincode;
                     })
					  ->addColumn('validity_end', function ($row) {
                        return date('d/m/Y', strtotime($row->validity_end)) ?? '';
                     })

                    ->rawColumns(['action','address'])
                    ->make(true);
        }
		 return view('admin.inputapproval.application_generate_certificate_list',compact('list'));
	}


	public function applicationRenewalList(Request $request)
	{
		$list=AtInputApprovalRegDetail::whereDate('validity_end', '<', date('Y-m-d'))->get();

        if ($request->ajax()) {

             return Datatables::of($list)
                    ->addIndexColumn()
                    ->addColumn('action', function($row){
						$btn = '<a href="'.route("superadmin.applicationRenewalProcess",$row->id).'">Process</a>';
                        return $btn;
                    })
					  ->addColumn('registration_no', function ($row) {
                        return $row->registration_no;
                     })
					->editColumn('company_name', function ($row) {
							return $row->company_name;
                     })
					 ->editColumn('unit_name', function ($row) {
                        return $row->unit_name;
                     })

					 ->addColumn('address', function ($row) {
                        return $row->address.'<br>City: '.getDistrictID($row->ref_district_id)->district_name.'<br>State: '.get_state_name($row->ref_state_id).'<br>Pincode: '.$row->pincode;
                     })
					  ->addColumn('validity_end', function ($row) {
                        return date('d/m/Y', strtotime($row->validity_end)) ?? '';
                     })

                    ->rawColumns(['action','address'])
                    ->make(true);
        }
		 return view('admin.inputapproval.application_renewal_list',compact('list'));
	}


	public function applicationRenewalProcess(Request $request,$id)
	{
		$data = AtInputApprovalRegDetail::with('getUnitRegDetails')->where('id',$id)->first();
		return view('admin.inputapproval.application_renewal_process',compact('data','id'));
	}


    public function applicationGenerateCertificateview(Request $request ,$id){

      $approval_reg_details = AtInputApprovalRegDetail::with('getUnitRegDetailsWithIngredient')->where('id',$id)->first();
	//pra( $approval_reg_details);
      return view('admin.inputapproval.application_generate_certificate_view',compact('approval_reg_details','id'));

    }

	public function applicationGenerateCertificatePDF(Request $request ,$id){

      $approval_reg_details = AtInputApprovalRegDetail::with('getUnitRegDetailsWithIngredient')->where('id',$id)->first();
		$pdf = PDF::loadView('admin.inputapproval.tpl_application_generate_certificate_pdf',compact('approval_reg_details','id'))->setOptions(['defaultFont' => 'sans-serif']);
      // download PDF file with download method
	  $filename = 'application_certificate_'.uniqid().time().'.pdf';
      return $pdf->download($filename);

    }





	public function storeApplicationUnit(Request $request)
	{
		//pr($request->all());
		$validator = \Validator::make($request->all(), [
           'at_input_approval_reg_details_id' => 'required',
            'unit_name' => 'required',
			'license_no' => 'required',
            'ref_state_id' => 'required',
            'ref_district_id' => 'required',
            'ref_block_tehsil_id' => 'required',
            'pincode' => 'required',
        ]);

        if ($validator->fails())
        {
            return response()->json(['errors'=>$validator->errors()->all()]);
        }

		try {
			$registration_no =  'IA-'.date('Y').'-'.str_pad($request->at_input_approval_reg_details_id,5,"0",STR_PAD_LEFT);
			$getData = AtInputApprovalUnitRegDetail::where('at_input_approval_reg_details_id',$request->at_input_approval_reg_details_id)->count();
			 $insertData = array(
				'at_input_approval_reg_details_id' =>  $request->at_input_approval_reg_details_id,
				'unit_reg_number' => $registration_no.'-'.$getData+1,
				'unit_name' => $request->unit_name,
				'license_no' => $request->license_no,
				'address' => $request->address,
				'installed_capacity' => $request->installed_capacity,
				'additional_certification' => ($request->additional_certification) ? implode(',',$request->additional_certification) : '',
				'estimated_production_in_mt' => $request->estimated_production_in_mt,
				'license_validity_upto' => date('Y-m-d',strtotime($request->license_validity_upto)),
				'ref_state_id' => $request->ref_state_id,
				'ref_district_id' => $request->ref_district_id,
				'ref_block_tehsil_id' => $request->ref_block_tehsil_id,
				'pincode' => $request->pincode,
			 );
				$insertData['created_at'] = date('Y-m-d H:i:s');
				$insertData['created_by'] = Auth::guard('misadmin')->user()->id;
				//pr($insertData);
				$input_approval = AtInputApprovalUnitRegDetail::create($insertData);

			return response()->json(['data'=>[],'success'=>'Application unit is successfully added']);

		} catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
	}


	public function applicationGenerateRenewalCertificate(Request $request,$id)
	{
		$data = AtInputApprovalRegDetail::where('id',$id)->first();

		return view('admin.inputapproval.application_renewal_certificate',compact('data','id'));
	}

	public function storeApplicationGenerateRenewalCertificate(Request $request,$id)
	{
		try {

		$request->validate([
			'validity_start_from' => 'required',
            'validity_end' => 'required',
            'remarks' => 'required',
        ]);

		$insertData = array(
		'validity_start_from' => $request->validity_start_from,
		'validity_end' => $request->validity_end,
		'renewal_flag' => 1,
		'renewal_date' => date('Y-m-d'),
		'remarks' => $request->remarks,
		'updated_at' => date('Y-m-d H:i:s'),
		'updated_by' => Auth::guard('misadmin')->user()->id,
		);

		AtInputApprovalRegDetail::where('id',$id)->update($insertData);


		Alert::success('Success', 'Certificate has been renewed successfully!');
		return redirect()->route('superadmin.applicationGenerateCertificateList')->with('loader',true);

		} catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }

	}


}

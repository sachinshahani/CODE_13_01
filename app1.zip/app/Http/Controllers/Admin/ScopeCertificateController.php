<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Permission;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\AtImportedProductMaster;
use App\Models\AtImportedProductDetails;
use App\Models\CertificateStandardDetail;
use App\Models\IndividualProducerFarmDetail;
use App\Models\TradersProductDetail;
use App\Models\AtProProductsDetails;
use App\Models\TraderGeoTaggingWarehouseUnitDetails;
use App\Models\WildHarvesterForestProductDetail;
use App\Models\CBCategoryWiseRestriction;
use App\Models\RefEligibleCategory;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;
// use Barryvdh\DomPDF\Facade as PDF;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use PDF;
use Validator;
use DataTables;
use DB;
use Gate;
use QrCode;
use Symfony\Component\HttpKernel\Exception\MethodNotAllowedHttpException;

class ScopeCertificateController extends Controller
{
	public function applyScopeCertificate(Request $request)
	{
		try {
			$userId = Auth::id();
			$user = User::with('appliedScope')->where('id', $userId)->first();
			if (empty($user->registration_no && $user->status == '2')) {
				Alert::error('error', "Please! Complete your profile to Apply for the Scope Certificate.");
				return redirect()->back();
			}
			// dd($user);
			$elegible = '';
			if (empty($user->appliedScope)) {
				$fdate = date('Y-m-d', strtotime($user->created_at));
				$tdate = date('Y-m-d');
				$datetime1 = new \DateTime($fdate);
				$datetime2 = new \DateTime($tdate);
				$interval = $datetime1->diff($datetime2);
				$days = $interval->format('%a');
				if ($days > 180) {
					$user = User::where('id', $userId)->update(['login_status' => 0]);
					Auth::guard('misadmin')->logout();
					$request->session()->flush();
				}
				//$elegible =1;
			} else {
				//echo $user->appliedScope->status;


				if ($user->appliedScope->status == 0) {

					$elegible = 0; // already applied
				} else if ($user->appliedScope->status == 1) {

					$elegible = 1; // already scope generated
				}
			}
			return view('admin/scope_certificate/apply_scope_certificate', compact('user', 'elegible'));
		} catch (Exception $e) {
			return redirect()->back();
		} catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
			return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
		}
	}

	public function previewOfApplication(Request $request)
	{ //dd('dsfwer');

		try {
			//dd('hello');
			$userId = Auth::id();
			$user = User::with('appliedScope')->where('id', $userId)->first();
			$elegible = '';
			//pr($user);
			if (empty($user->appliedScope)) {
				$fdate = date('Y-m-d', strtotime($user->created_at));
				$tdate = date('Y-m-d');
				$datetime1 = new \DateTime($fdate);
				$datetime2 = new \DateTime($tdate);
				$interval = $datetime1->diff($datetime2);
				$days = $interval->format('%a');
				if ($days > 180) {
					$user = User::where('id', $userId)->update(['login_status' => 0]);
					Auth::guard('misadmin')->logout();
					$request->session()->flush();
				}
				//$elegible =1;

				// $data = array(
				// 	'at_user_id' =>Auth::id(),
				// 	'ref_operator_type_id'=>Auth::user()->ref_operator_type_id,
				// 	'standard_type'=>"Production",
				// 	'scope_for'=>"Production",
				// 	'created_by' => Auth::guard('misadmin')->user()->id,
				// 	'created_at' => date('Y-m-d H:i:s'),

				// );
				// $saveData = CertificateStandardDetail::create($data);

			} else {
				if ($user->appliedScope->status == 0) {
					$elegible = 0; // already applied
				} else {
					$elegible = 2; // already scope generated
				}
			}



			return view('admin/scope_certificate/preview_scope_certificate', compact('user', 'elegible'));
		} catch (Exception $e) {
			return redirect()->back();
		}
	}



	public function previewScopeCertificate(Request $request, $id)
	{
		try {

			// $appliedscop = CertificateStandardDetail::where('at_user_id',$id)->first();
			$appliedscop = $user = User::where('id', $id)->first();

			$flname = '/scope_certificate/' . $appliedscop->id . '_' . time() . '.pdf';
			$qrcode = base64_encode(QrCode::format('svg')->size(500)->errorCorrection('H')->generate(asset($flname)));
			$data2 = [
				'reg_no' => $user->registration_no,
				'name' => $appliedscop->first_name,
				'address' => $appliedscop->address,
				'opr_type' => getOperatorTypeById($appliedscop->ref_operator_type_id),
				'cb_name' => Auth::guard('misadmin')->user()->first_name,
				'cb_address' => Auth::guard('misadmin')->user()->address,
				'issued_on' => date('d/m/Y'),
				'qr_code' => $qrcode,
				'accreditation_agency_no' => '',
				'accreditation_agency_name' => '',
				'scope_certificate_no' => getScopeCerNo($appliedscop->id, $appliedscop->ref_operator_type_id),
				'scope_for' => "Production",
				'is_renewed' => '0',
				'validity_start_date' => $appliedscop->validity_start_date,
				'cb_id' => $appliedscop->created_by,
				// 'validity_end_date' => date('Y-m-d', strtotime('+1 years')),
				'validity_end_date' => date('Y-m-d', strtotime('+1 year -1 day')),
				//'file_name' => $flname,
				//'product' => getProductByICS($user->id),
				//'otherinfo' => getFarmersByICS($user->id)
			];
			//dd($data2);
			if ($user->ref_operator_type_id == 2) // ICS
			{

				$products = getProductByICS($appliedscop->id);

				//dd($products);
				$formers = getFarmersByICS($appliedscop->id);
				// dd($formers);
				$cb_category = CBCategoryWiseRestriction::where('cb_id', Auth::id())->first();
				if (isset($cb_category)) {
					$ref_eligible_category = RefEligibleCategory::where('id', $cb_category->ref_eligible_category_id)->first();
					if (isset($ref_eligible_category)) {
						$ref_eligible_data = '(Category ' . $ref_eligible_category->category . ') ';
					} else {
						$ref_eligible_data = ' ';
					}
				} else {
					$ref_eligible_data = ' ';
				}

				echo view('admin/usermanagement/pdf/scopeCertificateICS', compact('user', 'data2', 'products', 'formers', 'ref_eligible_data'))->render();
			} elseif ($user->ref_operator_type_id == 3) // IP
			{

				$products = getProductByIP($appliedscop->id);
				$forms = IndividualProducerFarmDetail::where('at_user_id', $appliedscop->id)->get();

				echo view('admin/usermanagement/pdf/scopeCertificateIP', compact('user', 'data2', 'products', 'forms'))->render();
			} elseif ($user->ref_operator_type_id == 4) // WH
			{

				$products = getProductByWH($appliedscop->id);
				echo view('admin/usermanagement/pdf/scopeCertificateWH', compact('user', 'data2', 'products'))->render();
			} elseif ($user->ref_operator_type_id == 5) //TRD
			{
				$products = TradersProductDetail::where('at_user_id', $appliedscop->id)->get();
				$warehouse = TraderGeoTaggingWarehouseUnitDetails::where('at_user_id', $appliedscop->id)->get();
				// dd($warehouse);
				echo view('admin/usermanagement/pdf/scopeCertificateTRD', compact('user', 'data2', 'products', 'warehouse'))->render();
			} elseif ($user->ref_operator_type_id == 6) // PROCESSOR
			{
				//dd($appliedscop->id);
				$products = AtProProductsDetails::where('at_user_id', $appliedscop->id)->get();
				echo view('admin/usermanagement/pdf/scopeCertificatePRO', compact('user', 'data2', 'products'))->render();
			}
		} catch (Exception $e) {
			return redirect()->back();
		} catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
			return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
		}
	}

	public function applyScopeCertificateSave(Request $request)
	{
		try {
			$data = array(
				'at_user_id' => Auth::id(),
				'ref_operator_type_id' => Auth::user()->ref_operator_type_id,
				'standard_type' => "Production",
				'scope_for' => "Production",
				'status' => 0,
				'created_by' => Auth::guard('misadmin')->user()->id,
				'created_at' => date('Y-m-d H:i:s'),

			);
			$saveData = CertificateStandardDetail::create($data);
			if ($saveData) {
				Alert::success('Success', "Your application has been submitted to CB.");
			} else {
				Alert::success('Error', "Application not forwarded.");
			}

			return redirect()->route('superadmin.applyScopeCertificate')->with('loader', true);
		} catch (Exception $e) {
			return redirect()->back();
		} catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
			return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
		}
	}


	public function ScopeCertificateStatusUpdate(Request $request, $id)
	{
		try {
			$request->validate([
				'inspection_date' => 'required',
				'inspected_by' => 'required',
				'status' => 'required',
			]);

			$data = array(
				'is_approved' => ($request->status == 1 ? "1" : NULL),
				'is_rejected' => ($request->status == 2 ? "1" : NULL),
				'approved_on' => $request->inspection_date,
				'approved_by' => $request->inspected_by,
				'remarks' => $request->cb_remarks,
				'updated_by' => Auth::guard('misadmin')->user()->id,
				'updated_at' => date('Y-m-d H:i:s'),

			);
			$saveData = AtImportedProductMaster::where('id', $id)->update($data);

			Alert::success('Success', "Status Changed Successfully.");
			return redirect()->back();
		} catch (Exception $e) {
			return redirect()->back();
		} catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
			return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
		}
	}


	public function scopeCertificateList(Request $request)
	{
		try {

			$list = CertificateStandardDetail::whereHas('getuser', function ($q) {
				return $q->where('created_by', Auth::id());
			})
				->where('status', 0)->orderBy('id', 'desc')
				->get();

			if ($request->ajax()) {
				return Datatables::of($list)
					->addIndexColumn()
					->addColumn('registration_no', function ($row) {
						return $row->getuser->registration_no ?? 'Not Alloted';
						//return $row->scope_certificate_no ?? 'Not Alloted';
					})
					->addColumn('name', function ($row) {
						return ucwords($row->getuser->first_name) ?? ''; //date('d-m-Y',strtotime($row->created_at));
					})
					->addColumn('programme', function ($row) {
						return 'NPOP';
					})
					->addColumn('opr_type', function ($row) {
						return getOperatorTypeById($row->ref_operator_type_id);
					})
					->addColumn('created_at', function ($row) {
						return date('d-m-Y', strtotime($row->created_at));
					})
					->addColumn('status', function ($row) {
						return $row->status == 0 ? "Pending" : "Active";
					})
					->addColumn('action', function ($row) {
						$actionBtn = '';

						/* 	$actionBtn .= '<a style="text-align: center;display: block;"  href='.route('superadmin.scopeCertificateGenerate',$row->id).'>View OSP Detail(s)</a>';
					$actionBtn .= '<a style="text-align: center;display: block;" href='.route('superadmin.scopeCertificateGenerate',$row->id).'>Initiate Risk Assessment</a>';
					$actionBtn .= '<a style="text-align: center;display: block;" href='.route('superadmin.scopeCertificateGenerate',$row->id).'>View/Edit Application</a>';
					$actionBtn .= '<a style="text-align: center;display: block;" href='.route('superadmin.scopeCertificateGenerate',$row->id).'>Generate Scope Certificate</a>';
					 */
						// if(Gate::check('scope_approve')){ 



						// All user type show same profile so comment 
						//$actionBtn.= '<a href='.route('superadmin.usermanagement.deptUser.view', [$row->at_user_id]).' target="_blank"><span><i class="mdi mdi-eye text-muted fs-24 align-middle me-1" data-toggle="tooltip"  title="View User"></i></span></a>';

						if ($row->ref_operator_type_id == 2) {
							if ($row->status == 1) {
								$actionBtn .= '<a download href=' . asset('public' . $row->file_name) . '><span><i class="mdi mdi-file-certificate text-info fs-24 align-middle me-1" data-toggle="tooltip" title="Download Scope certificate"></i></span></a>';
							} else {
								$actionBtn .= '<a href=' . route('superadmin.scopeCertificateGenerate', $row->id) . '><span><i class="mdi mdi-file-certificate text-muted fs-24 align-middle me-1" data-toggle="tooltip" title="Generate Scope certificate"></i></span></a>';
							}
						} else if ($row->ref_operator_type_id == 3) {
							// if ip
							if ($row->status == 1) {
								$actionBtn .= '<a download href=' . asset('public' . $row->file_name) . '><span><i class="mdi mdi-file-certificate text-info fs-24 align-middle me-1" data-toggle="tooltip" title="Download Scope certificate"></i></span></a>';
							} else {
								$actionBtn .= '<a href=' . route('superadmin.scopeCertificateGenerate', $row->id) . '><span><i class="mdi mdi-file-certificate text-muted fs-24 align-middle me-1" data-toggle="tooltip" title="Generate Scope certificate"></i></span></a>';
							}
						} else if ($row->ref_operator_type_id == 4) {
							// if wh
							if ($row->status == 1) {
								$actionBtn .= '<a download href=' . asset('public' . $row->file_name) . '><span><i class="mdi mdi-file-certificate text-info fs-24 align-middle me-1" data-toggle="tooltip" title="Download Scope certificate"></i></span></a>';
							} else {
								$actionBtn .= '<a href=' . route('superadmin.scopeCertificateGenerate', $row->id) . '><span><i class="mdi mdi-file-certificate text-muted fs-24 align-middle me-1" data-toggle="tooltip" title="Generate Scope certificate"></i></span></a>';
							}
						} else if ($row->ref_operator_type_id == 5) {
							// if trader
							if ($row->status == 1) {
								$actionBtn .= '<a download href=' . asset('public' . $row->file_name) . '><span><i class="mdi mdi-file-certificate text-info fs-24 align-middle me-1" data-toggle="tooltip" title="Download Scope certificate"></i></span></a>';
							} else {
								$actionBtn .= '<a href=' . route('superadmin.scopeCertificateGenerate', $row->id) . '><span><i class="mdi mdi-file-certificate text-muted fs-24 align-middle me-1" data-toggle="tooltip" title="Generate Scope certificate"></i></span></a>';
							}
						} else {
							// if processor
							//$actionBtn.= '<a href='.route('superadmin.usermanagement.deptUser.proview',[$row->at_user_id]).' target="_blank"><span><i class="mdi mdi-eye text-muted fs-24 align-middle me-1" data-toggle="tooltip" title="View User"></i></span></a>';
							$actionBtn .= '<a href=' . route('superadmin.scopeCertificateGenerate', $row->id) . '><span><i class="mdi mdi-file-certificate text-muted fs-24 align-middle me-1" data-toggle="tooltip" title="Generate Scope certificate"></i></span></a>';
						}

						// }
						return $actionBtn;
					})
					->rawColumns(['action'])
					->make(true);
			}

			return view('admin/scope_certificate/scope_certificate_list');
		} catch (Exception $e) {
			return redirect()->back();
		} catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
			return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
		}
	}

	public function issuedScopeCertificateList(Request $request)
	{ //$dd1 =  date('Y-m-d', strtotime('+1 year -1 day')) ;
		//dd($dd1);

		try {

			$list = CertificateStandardDetail::whereHas('getuser', function ($q) {
				return $q->where('created_by', Auth::id());
			})
				->where('status', 1)->orderBy('id', 'desc')
				->get();
			// pra($list);

			if ($request->ajax()) {
				return Datatables::of($list)
					->addIndexColumn()
					->addColumn('registration_no', function ($row) {
						//return $row->getuser->registration_no ?? 'Not Alloted';
						return $row->scope_certificate_no ?? 'Not Alloted';
					})
					->addColumn('name', function ($row) {
						return ucwords($row->getuser->first_name) ?? ''; //date('d-m-Y',strtotime($row->created_at));
					})
					->addColumn('programme', function ($row) {
						return 'NPOP';
					})
					->addColumn('opr_type', function ($row) {
						return getOperatorTypeById($row->ref_operator_type_id);
					})
					->addColumn('created_at', function ($row) {
						return date('d-m-Y', strtotime($row->created_at));
					})
					->addColumn('validity', function ($row) {
						$validity = date('d-m-Y', strtotime($row->validity_start_date)) . " to " . date('d-m-Y', strtotime($row->validity_end_date));
						return $validity;
					})
					->addColumn('status', function ($row) {
						return $row->status == 0 ? "Pending" : "Active";
					})
					->addColumn('action', function ($row) {
						$actionBtn = '';

						// $actionBtn .= '<a style="text-align: center;display: block;"  href='.route('superadmin.scopeCertificateGenerate',$row->id).'>View OSP Detail(s)</a>';
						// $actionBtn .= '<a style="text-align: center;display: block;" href='.route('superadmin.scopeCertificateGenerate',$row->id).'>Initiate Risk Assessment</a>';
						// $actionBtn .= '<a style="text-align: center;display: block;" href='.route('superadmin.scopeCertificateGenerate',$row->id).'>View/Edit Application</a>';
						// $actionBtn .= '<a style="text-align: center;display: block;" href='.route('superadmin.scopeCertificateGenerate',$row->id).'>Generate Scope Certificate</a>';

						// if(Gate::check('scope_approve')){
						$actionBtn .= '<a href=' . route('superadmin.usermanagement.deptUser.view', [$row->at_user_id]) . ' target="_blank"><span><i class="mdi mdi-eye text-muted fs-24 align-middle me-1 ss" data-toggle="tooltip"  title="View User"></i></span></a>';

						if ($row->ref_operator_type_id == 2) {
							if ($row->status == 1) {
								$actionBtn .= '<a download href=' . asset('public' . $row->file_name) . '><span><i class="mdi mdi-pdf-certificate text-info fs-24 align-middle me-1 ss-1" data-toggle="tooltip" title="Download Scope certificate"></i></span></a>';
							} else {
								$actionBtn .= '<a href=' . route('superadmin.scopeCertificateGenerate', $row->id) . '><span><i class="mdi mdi-file-certificate text-muted fs-24 align-middle me-1 ss-2" data-toggle="tooltip" title="Generate Scope certificate"></i></span></a>';
							}
						} else if ($row->ref_operator_type_id == 3) {
							// if ip
							if ($row->status == 1) {
								$actionBtn .= '<a download href=' . asset('public' . $row->file_name) . '><span><i class="mdi mdi-file-certificate text-info fs-24 align-middle me-1 ss-3" data-toggle="tooltip" title="Download Scope certificate"></i></span></a>';
							} else {
								$actionBtn .= '<a href=' . route('superadmin.scopeCertificateGenerate', $row->id) . '><span><i class="mdi mdi-file-certificate text-muted fs-24 align-middle me-1 ss-3" data-toggle="tooltip" title="Generate Scope certificate"></i></span></a>';
							}
						} else if ($row->ref_operator_type_id == 4) {
							// if wh
							if ($row->status == 1) {
								$actionBtn .= '<a download href=' . asset('public' . $row->file_name) . '><span><i class="mdi mdi-file-certificate text-info fs-24 align-middle ss-4" data-toggle="tooltip" title="Download Scope certificate"></i></span></a>';
								// $actionBtn .= '<a onclick="getBase64(' . json_encode(asset('public'.$row->file_name)) . ', ' . $row->id . ')">
								// 	<span><i class="mdi mdi-file-certificate text-primary fs-24 align-middle" data-toggle="tooltip" title="Sign Scope certificate"></i></span>
								// </a>';
							} else {
								$actionBtn .= '<a href="' . route('superadmin.scopeCertificateGenerate', $row->id) . '">
											<span><i class="mdi mdi-file-certificate text-muted fs-24 align-middle me-1 ss-5" data-toggle="tooltip" title="Generate Scope certificate"></i></span>
										</a>';
							}
						} else if ($row->ref_operator_type_id == 5) {
							// if trader
							if ($row->status == 1) {
								$actionBtn .= '<a download href=' . asset('public' . $row->file_name) . '><span><i class="mdi mdi-file-certificate text-info fs-24 align-middle me-1 ss-6" data-toggle="tooltip" title="Download Scope certificate"></i></span></a>';
							} else {
								$actionBtn .= '<a href=' . route('superadmin.scopeCertificateGenerate', $row->id) . '><span><i class="mdi mdi-file-certificate text-muted fs-24 align-middle me-1 ss-7" data-toggle="tooltip" title="Generate Scope certificate"></i></span></a>';
							}
						} else {
							// if processor
							if ($row->status == 1) {
								$actionBtn .= '<a download href=' . asset('public' . $row->file_name) . '><span><i class="mdi mdi-file-certificate text-info fs-24 align-middle me-1 ss-8" data-toggle="tooltip" title="Download Scope certificate"></i></span></a>';
							} else {
								$actionBtn .= '<a href=' . route('superadmin.scopeCertificateGenerate', $row->id) . '><span><i class="mdi mdi-file-certificate text-muted fs-24 align-middle me-1 ss-9" data-toggle="tooltip" title="Generate Scope certificate"></i></span></a>';
							}
						}

						// }
						//eMSigned Digital Signature Allow
						$result = getUserDigitalSignatureModules(Auth::id(), 'SC');
						$module = $result['status'] == 'success' && $result['isAllowed'] == '1' ? '1' : '0';

						if ($module == '1') {
							$fileName = basename($row->file_name);
							$filePath = str_replace($fileName, '', $row->file_name);
							$hostName = request()->getSchemeAndHttpHost();
							$checkSignedPDf = getDigitalSignedPdf(Auth::id(), $fileName);
							if ($checkSignedPDf['status'] == 'success') {
								$publicPath = str_replace('var/www/html/apeda/', '', $checkSignedPDf['signedPath']);
								$actionBtn .= '<a class="btn btn-success btn-sm" download href=' . $hostName . $publicPath . '>Signed PDF</a>';
							} else {
								$actionBtn .= '<button type="button" class="btn btn-primary btn-sm" id="generateDigitalSign" data-fileName="' . $fileName . '" data-path="' . $filePath . '" data-fileStored="public" data-certificate="SCC">Digital Sign</button>';
							}
						}

						return $actionBtn;
					})
					->rawColumns(['action'])
					->make(true);
			}

			return view('admin/scope_certificate/issued_scope_certificate_list');
		} catch (Exception $e) {
			return redirect()->back();
		} catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
			return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
		}
	}


	public function scopeCertificateGenerate(Request $request, $id)
	{
		try {
			$data = array(
				'accreditation_agency_no' => $request->status,
				'accreditation_agency_name' => $request->status,
				'scope_certificate_no' => $request->inspection_date,
				'scope_for' => $request->inspected_by,
				'is_renewed' => $request->cb_remarks,
				// 'validity_start_date' => '2',
				// 'validity_end_date' => '2' ,
				'barcode' => '2',
				'file_name' => 'GGG',
				'remarks' => 'JJ',
				'updated_by' => Auth::guard('misadmin')->user()->id,
				'updated_at' => date('Y-m-d H:i:s'),
			);
			$saveData = CertificateStandardDetail::where('id', $id)->update($data);
			$user = CertificateStandardDetail::with('getuser')->where('id', $id)->where('status', 0)->first();

			$authsign = User::whereHas('roles', function ($q) {
				return $q->where('title', 'Authorized Signatory');
			})
				->where('created_by', Auth::id())
				->get();
			return view('admin/scope_certificate/scope_certificate_generate', compact('user', 'authsign'));
		} catch (Exception $e) {
			return redirect()->back();
		} catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
			return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
		}
	}

	// CB

	public function saveViewCertificatePreview(Request $request)
	{
		try {
			//dd(date('Y-m-d', strtotime(' + 1 years')));
			$appliedscop = CertificateStandardDetail::where('id', $request->hid)->first();
			$user = User::where('id', $appliedscop->at_user_id)->first();

			$data = array(
				'accreditation_agency_no' => '',
				'accreditation_agency_name' => '',
				'scope_certificate_no' => getScopeCerNo($appliedscop->at_user_id, $appliedscop->ref_operator_type_id),
				'scope_for' => "Production",
				'is_renewed' => '0',
				'validity_start_date' => $request->certification_date,
				// 'validity_end_date' => date('Y-m-d', strtotime('+1 years')),
				'validity_end_date' => date('Y-m-d', strtotime('+1 year -1 day')),
				'barcode' => '',
				'file_name' => '',
				'remarks' => '',
				'updated_by' => Auth::guard('misadmin')->user()->id,
				'updated_at' => date('Y-m-d H:i:s'),

			);
			$saveData = CertificateStandardDetail::where('id', $request->hid)->update($data);

			return redirect()->route('superadmin.viewCertificatePreview', $request->hid)->with('loader', true);
		} catch (Exception $e) {
			return redirect()->back();
		} catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
			return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
		}
	}

	public function viewCertificatePreview(Request $request, $id)
	{
		$appliedscop = CertificateStandardDetail::where('id', $id)->first();
		return view('admin/scope_certificate/cb_preview_scope_certificate', compact('appliedscop'));
	}

	public function CBpreviewScopeCertificate(Request $requst, $id)
	{


		try {

			$appliedscop = CertificateStandardDetail::where('id', $id)->first();

			$user = User::where('id', $appliedscop->at_user_id)->first();
			$flname = '/scope_certificate/' . $appliedscop->at_user_id . '_' . time() . '.pdf';
			$qrcode = base64_encode(QrCode::format('svg')->size(500)->errorCorrection('H')->generate(asset($flname)));
			$data2 = [
				'reg_no' => $user->registration_no,
				'name' => $appliedscop->first_name,
				'address' => $appliedscop->address,
				'opr_type' => getOperatorTypeById($appliedscop->ref_operator_type_id),
				'cb_name' => Auth::guard('misadmin')->user()->first_name,
				'cb_address' => Auth::guard('misadmin')->user()->address,
				'issued_on' => date('d/m/Y'),
				'qr_code' => $qrcode,
				'accreditation_agency_no' => '',
				'accreditation_agency_name' => '',
				'scope_certificate_no' => getScopeCerNo($appliedscop->at_user_id, $appliedscop->ref_operator_type_id),
				'scope_for' => "Production",
				'is_renewed' => '0',
				'validity_start_date' => $appliedscop->validity_start_date,
				//'validity_end_date' => date('Y-m-d', strtotime('+1 years')),
				'validity_end_date' => date('Y-m-d', strtotime('+1 year -1 day')),
				'cb_id' => $user->created_by,
				//'file_name' => $flname,
				//'product' => getProductByICS($user->id),
				//'otherinfo' => getFarmersByICS($user->id)
			];

			if ($user->ref_operator_type_id == 2) // ICS
			{

				$products = getProductByICS($appliedscop->at_user_id);
				$formers = getFarmersByICS($appliedscop->at_user_id);

				$cb_category = CBCategoryWiseRestriction::where('cb_id', Auth::id())->first();
				if (isset($cb_category)) {
					$ref_eligible_category = RefEligibleCategory::where('id', $cb_category->ref_eligible_category_id)->first();
					if (isset($ref_eligible_category)) {
						$ref_eligible_data = '(Category ' . $ref_eligible_category->category . ') ';
					} else {
						$ref_eligible_data = ' ';
					}
				} else {
					$ref_eligible_data = '';
				}


				echo view('admin/usermanagement/pdf/scopeCertificateICS', compact('user', 'data2', 'products', 'formers', 'ref_eligible_data'))->render();
			} elseif ($user->ref_operator_type_id == 3) // IP
			{
				$products = getProductByIP($appliedscop->at_user_id);
				$forms = IndividualProducerFarmDetail::where('at_user_id', $appliedscop->at_user_id)->get();
				echo view('admin/usermanagement/pdf/scopeCertificateIP', compact('user', 'data2', 'products', 'forms'))->render();
			} elseif ($user->ref_operator_type_id == 4) // WH
			{
				$products = getProductByWH($appliedscop->at_user_id);
				echo view('admin/usermanagement/pdf/scopeCertificateWH', compact('user', 'data2', 'products'))->render();
			} elseif ($user->ref_operator_type_id == 5) //TRD
			{
				$products = TradersProductDetail::where('at_user_id', $appliedscop->at_user_id)->get();
				$warehouse = TraderGeoTaggingWarehouseUnitDetails::where('at_user_id', $appliedscop->at_user_id)->get();
				// dd($warehouse);
				echo view('admin/usermanagement/pdf/scopeCertificateTRD', compact('user', 'data2', 'products', 'warehouse'))->render();
			} elseif ($user->ref_operator_type_id == 6) // PROCESSOR
			{

				$products = AtProProductsDetails::where('at_user_id', $appliedscop->at_user_id)->get();
				echo view('admin/usermanagement/pdf/scopeCertificatePRO', compact('user', 'data2', 'products'))->render();
			}
		} catch (Exception $e) {
			return redirect()->back();
		} catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
			return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
		}
	}

	public function scopeCertificateGenerateSave(Request $request)
	{

		try {


			$appliedscop = CertificateStandardDetail::where('id', $request->hid)->first();

			//dd($appliedscop );
			$user = User::where('id', $appliedscop->at_user_id)->first();
			$serialNumber = 'SC/CB' . Auth::guard('misadmin')->user()->id . '/' . date('Y') . '/' . rand(1000, 9999);

			// pr(getProductByICS($user->id));
			$flname = '/scope_certificate/' . $appliedscop->at_user_id . '_' . time() . '.pdf';
			$qrcode = base64_encode(QrCode::format('svg')->size(500)->errorCorrection('H')->generate(asset($flname)));

			$data2 = [
				'reg_no' => $user->registration_no ?? 'N/A',
				'name' => $appliedscop->first_name ?? 'N/A',
				'address' => $appliedscop->address ?? 'N/A',
				'opr_type' => getOperatorTypeById($appliedscop->ref_operator_type_id),
				'cb_name' => Auth::guard('misadmin')->user()->first_name,
				'cb_address' => Auth::guard('misadmin')->user()->address,
				'issued_on' => date('d/m/Y'),
				'qr_code' => $qrcode,
				'accreditation_agency_no' => '',
				'accreditation_agency_name' => '',
				'scope_certificate_no' => getScopeCerNo($appliedscop->at_user_id, $appliedscop->ref_operator_type_id),
				'scope_for' => "Production",
				'is_renewed' => '0',
				'validity_start_date' => $request->certification_date,
				// 'validity_end_date' => date('Y-m-d', strtotime('+1 years')),
				'validity_end_date' => date('Y-m-d', strtotime('+1 year -1 day')),
				'cb_id' => $user->created_by,
				//'file_name' => $flname,
				//'product' => getProductByICS($user->id),
				//'otherinfo' => getFarmersByICS($user->id)
			];


			if ($user->ref_operator_type_id == 2) // ICS
			{



				$products = getProductByICS($appliedscop->at_user_id)  ?? [];
				$formers = getFarmersByICS($appliedscop->at_user_id) ?? [];

				$cb_category = CBCategoryWiseRestriction::where('cb_id', Auth::id())->first();
				if(isset($cb_category)){
				$ref_eligible_category = RefEligibleCategory::where('id', $cb_category->ref_eligible_category_id)->first();
				if (isset($ref_eligible_category)) {
					$ref_eligible_data = '(Category ' . $ref_eligible_category->category . ' ) ';
				} else {
					$ref_eligible_data = ' ';
				}
			}else{
				$ref_eligible_data = ' ';
			}

				$pdf = PDF::loadView('admin/usermanagement/pdf/scopeCertificateICS', compact('user', 'data2', 'products', 'formers', 'ref_eligible_data'));

				$pdf->getDomPDF()->getCanvas()->page_text(520, 800, "Page: {PAGE_NUM} of {PAGE_COUNT}", null, 12, array(0, 0, 0));
				$pdf->getDomPDF()->getCanvas()->page_text(30, 800, "Serial Number:", null, 12, array(0, 0, 0));
				$pdf->getDomPDF()->getCanvas()->page_text(112, 800, $serialNumber ?? 'N/A', null, 12, array(255, 0, 0));
				$footerYPosition = 770;
				$footerLine1 = Auth::guard('misadmin')->user()->first_name . ' ' . Auth::guard('misadmin')->user()->last_name;
				$footerLine2 = Auth::guard('misadmin')->user()->address;
				$pdf->getDomPDF()->getCanvas()->page_text(30, $footerYPosition, $footerLine1 ?? 'N/A', null, 10, array(0, 0, 0));
				$pdf->getDomPDF()->getCanvas()->page_text(30, $footerYPosition + 15, $footerLine2 ?? 'N/A', null, 10, array(0, 0, 0));
				if (!file_exists(public_path('path_to_save_pdf'))) {
					mkdir(public_path('path_to_save_pdf'), 0777, true);
				}

				$pdf->save(public_path($flname));
				// $pdf->getDomPDF()->getCanvas()->get_cpdf();


			} elseif ($user->ref_operator_type_id == 3) // IP
			{
				$products = getProductByIP($appliedscop->at_user_id);
				$forms = IndividualProducerFarmDetail::where('at_user_id', $appliedscop->at_user_id)->get();
				$pdf = PDF::loadView('admin/usermanagement/pdf/scopeCertificateIP', compact('user', 'data2', 'products', 'forms'));

				$pdf->getDomPDF()->getCanvas()->page_text(520, 800, "Page: {PAGE_NUM} of {PAGE_COUNT}", null, 12, array(0, 0, 0));
				$pdf->getDomPDF()->getCanvas()->page_text(30, 800, "Serial Number:", null, 12, array(0, 0, 0));
				$pdf->getDomPDF()->getCanvas()->page_text(112, 800, $serialNumber, null, 12, array(255, 0, 0));

				$footerYPosition = 770;
				$footerLine1 = Auth::guard('misadmin')->user()->first_name . ' ' . Auth::guard('misadmin')->user()->last_name;
				$footerLine2 = Auth::guard('misadmin')->user()->address;
				$pdf->getDomPDF()->getCanvas()->page_text(30, $footerYPosition, $footerLine1, null, 10, array(0, 0, 0));
				$pdf->getDomPDF()->getCanvas()->page_text(30, $footerYPosition + 15, $footerLine2, null, 10, array(0, 0, 0));
				$canvas = $pdf->getDomPDF()->getCanvas();
				// $imagePath = public_path('backend/images/india-org.jpg');
				// $canvas->image($imagePath, 100, 300, 400, 400, 'png'); 

				// $pdf->getDomPDF()->getCanvas()->get_cpdf();
				$pdf->save(public_path($flname));
			} elseif ($user->ref_operator_type_id == 4) // WH
			{
				$products = getProductByWH($appliedscop->at_user_id);
				$pdf = PDF::loadView('admin/usermanagement/pdf/scopeCertificateWH', compact('user', 'data2', 'products'));


				$pdf->getDomPDF()->getCanvas()->page_text(520, 800, "Page: {PAGE_NUM} of {PAGE_COUNT}", null, 12, array(0, 0, 0));
				$pdf->getDomPDF()->getCanvas()->page_text(30, 800, "Serial Number:", null, 12, array(0, 0, 0));
				$pdf->getDomPDF()->getCanvas()->page_text(112, 800, $serialNumber, null, 12, array(255, 0, 0));
				$footerYPosition = 770;
				$footerLine1 = Auth::guard('misadmin')->user()->first_name . ' ' . Auth::guard('misadmin')->user()->last_name;
				$footerLine2 = Auth::guard('misadmin')->user()->address;
				$pdf->getDomPDF()->getCanvas()->page_text(30, $footerYPosition, $footerLine1, null, 10, array(0, 0, 0));
				$pdf->getDomPDF()->getCanvas()->page_text(30, $footerYPosition + 15, $footerLine2, null, 10, array(0, 0, 0));
				$canvas = $pdf->getDomPDF()->getCanvas();
				// $imagePath = public_path('backend/images/india-org.jpg');
				// $canvas->image($imagePath, 100, 300, 400, 400, 'png'); 

				// $pdf->getDomPDF()->getCanvas()->get_cpdf();
				$pdf->save(public_path($flname));
			} elseif ($user->ref_operator_type_id == 5) //TRD
			{

				$products = TradersProductDetail::where('at_user_id', $appliedscop->at_user_id)->get();
				$warehouse = TraderGeoTaggingWarehouseUnitDetails::where('at_user_id', $appliedscop->at_user_id)->get();
				$pdf = PDF::loadView('admin/usermanagement/pdf/scopeCertificateTRD', compact('user', 'data2', 'products', 'warehouse'));
				$pdf->getDomPDF()->getCanvas()->page_text(520, 800, "Page: {PAGE_NUM} of {PAGE_COUNT}", null, 12, array(0, 0, 0));
				$pdf->getDomPDF()->getCanvas()->page_text(30, 800, "Serial Number:", null, 12, array(0, 0, 0));
				$pdf->getDomPDF()->getCanvas()->page_text(112, 800, $serialNumber, null, 12, array(255, 0, 0));
				$footerYPosition = 770;
				$footerLine1 = Auth::guard('misadmin')->user()->first_name . ' ' . Auth::guard('misadmin')->user()->last_name;
				$footerLine2 = Auth::guard('misadmin')->user()->address;
				$pdf->getDomPDF()->getCanvas()->page_text(30, $footerYPosition, $footerLine1, null, 10, array(0, 0, 0));
				$pdf->getDomPDF()->getCanvas()->page_text(30, $footerYPosition + 15, $footerLine2, null, 10, array(0, 0, 0));
				$canvas = $pdf->getDomPDF()->getCanvas();
				// $imagePath = public_path('backend/images/india-org.jpg');
				// $canvas->image($imagePath, 100, 300, 400, 400, 'png'); 

				// $pdf->getDomPDF()->getCanvas()->get_cpdf();
				$pdf->save(public_path($flname));
			} elseif ($user->ref_operator_type_id == 6) // PROCESSOR
			{

				$products = AtProProductsDetails::where('at_user_id', $appliedscop->at_user_id)->get();
				$pdf = PDF::loadView('admin/usermanagement/pdf/scopeCertificatePRO', compact('user', 'data2', 'products', 'serialNumber'));
				$pdf->getDomPDF()->getCanvas()->page_text(520, 800, "Page: {PAGE_NUM} of {PAGE_COUNT}", null, 12, array(0, 0, 0));
				$pdf->getDomPDF()->getCanvas()->page_text(30, 800, "Serial Number:", null, 12, array(0, 0, 0));
				$pdf->getDomPDF()->getCanvas()->page_text(112, 800, $serialNumber, null, 12, array(255, 0, 0));
				$footerYPosition = 770;
				$footerLine1 = Auth::guard('misadmin')->user()->first_name . ' ' . Auth::guard('misadmin')->user()->last_name;
				$footerLine2 = Auth::guard('misadmin')->user()->address;
				$pdf->getDomPDF()->getCanvas()->page_text(30, $footerYPosition, $footerLine1, null, 10, array(0, 0, 0));
				$pdf->getDomPDF()->getCanvas()->page_text(30, $footerYPosition + 15, $footerLine2, null, 10, array(0, 0, 0));
				$canvas = $pdf->getDomPDF()->getCanvas();
				// $imagePath = public_path('backend/images/india-org.jpg');
				// $canvas->image($imagePath, 100, 300, 400, 400, 'png'); 


				// $pdf->getDomPDF()->getCanvas()->get_cpdf();

				$pdf->save(public_path($flname));
			}

			//dd('yes');
			$data = array(
				'accreditation_agency_no' => '',
				'accreditation_agency_name' => '',
				'scope_certificate_no' => getScopeCerNo($appliedscop->at_user_id, $appliedscop->ref_operator_type_id),
				'scope_for' => "Production",
				'is_renewed' => '0',
				'validity_start_date' => $request->certification_date,
				// 'validity_end_date' => date('Y-m-d', strtotime('+1 years')),
				'validity_end_date' => date('Y-m-d', strtotime('+1 year -1 day')),
				'barcode' => $qrcode,
				'file_name' => $flname,
				'remarks' => '',
				'status' => 1,
				'updated_by' => Auth::guard('misadmin')->user()->id,
				'updated_at' => date('Y-m-d H:i:s'),

			);
			$saveData = CertificateStandardDetail::where('id', $request->hid)->update($data);
			if ($saveData) {
				Alert::success('Success', "Scope Generated Successfully.");
			} else {
				Alert::success('Error', "Scope not Generated!!.");
			}
			return redirect()->route('superadmin.issuedScopeCertificateList')->with('loader', true);
		} catch (Exception $e) {
			return redirect()->back();
		} catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
			return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
		}
	}

	public function renewalScopeCertificateList(Request $request)
	{
		try {
			$userId = Auth::id();

			//$list = CertificateStandardDetail::where('is_renewed',1)
			//->get();
			$list = CertificateStandardDetail::whereHas('getuser', function ($q) {
				return $q->where('created_by', Auth::id());
			})
				->where('is_renewed', 1)
				->get();
			// pra($list);
			if ($request->ajax()) {
				return Datatables::of($list)
					->addIndexColumn()
					->addColumn('registration_no', function ($row) {
						return 'Not Alloted';
					})
					->addColumn('name', function ($row) {
						return ucwords($row->getuser->first_name) ?? ''; //date('d-m-Y',strtotime($row->created_at));
					})
					->addColumn('programme', function ($row) {
						return 'NPOP';
					})
					->addColumn('opr_type', function ($row) {
						return getOperatorTypeById($row->ref_operator_type_id);
					})
					->addColumn('validity_start_date', function ($row) {
						return date('d-m-Y', strtotime($row->validity_start_date));
					})
					->addColumn('validity_end_date', function ($row) {
						return date('d-m-Y', strtotime($row->validity_end_date));
					})
					->addColumn('status', function ($row) {
						return $row->is_renewed == 1 ? "Pending" : "Active";
					})
					->addColumn('action', function ($row) {
						$actionBtn = '';


						// if(Gate::check('scope_approve')){
						$actionBtn .= '<a href=' . route('superadmin.usermanagement.deptUser.view', [$row->at_user_id]) . ' target="_blank"><span><i class="mdi mdi-eye text-muted fs-24 align-middle me-1" data-toggle="tooltip"  title="View User"></i></span></a>';

						if ($row->ref_operator_type_id == 2) {
							if ($row->status == 1) {
								$actionBtn .= '<a download href=' . asset('public' . $row->file_name) . '><span><i class="mdi mdi-file-certificate text-info fs-24 align-middle me-1" data-toggle="tooltip" title="Download Scope certificate"></i></span></a>';
							} else {
								$actionBtn .= '<a href=' . route('superadmin.scopeCertificateGenerate', $row->id) . '><span><i class="mdi mdi-file-certificate text-muted fs-24 align-middle me-1" data-toggle="tooltip" title="Generate Scope certificate"></i></span></a>';
							}
						} else if ($row->ref_operator_type_id == 3) {
							// if ip
							if ($row->status == 1) {
								$actionBtn .= '<a download href=' . asset('public' . $row->file_name) . '><span><i class="mdi mdi-file-certificate text-info fs-24 align-middle me-1" data-toggle="tooltip" title="Download Scope certificate"></i></span></a>';
							} else {
								$actionBtn .= '<a href=' . route('superadmin.scopeCertificateGenerate', $row->id) . '><span><i class="mdi mdi-file-certificate text-muted fs-24 align-middle me-1" data-toggle="tooltip" title="Generate Scope certificate"></i></span></a>';
							}
						} else if ($row->ref_operator_type_id == 4) {
							// if wh
							if ($row->status == 1) {
								$actionBtn .= '<a download href=' . asset('public' . $row->file_name) . '><span><i class="mdi mdi-file-certificate text-info fs-24 align-middle me-1" data-toggle="tooltip" title="Download Scope certificate"></i></span></a>';
							} else {
								$actionBtn .= '<a href=' . route('superadmin.scopeCertificateGenerate', $row->id) . '><span><i class="mdi mdi-file-certificate text-muted fs-24 align-middle me-1" data-toggle="tooltip" title="Generate Scope certificate"></i></span></a>';
							}
						} else if ($row->ref_operator_type_id == 5) {
							// if trader
							if ($row->status == 1) {
								$actionBtn .= '<a download href=' . asset('public' . $row->file_name) . '><span><i class="mdi mdi-file-certificate text-info fs-24 align-middle me-1" data-toggle="tooltip" title="Download Scope certificate"></i></span></a>';
							} else {
								$actionBtn .= '<a href=' . route('superadmin.scopeCertificateGenerate', $row->id) . '><span><i class="mdi mdi-file-certificate text-muted fs-24 align-middle me-1" data-toggle="tooltip" title="Generate Scope certificate"></i></span></a>';
							}
						} else {
							// if processor
							//$actionBtn.= '<a href='.route('superadmin.usermanagement.deptUser.proview',[$row->at_user_id]).' target="_blank"><span><i class="mdi mdi-eye text-muted fs-24 align-middle me-1" data-toggle="tooltip" title="View User"></i></span></a>';
							$actionBtn .= '<a href=' . route('superadmin.scopeCertificateGenerate', $row->id) . '><span><i class="mdi mdi-file-certificate text-muted fs-24 align-middle me-1" data-toggle="tooltip" title="Generate Scope certificate"></i></span></a>';
						}

						// }
						return $actionBtn;
					})
					->rawColumns(['action'])
					->make(true);
			}

			return view('admin/scope_certificate/renewal_scope_certificate_list');
		} catch (Exception $e) {
			return redirect()->back();
		} catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
			return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
		}
	}
}

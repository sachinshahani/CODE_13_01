<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AtAccrediationDocumentUpload;
use App\Models\User;
use App\Models\RefState;
use App\Models\RefDistrict;
use App\Models\RefRegion;
use App\Models\RefVillage;
use App\Models\RoleUser;
use App\Models\UserInspector;
use App\Models\AtFarmerRegDetail;
use App\Models\MandatorRegister;
use App\Models\AtAccrediationEmployeeDetails;
use App\Models\AtAccrediationCertificationBody;
use App\Models\RefSupportingDocumentaster;
use App\Models\AtCbaApplicationDdetailForAamendment;
use Illuminate\Http\Request;
use RealRashid\SweetAlert\Facades\Alert;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\Auth;
use DB;

use function Ramsey\Uuid\v1;

class AccreditationController extends Controller
{



    public function processApplication(Request $request)
    {

        if ($request->ajax()) {

            $query = AtAccrediationCertificationBody::query()
                  ->leftJoin('at_accrediation_certificationbody_emp_details', 'at_accrediation_certificationbody_master.id', '=', 'at_accrediation_certificationbody_emp_details.at_accrediation_certificationbody_master_id');

                  $finalData = $query->select([
                    'at_accrediation_certificationbody_master.*',
                    'at_accrediation_certificationbody_emp_details.name',

                ])->get();

            return Datatables::of($finalData)
                ->addIndexColumn()
                // ->addColumn('ref_no', function ($row) {

                //     return $row->name_of_inspector ?? '';
                // })
                ->addColumn('name', function ($row) {
                    return $row->name ?? '';
                })->addColumn('org_name', function ($row) {
                    return $row->first_name ?? '';
                })->addColumn('org_address', function ($row) {

                    return  $row->cb_registered_office_address ?? '';

                })->addColumn('application_type', function ($row) {

                    return  $row->application_type ?? '';
                })->addColumn('scope', function ($row) {

                    return  'Aquacuture Production';
                })->addColumn('application_date', function ($row) {

                    return  date('d/m/Y', strtotime($row->created_at)) ?? '';

                })
                ->addColumn('action', function ($row) {

                    $addEditDetailButton =  '<a href=' . route('superadmin.processApplicationForm', [$row->id]) . '><span><i class="mdi mdi-pencil text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Edit Individual User"></i></span></a>';

                    return $addEditDetailButton;
                })
                ->rawColumns(['action', 'role'])
                ->make(true);
        }

        return view('admin.accreditation.process-application-list');
    }

    public function processApplicationForm()
    {

        $data = RefSupportingDocumentaster::all();
        $userid = Auth::user()->id;
        $userData = User::where('id', $userid)->first();
        $app = AtAccrediationCertificationBody::where('at_user_id', $userData->id)->first();
        $cbodyData = AtAccrediationEmployeeDetails::where('created_by', $userid)->whereNull('deleted_at')->get();
        $acDocData = AtAccrediationDocumentUpload::where('created_by', $userid)->get();

  //dd( $app);

        return view('admin.accreditation.process-application-form', compact('data', 'acDocData', 'cbodyData', 'userid', 'app'));
    }

    public function processApplicationFormSubmit(Request $request)
{
    try {
        $app_id = $request->application_id;

        // Handle the signature upload
        if (!empty($request->file('signature'))) {
            if (!empty($request->signature_edit)) {
                $imagePath = public_path('accredtiation/signature/') . $request->signature_edit;
                deleteOldImage($request->signature_edit, $imagePath);
            }
            $documentRootPath = 'public/accredtiation/signature';
            $file_path = time() . rand() . '.' . $request->file('signature')->getClientOriginalExtension();
            $request->file('signature')->move($documentRootPath, $file_path);
            $signature = $file_path;
        } else {
            $signature = $request->signature_edit;
        }

        // Prepare the data for the accreditation certification body
        $data = [
            'accrediation_agency_no' => "NPOP/NAB/" . Auth::user()->id,
            'at_user_id' => Auth::user()->id,
            'category_type' => !empty($request->category_type) ? $request->category_type : NULL,
            'ref_designation_master_id' => !empty($request->ref_designation_master_id) ? $request->ref_designation_master_id : NULL,
            'application_type' => !empty($request->application_type) ? $request->application_type : NULL,
            'name' => !empty($request->name) ? $request->name : NULL,
            'cb_head_name' => !empty($request->cb_head_name) ? $request->cb_head_name : NULL,
            'contact_person_first_name' => !empty($request->contact_person_first_name) ? $request->contact_person_first_name : NULL,
            'contact_person_mobile_number' => !empty($request->contact_person_mobile_number) ? $request->contact_person_mobile_number : NULL,
            'contact_person_email' => !empty($request->contact_person_email) ? $request->contact_person_email : NULL,
            'is_your_registered' => !empty($request->is_your_registered) ? $request->is_your_registered : NULL,
            'cb_address_type' => !empty($request->cb_address_type) ? $request->cb_address_type : NULL,
            'cb_registered_office_address' => !empty($request->cb_registered_office_address) ? $request->cb_registered_office_address : NULL,
            'country' => !empty($request->country) ? $request->country : NULL,
            'ref_state_id' => !empty($request->ref_state_id) ? $request->ref_state_id : NULL,
            'ref_district_id' => !empty($request->ref_district_id) ? $request->ref_district_id : NULL,
            'ref_block_tehsil_id' => !empty($request->ref_block_tehsil_id) ? $request->ref_block_tehsil_id : NULL,
            'ref_village_id' => !empty($request->ref_village_id) ? $request->ref_village_id : NULL,
            'pin' => !empty($request->pin) ? $request->pin : NULL,
            'office_phone_number' => !empty($request->office_phone_number) ? $request->office_phone_number : NULL,
            'fax' => !empty($request->fax) ? $request->fax : NULL,
            'cb_email_id' => !empty($request->cb_email_id) ? $request->cb_email_id : NULL,
            'website_address' => !empty($request->website_address) ? $request->website_address : NULL,
            'legal_status' => !empty($request->legal_status) ? $request->legal_status : NULL,
            'year_of_establishment' => !empty($request->year_of_establishment) ? $request->year_of_establishment : NULL,
            'date_of_establishment' => !empty($request->date_of_establishment) ? $request->date_of_establishment : NULL,
            'gst_no' => !empty($request->gst_no) ? $request->gst_no : NULL,
            'descriptions' => !empty($request->descriptions) ? $request->descriptions : NULL,
            'declaration_date' => !empty($request->declaration_date) ? $request->declaration_date : NULL,
            'declaration_signature' => $signature, // Assuming signature has already been processed
            'declaration_payment_mode' => !empty($request->declaration_payment_mode) ? $request->declaration_payment_mode : NULL,
            'created_by' => Auth::user()->id,
        ];

        // Create or update the accreditation certification body
        $accrediationCertificationBody = AtAccrediationCertificationBody::Create(
            // ['id' => $app_id], // condition to check
            $data // data to be updated or created
        );

        if ($accrediationCertificationBody) {
            // Process employee details
            foreach ($request->employee_type as $key => $val) {
                $bio_data = '';

                if (!empty($request->file('upload_biodata')[$key])) {
                    if (!empty($request->bio_data[$key])) {
                        $imagePath = public_path('accredtiation/upload_biodata/') . $request->bio_data[$key];
                        deleteOldImage($request->bio_data[$key], $imagePath);
                    }

                    $documentRootPath = 'public/accredtiation/upload_biodata';
                    $file_path = time() . rand() . '.' . $request->file('upload_biodata')[$key]->getClientOriginalExtension();
                    $request->file('upload_biodata')[$key]->move($documentRootPath, $file_path);
                    $bio_data = $file_path;
                } else {
                    if (!empty($request->bio_data[$key])) {
                        $bio_data = $request->bio_data[$key];
                    }
                }

                $createLabData = [
                    'employee_type' => $val,
                    'at_accrediation_certificationbody_master_id' => $accrediationCertificationBody->id,
                    'name' => !empty($request->name[$key]) ? $request->name[$key] : NULL,
                    'ref_designation_master_id' => !empty($request->ref_designation_master_id[$key]) ? $request->ref_designation_master_id[$key] : NULL,
                    'qualification' => !empty($request->qualification[$key]) ? $request->qualification[$key] : NULL,
                    'total_experience' => !empty($request->total_experience[$key]) && is_numeric($request->total_experience[$key]) ? $request->total_experience[$key] : NULL,
                    'date_of_joining' => !empty($request->date_of_joining[$key]) ? $request->date_of_joining[$key] : NULL,
                    'training' => !empty($request->training[$key]) ? $request->training[$key] : NULL,
                    'upload_biodata' => $bio_data,
                    'created_at' => now(),
                    'created_by' => Auth::user()->id,
                ];

                // Create the employee details
                AtAccrediationEmployeeDetails::create($createLabData);
            }

            Alert::success('Success', 'Data saved successfully');
            return redirect()->back();
        } else {
            Alert::error('Error', 'Something went wrong, please try again later');
            return redirect()->back();
        }
    } catch (Exception $e) {
        Log::error($e);
        Alert::error('Error', 'Something went wrong, please try again later');
        return redirect()->back();
    }
}


    public function saveCertificationBody(Request $request)
    {
        $data = new AtAccrediationCertificationBody;

        if ($request->hasFile('upload_biodata')) {
            if (!empty($request->document_upload)) {
                $imagePath = public_path('accredtiation/upload_biodata/') . $request->document_upload;
                deleteOldImage($request->document_upload_edit, $imagePath);
            }
            $documentRootPath = 'public/accredtiation/upload_biodata';
            $file_path = time() . rand() . '.' . $request->file('upload_biodata')->getClientOriginalExtension();
            $request->file('upload_biodata')->move($documentRootPath, $file_path);
            $document_upload_photo = $file_path;
        } else {
            $document_upload_photo = $request->document_upload_edit;
        }
        $data->save();


        return response()->json(['message' => 'Data saved successfully']);
    }


    public function upload(Request $request)
    {
        $userId = auth()->user()->id;
       // dd($request->all());
        if ($request->hasFile('document_upload')) {
            if (!empty($request->document_upload)) {
                $imagePath = public_path('accredtiation/accrediation_document/') . $request->document_upload;
                deleteOldImage($request->document_upload_edit, $imagePath);
            }
            $documentRootPath = 'public/accredtiation/accrediation_document';
            $file_path = time() . rand() . '.' . $request->file('document_upload')->getClientOriginalExtension();
            $request->file('document_upload')->move($documentRootPath, $file_path);
            $document_upload_photo = $file_path;
        } else {
            $document_upload_photo = $request->document_upload_edit;
        }

        $document = new AtAccrediationDocumentUpload;
        $document->at_accrediation_certificationbody_master_id = !empty($request->application_id) ? $request->application_id : NULL;
        $document->ref_cba_supporting_document_master_id = !empty($request->document_id) ? $request->document_id : NULL;
        $document->document_upload = !empty($document_upload_photo) ? $document_upload_photo : NULL;
        $document->created_by = !empty($userId) ? $userId : Auth::user()->id; // Fallback to Auth::user()->id if userId is empty.
        
      //dd($document);
        $document->save();

        if (!empty($document)) {
            $return_file_path = url('/' . $documentRootPath . "/" . $file_path);
            return response()->json(['success' => 'done', 'path' => $return_file_path, 'file' => $document_upload_photo, 'id' => $document->id]);
        } else {
            return response()->json(['success' => 'No file provided.'], 400);
        }
    }


    public function deleteFile(Request $request)
    {

        try {

            $id = $request->id;
            $user = AtAccrediationDocumentUpload::find($id);
            $user->deleted_at = date('Y-m-d H:i:s');
            $user->save();
            //dd($user->ref_cba_supporting_document_master_id);
            return json_encode(['message' => 'done']);
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function bioDataDelete(Request $request)
    {

        try {

            $id = $request->id;
            $user = AtAccrediationEmployeeDetails::find($id);
            $user->deleted_at = date('Y-m-d H:i:s');
            $user->save();
          //  dd($user->at_accrediation_certificationbody_master_id);
            return json_encode(['message' => 'done']);
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function accrRenewal()
    {

        return view('admin.accreditation.renewal');
    }
    public function accrAmendment()
    {

        $userid = Auth::user();

        return view('admin.accreditation.amendment', compact('userid'));
    }
    public function accrAmendmentSave(Request $request)
    {
        //---------name change file-----
        if ($request->hasFile('name_document_upload')) {
            if (!empty($request->name_document_upload)) {
                $imagePath = public_path('accredtiation/amendment/name_document/') . $request->name_document_upload;
                deleteOldImage($request->name_document_upload_edit, $imagePath);
            }
            $documentRootPath = 'public/accredtiation/amendment/name_document';
            $file_path = time() . rand() . '.' . $request->file('name_document_upload')->getClientOriginalExtension();
            $request->file('name_document_upload')->move($documentRootPath, $file_path);
            $document_upload_photo = $file_path;
        } else {
            $document_upload_photo = $request->name_document_upload_edit;
        }

        //---------Address change file-----
        if ($request->hasFile('address_document_upload')) {
            if (!empty($request->address_document_upload)) {
                $imagePath = public_path('accredtiation/amendment/address_document/') . $request->address_document_upload;
                deleteOldImage($request->name_document_upload_edit, $imagePath);
            }
            $documentRootPath = 'public/accredtiation/amendment/address_document';
            $file_path = time() . rand() . '.' . $request->file('address_document_upload')->getClientOriginalExtension();
            $request->file('address_document_upload')->move($documentRootPath, $file_path);
            $address_document_upload = $file_path;
        } else {
            $address_document_upload = $request->name_document_upload_edit;
        }
        //---------logo change file-----
        if ($request->hasFile('logo_change_document_upload')) {
            if (!empty($request->logo_change_document_upload)) {
                $imagePath = public_path('accredtiation/amendment/logo/') . $request->logo_change_document_upload;
                deleteOldImage($request->name_document_upload_edit, $imagePath);
            }
            $documentRootPath = 'public/accredtiation/amendment/logo';
            $file_path = time() . rand() . '.' . $request->file('logo_change_document_upload')->getClientOriginalExtension();
            $request->file('logo_change_document_upload')->move($documentRootPath, $file_path);
            $logo_change_upload = $file_path;
        } else {
            $logo_change_upload = $request->name_document_upload_edit;
        }
        //---------legal status change file-----
        if ($request->hasFile('legal_status_document_upload')) {
            if (!empty($request->legal_status_document_upload)) {
                $imagePath = public_path('accredtiation/amendment/legal-status-document/') . $request->legal_status_document_upload;
                deleteOldImage($request->name_document_upload_edit, $imagePath);
            }
            $documentRootPath = 'public/accredtiation/amendment/legal-status-document';
            $file_path = time() . rand() . '.' . $request->file('legal_status_document_upload')->getClientOriginalExtension();
            $request->file('legal_status_document_upload')->move($documentRootPath, $file_path);
            $legel_status_upload = $file_path;
        } else {
            $legel_status_upload = $request->name_document_upload_edit;
        }
        //---------Processing and Handling change file-----
        if ($request->hasFile('supporting_document_upload')) {
            if (!empty($request->supporting_document_upload)) {
                $imagePath = public_path('accredtiation/amendment/proccess-and-handling-document/') . $request->supporting_document_upload;
                deleteOldImage($request->name_document_upload_edit, $imagePath);
            }
            $documentRootPath = 'public/accredtiation/amendment/proccess-and-handling-document';
            $file_path = time() . rand() . '.' . $request->file('supporting_document_upload')->getClientOriginalExtension();
            $request->file('supporting_document_upload')->move($documentRootPath, $file_path);
            $proccess_upload = $file_path;
        } else {
            $proccess_upload = $request->name_document_upload_edit;
        }

        //---------accreditation_validity change file-------------
        if ($request->hasFile('extended_accreditation_validity_document_upload')) {
            if (!empty($request->extended_accreditation_validity_document_upload)) {
                $imagePath = public_path('accredtiation/amendment/extended-of-Accreditation-document/') . $request->extended_accreditation_validity_document_upload;
                deleteOldImage($request->name_document_upload_edit, $imagePath);
            }
            $documentRootPath = 'public/accredtiation/amendment/extended-of-Accreditation-document';
            $file_path = time() . rand() . '.' . $request->file('extended_accreditation_validity_document_upload')->getClientOriginalExtension();
            $request->file('extended_accreditation_validity_document_upload')->move($documentRootPath, $file_path);
            $extended_upload = $file_path;
        } else {
            $extended_upload = $request->name_document_upload_edit;
        }







        //--------------Name Change---------------------
        $amendment = new AtCbaApplicationDdetailForAamendment;
        $amendment->at_user_id = Auth::user()->id;
        // $amendment->existing_name = $request->input('existing_name');
        $amendment->amendment_name = $request->input('amendment_name');
        $amendment->name_document_upload = $document_upload_photo;
        $amendment->remarks = $request->input('remarks');

        //--------------Address change-------------------
        $amendment->address = $request->input('address');
        $amendment->ref_state_id = $request->input('ref_state_id');
        $amendment->ref_district_id = $request->input('ref_district_id');
        $amendment->city_name = $request->input('city_name');
        $amendment->pin = $request->input('pin');
        $amendment->address_document_upload = $address_document_upload;
        $amendment->remarks = $request->input('remarks');


        //----------logo change------------
        $amendment->logo_change_document_upload = $logo_change_upload;
        $amendment->remarks = $request->input('remarks');

        //---------legal status change-----------
        $amendment->legal_status = $request->input('legal_status');
        $amendment->legal_status_document_upload = $legel_status_upload;
        $amendment->remarks = $request->input('remarks');

        //-------------- Processing and Handling change----------------

        $amendment->supporting_document_upload = $proccess_upload;
        $amendment->remarks = $request->input('remarks');


        //---------------Accreditation Chnage-------------------------
        $amendment->accreditation_existing_validity = $request->input('accreditation_existing_validity');
        $amendment->extended_accreditation_validity = $request->input('extended_accreditation_validity');
        $amendment->extended_accreditation_validity_document_upload = $extended_upload;
        $amendment->remarks = $request->input('remarks');

        // dd($amendment);
        $amendment->save();
        if (!empty($amendment)) {
            // $return_file_path = url('/'.$documentRootPath."/".$file_path);
            return redirect()->back()->with('success', 'Data stored successfully.');
        }
    }

    public function accrCertificateList()
    {

        return view('admin.accreditation.certificate-list');
    }

    public function accrAnnualReport()
    {

        return view('admin.accreditation.annual-report');
    }
}

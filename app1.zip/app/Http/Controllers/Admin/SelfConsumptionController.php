<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\AtOpCertificateStandardDetail;
use App\Models\AtProProcessingUnit;
use App\Models\AtOpTransactionCertificateEntry;
use App\Models\AtFarmerRegDetail;
use App\Models\AtIpFarmerRegDetail;
use App\Models\AtBatchDetail;
use App\Models\AtBatchCreation;
use App\Models\RefProduct;
use Yajra\DataTables\DataTables;
use App\Models\AtOpTransactionVsTransactionProduct;
use App\Models\AtTcSelfConsumed;
use App\Models\User;
use Illuminate\Support\Facades\Validator;
use RealRashid\SweetAlert\Facades\Alert;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class SelfConsumptionController extends Controller
{

    public function listbatchdetails()
    {
        return view("admin.self_consumption.consumption-for-batch-details");
    }

    public function listofregistersearch(Request $request)
    {
        // Your existing code
        $returnData = array();
        $query = User::join('at_op_certificate_standard_details as b', 'b.at_user_id', '=', 'at_user.id')
            ->where('at_user.registration_no', 'LIKE', "%{$request->registration_no}%");

        if (!empty($request->scope_for)) {
            $query->where('b.scope_for', 'LIKE', "%{$request->scope_for}%");
        }

        $results = $query->select('at_user.id', 'at_user.first_name', 'b.scope_for', 'b.scope_certificate_no', 'b.validity_start_date', 'b.validity_end_date')
            ->first();

        $operatorDetail = array(
            'operator_name' => $results->first_name ?? '',
            'scope_for' =>  $results->scope_for ?? '',
            'scope_certificate_no' => $results->scope_certificate_no ?? '',
            'validity_from' => date('Y-m-d', strtotime($results->validity_start_date ?? '')),
            'validity_to' => date('Y-m-d', strtotime($results->validity_end_date ?? ''))
        );

        //$batchdetails=  AtBatchDetail::where('at_user_id',$results->id)->get();
        $batchdetails = AtBatchDetail::join('at_batch_creation', 'at_batch_creation.id', '=', 'at_batch_details.batch_id')
            ->select('at_batch_details.*', 'at_batch_creation.organic_status')
            ->where('at_batch_details.at_user_id', $results->id)
            ->get();


        //dd($batchdetails);

        if (count($batchdetails) > 0) {
            foreach ($batchdetails as $key => $res) {
                $returnData[$key]['checkbox'] = '<input type="checkbox" name="ss_id[]" class="ss_id" value="' . $res->id . '">';
                $returnData[$key]['batch_id'] = '<input type="text" readonly class=" form-control" name="" value="' . time() . ($res->id ?? '') . '">';
                $returnData[$key]['product_name'] = '<input type="text" readonly class=" form-control" name="" value="' . ($res->product_name ?? '') . '">';
                $returnData[$key]['type'] = '<input type="text" readonly class=" form-control" name="" value="Lot">';
                $returnData[$key]['total_quantity'] =  '<input type="text" readonly class=" form-control" name="" value="' . ($res->total_quantity ?? '') . '">';
                $returnData[$key]['quantity_source'] = '<input type="text" readonly class=" form-control" name="" value="' . ($res->quantity_source ?? '') . '">';
                $returnData[$key]['used_quantity'] =  '<input type="text" readonly class=" form-control" name="" value="' . ($res->used_quantity ?? '') . '">';
                $returnData[$key]['organic_status'] = '<input type="text" readonly class="form-control" name="" value="' . getRefOrganicStatuscodeByname($res->organic_status ?? '') . '">' .
                    '<input type="hidden" class="organic_status form-control" name="organic_status[]" value="' . ($res->organic_status ?? '') . '">';

                $returnData[$key]['available_quantity'] = '<input type="text" readonly class="available_quantity form-control" name="available_quantity[]" value="' . ($res->available_quantity ?? '') . '">';
                $returnData[$key]['self_consumption'] = '<input type="text" class="self_consumption form-control" name="self_consumption[]"  >';
                $returnData[$key]['remark'] = '<input type="text" class="remark form-control" name="remark[]">';
                $returnData[$key]['at_user_id'] = '<input type="hidden" class="at_user_id form-control" name="at_user_id[]" value="' . $res->at_user_id . '" >';
                                                  
            }


            // Add the dummy data to the response
            $returnData['operator_detail'] = $operatorDetail;
            $returnData['table_data'] = $batchdetails;

            // Return success response with data
            return response()->json(['msg' => 'success', 'data' => $returnData]);
        } else {
            return response()->json(['msg' => 'error', 'data' => 'No Record found.']);
        }
    }
    public function consumptionsave(Request $request)
    {
         //dd($request->all());
        try {
            if (!empty($request->ids)) {
                $ids = $request->ids;
                $available_quantity = $request->available_quantity;
                $self_consumption = $request->self_consumption;
                $remark = $request->remark;
                $organic_status = $request->organic_status;
                $at_user_id = $request->at_user_id;
                foreach ($ids as $key => $id) {
                    $refProduct = RefProduct::find($id);

                    $refProductId = $refProduct ? $id : null;

                    $data = [

                        
                        'self_qty_consumed' => $self_consumption[$key],
                        'remark' => $remark[$key],
                        'ref_product_id' => $refProductId,
                        'is_read' => '1',
                        'ref_organic_status_master_id' => $organic_status[$key],
                        'created_at' => now(),
                        'updated_at' => now(),
                        'created_by' => $at_user_id[$key],
                        'updated_by' => Auth::guard('misadmin')->user()->id
                    ];
                   // dd($data);
                    AtTcSelfConsumed::create($data);
                }

                return response()->json(['status' => '1', 'message' => 'Data saved successfully.']);
            } else {
                return response()->json(['status' => '0', 'message' => 'Please try again later.']);
            }
        } catch (Exception $e) {
            Log::error($e);
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    public function listconsumptionfortc()
    {
        return view("admin.self_consumption.consumption-for-tc");
    }

    public function listofregistersearchTcConsumption(Request $request)
    {
        // Your existing code
        $returnData = array();
        $results = User::join('at_op_certificate_standard_details as b', 'b.at_user_id', 'at_user.id')
            ->join('at_op_transaction_vs_transaction_product', 'at_op_transaction_vs_transaction_product.created_by', '=', 'at_user.id')
            ->where('at_user.registration_no', 'LIKE', "%{$request->registration_no}%")
            ->select('at_user.id', 'at_user.first_name', 'b.scope_for', 'b.scope_certificate_no', 'b.validity_start_date', 'b.validity_end_date', 'at_op_transaction_vs_transaction_product.transaction_certificate_no')
            ->first();
        //dd($results);

        $operatorDetail = array(
            'operator_name' => $results->first_name,
            'scope_for' => $results->scope_for ?? '',
            'scope_certificate_no' => $results->scope_certificate_no,
            'validity_from' => date('Y-m-d', strtotime($results->validity_start_date)),
            'validity_to' => date('Y-m-d', strtotime($results->validity_end_date))
        );

        $batchdetails = AtBatchDetail::join('at_batch_creation', 'at_batch_creation.id', '=', 'at_batch_details.batch_id')
            ->join('at_tc_self_consumed', 'at_tc_self_consumed.created_by', '=', 'at_batch_details.at_user_id')
            ->join('at_op_transaction_vs_transaction_product', 'at_op_transaction_vs_transaction_product.created_by', '=', 'at_batch_details.at_user_id')
            ->select('at_batch_details.*', 'at_batch_creation.organic_status', 'at_batch_creation.quantity', 'at_tc_self_consumed.self_qty_consumed', 'at_op_transaction_vs_transaction_product.transaction_certificate_no')
            ->where('at_batch_details.at_user_id', $results->id)
            ->limit(7)
            ->get();

        //dd($batchdetails);

        if (count($batchdetails) > 0) {
            foreach ($batchdetails as $key => $res) {
                $returnData[$key]['checkbox'] = '<input type="checkbox" name="ss_id[]" class="ss_id" value="' . $res->id . '">';
                $returnData[$key]['transaction_certificate_no'] =  '<input type="text" readonly class="tc_no form-control" name="tc_no[]" value="' . ($res->transaction_certificate_no ?? '') . '">';
                $returnData[$key]['product_name'] = '<input type="text" readonly class=" form-control" name="" value="' . ($res->product_name ?? '') . '">';
                $returnData[$key]['type'] = '<input type="text" readonly class=" form-control" name="" value="Lot">';
                $returnData[$key]['total_quantity'] =  '<input type="text" readonly class=" form-control" name="" value="' . ($res->total_quantity ?? '') . '">';
                $returnData[$key]['quantity_source'] = '<input type="text" readonly class=" form-control" name="" value="' . ($res->quantity_source ?? '') . '">';
                $returnData[$key]['used_quantity'] =  '<input type="text" readonly class=" form-control" name="" value="' . ($res->used_quantity ?? '') . '">';
                $returnData[$key]['organic_status'] = '<input type="text" readonly class="form-control" name="" value="' . getRefOrganicStatusMasterByID($res->organic_status ?? '') . '">' .
                    '<input type="hidden" class="organic_status form-control" name="organic_status[]" value="' . ($res->organic_status ?? '') . '">';

                $returnData[$key]['available_quantity'] = '<input type="text" readonly class="available_quantity form-control" name="available_quantity[]" value="' . ($res->available_quantity ?? '') . '">';
                $returnData[$key]['self_consumption'] = '<input type="text" class="self_consumption form-control" name="self_consumption[]"  >';
                $returnData[$key]['remark'] = '<input type="text" class="remark form-control" name="remark[]">';
                $returnData[$key]['at_user_id'] = '<input type="hidden" class="at_user_id form-control" name="at_user_id[]" value="' . $res->at_user_id . '" >';
            }

            $returnData['operator_detail'] = $operatorDetail;
            $returnData['table_data'] = $batchdetails;

            return response()->json(['msg' => 'success', 'data' => $returnData]);
        } else {
            return response()->json(['msg' => 'error', 'data' => 'No Record found.']);
        }
    }

    public function consumptionsavefortc(Request $request)
    {
       // dd($request->all());
        try {
            if (!empty($request->ids)) {
                $ids = $request->ids;
                $at_user_id = $request->at_user_id;
                $self_consumption = $request->self_consumption;
                $remark = $request->remark;
                $organic_status = $request->organic_status;
                $tc_no = $request->tc_no;


                foreach ($ids as $key => $id) {
                    $refProduct = RefProduct::find($id);

                    $refProductId = $refProduct ? $id : null;

                    $data = [

                        'transaction_certificate_no' => $tc_no[$key],
                        'self_qty_consumed' => $self_consumption[$key],
                        'remark' => $remark[$key],
                        'ref_product_id' => $refProductId,
                        'is_read' => '2',
                        'ref_organic_status_master_id' => $organic_status[$key],
                        'created_at' => now(),
                        'updated_at' => now(),
                        'created_by' => $at_user_id[$key],
                        'updated_by' => Auth::guard('misadmin')->user()->id
                    ];

                  // dd($data);

                    AtTcSelfConsumed::create($data);
                }

                return response()->json(['status' => '1', 'message' => 'Data saved successfully.']);
            } else {
                return response()->json(['status' => '0', 'message' => 'Please try again later.']);
            }
        } catch (Exception $e) {
            Log::error($e);
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    public function viewtclistselfconsumed()
    {
        return view("admin.self_consumption.view-tc-list-self-consumed");
    }
    public function listofregistersearchTc(Request $request)
    {
        // Your existing code
        $returnData = array();
        $results = User::join('at_op_certificate_standard_details as b', 'b.at_user_id', 'at_user.id')
            ->join('at_op_transaction_vs_transaction_product', 'at_op_transaction_vs_transaction_product.created_by', '=', 'at_user.id')
            ->where('at_user.registration_no', 'LIKE', "%{$request->registration_no}%")
            ->select('at_user.id', 'at_user.first_name', 'b.scope_for', 'b.scope_certificate_no', 'b.validity_start_date', 'b.validity_end_date', 'at_op_transaction_vs_transaction_product.transaction_certificate_no')
            ->first();
        //dd($results);

        $operatorDetail = array(
            'operator_name' => $results->first_name,
            'scope_for' => $results->scope_for,
            'scope_certificate_no' => $results->scope_certificate_no,
            'validity_from' => date('Y-m-d', strtotime($results->validity_start_date)),
            'validity_to' => date('Y-m-d', strtotime($results->validity_end_date))
        );

        $batchdetails = AtBatchDetail::join('at_batch_creation', 'at_batch_creation.id', '=', 'at_batch_details.batch_id')
            ->join('at_tc_self_consumed', 'at_tc_self_consumed.created_by', '=', 'at_batch_details.at_user_id')
            ->join('at_op_transaction_vs_transaction_product', 'at_op_transaction_vs_transaction_product.created_by', '=', 'at_batch_details.at_user_id')
            ->select('at_batch_details.*', 'at_batch_creation.organic_status', 'at_batch_creation.quantity', 'at_tc_self_consumed.self_qty_consumed', 'at_op_transaction_vs_transaction_product.transaction_certificate_no')
            ->where('at_batch_details.at_user_id', $results->id)
            ->limit(10)
            ->get();


        //dd($batchdetails);

        if (count($batchdetails) > 0) {
            foreach ($batchdetails as $key => $res) {
                // $returnData[$key]['checkbox'] = '<input type="checkbox" name="ss_id[]" class="ss_id" value="'.$res->id.'">';
                $returnData[$key]['transaction_certificate_no'] = $res->transaction_certificate_no ?? '';
                $returnData[$key]['batch_id'] = $res->batch_id;
                $returnData[$key]['product_name'] = $res->product_name ?? '';
                $returnData[$key]['organic_status'] = getRefOrganicStatusMasterByID($res->organic_status ?? '');
                $returnData[$key]['self_qty_consumed'] = $res->self_qty_consumed ?? '0.00';

                $returnData[$key]['quantity'] = $res->quantity ?? '0.00';
                $returnData[$key]['used_quantity'] = $res->used_quantity ?? '0.00';

                // New parameter to store the result of subtraction
                $returnData[$key]['remaining_quantity'] = $res->quantity - $res->used_quantity ?? '0.00';

                $returnData[$key]['type'] = 'Batch';
                $returnData[$key]['total_quantity'] = $res->total_quantity ?? '0.00';
                $returnData[$key]['quantity_source'] = $res->quantity_source ?? '0.00';
                // $returnData[$key]['organic_status'] = '<input type="number" class="organic_status" name="organic_status[]" value="'.$res->organic_status.'">';
                $returnData[$key]['available_quantity'] = $res->available_quantity ?? '0.00';
                $returnData[$key]['self_consumption'] = '<input type="text" class="self_consumption" name="self_consumption[]" >';
                $returnData[$key]['remark'] = '<input type="text" class="remark" name="remark[]">';
            }


            // Add the dummy data to the response
            $returnData['operator_detail'] = $operatorDetail;
            $returnData['table_data'] = $batchdetails;

            // Return success response with data
            return response()->json(['msg' => 'success', 'data' => $returnData]);
        } else {
            return response()->json(['msg' => 'error', 'data' => 'No Record found.']);
        }
    }

    public function viewlotbatchlistselfconsume()
    {
        return view("admin.self_consumption.view-lot-batch-list-self-consume");
    }

    public function listofregistersearchLot(Request $request)
    {
        // Your existing code
        $returnData = array();
        $results = User::join('at_op_certificate_standard_details as b', 'b.at_user_id', 'at_user.id')
            ->join('at_op_transaction_vs_transaction_product', 'at_op_transaction_vs_transaction_product.created_by', '=', 'at_user.id')
            ->where('at_user.registration_no', 'LIKE', "%{$request->registration_no}%")
            ->select('at_user.id', 'at_user.first_name', 'b.scope_for', 'b.scope_certificate_no', 'b.validity_start_date', 'b.validity_end_date', 'at_op_transaction_vs_transaction_product.transaction_certificate_no')
            ->first();
        //dd($results);

        $operatorDetail = array(
            'operator_name' => $results->first_name,
            'scope_for' => $results->scope_for ?? '',
            'scope_certificate_no' => $results->scope_certificate_no,
            'validity_from' => date('Y-m-d', strtotime($results->validity_start_date)),
            'validity_to' => date('Y-m-d', strtotime($results->validity_end_date))
        );

        $batchdetails = AtBatchDetail::join('at_batch_creation', 'at_batch_creation.id', '=', 'at_batch_details.batch_id')
            ->join('at_tc_self_consumed', 'at_tc_self_consumed.created_by', '=', 'at_batch_details.at_user_id')
            ->join('at_op_transaction_vs_transaction_product', 'at_op_transaction_vs_transaction_product.created_by', '=', 'at_batch_details.at_user_id')
            ->select('at_batch_details.*', 'at_batch_creation.organic_status', 'at_batch_creation.quantity', 'at_tc_self_consumed.self_qty_consumed', 'at_op_transaction_vs_transaction_product.transaction_certificate_no')
            ->where('at_batch_details.at_user_id', $results->id)
            ->limit(10)
            ->get();


       //dd($batchdetails);

        if (count($batchdetails) > 0) {
            foreach ($batchdetails as $key => $res) {
                
                $returnData[$key]['batch_id'] = $res->batch_id;
                $returnData[$key]['product_name'] = $res->product_name ?? '';
                $returnData[$key]['organic_status'] = getRefOrganicStatusMasterByID($res->organic_status ?? '');
                $returnData[$key]['self_qty_consumed'] = $res->self_qty_consumed ?? '0.00';
                $returnData[$key]['quantity'] = $res->quantity ?? '0.00';
                $returnData[$key]['used_quantity'] = $res->used_quantity ?? '0.00';
                $returnData[$key]['remaining_quantity'] = $res->quantity - $res->used_quantity ?? '0.00';
                $returnData[$key]['type'] = 'Lot';
                $returnData[$key]['total_quantity'] = $res->total_quantity ?? '0.00';
                $returnData[$key]['quantity_source'] = $res->quantity_source ?? '0.00';
                $returnData[$key]['available_quantity'] = $res->available_quantity ?? '0.00';
                $returnData[$key]['self_consumption'] = '<input type="text" class="self_consumption" name="self_consumption[]" >';
                $returnData[$key]['remark'] = '<input type="text" class="remark" name="remark[]">';

            }


            // Add the dummy data to the response
            $returnData['operator_detail'] = $operatorDetail;
            $returnData['table_data'] = $batchdetails;

            // Return success response with data
            return response()->json(['msg' => 'success', 'data' => $returnData]);
        } else {
            return response()->json(['msg' => 'error', 'data' => 'No Record found.']);
        }
    }


    public function getAlerts()
    {
        $operatorId = Auth::id();
        $alerts = AtTcSelfConsumed::where('created_by', $operatorId)
            ->where('is_read', 1)
            ->get();
        $alertCount = $alerts->count();
        return response()->json(['alerts' => $alerts, 'alertCount' => $alertCount]);
    }

    public function getAlertsforCb()
    {
        $operatorId = Auth::id();
        $alerts = AtTcSelfConsumed::where('updated_by', $operatorId)
            ->where('is_read', 2)
            ->get();
        $alertCount = $alerts->count();
        return response()->json(['alerts' => $alerts, 'alertCount' => $alertCount]);
    }

   
    public function markAlertAsRead($id)
    {
        try {
            // Enable query logging
            DB::connection()->enableQueryLog();

            $alert = AtTcSelfConsumed::findOrFail($id);
            $alert->is_read = 0;
            $alert->save();

            $queries = DB::getQueryLog();

            DB::disableQueryLog();

            foreach ($queries as $query) {
                \Log::info($query['query']);
            }

            return response()->json(['success' => true]);
        } catch (\Exception $e) {
            \Log::error('Error occurred: ' . $e->getMessage());
            return response()->json(['success' => false]);
        }
    }

    public function markAlertAsReadTc($id)
    {
        try {
            // Enable query logging
            DB::connection()->enableQueryLog();

            $alert = AtTcSelfConsumed::findOrFail($id);
            $alert->is_read = 0;
            $alert->save();

            $queries = DB::getQueryLog();

            DB::disableQueryLog();

            foreach ($queries as $query) {
                \Log::info($query['query']);
            }

            return response()->json(['success' => true]);
        } catch (\Exception $e) {
            \Log::error('Error occurred: ' . $e->getMessage());
            return response()->json(['success' => false]);
        }
    }


    public function show(Request $request, $self_qty_consumed, $remark, $org_status, $created_at)
    {
        $data = compact('self_qty_consumed', 'remark', 'org_status', 'created_at');

        return view("admin.self_consumption.alert-detail", $data);
    }
}

<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Permission;
use App\Models\Role;
use App\Models\RoleUser;
use App\Models\User;
use App\Models\AtClosingStock;
use App\Models\UserInspector;
use App\Models\UserWarehouse;
use App\Models\WildHarvesterForestProductDetail;
use App\Models\RefState;
use App\Models\RefDistrict;
use App\Models\RefVillage;
use App\Models\IndividualProducerFarmerDetail;
use App\Models\IndividualProducerFarmDetail;
use App\Models\AtFarmerRegDetail;
use App\Models\AtFarmDetails;
use App\Models\WildHarvesterDetail;
use App\Models\IndividualProducerDetailOfStandingCorp;
use Yajra\DataTables\DataTables;
use App\Models\AtFarmerStandingCorpDetail;
use App\Models\AtPurchaseDetails;
use Exception;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;

class ClosingStockController extends Controller
{


public function updateclosingestock(Request $request){

		$user_id = Auth::guard('misadmin')->user()->id;
		return view('admin.closing_stock.update_closing_stock_scope',compact('user_id'));
	}


	public function operatorDetailsClosingStock(Request $request)
    {


      $operator_list = AtClosingStock::
           
                orderBy('created_at', 'desc')
                ->get()
                ->unique('at_user_id');

    
       // dd($operator_list );
        // pr(getbyOperatornameRegNo);
        if ($request->ajax()) {

            return Datatables::of($operator_list)
                    ->addIndexColumn()
                    ->addColumn('action', function($row){
						$btn = '<a href="'.route("superadmin.closingstocks.updateclosingstockscope",[$row->at_user_id]).'">Enter Closing Stock</a>';

                        return $btn;
                    })
					->editColumn('registration_no', function ($row) {

							return getbyOperatornameRegNo($row->at_user_id);

                     })
					 ->editColumn('operator_name', function ($row) {
                        return user_name($row->at_user_id);
                     })
					  ->addColumn('ref_operator_type_id', function ($row) {
                        return getOperatorTypeById($row->ref_operator_type_id);

                     })
					 ->addColumn('created_at', function ($row) {
                        return Carbon::parse($row->created_at)->format('d-m-Y');

                     })

                    ->rawColumns(['action'])
                    ->make(true);
        }

        return view('admin.closing_stock.operator_list',compact('operator_list'));
    }



	public function updateclosingstockscope(Request $request ,$id){
        
        $operator_list = User::where('id',$id)->first();
        if(empty($operator_list->ref_operator_type_id)){
            Alert::error('error','Registration Not Alloted');
            return redirect()->back();
        }
       
         if($operator_list->ref_operator_type_id == 2) // ICS
			{
                $FarmerRegDetail = AtFarmerRegDetail::where('at_user_id',$operator_list->id)->get();
                return view('admin.closing_stock.ics.update_closing_stock_farmerdetails',compact('id','FarmerRegDetail','operator_list'));

			}elseif($operator_list->ref_operator_type_id == 3) // Individual Producer
			{
                $FarmerRegDetail = IndividualProducerFarmerDetail::where('at_user_id',$operator_list->id)->get();
                return view('admin.closing_stock.ip.update_ip_closing_stock_scope',compact('FarmerRegDetail','id','operator_list'));


			}elseif($operator_list->ref_operator_type_id == 4) //Wild Harvester
			{

                // $operator_list = AtClosingStock::where('at_user_id',$operator_list->id)->first();
                $product_details = WildHarvesterForestProductDetail::with('getwhClosingstock')->where('at_user_id',$operator_list->id)->get();
                // pra($product_details);
                return view('admin.closing_stock.wh.update_wh_closing_stock_products',compact('id','product_details','operator_list'));
			}
	}


/*-------// ICS// function */

public function updateicsclosingstockfarmsdetails(Request $request,$oprator_id ,$farmer_id){
   
    $operator_list = AtClosingStock::where('at_user_id',$oprator_id)->first();
    $FarmerRegDetail = AtFarmerRegDetail::where('at_user_id',$oprator_id)->where('id',$farmer_id)->first();
    $farm_details = AtFarmDetails::where('at_farmer_reg_details_id',$farmer_id)->get();
        // dd($farm_details);
	return view('admin.closing_stock.ics.update_closing_stock_farmsdetails',compact('farmer_id','oprator_id','operator_list','farm_details','FarmerRegDetail'));

}

public function updateicsclosingstockproductdetails(Request $request,$oprator_id ,$farmer_id, $farm_id){

    $FarmerRegDetail = AtFarmerRegDetail::where('at_user_id',$oprator_id)->where('id',$farmer_id)->first();
    $farm_details = AtFarmDetails::where('at_farmer_reg_details_id',$farmer_id)->first();
    $operator_list = AtClosingStock::where('at_user_id',$oprator_id)->first();
    $product_details = AtFarmerStandingCorpDetail::with('getClosingstock')->where('at_farm_details_id',$farm_id)->get();
    //DD($FarmerRegDetail);
	return view('admin.closing_stock.ics.update_closing_stock_products',compact('operator_list','farm_details','FarmerRegDetail','product_details','farm_id'));

}



    public function editIcsClosingstockProduct(Request $request)
    {

        $stcropData = AtFarmerStandingCorpDetail::where('id',$request->product_id)->first();
        $product_detail = AtClosingStock::where('at_farmer_standing_crop_details_id',$request->product_id)
        ->where('created_by',Auth::user()->id)->first();
       // dd($product_detail);
        $product_id =$stcropData->ref_product_id;
        $farm_id =$request->farm_id;
        $harvest_date =$request->harvest_date;
        return  view('admin.closing_stock.ics.tpl_closing_stock_edit_product',compact('stcropData','product_detail','product_id','farm_id','harvest_date'))->render();
    }

	public function storeIcsclosingstockProduct(Request $request)
	{
        //dd($request->all());
		$validator = \Validator::make($request->all(), [
            'product_id' => 'required',
            'farm_id' => 'required',
            'harvest_date' => 'required',
            'closing_stock' => 'required',
            'closing_stock_date' => 'required',

        ]);

        if ($validator->fails())
        {
            return response()->json(['errors'=>$validator->errors()->all()]);
        }

		try {

                 $input_approval = AtClosingStock::updateOrCreate(
                    ['at_farmer_standing_crop_details_id' => $request->stcrop_id],
                    [
                    'at_farmer_standing_crop_details_id' =>$request->stcrop_id,
                    'ref_product_id' =>$request->product_id,
                    'closing_stock' =>  $request->closing_stock,
                    'closing_stock_date' => date('Y-m-d',strtotime($request->closing_stock_date)),
                    'created_at' => date('Y-m-d H:i:s'),
                    'created_by' => Auth::guard('misadmin')->user()->id,
                    'updated_at' => date('Y-m-d H:i:s'),
                    'updated_by' => Auth::guard('misadmin')->user()->id
                    ]
                );


                AtPurchaseDetails::updateOrCreate(
                    ['at_closing_stock_id' => $input_approval->id],
                    [
                        'at_closing_stock_id' =>$input_approval->id,
                        'commodity' =>$request->product_id,
                        'at_user_id' =>  $input_approval->at_user_id,
                        'at_farm_details_id' => $request->farm_id,
                        'harvest_date' => $request->harvest_date,
                        'created_at' =>date('Y-m-d H:i:s'),
                        'created_by' => Auth::guard('misadmin')->user()->id,
                        'updated_at' => date('Y-m-d H:i:s'),
                        'updated_by' => Auth::guard('misadmin')->user()->id
                    ]
                );

		    	return response()->json(['data'=>$input_approval,'success'=>'Data is successfully added']);

		} catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
	}


/*------{WH}---end---*/

public function editWHClosingstockProduct(Request $request)
{

    $product_detail = AtClosingStock::where('at_wh_forest_product_details_id',$request->product_id)
    ->where('created_by',Auth::user()->id)->first();

    $product_id =$request->product_id;
    $at_wh_forest_details_id =$request->at_wh_forest_details_id;
    $harvest_date =$request->harvest_date;
    $user_id =$request->user_id;

    return  view('admin.closing_stock.wh.tpl_wh_edit_product',compact('product_detail','product_id','at_wh_forest_details_id','harvest_date','user_id'))->render();
}

public function storeWHclosingstockProduct(Request $request)
{
//    dd($request->all());
		$validator = \Validator::make($request->all(), [
            'product_id' => 'required',
            'at_wh_forest_details_id' => 'required',
            // 'ref_operator_type_id' => 'required',
            'user_id' => 'required',
            'closing_stock' => 'required',
            'closing_stock_date' => 'required',

        ]);

        if ($validator->fails())
        {
            return response()->json(['errors'=>$validator->errors()->all()]);
        }

		// try {

                 $input_approval = AtClosingStock::updateOrCreate(
                    ['at_wh_forest_product_details_id' => $request->product_id],
                    [
                        'at_wh_forest_product_details_id' =>$request->product_id,
                        'at_user_id' =>  $request->user_id,
                        'closing_stock' =>  $request->closing_stock,
                        'closing_stock_date' => date('Y-m-d',strtotime($request->closing_stock_date)),
                        'created_at' => date('Y-m-d H:i:s'),
                        'created_by' => Auth::guard('misadmin')->user()->id,
                        'updated_at' => date('Y-m-d H:i:s'),
                        'updated_by' => Auth::guard('misadmin')->user()->id
                    ]
                );

                AtPurchaseDetails::updateOrCreate(
                    ['at_closing_stock_id' => $input_approval->id],
                    [
                        'at_closing_stock_id' =>$input_approval->id,
                        'at_user_id' =>  $input_approval->at_user_id,
                        'ref_operator_type_id' => 4,
                        'at_farm_details_id' => $request->at_wh_forest_details_id,
                        'harvest_date' => $request->harvest_date ?? '',
                        'created_at' =>date('Y-m-d H:i:s'),
                        'created_by' => Auth::guard('misadmin')->user()->id,
                        'updated_at' => date('Y-m-d H:i:s'),
                        'updated_by' => Auth::guard('misadmin')->user()->id
                    ]
                );

		    	return response()->json(['data'=>$input_approval,'success'=>'Data is successfully added']);

		// } catch (Exception $e) {
        //     Log::error($e->getMessage());
        //     abort('404');
        // }

}



/*-------// IP---end// function */

public function updateipclosingstockfarmsdetails(Request $request,$oprator_id ,$farmer_id)
{

    $operator_list = AtClosingStock::where('at_user_id',$oprator_id)->first();
    $FarmerRegDetail = IndividualProducerFarmerDetail::where('at_user_id',$oprator_id)->where('id',$farmer_id)->first();
	$farm_details = IndividualProducerFarmDetail::where('at_farmer_reg_details_id',$farmer_id)->get();

    return view('admin.closing_stock.ip.update_ip_closing_stock_farmsdetails',compact('oprator_id','farmer_id','FarmerRegDetail','operator_list','farm_details'));




}


public function updateipclosingstockproductdetails(Request $request,$oprator_id ,$farmer_id, $farm_id){


    $operator_list = AtClosingStock::where('at_user_id',$oprator_id)->first();

    $FarmerRegDetail = IndividualProducerFarmerDetail::where('at_user_id',$oprator_id)->where('id',$farmer_id)->first();
    $farm_details = IndividualProducerFarmDetail::where('at_farmer_reg_details_id',$farmer_id)->first();
    $product_details = IndividualProducerDetailOfStandingCorp::with('getClosingstock')->where('at_ip_farm_details_id',$farm_id)->get();
     //pra($product_details);
	return view('admin.closing_stock.ip.update_ip_closing_stock_products',compact('farm_id','operator_list','farm_details','FarmerRegDetail','product_details'));

}


public function editipClosingstockProduct(Request $request)
{


    // AtFarmerStandingCorpDetail::where('id',$request->product_id)->first();
    $product_detail = AtClosingStock::where('at_ip_details_standing_crop_id',$request->product_id)
    ->where('created_by',Auth::user()->id)->first();
//    dd($product_detail);
    $product_id =$request->product_id;
    $farm_id =$request->farm_id;
    $harvest_date =$request->harvest_date;
    $user_id =$request->user_id;
    return  view('admin.closing_stock.ip.tpl_ip_closing_stock_edit_product',compact('product_detail','product_id','farm_id','harvest_date','user_id'))->render();
}




public function storeipclosingstockProduct(Request $request)
	{
        // dd($request->all());
		$validator = \Validator::make($request->all(), [
            'product_id' => 'required',
            'farm_id' => 'required',
            //'user_id' => 'required',
            'closing_stock' => 'required',
            'closing_stock_date' => 'required',

        ]);

        if ($validator->fails())
        {
            return response()->json(['errors'=>$validator->errors()->all()]);
        }

		try {

                 $input_approval = AtClosingStock::updateOrCreate(
                    ['at_ip_details_standing_crop_id' => $request->product_id],
                    [
                        'at_ip_details_standing_crop_id' =>$request->product_id,
                        //'at_user_id' =>  $request->user_id,
                        'closing_stock' =>  $request->closing_stock,
                        'closing_stock_date' => date('Y-m-d',strtotime($request->closing_stock_date)),
                        'created_at' => date('Y-m-d H:i:s'),
                        'created_by' => Auth::guard('misadmin')->user()->id,
                        'updated_at' => date('Y-m-d H:i:s'),
                        'updated_by' => Auth::guard('misadmin')->user()->id
                    ]
                );

                AtPurchaseDetails::updateOrCreate(
                    ['at_closing_stock_id' => $input_approval->id],
                    [
                        'at_closing_stock_id' =>$input_approval->id,
                        //'at_user_id' =>  $input_approval->at_user_id,
                        'at_farm_details_id' => $request->farm_id,
                        'harvest_date' => $request->harvest_date ?? '',
                        'created_at' =>date('Y-m-d H:i:s'),
                        'created_by' => Auth::guard('misadmin')->user()->id,
                        'updated_at' => date('Y-m-d H:i:s'),
                        'updated_by' => Auth::guard('misadmin')->user()->id
                    ]
                );

		    	return response()->json(['data'=>$input_approval,'success'=>'Data is successfully added']);

		} catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
	}






}

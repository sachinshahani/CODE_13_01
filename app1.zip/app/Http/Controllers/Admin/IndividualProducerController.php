<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\IndividualProducerBankDetail;
use App\Models\IndividualProducerDetailOfProposedCorp;
use App\Models\IndividualProducerDetailOfStandingCorp;
use App\Models\IndividualProducerDocument;
use App\Models\IndividualProducerFarmDetail;
use App\Models\IndividualProducerFarmerDetail;
use App\Models\IndividualProducerGeoTagging;
use App\Models\Permission;
use App\Models\Role;
use App\Models\RoleUser;
use App\Models\User;
use Illuminate\Support\Facades\File;
use App\Models\UserSelf;
use App\Models\UserInspector;
use App\Models\UserWarehouse;
use App\Models\UserWarehouseManagerOfficers;
use App\Models\RefState;
use App\Models\RefDistrict;
use App\Models\RefVillage;
use App\Models\RefRegion;
use App\Models\WildHarvesterForestProductDetail;
use App\Models\CertificateStandardDetail;
use App\Models\AtProProductsDetails;
use App\Models\BatchCreation;
use App\Models\AtBatchDetail;
use App\Models\AtOpTransactionVsTransactionProduct;
use App\Models\AtBatchCreation;
use App\Models\AtOpTransactionProductSourced;
use App\Models\AtFarmerStandingCorpDetail;
use App\Models\AtClosingStock;
use App\Models\RefPackingMaster;
use App\Models\AtOpTransactionPackingDetails;
use App\Models\AtOpTransactionCertificateEntry;
use App\Models\AtPurchaseDetails;
use App\Models\AtUserLoginDetails;
use App\Models\AtUserRegistrationDetails;
use Yajra\DataTables\DataTables;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;
// use Barryvdh\DomPDF\Facade as PDF;
use Mpdf\Mpdf;
use PDF;
//use DB;
use Illuminate\Support\Facades\DB;
use Session;

class IndividualProducerController extends Controller
{

    public function individualUserAdd($id)
    {
        $userdetails = User::find(Auth::guard('misadmin')->user()->id);
        $farmerDetails = IndividualProducerFarmerDetail::where('at_user_id', $id)->first();
        $user = User::where('id', $id)->first();
        $states = RefState::orderBy('state_name', 'ASC')->get();
        $districts = RefDistrict::where('ref_state_id', $user->ref_state_id)->orderBy('district_name', 'ASC')->get();
        $regions = RefRegion::where('ref_state_id', $user->ref_state_id)->orderBy('block_tehsil_name', 'ASC')->get();
        $villages = RefVillage::where('ref_district_id', $user->ref_district_id)->orderBy('village_name', 'ASC')->get();

        return view('admin.usermanagement.deptUser.individualDetail', compact('id', 'states', 'districts', 'regions', 'villages', 'farmerDetails', 'userdetails', 'user'));
    }

    public function individualUserAddStep2($id)
    {
        $userdetails = User::find(Auth::guard('misadmin')->user()->id);
        $user = IndividualProducerBankDetail::where('at_user_id', $id)->first();
        $states = RefState::orderBy('state_name', 'ASC')->get();
        $districts = RefDistrict::where('ref_state_id', $userdetails->ref_state_id)->orderBy('district_name', 'ASC')->get();
        $regions = RefRegion::where('ref_state_id', $userdetails->ref_state_id)->orderBy('block_tehsil_name', 'ASC')->get();
        $villages = RefVillage::where('ref_district_id', $userdetails->ref_district_id)->orderBy('village_name', 'ASC')->get();

        return view('admin.usermanagement.deptUser.individualDetail1', compact('id', 'states', 'districts', 'regions', 'villages', 'userdetails', 'user'));
    }

    public function individualUserAddStep3($id)
    {
        $userdetails = User::find($id);
        $farm_detail = IndividualProducerFarmDetail::where('at_user_id', $id)->first();
        //$farmerDetails = IndividualProducerFarmerDetail::where('at_user_id', $id)->first();
        $farmerDetails = $id;
        if (!empty($farm_detail)) {
            $geo_taggings = IndividualProducerGeoTagging::where('at_ip_farmer_reg_details_id', $farm_detail->at_farmer_reg_details_id)->where('at_ip_farm_details_id', $farm_detail->id)->get();
        } else {
            $geo_taggings = "";
        }

        $states = RefState::orderBy('state_name', 'ASC')->get();
        $districts = RefDistrict::where('ref_state_id', $userdetails->ref_state_id)->orderBy('district_name', 'ASC')->get();
        $regions = RefRegion::where('ref_state_id', $userdetails->ref_state_id)->orderBy('block_tehsil_name', 'ASC')->get();
        $villages = RefVillage::where('ref_district_id', $userdetails->ref_district_id)->orderBy('village_name', 'ASC')->get();

        return view('admin.usermanagement.deptUser.individualDetail2', compact('id', 'states', 'districts', 'regions', 'villages', 'userdetails', 'farm_detail', 'farmerDetails', 'geo_taggings'));
    }

    public function individualUserAddStep4($id)
    {

        $userdetails = User::find($id);
        $farm_detail = IndividualProducerFarmDetail::where('at_user_id', $id)->get();
         //dd($farm_detail);
        $standing_corps = IndividualProducerDetailOfStandingCorp::where('at_user_id', $id)->get();
        //dd($standing_corps);die;
        $states = RefState::orderBy('state_name', 'ASC')->get();
        $districts = RefDistrict::where('ref_state_id', $userdetails->ref_state_id)->orderBy('district_name', 'ASC')->get();
        $regions = RefRegion::where('ref_state_id', $userdetails->ref_state_id)->orderBy('block_tehsil_name', 'ASC')->get();
        $villages = RefVillage::where('ref_district_id', $userdetails->ref_district_id)->orderBy('village_name', 'ASC')->get();

        return view('admin.usermanagement.deptUser.individualDetail3', compact('farm_detail', 'id', 'states', 'districts', 'regions', 'villages', 'userdetails', 'standing_corps'));
    }

    public function individualUserAddStep5($id)
    {
        $userdetails = User::find($id);
        $farm_detail = IndividualProducerFarmDetail::where('at_user_id', $id)->get();
        // dd($farm_detail);
        $states = RefState::orderBy('state_name', 'ASC')->get();
        $proposed_corps = IndividualProducerDetailOfProposedCorp::where('at_user_id', $id)->get();
        $districts = RefDistrict::where('ref_state_id', $userdetails->ref_state_id)->orderBy('district_name', 'ASC')->get();
        $regions = RefRegion::where('ref_state_id', $userdetails->ref_state_id)->orderBy('block_tehsil_name', 'ASC')->get();
        $villages = RefVillage::where('ref_district_id', $userdetails->ref_district_id)->orderBy('village_name', 'ASC')->get();

        return view('admin.usermanagement.deptUser.individualDetail4', compact('id', 'states', 'districts', 'regions', 'villages', 'userdetails', 'proposed_corps', 'farm_detail'));
    }

    public function individualUserAddStep6($id)
    {
        $userdetails = User::find(Auth::guard('misadmin')->user()->id);
        $states = RefState::orderBy('state_name', 'ASC')->get();
        $document = IndividualProducerDocument::where('at_user_id', $id)->first();
        $districts = RefDistrict::where('ref_state_id', $userdetails->ref_state_id)->orderBy('district_name', 'ASC')->get();
        $regions = RefRegion::where('ref_state_id', $userdetails->ref_state_id)->orderBy('block_tehsil_name', 'ASC')->get();
        $villages = RefVillage::where('ref_district_id', $userdetails->ref_district_id)->orderBy('village_name', 'ASC')->get();

        return view('admin.usermanagement.deptUser.individualDetail5', compact('id', 'states', 'districts', 'regions', 'villages', 'userdetails', 'document'));
    }

    public function individualUserDeleteGeoTagging(Request $request)
    {
        try {
            IndividualProducerGeoTagging::where('id', $request->id)->delete();

            return 1;
        } catch (Exception $e) {
            Alert::error('Error', $e->getMessage());
            \Log::error($e->getMessage());
            abort(404);
        } catch (\Illuminate\Database\QueryException $exception) {
            Alert::error('Error', $exception->getMessage());
            \Log::error($exception->getMessage());
            Alert::error('error', 'Query Exception');

            return redirect()->back();
        }
    }

    public function individualUserDeleteStandingCorp(Request $request)
    {
        try {
            IndividualProducerDetailOfStandingCorp::where('id', $request->id)->delete();

            return 1;
        } catch (Exception $e) {
            Alert::error('Error', $e->getMessage());
            \Log::error($e->getMessage());
            abort(404);
        } catch (\Illuminate\Database\QueryException $exception) {
            Alert::error('Error', $exception->getMessage());
            \Log::error($exception->getMessage());
            Alert::error('error', 'Query Exception');
            return redirect()->back();
        }
    }

    public function individualUserDeleteProposedCorp(Request $request)
    {
        try {
            IndividualProducerDetailOfProposedCorp::where('id', $request->id)->delete();
            return 1;
        } catch (Exception $e) {
            Alert::error('Error', $e->getMessage());
            \Log::error($e->getMessage());
            abort(404);
        } catch (\Illuminate\Database\QueryException $exception) {
            Alert::error('Error', $exception->getMessage());
            \Log::error($exception->getMessage());
            Alert::error('error', 'Query Exception');
            return redirect()->back();
        }
    }


    public function individualUserStore(Request $request, $id)
    {

        // dd($request->all());

        $request->validate([
            'user_name' => 'required',
            'farmer_first_name' => 'required',
            //'farmer_middle_name' => 'required',
            // 'farmer_last_name' => 'required',
            'gender' => 'required',
            'father_husband_flag' => 'required',
            'father_first_name' => 'required',
            //'father_middle_name' => 'required',
            'father_last_name' => 'required',
            'state' => 'required',
            'taluka' => 'required',
            'district' => 'required',
            'village' => 'required',
            'pin_code' => 'required|numeric|digits:6',
            'address' => 'required',
            // 'mobile_number' => 'required|numeric|unique:at_user,mobile_no',
            // 'aadhar_number' => 'required|numeric|digits:12|unique:at_user,contact_person_aadhar_number',
            // 'pan_number' => 'required',
            'email_id' => 'required',
        ]);

        try {

            User::updateOrCreate(['id' => $id], [
                'id' => $id,
                'ref_operator_type_id' => 3,
                'ref_state_id' => $request->state,
                'ref_block_tehsil_id' => $request->taluka,
                'ref_district_id' => $request->district,
                'ref_village_id' => $request->village,
                'pin' => $request->pin_code,
                'farmer_address' => $request->address,
                'mobile_no' => $request->mobile_number,
                'contact_person_pan_number' => $request->pan_number,
                // 'contact_person_aadhar_number' => $request->aadhar_number,
                // 'email_id' => $request->email_id,
            ]);
             $atUserloginDetail_id= AtUserLoginDetails::where('at_user_id',$id)->first();
             AtUserLoginDetails::updateOrCreate(['id'=>$atUserloginDetail_id->id],[
                    'at_user_id' => !empty($id) ? $id : NULL,
                    'ref_operator_type_id' => 3,
             ]);
             $atUserRegistrationDetail_id = AtUserRegistrationDetails::where('at_user_login_details_id',$atUserloginDetail_id->id)->first();
            //  dd($atUserloginDetail_id->id);
            AtUserRegistrationDetails::updateOrCreate(['id'=>$atUserRegistrationDetail_id->id],[
                'id'=>$atUserRegistrationDetail_id->id,
                'at_user_id' => !empty($id) ? $id : NULL,
                'at_user_login_details_id' => !empty($atUserloginDetail_id->id) ? $atUserloginDetail_id->id : NULL,
                'ref_operator_type_id' => 3,
            ]);
            $add =  IndividualProducerFarmerDetail::updateOrCreate(['at_user_id' => $id], [
                'at_user_id' => $id,
                'ref_operator_type_id' => 3,
                'farmer_first_name' => $request->farmer_first_name,
                'father_husband_flag' => $request->father_husband_flag,
                'father_husband_first_name' => $request->father_first_name,
                'father_husband_middle_name' => $request->father_middle_name,
                'father_husband_last_name' => $request->father_last_name,
                'ref_state_id' => $request->state,
                'ref_district_id' => $request->district,
                'ref_block_tehsil_id' => $request->taluka,
                'ref_village_id' => $request->village,
                'pin' => $request->pin_code,
                'farmer_address' => $request->address,
                'gender' => $request->gender,
            ]);

            Alert::success('Success', 'Record updated Successfully');
            if ($request->ref_operator_type_id == 3) {
                return redirect()->route('superadmin.usermanagement.deptUser.individualUserAddStep2', $id)->with('success', __('message.add_first_success'));
            } else {
                return redirect()->back()->with('success', __('message.add_success'));
            }
        } catch (Exception $e) {
            Alert::error('Error', $e->getMessage());
            \Log::error($e->getMessage());
            abort(404);
        } catch (\Illuminate\Database\QueryException $exception) {
            Alert::error('Error', $exception->getMessage());
            \Log::error($exception->getMessage());
            Alert::error('error', "Query Exception");
            return redirect()->back()->with('loader', true);
        }
    }


    public function individualUserStoreStep2(Request $request, $id)
    {

        // dd($request->all());
        // $request->validate([
        //     'ref_bank_id' => 'required',
        //     'account_number' => 'required',
        //     'ifsc_code' => 'required',
        //     'branch_name' => 'required',
        //     'bank_address' => 'required',
        //     'bank_pincode' => 'required',
        // ]);
        // try {

        $check = IndividualProducerBankDetail::where('at_user_id', $id)->first();
        $farmer_photo = '';
        $documentRootPath = public_path('research/uploads');
        if (!file_exists($documentRootPath)) {
            mkdir($documentRootPath, 0777, true);
        }

        if (!empty($check)) {
            if ($request->hasFile('farmer_photo')) {
                $file_path = time() . rand() . '.' . $request->file('farmer_photo')->getClientOriginalExtension();
                $request->file('farmer_photo')->move($documentRootPath, $file_path);
                $farmer_photo = $file_path;
            } else {
                $farmer_photo = $check->farmer_photo;
            }
        } else {
            if ($request->hasFile('farmer_photo')) {
                $file_path = time() . rand() . '.' . $request->file('farmer_photo')->getClientOriginalExtension();
                $request->file('farmer_photo')->move($documentRootPath, $file_path);
                $farmer_photo = $file_path;
            } else {
                $farmer_photo = '';
            }
        }


        IndividualProducerBankDetail::updateOrCreate(['at_user_id' => $id,], [
            'at_user_id' => !empty($id) ? $id : '',
            'ref_operator_type_id' => !empty($request->ref_operator_type_id) ? $request->ref_operator_type_id : '',
            'ref_bank_id' => !empty($request->ref_bank_id) ? $request->ref_bank_id : Null,
            'account_number' => !empty($request->account_number) ? $request->account_number : '',
            'ifsc_code' => !empty($request->ifsc_code) ? $request->ifsc_code : '',
            'branch_name' => !empty($request->branch_name) ? $request->branch_name : '',
            'bank_address' => !empty($request->bank_address) ? $request->bank_address : '',
            'pincode' => !empty($request->bank_pincode) ? $request->bank_pincode : '',
            // 'farmer_photo' => $farmer_photo,
        ]);

        Alert::success('Success', 'Record updated Successfully');
        if ($request->ref_operator_type_id == 3) {
            return redirect()->route('superadmin.usermanagement.deptUser.individualUserAddStep3', $id)->with('success', __('message.add_second_success'));
        } else {
            return redirect()->back()->with('success', __('message.add_success'));
        }
        // } catch (Exception $e) {
        //     Alert::error('Error', $e->getMessage());
        //     \Log::error($e->getMessage());
        //     abort(404);
        // } catch (\Illuminate\Database\QueryException $exception) {
        //     Alert::error('Error', $exception->getMessage());
        //     \Log::error($exception->getMessage());
        //     Alert::error('error', "Query Exception");
        //     return redirect()->back()->with('loader', true);
        // }
    }


    // public function individualUserStoreStep3(Request $request, $id)
    // {
    //     //$at_farmer_reg_details_id = Session::get('at_farmer_reg_details_id');
    //     // $at_farmer_reg_details_id = $request->at_farmer_reg_details_id;
    //     $at_farmer_reg_details_id = IndividualProducerFarmerDetail::where('at_user_id', $request->at_farmer_reg_details_id)->first();
    //     //dd($at_farmer_reg_details_id);
    //     $request->validate([
    //         'farm_name' => 'required',
    //         'khasra_number' => 'required',
    //         'land_holding_type' => 'required',
    //         //'farm_id' => 'required',
    //         // 'geo_tagging_of_farm' => 'required',
    //         // 'total_area_of_farm' => 'required',
    //         // 'under_organic_cultivation' => 'required',
    //     ]);
    //     try {
    //         //  dd($request->all());
    //         $data = IndividualProducerFarmDetail::updateOrCreate(['at_user_id' => $id,], [
    //             'at_farmer_reg_details_id' => $at_farmer_reg_details_id->id,
    //             'at_user_id' => $id,
    //             'farm_name' => $request->farm_name,
    //             'survay_no' => $request->khasra_number,
    //             'land_holding_type' => $request->land_holding_type,
    //         ]);

    //         $geo_tagging_of_farm = $request->geo_tagging_of_farm;
    //         if (count($geo_tagging_of_farm) > 0) {
    //             foreach ($geo_tagging_of_farm as $key => $fi) {
    //                 if (!empty($fi)) {
    //                     if (isset($request->row_id[$key])) {
    //                         IndividualProducerGeoTagging::where(['id' => $request->row_id[$key], 'at_user_id' => $id])->update(
    //                             [
    //                                 'at_user_id' => $id,
    //                                 'at_ip_farmer_reg_details_id' => $at_farmer_reg_details_id ?? '0',
    //                                 'at_ip_farm_details_id' => $data->id,
    //                                 'geo_tagging_of_farm' => $request->geo_tagging_of_farm[$key],
    //                                 'total_area_of_farm' => $request->total_area_of_farm[$key],
    //                                 'under_organic_cultivation' => $request->under_organic_cultivation[$key],
    //                             ]
    //                         );
    //                     } else {
    //                         IndividualProducerGeoTagging::create(
    //                             [
    //                                 'at_user_id' => $id,
    //                                 'at_ip_farmer_reg_details_id' => $at_farmer_reg_details_id ?? 0,  // Ensure it's an integer or null
    //                                 'at_ip_farm_details_id' => $data->id,
    //                                 'geo_tagging_of_farm' => $request->geo_tagging_of_farm[$key],
    //                                 'total_area_of_farm' => $request->total_area_of_farm[$key],
    //                                 'under_organic_cultivation' => $request->under_organic_cultivation[$key],
    //                                 'created_at' => now(),
    //                                 'updated_at' => now(),
    //                             ]
    //                         );
                            
    //                     }
    //                 }
    //             }
    //         }


    //         Alert::success('Success', 'Record updated Successfully');
    //         if ($request->ref_operator_type_id == 3) {
    //             return redirect()->route('superadmin.usermanagement.deptUser.individualUserAddStep4', $id)->with('success', __('message.add_second_success'));
    //         } else {
    //             return redirect()->back()->with('success', __('message.add_success'));
    //         }
    //     } catch (Exception $e) {
    //         Log::error($e->getMessage());
    //         abort('404');
    //     }
    // }

    // Update by Sachin 03-01-25
    public function individualUserStoreStep3(Request $request, $id)
    {
        $at_farmer_reg_details_id = IndividualProducerFarmerDetail::where('at_user_id', $request->at_farmer_reg_details_id)->first();
        $request->validate([
            'farm_name' => 'required',
            'khasra_number' => 'required',
            'land_holding_type' => 'required',
        ]);
        try {
            $data = IndividualProducerFarmDetail::updateOrCreate(['at_user_id' => $id], [
                'at_farmer_reg_details_id' => $at_farmer_reg_details_id->id ?? 0, // Ensure it's an integer
                'at_user_id' => $id,
                'farm_name' => $request->farm_name,
                'survay_no' => $request->khasra_number,
                'land_holding_type' => $request->land_holding_type,
            ]);
            $geo_tagging_of_farm = $request->geo_tagging_of_farm;
            if (count($geo_tagging_of_farm) > 0) {
                foreach ($geo_tagging_of_farm as $key => $fi) {
                    if (!empty($fi)) {
                        if (isset($request->row_id[$key])) {
                           $dsdfd = IndividualProducerGeoTagging::where(['id' => $request->row_id[$key], 'at_user_id' => $id])->update([
                                'at_user_id' => $id,
                                'at_ip_farmer_reg_details_id' => $at_farmer_reg_details_id->id ?? 0, // Ensure it's an integer
                                'at_ip_farm_details_id' => $data->id,
                                'geo_tagging_of_farm' => $request->geo_tagging_of_farm[$key],
                                'total_area_of_farm' => $request->total_area_of_farm[$key],
                                'under_organic_cultivation' => $request->under_organic_cultivation[$key],
                            ]);
                        } else {
                            IndividualProducerGeoTagging::create([
                                'at_user_id' => $id,
                                'at_ip_farmer_reg_details_id' => $at_farmer_reg_details_id->id ?? 0, // Ensure it's an integer
                                'at_ip_farm_details_id' => $data->id,
                                'geo_tagging_of_farm' => $request->geo_tagging_of_farm[$key],
                                'total_area_of_farm' => $request->total_area_of_farm[$key],
                                'under_organic_cultivation' => $request->under_organic_cultivation[$key],
                                'created_at' => now(),
                                'updated_at' => now(),
                            ]);
                        }
                    }
                }
            }
            Alert::success('Success', 'Record updated Successfully');
            if ($request->ref_operator_type_id == 3) {
                return redirect()->route('superadmin.usermanagement.deptUser.individualUserAddStep4', $id)->with('success', __('message.add_second_success'));
            } else {
                return redirect()->back()->with('success', __('message.add_success'));
            }
        } catch (Exception $e) {
            Log::error('Error in individualUserStoreStep3: ' . $e->getMessage() . ' Stack trace: ' . $e->getTraceAsString());
            abort(404);
        }
    }



    public function individualUserStoreStep4(Request $request, $id)
    {  // dd($request->all());
        $request->validate([
            'corp_farm_id' => 'required',
            'name_of_corp' => 'required',
            'name_of_season' => 'required',
            'area' => 'required',
            'organic_status' => 'required',
        ]);
        try {
            $corp_farm_id = $request->corp_farm_id;
            if (count($corp_farm_id) > 0) {
                foreach ($corp_farm_id as $key => $cfi) {
                    if (!empty($cfi)) {
                        if (isset($request->row_id[$key])) {
                            $check = IndividualProducerDetailOfStandingCorp::where('id', $request->row_id[$key])->where('at_user_id', $id)->first();
                            $photo_of_corp = '';
                            if (!empty($check)) {
                                if (!empty($request->file('photo_of_corp')[$key])) {
                                    $documentRootPath = 'public/research/uploads';
                                    $file_path = time() . rand() . '.' . $request->file('photo_of_corp')[$key]->getClientOriginalExtension();
                                    $request->file('photo_of_corp')[$key]->move($documentRootPath, $file_path);
                                    $photo_of_corp = $file_path;
                                } else {
                                    $photo_of_corp = $check->crop_photo;
                                }

                                if (!empty($id)) {
                                    $check->at_user_id = $id;
                                }

                                if (!empty($cfi)) {
                                    $check->at_ip_farm_details_id = $cfi;
                                }

                                if (!empty($request->name_of_corp[$key])) {
                                    $check->name_of_corp = $request->name_of_corp[$key];
                                }

                                if (!empty($request->name_of_season[$key])) {
                                    $check->season_name = $request->name_of_season[$key];
                                }

                                if (!empty($request->area[$key])) {
                                    $check->area = $request->area[$key];
                                }

                                if (!empty($photo_of_corp)) {
                                    $check->crop_photo = $photo_of_corp;
                                }

                                if (!empty($request->organic_status[$key])) {
                                    $check->organic_status = $request->organic_status[$key];
                                }

                                $check->save();
                            }
                        } else {
                            if (!empty($request->file('photo_of_corp')[$key])) {
                                $documentRootPath = 'public/research/uploads';
                                $file_path = time() . rand() . '.' . $request->file('photo_of_corp')[$key]->getClientOriginalExtension();
                                $request->file('photo_of_corp')[$key]->move($documentRootPath, $file_path);
                                $photo_of_corp = $file_path;
                            } else {
                                $photo_of_corp = '';
                            }

                            $standing = new IndividualProducerDetailOfStandingCorp();
                            if (!empty($id)) {
                                $standing->at_user_id = $id;
                            }

                            if (!empty($cfi)) {
                                $standing->at_ip_farm_details_id = $cfi;
                            }

                            if (!empty($request->name_of_corp[$key])) {
                                $standing->name_of_corp = $request->name_of_corp[$key];
                            }

                            if (!empty($request->name_of_season[$key])) {
                                $standing->season_name = $request->name_of_season[$key];
                            }

                            $standing->ref_operator_type_id = 3;  // Assuming ref_operator_type_id should always be 3 as per your original code

                            if (!empty($request->area[$key])) {
                                $standing->area = $request->area[$key];
                            }

                            if (!empty($photo_of_corp)) {
                                $standing->crop_photo = $photo_of_corp;
                            }

                            if (!empty($request->organic_status[$key])) {
                                $standing->organic_status = $request->organic_status[$key];
                            }

                            $standing->save();
                        }
                    }
                }
            }
            Alert::success('Success', 'Record updated Successfully');
            if ($request->ref_operator_id == 3) {
                return redirect()->route('superadmin.usermanagement.deptUser.individualUserAddStep5', $id)->with('success', __('message.add_second_success'));
            } else {
                return redirect()->back()->with('success', __('message.add_success'));
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function individualUserStoreStep5(Request $request, $id)
    {
        // dd($request->all());
        $request->validate([
            'details_farm_id' => 'required',
            'details_name_of_corp' => 'required',
            'details_name_of_season' => 'required',
            'details_area' => 'required',
            'details_organic_status' => 'required',
        ]);
        try {
            $details_farm_id = $request->details_farm_id;
            if (count($details_farm_id) > 0) {
                foreach ($details_farm_id as $key => $dfi) {
                    if (!empty($dfi)) {
                        if (isset($request->row_id[$key])) {
                            $check = IndividualProducerDetailOfProposedCorp::where('id', $request->row_id[$key])->where('at_user_id', $id)->first();
                            if (!empty($check)) {
                                $check->at_user_id = $id;
                                $check->at_ip_farm_details_id = $dfi;
                                $check->ref_hscode_id = $request->ref_hscode_id[$key];
                                $check->details_name_of_corp = $request->details_name_of_corp[$key];
                                $check->season_name = $request->details_name_of_season[$key];
                                $check->area = $request->details_area[$key];
                                $check->organic_status = $request->details_organic_status[$key];
                                $check->save();
                            }
                        } else {

                            $standing = new IndividualProducerDetailOfProposedCorp();
                            $standing->at_user_id = $id;
                            $standing->at_ip_farm_details_id = $dfi;
                            $standing->ref_hscode_id = $request->ref_hscode_id[$key];
                            $standing->details_name_of_corp = $request->details_name_of_corp[$key];
                            $standing->season_name = $request->details_name_of_season[$key];
                            $standing->area = $request->details_area[$key];
                            $standing->organic_status = $request->details_organic_status[$key];
                            $standing->save();
                        }
                    }
                }
            }
            Alert::success('Success', 'Record updated Successfully');
            if ($request->ref_operator_id == 3) {
                return redirect()->route('superadmin.usermanagement.deptUser.individualUserAddStep6', $id)->with('success', __('message.add_second_success'));
            } else {
                return redirect()->back()->with('success', __('message.add_success'));
            }
        } catch (Exception $e) {

            Log::error($e->getMessage());
            abort('404');
        }
    }


    // public function individualUserStoreStep6(Request $request, $id)
    // {

    //     // dd($request->all());
    //     // $request->validate([
    //     //     'aadhar_card' => 'required',
    //     //     'pan_card' => 'required',
    //     //     'land_document' => 'required',
    //     //     'bank_passbook' => 'required',
    //     //     'farmer_sign_thumb_Impression' => 'required',
    //     //     'live_signature_thumb_impression' => 'required',
    //     // ]);
    //    // try {
    //         $land_document = $aadhar_card = $pan_card = $bank_passbook =  $farmer_sign_thumb_Impression = $live_signature_thumb_impression = '';

    //         // if (!empty($request->file('aadhar_card'))) {
    //         //     if (!empty($request->aadhar_card_edit)) {
    //         //         $imagePath = public_path('individualProducer/documents/aadhar_card/') . $request->aadhar_card;
    //         //         deleteOldImage($request->aadhar_card_edit, $imagePath);
    //         //     }
    //         //     $documentRootPath = 'public/individualProducer/documents/aadhar_card';
    //         //     $file_path = time() . rand() . '.' . $request->file('aadhar_card')->getClientOriginalExtension();
    //         //     $request->file('aadhar_card')->move($documentRootPath, $file_path);
    //         //     $aadhar_card = $file_path;
    //         // } else {
    //         //     if (!empty($request->aadhar_card_edit))
    //         //         $aadhar_card = $request->aadhar_card_edit;
    //         // }

    //         if (!empty($request->file('land_document'))) {
    //             if (!empty($request->land_document_edit)) {
    //                 $imagePath = public_path('individualProducer/documents/land_document/') . $request->aadhar_card;
    //                 // deleteOldImage($request->land_document_edit, $imagePath);
    //             }
    //             $documentRootPath = 'public/individualProducer/documents/land_document';
    //             $file_path = time() . rand() . '.' . $request->file('land_document')->getClientOriginalExtension();


    //             $request->file('land_document')->move($documentRootPath, $file_path);
    //             $land_document = $file_path;
    //         } else {
    //             if (!empty($request->land_document_edit))
    //                 $land_document = $request->land_document_edit;
    //         }

    //         // if (!empty($request->file('pan_card'))) {
    //         //     if (!empty($request->pan_card_edit)) {
    //         //         $imagePath = public_path('individualProducer/documents/pan_card/') . $request->pan_card;
    //         //         deleteOldImage($request->pan_card_edit, $imagePath);
    //         //     }
    //         //     $documentRootPath = 'public/individualProducer/documents/pan_card';
    //         //     $file_path = time() . rand() . '.' . $request->file('pan_card')->getClientOriginalExtension();
    //         //     $request->file('pan_card')->move($documentRootPath, $file_path);
    //         //     $pan_card = $file_path;
    //         // } else {
    //         //     if (!empty($request->pan_card_edit))
    //         //         $pan_card = $request->pan_card_edit;
    //         // }

    //         // if (!empty($request->file('bank_passbook'))) {
    //         //     if (!empty($request->bank_passbook_edit)) {
    //         //         $imagePath = public_path('individualProducer/documents/bank_passbook/') . $request->bank_passbook;
    //         //         deleteOldImage($request->bank_passbook_edit, $imagePath);
    //         //     }
    //         //     $documentRootPath = 'public/individualProducer/documents/bank_passbook';
    //         //     $file_path = time() . rand() . '.' . $request->file('bank_passbook')->getClientOriginalExtension();
    //         //     $request->file('bank_passbook')->move($documentRootPath, $file_path);
    //         //     $bank_passbook = $file_path;
    //         // } else {
    //         //     if (!empty($request->bank_passbook_edit))
    //         //         $bank_passbook = $request->bank_passbook_edit;
    //         // }

    //         // if (!empty($request->file('farmer_sign_thumb_Impression'))) {
    //         //     if (!empty($request->farmer_sign_thumb_Impression_edit)) {
    //         //         $imagePath = public_path('individualProducer/documents/farmer_sign_thumb_Impression/') . $request->farmer_sign_thumb_Impression;
    //         //         deleteOldImage($request->farmer_sign_thumb_Impression_edit, $imagePath);
    //         //     }
    //         //     $documentRootPath = 'public/individualProducer/documents/farmer_sign_thumb_Impression';
    //         //     $file_path = time() . rand() . '.' . $request->file('farmer_sign_thumb_Impression')->getClientOriginalExtension();
    //         //     $request->file('farmer_sign_thumb_Impression')->move($documentRootPath, $file_path);
    //         //     $farmer_sign_thumb_Impression = $file_path;
    //         // } else {
    //         //     if (!empty($request->farmer_sign_thumb_Impression_edit))
    //         //         $farmer_sign_thumb_Impression = $request->farmer_sign_thumb_Impression_edit;
    //         // }


    //         // if (!empty($request->file('live_signature_thumb_impression'))) {
    //         //     if (!empty($request->live_signature_thumb_impression_edit)) {
    //         //         $imagePath = public_path('individualProducer/documents/live_signature_thumb_impression/') . $request->live_signature_thumb_impression;
    //         //         deleteOldImage($request->live_signature_thumb_impression_edit, $imagePath);
    //         //     }
    //         //     $documentRootPath = 'public/individualProducer/documents/live_signature_thumb_impression';
    //         //     $file_path = time() . rand() . '.' . $request->file('live_signature_thumb_impression')->getClientOriginalExtension();
    //         //     $request->file('live_signature_thumb_impression')->move($documentRootPath, $file_path);
    //         //     $live_signature_thumb_impression = $file_path;
    //         // } else {
    //         //     if (!empty($request->live_signature_thumb_impression_edit))
    //         //         $live_signature_thumb_impression = $request->live_signature_thumb_impression_edit;
    //         // }


    //         $data = array(
    //             'at_user_id' => $id,
    //             // 'aadhar_card_image_path' => $aadhar_card,
    //             // 'pan_card_image_path' => $pan_card,
    //             // 'passbook_image_path' => $bank_passbook,
    //             'land_documents_image_path' => $land_document,
    //             // 'contact_person_sign_image_path' => $farmer_sign_thumb_Impression,
    //             // 'live_signature_image_path' => $live_signature_thumb_impression,
    //         );

    //        // $traders_document = IndividualProducerDocument::find($id);
    //         $traders_document = IndividualProducerDocument::where('at_user_id', $id)->first();
    //        // echo $traders_document; die;

    //         if (!empty($traders_document)) {
    //            /// echo "exist";   echo $id ; die;
    //             $data['updated_at'] = date('Y-m-d H:i:s');
    //             $data['updated_by'] = Auth::guard('misadmin')->user()->id;
    //             $traders_document->where('id', $traders_document->id)->where('at_user_id', $id)->update($data);
    //         } else {
    //            // echo "na";  die;
    //             $data['created_by'] = Auth::guard('misadmin')->user()->id;
    //             $data['created_at'] = date('Y-m-d H:i:s');
    //             IndividualProducerDocument::create($data);
    //         }
    //        // echo "fsdf";
    //         //dd($request->ref_operator_id);die;


    //         Alert::success('Success', 'Record updated Successfully');
    //         if ($request->ref_operator_id == 3) { 
    //            // return redirect()->route('superadmin.usermanagement.deptUser.individualUserAddStep6', $id)->with('success', __('message.add_second_success'));
    //             return redirect()->route('superadmin.individualProducer.preview', $id)->with('success', __('message.add_second_success')); 
    //         } else {
    //             return redirect()->back()->with('success', __('message.add_success'));
    //         }
    //     // } catch (Exception $e) {
    //     //     Log::error($e->getMessage());
    //     //     abort('404');
    //     // }
    // }
    public function individualUserStoreStep6(Request $request, $id)
    {

        // dd($request->all());
        // $request->validate([
        //     'aadhar_card' => 'required',
        //     'pan_card' => 'required',
        //     'land_document' => 'required',
        //     'bank_passbook' => 'required',
        //     'farmer_sign_thumb_Impression' => 'required',
        //     'live_signature_thumb_impression' => 'required',
        // ]);
        try {
            $land_document = $aadhar_card = $pan_card = $bank_passbook =  $farmer_sign_thumb_Impression = $live_signature_thumb_impression = '';

            if (!empty($request->file('aadhar_card'))) {
                if (!empty($request->aadhar_card_edit)) {
                    $imagePath = public_path('individualProducer/documents/aadhar_card/') . $request->aadhar_card;
                    deleteOldImage($request->aadhar_card_edit, $imagePath);
                }
                $documentRootPath = 'public/individualProducer/documents/aadhar_card';
                $file_path = time() . rand() . '.' . $request->file('aadhar_card')->getClientOriginalExtension();
                $request->file('aadhar_card')->move($documentRootPath, $file_path);
                $aadhar_card = $file_path;
            } else {
                if (!empty($request->aadhar_card_edit))
                    $aadhar_card = $request->aadhar_card_edit;
            }

            if (!empty($request->file('land_document'))) {
                if (!empty($request->land_document_edit)) {
                    $imagePath = public_path('individualProducer/documents/land_document/') . $request->aadhar_card;
                    // deleteOldImage($request->land_document_edit, $imagePath);
                }
                $documentRootPath = 'public/individualProducer/documents/land_document';
                $file_path = time() . rand() . '.' . $request->file('land_document')->getClientOriginalExtension();


                $request->file('land_document')->move($documentRootPath, $file_path);
                $land_document = $file_path;
            } else {
                if (!empty($request->land_document_edit))
                    $land_document = $request->land_document_edit;
            }

            if (!empty($request->file('pan_card'))) {
                if (!empty($request->pan_card_edit)) {
                    $imagePath = public_path('individualProducer/documents/pan_card/') . $request->pan_card;
                    deleteOldImage($request->pan_card_edit, $imagePath);
                }
                $documentRootPath = 'public/individualProducer/documents/pan_card';
                $file_path = time() . rand() . '.' . $request->file('pan_card')->getClientOriginalExtension();
                $request->file('pan_card')->move($documentRootPath, $file_path);
                $pan_card = $file_path;
            } else {
                if (!empty($request->pan_card_edit))
                    $pan_card = $request->pan_card_edit;
            }

            if (!empty($request->file('bank_passbook'))) {
                if (!empty($request->bank_passbook_edit)) {
                    $imagePath = public_path('individualProducer/documents/bank_passbook/') . $request->bank_passbook;
                    deleteOldImage($request->bank_passbook_edit, $imagePath);
                }
                $documentRootPath = 'public/individualProducer/documents/bank_passbook';
                $file_path = time() . rand() . '.' . $request->file('bank_passbook')->getClientOriginalExtension();
                $request->file('bank_passbook')->move($documentRootPath, $file_path);
                $bank_passbook = $file_path;
            } else {
                if (!empty($request->bank_passbook_edit))
                    $bank_passbook = $request->bank_passbook_edit;
            }

            if (!empty($request->file('farmer_sign_thumb_Impression'))) {
                if (!empty($request->farmer_sign_thumb_Impression_edit)) {
                    $imagePath = public_path('individualProducer/documents/farmer_sign_thumb_Impression/') . $request->farmer_sign_thumb_Impression;
                    deleteOldImage($request->farmer_sign_thumb_Impression_edit, $imagePath);
                }
                $documentRootPath = 'public/individualProducer/documents/farmer_sign_thumb_Impression';
                $file_path = time() . rand() . '.' . $request->file('farmer_sign_thumb_Impression')->getClientOriginalExtension();
                $request->file('farmer_sign_thumb_Impression')->move($documentRootPath, $file_path);
                $farmer_sign_thumb_Impression = $file_path;
            } else {
                if (!empty($request->farmer_sign_thumb_Impression_edit))
                    $farmer_sign_thumb_Impression = $request->farmer_sign_thumb_Impression_edit;
            }


            if (!empty($request->file('live_signature_thumb_impression'))) {
                if (!empty($request->live_signature_thumb_impression_edit)) {
                    $imagePath = public_path('individualProducer/documents/live_signature_thumb_impression/') . $request->live_signature_thumb_impression;
                    deleteOldImage($request->live_signature_thumb_impression_edit, $imagePath);
                }
                $documentRootPath = 'public/individualProducer/documents/live_signature_thumb_impression';
                $file_path = time() . rand() . '.' . $request->file('live_signature_thumb_impression')->getClientOriginalExtension();
                $request->file('live_signature_thumb_impression')->move($documentRootPath, $file_path);
                $live_signature_thumb_impression = $file_path;
            } else {
                if (!empty($request->live_signature_thumb_impression_edit))
                    $live_signature_thumb_impression = $request->live_signature_thumb_impression_edit;
            }


            $data = array(
                'at_user_id' => $id,
                'aadhar_card_image_path' => $aadhar_card,
                'pan_card_image_path' => $pan_card,
                'passbook_image_path' => $bank_passbook,
                'land_documents_image_path' => $land_document,
                'contact_person_sign_image_path' => $farmer_sign_thumb_Impression,
                'live_signature_image_path' => $live_signature_thumb_impression,
            );

            // $traders_document = IndividualProducerDocument::find($id);
            $traders_document = IndividualProducerDocument::where('at_user_id', $id)->first();
            //echo $traders_document; die;

            if (!empty($traders_document)) {
                /// echo "exist";   echo $id ; die;
                $data['updated_at'] = date('Y-m-d H:i:s');
                $data['updated_by'] = Auth::guard('misadmin')->user()->id;
                $traders_document->where('id', $traders_document->id)->where('at_user_id', $id)->update($data);
            } else {
                // echo "na";  die;
                $data['created_by'] = Auth::guard('misadmin')->user()->id;
                $data['created_at'] = date('Y-m-d H:i:s');
                IndividualProducerDocument::create($data);
            }


            Alert::success('Success', 'Record updated Successfully');
            if ($request->ref_operator_id == 3) {
                //return redirect()->route('superadmin.usermanagement.deptUser.individualUserAddStep6', $id)->with('success', __('message.add_second_success'));
                return redirect()->route('superadmin.individualProducer.preview', $id)->with('success', __('message.add_second_success'));
            } else {
                return redirect()->back()->with('success', __('message.add_success'));
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }
    public function individualProducerPreview(Request $request, $id)
    {
        
        $user = User::where('id', $id)->first();
        $farmerDetails = IndividualProducerFarmerDetail::where('at_user_id', $id)->get();
        $user = User::where('id', $id)->first();
        $farmerDetails = IndividualProducerFarmerDetail::where('at_user_id', $id)->get();
        $producer_docs = IndividualProducerDocument::where('at_user_id', $id)->get();

        $producer_farm_detail = IndividualProducerFarmDetail::with(['state', 'district', 'blockTehsil'])
            ->where('at_user_id', $id) 
            ->get();
     
        $farm_detail = IndividualProducerFarmDetail::where('at_user_id', $id)->first();        
        if (!empty($farm_detail)) {
            $geo_taggings = IndividualProducerGeoTagging::where('at_ip_farmer_reg_details_id', $farm_detail->at_farmer_reg_details_id)->where('at_ip_farm_details_id', $farm_detail->id)->get();
        } else {
            $geo_taggings = "";
        }

        
        $producer_standing_corp = IndividualProducerDetailOfStandingCorp::where('at_user_id', $id)->get();
        $producer_proposed_corp = IndividualProducerDetailOfProposedCorp::where('at_user_id', $id)->get();
        $states = RefState::orderBy('state_name', 'ASC')->get();

        $eMSignedModuleResult  = '';
        $hostName = '';

        $eMSignedModuleAlow = getUserDigitalSignatureModules(Auth::id(), 'SC');
        if ($eMSignedModuleAlow['status'] == 'success' && $eMSignedModuleAlow['isAllowed'] == '1') {
            $hostName = request()->getSchemeAndHttpHost();
            $checkSignedPDf = getDigitalSignedPdf(Auth::id(), basename($user->registration_certificate));
            if ($checkSignedPDf['status'] == 'success') {
                $eMSignedModuleResult = [
                    'signedPath' => $checkSignedPDf['signedPath'],
                    'status' => 'success',
                ];
            } else {
                $eMSignedModuleResult = [
                    'signedPath' => '',
                    'status' => 'failed',
                ];
            }
        }

        return view('admin/usermanagement/deptUser/individual_producer_preview', compact('id', 'user', 'farmerDetails', 'producer_docs', 'states', 'producer_farm_detail', 'producer_standing_corp', 'producer_proposed_corp', 'eMSignedModuleAlow', 'eMSignedModuleResult', 'hostName','geo_taggings'));
    }


    public function individualProducerPreviewPdf($id)
    {


        $user = User::where('id', $id)->first();
        $farmerDetails = IndividualProducerFarmerDetail::where('at_user_id', $id)->get();
        $producer_docs = IndividualProducerDocument::where('at_user_id', $id)->get();

        $producer_farm_detail = IndividualProducerFarmDetail::where('at_user_id', $id)->get();

        $producer_standing_corp = IndividualProducerDetailOfStandingCorp::where('at_user_id', $id)->get();
        $producer_proposed_corp = IndividualProducerDetailOfProposedCorp::where('at_user_id', $id)->get();
        $states = RefState::orderBy('state_name', 'ASC')->get();

        $pdf = PDF::loadView('admin/usermanagement/deptUser/pdf_test', compact('id', 'user', 'farmerDetails', 'producer_docs', 'states', 'producer_farm_detail', 'producer_standing_corp', 'producer_proposed_corp'));

        $filePath = base_path('/esign/cert/invpusha' . time() . '.pdf');
        $directoryPath = dirname($filePath);
        if (!File::exists($directoryPath)) {
            File::makeDirectory($directoryPath, 0777, true);
        }
        $pdf->save($filePath);
        return redirect()->back();
    }


    public function ipbatchCreationindex(Request $request, $at_user_id)
    {
        $product_details = IndividualProducerDetailOfProposedCorp::where('at_user_id', $at_user_id)->get();
        //dd($product_details);
        return view('admin.individualproducer.batch_add', compact('product_details'));
    }

    public function ipbatchCreation(Request $request, $at_user_id)
    {

        $list = CertificateStandardDetail::where('at_user_id', $at_user_id)->first();
        $org_st = IndividualProducerDetailOfProposedCorp::where('at_user_id', $at_user_id)->first();
        $user = User::where('id', $at_user_id)->first();


        //dd($org_st);
        return view('admin/individualproducer/create_batch', compact('list', 'org_st', 'user'));
    }

    /* public function batchCreationsave(Request $request)
    {
        // $request->validate([
        //     'scope_certificate_no' => 'required',
        //     'hs_code' => 'required',
        //     'product' => 'required',
        // ]);


        $formData = new BatchCreation;

        $formData->scope_certificate_no = $request->input('scope_certificate_no');
        $formData->unit_name = $request->input('unit_name');
        $formData->hs_code = $request->input('hs_code');
        $formData->product = $request->input('product');
        $formData->organic_status = $request->input('organic_status');
        $formData->quantity = $request->input('quantity');
        $formData->percentage = $request->input('percentage');
        $formData->processing_date = $request->input('processing_date');
        $formData->expiry_date = $request->input('expiry_date');
        $formData->by_product = $request->input('byProduct');
        $formData->created_at = date('Y-m-d H:i:s');
        $formData->updated_at = date('Y-m-d H:i:s');
        $formData->created_by = Auth::guard('misadmin')->user()->id;
        $formData->updated_by = Auth::guard('misadmin')->user()->id;
        $formData->at_user_id = Auth::guard('misadmin')->user()->id;

        $formData->save();
        // dd($formData);


        return redirect()->route('superadmin.ipbatchCreationsouceDetails');
    }*/

    public function batchCreationsave(Request $request)
    {
        // Create a new BatchCreation instance and populate its fields
        $formData = new BatchCreation;
        $formData->scope_certificate_no = $request->input('scope_certificate_no');
        $formData->unit_name = $request->input('unit_name');
        $formData->hs_code = $request->input('hs_code');
        $formData->product = $request->input('product');
        $formData->organic_status = $request->input('organic_status');
        $formData->quantity = $request->input('quantity');
        $formData->percentage = $request->input('percentage');
        $formData->processing_date = $request->input('processing_date');
        $formData->expiry_date = $request->input('expiry_date');
        $formData->by_product = $request->input('byProduct');
        $formData->created_at = now();
        $formData->updated_at = now();
        $formData->created_by = Auth::guard('misadmin')->user()->id;
        $formData->updated_by = Auth::guard('misadmin')->user()->id;
        $formData->at_user_id = Auth::guard('misadmin')->user()->id;

        // Save the BatchCreation record
        $formData->save();

        // Retrieve the id of the newly created BatchCreation record
        $batchCreationId = $formData->id;

        $atBatchDetail = new AtBatchDetail;
        $atBatchDetail->batch_id = $batchCreationId;
        $atBatchDetail->product_code =  $request->input('hs_code');
        $atBatchDetail->product_name =  $request->input('product');
        $atBatchDetail->total_quantity =  $request->input('quantity');
        $atBatchDetail->created_at = now();
        $atBatchDetail->updated_at = now();
        $atBatchDetail->created_by = Auth::guard('misadmin')->user()->id;
        $atBatchDetail->updated_by = Auth::guard('misadmin')->user()->id;
        $atBatchDetail->at_user_id = Auth::guard('misadmin')->user()->id;
        $atBatchDetail->save();

        // Redirect the user to the desired route after successful insertion
        return redirect()->route('superadmin.ipbatchCreationsouceDetails');
    }

    public function ipbatchCreationsouceDetails()
    {
        return view('admin/individualproducer/source_detail');
    }

    public function batchCreationPreviewDetails($at_user_id)
    {

        $data = BatchCreation::where('at_user_id', $at_user_id)->first();
        $Sourcedata = AtBatchDetail::where('at_user_id', $at_user_id)->get();
        //dd($Sourcedata);


        return view('admin/individualproducer/preview_detail', compact('data', 'Sourcedata'));
    }

    public function saveQuantitySource(Request $request)
    {
        // dd($request->all());
        $at_user_id = Auth::guard('misadmin')->user()->id;
        $rowId = $request->input('row_id');
        $tcNo = $request->input('tc_no');
        $procode = $request->input('pro_code');
        $qty = $request->input('total_quantity');
        $usedqty = $request->input('used_quantity');
        $available_qnt = $request->input('available_qnt');
        $qntSourceValue = $request->input('qnt_source');
        $batch_id = $request->input('row_id');
        //dd($batch_id);

        $record = new AtBatchDetail;

        if ($record) {

            $record->at_user_id = $at_user_id;
            $record->product_code = $procode;
            $record->tc_no = $tcNo;
            // $record->organic_status = $organic_statusValue;
            $record->total_quantity = $qty;
            $record->source_from = 'TC';
            $record->used_quantity =   $usedqty;
            $record->available_quantity = $available_qnt;
            $record->expiry_date = $request->input('expiry_date');
            $record->quantity_source = $qntSourceValue;
            $record->batch_id = $batch_id;

            $record->save();


            return response()->json(['success' => true, 'message' => 'Saved successfully']);
        } else {

            return response()->json(['success' => false, 'message' => 'Record not found'], 404);
        }
    }

    public function Search(Request $request)
    {
        try {
            // Check if the request is an AJAX request
            if ($request->ajax()) {

                $userId = Auth::id();
                $query = AtOpTransactionVsTransactionProduct::query()
                    ->where('created_by', $userId);


                if (!empty($request->registration_no)) {
                    $query->where('product_code', $request->registration_no);
                }
                $finalData = $query->get();
                // dd($finalData);

                // Use DataTables to format the data
                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()
                    ->addColumn('tc_no', function ($row) {
                        return $row->transaction_certificate_no;
                    })
                    ->addColumn('product_name', function ($row) {
                        return $row->product_code;
                    })
                    ->addColumn('organic_status', function ($row) {
                        return $row->organic_status;
                    })
                    ->addColumn('total_qnt', function ($row) {
                        return $row->total_qty;
                    })
                    ->addColumn('used_qnt', function ($row) {
                        return $row->quantity_for_tc;
                    })
                    ->addColumn('available_qnt', function ($row) {
                        return $row->rem_qty;
                    })
                    ->addColumn('qnt_source', function ($row) {

                        $uniqueId = 'qnt_source_' . $row->id;
                        return sprintf(
                            '<input type="text" class="form-control" id="qnt_source' . $row->id . '"  name="qnt_source" value="">',
                            $uniqueId,
                            $row->id,
                            $row->qnt_source
                        );
                    })
                    ->addColumn('action', function ($row) {

                        return '<a href="javascript:;" class="saveButton" data-id="' . $row->id . '" data-tcno="' . $row->transaction_certificate_no . '" data-procode="' . $row->product_code . '" data-qty ="' . $row->total_qty . '" data-usedqty ="' . $row->quantity_for_tc . '" data-available_qnt="' . $row->rem_qty . '">Add</a>';
                    })
                    ->rawColumns(['qnt_source', 'action']);


                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            // Handle exceptions and log errors
            Log::error($e);
            Alert::error('Error', 'Something went wrong, please try again later.');
            return redirect()->back();
        }
    }

    public function batchCreationPreviewDetailssave(Request $request)
    {
        return redirect()->route('superadmin.IpDetails',  auth()->user()->id);
    }

    public function Details($at_user_id)
    {

        $data = AtBatchDetail::where('at_user_id', $at_user_id)->get();

        // dd($data);
        return view('admin/individualproducer/batch_detail', compact('data'));
    }

    public function History()
    {

        $data = AtBatchDetail::get();
        return view('admin.individualproducer.history', compact('data'));
    }

    public function applyForDomesticTC($id = NULL)
    {

        $user_id = Auth::guard('misadmin')->user()->id;
        $operator_type_id = Auth::guard('misadmin')->user()->ref_operator_type_id;
        $order_list2 = DB::select("select * from at_batch_creation where at_user_id = $user_id");
        $order = array();
        $j = 0;
        $data = IndividualProducerDetailOfProposedCorp::with('getFramsDetails')->where('at_user_id', $user_id)->get();
        foreach ($order_list2 as $key => $vls) {
            $order['purchase_list'][$key] = $vls;
            $purchases = AtBatchDetail::where('batch_id', $vls->id)->get();
            $order['purchase_list'][$key]->mypurchase = $purchases;
        }
        return view('admin.individualproducer.apply_for_domestic_tc', compact('order', 'data'));
    }

    public function storeApplyForDomesticTCT(Request $request)
    {
        // dd($request->all());
        $request->validate([
            //'transportation_date' => 'required',
        ]);
        try {
            $operator_type_id = Auth::guard('misadmin')->user()->ref_operator_type_id;
            foreach ($request->lots as $key => $val) {
                if (!empty($request->lots[$key])) {
                    $data = array(
                        'farm_no'   => !empty($request->farm_no[$key]) ? $request->farm_no[$key] : NULL,
                        'total_qty'   => !empty($request->total_qty[$key]) ? $request->total_qty[$key] : NULL,
                        'tc_date'   => date('Y-m-d'),
                        'operator_type'   => !empty($operator_type_id) ? $operator_type_id : NULL,
                        'rem_qty'   => !empty($request->rem_qty[$key]) ? $request->rem_qty[$key] : NULL,
                        // 'quantity_for_tc'   => $request->req_qty[$key],
                        'product_code' => !empty($request->product_code[$key]) ? $request->product_code[$key] : NULL,
                        'organic_status' => !empty($request->organic_status[$key]) ? $request->organic_status[$key] : NULL,
                        //'quantity_for_tc'   => $request->quantity_for_tc[$key],
                        'created_by' => Auth::guard('misadmin')->user()->id,
                        'updated_by' => Auth::guard('misadmin')->user()->id
                    );
                    $result = AtOpTransactionVsTransactionProduct::updateOrCreate([
                        'id'   => $request->row_id[$key],
                    ], $data);
                    if (!empty($result)) {
                        foreach ($request->pur_lots[$key]  as $k => $val1) {

                            if (!empty($request->pur_lots[$key])) {
                                $data1 = array(
                                    'at_op_transaction_vs_transaction_product_id'   => !empty($result->id) ? $result->id : NULL,
                                    'ref_product_id'   => !empty($result->product_code) ? $result->product_code : NULL,
                                    'at_closing_stock_id'   => !empty($request->at_closing_stock_id[$key][$k]) ? $request->at_closing_stock_id[$key][$k] : NULL,
                                    // 'at_purchase_details_id'   => $request->at_purchase_details_id[$key][$k],
                                    // 'product_code' =>'',
                                    'organic_status' => !empty($request->op_organic_status[$key][$k]) ? $request->op_organic_status[$key][$k] : NULL,
                                    'qty_in_mt' => !empty($request->used_quantity[$key][$k]) ? $request->used_quantity[$key][$k] : NULL,
                                    'source_date'   => date('Y-m-d'),
                                    'created_by' => Auth::guard('misadmin')->user()->id,
                                    'updated_by' => Auth::guard('misadmin')->user()->id
                                );
                                $result1 = AtOpTransactionProductSourced::updateOrCreate([
                                    'id'   => $request->rows_id[$key][$k],
                                ], $data1);
                            }
                        }
                        if (!empty($result1->id)) {
                            Alert::success('Success', __('message.add_success'));
                            return redirect()->route('superadmin.IPtrader.packingDetailTC', [$result->id]);
                        } else {
                            Alert::success('Success', 'Something went wrong.');
                            return redirect()->back();
                        }
                    }
                }
            }
        } catch (Exception $e) {

            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function storeIcsHarvestProduct(Request $request)
    {

        $validator = \Validator::make($request->all(), [
            'actual_yield' => 'required',
            'harvest_date' => 'required',
            'sowing_date' => 'required',
            'product_id' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()->all()]);
        }

        try {

            $insertData = array(
                'actual_yield' =>  $request->actual_yield,
                'harvest_date' => date('Y-m-d', strtotime($request->harvest_date)),
                'sowing_date' => date('Y-m-d', strtotime($request->sowing_date)),
                'updated_at' => date('Y-m-d H:i:s'),
                'updated_by' => Auth::guard('misadmin')->user()->id,
            );

            AtFarmerStandingCorpDetail::where('id', $request->product_id)->update($insertData);
            $input_approval = AtFarmerStandingCorpDetail::where('id', $request->product_id)->first();

            $insert_closing_stock = array(
                'at_farmer_standing_crop_details_id' => $input_approval->id,
                'ref_operator_type_id' => Auth::guard('misadmin')->user()->ref_operator_type_id,
                'at_user_id' => Auth::guard('misadmin')->user()->id,
                'organic_status' => $input_approval->organic_status,
                'ref_product_id' => $request->product_id,
                'date_of_harvest' => date('Y-m-d', strtotime($input_approval->harvest_date)),
                'harvest_year' => date('Y'),
            );
            //dd($insert_closing_stock);
            $result = AtClosingStock::create($insert_closing_stock);

            if (!empty($result)) {
                return response()->json(['status' => 1, 'data' => $input_approval, 'msg' => 'Data is successfully added.']);
            } else {
                return response()->json(['status' => 2, 'data' => $input_approval, 'msg' => 'Something went wrong.']);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            // abort('404');
        }
    }

    public function packingDetailTC($id)
    {
        $trans = AtOpTransactionVsTransactionProduct::with('getTransProductSource')->where('id', $id)->get();
        // dd($trans);
        // packing master list get
        $packs = RefPackingMaster::get();
        //AtOpTransactionPackingDetails::where(['product_code'=>$trans[0]->ref_product_id,'crested_by',Auth::guard('misadmin')->user()->id])->get();
        //dd($packDet);

        return view('admin.individualproducer.packing_detail_tc', compact('trans', 'packs'));
    }

    public function storePackingDetailTC(Request $request)
    {

        $request->validate([
            'value_inr' => 'required',
            'trade_name_of_product' => 'required',
            'ref_packing_master_id.*' => 'required',
            'no_of_box.*' => 'required',
            'pack_size.*' => 'required',
            'total_qty_in_kg.*' => 'required',
        ]);
        // if(!empty($validator->fails())) {
        // 	return Redirect::back()->withErrors($validator);
        // }
        try {
            // dd($request->all());
            $operator_type_id = Auth::guard('misadmin')->user()->ref_operator_type_id;
            $edtVal = 0;
            if (!empty($request->at_op_transaction_product_sourced_id)) {
                foreach ($request->at_op_transaction_product_sourced_id as $key => $val) {

                    if (!empty($request->at_op_transaction_product_sourced_id[$key])) {
                        $data = array(
                            'at_op_transaction_product_sourced_id'   => $request->at_op_transaction_product_sourced_id[$key],
                            'ref_product_id'   => $request->ref_product_id,
                            'ref_packing_master_id'   => $request->ref_packing_master_id[$key],
                            'no_of_box'   => $request->no_of_box[$key],
                            'pack_size'   => $request->pack_size[$key],
                            'total_qty_in_kg'   => $request->total_qty_in_kg[$key],
                            'created_by' => Auth::guard('misadmin')->user()->id,
                            'updated_by' => Auth::guard('misadmin')->user()->id
                        );
                        if (isset($request->row_id[$key])) {
                            $result = AtOpTransactionPackingDetails::create($data);
                        } else {
                            $result = AtOpTransactionPackingDetails::where('id', $request->row_id[$key])->update($data);
                        }

                        // $result = AtOpTransactionPackingDetails::updateOrCreate([
                        //     'id' => $request->row_id[$key],
                        // ], $data);
                    }
                }

                if (!empty($result)) {
                    $updateData = array(
                        'value_inr' => $request->value_inr,
                        'trade_name_of_product' => $request->trade_name_of_product,
                    );
                    $res = AtOpTransactionVsTransactionProduct::where('id', $request->trans_id)->update($updateData);

                    //if(isset($request->row_id[0]) && $request->row_id[0]!=''){
                    Alert::success('Success', __('message.add_success'));
                    return redirect()->route('superadmin.iptrader.TcDetail', $request->trans_id);
                    // }else{
                    // 	Alert::success('Success', __('message.add_success'));
                    // 	return redirect()->back();
                    // }

                }
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function TcDetail($id)
    {

        $data =  AtOpTransactionCertificateEntry::where('at_op_transaction_vs_transaction_product_id', $id)->first();
        return view('admin.individualproducer.tc_details', compact('id', 'data'));
    }

    public function IPapplyForDomesticTC($id = NULL)
    {

        $user_id = Auth::guard('misadmin')->user()->id;

        $operator_type_id = Auth::guard('misadmin')->user()->ref_operator_type_id;

        // $order_list2 = AtPurchaseRequest::select('at_purchase_request.*')
        // ->join('at_order_details_received_from_buyer as odrb','odrb.at_purchase_request_id','at_purchase_request.id')
        // ->join('at_order_accepted','at_order_accepted.at_order_details_received_from_buyer_id','odrb.id')
        // ->join('at_closing_stock','at_closing_stock.at_user_id','at_purchase_request.at_user_id')
        // ->join('at_farmer_standing_crop_details','at_farmer_standing_crop_details.id','at_closing_stock.at_farmer_standing_crop_details_id')
        // ->where('at_purchase_request.at_user_id',$user_id)
        // ->orderBy('at_purchase_request.created_at', 'asc')
        // ->get();

        $order_list2 = DB::select("select at_purchase_request.id, at_purchase_request.commodity, at_closing_stock.id as clsid,at_closing_stock.organic_status, at_closing_stock.closing_stock, at_purchase_request.quantity from at_purchase_request INNER join at_order_details_received_from_buyer as odrb on odrb.at_purchase_request_id = at_purchase_request.id inner join at_order_accepted on at_order_accepted.at_order_details_received_from_buyer_id = odrb.id inner join at_closing_stock on at_closing_stock.at_user_id = at_purchase_request.at_user_id and at_closing_stock.ref_product_id = at_purchase_request.commodity
        inner join at_farmer_standing_crop_details on at_farmer_standing_crop_details.id = at_closing_stock.at_farmer_standing_crop_details_id where at_purchase_request.at_user_id = $user_id and at_purchase_request.order_status = 1  group BY (at_purchase_request.commodity,at_purchase_request.id,at_closing_stock.organic_status,closing_stock,at_purchase_request.quantity,at_closing_stock.id)");

        $order = array();
        $j = 0;

        foreach ($order_list2 as $key => $vls) {
            $order['purchase_list'][$key] = $vls;
            $purchases = AtPurchaseDetails::where('at_closing_stock_id', $vls->clsid)->get();
            $order['purchase_list'][$key]->mypurchase = $purchases;
        }

        $data = AtOpTransactionVsTransactionProduct::with('getTransProductSource')->where('created_by', Auth::guard('misadmin')->user()->id)->get();
        //dd($order);
        //dd($data);

        //$data= array();
        // here aaproved purchase req from trader/processor should be display here
        // $order_list = AtClosingStock::with('getPurchaseDetails')
        // ->when($operator_type_id == 2, function($q) {
        // 	$q->with('getFarmerStandingCorpDetail');
        // })
        /* ->when($operator_type_id == 3, function($q) {
			$q->with('IPDetailOfStandingCorp');
		})
		->when($operator_type_id == 4, function($q) {
			$q->with('getwhproducts');
		})	 */
        // ->where('at_user_id',$user_id)
        // ->orderBy('created_at', 'asc')
        // ->get();
        // pra($order_list);
        return view('admin.individualproducer.apply_for_domestic_tc', compact('order', 'data'));
    }

    public function storeTcDetail(Request $request)
    {
        // dd($request->all());
        $request->validate([
            'invoice_no' => 'required',
            'invoice_date' => 'required',
            'invoice_value' => 'required',
            //'place_of_dispatch' => 'required',
            'lot_number' => 'required',
            'place_of_destination' => 'required',
            'marks_no' => 'required',
            'reference_no' => 'required',
        ]);
        // if(!empty($validator->fails())) {
        // 	return Redirect::back()->withErrors($validator);
        // }
        try {

            /// Date of Transport
            if (!empty($request->road_transport_date)) {
                $transport_date = date('Y-m-d H:i:s', strtotime($request->road_transport_date));
            } elseif (!empty($request->train_transport_date)) {
                $transport_date = date('Y-m-d H:i:s', strtotime($request->train_transport_date));
            } else {
                $transport_date = null;
            }


            // dd(date('Y-m-d H:i:s',strtotime($request->invoice_date[0])));
            $data = array(
                'exporter_seller_name' => !empty($request->exporter_seller_name) ? $request->exporter_seller_name : null,
                'seller_email' => !empty($request->seller_email) ? $request->seller_email : null,
                'seller_at_op_certificate_standard_details_id' => !empty($request->seller_at_op_certificate_standard_details_id) ? $request->seller_at_op_certificate_standard_details_id : null,
                'exporter_seller_address' => !empty($request->exporter_seller_address) ? $request->exporter_seller_address : null,
                'buyer_id_proof' => !empty($request->buyer_id_proof) ? $request->buyer_id_proof : null,
                'buyer_name' => !empty($request->buyer_name) ? $request->buyer_name : null,
                'buyer_address' => !empty($request->buyer_address) ? $request->buyer_address : null,
                'buyer_at_op_certificate_standard_details_id' => !empty($request->buyer_at_op_certificate_standard_details_id) ? $request->buyer_at_op_certificate_standard_details_id : null,
                'buyer_ref_state_id' => !empty($request->buyer_ref_state_id) ? $request->buyer_ref_state_id : null,
                'buyer_email' => !empty($request->buyer_email) ? $request->buyer_email : null,
                'invoice_no' => !empty($request->invoice_no[0]) ? $request->invoice_no[0] : null,
                'invoice_date' => !empty($request->invoice_date[0]) ? date('Y-m-d H:i:s', strtotime($request->invoice_date[0])) : null,
                'invoice_value' => !empty($request->invoice_value) ? $request->invoice_value : null,
                //'place_of_dispatch' => !empty($request->place_of_dispatch) ? $request->place_of_dispatch : null,
                'place_of_destination' => !empty($request->place_of_destination) ? $request->place_of_destination : null,
                'marks_no' => !empty($request->marks_no) ? $request->marks_no : null,
                'reference_no' => !empty($request->reference_no) ? $request->reference_no : null,
                'transport_mode' => !empty($request->transport_mode) ? $request->transport_mode : null,

                'container_no_road' => !empty($request->container_no_road) ? $request->container_no_road : null,
                'transport_doc_no' => !empty($request->transport_doc_no) ? $request->transport_doc_no : null,
                'transport_date' => !empty($transport_date) ? $transport_date : null,

                'train_no' => !empty($request->train_no) ? $request->train_no : null,
                'wagon_no' => !empty($request->wagon_no) ? $request->wagon_no : null,
                'train_transport_date' => !empty($request->train_transport_date) ? date('Y-m-d H:i:s', strtotime($request->train_transport_date)) : null,

                'flight_no' => !empty($request->flight_no) ? $request->flight_no : null,
                'flight_date' => !empty($request->flight_date) ? date('Y-m-d H:i:s', strtotime($request->flight_date)) : null,
                'airway_bill_no' => !empty($request->airway_bill_no) ? $request->airway_bill_no : null,
                'airway_bill_date' => !empty($request->airway_bill_date) ? date('Y-m-d H:i:s', strtotime($request->airway_bill_date)) : null,
                'container_no_air' => !empty($request->container_no_air) ? $request->container_no_air : null,

                'ship_no' => !empty($request->ship_no) ? $request->ship_no : null,
                'ship_name' => !empty($request->ship_name) ? $request->ship_name : null,
                'vessel_date' => !empty($request->vessel_date) ? $request->vessel_date : null,
                'bill_of_lading' => !empty($request->bill_of_lading) ? $request->bill_of_lading : null,
                'date_of_lading' => !empty($request->date_of_lading) ? $request->date_of_lading : null,
                'container_no_ship' => !empty($request->container_no_ship) ? $request->container_no_ship : null,

                'gross_weight' => !empty($request->gross_weight) ? $request->gross_weight : null,
                'created_by' => Auth::guard('misadmin')->user()->id,
                'updated_by' => Auth::guard('misadmin')->user()->id,
                'at_op_transaction_vs_transaction_product_id' => !empty($request->at_op_transaction_vs_transaction_product_id) ? $request->at_op_transaction_vs_transaction_product_id : null,
                'lot_number' => !empty($request->lot_number) ? $request->lot_number : null,
            );
            // dd($data);
            $saveData = AtOpTransactionCertificateEntry::updateOrCreate(['at_op_transaction_vs_transaction_product_id' => $request->at_op_transaction_vs_transaction_product_id], $data);

            Alert::success('Success', __('message.add_success'));
            return redirect()->route('superadmin.IPforwardToCB', $request->at_op_transaction_vs_transaction_product_id);
            // if(!empty($saveData)){
            // 	Alert::success('Success', __('message.add_success'));
            // 	return redirect()->route('superadmin.TcDetail',$request->at_op_transaction_vs_transaction_product_id);
            // }else{
            // 	Alert::success('Success', 'Something Went Wrong!');
            // 	return redirect()->back();
            // }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function forwardToCB($id)
    {

        return view('admin.individualproducer.forwardToCB', compact('id'));
    }

    public function postForwardToCB(Request $request)
    {
        //dd($request->all());
        try {
            $data = AtOpTransactionVsTransactionProduct::select('created_at', 'id')->where('id', $request->row_id)->first();
            if ($data) {
                $m = date('m', strtotime($data->created_at));
                $y = date('y', strtotime($data->created_at));
                $lst = str_pad($data->id, 4, "0", STR_PAD_LEFT);
                $app_no = "TC-" . $y . $m . $lst;
            }
            $upData = array(
                'tc_application_no' => $app_no,
                'tc_date' => date('Y-m-d'),
                'nop_status' => 'Pending',
            );

            $res = AtOpTransactionVsTransactionProduct::where('id', $request->row_id)->update($upData);

            if ($res > 0) {
                Alert::success('Success', __('message.add_success'));
                return redirect()->route('superadmin.IPlistOfTransCertificate');
            } else {
                Alert::error('', 'Something went Wrong.');
                return redirect()->back();
            }
        } catch (Exception $e) {
            //dd($e->getMessage());
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function listOfTransCertificate(Request $request)
    {
        $id = Auth::guard('misadmin')->user()->id;
        $totalData = AtOpTransactionVsTransactionProduct::where('created_by', $id)->get();
        
        
        if ($request->ajax()) {
            
            return Datatables::of($totalData)
                ->addIndexColumn()
                ->addColumn('tc_application_no', function ($row) {
                    return $row->tc_application_no;
                })->addColumn('tc_date', function ($row) {
                    return date('d-m-Y', strtotime($row->tc_date));
                })->addColumn('seller', function ($row) {
                    return $row->quantity;
                })->addColumn('buyer', function ($row) {
                    return getHscodeProductName($row->commodity) ?? '';
                })->addColumn('country', function ($row) {
                    return 'INDIA';
                })->addColumn('status', function ($row) {
                    return  $row->nop_status ?? '';
                })->addColumn('tc_type', function ($row) {
                    return  'Domestic';
                })->addColumn('action', function ($row) {

                    $actionBtn = '<a href="' . route('superadmin.IPviewTCApplication', [$row->id]) . '" class="btn btn-soft-primary ms-2"><span><i class="ri-file-edit-fill" data-toggle="tooltip" title="Apply for domestic TC" ></i></span></a>';

                    return $actionBtn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        return view('admin.individualproducer.listOfTransCertificate');
    }

    public function viewTCApplication($id)
    {

        $trans = AtOpTransactionVsTransactionProduct::with('getTransProductSource')->where('id', $id)->get();
        //$packs = RefPackingMaster::get();
        //dd($trans[0]->getTransProductSource);
        $data =  AtOpTransactionCertificateEntry::where('at_op_transaction_vs_transaction_product_id', $id)->first();
        return view('admin.individualproducer.viewApplication', compact('id', 'trans', 'data'));
    }

    public function tsIssueList()
    {
        $tcIssueList = AtOpTransactionVsTransactionProduct::whereNotNull('tc_application_no')->get();


        return view('admin.individualproducer.tc_issue_list', ['tcIssueList' =>  $tcIssueList]);
    }

    public function TcViewApplication($id)
    {

        $tcIssueList = AtOpTransactionVsTransactionProduct::where('id', $id)->get();

        return view('admin.individualproducer.cbTcviewApplication', compact('tcIssueList'));
    }
}

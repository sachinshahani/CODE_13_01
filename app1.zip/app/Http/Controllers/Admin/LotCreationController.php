<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;
use Yajra\DataTables\DataTables;
use App\Models\AtFarmerStandingCorpDetail;
use App\Models\User;
use App\Models\AtFarmDetails;
use App\Models\AtClosingStock;
use App\Models\RefProcuremenEntry;
use App\Models\AtFarmerRegDetail;
use App\Models\IndividualProducerFarmDetail;
use App\Models\IndividualProducerDetailOfStandingCorp;
use App\Models\IndividualProducerFarmerDetail;
//use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\DB;
use Exception;

class LotCreationController extends Controller
{
    public function lotcreation(Request $request)
    {
        // $user_id = Auth::guard('misadmin')->user()->id;
        return view('admin.lot_creation.lotcreation');
    }


    public function LotCreationYieldScope()
    {

        $user_id = Auth::guard('misadmin')->user()->id;
        $products = AtFarmerStandingCorpDetail::where('updated_by', $user_id)->get();
        $stocks = AtClosingStock::where('at_user_id', $user_id)->get();
        // dd($stock);

        return view('admin.lot_creation.next-step', compact('products', 'stocks'));
    }

    public function Step2($id)
    {
        $user_id = Auth::guard('misadmin')->user()->id;
        $data = AtFarmerStandingCorpDetail::join('at_closing_stock as b', 'b.at_farmer_standing_crop_details_id', '=', 'at_farmer_standing_crop_details.id')
            //->join('ref_procurement_entry as p', 'p.ref_product_id', '=', 'at_farmer_standing_crop_details.id')
            ->select('at_farmer_standing_crop_details.*', 'b.harvest_year', 'b.closing_stock', 'b.date_of_harvest')
            ->where('at_farmer_standing_crop_details.id', $id)
            ->first();
        $procuredata = RefProcuremenEntry::where('ref_product_id', $id)->first();
        //$products = AtFarmerStandingCorpDetail::where('id', $id )->get();
        return view('admin.lot_creation.step2', compact('data', 'procuredata'));
    }

    public function saveLotDetails(Request $request)
    {
        $atUserId = Auth::guard('misadmin')->user()->id;

        // Validate the incoming request data
        $validatedData = $request->validate([
            'id' => 'required|integer',
            'quantity_source' => 'required|numeric',
            'receipt_no' => 'required|string|max:255',
            'receipt_date' => 'required|date',
            'at_farmer_details_id' => 'required|integer',
            // 'at_farm_details_id' => 'required|integer',
        ]);

        $id = $validatedData['id'];


        $existingEntry = RefProcuremenEntry::where('ref_product_id', $id)->first();

        if ($existingEntry) {
            return response()->json(['error' => 'Data for this product ID already exists'], 400);
        }

        $data = [
            'ref_product_id' => $id,
            'quantity_source' => $validatedData['quantity_source'],
            'receipt_no' => $validatedData['receipt_no'],
            'receipt_date' => $validatedData['receipt_date'],
            'at_farmers_details_id' => $validatedData['at_farmer_details_id'],
            // 'at_farms_details_id' => $validatedData['at_farm_details_id'],
            'created_at' => now(),
            'updated_at' => now(),
            'created_by' => $atUserId,
            'lot_number' => ''
        ];

        RefProcuremenEntry::create($data);

        return response()->json(['message' => 'Lot details saved successfully']);
    }

    public function generateLotNumber(Request $request)
    {
        $refProductId = $request->input('ref_product_id');

        $entry = RefProcuremenEntry::where('ref_product_id', $refProductId)->first();

        if ($entry) {
            $lotNumber = 'LOT' . str_pad($entry->id, 8, '0', STR_PAD_LEFT);

            // Update the entry with the new lot number
            $entry->update(['lot_number' => $lotNumber]);

            return response()->json(['success' => true, 'message' => 'Lot number generated successfully']);
        }

        return response()->json(['success' => false, 'message' => 'Entry not found']);
    }

    public function LotDetails($id)
    {
        $user_id = Auth::guard('misadmin')->user()->id;
        $entry = RefProcuremenEntry::where('ref_product_id', $id)->first();
        $products = AtFarmerStandingCorpDetail::where('updated_by', $user_id)->first();
        return view('admin.lot_creation.step3', compact('entry', 'products'));
    }

    public function delete($id)
    {
        $entry = RefProcuremenEntry::where('ref_product_id', $id)->first();

        if ($entry) {
            $entry->is_deleted = date('Y-m-d H:i:s'); // Assuming 'is_deleted' is the column name
            $entry->save();
            return response()->json(['success' => true]);
        } else {
            return response()->json(['success' => false]);
        }
    }

    public function ViewLotsDetail()
    {
        $user_id = Auth::guard('misadmin')->user()->id;
        $entry = RefProcuremenEntry::where('created_by', $user_id)->get();
        // Extract all ref_product_ids from the entries
        $ref_product_ids = $entry->pluck('ref_product_id');
        $products = AtFarmerStandingCorpDetail::whereIn('id', $ref_product_ids)->get();

        return view('admin.lot_creation.view-lots-detail', compact('entry', 'products'));
    }

    public function Step3()
    {
        return view('admin.lot_creation.step3');
    }

    public function Step3Save()
    {

        return view('admin.lot_creation.step4');
    }

    public function icsearchlots(Request $request)
    {
        try {
            if ($request->ajax()) {
                $createdBy = Auth::guard('misadmin')->user()->id;

                $query = AtFarmerStandingCorpDetail::join('at_closing_stock', function ($join) {
                    $join->on(DB::raw('CAST(at_closing_stock.created_by AS VARCHAR)'), '=', DB::raw('CAST(at_farmer_standing_crop_details.created_by AS VARCHAR)'));
                })
                    ->join('at_batch_details as bd', function ($join) {
                        $join->on(DB::raw('CAST(bd.created_by AS VARCHAR)'), '=', DB::raw('CAST(at_farmer_standing_crop_details.created_by AS VARCHAR)'));
                    })
                    ->join('at_batch_creation as bc', function ($join) {
                        $join->on(DB::raw('CAST(bc.created_by AS VARCHAR)'), '=', DB::raw('CAST(at_farmer_standing_crop_details.created_by AS VARCHAR)'));
                    })
                    ->select(
                        DB::raw('DISTINCT at_farmer_standing_crop_details.*'),
                        'at_closing_stock.harvest_year',
                        'at_closing_stock.closing_stock',
                        'bc.hs_code',
                        'bd.total_quantity',
                        'bd.source_from'
                    )
                    ->where(DB::raw('CAST(at_farmer_standing_crop_details.created_by AS VARCHAR)'), $createdBy);

                $finalData = $query->get();
                Log::info('Final Data:', $finalData->toArray());

                // Construct the DataTable response     
                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()
                    ->addColumn('id', function ($row) {
                        return $row->id ?? '';
                    })
                    ->addColumn('crop_name', function ($row) {
                        return $row->crop_name ?? '';
                    })
                    ->addColumn('hs_code', function ($row) {
                        return $row->hs_code ?? '';
                    })
                    ->addColumn('organic_status', function ($row) {
                        return $row->organic_status ?? '';
                    })
                    ->addColumn('source_from', function ($row) {
                        return $row->source_from ?? '';
                    })
                    ->addColumn('harvest_year', function ($row) {
                        return $row->harvest_year ?? '';
                    })
                    ->addColumn('estimated_yield', function ($row) {
                        return $row->estimated_yield ?? '';
                    })
                    ->addColumn('closing_stock', function ($row) {
                        return $row->closing_stock ?? '';
                    })
                    ->addColumn('actual_yield', function ($row) {
                        return $row->actual_yield ?? '';
                    })
                    ->addColumn('action', function ($row) {
                        $csrfToken = csrf_token();
                        $deleteRoute = route('superadmin.Step2', $row->id);

                        return '
                            <form action="' . $deleteRoute . '" method="get" style="display:inline;">
                                <input type="hidden" name="_token" value="' . $csrfToken . '">
                                <input type="hidden" name="_method" value="">
                                <button type="submit" class="btn btn-danger btn-sm">Proceed</button>
                            </form>';
                    })
                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            // Log the exception for debugging
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    public function IPlotcreation(Request $request)
    {
        // $user_id = Auth::guard('misadmin')->user()->id;
        return view('admin.lot_creation.IPlotcreation');
    }

    public function IPLotCreationYieldScope()
    {
        $user_id = Auth::guard('misadmin')->user()->id;
        $products = IndividualProducerDetailOfStandingCorp::where('at_user_id', $user_id)->get();
        $stocks = AtClosingStock::where('at_user_id', $user_id)->get();

        return view('admin.lot_creation.IP-next-step', compact('products', 'stocks'));
    }

    public function IPStep2($id)
    {
        $user_id = Auth::guard('misadmin')->user()->id;
        $data = IndividualProducerDetailOfStandingCorp::join('at_closing_stock', 'at_ip_details_standing_crop.id', '=', 'at_closing_stock.at_ip_details_standing_crop_id')
            ->select('at_ip_details_standing_crop.*', 'at_closing_stock.closing_stock', 'at_closing_stock.harvest_year')
            ->where('at_ip_details_standing_crop.id', $id)
            ->first();
        $farmdetail = IndividualProducerFarmDetail::where('at_user_id', $user_id)->first();
        $farmerdetail = IndividualProducerFarmerDetail::where('at_user_id', $user_id)->first();
        $procuredata = RefProcuremenEntry::where('ref_product_id', $id)->first();
        return view('admin.lot_creation.IPstep2', compact('data', 'farmdetail', 'farmerdetail', 'procuredata'));
    }

    public function saveIPLotDetails(Request $request)
    {
        $atUserId = Auth::guard('misadmin')->user()->id;

        // Validate the incoming request data
        $validatedData = $request->validate([
            'id' => 'required|integer',
            'quantity_source' => 'required|numeric',
            'receipt_no' => 'required|string|max:255',
            'receipt_date' => 'required|date',
            'at_farmer_details_id' => 'required|integer',
            // 'at_farm_details_id' => 'required|integer',
        ]);

        $id = $validatedData['id'];

        $existingEntry = RefProcuremenEntry::where('ref_product_id', $id)->first();

        if ($existingEntry) {
            return response()->json(['error' => 'Data for this product ID already exists'], 400);
        }

        $data = [
            'ref_product_id' => $id,
            'quantity_source' => $validatedData['quantity_source'],
            'receipt_no' => $validatedData['receipt_no'],
            'receipt_date' => $validatedData['receipt_date'],
            'at_farmers_details_id' => $validatedData['at_farmer_details_id'],
            // 'at_farms_details_id' => $validatedData['at_farm_details_id'],
            'created_at' => now(),
            'updated_at' => now(),
            'created_by' => $atUserId,
            'lot_number' => ''
        ];

        $data =  RefProcuremenEntry::create($data);

        //dd($data);

        return response()->json(['message' => 'Lot details saved successfully']);
    }

    public function generateIPLotNumber(Request $request)
    {
        $refProductId = $request->input('ref_product_id');

        $entry = RefProcuremenEntry::where('ref_product_id', $refProductId)->first();

        if ($entry) {
            $lotNumber = 'LOT' . str_pad($entry->id, 8, '0', STR_PAD_LEFT);

            $entry->update(['lot_number' => $lotNumber]);

            return response()->json(['success' => true, 'message' => 'Lot number generated successfully']);
        }

        return response()->json(['success' => false, 'message' => 'Entry not found']);
    }

    public function IPLotDetails($id)
    {
        $user_id = Auth::guard('misadmin')->user()->id;
        $entry = RefProcuremenEntry::where('ref_product_id', $id)->first();
        $products = IndividualProducerDetailOfStandingCorp::where('at_user_id', $user_id)->where('id', $entry->ref_product_id)->first();
        return view('admin.lot_creation.IPstep3', compact('entry', 'products'));
    }

    public function IPdelete($id)
    {
        $entry = RefProcuremenEntry::where('ref_product_id', $id)->first();

        if ($entry) {
            $entry->is_deleted = date('Y-m-d H:i:s'); // Assuming 'is_deleted' is the column name
            $entry->save();
            return response()->json(['success' => true]);
        } else {
            return response()->json(['success' => false]);
        }
    }

    public function IPViewLotsDetail()
    {
        $user_id = Auth::guard('misadmin')->user()->id;
        $entry = RefProcuremenEntry::where('created_by', $user_id)->get();
        $ref_product_ids = $entry->pluck('ref_product_id');
        $products = IndividualProducerDetailOfStandingCorp::where('at_user_id', $user_id)->get();
        return view('admin.lot_creation.ip-view-lots-detail', compact('entry', 'products'));
    }
}

<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;
use App\Models\AtLcRcAc;
use App\Models\AtApplicationRCAC;
use App\Models\User;
use App\Models\AtOpTransactionVsTransactionProduct;
use Illuminate\Support\Facades\Log;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;


class OrganicRCAC extends Controller
{

    //---------------RCAC for trader operator start--------------------------//

    public function LcEntry(Request $request)
    {

        $data = AtLcRcAc::orderBy('id', 'desc')->limit(5)->get();


        return view('admin.rcac.lc_contract_details', compact('data'));
    }

    public function LcEntryAdd()
    {
        $user_id = Auth::user()->id;

        $user = User::where('id', $user_id)->first();

        // dd( $user);

        return view('admin.rcac.lc_contract_details_add', compact('user'));
    }

    public function LcEntrySave(Request $request)
    {
        // dd($request->all());
        // $request->validate([
        //     'lc_type' => 'required',
        //     'lc_no' => 'required',
        //     'lc_date' => 'required|email',
        //     'lc_validity_date' => 'required',
        //     'lc_qty' => 'required',
        //     'importer_name' =>'required',
        //     'importer_address' =>'required',
        //     'importer_country' => 'required',
        //     'declaration' => 'required'
        // ]);

        try {
            $file_path = null;

            if ($request->hasFile('lc_file')) {
                $documentRootPath = 'public/LC/';
                if (!file_exists($documentRootPath)) {
                    mkdir($documentRootPath, 0777, true); // Create directory if it doesn't exist
                }
                $file_path = time() . rand() . '.' . $request->file('lc_file')->getClientOriginalExtension();
                $request->file('lc_file')->move($documentRootPath, $file_path);
            }

            $data = [
                "operator_type_id" => Auth::guard('misadmin')->user()->ref_operator_type_id,
                "lc_type" => $request->lc_type,
                "lc_no" => $request->lc_no,
                "lc_date" => $request->lc_date,
                "lc_file" => $file_path,
                "lc_validity_date" => $request->lc_validity_date,
                "lc_qty" => $request->lc_qty,
                "importer_name" => $request->importer_name,
                "importer_address" => $request->importer_address,
                "importer_country" => $request->importer_country,
                "declaration" => $request->declaration,
                "created_by" => Auth::guard('misadmin')->user()->id,
                "created_on" => date("Y-m-d H:i:s"),
                "updated_on" => date("Y-m-d H:i:s")
            ];

            // if ($file_path) {
            //     $data['lc_file'] = $file_path; // Save relative path to the database
            // }

            // dd($data);
            AtLcRcAc::create($data);
            Alert::success('Success', 'Saved successfully');
            return redirect()->route('LcEntry');
        } catch (Exception $e) {
            Log::error($e);
            Alert::error('Error', $e->getMessage());
            return redirect()->back();
        }
    }

    public function Edit($id)
    {
        $data = AtLcRcAc::where('id', $id)->first();
        return view('admin.rcac.lc_contract_details_edit', compact('data'));
    }

    public function LcEntryEdit(Request $request)
    {
        try {


            $lcRecord = AtLcRcAc::find($request->id);

            if (!$lcRecord) {
                return redirect()->back()->withErrors('Record not found.');
            }

            $file_path = $lcRecord->lc_file; // Preserve existing file path if not updating

            if ($request->hasFile('lc_file')) {
                $documentRootPath = 'public/LC/';
                if (!file_exists($documentRootPath)) {
                    mkdir($documentRootPath, 0777, true); // Create directory if it doesn't exist
                }
                $file_path = time() . rand() . '.' . $request->file('lc_file')->getClientOriginalExtension();
                $request->file('lc_file')->move($documentRootPath, $file_path);

                // Optionally delete old file if necessary
                // if ($lcRecord->lc_file && file_exists($lcRecord->lc_file)) {
                //     unlink($lcRecord->lc_file);
                // }
            }

            // Update record fields
            $lcRecord->operator_type_id = Auth::guard('misadmin')->user()->ref_operator_type_id;
            $lcRecord->lc_type = $request->lc_type;
            $lcRecord->lc_no = $request->lc_no;
            $lcRecord->lc_date = $request->lc_date;
            $lcRecord->lc_file = $file_path;
            $lcRecord->lc_validity_date = $request->lc_validity_date;
            $lcRecord->lc_qty = $request->lc_qty;
            $lcRecord->importer_name = $request->importer_name;
            $lcRecord->importer_address = $request->importer_address;
            $lcRecord->importer_country = $request->importer_country;
            $lcRecord->declaration = $request->declaration;
            $lcRecord->updated_on = date("Y-m-d H:i:s");

            // Save the updated record
            $lcRecord->save();

            Alert::success('Success', 'Updated successfully');
            return redirect()->route('LcEntry');
        } catch (Exception $e) {
            Log::error($e);
            Alert::error('Error', $e->getMessage());
            return redirect()->back();
        }
    }

    public function Delete($id)
    {
        try {


            $user = AtLcRcAc::find($id);
            $user->deleted_at = date('Y-m-d H:i:s');
            $user->save();

            AtLcRcAc::where('id', $id)->delete();
            Alert::success('Success', 'Delete successfully');
            return redirect()->route('LcEntry');
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function ApllyForRCAC($id)
    {
        $user_id = Auth::user()->id;

        $data = AtLcRcAc::where('created_by', $user_id)->get();

        //dd( $data);
        return view('admin.rcac.apply_for_rcac', compact('data', 'id'));
    }
    public function ApllyForRCACSave(Request $request, $id)
    {
        // dd($request->all());
        // $request->validate([
        //     'lc_type' => 'required',
        //     'lc_no' => 'required',
        //     'lc_date' => 'required|email',
        //     'lc_validity_date' => 'required',
        //     'lc_qty' => 'required',
        //     'importer_name' =>'required',
        //     'importer_address' =>'required',
        //     'importer_country' => 'required',
        //     'declaration' => 'required'
        // ]);

        try {

            $data = [
                "operator_type_id" => Auth::guard('misadmin')->user()->ref_operator_type_id,
                "lc_type" => $request->lc_type,
                "lc_no" => $request->lc_no,
                "ptc_no" => $request->ptc_no,
                "created_by" => Auth::guard('misadmin')->user()->id,
                "created_on" => date("Y-m-d H:i:s"),
                // "updated_on" => date("Y-m-d H:i:s")
            ];


            // dd($data);
            AtApplicationRCAC::create($data);
            Alert::success('Success', 'Saved successfully');
            return redirect()->route('ApplicationForRCAC', $id);
        } catch (Exception $e) {
            Log::error($e);
            Alert::error('Error', $e->getMessage());
            return redirect()->back();
        }
    }

    public function ApplicationForRCAC($id)
    {
        $data = AtApplicationRCAC::where('created_by', $id)->first();
        $user_id = Auth::user()->id;
        $user = User::where('id', $user_id)->first();

        $importer = AtLcRcAc::where('created_by', $id)->first();

        // dd($importer );
        return view('admin.rcac.application_for_rcac', compact('data', 'user', 'importer'));
    }

    public function ApplicationForRCACSave(Request $request)
    {
        // dd($request->all());

        try {

            $Record = AtApplicationRCAC::find($request->id);

            $Record->operator_type_id = Auth::guard('misadmin')->user()->ref_operator_type_id;
            $Record->registration_no = $request->registration_no;
            $Record->exporter_name = $request->exporter_name;
            $Record->quota = $request->quota;
            $Record->office = $request->office;
            $Record->product_category = $request->product_category;
            $Record->trade_notice_no = $request->trade_notice_no;
            $Record->hscode = $request->hscode;
            $Record->product_name = $request->product_name;
            $Record->product_status = $request->product_status;
            $Record->quantity = $request->quantity;
            $Record->validity_date = $request->validity_date;
            $Record->remaining_qty = $request->remaining_qty;
            $Record->applying_qty = $request->applying_qty;
            $Record->fob = $request->fob;
            $Record->port_of_origin = $request->port_of_origin;
            $Record->value = $request->value;
            $Record->cif_amount = $request->cif_amount;
            $Record->importer_name = $request->importer_name;
            $Record->importer_address = $request->importer_address;
            $Record->certificate_dispatch_by = $request->certificate_dispatch_by;
            $Record->importer_country = $request->importer_country;
            $Record->mode_of_payment = $request->mode_of_payment;
            $Record->declaration = $request->declaration;
            $Record->registration_no = $request->registration_no;
            $Record->registration_no = $request->registration_no;
            $Record->registration_no = $request->registration_no;
            $Record->registration_no = $request->registration_no;
            $Record->updated_on = date("Y-m-d H:i:s");

            // Save the updated record
            $Record->save();


            // $data = [
            //     "operator_type_id" => Auth::guard('misadmin')->user()->ref_operator_type_id,
            //     "registration_no" => $request->registration_no,
            //     "exporter_name" => $request->exporter_name,
            //     "quota" => $request->quota,
            //     "office" => $request->office,
            //     "product_category" => $request->product_category,
            //     "trade_notice_no" => $request->trade_notice_no,
            //     "hscode" => $request->hscode,
            //     "product_name" => $request->product_name,
            //     "product_status" => $request->product_status,
            //     "quantity" => $request->quantity,
            //     "lc_no" => $request->lc_no,
            //     "validity_date" => $request->validity_date,
            //     "remaining_qty" => $request->remaining_qty,
            //     "applying_qty" => $request->applying_qty,
            //     "fob" => $request->fob,
            //     "port_of_origin" => $request->port_of_origin,
            //     "value" => $request->value,
            //     "cif_amount" => $request->cif_amount,
            //     "importer_name" => $request->importer_name,
            //     "importer_address" => $request->importer_address,
            //     "certificate_dispatch_by" => $request->certificate_dispatch_by,
            //     "importer_country" => $request->importer_country,
            //     "declaration" => $request->declaration,
            //     "created_by" => Auth::guard('misadmin')->user()->id,
            //     "created_on" => date("Y-m-d H:i:s"),
            //     "updated_on" => date("Y-m-d H:i:s")
            // ];
            Alert::success('Success', 'update successfully');
            return redirect()->route('PaymentProcees', auth()->user()->id);
        } catch (Exception $e) {
            Log::error($e);
            Alert::error('Error', $e->getMessage());
            return redirect()->back();
        }
    }
    public function PaymentProcess($created_by)
    {
        $orderNo = 'ORG/RC/' . time();

        return view('admin.rcac.payment', ['orderNo' => $orderNo]);
    }


    // public function processPayment(Request $request)
    // {
    //     $orderNo = $request->input('orderNo');
    //     $amount = $request->input('amount');



    //     $paymentUrl = "https://payment-gateway-url.com/process?orderNo={$orderNo}&amount={$amount}";

    //     return redirect($paymentUrl);
    // }


    public function PendingPayment()
    {

        return view('admin.rcac.apply_for_rcac_pending_payment');
    }

    public function PendingPaymentSearch(Request $request)
    {
        try {
            if ($request->ajax()) {
                $query = AtApplicationRCAC::query()
                    ->leftJoin('at_user', DB::raw('CAST(at_rcac_application_details.created_by AS bigint)'), '=', 'at_user.id')
                    ->where('at_rcac_application_details.operator_type_id', 5);



                $finalData = $query->select([
                    'at_rcac_application_details.*',
                    'at_user.first_name',
                    'at_user.registration_no',

                ])->limit(8)->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()
                    ->addColumn('reg_no', function ($row) {
                        return $row->registration_no ?? 'N/A';
                    })
                    ->addColumn('operator_name', function ($row) {
                        return $row->first_name ?? 'N/A';
                    })
                    ->addColumn('application_no', function ($row) {
                        return time() . ($row->id ?? 'N/A');
                    })
                    ->addColumn('applied_on', function ($row) {
                        return dateFormat($row->updated_on ?? 'N/A');
                    })
                    ->addColumn('ptc_no', function ($row) {
                        return $row->ptc_no ?? 'N/A';
                    })
                    ->addColumn('ptc_date', function ($row) {
                        return dateFormat($row->updated_on ?? 'N/A');
                    })
                    ->addColumn('category', function ($row) {
                        return getCategoryNameById($row->product_category ?? '3');
                    })
                    ->addColumn('product', function ($row) {
                        return $row->product_name ?? 'N/A';
                    })
                    ->addColumn('qty', function ($row) {
                        return $row->quantity ?? 'N/A';
                    })
                    ->addColumn('amount', function ($row) {
                        return $row->cif_amount ?? 'N/A';
                    })
                    ->addColumn('status', function ($row) {
                        if ($row->status === 0) {
                            return 'Pending';
                        } elseif ($row->status === 1) {
                            return 'Approved';
                        } else {
                            return 'N/A';
                        }
                    })
                    ->addColumn('action', function ($row) {
                        $processUrl = route('PaymentProcessor', ['created_by' => auth()->user()->id ,'id' => $row->id]);

                        return '<a href="' . $processUrl . '"">Process</a>';
                    })
                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    public function ViewStatusTrader()
    {
        return view('admin.rcac.view_status');
    }

    public function ViewStatusTraderSearch(Request $request)
    {
        try {
            if ($request->ajax()) {
                $query = AtApplicationRCAC::query()
                    ->leftJoin('at_user', DB::raw('CAST(at_rcac_application_details.created_by AS bigint)'), '=', 'at_user.id')
                    ->where('at_rcac_application_details.operator_type_id', 5);


                $finalData = $query->select([
                    'at_rcac_application_details.*',
                    'at_user.first_name',
                    'at_user.registration_no',

                ])->limit(8)->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('application_no', function ($row) {
                        return time() . ($row->id ?? 'N/A');
                    })
                    ->addColumn('applied_on', function ($row) {
                        return dateFormat($row->updated_on ?? 'N/A');
                    })
                    ->addColumn('ptc_no', function ($row) {
                        return $row->ptc_no ?? 'N/A';
                    })
                    ->addColumn('ptc_date', function ($row) {
                        return dateFormat($row->updated_on ?? 'N/A');
                    })
                    ->addColumn('category', function ($row) {
                        return getCategoryNameById($row->product_category ?? '3');
                    })
                    ->addColumn('product', function ($row) {
                        return $row->product_name ?? 'N/A';
                    })
                    ->addColumn('lc_no', function ($row) {
                        return $row->lc_no ?? 'N/A';
                    })
                    ->addColumn('rcac_no', function ($row) {
                        return $row->id ?? 'N/A';
                    })
                    ->addColumn('rcac_date', function ($row) {
                        return  dateFormat($row->updated_on ?? 'N/A');
                    })
                    ->addColumn('qty', function ($row) {
                        return $row->quantity ?? 'N/A';
                    })
                    ->addColumn('name', function ($row) {
                        return ($row->importer_name ?? 'N/A');
                    })
                    ->addColumn('country', function ($row) {
                        return  getCountryName($row->importer_country ?? 'N/A');
                    })
                    ->addColumn('status', function ($row) {
                        if ($row->status === 0) {
                            return 'Pending';
                        } elseif ($row->status === 1) {
                            return 'Approved';
                        } else {
                            return 'N/A';
                        }
                    })
                    ->addColumn('action', function ($row) {
                        $processUrl = route('ViewStatusProcessor', ['id' => $row->id]);

                        return '<a href="' . $processUrl . '"">View</a>';
                    })
                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }



    //---------------RCAC for trader operator end--------------------------//

    //---------------RCAC for Processer operator start--------------------------//

    public function index()
    {

        $user_id = Auth::user()->id;

        $data = AtLcRcAc::where('created_by', $user_id)->get();

        return view('admin.rcac.processor.index', compact('data'));
    }

    public function Add()
    {
        $user_id = Auth::user()->id;

        $user = User::where('id', $user_id)->first();

        // dd( $user);

        return view('admin.rcac.processor.add', compact('user'));
    }
    public function Save(Request $request)
    {
        // dd($request->all());
        // $request->validate([
        //     'lc_type' => 'required',
        //     'lc_no' => 'required',
        //     'lc_date' => 'required|email',
        //     'lc_validity_date' => 'required',
        //     'lc_qty' => 'required',
        //     'importer_name' =>'required',
        //     'importer_address' =>'required',
        //     'importer_country' => 'required',
        //     'declaration' => 'required'
        // ]);

        try {
            $file_path = null;

            if ($request->hasFile('lc_file')) {
                $documentRootPath = 'public/LC/';
                if (!file_exists($documentRootPath)) {
                    mkdir($documentRootPath, 0777, true); // Create directory if it doesn't exist
                }
                $file_path = time() . rand() . '.' . $request->file('lc_file')->getClientOriginalExtension();
                $request->file('lc_file')->move($documentRootPath, $file_path);
            }

            $data = [
                "operator_type_id" => Auth::guard('misadmin')->user()->ref_operator_type_id,
                "lc_type" => $request->lc_type,
                "lc_no" => $request->lc_no,
                "lc_date" => $request->lc_date,
                "lc_file" => $file_path,
                "lc_validity_date" => $request->lc_validity_date,
                "lc_qty" => $request->lc_qty,
                "importer_name" => $request->importer_name,
                "importer_address" => $request->importer_address,
                "importer_country" => $request->importer_country,
                "declaration" => $request->declaration,
                "created_by" => Auth::guard('misadmin')->user()->id,
                "created_on" => date("Y-m-d H:i:s"),
                "updated_on" => date("Y-m-d H:i:s")
            ];

            // if ($file_path) {
            //     $data['lc_file'] = $file_path; // Save relative path to the database
            // }

            // dd($data);
            AtLcRcAc::create($data);
            Alert::success('Success', 'Saved successfully');
            return redirect()->route('index');
        } catch (Exception $e) {
            Log::error($e);
            Alert::error('Error', $e->getMessage());
            return redirect()->back();
        }
    }
    public function ProcessorEdit($id)
    {
        $data = AtLcRcAc::where('id', $id)->first();
        return view('admin.rcac.processor.edit', compact('data'));
    }
    public function Update(Request $request)
    {
        try {


            $lcRecord = AtLcRcAc::find($request->id);

            if (!$lcRecord) {
                return redirect()->back()->withErrors('Record not found.');
            }

            $file_path = $lcRecord->lc_file; // Preserve existing file path if not updating

            if ($request->hasFile('lc_file')) {
                $documentRootPath = 'public/LC/';
                if (!file_exists($documentRootPath)) {
                    mkdir($documentRootPath, 0777, true); // Create directory if it doesn't exist
                }
                $file_path = time() . rand() . '.' . $request->file('lc_file')->getClientOriginalExtension();
                $request->file('lc_file')->move($documentRootPath, $file_path);

                // Optionally delete old file if necessary
                // if ($lcRecord->lc_file && file_exists($lcRecord->lc_file)) {
                //     unlink($lcRecord->lc_file);
                // }
            }

            // Update record fields
            $lcRecord->operator_type_id = Auth::guard('misadmin')->user()->ref_operator_type_id;
            $lcRecord->lc_type = $request->lc_type;
            $lcRecord->lc_no = $request->lc_no;
            $lcRecord->lc_date = $request->lc_date;
            $lcRecord->lc_file = $file_path;
            $lcRecord->lc_validity_date = $request->lc_validity_date;
            $lcRecord->lc_qty = $request->lc_qty;
            $lcRecord->importer_name = $request->importer_name;
            $lcRecord->importer_address = $request->importer_address;
            $lcRecord->importer_country = $request->importer_country;
            $lcRecord->declaration = $request->declaration;
            $lcRecord->updated_on = date("Y-m-d H:i:s");

            // Save the updated record
            $lcRecord->save();

            Alert::success('Success', 'Updated successfully');
            return redirect()->route('index');
        } catch (Exception $e) {
            Log::error($e);
            Alert::error('Error', $e->getMessage());
            return redirect()->back();
        }
    }

    public function DeleteRecord($id)
    {
        try {


            $user = AtLcRcAc::find($id);
            $user->deleted_at = date('Y-m-d H:i:s');
            $user->save();

            AtLcRcAc::where('id', $id)->delete();
            Alert::success('Success', 'Delete successfully');
            return redirect()->route('index');
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function ApllyForRCACProcessor($id)
    {
        $user_id = Auth::user()->id;

        $data = AtLcRcAc::where('created_by', $user_id)->get();

        //dd( $data);
        return view('admin.rcac.processor.apply_for_rcac', compact('data', 'id'));
    }

    public function ApllyForRCACProcessorSave(Request $request, $id)
    {
        // dd($request->all());
        // $request->validate([
        //     'lc_type' => 'required',
        //     'lc_no' => 'required',
        //     'lc_date' => 'required|email',
        //     'lc_validity_date' => 'required',
        //     'lc_qty' => 'required',
        //     'importer_name' =>'required',
        //     'importer_address' =>'required',
        //     'importer_country' => 'required',
        //     'declaration' => 'required'
        // ]);

        try {

            $data = [
                "operator_type_id" => Auth::guard('misadmin')->user()->ref_operator_type_id,
                "lc_type" => $request->lc_type,
                "lc_no" => $request->lc_no,
                "ptc_no" => $request->ptc_no,
                "created_by" => Auth::guard('misadmin')->user()->id,
                "created_on" => date("Y-m-d H:i:s"),
                // "updated_on" => date("Y-m-d H:i:s")
            ];


            // dd($data);
            AtApplicationRCAC::create($data);
            Alert::success('Success', 'Saved successfully');
            return redirect()->route('ApplicationForRCACProcessor', $id);
        } catch (Exception $e) {
            Log::error($e);
            Alert::error('Error', $e->getMessage());
            return redirect()->back();
        }
    }

    public function ApplicationForRCACProcessor($id)
    {
        $data = AtApplicationRCAC::where('created_by', $id)->first();
        $user_id = Auth::user()->id;
        $user = User::where('id', $user_id)->first();
        $ptc = AtOpTransactionVsTransactionProduct::where('created_by', $user_id)->get();

        $importer = AtLcRcAc::where('created_by', $id)->first();

        // dd($ptc);
        return view('admin.rcac.processor.application_for_rcac', compact('data', 'user', 'importer','ptc'));
    }

    public function ApplicationForRCACProcessorSave(Request $request)
    {
        // dd($request->all());

        try {

            $Record = AtApplicationRCAC::find($request->id);

            $Record->operator_type_id = Auth::guard('misadmin')->user()->ref_operator_type_id;
            $Record->registration_no = $request->registration_no;
            $Record->exporter_name = $request->exporter_name;
            $Record->quota = $request->quota;
            $Record->office = $request->office;
            $Record->product_category = $request->product_category;
            $Record->trade_notice_no = $request->trade_notice_no;
            $Record->hscode = $request->hscode;
            $Record->product_name = $request->product_name;
            $Record->product_status = $request->product_status;
            $Record->quantity = $request->quantity;
            $Record->validity_date = $request->validity_date;
            $Record->remaining_qty = $request->remaining_qty;
            $Record->applying_qty = $request->applying_qty;
            $Record->fob = $request->fob;
            $Record->port_of_origin = $request->port_of_origin;
            $Record->value = $request->value;
            $Record->cif_amount = $request->cif_amount;
            $Record->importer_name = $request->importer_name;
            $Record->importer_address = $request->importer_address;
            $Record->certificate_dispatch_by = $request->certificate_dispatch_by;
            $Record->importer_country = $request->importer_country;
            $Record->mode_of_payment = $request->mode_of_payment;
            $Record->declaration = $request->declaration;
            $Record->registration_no = $request->registration_no;
            $Record->registration_no = $request->registration_no;
            $Record->registration_no = $request->registration_no;
            $Record->registration_no = $request->registration_no;
            $Record->updated_on = date("Y-m-d H:i:s");
            // $Record->created_on = date("Y-m-d H:i:s");
            // Save the updated record
            $Record->save();

            Alert::success('Success', 'update successfully');
            return redirect()->route('PaymentProcessor', auth()->user()->id);
        } catch (Exception $e) {
            Log::error($e);
            Alert::error('Error', $e->getMessage());
            return redirect()->back();
        }
    }

    public function paymentProcessor(Request $request, $created_by)
    {
        // Retrieve the 'id' from the query string
        $rc_id = $request->query('id');
        // Generate the order number
        $orderNo = 'ORG/RC/' . time() . '-AAPD-' . $rc_id;
    
        // Pass the order number to the view
        return view('admin.rcac.processor.payment', [
            'orderNo' => $orderNo,
            'rc_id' => $rc_id
        ]);
    }

    public function PendingPaymentProcessor()
    {

        return view('admin.rcac.processor.apply_for_rcac_pending_payment');
    }

    public function PendingPaymentProcessorSearch(Request $request)
    {
        try {
            if ($request->ajax()) {
                $query = AtApplicationRCAC::query()
                    ->leftJoin('at_user', DB::raw('CAST(at_rcac_application_details.created_by AS bigint)'), '=', 'at_user.id')
                    ->where('at_rcac_application_details.operator_type_id', 6);



                $finalData = $query->select([
                    'at_rcac_application_details.*',
                    'at_user.first_name',
                    'at_user.registration_no',

                ])->limit(8)->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()
                    ->addColumn('reg_no', function ($row) {
                        return $row->registration_no ?? 'N/A';
                    })
                    ->addColumn('operator_name', function ($row) {
                        return $row->first_name ?? 'N/A';
                    })
                    ->addColumn('application_no', function ($row) {
                        return time() . ($row->id ?? 'N/A');
                    })
                    ->addColumn('applied_on', function ($row) {
                        return dateFormat($row->updated_on ?? 'N/A');
                    })
                    ->addColumn('ptc_no', function ($row) {
                        return $row->ptc_no ?? 'N/A';
                    })
                    ->addColumn('ptc_date', function ($row) {
                        return dateFormat($row->updated_on ?? 'N/A');
                    })
                    ->addColumn('category', function ($row) {
                        return getCategoryNameById($row->product_category ?? '3');
                    })
                    ->addColumn('product', function ($row) {
                        return $row->product_name ?? 'N/A';
                    })
                    ->addColumn('qty', function ($row) {
                        return $row->quantity ?? 'N/A';
                    })
                    ->addColumn('amount', function ($row) {
                        return $row->cif_amount ?? 'N/A';
                    })
                    ->addColumn('status', function ($row) {
                        if ($row->status === 0) {
                            return 'Pending';
                        } elseif ($row->status === 1) {
                            return 'Approved';
                        } else {
                            return 'N/A';
                        }
                    })
                    ->addColumn('action', function ($row) {
                        $processUrl = route('PaymentProcessor', ['created_by' => auth()->user()->id ,'id' => $row->id]);

                        return '<a href="' . $processUrl . '"">Process</a>';
                    })
                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }



    public function ViewStatusProcessor()
    {

        return view('admin.rcac.processor.view_status');
    }

    public function ViewStatusProcessorSearch(Request $request)
    {
        try {
            if ($request->ajax()) {
                $query = AtApplicationRCAC::query()
                    ->leftJoin('at_user', DB::raw('CAST(at_rcac_application_details.created_by AS bigint)'), '=', 'at_user.id')
                    ->where('at_rcac_application_details.operator_type_id', 6);


                $finalData = $query->select([
                    'at_rcac_application_details.*',
                    'at_user.first_name',
                    'at_user.registration_no',

                ])->limit(8)->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('application_no', function ($row) {
                        return time() . ($row->id ?? 'N/A');
                    })
                    ->addColumn('applied_on', function ($row) {
                        return dateFormat($row->updated_on ?? 'N/A');
                    })
                    ->addColumn('ptc_no', function ($row) {
                        return $row->ptc_no ?? 'N/A';
                    })
                    ->addColumn('ptc_date', function ($row) {
                        return dateFormat($row->updated_on ?? 'N/A');
                    })
                    ->addColumn('category', function ($row) {
                        return getCategoryNameById($row->product_category ?? '3');
                    })
                    ->addColumn('product', function ($row) {
                        return $row->product_name ?? 'N/A';
                    })
                    ->addColumn('lc_no', function ($row) {
                        return $row->lc_no ?? 'N/A';
                    })
                    ->addColumn('rcac_no', function ($row) {
                        return $row->id ?? 'N/A';
                    })
                    ->addColumn('rcac_date', function ($row) {
                        return  dateFormat($row->updated_on ?? 'N/A');
                    })
                    ->addColumn('qty', function ($row) {
                        return $row->quantity ?? 'N/A';
                    })
                    ->addColumn('name', function ($row) {
                        return $row->importer_name ?? 'N/A';
                    })
                    ->addColumn('country', function ($row) {
                        return getCountryName($row->importer_country ?? 'N/A');
                    })
                    ->addColumn('status', function ($row) {
                        if ($row->status === 0) {
                            return 'Pending';
                        } elseif ($row->status === 1) {
                            return 'Approved';
                        } else {
                            return 'N/A';
                        }
                    })
                    ->addColumn('action', function ($row) {
                        $processUrl = route('ViewStatusProcessor', ['id' => $row->id]);

                        return '<a href="' . $processUrl . '"">View</a>';
                    })
                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }





    //---------------RCAC for Processer operator end--------------------------//

}

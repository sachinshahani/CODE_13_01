<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AtBatchCreation;
use App\Models\Permission;
use App\Models\Role;
use App\Models\RoleUser;
use App\Models\User;
use App\Models\UserSelf;
use App\Models\UserInspector;
use App\Models\UserWarehouse;
use App\Models\UserWarehouseManagerOfficers;
use App\Models\RefState;
use App\Models\RefDistrict;
use App\Models\RefVillage;
use App\Models\RefRegion;
use App\Models\TradersBasicDetail;
use App\Models\WildHarvesterBankDetail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;
use Validator;
use App\Models\GeoTaggingWarehouseDetail;
use App\Models\TradersProductDetail;
use App\Models\TradersDocument;
use App\Models\AtProProductsDetails;
use App\Models\CertificateStandardDetail;
use App\Models\RefProduct;
use App\Models\BatchCreation;
use App\Models\AtBatchDetail;
use App\Models\SourceDetails;
use App\Models\AtOpTransactionVsTransactionProduct;
use App\Models\AtPurchaseDetails;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\DataTables;
use App\Models\AtOpTransactionProductSourced;
use App\Models\AtOpTransactionCertificateEntry;
use App\Models\RefPackingMaster;
use App\Models\AtOpTransactionPackingDetails;

class TradersUserController extends Controller
{
    //

    public function tradersDeptUserEdit(Request $request, $user_id)
    {


        try {

            $userdetails = User::find($user_id);
            $cbStates = User::where('id', $userdetails->created_by)->first();
            $bankDetail = $userdetails->bankDetails;
            //dd($userdetails); exit;
            return view('admin/traders/traderDetail', compact('userdetails', 'bankDetail', 'cbStates'));
        } catch (Exception $e) {
            return redirect()->back();
        } catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
            return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
        }
    }

    public function tradersEditStepSave(Request $request, $user_id)
    {

        try {
            $request->validate([
                'first_name' => 'required',
                //'middle_name' => 'required',
                // 'last_name' => 'required',
                'processor_state_id' => 'required',
                'processor_district_id' => 'required',
                'processor_block_tehsil_id' => 'required',
                'processor_village_id' => 'required',
                'pin' => 'required|numeric|digits:6',
                'processor_address' => 'required',

            ]);

            $trader_photo = $contact_person_photo = '';

            if ($request->hasFile('processor_photo')) {
                if (!empty($request->processor_photo_edit)) {
                    $imagePath = public_path('trader_photo/') . $request->processor_photo_edit;
                    deleteOldImage($request->processor_photo_edit, $imagePath);
                }
                $documentRootPath = 'public/trader_photo';
                $file_path = time() . rand() . '.' . $request->file('processor_photo')->getClientOriginalExtension();
                $request->file('processor_photo')->move($documentRootPath, $file_path);
                $trader_photo = $file_path;
            } else {
                $trader_photo = $request->processor_photo_edit;
            }

            if ($request->hasFile('contact_person_photo')) {
                if (!empty($request->contact_person_photo_edit)) {
                    $imagePath = public_path('contact_person_photo/') . $request->contact_person_photo_edit;
                    deleteOldImage($request->contact_person_photo_edit, $imagePath);
                }
                $documentRootPath = 'public/contact_person_photo';
                $file_path = time() . rand() . '.' . $request->file('contact_person_photo')->getClientOriginalExtension();
                $request->file('contact_person_photo')->move($documentRootPath, $file_path);
                $contact_person_photo = $file_path;
            } else {
                $contact_person_photo = $request->contact_person_photo_edit;
            }


            $user = User::find($user_id);
            $user->first_name = $request->first_name;
            $user->middle_name = $request->middle_name;
            $user->last_name = $request->last_name;
            $user->processor_photo = $trader_photo;
            $user->processor_state_id = $request->processor_state_id;
            $user->processor_district_id = $request->processor_district_id;
            $user->processor_block_tehsil_id = $request->processor_block_tehsil_id;
            $user->processor_village_id = $request->processor_village_id;
            $user->processor_pin = $request->processor_pin;
            $user->processor_address = $request->processor_address;
            $user->contact_person_first_name = $request->contact_person_first_name;
            $user->contact_person_middle_name = $request->contact_person_middle_name;
            $user->contact_person_last_name = $request->contact_person_last_name;
            $user->contact_person_gender = $request->contact_person_gender;
            $user->contact_person_mobile_number = $request->contact_person_mobile;
            $user->contact_person_pan_number = $request->pan_number;
            $user->contact_person_aadhar_number = $request->contact_person_aadhar_number;
            $user->contact_person_photo = $contact_person_photo;
            $user->contact_person_email = $request->contact_person_email;
            $user->ref_state_id = $request->ref_state_id;
            $user->ref_district_id = $request->ref_district_id;
            $user->ref_block_tehsil_id = $request->ref_block_tehsil_id;
            $user->ref_village_id = $request->ref_village_id;
            $user->pin = $request->pin;
            $user->address = $request->address;

            $user->save();

            if (isset($user)) {

                $newUser = WildHarvesterBankDetail::updateOrCreate([
                    'at_user_id'   => $user_id,
                ], [
                    'at_user_id'   => $user_id,
                    'ref_operator_type_id'   => 5,
                    'ref_bank_id' => $request->ref_bank_id,
                    'account_number' => $request->account_number,
                    'ifsc_code' => $request->ifsc_code,
                    'branch_name' => $request->branch_name,
                    'bank_address' => $request->bank_address,
                    'pincode' => $request->pincode,

                ]);
            }

            //pr($request->all());

            //return redirect()->route('superadmin.tradersUseredit.step1',$user_id);
            Alert::success('Success', 'Record updated Successfully');
            return redirect()->route('superadmin.tradersUseredit.step1', $user_id);
        } catch (Exception $e) {
            return redirect()->back();
        } catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
            return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
        }
    }

    public function tradersEditStep1(Request $request, $user_id)
    {
        try {
            $userdetails = User::with('GeoTaggingWarehouseDetail')->find($user_id);
            $GeoTaggingWarehouseDetails = $userdetails->GeoTaggingWarehouseDetail;

            //$states = RefState::orderBy('state_name','ASC')->get();
            //$districts = RefDistrict::where('ref_state_code',$userdetails->state)->orderBy('district_name','ASC')->get();

            //$regions = RefRegion::where('state_code',$userdetails->state)->orderBy('region_name','ASC')->get();
            //$villages = RefVillage::where('ref_district_code',$userdetails->district)->orderBy('village_name','ASC')->get();

            return view('admin/traders/geo_tagging_warehouse_detail', compact('userdetails', 'GeoTaggingWarehouseDetails'));
        } catch (Exception $e) {
            return redirect()->back();
        } catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
            return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
        }
    }



    public function tradersEditStep1Save(Request $request, $user_id)
    {
        try {


            $request->validate([
                'warehouse_unit_id' => 'required|array|',
                'warehouse_name' => 'required|array|',
                'fssai_license_number' => 'required|array|',
                'license_validity' => 'required|array|',
                'agreement_status' => 'required|array|',
                'number_of_products' => 'required|array|',
                // 'additional_certificate' => 'required|array|',
                'geo_tagging_warehouse_unit' => 'required|array|',
                'total_capacity' => 'required|array|',
                'organic_installed_capacity' => 'required|array|',
            ]);

            foreach ($request->warehouse_unit_id as $key => $warehouse_unit_id) {
                $license_document = $additional_certificate = $reflect_farm_image_after_tagging = '';
                if (!empty($request->file('license_document')[$key])) {
                    if (!empty($request->license_document_edit[$key])) {
                        $imagePath = public_path('traders/license_document/') . $request->license_document[$key];
                        deleteOldImage($request->license_document_edit[$key], $imagePath);
                    }
                    $documentRootPath = 'public/traders/license_document';
                    $file_path = time() . rand() . '.' . $request->file('license_document')[$key]->getClientOriginalExtension();
                    $request->file('license_document')[$key]->move($documentRootPath, $file_path);
                    $license_document = $file_path;
                } else {
                    if (!empty($request->license_document_edit[$key]))
                        $license_document = $request->license_document_edit[$key];
                }



                if (!empty($request->file('additional_certificate')[$key])) {
                    if (!empty($request->additional_certificate_edit[$key])) {
                        $imagePath = public_path('traders/additional_certificate/') . $request->additional_certificate[$key];
                        deleteOldImage($request->additional_certificate_edit[$key], $imagePath);
                    }
                    $documentRootPath = 'public/traders/additional_certificate';
                    $file_path = time() . rand() . '.' . $request->file('additional_certificate')[$key]->getClientOriginalExtension();
                    $request->file('additional_certificate')[$key]->move($documentRootPath, $file_path);
                    $additional_certificate = $file_path;
                } else {
                    if (!empty($request->additional_certificate_edit[$key]))
                        $additional_certificate = $request->additional_certificate_edit[$key];
                }

                if (!empty($request->file('image_after_tagging')[$key])) {
                    if (!empty($request->image_after_tagging_edit[$key])) {
                        $imagePath = public_path('traders/reflect_farm_image_after_tagging/') . $request->image_after_tagging[$key];
                        deleteOldImage($request->image_after_tagging_edit[$key], $imagePath);
                    }
                    $documentRootPath = 'public/traders/reflect_farm_image_after_tagging';
                    $file_path = time() . rand() . '.' . $request->file('image_after_tagging')[$key]->getClientOriginalExtension();
                    $request->file('image_after_tagging')[$key]->move($documentRootPath, $file_path);
                    $reflect_farm_image_after_tagging = $file_path;
                } else {
                    if (!empty($request->image_after_tagging_edit[$key]))
                        $reflect_farm_image_after_tagging = $request->image_after_tagging_edit[$key];
                }

                $data = array(
                    'at_user_id' => $user_id,
                    'warehouse_unit_id' => $request->warehouse_unit_id[$key],
                    'warehouse_name' => $request->warehouse_name[$key],
                    'fssai_license_number' => $request->fssai_license_number[$key],
                    'license_validity' => date('Y-m-d', strtotime($request->license_validity[$key])),
                    'address' => $request->address[$key],
                    // 'fssai_license_record' => $request->company[$key],
                    // 'fssai_license_record' => $request->licenseActiveFlag[$key],
                    // 'fssai_license_record' => $request->products[$key],
                    'agreement_status' => $request->agreement_status[$key],
                    'number_of_products' => $request->number_of_products[$key],
                    'geo_tagging_warehouse_unit' => $request->geo_tagging_warehouse_unit[$key],
                    'total_capacity' => $request->total_capacity[$key],
                    'organic_installed_capacity' => $request->organic_installed_capacity[$key],
                    'license_document' => $license_document,
                    'additional_certificate' => $additional_certificate,
                    'image_after_tagging' => $reflect_farm_image_after_tagging,
                    // 'fssai_license_record' => $request->fssai_license_record[$key],
                );

                if (!empty($request->row_id[$key])) {
                    $data['updated_at'] = date('Y-m-d H:i:s');
                    $data['updated_by'] = Auth::guard('misadmin')->user()->id;
                    GeoTaggingWarehouseDetail::where('id', $request->row_id[$key])->where('at_user_id', $user_id)->update($data);
                } else {
                    $data['created_by'] = Auth::guard('misadmin')->user()->id;
                    $data['created_at'] = date('Y-m-d H:i:s');
                    GeoTaggingWarehouseDetail::create($data);
                }
            }


            Alert::success('Success', 'Record updated Successfully');
            return redirect()->route('superadmin.tradersUseredit.step2', $user_id);
        } catch (Exception $e) {
            return redirect()->back();
        } catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
            return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
        }
    }

    public function tradersEditStep2(Request $request, $user_id)
    {
        try {
            $userdetails = User::with('TradersProductDetails')->find($user_id);
            $traders_product_details = $userdetails->TradersProductDetails;
            $auth =  Auth::guard('misadmin')->user()->created_by;
            $cbID =  User::where('id',$auth)->first();
            return view('admin/traders/product_detail', compact('userdetails', 'traders_product_details','cbID'));
        } catch (Exception $e) {
            return redirect()->back();
        } catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
            return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
        }
    }


    public function tradersEditStep2Save(Request $request, $user_id)
    {
        try {

            $request->validate([
                'warehouse_unit_id' => 'required|array|',
                'ref_hscode_id' => 'required|array|',
                'ref_product_id' => 'required|array|',
                'product_description' => 'required|array|',
                'product_trader_name' => 'required|array|',
                'organic_status' => 'required|array|',
                //'product_image' => 'required|array|',

            ]);
            //dd($request->all());
            foreach ($request->warehouse_unit_id as $key => $warehouse_unit_id) {
                $product_photo = $aadhar_card = $pan_card = $bank_copy_passbook =  $contact_person_sign_thumb_Impression = $live_signature_thumb_impression = '';
                if (!empty($request->file('product_image')[$key])) {
                    if (!empty($request->product_image_edit[$key])) {
                        $imagePath = public_path('traders/product_photo/') . $request->product_image[$key];
                        deleteOldImage($request->product_image_edit[$key], $imagePath);
                    }
                    $documentRootPath = 'public/traders/product_photo';
                    $file_path = time() . rand() . '.' . $request->file('product_image')[$key]->getClientOriginalExtension();
                    $request->file('product_image')[$key]->move($documentRootPath, $file_path);
                    $product_photo = $file_path;
                } else {
                    if (!empty($request->product_image_edit[$key]))
                        $product_photo = $request->product_image_edit[$key];
                }


                $data = array(
                    'at_user_id' => $user_id,
                    'warehouse_unit_id' => $request->warehouse_unit_id[$key],
                    'ref_hscode_id' => $request->ref_hscode_id[$key],
                    'product_description' => $request->product_description[$key],
                    'ref_product_id' => $request->ref_product_id[$key],
                    'product_trader_name' => $request->product_trader_name[$key],
                    'organic_status' => $request->organic_status[$key],
                    'product_image' => $product_photo,
                );

                if (!empty($request->row_id[$key])) {
                    $data['updated_at'] = date('Y-m-d H:i:s');
                    $data['updated_by'] = Auth::guard('misadmin')->user()->id;
                    TradersProductDetail::where('id', $request->row_id[$key])->where('at_user_id', $user_id)->update($data);
                } else {
                    $data['created_by'] = Auth::guard('misadmin')->user()->id;
                    $data['created_at'] = date('Y-m-d H:i:s');
                    TradersProductDetail::create($data);
                }
            }

            Alert::success('Success', 'Record updated Successfully');
            return redirect()->route('superadmin.tradersUseredit.step3', $user_id);
        } catch (Exception $e) {
            return redirect()->back();
        } catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
            return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
        }
    }

    public function tradersEditStep3(Request $request, $user_id)
    {
        try {
            $userdetails = User::with('TradersDocuments')->find($user_id);
            $traders_document = $userdetails->TradersDocuments;
            return view('admin/traders/list_of_document', compact('userdetails', 'traders_document'));
        } catch (Exception $e) {
            return redirect()->back();
        } catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
            return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
        }
    }

    public function tradersEditFinalSave(Request $request, $user_id)
    {
        try {
            if (empty($request->row_id)) {
                $request->validate([
                    // 'aadhar_card_image_path' => 'required',
                    // 'pan_card_image_path' => 'required',
                    // 'passbook_image_path' => 'required',
                    // 'contact_person_sign_image_path' => 'required',
                    // 'live_signature_image_path' => 'required',
                ]);
            }

            $product_photo = $aadhar_card = $pan_card = $bank_copy_passbook =  $contact_person_sign_thumb_Impression = $live_signature_thumb_impression = '';


            if (!empty($request->file('aadhar_card_image_path'))) {
                if (!empty($request->aadhar_card_image_path_edit)) {
                    $imagePath = public_path('traders/documents/aadhar_card/') . $request->aadhar_card_image_path;
                    deleteOldImage($request->aadhar_card_image_path_edit, $imagePath);
                }
                $documentRootPath = 'public/traders/documents/aadhar_card';
                $file_path = time() . rand() . '.' . $request->file('aadhar_card_image_path')->getClientOriginalExtension();
                $request->file('aadhar_card_image_path')->move($documentRootPath, $file_path);
                $aadhar_card = $file_path;
            } else {
                if (!empty($request->aadhar_card_image_path_edit))
                    $aadhar_card = $request->aadhar_card_image_path_edit;
            }

            if (!empty($request->file('pan_card_image_path'))) {
                if (!empty($request->pan_card_image_path_edit)) {
                    $imagePath = public_path('traders/documents/pan_card/') . $request->pan_card_image_path;
                    deleteOldImage($request->pan_card_image_path_edit, $imagePath);
                }
                $documentRootPath = 'public/traders/documents/pan_card';
                $file_path = time() . rand() . '.' . $request->file('pan_card_image_path')->getClientOriginalExtension();
                $request->file('pan_card_image_path')->move($documentRootPath, $file_path);
                $pan_card = $file_path;
            } else {
                if (!empty($request->pan_card_image_path_edit))
                    $pan_card = $request->pan_card_image_path_edit;
            }

            if (!empty($request->file('passbook_image_path'))) {
                if (!empty($request->passbook_image_path_edit)) {
                    $imagePath = public_path('traders/documents/bank_copy_passbook/') . $request->passbook_image_path;
                    deleteOldImage($request->passbook_image_path_edit, $imagePath);
                }
                $documentRootPath = 'public/traders/documents/bank_copy_passbook';
                $file_path = time() . rand() . '.' . $request->file('passbook_image_path')->getClientOriginalExtension();
                $request->file('passbook_image_path')->move($documentRootPath, $file_path);
                $bank_copy_passbook = $file_path;
            } else {
                if (!empty($request->passbook_image_path_edit))
                    $bank_copy_passbook = $request->passbook_image_path_edit;
            }

            if (!empty($request->file('contact_person_sign_image_path'))) {
                if (!empty($request->contact_person_sign_image_path_edit)) {
                    $imagePath = public_path('traders/documents/contact_person_sign_thumb_Impression/') . $request->contact_person_sign_image_path;
                    deleteOldImage($request->contact_person_sign_image_path_edit, $imagePath);
                }
                $documentRootPath = 'public/traders/documents/contact_person_sign_thumb_Impression';
                $file_path = time() . rand() . '.' . $request->file('contact_person_sign_image_path')->getClientOriginalExtension();
                $request->file('contact_person_sign_image_path')->move($documentRootPath, $file_path);
                $contact_person_sign_thumb_Impression = $file_path;
            } else {
                if (!empty($request->contact_person_sign_image_path_edit))
                    $contact_person_sign_thumb_Impression = $request->contact_person_sign_image_path_edit;
            }


            if (!empty($request->file('live_signature_image_path'))) {
                if (!empty($request->live_signature_image_path_edit)) {
                    $imagePath = public_path('traders/documents/live_signature_thumb_impression/') . $request->live_signature_image_path;
                    deleteOldImage($request->live_signature_image_path_edit, $imagePath);
                }
                $documentRootPath = 'public/traders/documents/live_signature_thumb_impression';
                $file_path = time() . rand() . '.' . $request->file('live_signature_image_path')->getClientOriginalExtension();
                $request->file('live_signature_image_path')->move($documentRootPath, $file_path);
                $live_signature_thumb_impression = $file_path;
            } else {
                if (!empty($request->live_signature_image_path_edit))
                    $live_signature_thumb_impression = $request->live_signature_image_path_edit;
            }


            $data = array(
                'at_user_id' => $user_id,
                'aadhar_card_image_path' => $aadhar_card,
                'pan_card_image_path' => $pan_card,
                'passbook_image_path' => $bank_copy_passbook,
                'contact_person_sign_image_path' => $contact_person_sign_thumb_Impression,
                'live_signature_image_path' => $live_signature_thumb_impression,

            );

            $traders_document = TradersDocument::find($request->row_id);

            if (!empty($traders_document)) {
                $data['updated_at'] = date('Y-m-d H:i:s');
                $data['updated_by'] = Auth::guard('misadmin')->user()->id;
                $traders_document->where('id', $request->row_id)->where('at_user_id', $user_id)->update($data);
            } else {
                $data['created_by'] = Auth::guard('misadmin')->user()->id;
                $data['created_at'] = date('Y-m-d H:i:s');
                TradersDocument::create($data);
            }


            Alert::success('Success', 'Record updated Successfully.');

            //return redirect()->route('superadmin.tradersUseredit.step3', $user_id);
            return redirect()->route('superadmin.traders.preview', $user_id);
        } catch (Exception $e) {
            return redirect()->back();
        } catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
            return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
        }
    }



    public function deptUserDelete(Request $request)
    {
        try {
            $id = $request->id;
            $user = User::find($id);
            $user->is_deleted = 1;
            $user->deleted_at = date('Y-m-d H:i:s');
            $user->save();


            return json_encode(['message' => 'done']);
        } catch (Exception $e) {
            return redirect()->back();
        } catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
            return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
        }
    }
    public function storeMedia(Request $request)
    {

        /*$validator = Validator::make($request->all(), [
                'file' => 'required|mimes:jpeg,jpg,png,pdf,doc,gif,docx,mp4,uvu,mp4s,avi
                          |mimetypes:image/jpeg,image/jpg,image/png,application/pdf,application/msword,image/gif,
                          application/vnd.openxmlformats-officedocument.wordprocessingml.document,video/vnd.uvvu.mp4,
                          application/mp4,video/mp4,video/x-msvideo',
        ]);

        if($validator->fails()){
                return Response::make($validator->errors()->first(), 400);
            }*/

        try {
            $path = 'public/research/uploads';
            if (!file_exists($path)) {
                mkdir($path, 0777, true);
            }

            $file = $request->file('file');
            $name = uniqid() . '_' . trim($file->getClientOriginalName());

            /*Custom Validation Vikash Chaudhary 17/11/2020*/

            $file_name = (isset($_FILES['file']['name']) && !empty($_FILES['file']['name'])) ? $_FILES['file']['name'] : "";
            $file_tmp_name = (isset($_FILES['file']['tmp_name']) && !empty($_FILES['file']['tmp_name'])) ? $_FILES['file']['tmp_name'] : "";

            $mime = $file->getMimeType();

            $file_array = array(
                'file_name' => $file_name,
                'file_tmp_name' => $file_tmp_name,
                'file_mime_type' => $mime,
            );
            $data = getimagesize($file_tmp_name);
            if ($data != false) {
                $width = $data[0];
                $height = $data[1];
            } else {
                $width = '';
                $height = '';
            }

            // $checkFileUpload = checkUploadFileContent($file_array);


            // if (!empty($checkFileUpload)) {
            //     if (isset($checkFileUpload['error']) && $checkFileUpload['error'] == 1) {
            //         return Response::make($checkFileUpload['message'], 400);
            //     }
            // }

            $file->move($path, $name);

            if (in_array($file->getClientOriginalExtension(), ['pdf', 'png', 'jpg', 'jpeg', 'PNG', 'JPG', 'JPEG', 'mp4', 'MP4'])) {
                $image = str_replace(asset('/'), '', $path . '/' . $name);
                $path = $path . '/' . $name;
                $image = str_replace('', '_', urldecode($image));

                $image = explode('/', $image);
                $name = end($image);

                # Generate thumbs of the images

                # Check image size
                if ($width != '') {
                    // $this->createThumb($path, $width, $height, str_replace('', '_', $name), false);
                }
                // slider
                // $this->createThumb($path, 378, 194, 'thumb_378X194_' . str_replace('', '_', $name), true); //campaign home page slider
                // $this->createThumb($path, 75, 76, 'thumb_511X341_' . str_replace('', '_', $name), true); //blog page slider home page
                // $this->createThumb($path, 931, 214, 'thumb_931X214_' . str_replace('', '_', $name), true); //Blog Page Details page
                // $this->createThumb($path, 511, 341, 'thumb_511X341_' . str_replace('', '_', $name), true); // Blog Listing Page
                // $this->createThumb($path, 267, 183, 'thumb_267X183_' . str_replace('', '_', $name), true); // Event Home page slider
                // $this->createThumb($path, 261, 251, 'thumb_261X251_' . str_replace('', '_', $name), true); // compatation winners home page
                // $this->createThumb($path, 369, 186, 'thumb_369X186_' . str_replace('', '_', $name), true); // AVCC Slider home page
            } else {
                dd('no');
            }

            return response()->json([
                'name' => $name,
                'original_name' => $file->getClientOriginalName(),
            ]);
        } catch (Exception $e) {
            return redirect()->back();
        } catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
            return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
        }
    }


    public function traderview(Request $request, $id)
    {

        $user = User::where('id', $id)->first();

        $traders_document = TradersDocument::where('at_user_id', $id)->get();

        $traders_warehouse_details = GeoTaggingWarehouseDetail::where('at_user_id', $id)->get();
        // dd($traders_warehouse_details);
        $traders_product_details = TradersProductDetail::where('at_user_id', $id)->get();
        $states = RefState::orderBy('state_name', 'ASC')->get();

        $eMSignedModuleAlow = getUserDigitalSignatureModules(Auth::id(), 'SC');
        $eMSignedModuleResult = '';
        $hostName = '';
        if ($eMSignedModuleAlow['status'] == 'success' && $eMSignedModuleAlow['isAllowed'] == '1') {
            $hostName = request()->getSchemeAndHttpHost();
            $checkSignedPDf = getDigitalSignedPdf(Auth::id(), basename($user->registration_certificate));

            if ($checkSignedPDf['status'] == 'success') {
                $eMSignedModuleResult = [
                    'signedPath' => $checkSignedPDf['signedPath'],
                    'status' => 'success',
                ];
            } else {
                $eMSignedModuleResult = [
                    'signedPath' => '',
                    'status' => 'failed',
                ];
            }
        }
        return view('admin/traders/traderpreview', compact('id', 'traders_document', 'traders_warehouse_details', 'traders_product_details', 'user', 'states', 'eMSignedModuleAlow', 'eMSignedModuleResult', 'hostName'));
    }

    public function getFSSAIDetails(Request $request)
    {

        $curl = curl_init();
        $dt = array("licenseNo" => $request->license_number);
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://foscos.fssai.gov.in/gateway/extranet/thirdpartyapi/fboDetailsAndProductDetailsSearchByLicenseNo',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode($dt),
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json'
            ),
        ));

        $response = curl_exec($curl);
        //dd($response);

        // if (curl_errno($curl)) {
        //     $error_msg = curl_error($curl);
        // }
        // if (isset($error_msg)) {
        //     echo "<pre>";
        //     print_r($error_msg);
        //     die();
        // }
        $token_data = json_decode($response, true);


        curl_close($curl);
        return $response;
    }


    public function batchCreate()
    {
        $usID = Auth::id();
        $product_details = TradersProductDetail::where('created_by', $usID)->get();

        return view('admin/traders/create_batch', compact('product_details'));
    }
    public function BatchHistory()
    {

        $data = SourceDetails::select('at_source_details.*', 'at_batch_details.product_code', 'at_batch_details.product_name', 'at_batch_details.total_quantity', 'at_batch_details.created_at') // Select 
            ->LeftJoin('at_batch_details', 'at_source_details.batch_id', '=', 'at_batch_details.batch_id')
            ->whereNull('at_source_details.deleted_at')
            ->orderby('at_source_details.id', 'desc')
            ->get();

        return view('admin/traders/history', compact('data'));
    }



    public function processedbatch(Request $request, $at_user_id)
    {

        $list = CertificateStandardDetail::where('at_user_id', $at_user_id)->first();
        $org_st = TradersProductDetail::where('at_user_id', $at_user_id)->first();
        $user = User::where('id', $at_user_id)->first();
        // dd($org_st );
        return view('admin/traders/processed', compact('list', 'org_st',  'user'));
    }

    public function search_source(Request $request)
    {
        try {
            // Check if the request is an AJAX request
            if ($request->ajax()) {

                $userId = Auth::id();

                $query = AtOpTransactionVsTransactionProduct::whereNotNull('transaction_certificate_no')->whereNotNull('product_code')
                    ->where('transaction_certificate_no', '!=', '')
                    ->where('product_code', '!=', '')
                    ->get();


                if (!empty($request->registration_no)) {
                    $query->where('product_code', $request->registration_no);
                }
                //   $finalData = $query->get();
                //  dd($finalData);

                $dataTable = DataTables::of($query)
                    ->addIndexColumn()
                    ->addColumn('tc_no', function ($row) {
                        return !empty($row->transaction_certificate_no) ? $row->transaction_certificate_no : 'N/A';
                    })
                    ->addColumn('product_name', function ($row) {
                        return !empty($row->product_code) ? getHscodeProductName($row->product_code) : 'N/A';
                    })
                    ->addColumn('organic_status', function ($row) {
                        return !empty($row->organic_status) ? getRefOrganicStatuscodeByname($row->organic_status) : 'N/A';
                    })
                    ->addColumn('total_qnt', function ($row) {
                        return !empty($row->total_qty) ? $row->total_qty : '0';
                    })
                    ->addColumn('used_qnt', function ($row) {
                        return !empty($row->quantity_for_tc) ? $row->quantity_for_tc : '0';
                    })
                    ->addColumn('available_qnt', function ($row) {
                        return !empty($row->rem_qty) ? $row->rem_qty : '0';
                    })
                    ->addColumn('qnt_source', function ($row) {

                        $uniqueId = 'qnt_source_' . $row->id;
                        return sprintf(
                            '<input type="text" class="form-control" id="qnt_source' . $row->id . '"  name="qnt_source" value="">',
                            $uniqueId,
                            $row->id,
                            $row->qnt_source
                        );
                    })
                    ->addColumn('action', function ($row) {

                        return '<a href="javascript:;" class="saveButton" data-id="' . $row->id . '" data-tcno="' . $row->transaction_certificate_no . '" data-procode="' . $row->product_code . '" data-qty ="' . $row->total_qty . '" data-usedqty ="' . $row->quantity_for_tc . '" data-available_qnt="' . $row->rem_qty . '">Add</a>';
                    })
                    ->rawColumns(['qnt_source', 'action']);


                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            // Handle exceptions and log errors
            Log::error($e);
            Alert::error('Error', 'Something went wrong, please try again later.');
            return redirect()->back();
        }
    }

    public function saveQuantity(Request $request)
    {
        // dd($request->all());
        $at_user_id = Auth::guard('misadmin')->user()->id;
        $rowId = $request->input('row_id');
        $tcNo = $request->input('tc_no');
        $procode = $request->input('pro_code');
        $qty = $request->input('total_quantity');
        $usedqty = $request->input('used_quantity');
        $available_qnt = $request->input('available_qnt');
        $qntSourceValue = $request->input('qnt_source');
        // $batch_id = $request->input('row_id');
        $batchId = $request->input('batch_id');
        $record = new SourceDetails;

        if ($record) {

            // $record->at_user_id = $at_user_id;
            // $record->product_code = $procode;
            // $record->tc_no = $tcNo;
            // $record->organic_status = $organic_statusValue;
            // $record->total_quantity = $qty;
            // $record->source_from = 'TC';
            // $record->used_quantity =   $usedqty;
            // $record->available_quantity = $available_qnt;
            // $record->expiry_date = $request->input('expiry_date');
            // $record->quantity_source = $qntSourceValue;
            // $record->batch_id = $batch_id;
            $record->at_user_id = $at_user_id;
            $record->product_code = $procode;
            $record->batch_id =  $batchId;
            // $record->batchdetails_id =  $batchDetailsId; 
            $record->tc_no = $tcNo;
            $record->used_quantity =  $usedqty;
            $record->available_quantity =  $available_qnt;
            $record->quantity_source =  $qntSourceValue;
            $record->save();


            return response()->json(['success' => true, 'message' => 'Saved successfully']);
        } else {

            return response()->json(['success' => false, 'message' => 'Record not found'], 404);
        }
    }


    /*  public function processedbatchsave(Request $request)
    {
        // $request->validate([
        //     'scope_certificate_no' => 'required',
        //     'hs_code' => 'required',
        //     'product' => 'required',

        // ]);


        $formData = new BatchCreation;


        $formData->scope_certificate_no = $request->input('scope_certificate_no');
        $formData->unit_name = $request->input('unit_name');
        $formData->hs_code = $request->input('hs_code');
        $formData->product = $request->input('product');
        $formData->organic_status = $request->input('organic_status');
        $formData->quantity = $request->input('quantity');
        $formData->percentage = $request->input('percentage');
        $formData->processing_date = $request->input('processing_date');
        $formData->expiry_date = $request->input('expiry_date');
        $formData->by_product = $request->input('byProduct');
        $formData->created_at = date('Y-m-d H:i:s');
        $formData->updated_at = date('Y-m-d H:i:s');
        $formData->created_by = Auth::guard('misadmin')->user()->id;
        $formData->updated_by = Auth::guard('misadmin')->user()->id;
        $formData->at_user_id = Auth::guard('misadmin')->user()->id;

        $formData->save();
        // dd($formData);


        return redirect()->route('superadmin.batchSouceDetails');
    }*/

    public function processedbatchsave(Request $request)
    {
        // Create a new BatchCreation instance and populate its fields
        $formData = new BatchCreation;
        $formData->scope_certificate_no = $request->input('scope_certificate_no');
        $formData->unit_name = $request->input('unit_name');
        $formData->hs_code = $request->input('hs_code');
        $formData->product = $request->input('product');
        $formData->organic_status = $request->input('organic_status');
        $formData->quantity = $request->input('quantity');
        $formData->percentage = $request->input('percentage');
        $formData->processing_date = $request->input('processing_date');
        $formData->expiry_date = $request->input('expiry_date');
        $formData->by_product = $request->input('byProduct');
        $formData->created_at = now();
        $formData->updated_at = now();
        $formData->created_by = Auth::guard('misadmin')->user()->id;
        $formData->updated_by = Auth::guard('misadmin')->user()->id;
        $formData->at_user_id = Auth::guard('misadmin')->user()->id;

        // Save the BatchCreation record
        $formData->save();

        // Retrieve the id of the newly created BatchCreation record
        $batchCreationId = $formData->id;

        $atBatchDetail = new AtBatchDetail;
        $atBatchDetail->batch_id = $batchCreationId;
        $atBatchDetail->product_code =  $request->input('hs_code');
        $atBatchDetail->product_name =  $request->input('product');
        $atBatchDetail->total_quantity =  $request->input('quantity');
        $atBatchDetail->created_at = now();
        $atBatchDetail->updated_at = now();
        $atBatchDetail->created_by = Auth::guard('misadmin')->user()->id;
        $atBatchDetail->updated_by = Auth::guard('misadmin')->user()->id;
        $atBatchDetail->at_user_id = Auth::guard('misadmin')->user()->id;
        $atBatchDetail->save();

        // Redirect the user to the desired route after successful insertion
        return redirect()->route('superadmin.batchSouceDetails', auth()->user()->id);
    }

    public function batchSouceDetails(Request $request, $at_user_id)
    {
        $batchId = BatchCreation::where('at_user_id', $at_user_id)->latest()->first();
        $batchDetailsId = AtBatchDetail::where('at_user_id', $at_user_id)->get();
        $data =  SourceDetails::where('at_user_id', $at_user_id)->get();
        //dd($data );
        if ($request->ajax()) {
            $dataTable = DataTables::of($data)
                ->addIndexColumn()
                ->addColumn('tc_no', function ($row) {
                    return !empty($row->tc_no) ? $row->tc_no : 'N/A';
                })
                ->addColumn('product_code', function ($row) {
                    return !empty($row->product_code) ? getHscodeProductName($row->product_code) : 'N/A';
                })
                ->addColumn('available_quantity', function ($row) {
                    return !empty($row->available_quantity) ? $row->available_quantity : 'N/A';
                })
                ->addColumn('quantity_source', function ($row) {
                    return !empty($row->quantity_source) ? $row->quantity_source : '0';
                })
                ->addColumn('action', function ($row) {
                    return ;
                })
                ->rawColumns(['action']);
            return $dataTable->make(true);
        }
        return view('admin/traders/source_details', compact('batchId', 'batchDetailsId', 'data'));
    }

    public function SouceDetail($at_user_id)
    {

        $data = BatchCreation::where('at_user_id', $at_user_id)->first();
        $Sourcedata =  SourceDetails::where('at_user_id', $at_user_id)->get();
        //  dd($Sourcedata);
        return view('admin/traders/preview_detail', compact('data', 'Sourcedata'));
    }

    public function Detailsave(Request $request)
    {

        return redirect()->route('superadmin.batchdetails',  auth()->user()->id);
    }
    public function batchdetails($at_user_id)
    {

        $data = SourceDetails::select('at_source_details.*', 'at_batch_details.product_code', 'at_batch_details.product_name', 'at_batch_details.total_quantity', 'at_batch_details.created_at') // Select 
            ->LeftJoin('at_batch_details', 'at_source_details.batch_id', '=', 'at_batch_details.batch_id')
            ->whereNull('at_source_details.deleted_at')
            ->orderby('at_source_details.id', 'desc')
            ->get();

        // dd($data);
        return view('admin/traders/batch_detail', compact('data'));
    }

    public function batch_Delete(Request $request)
    {
        try {
            $id = $request->id;
            $user = SourceDetails::find($id);
            $user->deleted_at = date('Y-m-d H:i:s');
            $user->save();


            return json_encode(['message' => 'done']);
        } catch (Exception $e) {
            return redirect()->back();
        } catch (\Illuminate\Contracts\Encryption\DecryptException $exception) {
            return redirect()->back()->withErrors(['msg' => 'somethig went wrong.']);
        }
    }

    public function listOfTransCertificate(Request $request)
    {

        $id = Auth::guard('misadmin')->user()->id;
        if ($request->ajax()) {
            $totalData = AtOpTransactionVsTransactionProduct::where('created_by', $id)->get();
            return Datatables::of($totalData)
                ->addIndexColumn()
                ->addColumn('tc_application_no', function ($row) {
                    return $row->tc_application_no;
                })->addColumn('tc_date', function ($row) {
                    return date('d-m-Y', strtotime($row->tc_date));
                })->addColumn('seller', function ($row) {
                    return $row->quantity;
                })->addColumn('buyer', function ($row) {
                    return getHscodeProductName($row->commodity) ?? '';
                })->addColumn('country', function ($row) {
                    return 'INDIA';
                })->addColumn('status', function ($row) {
                    return  $row->nop_status ?? '';
                })->addColumn('tc_type', function ($row) {
                    return  'Domestic';
                })->addColumn('action', function ($row) {

                    $actionBtn = '<a href="' . route('superadmin.viewTCApplication', [$row->id]) . '" class="btn btn-soft-primary ms-2"><span><i class="ri-file-edit-fill" data-toggle="tooltip" title="Apply for domestic TC" ></i></span></a>';

                    return $actionBtn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        return view('admin.traders.listOfTransCertificate');
    }

    public function applyForDomesticTC($id = NULL)
    {

        $user_id = Auth::guard('misadmin')->user()->id;

        $operator_type_id = Auth::guard('misadmin')->user()->ref_operator_type_id;

        // $order_list2 = AtPurchaseRequest::select('at_purchase_request.*')
        // ->join('at_order_details_received_from_buyer as odrb','odrb.at_purchase_request_id','at_purchase_request.id')
        // ->join('at_order_accepted','at_order_accepted.at_order_details_received_from_buyer_id','odrb.id')
        // ->join('at_closing_stock','at_closing_stock.at_user_id','at_purchase_request.at_user_id')
        // ->join('at_farmer_standing_crop_details','at_farmer_standing_crop_details.id','at_closing_stock.at_farmer_standing_crop_details_id')
        // ->where('at_purchase_request.at_user_id',$user_id)
        // ->orderBy('at_purchase_request.created_at', 'asc')
        // ->get();

        // $order_list2 = DB::select("select abc.id, abc.commodity, at_closing_stock.id as clsid,at_closing_stock.organic_status, at_closing_stock.closing_stock, abc.quantity from at_batch_creation as abc INNER join at_order_details_received_from_buyer as odrb on odrb.at_purchase_request_id = abc.id inner join at_order_accepted on at_order_accepted.at_order_details_received_from_buyer_id = odrb.id inner join at_closing_stock on at_closing_stock.at_user_id = abc.at_user_id and at_closing_stock.ref_product_id = abc.commodity
        // inner join at_farmer_standing_crop_details on at_farmer_standing_crop_details.id = at_closing_stock.at_farmer_standing_crop_details_id where abc.at_user_id = $user_id and abc.order_status = 1  group BY (abc.commodity,abc.id,at_closing_stock.organic_status,closing_stock,abc.quantity,at_closing_stock.id)");
        $order_list2 = DB::select("select * from at_batch_creation where at_user_id = $user_id");
        $order = array();
        $j = 0;

        foreach ($order_list2 as $key => $vls) {
            $order['purchase_list'][$key] = $vls;
            $purchases = AtBatchDetail::where('batch_id', $vls->id)->get();
            $order['purchase_list'][$key]->mypurchase = $purchases;
        }

        // $data = AtBatchCreation::with('batchDetails')->where('created_by', $user_id)->get();
        $data = AtBatchCreation::with(['batchDetails', 'sourceDetails'])->where('created_by', $user_id)->get();
        // dd($query);
        //dd($order);
        // dd($data);

        //$data= array();
        // here aaproved purchase req from trader/processor should be display here
        // $order_list = AtClosingStock::with('getPurchaseDetails')
        // ->when($operator_type_id == 2, function($q) {
        // 	$q->with('getFarmerStandingCorpDetail');
        // })
        /* ->when($operator_type_id == 3, function($q) {
			$q->with('IPDetailOfStandingCorp');
		})
		->when($operator_type_id == 4, function($q) {
			$q->with('getwhproducts');
		})	 */
        // ->where('at_user_id',$user_id)
        // ->orderBy('created_at', 'asc')
        // ->get();
        // pra($order_list);
        // dd($data);
        return view('admin.traders.apply_for_domestic_tc', compact('order', 'data'));
    }

    public function storeApplyForDomesticTCT(Request $request)
    {
        //  dd($request->all());
        $request->validate([
            //'transportation_date' => 'required',
        ]);
        try {
            $operator_type_id = Auth::guard('misadmin')->user()->ref_operator_type_id;
            foreach ($request->lots as $key => $val) {
                if (!empty($request->lots[$key])) {
                    $data = array(
                        'farm_no'   => $request->farm_no[$key] ?? '',
                        'total_qty'   => $request->total_qty[$key] ?? '',
                        'tc_date'   => date('Y-m-d'),
                        'operator_type'   => $operator_type_id ?? '',
                        'rem_qty'   => $request->rem_qty[$key] ?? '',
                        // 'quantity_for_tc'   => $request->req_qty[$key],
                        'product_code' => $request->product_code[$key] ?? '',
                        'organic_status' => $request->organic_status[$key] ?? '',
                        //'quantity_for_tc'   => $request->quantity_for_tc[$key],
                        'created_by' => Auth::guard('misadmin')->user()->id,
                        'updated_by' => Auth::guard('misadmin')->user()->id
                    );
                    $result = AtOpTransactionVsTransactionProduct::updateOrCreate([
                        'id'   => $request->row_id[$key],
                    ], $data);
                    // $result = AtOpTransactionVsTransactionProduct::where('id',78)->first();
                    // $ref_product = RefProduct::where('hs_code', $result->product_code)->first();
                    if (!empty($result)) {
                        // dd($data);
                        foreach ($request->pur_lots[$key]  as $k => $val1) {

                            if (!empty($request->pur_lots[$key])) {
                                $data1 = array(
                                    'at_op_transaction_vs_transaction_product_id'   => $result->id ?? '',
                                    // 'at_op_transaction_vs_transaction_product_id'   => 78,
                                    'ref_product_id'   => $result->product_code ?? '',
                                    // 'at_closing_stock_id'   => $request->at_closing_stock_id[$key][$k] ?? '0',
                                    // 'at_purchase_details_id'   => $request->at_purchase_details_id[$key][$k] ?? '0',
                                    // 'product_code' =>'',
                                    // 'organic_status' => $result->$request->organic_status $op_organic_status[$key][$k] ?? '' ,
                                    'organic_status' => $result->organic_status ?? '',
                                    'qty_in_mt' => $request->used_quantity[$key][$k] ?? '',
                                    'source_date'   => date('Y-m-d'),
                                    'created_by' => Auth::guard('misadmin')->user()->id,
                                    'updated_by' => Auth::guard('misadmin')->user()->id
                                );
                                if ($request->rows_id[$key][$k] != '') {
                                    $result1 = AtOpTransactionProductSourced::create($data1);
                                } else {
                                    $result1 = AtOpTransactionProductSourced::where('id', $request->rows_id[$key][$k])->upedate();
                                }
                                // $result1 = AtOpTransactionProductSourced::updateOrCreate([
                                //     'id'   => $request->rows_id[$key][$k],
                                // ], $data1);
                            }
                        }

                        if (!empty($result1->id)) {
                            Alert::success('Success', __('message.add_success'));
                            return redirect()->route('superadmin.trader.packingDetailTC', [$result->id]);
                        } else {
                            Alert::success('Success', 'Something went wrong.');
                            return redirect()->back();
                        }
                    }
                }
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }

    public function packingDetailTC($id)
    {
        $trans = AtOpTransactionVsTransactionProduct::with('getTransProductSource')->where('id', $id)->get();
        // packing master list get
        $packs = RefPackingMaster::get();
        //AtOpTransactionPackingDetails::where(['product_code'=>$trans[0]->ref_product_id,'crested_by',Auth::guard('misadmin')->user()->id])->get();
        // dd($packs);
        return view('admin.traders.packing_detail_tc', compact('trans', 'packs'));
    }


    public function storePackingDetailTC(Request $request)
    {
        // dd($request->all());
        $request->validate([
            'value_inr' => 'required',
            'trade_name_of_product' => 'required',
            'ref_packing_master_id.*' => 'required',
            'no_of_box.*' => 'required',
            'pack_size.*' => 'required',
            'total_qty_in_kg.*' => 'required',
        ]);
        // if(!empty($validator->fails())) {
        // 	return Redirect::back()->withErrors($validator);
        // }
        try {
            // dd($request->all());
            $operator_type_id = Auth::guard('misadmin')->user()->ref_operator_type_id;
            $edtVal = 0;
            $ref_product = RefProduct::where('id', $request->ref_product_id)->first();
            // if (!empty($request->at_op_transaction_product_sourced_id)) {
            //     foreach ($request->at_op_transaction_product_sourced_id as $key => $val) {

            // if (!empty($request->at_op_transaction_product_sourced_id[$key])) {

            $data = array(
                'at_op_transaction_product_sourced_id'   => $request->at_op_transaction_product_sourced_id ?? '',
                'ref_product_id'   => $ref_product->id ?? '',
                'ref_packing_master_id'   => $request->ref_packing_master_id ?? '',
                'no_of_box'   => $request->no_of_box ?? '',
                'pack_size'   => $request->pack_size ?? '',
                'total_qty_in_kg'   => $request->total_qty_in_kg ?? '',
                'created_by' => Auth::guard('misadmin')->user()->id,
                'updated_by' => Auth::guard('misadmin')->user()->id
            );
            // if($request->row_id != ''){
            // dd($data);
            $result = AtOpTransactionPackingDetails::create($data);
            // }else{
            //     $result = AtOpTransactionPackingDetails::where('id', $request->row_id)->update($data);
            // }
            // $result = AtOpTransactionPackingDetails::updateOrCreate(
            //     ['id' => $request->row_id]
            // , $data);
            //     }
            // }

            if (!empty($result)) {
                $updateData = array(
                    'value_inr' => $request->value_inr ?? '',
                    'trade_name_of_product' => $request->trade_name_of_product ?? '',
                );
                $res = AtOpTransactionVsTransactionProduct::where('id', $request->trans_id)->update($updateData);

                //if(isset($request->row_id[0]) && $request->row_id[0]!=''){
                Alert::success('Success', __('message.add_success'));
                return redirect()->route('superadmin.trader.TcDetail', $request->trans_id);
                // }else{
                // 	Alert::success('Success', __('message.add_success'));
                // 	return redirect()->back();
                // }

            }
            // }
        } catch (Exception $e) {
            Log::error($e->getMessage('kuch save nhi ho rha'));
            abort('404');
        }
    }

    public function TcDetail($id)
    {

        $data =  AtOpTransactionCertificateEntry::where('at_op_transaction_vs_transaction_product_id', $id)->first();
        return view('admin.traders.tc_details', compact('id', 'data'));
    }


    public function storeTcDetail(Request $request)
    {
        //dd($request->all());
        $request->validate([
            'invoice_no' => 'required',
            'invoice_date' => 'required',
            'invoice_value' => 'required',
            //'place_of_dispatch' => 'required',
            'lot_number' => 'required',
            'place_of_destination' => 'required',
            'marks_no' => 'required',
            'reference_no' => 'required',
        ]);
        // if(!empty($validator->fails())) {
        // 	return Redirect::back()->withErrors($validator);
        // }
        try {

            /// Date of Transport
            if (!empty($request->road_transport_date)) {
                $transport_date = date('Y-m-d H:i:s', strtotime($request->road_transport_date));
            } elseif (!empty($request->train_transport_date)) {
                $transport_date = date('Y-m-d H:i:s', strtotime($request->train_transport_date));
            } else {
                $transport_date = null;
            }


            // dd(date('Y-m-d H:i:s',strtotime($request->invoice_date[0])));
            $data = array(
                'exporter_seller_name'   => !empty($request->exporter_seller_name) ? $request->exporter_seller_name : Null,
                'seller_email'   => !empty($request->seller_email) ? $request->seller_email :  Null,
                'seller_at_op_certificate_standard_details_id'   => !empty($request->seller_at_op_certificate_standard_details_id) ? $request->seller_at_op_certificate_standard_details_id : Null,
                'exporter_seller_address'   => !empty($request->exporter_seller_address) ? $request->exporter_seller_address : Null,
                'buyer_id_proof'   => !empty($request->buyer_id_proof) ? $request->buyer_id_proof : Null,
                'buyer_name'   => !empty($request->buyer_name) ? $request->buyer_name : Null,
                'buyer_address'   => !empty($request->buyer_address) ? $request->buyer_address : Null,
                'buyer_at_op_certificate_standard_details_id'   => !empty($request->buyer_at_op_certificate_standard_details_id) ? $request->buyer_at_op_certificate_standard_details_id : Null,
                'buyer_ref_state_id'   => !empty($request->buyer_ref_state_id) ? $request->buyer_ref_state_id : Null,
                'buyer_email'   => !empty($request->buyer_email) ? $request->buyer_email : Null,
                'invoice_no'   => !empty($request->invoice_no[0]) ? $request->invoice_no[0] : Null,
                'invoice_date'   => date('Y-m-d H:i:s', strtotime(!empty($request->invoice_date[0]) ? $request->invoice_date[0] : NULL)),
                'invoice_value'   => !empty($request->invoice_value) ? $request->invoice_value : Null,
                //'place_of_dispatch'   => $request->place_of_dispatch ?? Null,
                'place_of_destination'   => !empty($request->place_of_destination) ? $request->place_of_destination : Null,
                'marks_no'   => !empty($request->marks_no) ? $request->marks_no : Null,
                'reference_no'   => !empty($request->reference_no) ? $request->reference_no :  Null,
                'transport_mode'   => !empty($request->transport_mode) ? $request->transport_mode : null,

                'container_no_road'   => !empty($request->container_no_road) ? $request->container_no_road : null,
                'transport_doc_no'   => !empty($request->transport_doc_no) ? $request->transport_doc_no : null,
                'transport_date'   => !empty($transport_date) ? $transport_date : null,

                'train_no'   => !empty($request->train_no) ? $request->train_no : null,
                'wagon_no'   => !empty($request->wagon_no) ? $request->wagon_no : null,
                'train_transport_date'   => !empty($request->train_transport_date) ? date('Y-m-d H:i:s', strtotime($request->train_transport_date)) : null,

                'flight_no'   => !empty($request->flight_no) ? $request->flight_no : null,
                'flight_date'   => !empty($request->flight_date) ? date('Y-m-d H:i:s', strtotime($request->flight_date)) : null,
                'airway_bill_no'   => !empty($request->airway_bill_no) ? $request->airway_bill_no : null,
                'airway_bill_date'   => !empty($request->airway_bill_date) ? date('Y-m-d H:i:s', strtotime($request->airway_bill_date)) : null,
                'container_no_air'   => !empty($request->container_no_air) ? $request->container_no_air : null,

                'ship_no'   => !empty($request->ship_no) ? $request->ship_no : null,
                'ship_name'   => !empty($request->ship_name) ? $request->ship_name : null,
                'vessel_date'   => !empty($request->vessel_date) ? $request->vessel_date : null,
                'bill_of_lading'   => !empty($request->bill_of_lading) ? $request->bill_of_lading : null,
                'date_of_lading'   => !empty($request->date_of_lading) ? $request->date_of_lading : null,
                'container_no_ship'   => !empty($request->container_no_ship) ? $request->container_no_ship : null,

                'gross_weight'   => !empty($request->gross_weight) ? $request->gross_weight : null,
                'created_by' => Auth::guard('misadmin')->user()->id,
                'updated_by' => Auth::guard('misadmin')->user()->id,
                'at_op_transaction_vs_transaction_product_id' => $request->at_op_transaction_vs_transaction_product_id,
                'lot_number' => !empty($request->lot_number) ? $request->lot_number : null,
            );
            //dd($data);
            $saveData = AtOpTransactionCertificateEntry::updateOrCreate(['at_op_transaction_vs_transaction_product_id' => $request->at_op_transaction_vs_transaction_product_id], $data);

            Alert::success('Success', __('message.add_success'));
            return redirect()->route('superadmin.forwardToCB', $request->at_op_transaction_vs_transaction_product_id);
            // if(!empty($saveData)){
            // 	Alert::success('Success', __('message.add_success'));
            // 	return redirect()->route('superadmin.TcDetail',$request->at_op_transaction_vs_transaction_product_id);
            // }else{
            // 	Alert::success('Success', 'Something Went Wrong!');
            // 	return redirect()->back();
            // }
        } catch (Exception $e) {
            Log::error($e->getMessage());
            abort('404');
        }
    }
}

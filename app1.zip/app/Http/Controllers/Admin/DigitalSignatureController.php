<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DigitalSignatureController extends Controller
{
    
    public function showForm()
    {
        return view('admin.signature.form');
    }

    public function signAndVerify(Request $request)
    {
        $data = $request->input('data');
        $encryptedData = encrypt($data);
        $decryptedData = decrypt($encryptedData);

        return view('admin.signature.result', compact('data', 'encryptedData', 'decryptedData'));
    }

}

<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use App\Models\AtOpTransactionVsTransactionProduct;
use App\Models\AtBatchCreation;
use App\Models\RefProcuremenEntry;
use App\Models\IndividualProducerDetailOfStandingCorp;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

class StockInventoryController extends Controller
{

    public function CbLotStock()
    {
        return view("admin.stock_inventory.cb.lot_stock");
    }
    public function CbLotStockSearch(Request $request)
    {
        try {
            if ($request->ajax()) {


                $query = RefProcuremenEntry::query()
                          ->leftJoin('at_user', 'at_user.id', '=', 'ref_procurement_entry.created_by');
                $finalData = $query->get();
                // dd($finalData);
                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('cb', function ($row) {
                        return  getCBNamesBycreatedBy(Auth::id());
                    })
                    ->addColumn('opertor', function ($row) {
                        return  getOperatorTypeById($row->ref_operator_type_id ?? 'N/A');
                    })

                    // ->addColumn('count', function ($row) {
                    //     return User::where('ref_operator_type_id', $row->ref_operator_type_id)->count();
                    // })
                    ->addColumn('lot_id', function ($row) {
                        return  $row->lot_number ?? 'N/A';
                    })

                    ->addColumn('product_code', function ($row) {
                       $products =  IndividualProducerDetailOfStandingCorp::where('id',$row->ref_product_id)->first();
                        return ( getRefHscodeByID($products->ref_product_id ?? ''));
                    })
                    ->addColumn('product_name', function ($row) {
                        return ($row->ref_product_id ?? 'N/A');
                    })
                    ->addColumn('quantity', function ($row) {
                        return $row->quantity_source ?? '5.000';
                    })

                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }


    public function CbBatchStock()
    {
        return view("admin.stock_inventory.cb.batch_stock");
    }


    public function CbBatchStockSearch(Request $request)
    {
        try {
            if ($request->ajax()) {


                $user_id = Auth::guard('misadmin')->user()->id;

                $query = AtBatchCreation::query()
                    ->leftJoin('at_batch_details', 'at_batch_creation.id', '=', 'at_batch_details.batch_id');
                

                $finalData = $query->get();

                $finalData = $query->select([
                    'at_batch_creation.*',
                    'at_batch_details.total_quantity',
                    'at_batch_details.product_name',
                    'at_batch_details.total_quantity',
                    // 'at_batch_details.available_quantity',


                ])->limit(8)->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()
                    ->addColumn('batch_id', function ($row) {
                        return time() . $row->id ?? 'N/A';
                    })
                    ->addColumn('product_name', function ($row) {
                        return $row->product_name ?? 'N/A';
                    })
                    ->addColumn('organic_status', function ($row) {
                        return getRefOrganicStatusMasterByID($row->organic_status ?? 'N/A');
                    })
                    ->addColumn('quantity', function ($row) {
                        return $row->quantity ?? 'N/A';
                    })
                    ->addColumn('total_quantity', function ($row) {
                        return $row->total_quantity ?? 'N/A';
                    })
                    ->addColumn('available', function ($row) {
                        return $row->available_quantity ?? '0.00';
                    })

                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    public function CbTcStock()
    {
        return view("admin.stock_inventory.cb.tc_stock");
    }
    public function CbTcStockSearch(Request $request)
    {
        try {
            if ($request->ajax()) {



                $user_id = Auth::guard('misadmin')->user()->id;

                $query = AtOpTransactionVsTransactionProduct::query();

                $finalData = $query->limit(10)->get();
                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('tc_no', function ($row) {
                        return  $row->transaction_certificate_no ?? 'N/A';
                    })

                    ->addColumn('product_name', function ($row) {
                        return ($row->product_code ?? '1904103015');
                    })
                    ->addColumn('organic_status', function ($row) {
                        return getRefOrganicStatusMasterByID($row->organic_status ?? 'N/A');
                    })
                    ->addColumn('tc_quantity', function ($row) {
                        return $row->quantity_for_tc ?? '5.000';
                    })

                    ->addColumn('available', function ($row) {
                        return $row->rem_qty ?? '0.00';
                    })

                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }




    // ---------ICS Stock Inventroy start-------//
    public function BatchStock()
    {
        $user_id = Auth::guard('misadmin')->user()->id;
      //  dd($user_id);
        return view("admin.stock_inventory.ics.batchstock");
    }

    public function ICSSearch(Request $request)
    {
        try {
            if ($request->ajax()) {



                $user_id = Auth::guard('misadmin')->user()->id;

                $query = AtOpTransactionVsTransactionProduct::query();

                $finalData = $query->where('created_by', $user_id)->limit(10)->get();
                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('tc_no', function ($row) {
                        return  $row->transaction_certificate_no ?? 'N/A';
                    })

                    ->addColumn('product_name', function ($row) {
                        return ($row->product_code ?? '1904103015');
                    })
                    ->addColumn('organic_status', function ($row) {
                        return getRefOrganicStatusMasterByID($row->organic_status ?? 'N/A');
                    })
                    ->addColumn('tc_quantity', function ($row) {
                        return $row->quantity_for_tc ?? '5.000';
                    })

                    ->addColumn('available', function ($row) {
                        return $row->rem_qty ?? '0.00';
                    })

                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }



    public function LotStock()
    {

        $user_id = Auth::guard('misadmin')->user()->id;

       // dd($user_id );

        return view("admin.stock_inventory.ics.lotstock");
    }

    public function LotStockSearch(Request $request)
    {
        try {
            if ($request->ajax()) {



                $user_id = Auth::guard('misadmin')->user()->id;

                $query = RefProcuremenEntry::query();

                $finalData = $query->where('created_by', $user_id)->limit(10)->get();
                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('lot_id', function ($row) {
                        return  $row->lot_number ?? 'N/A';
                    })

                    ->addColumn('product_code', function ($row) {
                        return ($row->ref_product_id ?? '1904103015');
                    })
                    ->addColumn('product_name', function ($row) {
                        return ($row->ref_product_id ?? 'N/A');
                    })
                    ->addColumn('quantity', function ($row) {
                        return $row->quantity_source ?? '5.000';
                    })

                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }




    // ---------ICS Stock Inventroy end-------//



    // ---------IP Stock Inventroy start-------//
    public function IpbatchStock()
    {
        return view("admin.stock_inventory.ip.batchstock");
    }
    public function IPSearch(Request $request)
    {
        try {
            if ($request->ajax()) {



                $user_id = Auth::guard('misadmin')->user()->id;

                $query = AtOpTransactionVsTransactionProduct::query();

                $finalData = $query->where('created_by', $user_id)->limit(10)->get();
                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('tc_no', function ($row) {
                        return  $row->transaction_certificate_no ?? 'N/A';
                    })

                    ->addColumn('product_name', function ($row) {
                        return ($row->product_code ?? '1904103015');
                    })
                    ->addColumn('organic_status', function ($row) {
                        return getRefOrganicStatusMasterByID($row->organic_status ?? 'N/A');
                    })
                    ->addColumn('tc_quantity', function ($row) {
                        return $row->quantity_for_tc ?? '5.000';
                    })

                    ->addColumn('available', function ($row) {
                        return $row->rem_qty ?? '0.00';
                    })

                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }


    public function IplotStock()
    {
        return view("admin.stock_inventory.ip.lotstock");
    }

    public function IPLotStockSearch(Request $request)
    {
        try {
            if ($request->ajax()) {



                $user_id = Auth::guard('misadmin')->user()->id;

                $query = RefProcuremenEntry::query();

                $finalData = $query->where('created_by', $user_id)->limit(10)->get();
                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('lot_id', function ($row) {
                        return  $row->lot_number ?? 'N/A';
                    })

                    ->addColumn('product_code', function ($row) {
                        return ($row->ref_product_id ?? '1904103015');
                    })
                    ->addColumn('product_name', function ($row) {
                        return ($row->ref_product_id ?? 'N/A');
                    })
                    ->addColumn('quantity', function ($row) {
                        return $row->quantity_source ?? '5.000';
                    })

                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }


    // ---------IP Stock Inventroy end-------//




    // ---------WH Stock Inventroy start-------//

    public function WHlotStock()
    {
        return view("admin.stock_inventory.wh.lotstock");
    }


    public function WHlotStockSearch(Request $request)
    {
        try {
            if ($request->ajax()) {


                $user_id = Auth::guard('misadmin')->user()->id;

                $query = AtBatchCreation::query()
                    ->leftJoin('at_batch_details', 'at_batch_creation.id', '=', 'at_batch_details.batch_id')
                    ->where('at_batch_creation.created_by', $user_id)  // Filter by created_by
                    ->limit(10);  // Limit to 10 results

                $finalData = $query->get();

                $finalData = $query->select([
                    'at_batch_creation.*',
                    'at_batch_details.total_quantity',
                    'at_batch_details.product_name',
                    'at_batch_details.total_quantity',
                    'at_batch_details.available_quantity',


                ])->limit(8)->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()
                    ->addColumn('batch_id', function ($row) {
                        return time() . $row->id ?? 'N/A';
                    })
                    ->addColumn('product_name', function ($row) {
                        return $row->product_name ?? 'N/A';
                    })
                    ->addColumn('organic_status', function ($row) {
                        return getRefOrganicStatusMasterByID($row->organic_status ?? 'N/A');
                    })
                    ->addColumn('quantity', function ($row) {
                        return $row->quantity ?? 'N/A';
                    })
                    ->addColumn('total_quantity', function ($row) {
                        return $row->total_quantity ?? 'N/A';
                    })
                    ->addColumn('available', function ($row) {
                        return $row->available_quantity ?? '0.00';
                    })

                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    // ---------WH Stock Inventroy end-------//




    // ---------trader Stock Inventroy start-------//
    public function TrbatchStock()
    {

        $user_id = Auth::guard('misadmin')->user()->id;
       // dd($user_id);
        return view("admin.stock_inventory.trader.batchstock");
    }

    public function TrbatchStockSearch(Request $request)
    {
        try {
            if ($request->ajax()) {



                $user_id = Auth::guard('misadmin')->user()->id;

                $query = AtBatchCreation::query()
                    ->leftJoin('at_batch_details', 'at_batch_creation.id', '=', 'at_batch_details.batch_id')
                    ->where('at_batch_creation.created_by', $user_id)
                    ->limit(10);

                $finalData = $query->get();




                $finalData = $query->select([
                    'at_batch_creation.*',
                    'at_batch_details.total_quantity',
                    'at_batch_details.product_name',
                    'at_batch_details.total_quantity',
                    'at_batch_details.available_quantity',


                ])->limit(8)->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()
                    ->addColumn('batch_id', function ($row) {
                        return time() . $row->id ?? 'N/A';
                    })
                    ->addColumn('product_name', function ($row) {
                        return $row->product_name ?? 'N/A';
                    })
                    ->addColumn('organic_status', function ($row) {
                        return getRefOrganicStatusMasterByID($row->organic_status ?? 'N/A');
                    })
                    ->addColumn('quantity', function ($row) {
                        return $row->quantity ?? 'N/A';
                    })
                    ->addColumn('total_quantity', function ($row) {
                        return $row->total_quantity ?? 'N/A';
                    })
                    ->addColumn('available', function ($row) {
                        return $row->available_quantity ?? '0.00';
                    })

                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }


    public function TrTcStock()
    {
        return view("admin.stock_inventory.trader.tcstock");
    }
    public function TrTcStockSearch(Request $request)
    {
        try {
            if ($request->ajax()) {



                $user_id = Auth::guard('misadmin')->user()->id;

                $query = AtOpTransactionVsTransactionProduct::query();

                $finalData = $query->where('created_by', $user_id)->limit(10)->get();
                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('tc_no', function ($row) {
                        return  $row->transaction_certificate_no ?? 'N/A';
                    })

                    ->addColumn('product_name', function ($row) {
                        return ($row->product_code ?? '1904103015');
                    })
                    ->addColumn('organic_status', function ($row) {
                        return getRefOrganicStatusMasterByID($row->organic_status ?? 'N/A');
                    })
                    ->addColumn('tc_quantity', function ($row) {
                        return $row->quantity_for_tc ?? '5.000';
                    })

                    ->addColumn('available', function ($row) {
                        return $row->rem_qty ?? '0.00';
                    })

                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    // ---------trader Stock Inventroy end-------//




    // ---------processor Stock Inventroy start-------//
    public function processorbatchStock()
    {

        $user_id = Auth::guard('misadmin')->user()->id;
       // dd($user_id);

        return view("admin.stock_inventory.processor.batchstock");
    }

    public function processorbatchStockSearch(Request $request)
    {
        try {
            if ($request->ajax()) {



                $user_id = Auth::guard('misadmin')->user()->id;

                $query = AtBatchCreation::query()
                    ->leftJoin('at_batch_details', 'at_batch_creation.id', '=', 'at_batch_details.batch_id')
                    ->where('at_batch_creation.created_by', $user_id)
                    ->limit(10);

                $finalData = $query->get();




                $finalData = $query->select([
                    'at_batch_creation.*',
                    'at_batch_details.total_quantity',
                    'at_batch_details.product_name',
                    'at_batch_details.total_quantity',
                    'at_batch_details.available_quantity',


                ])->limit(8)->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()
                    ->addColumn('batch_id', function ($row) {
                        return time() . $row->id ?? 'N/A';
                    })
                    ->addColumn('product_name', function ($row) {
                        return $row->product_name ?? 'N/A';
                    })
                    ->addColumn('organic_status', function ($row) {
                        return getRefOrganicStatusMasterByID($row->organic_status ?? 'N/A');
                    })
                    ->addColumn('quantity', function ($row) {
                        return $row->quantity ?? 'N/A';
                    })
                    ->addColumn('total_quantity', function ($row) {
                        return $row->total_quantity ?? 'N/A';
                    })
                    ->addColumn('available', function ($row) {
                        return $row->available_quantity ?? '0.00';
                    })

                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }






    public function processorTcStock()
    {

        return view("admin.stock_inventory.processor.tcstock");
    }

    public function processorTcStockSearch(Request $request)
    {
        try {

            if ($request->ajax()) {


                $user_id = Auth::guard('misadmin')->user()->id;

                $query = AtOpTransactionVsTransactionProduct::query();

                $finalData = $query->where('created_by', $user_id)->limit(10)->get();


                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('tc_no', function ($row) {
                        return  $row->transaction_certificate_no ?? 'N/A';
                    })

                    ->addColumn('product_name', function ($row) {
                        return ($row->product_code ?? '1904103015');
                    })
                    ->addColumn('organic_status', function ($row) {
                        return getRefOrganicStatusMasterByID($row->organic_status ?? 'N/A');
                    })
                    ->addColumn('tc_quantity', function ($row) {
                        return $row->quantity_for_tc ?? '5.000';
                    })

                    ->addColumn('available', function ($row) {
                        return $row->rem_qty ?? '0.00';
                    })

                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    // ---------processor Stock Inventroy end-------//


}

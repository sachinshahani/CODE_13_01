<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\RefState;
use App\Models\RefDistrict;
use App\Models\RefRegion;
use App\Models\RefVillage;
use App\Models\RoleUser;
use App\Models\UserInspector;
use App\Models\CBStatewiseRestriction;
use App\Models\AtFarmerRegDetail;
use App\Models\AtFarmDetails;
use App\Models\RefProduct;
use App\Models\CertificateStandardDetail;
use App\Models\AtOpTransactionVsTransactionProduct;
use App\Models\AtAccrediationCertificationBody;
use App\Models\Role;
use App\Models\MandatorRegister;
use App\Models\Announcement;
use App\Models\RefEligibleCategory;
use App\Models\AtOpNocDetails;
use Illuminate\Support\Facades\Log;
use App\Models\RefLaboratory;
use App\Models\RefAssingLabProduct;
use App\Models\AtSlider;
use Illuminate\Http\Request;
use App\Models\RefModule;
use App\Models\CBProductWiseRestriction;
use App\Models\AtCBRegistrationPermission;
use App\Models\RefSubmodule;
use App\Models\CBCategoryWiseRestriction;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use DataTables;
use Illuminate\Support\Facades\Mail;
use App\Mail\AccountStatusUpdateMail;
use Illuminate\Support\Facades\Queue;
use App\Jobs\SendEmailJob;
use Symfony\Component\Mime\Part\TextPart;
use App\Mail\RecordDeletedMail;
use RealRashid\SweetAlert\Facades\Alert;
use \Cache;

class DashboardController extends Controller
{


    //


    // public function twoStepAuth()
    // {
    //     $sliders = AtSlider::where('status', 1)->orderBy('created_at', 'desc')->get();

    //     return view('auth.twoStepAuthentication', compact('sliders'));
    // }

    public function dashboard(Request $request)
    {
        //$emp_id = auth()->user(); print_r($emp_id); die;
        $id_login_user = auth()->user()->id; // Get the ID of the logged-in user
        //print_r($id_login_user);
        // die;
        $c1 = date('Y-m-01');
        $c2 = date('Y-m-t');
        
        $useroperator = auth()->user()->ref_operator_type_id; 
       $announcement_list = Announcement::where('ref_operator_type_id', $useroperator)
                        ->orderBy('created_at', 'desc')
                        ->get();

                        //dd($announcement_list);

        $l1 = date('Y-m-01', strtotime("-1 month"));
        $l2 = date('Y-m-t', strtotime("-1 month"));

        $ll1 = date('Y-m-01', strtotime("-2 month"));
        $ll2 = date('Y-m-t', strtotime("-2 month"));

        $cur_month_users = User::select('ref_operator_type_id', DB::raw('COUNT(id) as users'))->groupBy('ref_operator_type_id')
            ->where('user_type', '=', 1)
            ->where('status', 1)
            ->where('ref_operator_type_id', '!=', 7)
            ->where('ref_operator_type_id', '!=', 1)
            ->whereBetween('created_at', [$c1, $c2])
            ->get();

        $last_month_users = User::select('ref_operator_type_id', DB::raw('COUNT(id) as users'))->groupBy('ref_operator_type_id')
            ->where('user_type', '=', 1)
            ->where('status', 1)
            ->where('ref_operator_type_id', '!=', 7)
            ->where('ref_operator_type_id', '!=', 1)
            ->whereBetween('created_at', [$l1, $l2])
            ->get();
        ////komal 1st chart
        $result = DB::table('at_user as u')
            ->join('at_op_certificate_standard_details as csd', 'csd.at_user_id', '=', 'u.id')
            ->whereIn('u.ref_operator_type_id', [2, 3, 4, 5, 6])
            ->whereRaw('csd.validity_end_date > NOW()')
            ->whereRaw('EXTRACT(YEAR FROM u.created_at) = EXTRACT(YEAR FROM CURRENT_DATE)')
            ->where('u.created_by', $id_login_user) // data of current cb
            ->select(
                DB::raw("TO_CHAR(u.created_at, 'YYYY-MM') AS year_month"),
                DB::raw("TO_CHAR(u.created_at, 'Month') AS month_name"),
                'u.ref_operator_type_id',
                DB::raw('COUNT(u.id) AS users')
            )
            ->groupBy(
                DB::raw("TO_CHAR(u.created_at, 'YYYY-MM')"),
                DB::raw("TO_CHAR(u.created_at, 'Month')"),
                'u.ref_operator_type_id'
            )
            ->orderBy(DB::raw("TO_CHAR(u.created_at, 'YYYY-MM')"))
            ->get();
        //dd($result);
        $formattedData = [];
        foreach ($result as $item) {
            $month = trim($item->month_name);
            $refOperatorTypeId = $item->ref_operator_type_id;
            $users = $item->users;

            if (!isset($formattedData[$month])) {
                $formattedData[$month] = [
                    'Month' => $month,
                    'Grower Group' => 0,
                    'Individual Producer' => 0,
                    'Wild Harvestor' => 0,
                    'Trader' => 0,
                    'Processor' => 0,
                    'Total Operators' => 0,
                ];
            }
            // Map users to the correct type
            switch ($refOperatorTypeId) {
                case 2:
                    $formattedData[$month]['Grower Group'] += $users;
                    break;
                case 3:
                    $formattedData[$month]['Individual Producer'] += $users;
                    break;
                case 4:
                    $formattedData[$month]['Wild Harvestor'] += $users;
                    break;
                case 5:
                    $formattedData[$month]['Trader'] += $users;
                    break;
                case 6:
                    $formattedData[$month]['Processor'] += $users;
                    break;
            }
            // Update total
            $formattedData[$month]['Total Operators'] += $users;
        }
        // Convert to Google Chart format
        $chartData = [
            ['Month', 'Grower Group', 'Individual Producer', 'Wild Harvestor', 'Trader', 'Processor', 'Total Operators'],
        ];
        foreach ($formattedData as $data) {
            $chartData[] = array_values($data);
        }
        //pr($chartData); die; 
        ////komal
        $llast_month_users = User::select('ref_operator_type_id', DB::raw('COUNT(id) as users'))->groupBy('ref_operator_type_id')
            ->where('user_type', '=', 1)
            ->where('status', 1)
            ->where('ref_operator_type_id', '!=', 7)
            ->where('ref_operator_type_id', '!=', 1)
            ->whereBetween('created_at', [$ll1, $ll2])
            ->get();
        //dd($llast_month_users);
        $icsWithFarmerCount = User::select('at_user.first_name as first_name', 'at_ics_inspector_details.id', DB::raw('COUNT(at_farmer_reg_details.id) as users'))
            ->join('at_ics_inspector_details', 'at_ics_inspector_details.at_user_id', 'at_user.id')
            ->join('at_farmer_reg_details', 'at_farmer_reg_details.at_ics_inspector_id', 'at_ics_inspector_details.id')
            ->where('at_user.ref_operator_type_id', 2)
            ->where('at_user.created_by', $id_login_user) //this is for showing data of current cb
            ->groupBy('at_user.id', 'at_ics_inspector_details.id')
            ->get();
        // $icsWithFarmerCount = json_encode($icsWithFarmerCounts);

        $operatorCountByState = User::select('ref_state_id', DB::raw('COUNT(id) as users'))
            ->groupBy('ref_state_id')
            ->where('user_type', '=', 1)
            ->where('ref_operator_type_id', '!=', 7)
            ->where('ref_operator_type_id', '!=', 1)
            ->where('id', $id_login_user)
            ->where('status', 1)
            ->get()->toArray();
        $users = User::all();
        $ics = $users->where('ref_operator_type_id', 2)->count();
        // $ics = RoleUser::with('users')->where('role_id',2)->get()->count();
        $individual = $users->where('ref_operator_type_id', 3)->count();
        $harvester = $users->where('ref_operator_type_id', 4)->count();
        $trader  = $users->where('ref_operator_type_id', 5)->count();
        $processor  = $users->where('ref_operator_type_id', 6)->count();
        $mandators  = MandatorRegister::count();
        $inspDetail  = UserInspector::where('at_user_id', Auth::guard('misadmin')->user()->id)->get();
        $insp = $inspDetail->count();
        $inspIds = array();
        if (!empty($inspDetail)) {
            foreach ($inspDetail as $key => $value) {
                $inspIds[] = $value->id;
                # code...
            }
        }
        // Transaction Certificate
        $tcData = AtOpTransactionVsTransactionProduct::where('tc_application_no', 'LIKE', 'TC%')->orderBy('created_at', 'asc')->get();
        // $tcData1 = AtOpTransactionVsTransactionProduct::selectRaw('tc_date as year, tc_date as month, COUNT(*) as tc')
        //     ->groupBy('year', 'month')
        //     ->orderBy('year')
        //     ->orderBy('month')
        //     ->get();
        ////kr  Transaction Certificate chart 4
        $tcData1 = AtOpTransactionVsTransactionProduct::selectRaw('
        EXTRACT(YEAR FROM created_at) AS year,
        EXTRACT(MONTH FROM created_at) AS month,
        CONCAT(TO_CHAR(created_at, \'FMMonth\'), \' \', EXTRACT(YEAR FROM created_at)) AS month_year, 
        COUNT(*) AS   count  
        ')
            ->whereRaw('EXTRACT(YEAR FROM created_at) = EXTRACT(YEAR FROM CURRENT_DATE)')
            ->where('created_by', $id_login_user)
            ->groupBy('year', 'month', 'month_year')
            ->orderBy('year')
            ->orderBy('month')
            ->get();
        //dd($tcData1);die;
        ///kr  Transaction Certificate
        //Scope certificate
        $farmers =  AtFarmerRegDetail::whereIn('at_ics_inspector_id', $inspIds)->count();

        $scList = CertificateStandardDetail::whereHas('getuser', function ($q) {
            return $q->where('created_by', Auth::id());
        })
            ->where('status', 1)->where('scope_certificate_no', '!=', '')
            ->get();

        if ($request->sc_certificate != '') {
            $scList = CertificateStandardDetail::whereHas('getuser', function ($q) {
                return $q->where('created_by', Auth::id());
            })
                ->where('status', $request->sc_certificate)->where('is_renewed', '!=', 1)
                ->get();
        }



        $ptcData = AtOpTransactionVsTransactionProduct::where('tc_application_no', 'LIKE', 'PTC%')->orderBy('created_at', 'asc')->get();
        $product = RefProduct::offset(10)->limit(10)->get();
        $nocList = AtOpNocDetails::where('noc_status', '!=', 'Pending')->get();
        $ipAddress = $_SERVER['REMOTE_ADDR'];
        //dd($tcData);
        return view('admin.dashboard', compact('ics', 'individual', 'harvester', 'trader', 'processor', 'mandators', 'insp', 'farmers', 'users', 'cur_month_users', 'last_month_users', 'llast_month_users', 'icsWithFarmerCount', 'operatorCountByState', 'scList', 'tcData', 'ptcData', 'product', 'nocList', 'ipAddress', 'tcData1', 'chartData', 'announcement_list'));
    }
    public function Cbdashboard(Request $request)
    {

        return view('admin.cb_dashboard');
    }
    public function superAdminDashboard()
    {
        // get ics list with farmer count
        
        $c1 = date('Y-m-01');
        $c2 = date('Y-m-t');

    //     $useroperator = auth()->user()->ref_operator_type_id;

    //    $announcement_list = Announcement::where('ref_operator_type_id', $useroperator)
    //                     ->orderBy('created_at', 'desc')
    //                     ->get();

        $l1 = date('Y-m-01', strtotime("-1 month"));
        $l2 = date('Y-m-t', strtotime("-1 month"));

        $ll1 = date('Y-m-01', strtotime("-2 month"));
        $ll2 = date('Y-m-t', strtotime("-2 month"));

        $cur_month_users = User::select('ref_operator_type_id', DB::raw('COUNT(id) as users'))->groupBy('ref_operator_type_id')
            ->where('user_type', '=', 1)
            ->where('status', 1)
            ->where('ref_operator_type_id', '!=', 7)
            ->where('ref_operator_type_id', '!=', 1)
            ->whereBetween('created_at', [$c1, $c2])
            ->get();

        $last_month_users = User::select('ref_operator_type_id', DB::raw('COUNT(id) as users'))->groupBy('ref_operator_type_id')
            ->where('user_type', '=', 1)
            ->where('status', 1)
            ->where('ref_operator_type_id', '!=', 7)
            ->where('ref_operator_type_id', '!=', 1)
            ->whereBetween('created_at', [$l1, $l2])
            ->get();

        //  foreach($last_month_users as $ls){
        //     echo $ls->ref_operator_type_id;
        //  }
        // dd();
        //  for($i=0;$i<5;$i++){
        //     if($last_month_users[$i]->ref_operator_type_id == $j++){
        //         echo "yes".$last_month_users[$i]->ref_operator_type_id;
        //     }else{
        //         echo "no".0;

        //     }
        //  }



        $llast_month_users = User::select('ref_operator_type_id', DB::raw('COUNT(id) as users'))->groupBy('ref_operator_type_id')
            ->where('user_type', '=', 1)
            ->where('status', 1)
            ->where('ref_operator_type_id', '!=', 7)
            ->where('ref_operator_type_id', '!=', 1)
            ->whereBetween('created_at', [$ll1, $ll2])
            ->get();



        // get operators with thier count
        // no of operator registered
        // total TC Issued

        $icsWithFarmerCount = User::select('at_user.first_name as first_name', 'at_ics_inspector_details.id', DB::raw('COUNT(at_farmer_reg_details.id) as users'))
            ->join('at_ics_inspector_details', 'at_ics_inspector_details.at_user_id', 'at_user.id')
            ->join('at_farmer_reg_details', 'at_farmer_reg_details.at_ics_inspector_id', 'at_ics_inspector_details.id')
            ->where('at_user.ref_operator_type_id', 2)
            ->groupBy('at_user.id', 'at_ics_inspector_details.id')
            ->get();
        // $icsWithFarmerCount = json_encode($icsWithFarmerCounts);

        $operatorCountByState = User::select('ref_state_id', DB::raw('COUNT(id) as users'))
            ->groupBy('ref_state_id')
            ->where('user_type', '=', 1)
            ->where('ref_operator_type_id', '!=', 7)
            ->where('ref_operator_type_id', '!=', 1)
            ->where('status', 1)
            ->get()->toArray();



        $users = User::all();
        $ics = $users->where('ref_operator_type_id', 2)->count();
        // $ics = RoleUser::with('users')->where('role_id',2)->get()->count();
        $individual = $users->where('ref_operator_type_id', 3)->count();
        $harvester = $users->where('ref_operator_type_id', 4)->count();
        $trader  = $users->where('ref_operator_type_id', 5)->count();
        $processor  = $users->where('ref_operator_type_id', 6)->count();
        $mandators  = MandatorRegister::count();

        $inspDetail  = UserInspector::where('at_user_id', Auth::guard('misadmin')->user()->id)->get();
        $insp = $inspDetail->count();
        $inspIds = array();
        if (!empty($inspDetail)) {
            foreach ($inspDetail as $key => $value) {
                $inspIds[] = $value->id;
                # code...
            }
        }
        $farmers =  AtFarmerRegDetail::whereIn('at_ics_inspector_id', $inspIds)->count();



        $dataByYear = CertificateStandardDetail::selectRaw('
        EXTRACT(YEAR FROM created_at) as year,
        COUNT(CASE WHEN status = 0 THEN 1 ELSE NULL END) as approvedCount,
        COUNT(CASE WHEN status = 1 THEN 1 ELSE NULL END) as pendingCount,
        COUNT(*) as totalCount
        ')->groupBy('year')->get();

        // dd($countData);

        return view('admin.superadmin_dashboard', compact('ics', 'individual', 'harvester', 'trader', 'processor', 'mandators', 'insp', 'farmers', 'users', 'cur_month_users', 'last_month_users', 'llast_month_users', 'icsWithFarmerCount', 'dataByYear',));
    }


    public function reports()
    {
        $id = request('uid');

        // dd($id);
        return view('admin.reports', compact('id'));
    }
    public function ReportsSearch(Request $request)
    {
        try {
            if ($request->ajax()) {

                $state_id = $request->uid;

                //dd($state_id );
                $query = USER::query();
                $finalData = $query->where('ref_operator_type_id', 1)->where('ref_state_id', $state_id)->get();

                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()
                    ->addColumn('cb_name', function ($row) {
                        return $row->first_name ?? '';
                    })
                    ->addColumn('address', function ($row) {
                        return $row->address ?? '';
                    })
                    ->addColumn('state', function ($row) {
                        return getStateNameById($row->ref_state_id ?? '');
                    })
                    ->addColumn('district', function ($row) {
                        return get_district_name_by_id($row->ref_district_id ?? '');
                    })
                    ->addColumn('reg_date', function ($row) {
                        return dateFormat($row->created_at ?? '');
                    })
                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }
            return view('admin.reports', compact('uid'));
            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }


    public function profile()
    {

        $userId = Auth::guard('misadmin')->user()->id;
        // dd($userId);
        // dd(Auth::guard('misadmin')->user());
        $empcount = User::where('ref_operator_type_id', 9)->where('created_by',   $userId)->count();
        $inspectorcount = UserInspector::where('created_by', $userId)->count();
        $data = AtAccrediationCertificationBody::where('at_user_id', $userId)->first();

        $user = Auth::guard('misadmin')->user();

        $role = Role::where('id', '>', 7)->get();

        $userrole = $user->roles->pluck("title")->first();



        $user = Auth::guard('misadmin')->user();

        $cbId = User::where('id', $user->id)
            ->select('created_by')
            ->first();
        $createdById = $cbId->created_by;

        $name = $user->first_name;
        if (isset($user->roles[0]) && $user->roles[0]->id == '9') {

            $empdata = $user;
            $cbname = User::where('id',   $cbId->created_by)->select('first_name')->first();
            $accno = AtAccrediationCertificationBody::where('at_user_id', $createdById)->first();
        } else {
            $empdata = null;
            $cbname = null;
            $accno = null;
        }

        return view('admin.profile', compact('data', 'empcount', 'inspectorcount', 'empdata', 'cbname', 'accno', 'userrole'));
    }


    public function updateProfile(Request $request)
    {
        //dd($request->all());

        try {
            $this->validate($request, [
                //'name' => 'required',
                //'contact_number' => 'required',	
                //'email' => 'required|email|unique:users,email,'.$id,
                // 'date_of_joining' => 'required',
                // 'skills' => 'required:array',
                // 'designation' => 'required',
                'contact_number' => 'required',
                'state' => 'required',
                'district' => 'required',
                // 'zipcode' => 'required',
            ]);


            $updateData = array(

                'contact_number' => $request->contact_number,
                //'email' => $request->email,
                'date_of_joining' => date('Y-m-d', strtotime($request->date_of_joining)),
                'skills' => implode(',', $request->skills),
                'designation' => $request->designation,
                'website_url' => $request->website_url,
                'state' => $request->state,
                'district' => $request->district,
                'zipcode' => $request->zipcode,
                'about_org' => $request->about_org
            );

            $user = User::find(Auth::guard('misadmin')->user());
            $user->update($updateData);

            Alert::success('Success', 'profile updated successfully');
            return redirect()->route('admin.profile');
        } catch (Exception $e) {
            Alert::error('Error', $e->getMessage());
            \Log::error($e->getMessage());
            abort(404);
        } catch (\Illuminate\Database\QueryException $exception) {
            Alert::error('Error', $exception->getMessage());
            \Log::error($exception->getMessage());
            Alert::error('error', "Query Exception");
            return redirect()->back();
        }
    }
    public function userprofile()
    {
        if (Auth::guard('misadmin')->user()->roles[0]->id == 2) {
            $userdetails = User::find(Auth::guard('misadmin')->user()->id);


            $states = RefState::orderBy('state_name', 'ASC')->get();
            $districts = RefDistrict::where('ref_state_code', $userdetails->state)->orderBy('district_name', 'ASC')->get();

            $regions = RefRegion::where('state_code', $userdetails->state)->orderBy('region_name', 'ASC')->get();
            $villages = RefVillage::where('ref_district_code', $userdetails->district)->orderBy('village_name', 'ASC')->get();


            return view('admin.icsprofile', compact('states', 'districts', 'regions', 'villages', 'userdetails'));
        } else if (Auth::guard('misadmin')->user()->roles[0]->id == 3) {
            return view('admin.profile');
        } else if (Auth::guard('misadmin')->user()->roles[0]->id == 4) {
            return view('admin.profile');
        } else {
            return view('admin.profile');
        }
    }

    public function changePassword()
    {
        return view('admin.change-password');
    }

    public function changePasswordPost(Request $request)
    {
        $request->validate([
            'current_password' => 'required',
            'new_password' => 'required|confirmed',
        ]);
        try {
            if ($request->current_password != $request->new_password) {
                if ($request->new_password == $request->new_password_confirmation) {
                    $user = User::find(Auth::guard('misadmin')->user()->id);
                    $user->password = $request->new_password;
                    $user->save();

                    return redirect()->back()->with('success', __('message.changed_success'));
                } else {
                    return redirect()->back()->with('error', __('message.not_match'));
                }
            } else {
                return redirect()->back()->with('error', __('message.both_password_same'));
            }
        } catch (Exception $e) {
            Log::error($e);

            return redirect()->back()->with('error', 'Invalid Credentials.');
        }
    }


    public function chnageFirstPassword()
    {
        $sliders = AtSlider::where('status', 1)->orderBy('created_at', 'desc')->get();
        if (Auth::guard('misadmin')->user()->first_change_password == 1) {
            return redirect()->route('superadmin.dashboard');
        } else {
            return view('admin.dashboard_fisrt_time', compact('sliders'));
        }
    }

    public function updateChnageFirstPassword(Request $request)
    {

        $this->validate(
            $request,
            [
                'passwords' => 'required',
                'confirm_password' => 'required|same:passwords',

            ]
        );
        try {

            if ($request->passwords == $request->confirm_password) {

                $user = User::find(Auth::guard('misadmin')->user()->id);
                $user->password = $request->confirm_password;
                $user->first_change_password = 1;
                $user->save();

                return redirect()->route('superadmin.dashboard')->with('success', __('message.changed_success'));
                //return redirect()->back()->with('success', __('message.changed_success'));

            } else {
                return redirect()->back()->with('error', __('message.not_match'));
            }
        } catch (Exception $e) {
            Log::error($e);

            return redirect()->back()->with('error', 'Invalid Credentials.');
        }
    }


    public function updateChnageFirstPasswordSkip(Request $request)
    {
        try {
            $user = User::find(Auth::guard('misadmin')->user()->id);
            $user->first_change_password = 1;
            $user->save();
            return response()->json(['data' => 'success', 'success' => 'Thank you for select Skip option!!']);
            //return redirect()->route('superadmin.dashboard')->with('success', 'Thank you for select Skip option!!');
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['data' => 'error', 'error' => 'Invalid Credentials.']);
            //return redirect()->back()->with('error', 'Invalid Credentials.');
        }
    }


    public function dashboardajaxcall(Request $request)
    {
        //     $userId = Auth::id();

        //     $userIds = User::where('created_by', $userId)
        //         ->where('status', 2)
        //         ->where('ref_operator_type_id', 2)
        //         ->whereNull('deleted_at')
        //         ->pluck('id')
        //         ->toArray();

        //     $farmerIds = AtFarmerRegDetail::whereIn('at_user_id', $userIds)
        //         ->pluck('id')
        //         ->toArray();

        //     $farmscount = AtFarmDetails::whereIn('at_farmer_reg_details_id', $farmerIds)
        //         ->where('area_in_ha', '>', 0)
        //         ->count(DB::raw('CAST(area_in_ha AS NUMERIC(18,3))'));

        //    $Land = AtFarmDetails::whereIn('at_farmer_reg_details_id', $farmerIds)
        //         ->where('total_area', '>=', 0)
        //         ->sum(DB::raw('CAST(total_area AS NUMERIC(16,2))'));

        $userId = Auth::id();

        // Fetch userIds and farmerIds in one query using a relationship, if available
        $userIds = User::where('created_by', $userId)
            ->where('status', 2)
            ->where('ref_operator_type_id', 2)
            ->whereNull('deleted_at')
            ->pluck('id');

        // Fetch farms count and land total in a single query by combining aggregations
        $farmsData = AtFarmDetails::whereIn('at_farmer_reg_details_id', function ($query) use ($userIds) {
            $query->select('id')
                ->from('at_farmer_reg_details')
                ->whereIn('at_user_id', $userIds);
        })
            ->where('area_in_ha', '>', 0)
            ->selectRaw('COUNT(*) as farmscount, SUM(CAST(total_area AS NUMERIC(16,2))) as Land')
            ->first();

        $farmscount = $farmsData->farmscount;
        $Land = $farmsData->Land;



        //    $count = 0; User::where('created_by', 31)->where('status', '2')->whereNotNull('ref_operator_type_id')->chunk(1000, function ($items) use (&$count) { $count += count($items); }); dd($count) ;

        $data = [

            'user_date' => date('d-m-Y'),
            'user' => User::where('created_by', $userId)
                ->where('is_deleted', false)
                ->whereHas('certificateStandardDetails', function ($query) {
                    $query->where('validity_end_date', '>', Carbon::now()->subDays(90));
                })
                ->count(),


            'ics' => User::where('created_by', $userId)
                ->where('is_deleted', false)
                ->where('ref_operator_type_id', 2)
                ->whereHas('certificateStandardDetails', function ($query) {
                    $query->where('validity_end_date', '>', Carbon::now()->subDays(90));
                })
                ->count(),


            'individual' => User::where('created_by', $userId)
                ->where('is_deleted', false)
                ->where('ref_operator_type_id', 3)
                ->whereHas('certificateStandardDetails', function ($query) {
                    $query->where('validity_end_date', '>', Carbon::now()->subDays(90));
                })
                ->count(),
            'harvester' => User::where('created_by', $userId)
                ->where('is_deleted', false)
                ->where('ref_operator_type_id', 4)
                ->whereHas('certificateStandardDetails', function ($query) {
                    $query->where('validity_end_date', '>', Carbon::now()->subDays(90));
                })
                ->count(),
            'trader' => User::where('created_by', $userId)
                ->where('is_deleted', false)
                ->where('ref_operator_type_id', 5)
                ->whereHas('certificateStandardDetails', function ($query) {
                    $query->where('validity_end_date', '>', Carbon::now()->subDays(90));
                })
                ->count(),
            'processor' => User::where('created_by', $userId)
                ->where('is_deleted', false)
                ->where('ref_operator_type_id', 6)
                ->whereHas('certificateStandardDetails', function ($query) {
                    $query->where('validity_end_date', '>', Carbon::now()->subDays(90));
                })
                ->count(),

            // 'farmer' => AtFarmerRegDetail::where('at_user_id',  $userId)->count(),
            'farmer' => AtFarmerRegDetail::whereIn('at_user_id', $userIds)->count(),
            'farm' => $farmscount,
            'land' => $Land,
            // // 'farm' => AtFarmDetails::where('total_area', '>=', 0)->count(),
            'product' => RefProduct::count(),
            //'product' => AtOpTransactionVsTransactionProduct::whereIn('created_by', $userIds)->count(),
            // 'mandators' => MandatorRegister::count(),
        ];
        //dd($data);
        return response()->json($data);
    }



    public function addLab()
    {
        return view('admin.lab.add');
    }

    public function registeredLab_old()
    {
        return view('admin.lab.registeredLab');
    }


    public function registeredLab(Request $request)
    {

        if ($request->ajax()) {
            $inspIds = RefLaboratory::orderBy('id', 'desc')->get();

            // dd($inspIds);
            return Datatables::of($inspIds)
                ->addIndexColumn()

                ->addColumn('lab_name', function ($row) {
                    return $row->lab_name;
                })
                ->addColumn('lab_email', function ($row) {
                    return $row->lab_email ?? '';
                })->addColumn('lab_tel', function ($row) {
                    return $row->lab_tel ?? '';
                })->addColumn('status', function ($row) {

                    return "active";
                })->addColumn('action', function ($row) {

                    $actionBtn = '<a href=' . route('superadmin.viewLab', $row->id) . '> View</a>';

                    $Product = '<a href=' . route('superadmin.assingProduct', $row->id) . '>Assign Product</a>';

                    return $actionBtn . ' | ' . $Product;
                })
                ->rawColumns(['action'])
                ->make(true);
        }

        return view('admin.lab.registeredLab');
    }


    public function lab_save(Request $request)
    {
        // dd($request->all());
        $userId = Auth::user()->id;
        $lab_logo = '';
        if ($request->hasFile('lab_logo')) {

            $name = $request->file('lab_logo')->getClientOriginalName();
            $isValid_Extention_Size = explode('.', $name);

            if (count($isValid_Extention_Size) <= 2) {

                if (in_array(strtolower($request->file('lab_logo')->getClientOriginalExtension()), ['jpg', 'jpeg', 'png', 'pdf'])) {
                    $documentRootPath = public_path() . '/news';
                    $lab_logo = '/public/news/' . time() . rand() . 'lab_logo.' . $request->file('lab_logo')->getClientOriginalExtension();
                    $request->file('lab_logo')->move($documentRootPath, $lab_logo);
                } else {
                    Alert::error('File Error', "Please upload valid File.");
                    return redirect()->back()->with('loader', true);
                }
            } else {

                Alert::error('File Error', "Please upload valid File.");
                return redirect()->back()->with('loader', true);
            }
        }

        $nabl_logo = '';
        if ($request->hasFile('nabl_logo')) {

            $name = $request->file('nabl_logo')->getClientOriginalName();
            $isValid_Extention_Size = explode('.', $name);
            //print_r(count($isValid_Extention_Size));die;
            if (count($isValid_Extention_Size) <= 2) {

                if (in_array(strtolower($request->file('nabl_logo')->getClientOriginalExtension()), ['jpg', 'jpeg', 'png', 'pdf'])) {
                    $documentRootPath = public_path() . '/news';
                    $nabl_logo = '/public/news/' . time() . rand() . 'nabl_logo.' . $request->file('nabl_logo')->getClientOriginalExtension();
                    $request->file('nabl_logo')->move($documentRootPath, $nabl_logo);
                } else {
                    Alert::error('File Error', "Please upload valid File.");
                    return redirect()->back()->with('loader', true);
                }
            } else {

                Alert::error('File Error', "Please upload valid File.");
                return redirect()->back()->with('loader', true);
            }
        }

        $nabl_certificate = '';
        if ($request->hasFile('nabl_certificate')) {

            $name = $request->file('nabl_certificate')->getClientOriginalName();
            $isValid_Extention_Size = explode('.', $name);

            if (count($isValid_Extention_Size) <= 2) {

                if (in_array(strtolower($request->file('nabl_certificate')->getClientOriginalExtension()), ['jpg', 'jpeg', 'png', 'pdf'])) {
                    $documentRootPath = public_path() . '/news';
                    $nabl_certificate = '/public/news/' . time() . rand() . 'nabl_certificate.' . $request->file('nabl_certificate')->getClientOriginalExtension();
                    $request->file('nabl_certificate')->move($documentRootPath, $nabl_certificate);
                } else {
                    Alert::error('File Error', "Please upload valid File.");
                    return redirect()->back()->with('loader', true);
                }
            } else {

                Alert::error('File Error', "Please upload valid File.");
                return redirect()->back()->with('loader', true);
            }
        }

        $data = [
            'lab_name' => $request->input('lab_name'),
            'lab_address' => $request->input('lab_address'),
            'ref_state_id' => $request->input('ref_state_id'),
            'ref_district_id' => $request->input('district'),
            'print_header' => $request->input('print_header'),
            'certificate_no' => $request->input('certificate_no'),
            'start_date' => $request->input('start_date'),
            'end_date' => $request->input('end_date'),
            'lab_city' => $request->input('lab_city'),
            'lab_pin' => $request->input('lab_pin'),
            'lab_tel' => $request->input('lab_tel'),
            'lab_email' => $request->input('lab_email'),
            'lab_fax' => $request->input('lab_fax'),
            'scope_for_sampling' => $request->input('scope_for_sampling'),
            'remarks' => $request->input('remarks'),
            'lab_logo' => $lab_logo,
            'nabl_logo' => $nabl_logo,
            'nabl_certificate' => $nabl_certificate,

        ];
        $refLaboratory = RefLaboratory::create($data);

        $refLaboratoryId = $refLaboratory->id;

        $user_data = [
            'user_name' => $request->input('lab_email'),
            'email' => $request->input('lab_email'),
            'mobile_no' => $request->input('lab_tel'),
            'password' => hash('sha256', '123456'),
            'user_type' => 1,
            'ref_operator_type_id' => 102,
            'lab_id' => $refLaboratoryId,
            'created_by' => $userId,


        ];
        User::create($user_data);

        // For mail
        $lab_name = getLabNameById($refLaboratoryId);

        $user_email = $request->input('lab_email');
        session(['user_email' => $user_email]);
        $emailOTP = rand('1000', '9999');
        session(['emailOTP' => $emailOTP]);
        $emails = $user_email;
        $maildata = array();
        $maildata  = ['send_message' => " Dear $lab_name LAB <br><br> Your User Name -:" .  $request->input('lab_email') . " <br> And Your Password -:" . '123456' . "  <br><br>Regards, <br>Apeda Team"];
        Mail::send('mail.inspector_register', $maildata, function ($message) use ($emails) {
            $message->subject("LAB Registration"); // Email subject body
            $message->to($emails);
        });


        // Mail end
        Alert::success('Success', 'Lab Details Save Successfully');
        return redirect()->route('superadmin.registeredLab');
    }
    public function viewLab($id)
    {

        $data = RefLaboratory::where('id', $id)->first();
        return view('admin.lab.viewLab', compact('data'));
    }

    public function assingProduct($id)
    {

        $data = RefLaboratory::where('id', $id)->first();
        //dd($data);
        return view('admin.lab.assingProduct', compact('data'));
    }

    // public function uploadFile(Request $request)
    // {
    //     $request->validate([
    //         'file' => 'required|mimes:pdf|max:1024', // PDF files only, max size 1MB
    //     ]);

    //     if ($request->file('file')) {

    //         $fileName = time() . rand() . '.' . $request->file('file')->getClientOriginalExtension();

    //         $documentRootPath = public_path('/news');
    //         $filePath = '/public/news/' . $fileName;


    //         $request->file('file')->move($documentRootPath, $fileName);


    //         return response()->json(['success' => 'File uploaded successfully.', 'file' => $filePath]);
    //     }


    //     return response()->json(['error' => 'File upload failed.']);
    // }


    public function submitForm(Request $request)
    {
        // dd($request->all());


        $validatedData = $request->validate([

            'file' => 'required|file|mimes:pdf|max:1024',
            'blocked_by' => 'required',
            'recommended_by' => 'required',
        ]);


        if ($request->file('file')) {

            $fileName = time() . rand() . '.' . $request->file('file')->getClientOriginalExtension();

            $documentRootPath = public_path('/news');
            $filePath = '/public/news/' . $fileName;


            $request->file('file')->move($documentRootPath, $fileName);
        }


        $data = RefAssingLabProduct::create([
            'lab_id' => $request->input('lab_id'),
            'module' => $request->input('module'),
            'product_name' => $request->input('product_name'),
            'eto_status' => $request->input('eto_status'),
            'gmo_status' => $request->input('gmo_status'),
            'ptmonth' => $request->input('ptmonth'),
            'ptyear' => $request->input('ptyear'),
            'nrldate' => $request->input('nrldate'),
            'file' => $filePath,
            'blocked_by' => json_encode($request->input('blocked_by', [])),
            'recommended_by' => json_encode($request->input('recommended_by', [])),
        ]);

        // dd($data);
        return redirect()->route('superadmin.registeredLab');
    }





    public function CbRegister(Request $request)
    {
        // abort_unless(\Gate::allows('user_access'), 403);

        $userId = Auth::id();

        if ($request->ajax()) {
            $query = User::with('roles')
                ->where('ref_operator_type_id', 1)
                ->orderBy('id', 'DESC');
            $users = $query->get();

            if ($request->status !== '' && $request->status !== 'all') {
                $query->where('status', $request->status);
            }

            // print_r($users);
            // die;
            return Datatables::of($users)
                ->addIndexColumn()
                ->addColumn('first_name', function ($row) {
                    return $row->first_name ?? '';
                })
                ->addColumn('user_name', function ($row) {
                    return $row->user_name;
                })
                ->addColumn('mobile', function ($row) {
                    return $row->mobile_no ?? '';
                })
                ->addColumn('created_on', function ($row) {
                    return $row->created_at ? date('d-m-Y', strtotime($row->created_at)) : '';
                })
                ->addColumn('action', function ($row) {

                    $addEditDetailButton = '';
                    if (Auth::guard('misadmin')->user()->roles[0]->id == 1) {

                        $addEditDetailButton .= '<a href=' . route('superadmin.usermanagement.panaltyview', [$row->id]) . ' target="_blank"><span><i class="mdi mdi-eye text-muted fs-16 align-middle me-1" data-toggle="tooltip"  title="View User"></i></span></a>';
                        // Delete button
                        $addEditDetailButton .= '<a href="JavaScript:void(0);" class="deletedata" data-value="' . $row->id . '"><span><i class="mdi mdi-delete-circle text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Delete User"></i></span></a>';
                    }
                    return $addEditDetailButton;
                })
                ->rawColumns(['action', 'first_name', 'user_name', 'mobile'])
                ->make(true);
        }
        return view('admin.cb.add');
    }

    // public function AddCb(Request $request)
    // {
    //     abort_unless(\Gate::allows('user_access'), 403);

    //     $userId = Auth::id();

    //     if ($request->ajax()) {
    //         // dd($request->all());

    //         if ($request->status != '' && $request->status != 'all') {
    //             $user = User::with('roles')->where('ref_operator_type_id', 1)->where('created_by', $userId)->where('status', $request->status)->orderBy('id', 'DESC')->get();
    //         } else {
    //             $user = User::with('roles')->where('ref_operator_type_id', 1)->where('created_by', $userId)->orderBy('id', 'DESC')
    //                 ->get();
    //         }
    //         //    dd($user);
    //         return Datatables::of($user)
    //             ->addIndexColumn()
    //             ->addColumn('first_name', function ($row) {
    //                 $first_name = $row->first_name ?? '';
    //                 // $middle_name = $row->middle_name ?? '';
    //                 // $last_name = $row->last_name ?? '';
    //                 return $first_name;
    //             })
    //             ->addColumn('user_name', function ($row) {

    //                 return $row->user_name;

    //             })
    //             ->addColumn('mobile', function ($row) {
    //                 return $row->mobile_no ?? '';
    //             })

    //             ->addColumn('created_on', function ($row) {

    //                 return  date('d-m-Y', strtotime($row->created_at)) ?? '';

    //             })


    //             ->rawColumns(['first_name', 'user_name', 'mobile'])
    //             ->make(true);
    //     }

    //  return view('admin.cb.add_cb');
    // }

    public function addCb(Request $request)
    {


        //abort_unless(\Gate::allows('user_access'), 403);

        $userId = Auth::id();

        if ($request->ajax()) {
            $query = User::with('roles')->where('ref_operator_type_id', 1)
                ->where('created_by', $userId);

            if ($request->status !== '' && $request->status !== 'all') {
                $query->where('status', $request->status);
            }

            $users = $query->orderBy('id', 'DESC')->get();

            return Datatables::of($users)
                ->addIndexColumn()
                ->addColumn('first_name', function ($row) {
                    return $row->first_name ?? '';
                })
                ->addColumn('user_name', function ($row) {
                    return $row->user_name;
                })
                ->addColumn('mobile', function ($row) {
                    return $row->mobile_no ?? '';
                })
                ->addColumn('created_on', function ($row) {
                    return $row->created_at ? date('d-m-Y', strtotime($row->created_at)) : '';
                })
                ->rawColumns(['first_name', 'user_name', 'mobile'])
                ->make(true);
        }

        return view('admin.cb.add_cb');
    }


    public function AddCbSave(Request $request)
    {


        $rules = [

            'user_name' => 'required|string|max:255|unique:at_user',
            'mobile_no' => 'required|string|max:10|unique:at_user',
            // 'password' => 'required|string|confirmed',
        ];


        $messages = [
            'user_name.unique' => 'The PAN Details is already taken. Please choose a different one.',
            'mobile_no.unique' => 'The mobile number is already in use. Please use a different one.',
            'password.confirmed' => 'The password confirmation does not match.',
        ];


        $request->validate($rules, $messages);

        $user = User::create([

            'first_name' => $request->input('first_name'),
            'user_name' => $request->input('user_name'),
            // 'email' => $request->input('email'),
            'mobile_no' => $request->input('mobile_no'),
            'password' => hash('sha256', $request->input('password')),
            'user_type' => 1,
            'ref_operator_type_id' => 1,

        ]);
        // dd($user);
        $user->roles()->attach(1);

        return redirect()->route('superadmin.CbRegister');
    }

    public function lab_register_list(Request $request)
    {
        // abort_unless(\Gate::allows('user_access'), 403);

        $userId = Auth::id();

        if ($request->ajax()) {
            $query = User::with('roles')
                ->where('ref_operator_type_id', 102)
                ->orderBy('id', 'DESC');
            $users = $query->get();

            if ($request->status !== '' && $request->status !== 'all') {
                $query->where('status', $request->status);
            }

            // print_r($users);
            // die;
            return Datatables::of($users)
                ->addIndexColumn()
                ->addColumn('first_name', function ($row) {
                    return $row->first_name ?? '';
                })
                ->addColumn('lab_id', function ($row) {
                    return getLabNameById($row->lab_id) ?? '';
                })
                ->addColumn('user_name', function ($row) {
                    return $row->user_name;
                })
                ->addColumn('mobile', function ($row) {
                    return $row->mobile_no ?? '';
                })
                ->addColumn('created_on', function ($row) {
                    return $row->created_at ? date('d-m-Y', strtotime($row->created_at)) : '';
                })
                ->addColumn('action', function ($row) {

                    $addEditDetailButton = '';
                    if (Auth::guard('misadmin')->user()->roles[0]->id == 1) {

                        $addEditDetailButton .= '<a href=' . route('superadmin.usermanagement.panaltyview', [$row->id]) . ' target="_blank"><span><i class="mdi mdi-eye text-muted fs-16 align-middle me-1" data-toggle="tooltip"  title="View User"></i></span></a>';
                        // Delete button
                        $addEditDetailButton .= '<a href="JavaScript:void(0);" class="deletedata" data-value="' . $row->id . '"><span><i class="mdi mdi-delete-circle text-muted fs-16 align-middle me-1" data-toggle="tooltip" title="Delete User"></i></span></a>';
                    }
                    return $addEditDetailButton;
                })
                ->rawColumns(['action', 'first_name', 'user_name', 'mobile'])
                ->make(true);
        }
        return view('admin.lab.lab_register_list');
    }


    public function lab_register(Request $request)
    {

        return view('admin.lab.lab_register');
    }

    public function lab_register_save(Request $request)
    {
        $userId = Auth::id();


        $lab_data = User::where('lab_id', $request->input('lab_id'))->first();
        if ($lab_data) {


            return redirect()->back()->with('error', 'Lab ID already exists.');
        } else {



            $user = User::create([

                //'first_name' => $request->input('first_name'),
                'user_name' => $request->input('email'),
                'email' => $request->input('email'),
                'mobile_no' => $request->input('mobile_no'),
                'password' => hash('sha256', $request->input('password')),
                'user_type' => 1,
                'ref_operator_type_id' => 102,
                'lab_id' => $request->input('lab_id'),
                'created_by' => $userId,

            ]);
            // dd($user);
            $user->roles()->attach(1);

            return redirect()->route('superadmin.lab_register_list');
        }
    }


    public function GrowerGroup(Request $request)
    {

        return view('admin.operator.ics');
    }

    public function GrowerGroupSearch(Request $request)
    {
        try {
            if ($request->ajax()) {

                $user_id = Auth::guard('misadmin')->user()->id;

                // $finalData = User::where('created_by', $user_id)->with('certificateStandardDetails')->where('status', '2')->where('ref_operator_type_id', 2)->get();
                $finalData = User::where('created_by', $user_id)
                    ->where('is_deleted', false)
                    ->where('ref_operator_type_id', 2)
                    ->whereHas('certificateStandardDetails', function ($query) {
                        $query->where('validity_end_date', '>', Carbon::now()->subDays(90));
                    })
                    ->get();


                //dd($finalData);
                // $finalData = $query->where('ref_operator_type_id', 2)->limit(10)->get();
                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('reg_no', function ($row) {
                        return  $row->registration_no ?? 'Profile Pendding';
                    })

                    ->addColumn('scope_no', function ($row) {
                        return $row->certificateStandardDetails[0]->scope_certificate_no ?? 'No Certificate';
                    })

                    ->addColumn('scope_validity', function ($row) {
                        return date('d-m-Y', strtotime($row->certificateStandardDetails[0]->validity_start_date)) . ' to ' . date('d-m-Y', strtotime($row->certificateStandardDetails[0]->validity_end_date)) ?? 'No Certificate';
                    })

                    ->addColumn('operator_name', function ($row) {
                        return ($row->first_name ?? '');
                    })
                    ->addColumn('reg_date', function ($row) {
                        return date('d-m-Y', strtotime($row->created_at ?? ''));
                    })

                    ->addColumn('contact_details', function ($row) {
                        $actionBtn =
                            "Name: " . ($row->contact_person_first_name ?? '') . " " . ($row->contact_person_last_name ?? '') . "<br>" .
                            "Mobile No: " . ($row->contact_person_mobile_number ?? '') . "<br>" .
                            "Email Id: " . ($row->contact_person_email ?? '');

                        return $actionBtn;
                    })

                    ->addColumn('address', function ($row) {
                        $actionBtn =
                            "Address: " . ($row->address ?? '') . "<br>" .
                            "State: " . getStateName($row->ref_state_id ?? '') . "<br>" .
                            "District: " . getDistrictNameById($row->ref_district_id ?? '') . "<br>" .
                            "Village: " . getVillageNameById($row->ref_village_id ?? '') . "<br>" .
                            "PIN Code: " . ($row->pin ?? '');

                        return $actionBtn;
                    })

                    ->rawColumns(['contact_details', 'address']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    public function IP(Request $request)
    {

        return view('admin.operator.ip');
    }

    public function IpSearch(Request $request)
    {
        try {
            if ($request->ajax()) {



                $user_id = Auth::guard('misadmin')->user()->id;

                $query = User::query();

                $finalData = User::where('created_by', $user_id)
                    ->where('is_deleted', false)
                    ->where('ref_operator_type_id', 3)
                    ->whereHas('certificateStandardDetails', function ($query) {
                        $query->where('validity_end_date', '>', Carbon::now()->subDays(90));
                    })
                    ->get();
                // $finalData = $query->where('created_by', $user_id)->where('status', '2')->where('ref_operator_type_id', 3)->limit(10)->get();
                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('reg_no', function ($row) {
                        return  $row->registration_no ?? 'Profile Pendding';
                    })

                    ->addColumn('scope_no', function ($row) {
                        return $row->certificateStandardDetails[0]->scope_certificate_no ?? 'No Certificate';
                    })
                    ->addColumn('scope_validity', function ($row) {
                        return date('d-m-Y', strtotime($row->certificateStandardDetails[0]->validity_start_date)) . ' to ' . date('d-m-Y', strtotime($row->certificateStandardDetails[0]->validity_end_date)) ?? 'No Certificate';
                    })

                    ->addColumn('operator_name', function ($row) {
                        return ($row->first_name ?? '');
                    })
                    ->addColumn('reg_date', function ($row) {
                        return date('d-m-Y', strtotime($row->created_at ?? ''));
                    })

                    ->addColumn('contact_details', function ($row) {
                        $actionBtn =
                            "Name: " . ($row->contact_person_first_name ?? '') . " " . ($row->contact_person_last_name ?? '') . "<br>" .
                            "Mobile No: " . ($row->contact_person_mobile_number ?? '') . "<br>" .
                            "Email Id: " . ($row->contact_person_email ?? '');

                        return $actionBtn;
                    })

                    ->addColumn('address', function ($row) {
                        $actionBtn =
                            "Address: " . ($row->address ?? '') . "<br>" .
                            "State: " . getStateName($row->ref_state_id ?? '') . "<br>" .
                            "District: " . getDistrictNameById($row->ref_district_id ?? '') . "<br>" .
                            "Village: " . getVillageNameById($row->ref_village_id ?? '') . "<br>" .
                            "PIN Code: " . ($row->pin ?? '');

                        return $actionBtn;
                    })

                    ->rawColumns(['contact_details', 'address']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    public function Wh(Request $request)
    {

        return view('admin.operator.wh');
    }

    public function WhSearch(Request $request)
    {
        try {
            if ($request->ajax()) {



                $user_id = Auth::guard('misadmin')->user()->id;

                $query = User::query();
                $finalData = User::where('created_by', $user_id)
                    ->where('is_deleted', false)
                    ->where('ref_operator_type_id', 4)
                    ->whereHas('certificateStandardDetails', function ($query) {
                        $query->where('validity_end_date', '>', Carbon::now()->subDays(90));
                    })
                    ->get();
                //$finalData = $query->where('created_by', $user_id)->where('status', '2')->where('ref_operator_type_id', 4)->get();
                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('reg_no', function ($row) {
                        return  $row->registration_no ?? 'Profile Pendding';
                    })

                    ->addColumn('scope_no', function ($row) {
                        return $row->certificateStandardDetails[0]->scope_certificate_no ?? 'No Certificate';
                    })
                    ->addColumn('scope_validity', function ($row) {
                        return date('d-m-Y', strtotime($row->certificateStandardDetails[0]->validity_start_date)) . ' to ' . date('d-m-Y', strtotime($row->certificateStandardDetails[0]->validity_end_date)) ?? 'No Certificate';
                    })

                    ->addColumn('operator_name', function ($row) {
                        return ($row->first_name ?? '');
                    })
                    ->addColumn('reg_date', function ($row) {
                        return date('d-m-Y', strtotime($row->created_at ?? ''));
                    })

                    ->addColumn('contact_details', function ($row) {
                        $actionBtn =
                            "Name: " . ($row->contact_person_first_name ?? '') . " " . ($row->contact_person_last_name ?? '') . "<br>" .
                            "Mobile No: " . ($row->contact_person_mobile_number ?? '') . "<br>" .
                            "Email Id: " . ($row->contact_person_email ?? '');

                        return $actionBtn;
                    })

                    ->addColumn('address', function ($row) {
                        $actionBtn =
                            "Address: " . ($row->address ?? '') . "<br>" .
                            "State: " . getStateName($row->ref_state_id ?? '') . "<br>" .
                            "District: " . getDistrictNameById($row->ref_district_id ?? '') . "<br>" .
                            "Village: " . getVillageNameById($row->ref_village_id ?? '') . "<br>" .
                            "PIN Code: " . ($row->pin ?? '');

                        return $actionBtn;
                    })

                    ->rawColumns(['contact_details', 'address']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }


    public function Processor(Request $request)
    {

        return view('admin.operator.processor');
    }

    public function ProcessorSearch(Request $request)
    {
        try {
            if ($request->ajax()) {



                $user_id = Auth::guard('misadmin')->user()->id;

                $query = User::query();
                $finalData = User::where('created_by', $user_id)
                    ->where('is_deleted', false)
                    ->where('ref_operator_type_id', 6)
                    ->whereHas('certificateStandardDetails', function ($query) {
                        $query->where('validity_end_date', '>', Carbon::now()->subDays(90));
                    })
                    ->get();
                //  $finalData = $query->where('created_by', $user_id)->where('status', '2')->where('ref_operator_type_id', 6)->get();
                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('reg_no', function ($row) {
                        return  $row->registration_no ?? 'Profile Pendding';
                    })
                    ->addColumn('scope_no', function ($row) {
                        return $row->certificateStandardDetails[0]->scope_certificate_no ?? 'Scope Certificate Not issue';
                    })
                    ->addColumn('scope_validity', function ($row) {
                        return date('d-m-Y', strtotime($row->certificateStandardDetails[0]->validity_start_date ?? '')) . ' to ' . date('d-m-Y', strtotime($row->certificateStandardDetails[0]->validity_end_date ?? '')) ?? 'No Certificate';
                    })

                    ->addColumn('operator_name', function ($row) {
                        return ($row->first_name ?? '');
                    })
                    ->addColumn('reg_date', function ($row) {
                        return date('d-m-Y', strtotime($row->created_at ?? ''));
                    })

                    ->addColumn('contact_details', function ($row) {
                        $actionBtn =
                            "Name: " . ($row->contact_person_first_name ?? '') . " " . ($row->contact_person_last_name ?? '') . "<br>" .
                            "Mobile No: " . ($row->contact_person_mobile_number ?? '') . "<br>" .
                            "Email Id: " . ($row->contact_person_email ?? '');

                        return $actionBtn;
                    })

                    ->addColumn('address', function ($row) {
                        $actionBtn =
                            "Address: " . ($row->address ?? '') . "<br>" .
                            "State: " . getStateName($row->ref_state_id ?? '') . "<br>" .
                            "District: " . getDistrictNameById($row->ref_district_id ?? '') . "<br>" .
                            "Village: " . getVillageNameById($row->ref_village_id ?? '') . "<br>" .
                            "PIN Code: " . ($row->pin ?? '');

                        return $actionBtn;
                    })

                    ->rawColumns(['contact_details', 'address']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }
    public function Trader(Request $request)
    {

        return view('admin.operator.Trader');
    }

    public function TraderSearch(Request $request)
    {
        try {
            if ($request->ajax()) {



                $user_id = Auth::guard('misadmin')->user()->id;

                $query = User::query();
                $finalData = User::where('created_by', $user_id)
                    ->where('is_deleted', false)
                    ->where('ref_operator_type_id', 5)
                    ->whereHas('certificateStandardDetails', function ($query) {
                        $query->where('validity_end_date', '>', Carbon::now()->subDays(90));
                    })
                    ->get();
                //$finalData = $query->where('created_by', $user_id)->where('status', '2')->where('ref_operator_type_id', 5)->get();
                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('reg_no', function ($row) {
                        return  $row->registration_no ?? 'Profile Pendding';
                    })

                    ->addColumn('scope_no', function ($row) {
                        return $row->certificateStandardDetails[0]->scope_certificate_no ?? 'Scope Certificate Not issue';
                    })
                    ->addColumn('scope_validity', function ($row) {
                        return date('d-m-Y', strtotime($row->certificateStandardDetails[0]->validity_start_date ?? '')) . ' to ' . date('d-m-Y', strtotime($row->certificateStandardDetails[0]->validity_end_date ?? '')) ?? 'No Certificate';
                    })

                    ->addColumn('operator_name', function ($row) {
                        return ($row->first_name ?? '');
                    })
                    ->addColumn('reg_date', function ($row) {
                        return date('d-m-Y', strtotime($row->created_at ?? ''));
                    })

                    ->addColumn('contact_details', function ($row) {
                        $actionBtn =
                            "Name: " . ($row->contact_person_first_name ?? '') . " " . ($row->contact_person_last_name ?? '') . "<br>" .
                            "Mobile No: " . ($row->contact_person_mobile_number ?? '') . "<br>" .
                            "Email Id: " . ($row->contact_person_email ?? '');

                        return $actionBtn;
                    })

                    ->addColumn('address', function ($row) {
                        $actionBtn =
                            "Address: " . ($row->address ?? '') . "<br>" .
                            "State: " . getStateName($row->ref_state_id ?? '') . "<br>" .
                            "District: " . getDistrictNameById($row->ref_district_id ?? '') . "<br>" .
                            "Village: " . getVillageNameById($row->ref_village_id ?? '') . "<br>" .
                            "PIN Code: " . ($row->pin ?? '');

                        return $actionBtn;
                    })

                    ->rawColumns(['contact_details', 'address']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    public function Farmer(Request $request)
    {

        return view('admin.operator.farmer');
    }

    public function FarmerSearch(Request $request)
    {
        try {
            if ($request->ajax()) {



                $user_id = Auth::guard('misadmin')->user()->id;

                // $query = AtFarmerRegDetail::query();

                //  $userIds = User::where('status', '2')->pluck('id')->toArray();


                $userIds = User::where('created_by', $user_id)
                    ->where('status', 2)
                    ->where('ref_operator_type_id', 2)
                    ->whereNull('deleted_at')
                    ->pluck('id')
                    ->toArray();

                $finalData = AtFarmerRegDetail::whereIn('at_user_id', $userIds)->orderby('id', 'desc')->get();

                // dd($query);
                // $finalData = $query->orderby('id', 'desc')->get();
                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('reg_no', function ($row) {
                        return  $row->registration_no ?? 'Profile Pendding';
                    })

                    ->addColumn('reg_date', function ($row) {
                        return dateFormat($row->registration_date ?? '');
                    })
                    ->addColumn('farmer_name', function ($row) {
                        return ($row->farmer_first_name . '   ' . $row->farmer_last_name ?? '');
                    })
                    ->addColumn('farmer_address', function ($row) {
                        return $row->farmer_address ?? '';
                    })
                    ->addColumn('state', function ($row) {
                        return getStateName($row->ref_state_id ?? '');
                    })
                    ->addColumn('district', function ($row) {
                        return getDisName($row->ref_district_id ?? '');
                    })
                    ->addColumn('mobile', function ($row) {
                        return $row->mobile_no ?? '';
                    })


                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    public function Farms(Request $request)
    {

        return view('admin.operator.farm');
    }

    public function FarmsSearch(Request $request)
    {
        try {
            if ($request->ajax()) {

                $user_id = Auth::guard('misadmin')->user()->id;

                $userIds = User::where('created_by', $user_id)
                    ->where('status', 2)
                    ->where('ref_operator_type_id', 2)
                    ->whereNull('deleted_at')
                    ->pluck('id')
                    ->toArray();


                $farmerId = AtFarmerRegDetail::whereIn('at_user_id', $userIds)->pluck('id')->toArray();


                // dd($farmerId);
                $query = AtFarmDetails::query();

                $finalData = AtFarmDetails::whereIn('at_farmer_reg_details_id',  $farmerId)->get();


                // $finalData = $query->orderby('id', 'asc')->get();
                $dataTable = DataTables::of($finalData)


                    ->addIndexColumn()

                    ->addColumn('reg_no', function ($row) {
                        return  $row->registration_no ?? 'Profile Pendding';
                    })
                    ->addColumn('farm_name', function ($row) {
                        return ($row->farm_name  ?? '');
                    })
                    ->addColumn('area', function ($row) {
                        return $row->area_in_ha ?? '';
                    })
                    ->addColumn('total_area', function ($row) {
                        return $row->total_area ?? '';
                    })
                    ->addColumn('state', function ($row) {
                        return getStateName($row->ref_state_id ?? '');
                    })
                    ->addColumn('district', function ($row) {
                        return getDisName($row->ref_district_id ?? '');
                    })
                    ->addColumn('plot', function ($row) {
                        return $row->no_of_plot ?? '';
                    })
                    ->addColumn('organic_cultivation', function ($row) {
                        return $row->area_organic_cultivation ?? '';
                    })


                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    public function Products(Request $request)
    {

        return view('admin.operator.product');
    }

    public function ProductsSearch(Request $request)
    {
        try {
            if ($request->ajax()) {





                $query = RefProduct::query();

                $finalData = $query->orderby('id', 'asc')->get();
                $dataTable = DataTables::of($finalData)
                    ->addIndexColumn()

                    ->addColumn('hs_code', function ($row) {
                        return  $row->hs_code ?? '1010121212';
                    })
                    ->addColumn('product_name', function ($row) {
                        return ($row->product_name  ?? '');
                    })
                    ->addColumn('hscode_description', function ($row) {
                        return $row->hscode_description ?? '';
                    })
                    ->addColumn('ref_category_id', function ($row) {
                        return getCategoryNameById($row->ref_category_id ?? '');
                    })

                    ->rawColumns(['action']);

                return $dataTable->make(true);
            }

            return response()->json(['msg' => 'success']);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json(['msg' => 'error', 'error' => $e->getMessage()]);
        }
    }

    public function testSms()
    {
        $mobileNumber = '8171162448';
        $username = 'TestUser';
        $email = 'test@example.com';
        $password = 'Test@1234';

        $response = $this->sendLoginDetailsSms($mobileNumber, $username, $email, $password);

        return response()->json($response);
    }

    private  function sendLoginDetailsSms($mobileNumber, $username, $email, $password = '123456')
    {
        $apiUrl = 'https://apeda.gov.in/apedaMobile/api/apedawebsite/sendNicOTP';

        $message = "Your Login details to access Tracenet are  Name : $username , User ID :$email and  Password  : $password , More details at www.apeda.gov.in";

        // dd($message );
        $data = [
            'txtmessage' => $message,
            'senderID' => 'APEDAI',
            'mobilenumber' => $mobileNumber,
            'templateID' => '1707161761984762652',
        ];

        $ch = curl_init($apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
        ]);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

        $response = curl_exec($ch);
        if (curl_errno($ch)) {
            Log::error('SMS sending failed: ' . curl_error($ch));
        }
        curl_close($ch);


        return json_decode($response, true);
    }

    public function activecb(Request $request)
    {


        $module_title = 'Active CB List';
        $module_name =  'active_cb_list';

        $menu = RefModule::get();
        $submodule = RefSubmodule::get();
        $userId = Auth::id();
        $query = User::with('roles')
            ->where('user_name', '!=', '')
            ->where('ref_operator_type_id', 1)
            ->whereNull('deleted_at')
            ->orderBy('id', 'DESC')
            ->get();

        //  pra($query);
        //  die;



        if ($request->ajax()) {

            return Datatables::of($query)
                ->addIndexColumn()
                ->addColumn('first_name', function ($row) {
                    
                    $actionBtn =
                        "<strong>Name:</strong> " . ($row->first_name ?? '') . " " . ($row->last_name ?? '') . "<br>" .
                        "<strong>Mobile No:</strong> " . ($row->mobile_no ?? 'N/A') . "<br>" .
                        "<strong>Email Id:</strong> " . ($row->email ?? 'N/A') . "<br>" .
                        "<strong>Address:</strong> " . $row->address ?? 'N/A';

                    return $actionBtn;
                })
                ->addColumn('user_name', function ($row) {
                    return $row->user_name;
                })

                ->addColumn('created_on', function ($row) {
                    return $row->created_at ? date('d-m-Y', strtotime($row->created_at)) : '';
                })
                ->addColumn('action', function ($row) {

                    
                    $addEditDetailButton = '';
                    if (Auth::guard('misadmin')->user()->roles[0]->id != 1) {

                        $addEditDetailButton .= '<a href="javascript:void(0);" onClick="AccountTerminated(' . $row->id . ')"><span><i class="mdi mdi-pencil text-muted fs-16 align-middle me-1" data-toggle="tooltip"  title="Account Terminated"></i></span></a>&nbsp&nbsp';
                        $addEditDetailButton .= '<a href="javascript:void(0);" onClick="menuassign(' . $row->id . ')"><span><i class="mdi mdi-eye text-muted fs-16 align-middle me-1" data-toggle="tooltip"  title="Menu Permissions"></i></span></a>&nbsp&nbsp';
                        $addEditDetailButton .= '<a href="JavaScript:void(0);" onClick="StateAllow(' . $row->id . ')"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-flag" viewBox="0 0 16 16"> <path d="M14.778.085A.5.5 0 0 1 15 .5V8a.5.5 0 0 1-.314.464L14.5 8l.186.464-.003.001-.006.003-.023.009a12 12 0 0 1-.397.15c-.264.095-.631.223-1.047.35-.816.252-1.879.523-2.71.523-.847 0-1.548-.28-2.158-.525l-.028-.01C7.68 8.71 7.14 8.5 6.5 8.5c-.7 0-1.638.23-2.437.477A20 20 0 0 0 3 9.342V15.5a.5.5 0 0 1-1 0V.5a.5.5 0 0 1 1 0v.282c.226-.079.496-.17.79-.26C4.606.272 5.67 0 6.5 0c.84 0 1.524.277 2.121.519l.043.018C9.286.788 9.828 1 10.5 1c.7 0 1.638-.23 2.437-.477a20 20 0 0 0 1.349-.476l.019-.007.004-.002h.001M14 1.221c-.22.078-.48.167-.766.255-.81.252-1.872.523-2.734.523-.886 0-1.592-.286-2.203-.534l-.008-.003C7.662 1.21 7.139 1 6.5 1c-.669 0-1.606.229-2.415.478A21 21 0 0 0 3 1.845v6.433c.22-.078.48-.167.766-.255C4.576 7.77 5.638 7.5 6.5 7.5c.847 0 1.548.28 2.158.525l.028.01C9.32 8.29 9.86 8.5 10.5 8.5c.668 0 1.606-.229 2.415-.478A21 21 0 0 0 14 7.655V1.222z"/> </svg>State Allow</a>&nbsp&nbsp';
                        $addEditDetailButton .= '<a href="javascript:void(0);" onClick="getRefProductpermission(' . $row->id . ')"><span><i class="mdi mdi-pencil text-muted fs-16 align-middle me-1" data-toggle="tooltip"  title="Products permission"></i></span></a>&nbsp&nbsp';
                        $addEditDetailButton .= '<a href="javascript:void(0);" onClick="categoryByidshow(' . $row->id . ')"><span><i class="mdi mdi-pencil text-muted fs-16 align-middle me-1" data-toggle="tooltip"  title="Category Permission"></i></span></a>';
                    }
                    if ($row->emStatus == "1") {
                        // Digital Signature Verified
                        $addEditDetailButton .= '<a href="javascript:void(0);" class="btn btn-success btn-sm mt-2 text-white" onClick="userDigitalSignatureData('.$row->id.')">
                            <span><i class="mdi mdi-eye text-white align-middle me-1" data-toggle="tooltip" title="Digital Signature Permissions"></i></span>
                            Digital Signature Verified
                        </a>';
                    } elseif ($row->emStatus == "0") {
                        // Pending
                        $addEditDetailButton .= '<a href="javascript:void(0);" class="btn btn-warning btn-sm mt-2 text-white" onClick="userDigitalSignatureData('.$row->id.')">
                            <span><i class="mdi mdi-eye text-white align-middle me-1" data-toggle="tooltip" title="Digital Signature Permissions"></i></span>
                            Digital Signature Pending
                        </a>';
                    } elseif ($row->emStatus == "2") {
                        // Expired
                        $addEditDetailButton .= '<a href="javascript:void(0);" class="btn btn-danger btn-sm mt-2 text-white" onClick="userDigitalSignatureData('.$row->id.')">
                            <span><i class="mdi mdi-eye text-white align-middle me-1" data-toggle="tooltip" title="Digital Signature Permissions"></i></span>
                            Digital Signature Expired
                        </a>';
                    } else {
                        // Default fallback (Optional)
                        $addEditDetailButton .= '<a href="javascript:void(0);" class="btn btn-secondary btn-sm mt-2 text-white" onClick="userDigitalSignatureData('.$row->id.')">
                            <span><i class="mdi mdi-eye text-white align-middle me-1" data-toggle="tooltip" title="Digital Signature Permissions"></i></span>
                            Digital Signature Status Unknown
                        </a>';
                    }
                    return $addEditDetailButton;
                })
                ->rawColumns(['action', 'first_name', 'user_name', 'mobile'])
                ->make(true);
        }
        return view('admin.cb.activecblist', compact('menu', 'submodule'));
    }


    public function menu_id_get(Request $request)
    {
        if (!empty($request->menu_id) && !empty($request->cbID)) {
            $cbid = AtCBRegistrationPermission::where('cb_id', $request->cbID)
                ->where('module_id', $request->menu_id)
                ->get();
            $submodules = RefSubmodule::where('module_id', $request->menu_id)->get();
            return response()->json(['data' => $submodules, 'cbid' => $cbid]);
        } else {
            return response()->json(['data' => [], 'cbid' => []]);
        }
    }




    public function storepermissionmenu(Request $request)
    {

        $request->validate([
            'Menu_id' => 'required',
            'cb_user_id' => 'required',
        ]);

        $checker = AtCBRegistrationPermission::where('cb_id', $request->cb_user_id)
            ->where('module_id', $request->Menu_id)
            ->where('deleted_at', NULL)
            ->whereIn('sub_module_id', $request->sub_module_name ?? [])
            ->exists();
        if ($checker) {
            return response()->json(['status' => 'error', 'msg' => 'Permission Menu already exists for this user.']);
        }
        $dataToInsert = [];
        if (!empty($request->sub_module_name) && is_array($request->sub_module_name)) {
            foreach ($request->sub_module_name as $subModule) {
                $dataToInsert[] = [
                    'module_id' => $request->Menu_id,
                    'sub_module_id' => $subModule,
                    'cb_id' => $request->cb_user_id,
                    'remarks' => $request->remark,
                    'created_at' => now(),
                    'created_by' => Auth::guard('misadmin')->user()->id,
                ];
            }
        } else {
            $dataToInsert[] = [
                'module_id' => $request->Menu_id,
                'sub_module_id' => '',
                'cb_id' => $request->cb_user_id,
                'remarks' => $request->remark,
                'created_at' => now(),
                'created_by' => Auth::guard('misadmin')->user()->id,
            ];
        }
        // dd($dataToInsert);
        AtCBRegistrationPermission::insert($dataToInsert);
        return response()->json(['status' => 'success', 'msg' => 'Permission Menu created successfully', 'html' => 'Data has been saved successfully',]);
    }






    public function menupermissionupdate(Request $request)
    {

        $results = DB::table('at_cb_registration_permission as cb')
            ->leftJoin('module as md', 'md.id', '=', 'cb.module_id')
            ->leftJoin('sub_module as smb', 'smb.id', '=', 'cb.sub_module_id')
            ->where('cb.cb_id', $request->cb_id)
            ->where('deleted_at',NULL)
            ->get();
       
        echo view('admin.cb.templateactivecb', compact('results'))->render();
    }

    public function menupermissionupdateStore(Request $request)
    {


        $deleted = AtCBRegistrationPermission::whereIn('cb_main_id', $request->cb_prm_id)->delete();
        if ($deleted) {
            Alert::success('Success', 'Deleted successfully');
        } else {
            Alert::error('Error', 'No records found to delete');
        }
        return redirect()->back();
    }




    public function AccountTerminated(Request $request)
    {
        $cbId = $request->cb_id;
        $results =  User::where('id', $cbId)->first();
        // pra($results);
        echo view('admin.cb.templatecbterminate', compact('cbId', 'results'))->render();
    }





    public function templatecbterminatesus(Request $request)
    {

        $request->validate([
            'cb_user_id' => 'required|exists:at_user,id',
            'account_terminated' => 'required|in:6,7,8',
        ]);

        try {
            $user = User::find($request->cb_user_id);
            if (!$user) {
                return response()->json(['status' => 'error', 'msg' => 'User not found.'], 404);
            }

            $status = $request->account_terminated;
            $statusMessage = '';
            $smsMessage = '';
            switch ($status) {
                case 6:
                    $statusMessage = 'Your account has been Terminated.';
                    $smsMessage = "Your account has been Terminated.";
                    break;

                case 7:
                    $statusMessage = 'Your account has been Suspended.';
                    $smsMessage = "Your account has been Suspended.";
                    break;

                case 8:
                    $statusMessage = 'Your account has been Blocked.';
                    $smsMessage = "Your account has been Blocked.";
                    break;
            }

            $user->operator_status = $status;
            $user->remark = $request->remarks;
            $user->to_date = $request->to_date;
            $user->from_date = $request->form_date;
            $user->updated_by = Auth::guard('misadmin')->user()->id;
            $user->save();
            $mailData = [
                'name' => $user->user_name,
                'first_name' => $user->first_name . ' ' . $user->last_name,
                'statusMessage' => $statusMessage,
            ];

            SendEmailJob::dispatch($mailData, $user->email);
            // Send SMS notification (optional)
            // $smsResponse = $this->sendLoginDetailsSms($user->mobile_number, $user->user_name, $smsMessage);
            // if (!$smsResponse) {
            //     return response()->json([ 'status' => 'error', 'msg' => 'Failed to send SMS notification.', ], 500);
            // }
            return response()->json([
                'status' => 'success',
                'msg' => 'User status updated and notifications sent successfully.',
                'html' => 'Data has been saved successfully',
            ]);
        } catch (Exception $e) {
            Log::error('Error in updating user status: ' . $e->getMessage());
            return response()->json([
                'status' => 'error',
                'msg' => 'An error occurred while updating the user status. Please try again later.',
            ], 500);
        }
    }




    // private function SendLoginDetailsSmssss($mobileNumber, $username, $smsMessage)
    // {

    //     $apiUrl = 'https://apeda.gov.in/apedaMobile/api/apedawebsite/sendNicOTP';
    //     $data = [
    //         'txtmessage' => $smsMessage,
    //         'senderID' => 'APEDAI',
    //         'mobilenumber' => $mobileNumber,
    //         'templateID' => '1707160681109422053',
    //     ];

    //     $ch = curl_init($apiUrl);
    //     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    //     curl_setopt($ch, CURLOPT_HTTPHEADER, [
    //         'Content-Type: application/json',
    //     ]);
    //     curl_setopt($ch, CURLOPT_POST, true);
    //     curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

    //     $response = curl_exec($ch);
    //     if (curl_errno($ch)) {
    //         return ['error' => curl_error($ch)];
    //     }
    //     curl_close($ch);
    //     //dd($response);
    //     return json_decode($response, true);
    //     //  dd($response);

    //     return response()->json($response);
    // }

    public function cbemSignKycUpdate(Request $request)
    {
        // Validation
        $rules = $request->eSignClient === "0" ? [
            'eSignUserId' => 'required|integer',
            'digitaSignStatus' => 'required|integer',
            'eSignType' => 'required|string|max:10',
            'emUserId' => 'required|string|max:255',
            'emUserName' => 'required|string|max:255',
            'emUserReason' => 'required|string|max:255',
            'eSignLocation' => 'required|string',
            'staticLocationDetails' => 'nullable|string|max:255',
            'moduleName' => 'required|array',
            'moduleName.*' => 'string|max:50',
        ] : [
            'eSignUserId' => 'required|integer',
            'eSignType' => 'required|string|max:10',
            'emUserId' => 'required|string|max:255',
            'emUserName' => 'required|string|max:255',
        ];
        $request->validate($rules);
    
        try {
            $eSignUser = User::find($request->eSignUserId);

            if (!$eSignUser) {
                return response()->json([
                    'status' => 'error',
                    'msg' => 'User not found.',
                ], 404);
            }

            $updateData = $request->eSignClient === "0" ? [
                'emStatus' => $request->digitaSignStatus,
                'eSignType' => $request->eSignType,
                'emUserId' => $request->emUserId,
                'emName' => $request->emUserName,
                'eSignReason' => $request->emUserReason,
                'eSignLocation' => $request->eSignLocation,
                'eSignStaticLocation' => $request->staticLocationDetails,
                'eSignModuleAllow' => json_encode($request->moduleName),
                'eSignUpdated_by' => Auth::guard('misadmin')->user()->id,
                'eSignUpdated_at' => now(),
            ] : [
                'emStatus' => '4',
                'eSignType' => $request->eSignType,
                'emUserId' => $request->emUserId,
                'emName' => $request->emUserName,
                'eSignCreated_at' => now(),
            ];
        
            // Update user data
            $eSignUser->update($updateData);

            return response()->json([
                'status' => 'success',
                'msg' => 'eSign KYC updated successfully.',
            ]);
        } catch (\Exception $e) {
            Log::error('Error updating eSign KYC:', [
                'error' => $e->getMessage(),
                'data' => $request->all(),
            ]);
    
            return response()->json([
                'status' => 'error',
                'msg' => 'An error occurred while processing your request.',
            ], 500);
        }
    }
    

    public function cbemSignKycData(Request $request)
    {
        // Validate input
        $request->validate([
            'id' => 'required|integer'
        ]);
    
        // Retrieve the user data
        $eSignUser = User::find($request->id);
    
        if (!$eSignUser) {
            return response()->json([
                'status' => 'error',
                'msg' => 'User not found.'
            ]);
        }
    
        try {
            // Prepare the data to send to the front-end
            $data = [
                'id' => $eSignUser->id,
                'emStatus' => $eSignUser->emStatus,
                'eSignType' => $eSignUser->eSignType,
                'emUserId' => $eSignUser->emUserId,
                'emUserName' => $eSignUser->emName,
                'emUserReason' => $eSignUser->eSignReason,
                'eSignLocation' => $eSignUser->eSignLocation,
                'eSignStaticLocation' => $eSignUser->eSignStaticLocation,
                'eSignModuleAllow' => json_decode($eSignUser->eSignModuleAllow),  // Decode the JSON to return as an array
            ];
    
            return response()->json([
                'status' => 'success',
                'data' => $data,  // Send user data to the frontend
            ]);
        } catch (\Exception $e) {
            // Log the error and return a generic error response
            Log::error('Error fetching user data: ' . $e->getMessage());
            return response()->json([
                'status' => 'error',
                'msg' => 'An error occurred while fetching the user data.'
            ], 500);
        }
    }



    public function getstatIdByallow(Request $request)
    {
        $cb_id = $request->cb_id;
        $state =  RefState::orderBy('state_name')->get();
        $cbstate =  CBStatewiseRestriction::where('cb_id', $cb_id)->get();
        $CBstateAssign = CBStatewiseRestriction::leftjoin('ref_state', 'ref_state.id', 'cb_statewise_restriction.ref_state_id')
            ->select('ref_state.id as refStateId', 'ref_state.state_name', 'cb_statewise_restriction.*')
            ->where('cb_id', $cb_id)
            ->orderBy('ref_state_id', 'ASC')
            ->get();

        echo view('admin.cb.templatestatename', compact('cb_id', 'state', 'cbstate', 'CBstateAssign'))->render();
    }



    public function getstatIdByallowstore_id(Request $request)
    {
        $request->validate([
            'cb_id' => 'required',
            'state_id' => 'required|array|min:1',
        ]);

        try {

            // $exists = CBStatewiseRestriction::where('cb_id', $request->cb_id)
            //     ->where ('deleted_at',NULL)
            //     ->whereIn('ref_state_id', $request->state_id ?? [])
            //     ->get();


            // if ($exists) {
            //     Alert::error('error', 'States already taken for this user.');
            //     return redirect()->back();
            // }

            if (!empty($request->state_id) && is_array($request->state_id)) {
                $dataToInsert = [];
                foreach ($request->state_id as $state_id) {
                    $dataToInsert[] = [
                        'cb_id' => $request->cb_id,
                        'ref_state_id' => $state_id,
                        'created_at' => now(),
                        'created_by' => Auth::id(),
                    ];
                }

                CBStatewiseRestriction::insert($dataToInsert);
            }
            Alert::success('Success', 'States added successfully.');
            return redirect()->back();
        } catch (Exception $e) {
            Log::error('Error in updating user status: ' . $e->getMessage());
            return response()->json([
                'status' => 'error',
                'msg' => 'An error occurred while updating the user status. Please try again later.',
            ], 500);
        }
    }


    public function getstatIdByUpdate(Request $request)
    {
        $selectedStates = $request->input('selectedStates');
        if (empty($selectedStates)) {
            return response()->json(['success' => false, 'message' => 'No states selected.'], 400);
        }

        try {
            $deletedRows = CBStatewiseRestriction::whereIn('id', $selectedStates)->delete();
            if ($deletedRows > 0) {
                return response()->json(['success' => true, 'message' => 'Records deleted successfully.']);
            } else {
                return response()->json(['success' => false, 'message' => 'No records found to delete.'], 404);
            }
        } catch (\Exception $e) {

            return response()->json(['success' => false, 'message' => 'An error occurred while deleting records.', 'error' => $e->getMessage()], 500);
        }
    }

    

    
    public function getCbByidRefproductpermission(Request $request)
    {
        // dd($request->all());
        $cbId = $request->cb_id;
        $results =  User::where('id', $cbId)->first();
        $productdata =  RefProduct::orderBy('id','ASC')->get();
        $procbID =  User::where('id',$cbId)->first();
        

        $getproduct = DB::table('cb_product_wise_restriction as prdres')
            ->select(
                'prdres.id as cbres_id',   
                'prdres.cb_id',   
                'prdres.ref_product_id',   
                'prdres.status',   
                'refpro.id',
                'refpro.hs_code',
                'refpro.product_name',
                'refpro.hscode_description',
                'refpro.ref_category_id',
                'userid.user_name',
                'userid.first_name',
                'userid.last_name',
                'userid.email',
            )
            ->leftJoin('ref_product as refpro', 'refpro.id', '=', 'prdres.ref_product_id')
            ->leftJoin('at_user as userid', 'userid.id', '=', 'prdres.cb_id')
            ->where('prdres.cb_id', $cbId)
            ->orderBy('prdres.id', 'ASC')
            ->get();
    
        // pra($getproduct);
                                     
        
        echo view('admin.cb.templateRefproductprms', compact('cbId', 'productdata','getproduct','results','procbID'))->render();
    }




    public function getCbByidRefproductpermissionStore(Request $request)
    {
        // dd($request->all());

        $request->validate([
            'cb_id' => 'required',
            'product_id' => 'required|array|min:1',
        ]);

        try {

            if (!empty($request->product_id) && is_array($request->product_id)) {
                $dataToInsert = [];
                foreach ($request->product_id as $product_id) {
                    $dataToInsert[] = [
                        'cb_id' => $request->cb_id,
                        'ref_product_id' => $product_id,
                        'created_at' => now(),
                        'created_by' => Auth::id(),
                    ];
                }

                CBProductWiseRestriction::insert($dataToInsert);
            }
            Alert::success('Success', 'Product added successfully.');
            return redirect()->back();
        } catch (Exception $e) {
            Log::error('Error in updating user status: ' . $e->getMessage());
            return response()->json([
                'status' => 'error',
                'msg' => 'An error occurred while updating the user status. Please try again later.',
            ], 500);
        }
     
    }



    public function getCbByidRefproductpermissionUpdate(Request $request)
    {
        // dd($request->all());
        $cbresID = $request->input('cbresID');
        if (empty($cbresID)) {
            return response()->json(['success' => false, 'message' => 'No Products selected.'], 400);
        }

        try {
             $deletedRows = CBProductWiseRestriction::whereIn('id', $cbresID)->delete();
            if ($deletedRows > 0) {
                return response()->json(['success' => true, 'message' => 'Records deleted successfully.']);
            } else {
                return response()->json(['success' => false, 'message' => 'No records found to delete.'], 404);
            }
        } catch (\Exception $e) {

            return response()->json(['success' => false, 'message' => 'An error occurred while deleting records.', 'error' => $e->getMessage()], 500);
        }

        
     
    }




    public function getCbByidcategorypermission(Request $request)
    {
        // dd($request->all());
        $cbId = $request->cb_id;
        $results =  User::where('id', $cbId)->first();
        $eligiblecategory =  RefEligibleCategory::orderBy('id','ASC')->get();
        $cbcatresult1 = CBCategoryWiseRestriction::
         select(
            'cb_category_wise_restriction.id',
            'cb_category_wise_restriction.cb_id',
            'cb_category_wise_restriction.ref_eligible_category_id',
            'elcat.id as elcatID',
            'elcat.category',
            'elcat.is_active',

         )
        ->leftjoin('ref_eligible_category as elcat','elcat.id','=','cb_category_wise_restriction.ref_eligible_category_id')
        ->where('cb_category_wise_restriction.cb_id', $cbId)
        ->orderBy('cb_category_wise_restriction.id', 'ASC')
        ->get();
        $cbcatresult = CBCategoryWiseRestriction::where('cb_id', $cbId)
        ->orderBy('id', 'ASC')
        ->pluck('ref_eligible_category_id')
        ->toArray();
        echo view('admin.cb.templatecategory', compact('cbId', 'eligiblecategory','results','cbcatresult','cbcatresult1'))->render();
    }



    public function getCbByidcategorypermissionstore(Request $request)
    {
        // dd($request->all());
        $request->validate([
            'cb_id' => 'required',
            'eligible_category_id' => 'required|array|min:1',
        ]);

        try {

            if (!empty($request->eligible_category_id) && is_array($request->eligible_category_id)) {
                $dataToInsert = [];
                foreach ($request->eligible_category_id as $eligiblecategoryid) {
                    $dataToInsert[] = [
                        'cb_id' => !empty($request->cb_id) ? $request->cb_id : NULL,
                        'ref_eligible_category_id' => !empty($eligiblecategoryid) ? $eligiblecategoryid : NULL,
                        'created_at' => now(),
                        'created_by' => Auth::id(),
                    ];
                }

                CBCategoryWiseRestriction::insert($dataToInsert);
            }
            Alert::success('Success', 'added successfully.');
            return redirect()->back();
        } catch (Exception $e) {
            Log::error('Error in updating user status: ' . $e->getMessage());
            return response()->json([
                'status' => 'error',
                'msg' => 'An error occurred while updating the user status. Please try again later.',
            ], 500);
        }
        
    }


    

    
    public function getCbByidcategorypermissionupdate(Request $request)
    {
        $eligiblecategory = $request->input('eligiblecategory_id');
        if (empty($eligiblecategory)) {
            return response()->json(['success' => false, 'message' => 'No Products selected.'], 400);
        }

        try {
             $deletedRows = CBCategoryWiseRestriction::whereIn('id', $eligiblecategory)->delete();
            if ($deletedRows > 0) {
                return response()->json(['success' => true, 'message' => 'Records deleted successfully.']);
            } else {
                return response()->json(['success' => false, 'message' => 'No records found to delete.'], 404);
            }
        } catch (\Exception $e) {

            return response()->json(['success' => false, 'message' => 'An error occurred while deleting records.', 'error' => $e->getMessage()], 500);
        }
    }

    public function announcementlist(Request $request)
{
    $useroperator = auth()->user()->ref_operator_type_id; 
    $query = Announcement::where('ref_operator_type_id', $useroperator)->get();


    if ($request->ajax()) {
        return DataTables::of($query)
            ->addIndexColumn()  
            ->editColumn('published_date', function ($announcement) {
                return $announcement->published_date ? \Carbon\Carbon::parse($announcement->published_date)->format('Y-m-d H:i:s') : '';
            })
            ->addColumn('related_link', function ($announcement) {
                return '<a href="' . $announcement->related_link . '" target="_blank">Link</a>';
            })
            ->addColumn('attachment', function ($announcement) {
                return $announcement->attachment ? '<a href="' . asset('public/attachment/attachment/' . $announcement->attachment) . '" target="_blank">Download</a>' : 'No Attachment';
            })
            ->rawColumns(['related_link', 'attachment']) 
            ->make(true);
    }


    return view('admin.announcement_list');
}

}

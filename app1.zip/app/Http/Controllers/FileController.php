<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\FileService;
use Illuminate\Support\Facades\Validator;

class FileController extends Controller
{
    private FileService $fileService;

    public function __construct(FileService $fileService)
    {
        $this->fileService = $fileService;
    }

    /**
     * List all files (metadata only).
     */
    public function index()
    {
        $files = \DB::table('at_upload_document_files')->where('status', 'active')->get();
        return response()->json($files, 200);
    }


    /**
     * Show metadata of a single file.
     */
    public function show(int $fileId)
    {
        $file = \DB::table('at_upload_document_files')->find($fileId);

        if (!$file) {
            return response()->json(['message' => 'File not found.'], 404);
        }

        return response()->json($file, 200);
    }

    /**
     * Upload a new file.
     */
    public function upload(Request $request)
    {
        \Log::info($request->all()); // Logs all input

        // Get allowed types and max size from configuration
        $allowedTypes = config('filesystems.upload.allowed_types');
        $maxSize = config('filesystems.upload.max_size');

        // Build validation rules
        $rules = [
            'documents' => "required|file|mimes:" . implode(',', $allowedTypes) . "|max:$maxSize",
        ];        

        // Validate the request
        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $response = $this->fileService->uploadFile(
            $request,
            'documents',
            $allowedTypes,
            'documents'
        );

        return response()->json($response);
    }


    /**
     * Download a file.
     */
    public function download(int $fileId)
    {
        return $this->fileService->downloadFile($fileId);
    }

    /**
     * Update metadata for a file.
     */
    public function update(Request $request, int $fileId)
    {
        $file = \DB::table('at_upload_document_files')->find($fileId);

        if (!$file) {
            return response()->json(['message' => 'File not found.'], 404);
        }

        $updated = \DB::table('at_upload_document_files')
            ->where('id', $fileId)
            ->update($request->only(['original_name', 'description', 'tags']));

        return response()->json(['message' => 'File metadata updated successfully.'], 200);
    }

    /**
     * Move a file to trash (soft delete).
     */
    public function delete(int $fileId)
    {
        $file = \DB::table('at_upload_document_files')->find($fileId);

        if (!$file) {
            return response()->json(['message' => 'File not found.'], 404);
        }

        \DB::table('at_upload_document_files')
            ->where('id', $fileId)
            ->update(['status' => 'trashed']);

        return response()->json(['message' => 'File moved to trash.'], 200);
    }
}

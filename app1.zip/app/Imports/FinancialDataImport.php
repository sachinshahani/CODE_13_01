<?php

namespace App\Imports;

use App\Models\TempTarget;
use Auth;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;

class FinancialDataImport implements ToModel, WithValidation, WithHeadingRow
{
    public function model(array $row)
    {
        $office = '';
        foreach ($row as $k => $r) {
            if ($k == 'offices') {
                $office = $r;
            }

            $fin = new TempTarget([
                'key' => $k,
                'value' => $r,
                'office' => $office,
                'scheme' => $row['scheme'],
                'year' => $row['year'],
                'created_at' => now(),
                'created_by' => Auth::user()->id,
            ]);
            $fin->save();
        }

        return $fin;
    }

    public function rules(): array
    {
        return [
            //'Offices' => ['required'],
        ];
    }

    /*
    * @author Prashant
    * Skip top heading Data
    */
    public function headingRow(): int
    {
        return 1;
    }
}

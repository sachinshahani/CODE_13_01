-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2023 at 12:24 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dharma`
--

-- --------------------------------------------------------

--
-- Table structure for table `asset_health_inspection`
--

CREATE TABLE `asset_health_inspection` (
  `inspection_id` int(11) NOT NULL,
  `PIC` varchar(254) NOT NULL,
  `nodes` varchar(500) DEFAULT NULL,
  `portfolio_nodes` text DEFAULT NULL,
  `inspection_type` varchar(250) NOT NULL,
  `inspection_from` date DEFAULT NULL,
  `inspection_to` date DEFAULT NULL,
  `health_condition` varchar(6) DEFAULT NULL COMMENT 'Cat I; II; III, general condition of the dam',
  `health_status` tinyint(4) DEFAULT NULL COMMENT '1 = Satisfactory 2 = Fair 3 = Poor 4 = Unsatisfactory',
  `inspecting_officers` text DEFAULT NULL,
  `insp_det_weather_conditions` varchar(100) DEFAULT NULL,
  `insp_det_reservoir_level` varchar(50) DEFAULT NULL,
  `insp_det_other_remarks` text DEFAULT NULL,
  `insp_det_lic_ad_remarks` text DEFAULT NULL,
  `find_gen_remarks` text DEFAULT NULL,
  `find_key_non_comp` text DEFAULT NULL,
  `rec_key_rcmndtns` text DEFAULT NULL,
  `ip_adress` varchar(265) DEFAULT NULL,
  `added_by` bigint(20) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `review_count` smallint(6) NOT NULL DEFAULT 0,
  `status` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0-Deleted, 1-Active, 2-Submitted but Pending Verification from Authorised Person, 3-Reviewed but pending for requested changes, 4- Rejected, 5-Not Yet submitted',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `asset_health_inspection_details`
--

CREATE TABLE `asset_health_inspection_details` (
  `ahi_id` bigint(20) NOT NULL,
  `inspection_id` bigint(20) NOT NULL,
  `node_id` bigint(20) DEFAULT NULL COMMENT '-1 means all nodes\r\n-2 means all nodes related to field_set and sub_set question_id',
  `question_id` bigint(20) DEFAULT NULL,
  `answer` text DEFAULT NULL,
  `deficiency_observed` text DEFAULT NULL,
  `health_condition` varchar(10) DEFAULT NULL,
  `remedy_suggested` text DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `added_by` bigint(20) DEFAULT NULL,
  `date_added` timestamp NULL DEFAULT current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '0-Deleted, 1-Active, 2-Pending Review, 3- Reported'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `asset_health_inspection_photos`
--

CREATE TABLE `asset_health_inspection_photos` (
  `SNO` bigint(20) NOT NULL,
  `insp_detail_id` bigint(20) NOT NULL,
  `position` int(11) DEFAULT NULL,
  `name` text NOT NULL,
  `remark` text DEFAULT NULL,
  `added_by` bigint(20) DEFAULT NULL,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` tinyint(4) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `asset_health_inspection_questions`
--

CREATE TABLE `asset_health_inspection_questions` (
  `ahq_id` bigint(20) NOT NULL,
  `node_type_id` bigint(20) DEFAULT NULL,
  `Node_Type` varchar(250) DEFAULT NULL COMMENT 'All questions are "Dam". But for questions related to health_status, we have associated node type',
  `applicability` varchar(250) DEFAULT NULL,
  `question_id_no` varchar(15) NOT NULL,
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `desired_answer` varchar(15) NOT NULL,
  `type` varchar(50) NOT NULL,
  `field_set` varchar(50) NOT NULL,
  `field_set_order` tinyint(2) NOT NULL DEFAULT 1,
  `field_sub_set` varchar(150) NOT NULL,
  `field_sub_set_order` varchar(5) NOT NULL DEFAULT '1',
  `date_added` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '0-Deleted, 1-Active, 2-Pending Review, 3-Reported'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `asset_health_inspection_remedials`
--

CREATE TABLE `asset_health_inspection_remedials` (
  `SNO` int(10) NOT NULL,
  `node_type` varchar(50) NOT NULL,
  `applicability` varchar(10) DEFAULT NULL,
  `question_ids` text DEFAULT NULL COMMENT 'list of id separated by '',''. Provide ''all'' to consider all questions',
  `remedial` varchar(300) NOT NULL,
  `date_added` date NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0 = not reviewed by expert. 1 = reviewed.'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `asset_health_instrumentation`
--

CREATE TABLE `asset_health_instrumentation` (
  `SN` int(2) NOT NULL,
  `N` int(2) NOT NULL,
  `PIC` varchar(10) NOT NULL,
  `amount` int(11) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `asset_health_instrumentation_remarks`
--

CREATE TABLE `asset_health_instrumentation_remarks` (
  `PIC` varchar(10) NOT NULL,
  `General` text DEFAULT NULL,
  `Geotechnical` text DEFAULT NULL,
  `Geodetic` text DEFAULT NULL,
  `Hydrometeorological` text DEFAULT NULL,
  `Seismic` text DEFAULT NULL,
  `Other` text DEFAULT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `asset_health_instruments_list`
--

CREATE TABLE `asset_health_instruments_list` (
  `SN` int(11) NOT NULL,
  `N` int(11) NOT NULL,
  `category` varchar(50) NOT NULL,
  `purpose` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `applicability` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `asset_health_investigation`
--

CREATE TABLE `asset_health_investigation` (
  `investigation_id` bigint(11) NOT NULL,
  `investigation_identifier` varchar(255) DEFAULT NULL,
  `PIC` varchar(254) NOT NULL,
  `investigation_status` varchar(20) NOT NULL,
  `investigation_type` varchar(50) NOT NULL,
  `investigation_from` varchar(20) NOT NULL,
  `investigation_to` varchar(20) NOT NULL,
  `scope_of_work` text DEFAULT NULL,
  `asset_component` text NOT NULL,
  `document_id` text DEFAULT NULL,
  `IP_ADD` varchar(265) NOT NULL,
  `Added_by` bigint(20) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0-Deleted, 1-Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `asset_health_om_budget`
--

CREATE TABLE `asset_health_om_budget` (
  `budget_id` bigint(11) NOT NULL,
  `om_id` int(11) NOT NULL,
  `PIC` varchar(254) NOT NULL,
  `budget_year` varchar(30) DEFAULT NULL,
  `requested` decimal(10,2) DEFAULT NULL,
  `allocated` decimal(10,2) DEFAULT NULL,
  `expenditure` decimal(10,2) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0-Deleted, 1-Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `asset_health_om_manual`
--

CREATE TABLE `asset_health_om_manual` (
  `om_id` bigint(11) NOT NULL,
  `PIC` varchar(254) NOT NULL,
  `status_om_prepared` tinyint(1) DEFAULT NULL,
  `status_om_prepared_remark` tinytext DEFAULT NULL,
  `status_om_published` tinyint(1) DEFAULT NULL,
  `status_om_published_remark` tinytext DEFAULT NULL,
  `status_om_pub_date` varchar(30) DEFAULT NULL,
  `status_om_pub_remark` tinytext DEFAULT NULL,
  `status_om_on_dharma` tinyint(1) DEFAULT NULL,
  `status_om_on_dharma_remark` tinytext DEFAULT NULL,
  `contents_question` varchar(25) NOT NULL,
  `contents_question_remark` tinytext DEFAULT NULL,
  `contents_operation_rule` tinyint(1) NOT NULL,
  `contents_operation_rule_remark` tinytext DEFAULT NULL,
  `contents_rating_curves` tinyint(1) NOT NULL,
  `contents_rating_curves_remark` tinytext DEFAULT NULL,
  `contents_elevation_area` tinyint(1) NOT NULL,
  `contents_elevation_area_remark` tinytext DEFAULT NULL,
  `contents_bathymatric_survey_date` varchar(30) DEFAULT NULL,
  `contents_bathymatric_survey_date_remark` tinytext DEFAULT NULL,
  `contents_sequence_of_Gate_Opening` tinyint(1) NOT NULL,
  `contents_sequence_of_gate_opening_remark` tinytext DEFAULT NULL,
  `contents_types_of_inspection` tinyint(1) NOT NULL,
  `contents_types_of_inspection_remark` tinytext DEFAULT NULL,
  `contents_inspection_checklist` tinyint(1) NOT NULL,
  `contents_inspection_checklist_remark` tinytext DEFAULT NULL,
  `contents_maintenance_requirements` tinyint(1) NOT NULL,
  `contents_maintenance_requirements_remark` tinytext DEFAULT NULL,
  `contents_dam_roles_and_res` tinyint(1) NOT NULL,
  `contents_dam_roles_and_res_remark` tinytext DEFAULT NULL,
  `contents_do_operating_personnel` tinyint(1) NOT NULL,
  `contents_do_operating_personnel_remark` tinytext DEFAULT NULL,
  `contents_om_budget` tinyint(1) NOT NULL,
  `contents_om_budget_remark` tinytext DEFAULT NULL,
  `IP_ADD` varchar(265) NOT NULL,
  `Added_by` bigint(20) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0-Deleted, 1-Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `asset_rehabilitation_details`
--

CREATE TABLE `asset_rehabilitation_details` (
  `rehabilitation_id` bigint(20) NOT NULL,
  `rehab_identifier` varchar(254) NOT NULL,
  `PIC` varchar(254) NOT NULL,
  `status_of_work` varchar(20) NOT NULL,
  `tow_civil` tinyint(1) DEFAULT NULL,
  `tow_mechanical` tinyint(1) DEFAULT NULL,
  `tow_electrical` tinyint(1) DEFAULT NULL,
  `tow_instrumentation` tinyint(1) DEFAULT NULL,
  `tow_other` tinyint(1) DEFAULT NULL,
  `nit_issued_date` varchar(10) DEFAULT NULL,
  `contract_agreement_date` varchar(10) DEFAULT NULL,
  `start_on_site` varchar(10) DEFAULT NULL,
  `work_completion_date` varchar(10) DEFAULT NULL,
  `supplier_id` varchar(20) DEFAULT NULL,
  `contract_value` varchar(25) NOT NULL,
  `scope_of_work` text DEFAULT NULL,
  `asset_component` text DEFAULT NULL,
  `added_by` bigint(20) NOT NULL,
  `IP_ADD` text NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `asset_rehabilitation_photos`
--

CREATE TABLE `asset_rehabilitation_photos` (
  `Sno` bigint(20) NOT NULL,
  `PIC` varchar(767) NOT NULL,
  `ASSET_ID` bigint(20) NOT NULL,
  `image_pos` int(11) NOT NULL,
  `image_name` text NOT NULL,
  `image_remarks` text DEFAULT NULL,
  `Added_By` bigint(20) NOT NULL,
  `Date_Added` timestamp NOT NULL DEFAULT current_timestamp(),
  `Status` tinyint(4) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `asset_rehab_details`
--

CREATE TABLE `asset_rehab_details` (
  `asset_id` int(11) NOT NULL,
  `asset_pic` varchar(265) NOT NULL,
  `asset_from` varchar(265) NOT NULL,
  `asset_to` varchar(265) NOT NULL,
  `asset_start_on_site` varchar(256) NOT NULL,
  `asset_civil` varchar(265) NOT NULL,
  `asset_mechanical` varchar(256) NOT NULL,
  `asset_electrical` varchar(256) NOT NULL,
  `asset_instrumentation` varchar(256) NOT NULL,
  `asset_other` varchar(256) NOT NULL,
  `asset_status_of_work` text DEFAULT NULL,
  `asset_suplier` varchar(265) NOT NULL,
  `asset_contract_value` varchar(265) NOT NULL,
  `asset_scope_of_work` text DEFAULT NULL,
  `asset_component` varchar(265) NOT NULL,
  `asset_photos` text DEFAULT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `basin_state_mapping`
--

CREATE TABLE `basin_state_mapping` (
  `id` bigint(20) NOT NULL,
  `ref_basin_list_id` bigint(20) NOT NULL,
  `ref_state_id` bigint(20) DEFAULT NULL,
  `Status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `connectivity_master`
--

CREATE TABLE `connectivity_master` (
  `Connectivity_SNO` bigint(20) NOT NULL,
  `Connectivity_Type` varchar(767) NOT NULL,
  `Connectivity_Code` varchar(6) NOT NULL,
  `Connectivity_Name` text NOT NULL,
  `Date_Added` timestamp NOT NULL DEFAULT current_timestamp(),
  `Added_By` bigint(20) NOT NULL,
  `Status` tinyint(4) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contact_page`
--

CREATE TABLE `contact_page` (
  `id` bigint(20) NOT NULL,
  `level` varchar(50) NOT NULL,
  `designation` varchar(150) NOT NULL,
  `office_address` text NOT NULL,
  `telefax` text NOT NULL,
  `email` varchar(150) NOT NULL,
  `website` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0-Active, 1-InActive',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customization_units`
--

CREATE TABLE `customization_units` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `Meter` tinyint(1) NOT NULL DEFAULT 0,
  `Feet` tinyint(1) NOT NULL DEFAULT 0,
  `KiloMeter` tinyint(1) NOT NULL DEFAULT 0,
  `Sq_Meter` tinyint(1) NOT NULL DEFAULT 0,
  `Sq_Feet` tinyint(1) NOT NULL DEFAULT 0,
  `Sq_KiloMeter` tinyint(1) NOT NULL DEFAULT 0,
  `Sq_Mile` tinyint(1) NOT NULL DEFAULT 0,
  `Acre` tinyint(1) NOT NULL DEFAULT 0,
  `Hectare` tinyint(1) NOT NULL DEFAULT 0,
  `M_Sq_Meter` tinyint(1) NOT NULL DEFAULT 0,
  `M_Acre` tinyint(1) NOT NULL DEFAULT 0,
  `M_Hectare` tinyint(4) NOT NULL DEFAULT 0,
  `Cu_Meter` tinyint(1) NOT NULL DEFAULT 0,
  `Cu_Feet` tinyint(1) NOT NULL DEFAULT 0,
  `BCM_Cu_KiloMeter` tinyint(1) NOT NULL DEFAULT 0,
  `Acre_Feet` tinyint(1) NOT NULL DEFAULT 0,
  `Cu_Hectometer` tinyint(1) NOT NULL DEFAULT 0,
  `M_Cu_Meter` tinyint(1) NOT NULL DEFAULT 0,
  `TMC_Th_M_Cu_Ft` tinyint(1) NOT NULL DEFAULT 0,
  `MAF_M_Acre_Feet` tinyint(1) NOT NULL DEFAULT 0,
  `Cumec` tinyint(1) NOT NULL DEFAULT 0,
  `Cusec` tinyint(1) NOT NULL DEFAULT 0,
  `Rs` tinyint(4) NOT NULL DEFAULT 0,
  `Thousand` tinyint(4) NOT NULL DEFAULT 0,
  `Lakhs` tinyint(4) NOT NULL DEFAULT 0,
  `Crores` tinyint(4) NOT NULL DEFAULT 0,
  `Million` tinyint(4) NOT NULL DEFAULT 0,
  `Billion` tinyint(1) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=Active,1=Inactive',
  `created_by` tinyint(1) DEFAULT NULL,
  `updated_by` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dashboard_inspection_report`
--

CREATE TABLE `dashboard_inspection_report` (
  `dir_id` bigint(20) NOT NULL,
  `PIC` varchar(254) NOT NULL,
  `year` varchar(4) NOT NULL,
  `state_sno` varchar(20) DEFAULT NULL,
  `licsensee_sno` varchar(20) DEFAULT NULL,
  `pre_high` varchar(1) DEFAULT NULL,
  `pre_cat_1` varchar(11) DEFAULT NULL,
  `pre_cat_2` varchar(11) DEFAULT NULL,
  `pre_cat_3` varchar(11) DEFAULT NULL,
  `post_high` varchar(1) DEFAULT NULL,
  `post_cat_1` varchar(11) DEFAULT NULL,
  `post_cat_2` varchar(11) DEFAULT NULL,
  `post_cat_3` varchar(11) DEFAULT NULL,
  `update_on` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dashboard_static_licenseewise`
--

CREATE TABLE `dashboard_static_licenseewise` (
  `sno` bigint(20) NOT NULL,
  `licensee_sno` bigint(20) NOT NULL,
  `licensee_name` text NOT NULL,
  `no_of_dams` text NOT NULL,
  `project_features` text NOT NULL,
  `project_portfolio` text NOT NULL,
  `eng_features` text NOT NULL,
  `progress` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dashboard_static_licenseewise_damwise`
--

CREATE TABLE `dashboard_static_licenseewise_damwise` (
  `id` bigint(20) NOT NULL,
  `license_sno` varchar(20) DEFAULT NULL,
  `pic` varchar(20) NOT NULL,
  `name_of_dam` text NOT NULL,
  `project_features` text DEFAULT NULL,
  `project_portfolio` text DEFAULT NULL,
  `eng_features` text DEFAULT NULL,
  `progress` text DEFAULT NULL,
  `last_id` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dashboard_static_licenseewise_damwise_old`
--

CREATE TABLE `dashboard_static_licenseewise_damwise_old` (
  `sno` bigint(20) NOT NULL,
  `licensee_sno` varchar(20) DEFAULT NULL,
  `pic` varchar(20) NOT NULL,
  `name_of_dam` text NOT NULL,
  `project_features` text DEFAULT NULL,
  `project_portfolio` text DEFAULT NULL,
  `eng_features` text DEFAULT NULL,
  `progress` text DEFAULT NULL,
  `last_id` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `deficiencies`
--

CREATE TABLE `deficiencies` (
  `def_id` int(10) NOT NULL,
  `inspection_id` int(10) NOT NULL,
  `deficiencies_date` varchar(20) DEFAULT NULL,
  `deficiency` text NOT NULL,
  `remedy` text NOT NULL,
  `category` varchar(3) NOT NULL,
  `action_taken` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dharma_action_log`
--

CREATE TABLE `dharma_action_log` (
  `log_sno` bigint(20) NOT NULL,
  `Actioned_Page` text NOT NULL,
  `Actioned_Module` text NOT NULL,
  `Old_Data` text DEFAULT NULL,
  `New_Data` text DEFAULT NULL,
  `Review_Status` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1-Not Reviewed, 2-Reviewed and Found OK, 3-Reviewed And Found Not OK, 4-To Be Deleted',
  `Reviewed_By` bigint(20) DEFAULT NULL,
  `Action_Taken` varchar(767) DEFAULT NULL,
  `IP_ADD` text NOT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dharma_cms`
--

CREATE TABLE `dharma_cms` (
  `id` bigint(20) NOT NULL,
  `title` varchar(256) DEFAULT NULL,
  `slug` varchar(256) DEFAULT NULL,
  `meta_keyword` text DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `content` text NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0=Active,1=Inactive',
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `dh_asset_health_eap`
--

CREATE TABLE `dh_asset_health_eap` (
  `id` bigint(20) NOT NULL,
  `eap_id` bigint(20) DEFAULT NULL,
  `PIC` varchar(150) NOT NULL,
  `eap_year` int(11) NOT NULL,
  `status_eap_prepared` tinyint(1) DEFAULT NULL,
  `status_eap_prepared_remark` tinytext DEFAULT NULL,
  `status_eap_published` tinyint(1) DEFAULT NULL,
  `status_eap_published_remark` tinytext DEFAULT NULL,
  `status_eap_pub_date` varchar(30) DEFAULT NULL,
  `status_eap_pub_remark` tinytext DEFAULT NULL,
  `status_eap_on_dharma` tinyint(1) DEFAULT NULL,
  `status_eap_on_dharma_remark` tinytext DEFAULT NULL,
  `contents_question` varchar(25) NOT NULL,
  `contents_question_remark` tinytext NOT NULL,
  `question1_ans` text DEFAULT NULL,
  `question2_ans` text DEFAULT NULL,
  `question3_ans` text DEFAULT NULL,
  `ip_add` varchar(265) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0-deleted, 1-active',
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_asset_health_eap_answer`
--

CREATE TABLE `dh_asset_health_eap_answer` (
  `id` bigint(20) NOT NULL,
  `answer_id` bigint(20) DEFAULT NULL,
  `dh_asset_health_eap_question_id` bigint(20) NOT NULL,
  `eap_answer` text NOT NULL,
  `score` tinyint(4) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_asset_health_eap_question`
--

CREATE TABLE `dh_asset_health_eap_question` (
  `id` bigint(20) NOT NULL,
  `question_id` bigint(20) DEFAULT NULL,
  `eap_question` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_asset_health_eap_ques_ans`
--

CREATE TABLE `dh_asset_health_eap_ques_ans` (
  `id` bigint(20) NOT NULL,
  `eap_id` bigint(20) NOT NULL,
  `question_id` bigint(20) NOT NULL,
  `answer_id` bigint(20) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` timestamp(3) NOT NULL DEFAULT current_timestamp(3) ON UPDATE current_timestamp(3),
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_basic_features_financials`
--

CREATE TABLE `dh_basic_features_financials` (
  `id` bigint(20) NOT NULL,
  `basic_features_financials_sno` bigint(20) DEFAULT NULL,
  `project_identification_code` varchar(150) NOT NULL,
  `project_features_fin_base_year_taken_org` varchar(50) DEFAULT NULL,
  `project_features_fin_base_year_taken_rev` varchar(50) DEFAULT NULL,
  `project_features_fin_base_year_taken_lat_act` varchar(50) DEFAULT NULL,
  `project_features_fin_total_cost_org` varchar(50) DEFAULT NULL,
  `project_features_fin_total_cost_rev` varchar(50) DEFAULT NULL,
  `project_features_fin_total_cost_lat_act` varchar(50) DEFAULT NULL,
  `project_features_fin_dam_comp_org` varchar(50) DEFAULT NULL,
  `project_features_fin_dam_comp_rev` varchar(50) DEFAULT NULL,
  `project_features_fin_dam_comp_lat_act` varchar(50) DEFAULT NULL,
  `project_features_fin_irr_comp_org` varchar(50) DEFAULT NULL,
  `project_features_fin_irr_comp_rev` varchar(50) DEFAULT NULL,
  `project_features_fin_irr_comp_lat_act` varchar(50) DEFAULT NULL,
  `project_features_fin_wat_comp_org` varchar(50) DEFAULT NULL,
  `project_features_fin_wat_comp_rev` varchar(50) DEFAULT NULL,
  `project_features_fin_wat_comp_lat_act` varchar(50) DEFAULT NULL,
  `project_features_fin_ben_cst_rat_org` varchar(50) DEFAULT NULL,
  `project_features_fin_ben_cst_rat_rev` varchar(50) DEFAULT NULL,
  `project_features_fin_ben_cst_rat_lat_act` varchar(50) DEFAULT NULL,
  `project_features_fin_net_pre_val_org` varchar(50) DEFAULT NULL,
  `project_features_fin_net_pre_val_rev` varchar(50) DEFAULT NULL,
  `project_features_fin_net_pre_val_lat_act` varchar(50) DEFAULT NULL,
  `project_features_fin_int_rt_ret_org` varchar(50) DEFAULT NULL,
  `project_features_fin_int_rt_ret_rev` varchar(50) DEFAULT NULL,
  `project_features_fin_int_rt_ret_lat_act` varchar(50) DEFAULT NULL,
  `project_features_fin_pbck_per_org` varchar(50) DEFAULT NULL,
  `project_features_fin_pbck_per_rev` varchar(50) DEFAULT NULL,
  `project_features_fin_pbck_per_lat_act` varchar(50) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_basic_features_fishing`
--

CREATE TABLE `dh_basic_features_fishing` (
  `id` bigint(20) NOT NULL,
  `basic_features_fishing_sno` bigint(20) DEFAULT NULL,
  `project_identification_code` varchar(150) NOT NULL,
  `basic_features_fis_bene_no_of_beneficiaries_yr` varchar(20) DEFAULT NULL,
  `basic_features_fis_bene_com_yes_no` tinyint(1) DEFAULT NULL,
  `basic_features_fis_bene_com_beneficiaries` varchar(20) DEFAULT NULL,
  `basic_features_fis_bene_com_annual_yield_kg` varchar(20) DEFAULT NULL,
  `basic_features_fis_bene_rec_yes_no` tinyint(1) DEFAULT NULL,
  `basic_features_fis_bene_rec_beneficiaries` varchar(20) DEFAULT NULL,
  `basic_features_fis_bene_rec_annual_yield_kg` varchar(20) DEFAULT NULL,
  `basic_features_fis_bene_sub_yes_no` tinyint(1) DEFAULT NULL,
  `basic_features_fis_bene_sub_beneficiaries` varchar(20) DEFAULT NULL,
  `basic_features_fis_bene_sub_annual_yield_kg` varchar(20) DEFAULT NULL,
  `basic_features_fishing_others_remarks` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_basic_features_flood_control`
--

CREATE TABLE `dh_basic_features_flood_control` (
  `id` bigint(20) NOT NULL,
  `basic_features_flood_control_sno` bigint(20) DEFAULT NULL,
  `project_identification_code` varchar(150) NOT NULL,
  `basic_features_fl_ctrl_bene_rural_yes_no` tinyint(1) DEFAULT NULL,
  `basic_features_fl_ctrl_bene_rural_location` varchar(155) DEFAULT NULL,
  `basic_features_fl_ctrl_bene_rural_area` varchar(20) DEFAULT NULL,
  `basic_features_fl_ctrl_bene_rural_population` varchar(20) DEFAULT NULL,
  `basic_features_fl_ctrl_bene_semi_urban_yes_no` tinyint(1) DEFAULT NULL,
  `basic_features_fl_ctrl_bene_semi_urban_location` varchar(155) DEFAULT NULL,
  `basic_features_fl_ctrl_bene_semi_urban_area` varchar(20) DEFAULT NULL,
  `basic_features_fl_ctrl_bene_semi_urban_population` varchar(20) DEFAULT NULL,
  `basic_features_fl_ctrl_bene_urban_yes_no` tinyint(1) DEFAULT NULL,
  `basic_features_fl_ctrl_bene_urban_location` varchar(155) DEFAULT NULL,
  `basic_features_fl_ctrl_bene_urban_area` varchar(20) DEFAULT NULL,
  `basic_features_fl_ctrl_bene_urban_population` varchar(20) DEFAULT NULL,
  `basic_features_fl_ctrl_bene_metropolitan_yes_no` tinyint(1) DEFAULT NULL,
  `basic_features_fl_ctrl_bene_metropolitan_location` varchar(155) DEFAULT NULL,
  `basic_features_fl_ctrl_bene_metropolitan_area` varchar(20) DEFAULT NULL,
  `basic_features_fl_ctrl_bene_metropolitan_population` varchar(20) DEFAULT NULL,
  `basic_features_fl_ctrl_bene_remarks` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_basic_features_general`
--

CREATE TABLE `dh_basic_features_general` (
  `id` bigint(20) NOT NULL,
  `basic_features_general_sno` bigint(20) NOT NULL,
  `Project_Identification_Code` varchar(150) NOT NULL,
  `aternate_Name_1` text DEFAULT NULL,
  `aternate_Name_2` text DEFAULT NULL,
  `aternate_Name_3` text DEFAULT NULL,
  `project_category` text DEFAULT NULL,
  `basic_features_gen_type_pur_irrgation` tinyint(1) DEFAULT 0,
  `basic_features_gen_type_pur_hydropower` tinyint(1) NOT NULL DEFAULT 0,
  `basic_features_gen_type_pur_navigation` tinyint(1) NOT NULL DEFAULT 0,
  `basic_features_gen_type_pur_water_Supply` tinyint(1) NOT NULL DEFAULT 0,
  `basic_features_gen_type_pur_industrial` tinyint(1) NOT NULL DEFAULT 0,
  `basic_features_gen_type_pur_tourism` tinyint(1) NOT NULL DEFAULT 0,
  `basic_features_gen_type_pur_flood_Control` tinyint(1) NOT NULL DEFAULT 0,
  `basic_features_gen_type_pur_fish_Production` tinyint(1) NOT NULL DEFAULT 0,
  `basic_features_gen_type_pur_other_Benefits` tinyint(1) NOT NULL DEFAULT 0,
  `state_government_s` text DEFAULT NULL,
  `maintained_by_cwc` tinyint(1) NOT NULL DEFAULT 0,
  `primary_project_owner` text DEFAULT NULL,
  `primary_operator` text DEFAULT NULL,
  `project_planner` text DEFAULT NULL,
  `project_designer` text DEFAULT NULL,
  `basic_features_general_agency_remarks` text DEFAULT NULL,
  `current_Status` text DEFAULT NULL,
  `start_of_construction` text DEFAULT NULL,
  `first_impoundment` text DEFAULT NULL,
  `project_commissioned` text DEFAULT NULL,
  `project_decommissioned` text DEFAULT NULL,
  `basic_features_general_history_Remarks` text DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_basic_features_hydropower`
--

CREATE TABLE `dh_basic_features_hydropower` (
  `id` bigint(20) NOT NULL,
  `basic_features_Hydropower_sno` bigint(20) DEFAULT NULL,
  `project_identification_code` varchar(150) NOT NULL,
  `basic_features_hp_beneficiaries_remarks` text DEFAULT NULL,
  `basic_features_hp_gen_total_inst_Capacity` varchar(50) DEFAULT NULL,
  `basic_features_hp_gen_firm_power` varchar(50) DEFAULT NULL,
  `basic_features_hp_gen_an_ele_gen` varchar(50) DEFAULT NULL,
  `basic_features_hp_gen_base_load` varchar(50) DEFAULT NULL,
  `basic_features_hp_gen_remarks` text DEFAULT NULL,
  `basic_features_hp_system_types` varchar(50) DEFAULT NULL,
  `basic_features_hp_system_remarks` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_basic_features_industrial`
--

CREATE TABLE `dh_basic_features_industrial` (
  `id` bigint(20) NOT NULL,
  `basic_features_industrial_sno` bigint(20) DEFAULT NULL,
  `project_identification_code` varchar(150) NOT NULL,
  `basic_features_ind_bene_no_of_industries` varchar(20) DEFAULT NULL,
  `basic_features_ind_bene_heavy_yes_no` tinyint(1) DEFAULT NULL,
  `basic_features_ind_bene_heavy_industry` varchar(20) DEFAULT NULL,
  `basic_features_ind_bene_heavy_volume` varchar(20) DEFAULT NULL,
  `basic_features_ind_bene_manufacturing_yes_no` tinyint(1) DEFAULT NULL,
  `basic_features_ind_bene_manufacturing_industry` varchar(20) DEFAULT NULL,
  `basic_features_ind_bene_manufacturing_volume` varchar(20) DEFAULT NULL,
  `basic_features_ind_bene_thermal_power_yes_no` tinyint(1) DEFAULT NULL,
  `basic_features_ind_bene_thermal_power_industry` varchar(20) DEFAULT NULL,
  `basic_features_ind_bene_thermal_power_volume` varchar(20) DEFAULT NULL,
  `basic_features_ind_others_remarks` text DEFAULT NULL,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_basic_features_irrigation`
--

CREATE TABLE `dh_basic_features_irrigation` (
  `id` bigint(20) NOT NULL,
  `basic_features_irrigation_sno` bigint(20) DEFAULT NULL,
  `project_identification_code` varchar(150) NOT NULL,
  `basic_features_irr_bene_small_farms_yes_no` tinyint(1) DEFAULT NULL,
  `basic_features_irr_bene_small_farms_area` varchar(50) DEFAULT NULL,
  `basic_features_irr_bene_small_farms_population` varchar(50) DEFAULT NULL,
  `basic_features_irr_bene_medium_farms_yes_no` tinyint(1) DEFAULT NULL,
  `basic_features_irr_bene_medium_farms_area` varchar(50) DEFAULT NULL,
  `basic_features_irr_bene_medium_farms_population` varchar(50) DEFAULT NULL,
  `basic_features_irr_bene_large_farms_yes_no` tinyint(1) DEFAULT NULL,
  `basic_features_irr_bene_large_farms_area` varchar(50) DEFAULT NULL,
  `basic_features_irr_bene_large_farms_population` varchar(50) DEFAULT NULL,
  `basic_features_irr_bene_remarks` text DEFAULT NULL,
  `basic_features_irr_demand_gross_command_area` varchar(50) DEFAULT NULL,
  `basic_features_irr_demand_culturable_command_area` varchar(50) DEFAULT NULL,
  `basic_features_irr_demand_kharif_area` varchar(50) DEFAULT NULL,
  `basic_features_irr_demand_rabi_area` varchar(50) DEFAULT NULL,
  `basic_features_irr_demand_zaid_area` varchar(50) DEFAULT NULL,
  `basic_features_irr_demand_typical_year_av` varchar(50) DEFAULT NULL,
  `basic_features_irr_demand_dry_year_min` varchar(50) DEFAULT NULL,
  `basic_features_irr_demand_remarks` text DEFAULT NULL,
  `basic_features_irr_sys_unlined_canals_yes_no` tinyint(1) DEFAULT NULL,
  `basic_features_irr_sys_unlined_canals_main` varchar(50) DEFAULT NULL,
  `basic_features_irr_sys_unlined_canals_branch` varchar(50) DEFAULT NULL,
  `basic_features_irr_sys_unlined_canals_dist` varchar(50) DEFAULT NULL,
  `basic_features_irr_sys_lined_canals_yes_no` tinyint(1) DEFAULT NULL,
  `basic_features_irr_sys_lined_canals_main` varchar(50) DEFAULT NULL,
  `basic_features_irr_sys_lined_canals_branch` varchar(50) DEFAULT NULL,
  `basic_features_irr_sys_lined_canals_dist` varchar(50) DEFAULT NULL,
  `basic_features_irr_sys_pipes_yes_no` tinyint(1) DEFAULT NULL,
  `basic_features_irr_sys_pipes_main` varchar(50) DEFAULT NULL,
  `basic_features_irr_sys_pipes_branch` varchar(50) DEFAULT NULL,
  `basic_features_irr_sys_pipes_distributary` varchar(50) DEFAULT NULL,
  `basic_features_irr_sys_surface_yes_no` tinyint(1) DEFAULT NULL,
  `basic_features_irr_sys_surface` varchar(50) DEFAULT NULL,
  `basic_features_irr_sys_sprinkler_yes_no` tinyint(1) DEFAULT NULL,
  `basic_features_irr_sys_sprinkler` varchar(50) DEFAULT NULL,
  `basic_features_irr_sys_drip_yes_no` tinyint(1) DEFAULT NULL,
  `basic_features_irr_sys_drip` varchar(50) DEFAULT NULL,
  `basic_features_irr_sys_remarks` varchar(50) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_basic_features_location`
--

CREATE TABLE `dh_basic_features_location` (
  `id` bigint(20) NOT NULL,
  `basic_features_location_sno` bigint(20) NOT NULL,
  `project_identification_code` varchar(150) NOT NULL,
  `basic_features_location_administrative_district` varchar(15) DEFAULT NULL,
  `basic_features_location_administrative_nearest_city` varchar(15) DEFAULT NULL,
  `basic_features_loc_geo_dam_location_lat_decimal` varchar(50) DEFAULT NULL,
  `basic_features_loc_geo_dam_location_lat_deg` varchar(50) DEFAULT NULL,
  `basic_features_loc_geo_dam_location_lat_min` varchar(50) DEFAULT NULL,
  `basic_features_loc_geo_dam_location_lat_sec` varchar(50) DEFAULT NULL,
  `basic_features_loc_geo_dam_location_long_decimal` varchar(50) DEFAULT NULL,
  `basic_features_loc_geo_dam_location_long_deg` varchar(50) DEFAULT NULL,
  `basic_features_loc_geo_dam_location_long_min` varchar(50) DEFAULT NULL,
  `basic_features_loc_geo_dam_location_long_sec` varchar(50) DEFAULT NULL,
  `basic_features_loc_geo_project_area_latitude_from_decimal` varchar(50) DEFAULT NULL,
  `basic_features_loc_geo_project_area_latitude_from_deg` varchar(50) DEFAULT NULL,
  `basic_features_loc_geo_project_area_latitude_from_min` varchar(50) DEFAULT NULL,
  `basic_features_loc_geo_project_area_latitude_from_sec` varchar(50) DEFAULT NULL,
  `basic_features_loc_geo_project_area_latitude_to_decimal` varchar(50) DEFAULT NULL,
  `basic_features_loc_geo_project_area_latitude_to_deg` varchar(50) DEFAULT NULL,
  `basic_features_loc_geo_project_area_latitude_to_min` varchar(50) DEFAULT NULL,
  `basic_features_loc_geo_project_area_latitude_to_sec` varchar(50) DEFAULT NULL,
  `basic_features_loc_geo_project_area_longitude_from_decimal` varchar(50) DEFAULT NULL,
  `basic_features_loc_geo_project_area_longitude_from_deg` varchar(50) DEFAULT NULL,
  `basic_features_loc_geo_project_area_longitude_from_min` varchar(50) DEFAULT NULL,
  `basic_features_loc_geo_project_area_longitude_from_sec` varchar(50) DEFAULT NULL,
  `basic_features_loc_geo_project_area_longitude_to_decimal` varchar(50) DEFAULT NULL,
  `basic_features_loc_geo_project_area_longitude_to_deg` varchar(50) DEFAULT NULL,
  `basic_features_loc_geo_project_area_longitude_to_min` varchar(50) DEFAULT NULL,
  `basic_features_loc_geo_project_area_longitude_to_sec` varchar(50) DEFAULT NULL,
  `basic_features_location_geographical_seismic_zone` tinyint(1) DEFAULT NULL,
  `basic_features_location_geographical_remarks` text DEFAULT NULL,
  `basic_features_loc_acc_nearest_airport` varchar(100) DEFAULT NULL,
  `basic_features_loc_acc_nearest_airport_distance` text DEFAULT NULL,
  `basic_features_loc_acc_nearest_railway_station` varchar(100) DEFAULT NULL,
  `basic_features_loc_acc_nearest_railway_station_distance` text DEFAULT NULL,
  `basic_features_loc_acc_nearest_roadways_nh` varchar(100) DEFAULT NULL,
  `basic_features_loc_acc_nearest_roadways_nh_distance` text DEFAULT NULL,
  `basic_features_loc_acc_nearest_roadways_sh` varchar(100) DEFAULT NULL,
  `basic_features_loc_acc_nearest_roadways_sh_distance` text DEFAULT NULL,
  `basic_features_loc_acc_remarks` text DEFAULT NULL,
  `basic_features_loc_hydro_river_basin` varchar(100) DEFAULT NULL,
  `basic_features_loc_hydro_main_river` varchar(100) DEFAULT NULL,
  `basic_features_loc_hydro_up_stream_project` varchar(767) DEFAULT NULL,
  `basic_features_loc_hydro_down_stream_project` varchar(767) DEFAULT NULL,
  `basic_features_loc_hydro_up_stream_project_distance` text DEFAULT NULL,
  `basic_features_loc_hydro_down_stream_project_distance` text DEFAULT NULL,
  `basic_features_loc_hydro_int_aspects_issues_yes_no` text DEFAULT NULL,
  `basic_features_loc_hydro_int_aspects_issues` text DEFAULT NULL,
  `basic_features_loc_hydro_int_st_aspects_issues_yes_no` text DEFAULT NULL,
  `basic_features_loc_hydro_int_st_aspects_issues` text DEFAULT NULL,
  `basic_features_loc_hydro_remarks` text DEFAULT NULL,
  `update_timestamp` text DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_basic_features_navigation`
--

CREATE TABLE `dh_basic_features_navigation` (
  `id` bigint(20) NOT NULL,
  `basic_features_navigation_sno` bigint(20) DEFAULT NULL,
  `project_identification_code` varchar(150) NOT NULL,
  `basic_features_nav_bene_passengers_yr_Yes_No` tinyint(1) DEFAULT NULL,
  `basic_features_nav_bene_passengers_yr` text DEFAULT NULL,
  `basic_features_nav_bene_freight_Yr_Yes_No` tinyint(1) DEFAULT NULL,
  `basic_features_nav_bene_freight_Yr` text DEFAULT NULL,
  `basic_features_nav_bene_remarks` text DEFAULT NULL,
  `basic_features_nav_wway_length_of_waterway` text DEFAULT NULL,
  `basic_features_nav_wway_Imp_Inland_Ports` text DEFAULT NULL,
  `basic_features_nav_waterway_remarks` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_basic_features_other_benefits`
--

CREATE TABLE `dh_basic_features_other_benefits` (
  `id` bigint(20) NOT NULL,
  `basic_features_other_benefits_sno` bigint(20) DEFAULT NULL,
  `project_identification_code` varchar(150) NOT NULL,
  `basic_features_other_benefits_other_benefits_remarks` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_basic_features_tourism`
--

CREATE TABLE `dh_basic_features_tourism` (
  `id` bigint(20) NOT NULL,
  `basic_features_tourism_sno` bigint(20) DEFAULT NULL,
  `project_identification_code` varchar(150) NOT NULL,
  `basic_features_tourism_tourism_no_of_tourists_yr` varchar(20) DEFAULT NULL,
  `basic_features_tourism_tourism_religious` tinyint(1) DEFAULT NULL,
  `basic_features_tourism_tourism_boating_water_sports` tinyint(1) DEFAULT NULL,
  `basic_features_tourism_tourism_tours_cruises` tinyint(1) DEFAULT NULL,
  `basic_features_tourism_tourism_others` tinyint(1) DEFAULT NULL,
  `basic_features_tourism_tourism_others_specify` varchar(20) DEFAULT NULL,
  `basic_features_tourism_tourism_remarks` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_basic_features_water_supply`
--

CREATE TABLE `dh_basic_features_water_supply` (
  `id` bigint(20) NOT NULL,
  `basic_features_water_supply_sno` bigint(20) DEFAULT NULL,
  `project_identification_code` varchar(150) NOT NULL,
  `basic_features_ws_bene_rural_yes_no` tinyint(1) DEFAULT NULL,
  `basic_features_ws_bene_rural_location` varchar(155) DEFAULT NULL,
  `basic_features_ws_bene_rural_volume` varchar(20) DEFAULT NULL,
  `basic_features_ws_bene_rural_population` varchar(20) DEFAULT NULL,
  `basic_features_ws_bene_semi_urban_yes_no` tinyint(1) DEFAULT NULL,
  `basic_features_ws_bene_semi_urban_location` varchar(155) DEFAULT NULL,
  `basic_features_ws_bene_semi_urban_volume` varchar(20) DEFAULT NULL,
  `basic_features_ws_bene_semi_urban_population` varchar(20) DEFAULT NULL,
  `basic_features_ws_bene_urban_yes_no` tinyint(1) DEFAULT NULL,
  `basic_features_ws_bene_urban_location` varchar(155) DEFAULT NULL,
  `basic_features_ws_bene_urban_volume` varchar(20) DEFAULT NULL,
  `basic_features_ws_bene_urban_population` varchar(20) DEFAULT NULL,
  `basic_features_ws_bene_metropolitan_yes_no` tinyint(1) DEFAULT NULL,
  `basic_features_ws_bene_metropolitan_location` varchar(155) DEFAULT NULL,
  `basic_features_ws_bene_metropolitan_volume` varchar(20) DEFAULT NULL,
  `basic_features_ws_bene_metropolitan_population` varchar(20) DEFAULT NULL,
  `basic_features_ws_bene_remarks` text DEFAULT NULL,
  `basic_features_ws_sys_area_served` varchar(20) DEFAULT NULL,
  `basic_features_ws_sys_open_canal_channel_yes_no` tinyint(1) DEFAULT NULL,
  `basic_features_ws_sys_open_canal_channel` varchar(20) DEFAULT NULL,
  `basic_features_ws_sys_closed_pipe_tunnel_yes_no` tinyint(1) DEFAULT NULL,
  `basic_features_ws_sys_closed_pipe_tunnel` varchar(20) DEFAULT NULL,
  `basic_features_ws_remarks` text DEFAULT NULL,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_dashboard_inspection_report`
--

CREATE TABLE `dh_dashboard_inspection_report` (
  `dir_id` bigint(20) NOT NULL,
  `PIC` varchar(254) NOT NULL,
  `year` int(11) NOT NULL DEFAULT 0,
  `state_sno` int(11) DEFAULT NULL,
  `licsensee_sno` varchar(20) DEFAULT NULL,
  `pre_high` varchar(1) DEFAULT NULL,
  `pre_cat_1` varchar(11) DEFAULT NULL,
  `pre_cat_2` varchar(11) DEFAULT NULL,
  `pre_cat_3` varchar(11) DEFAULT NULL,
  `post_high` varchar(1) DEFAULT NULL,
  `post_cat_1` varchar(11) DEFAULT NULL,
  `post_cat_2` varchar(11) DEFAULT NULL,
  `post_cat_3` varchar(11) DEFAULT NULL,
  `update_on` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_engg_feat_access_road`
--

CREATE TABLE `dh_engg_feat_access_road` (
  `id` bigint(20) NOT NULL,
  `efar_sno` bigint(20) DEFAULT NULL,
  `node_id` bigint(20) NOT NULL,
  `ele_wor` varchar(20) DEFAULT NULL,
  `ele_wos` varchar(20) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_engg_feat_dam`
--

CREATE TABLE `dh_engg_feat_dam` (
  `id` bigint(20) NOT NULL,
  `efd_sno` bigint(20) DEFAULT NULL,
  `node_id` bigint(20) NOT NULL,
  `added_by` bigint(20) NOT NULL,
  `dim_ldb` float DEFAULT NULL,
  `dim_dtw` float DEFAULT NULL,
  `dim_halrbl` float DEFAULT NULL,
  `dim_halfl` float DEFAULT NULL,
  `dim_houspw` float DEFAULT NULL,
  `dim_bpw` float DEFAULT NULL,
  `dim_bpl` float DEFAULT NULL,
  `ele_dtl` float DEFAULT NULL,
  `ele_lrbl` float DEFAULT NULL,
  `ele_lfl` float DEFAULT NULL,
  `ele_lucl` float DEFAULT NULL,
  `ele_ldcl` float DEFAULT NULL,
  `vol_tervf` float DEFAULT NULL,
  `vol_tcv` float DEFAULT NULL,
  `vol_tmv` float DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_engg_feat_dam_block_reach`
--

CREATE TABLE `dh_engg_feat_dam_block_reach` (
  `id` bigint(20) NOT NULL,
  `efdbr_sno` bigint(20) DEFAULT NULL,
  `node_id` bigint(20) NOT NULL,
  `bl_wadt` varchar(20) DEFAULT NULL,
  `bl_waf` varchar(20) DEFAULT NULL,
  `bl_lob` varchar(20) DEFAULT NULL,
  `bl_lfl` varchar(20) DEFAULT NULL,
  `bl_gt` varchar(30) DEFAULT NULL,
  `bl_dog` varchar(20) DEFAULT NULL,
  `bl_sc` varchar(20) DEFAULT NULL,
  `bl_ec` varchar(20) DEFAULT NULL,
  `reach_wadt` varchar(20) DEFAULT NULL,
  `reach_waf` varchar(20) DEFAULT NULL,
  `reach_sc` varchar(20) DEFAULT NULL,
  `reach_ec` varchar(20) DEFAULT NULL,
  `reach_ft` varchar(30) DEFAULT NULL,
  `reach_ct` varchar(30) DEFAULT NULL,
  `reach_tt` varchar(30) DEFAULT NULL,
  `reach_dot` varchar(30) DEFAULT NULL,
  `reach_cpt` varchar(30) DEFAULT NULL,
  `reach_cpw` varchar(30) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_engg_feat_desilting_basin_chamber`
--

CREATE TABLE `dh_engg_feat_desilting_basin_chamber` (
  `id` bigint(20) NOT NULL,
  `efdbc_sno` bigint(20) DEFAULT NULL,
  `node_id` bigint(20) NOT NULL,
  `remarks` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_engg_feat_drain`
--

CREATE TABLE `dh_engg_feat_drain` (
  `id` bigint(20) NOT NULL,
  `efdr_sno` bigint(20) DEFAULT NULL,
  `node_id` bigint(20) NOT NULL,
  `slope_1_in` varchar(20) DEFAULT NULL,
  `dim_ln` varchar(20) DEFAULT NULL,
  `dim_wd` varchar(20) DEFAULT NULL,
  `dim_de` varchar(20) DEFAULT NULL,
  `dim_dia` varchar(20) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_engg_feat_energy_dissipation_structure`
--

CREATE TABLE `dh_engg_feat_energy_dissipation_structure` (
  `id` bigint(20) NOT NULL,
  `efeds_sno` bigint(20) DEFAULT NULL,
  `node_id` bigint(20) NOT NULL,
  `ele_twl` varchar(20) DEFAULT NULL,
  `ele_teotw` varchar(20) DEFAULT NULL,
  `ele_losb` varchar(20) DEFAULT NULL,
  `ele_br` varchar(20) DEFAULT NULL,
  `ele_bsbil` varchar(20) DEFAULT NULL,
  `ele_bll` varchar(20) DEFAULT NULL,
  `ele_bea` varchar(20) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_engg_feat_flexi_component`
--

CREATE TABLE `dh_engg_feat_flexi_component` (
  `id` bigint(20) NOT NULL,
  `effc_sno` bigint(20) DEFAULT NULL,
  `node_id` bigint(20) NOT NULL,
  `remarks` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_engg_feat_gallery_shaft`
--

CREATE TABLE `dh_engg_feat_gallery_shaft` (
  `id` bigint(20) NOT NULL,
  `efgs_sno` bigint(20) DEFAULT NULL,
  `node_id` bigint(20) NOT NULL,
  `ele_te` varchar(20) DEFAULT NULL,
  `ele_be` varchar(20) DEFAULT NULL,
  `shape_sogs` varchar(20) DEFAULT NULL,
  `dim_ln` varchar(20) DEFAULT NULL,
  `dim_ht` varchar(20) DEFAULT NULL,
  `dim_wd` varchar(20) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_engg_feat_hydromechanical`
--

CREATE TABLE `dh_engg_feat_hydromechanical` (
  `id` bigint(20) NOT NULL,
  `efh_sno` bigint(20) DEFAULT NULL,
  `node_id` bigint(20) NOT NULL,
  `gslbh_loc` varchar(25) DEFAULT NULL,
  `gslbh_wd` varchar(25) DEFAULT NULL,
  `gslbh_ht` varchar(25) DEFAULT NULL,
  `gslbh_dwh` varchar(25) DEFAULT NULL,
  `gslbh_sl` varchar(25) DEFAULT NULL,
  `gslbh_cil` varchar(25) DEFAULT NULL,
  `gslbh_te` varchar(25) DEFAULT NULL,
  `gslbh_at` varchar(25) DEFAULT NULL,
  `gslbh_wt` varchar(25) DEFAULT NULL,
  `gslbh_seal` varchar(25) DEFAULT NULL,
  `gslbh_sp` varchar(25) DEFAULT NULL,
  `gslbh_oc` varchar(25) DEFAULT NULL,
  `gslbh_hbm` varchar(25) DEFAULT NULL,
  `gslbh_oe` varchar(25) DEFAULT NULL,
  `gslbh_st` varchar(25) DEFAULT NULL,
  `hcgom_om` varchar(25) DEFAULT NULL,
  `hcgom_cap` varchar(25) DEFAULT NULL,
  `hcgom_lift` varchar(25) DEFAULT NULL,
  `hcgom_dl` varchar(25) DEFAULT NULL,
  `hcgom_now` varchar(25) DEFAULT NULL,
  `hcgom_wb` varchar(25) DEFAULT NULL,
  `hcgom_rg` varchar(25) DEFAULT NULL,
  `hcgom_cw` varchar(25) DEFAULT NULL,
  `hcgom_hos_hpkw` varchar(25) DEFAULT NULL,
  `hcgom_hos_rpm` varchar(25) DEFAULT NULL,
  `hcgom_hos_gpr` varchar(25) DEFAULT NULL,
  `hcgom_lt_hpkw` varchar(25) DEFAULT NULL,
  `hcgom_lt_rpm` varchar(25) DEFAULT NULL,
  `hcgom_lt_gpr` varchar(25) DEFAULT NULL,
  `hcgom_m_ct_hpkw` varchar(25) DEFAULT NULL,
  `hcgom_m_ct_rpm` varchar(25) DEFAULT NULL,
  `hcgom_m_ct_gpr` varchar(25) DEFAULT NULL,
  `hcgom_low` varchar(25) DEFAULT NULL,
  `hcgom_rai` varchar(25) DEFAULT NULL,
  `hcgom_long` varchar(25) DEFAULT NULL,
  `hcgom_inch` varchar(25) DEFAULT NULL,
  `hcgom_s_ct` varchar(25) DEFAULT NULL,
  `valves_sov` varchar(25) DEFAULT NULL,
  `valves_ecc` varchar(25) DEFAULT NULL,
  `valves_dwh` varchar(25) DEFAULT NULL,
  `valves_oc` varchar(25) DEFAULT NULL,
  `valves_om` varchar(25) DEFAULT NULL,
  `valves_or` varchar(25) DEFAULT NULL,
  `trs_rk_il` varchar(25) DEFAULT NULL,
  `trs_rk_te` varchar(25) DEFAULT NULL,
  `trs_rk_qty` varchar(25) DEFAULT NULL,
  `trs_rk_mech` varchar(25) DEFAULT NULL,
  `trs_rk_sh` varchar(25) DEFAULT NULL,
  `trs_rk_sp` varchar(25) DEFAULT NULL,
  `trs_rk_thic` varchar(25) DEFAULT NULL,
  `trs_rk_daf` varchar(25) DEFAULT NULL,
  `trs_rk_ddh` varchar(25) DEFAULT NULL,
  `trcm_me` varchar(25) DEFAULT NULL,
  `trcm_sgw` varchar(25) DEFAULT NULL,
  `trcm_om` varchar(25) DEFAULT NULL,
  `trcm_sgdt` varchar(25) DEFAULT NULL,
  `trcm_sbc` varchar(25) DEFAULT NULL,
  `trcm_low` varchar(25) DEFAULT NULL,
  `trcm_rai` varchar(25) DEFAULT NULL,
  `trcm_inch` varchar(25) DEFAULT NULL,
  `trcm_ct` varchar(25) DEFAULT NULL,
  `trcm_rg` varchar(25) DEFAULT NULL,
  `trcm_now` varchar(25) DEFAULT NULL,
  `trcm_wb` varchar(25) DEFAULT NULL,
  `trcm_cw` varchar(25) DEFAULT NULL,
  `trcm_aa` varchar(25) DEFAULT NULL,
  `trcm_ot` varchar(25) DEFAULT NULL,
  `trcm_sh_hpkw` varchar(25) DEFAULT NULL,
  `trcm_sh_rpm` varchar(25) DEFAULT NULL,
  `trcm_lt_hpkw` varchar(25) DEFAULT NULL,
  `trcm_lt_rpm` varchar(25) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_engg_feat_instrumentation`
--

CREATE TABLE `dh_engg_feat_instrumentation` (
  `id` bigint(20) NOT NULL,
  `efi_sno` bigint(20) DEFAULT NULL,
  `node_id` bigint(20) NOT NULL,
  `remarks` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_engg_feat_intake_outlet_structure`
--

CREATE TABLE `dh_engg_feat_intake_outlet_structure` (
  `id` bigint(20) NOT NULL,
  `efios` bigint(20) DEFAULT NULL,
  `node_id` bigint(20) NOT NULL,
  `ele_cl` varchar(20) DEFAULT NULL,
  `Remarks` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_engg_feat_power_house`
--

CREATE TABLE `dh_engg_feat_power_house` (
  `id` bigint(20) NOT NULL,
  `efph_sno` bigint(20) DEFAULT NULL,
  `node_id` bigint(20) NOT NULL,
  `Remarks` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_engg_feat_reservoir`
--

CREATE TABLE `dh_engg_feat_reservoir` (
  `id` bigint(20) NOT NULL,
  `efr_sno` bigint(20) DEFAULT NULL,
  `node_id` bigint(20) NOT NULL,
  `vol_gross_storage` varchar(25) DEFAULT NULL,
  `vol_live_storage` varchar(25) DEFAULT NULL,
  `vol_dead_storage` varchar(25) DEFAULT NULL,
  `vol_flood_cushion` varchar(25) DEFAULT NULL,
  `ele_mwl` varchar(25) DEFAULT NULL,
  `ele_frl` varchar(25) DEFAULT NULL,
  `ele_mddl` varchar(25) DEFAULT NULL,
  `ele_dsl` varchar(25) DEFAULT NULL,
  `other_catch_ar` varchar(25) DEFAULT NULL,
  `other_total_spillway` varchar(25) DEFAULT NULL,
  `other_res_sur_lvl_frl` varchar(25) DEFAULT NULL,
  `other_res_sur_lvl_mwl` varchar(25) DEFAULT NULL,
  `other_back_wtr_rch` varchar(25) DEFAULT NULL,
  `other_straight_fe` varchar(25) DEFAULT NULL,
  `other_wave_ht` varchar(25) DEFAULT NULL,
  `other_free_br` varchar(25) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_engg_feat_spillway`
--

CREATE TABLE `dh_engg_feat_spillway` (
  `id` bigint(20) NOT NULL,
  `efs_sno` bigint(20) DEFAULT NULL,
  `node_id` bigint(20) NOT NULL,
  `og_sh_tssw` varchar(25) DEFAULT NULL,
  `og_sh_nob` varchar(25) DEFAULT NULL,
  `og_sh_top` varchar(25) DEFAULT NULL,
  `og_sh_sce` varchar(25) DEFAULT NULL,
  `og_sh_dfl` varchar(25) DEFAULT NULL,
  `og_sh_sbl` varchar(25) DEFAULT NULL,
  `og_sh_locc` varchar(25) DEFAULT NULL,
  `dis_mdc` varchar(25) DEFAULT NULL,
  `ot_st_tl` varchar(25) DEFAULT NULL,
  `ot_st_ht` varchar(25) DEFAULT NULL,
  `ot_st_wd` varchar(25) DEFAULT NULL,
  `ot_st_dia` varchar(25) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_engg_feat_surge_tank_chamber`
--

CREATE TABLE `dh_engg_feat_surge_tank_chamber` (
  `id` bigint(20) NOT NULL,
  `efstc_sno` bigint(20) DEFAULT NULL,
  `node_id` bigint(20) NOT NULL,
  `remarks` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_engg_feat_turbine_pump`
--

CREATE TABLE `dh_engg_feat_turbine_pump` (
  `id` bigint(20) NOT NULL,
  `eftp_sno` bigint(20) DEFAULT NULL,
  `node_id` bigint(20) NOT NULL,
  `capct_dh` varchar(25) DEFAULT NULL,
  `capct_dd` varchar(25) DEFAULT NULL,
  `capct_ic` varchar(25) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_engg_feat_water_conveyance_structure`
--

CREATE TABLE `dh_engg_feat_water_conveyance_structure` (
  `id` bigint(20) NOT NULL,
  `efwcs_sno` bigint(20) DEFAULT NULL,
  `node_id` bigint(20) NOT NULL,
  `dis_mdd` varchar(25) DEFAULT NULL,
  `dis_fsl` varchar(25) DEFAULT NULL,
  `dim_tl` varchar(25) DEFAULT NULL,
  `dim_ht` varchar(25) DEFAULT NULL,
  `dim_wd` varchar(25) DEFAULT NULL,
  `dim_dia` varchar(25) DEFAULT NULL,
  `shape_sh` varchar(25) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_project_portfolio_node_type_attributes`
--

CREATE TABLE `dh_project_portfolio_node_type_attributes` (
  `id` bigint(20) NOT NULL,
  `project_portfolio_node_type_attributes_sno` bigint(20) DEFAULT NULL,
  `node_type` varchar(150) NOT NULL,
  `node_display` varchar(150) NOT NULL,
  `node_attribute` varchar(150) NOT NULL,
  `node_attribute_display` varchar(150) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_project_portfolio_tree`
--

CREATE TABLE `dh_project_portfolio_tree` (
  `id` bigint(20) NOT NULL,
  `sno` bigint(20) DEFAULT NULL,
  `pic` varchar(150) DEFAULT NULL,
  `node_type` varchar(150) NOT NULL,
  `node_name` varchar(150) DEFAULT NULL,
  `node_attribute` varchar(150) DEFAULT NULL,
  `parent_node` bigint(20) NOT NULL DEFAULT 0,
  `node_lat_decimal` varchar(150) DEFAULT NULL,
  `node_lat_deg` varchar(150) DEFAULT NULL,
  `node_lat_min` varchar(150) DEFAULT NULL,
  `node_lat_sec` varchar(150) DEFAULT NULL,
  `node_long_decimal` varchar(150) DEFAULT NULL,
  `node_long_deg` varchar(150) DEFAULT NULL,
  `node_long_min` varchar(150) DEFAULT NULL,
  `node_long_sec` varchar(150) DEFAULT NULL,
  `node_remarks` text DEFAULT NULL,
  `node_pos` int(11) NOT NULL DEFAULT 1,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_project_portfolio_tree_drawings`
--

CREATE TABLE `dh_project_portfolio_tree_drawings` (
  `id` bigint(20) NOT NULL,
  `sno` bigint(20) DEFAULT NULL,
  `pic` varchar(150) NOT NULL,
  `dh_project_portfolio_tree_id` bigint(20) NOT NULL,
  `image_pos` int(11) NOT NULL,
  `image_name` text NOT NULL,
  `image_remarks` text DEFAULT NULL,
  `Status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dh_project_portfolio_tree_images`
--

CREATE TABLE `dh_project_portfolio_tree_images` (
  `id` bigint(20) NOT NULL,
  `sno` bigint(20) DEFAULT NULL,
  `pic` varchar(150) NOT NULL,
  `dh_project_portfolio_tree_id` bigint(20) NOT NULL,
  `image_pos` int(11) NOT NULL,
  `image_name` text NOT NULL,
  `image_remarks` text DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dm_news`
--

CREATE TABLE `dm_news` (
  `id` bigint(20) NOT NULL,
  `title` varchar(150) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `attached_file` varchar(255) DEFAULT NULL,
  `news_date` date DEFAULT NULL,
  `status` tinyint(1) DEFAULT 0 COMMENT '0=active,1=Inactive',
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `document_library`
--

CREATE TABLE `document_library` (
  `document_id` bigint(20) NOT NULL,
  `PIC` varchar(254) NOT NULL,
  `document_title` varchar(250) DEFAULT NULL,
  `document_author` varchar(500) DEFAULT NULL,
  `document_type` varchar(100) DEFAULT NULL,
  `document_date` varchar(10) DEFAULT NULL,
  `inspection_type` varchar(50) DEFAULT NULL,
  `inspection_id` varchar(20) DEFAULT NULL,
  `document_file_name` text DEFAULT NULL,
  `document_type_other_detail` text DEFAULT NULL,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  `added_by` bigint(20) DEFAULT NULL,
  `IP_ADD` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inspection`
--

CREATE TABLE `inspection` (
  `inspection_id` int(11) NOT NULL,
  `inspection_identifier` text DEFAULT NULL,
  `PIC` varchar(254) NOT NULL,
  `post_pre` varchar(250) NOT NULL,
  `inspection_from_year` varchar(4) NOT NULL,
  `inspection_from` varchar(20) NOT NULL,
  `inspection_to` varchar(10) NOT NULL,
  `inspecting_officers` text DEFAULT NULL,
  `Insp_Det_Weather_Conditions` varchar(100) DEFAULT NULL,
  `Insp_Det_Reservoir_Level` varchar(50) DEFAULT NULL,
  `Insp_Det_Other_remarks` text DEFAULT NULL,
  `Insp_Det_Lic_Ad_remarks` text DEFAULT NULL,
  `Find_Gen_Remarks` text DEFAULT NULL,
  `Find_Key_Non_Comp` text DEFAULT NULL,
  `Rec_Key_Rcmndtns` text DEFAULT NULL,
  `IP_ADD` varchar(265) NOT NULL,
  `Added_by` bigint(20) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0-Deleted, 1-Active, 2-Submitted but Pending Verification from Authorised Person, 3-Reviewed but pending for requested changes, 4- Rejected, 5-Not Yet submitted'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permission_role`
--

CREATE TABLE `permission_role` (
  `role_id` bigint(20) NOT NULL,
  `permission_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `photos_schematics_resize_log`
--

CREATE TABLE `photos_schematics_resize_log` (
  `resize_sno` bigint(20) NOT NULL,
  `image_id` text NOT NULL,
  `upload_type` text NOT NULL,
  `PIC` text NOT NULL,
  `node_id` text NOT NULL,
  `Wide_190xHigh_120` tinyint(1) NOT NULL DEFAULT 0,
  `Wide_467xHigh_263` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  `created_by` bigint(20) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ref_airport_list`
--

CREATE TABLE `ref_airport_list` (
  `airport_sno` bigint(20) NOT NULL,
  `airport_name` varchar(767) NOT NULL,
  `state_sno` bigint(20) NOT NULL,
  `district_sno` bigint(20) NOT NULL,
  `created_by` bigint(20) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ref_basin_list`
--

CREATE TABLE `ref_basin_list` (
  `id` bigint(20) NOT NULL,
  `basin_name` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ref_dam_category`
--

CREATE TABLE `ref_dam_category` (
  `id` bigint(20) NOT NULL,
  `category_sno` bigint(20) DEFAULT NULL,
  `dam_category` varchar(767) NOT NULL,
  `dam_code` varchar(2) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ref_district`
--

CREATE TABLE `ref_district` (
  `id` bigint(20) NOT NULL,
  `District_Name` varchar(255) NOT NULL,
  `ref_state_id` bigint(20) NOT NULL,
  `Status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ref_document_type`
--

CREATE TABLE `ref_document_type` (
  `id` bigint(20) NOT NULL,
  `document_type` varchar(150) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `ref_license_category`
--

CREATE TABLE `ref_license_category` (
  `id` bigint(20) NOT NULL,
  `license_category` varchar(767) NOT NULL,
  `parent_id` bigint(20) NOT NULL DEFAULT 0,
  `license_main_category` varchar(767) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ref_license_lists`
--

CREATE TABLE `ref_license_lists` (
  `id` bigint(20) NOT NULL,
  `license_sno` bigint(20) DEFAULT NULL,
  `license_id` bigint(20) NOT NULL,
  `license_name` varchar(767) NOT NULL,
  `jurisdiction` text DEFAULT NULL,
  `dams` text DEFAULT NULL,
  `license_category` varchar(2) DEFAULT NULL,
  `license_sub_cat` varchar(2) DEFAULT NULL,
  `license_type` text DEFAULT NULL,
  `address_line_1` text DEFAULT NULL,
  `address_line_2` text DEFAULT NULL,
  `address_line_3` text DEFAULT NULL,
  `contact_person` text DEFAULT NULL,
  `designation` text DEFAULT NULL,
  `contact_e_mail` varchar(150) DEFAULT NULL,
  `phone_office` varchar(20) DEFAULT NULL,
  `phone_resi` varchar(20) DEFAULT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `fax` varchar(50) DEFAULT NULL,
  `mission_vision_and_policy` text DEFAULT NULL,
  `licensee_message` text DEFAULT NULL,
  `update_from_CDSO` text DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0-Active, 1-Inactive',
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ref_license_type`
--

CREATE TABLE `ref_license_type` (
  `id` bigint(20) NOT NULL,
  `license_type` varchar(150) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `ref_national_highway_list`
--

CREATE TABLE `ref_national_highway_list` (
  `id` bigint(20) NOT NULL,
  `national_highway_name` varchar(155) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ref_nrld`
--

CREATE TABLE `ref_nrld` (
  `id` bigint(20) NOT NULL,
  `NRLD_SNO` bigint(20) NOT NULL,
  `Project_Identification_Code` varchar(150) NOT NULL,
  `Name_of_Dam` varchar(255) NOT NULL,
  `Operated_Maintained_By` bigint(20) DEFAULT NULL COMMENT 'licensee_sno',
  `Basic_Features_Location_Administrative_State` bigint(20) NOT NULL,
  `Added_By_Licensee` bigint(20) NOT NULL,
  `Status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ref_railway_list`
--

CREATE TABLE `ref_railway_list` (
  `id` bigint(20) NOT NULL,
  `railway_station_name` varchar(767) NOT NULL,
  `ref_district_id` bigint(20) NOT NULL,
  `ref_state_id` bigint(20) NOT NULL,
  `status` smallint(6) DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ref_river_list`
--

CREATE TABLE `ref_river_list` (
  `id` bigint(20) NOT NULL,
  `river_name` varchar(155) NOT NULL,
  `ref_basin_list_id` bigint(20) DEFAULT NULL,
  `Status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ref_state`
--

CREATE TABLE `ref_state` (
  `id` bigint(20) NOT NULL,
  `State_CEN_ID` int(11) DEFAULT NULL,
  `State_Name` text NOT NULL,
  `State_Abbr` varchar(2) NOT NULL,
  `state_counter` text DEFAULT NULL,
  `state_color` varchar(100) DEFAULT NULL,
  `Status` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0=Active,1=Not Active',
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ref_state_highway_list`
--

CREATE TABLE `ref_state_highway_list` (
  `id` bigint(20) NOT NULL,
  `state_highway_name` varchar(100) NOT NULL,
  `ref_state_id` bigint(20) NOT NULL,
  `Status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ref_status`
--

CREATE TABLE `ref_status` (
  `id` int(11) NOT NULL,
  `status_code` varchar(10) DEFAULT NULL,
  `status_name` varchar(80) DEFAULT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` bigint(20) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `Gender` varchar(100) NOT NULL,
  `mobile_no` char(50) DEFAULT NULL,
  `golden_product` bigint(1) DEFAULT 0 COMMENT '1 = yes and 0 = no',
  `product_catalogue` bigint(1) DEFAULT 0 COMMENT '1 = yes and 0 = no',
  `day_free` bigint(1) DEFAULT 0 COMMENT '1 = yes and 0 = no',
  `created_by` bigint(20) NOT NULL DEFAULT 0,
  `updated_by` bigint(20) NOT NULL DEFAULT 0,
  `created_at` date DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_type` int(11) DEFAULT 0 COMMENT '1=>mis admin/2=>intra',
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `request_new_users`
--

CREATE TABLE `request_new_users` (
  `id` bigint(20) NOT NULL,
  `first_name` varchar(150) DEFAULT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `role` int(11) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `mobile_no` bigint(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `district` int(11) DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  `pin_code` int(11) DEFAULT NULL,
  `approve_reject_by` bigint(20) DEFAULT NULL,
  `status` tinyint(4) DEFAULT 0 COMMENT '0=pending,1=Approved,2=Rejected',
  `created_by` bigint(20) DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `application_type` tinyint(4) DEFAULT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `role_user`
--

CREATE TABLE `role_user` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sliders`
--

CREATE TABLE `sliders` (
  `id` int(11) NOT NULL,
  `title` varchar(150) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `slider_image` varchar(255) DEFAULT NULL,
  `type` tinyint(4) DEFAULT 0 COMMENT '0=Banner image,1=Gallary Image',
  `status` tinyint(1) DEFAULT 0 COMMENT '0=active,1=Inactive',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stakeholders_app_user`
--

CREATE TABLE `stakeholders_app_user` (
  `ss_sno` bigint(20) NOT NULL,
  `PIC` varchar(254) NOT NULL,
  `name` varchar(500) NOT NULL,
  `address` text DEFAULT NULL,
  `email_id` varchar(5000) NOT NULL,
  `mobile_no` varchar(15) NOT NULL,
  `designation` varchar(222) NOT NULL,
  `access_level` varchar(222) NOT NULL,
  `IP_ADD` text NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `added_by` bigint(20) NOT NULL,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stakeholders_beneficiary`
--

CREATE TABLE `stakeholders_beneficiary` (
  `ss_sno` bigint(20) NOT NULL,
  `PIC` varchar(254) NOT NULL,
  `beneficiary_type` varchar(100) NOT NULL,
  `beneficiary_name` varchar(255) NOT NULL,
  `designation` varchar(150) NOT NULL,
  `contact_person` varchar(255) NOT NULL,
  `contact_no` varchar(15) NOT NULL,
  `email_id` varchar(254) NOT NULL,
  `beneficiary_address` tinytext DEFAULT NULL,
  `added_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) NOT NULL,
  `IP_ADD` text NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp(),
  `added_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stakeholders_disaster_management`
--

CREATE TABLE `stakeholders_disaster_management` (
  `ss_sno` bigint(20) NOT NULL,
  `PIC` varchar(254) NOT NULL,
  `name` varchar(500) NOT NULL,
  `email_id` varchar(5000) NOT NULL,
  `mobile_no` varchar(15) NOT NULL,
  `designation` tinytext NOT NULL,
  `comment` text NOT NULL,
  `IP_ADD` text NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `added_by` bigint(20) DEFAULT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stakeholders_staff`
--

CREATE TABLE `stakeholders_staff` (
  `ss_sno` bigint(20) NOT NULL,
  `PIC` varchar(254) NOT NULL,
  `staff_name` varchar(500) NOT NULL,
  `designation` varchar(150) NOT NULL,
  `contact_no` varchar(15) NOT NULL,
  `personal_email_id` varchar(254) NOT NULL,
  `dharma_email_id` varchar(254) DEFAULT NULL,
  `stakeholder_address` tinytext DEFAULT NULL,
  `current_staff` varchar(5) NOT NULL,
  `joining_date` varchar(10) NOT NULL,
  `leaving_date` varchar(10) DEFAULT NULL,
  `added_by` bigint(20) NOT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `IP_ADD` text NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stakeholders_suppliers`
--

CREATE TABLE `stakeholders_suppliers` (
  `ss_sno` bigint(20) NOT NULL,
  `PIC` varchar(254) NOT NULL,
  `supplier_name` varchar(500) NOT NULL,
  `supplier_type` varchar(50) NOT NULL,
  `supplier_address` text NOT NULL,
  `contact_person` varchar(250) NOT NULL,
  `email_id` varchar(5000) NOT NULL,
  `designation` varchar(150) NOT NULL,
  `mobile_no` varchar(15) NOT NULL,
  `joining_date` varchar(10) DEFAULT NULL,
  `leaving_date` varchar(10) DEFAULT NULL,
  `added_by` bigint(20) NOT NULL,
  `IP_ADD` text NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mobile_no` char(50) DEFAULT NULL,
  `golden_product` bigint(1) DEFAULT 0,
  `product_catalogue` bigint(1) DEFAULT 0,
  `day_free` bigint(1) DEFAULT 0,
  `Gender` varchar(100) NOT NULL,
  `state` varchar(100) DEFAULT NULL,
  `district` int(11) DEFAULT NULL,
  `pin_code` varchar(10) DEFAULT NULL,
  `managed_by` varchar(50) DEFAULT NULL,
  `status` bigint(20) DEFAULT NULL,
  `created_by` bigint(20) NOT NULL DEFAULT 0,
  `owner_licensee` bigint(20) NOT NULL DEFAULT 0,
  `designation` varchar(150) DEFAULT '0',
  `off_tel_std_code` varchar(50) DEFAULT '0',
  `off_tel_number` varchar(50) DEFAULT '0',
  `complete_postal_add` text DEFAULT NULL,
  `auth_states` varchar(150) NOT NULL DEFAULT '',
  `updated_by` bigint(20) NOT NULL DEFAULT 0,
  `created_at` date DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_type` int(11) DEFAULT 0 COMMENT '1=>mis admin/2=>intra',
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `middle_name`, `last_name`, `user_name`, `password`, `email`, `mobile_no`, `golden_product`, `product_catalogue`, `day_free`, `Gender`, `state`, `district`, `pin_code`, `managed_by`, `status`, `created_by`, `owner_licensee`, `designation`, `off_tel_std_code`, `off_tel_number`, `complete_postal_add`, `auth_states`, `updated_by`, `created_at`, `updated_at`, `user_type`, `is_deleted`) VALUES
(57, 'Sourav', NULL, NULL, NULL, '123456', 'ss@gmail.com', '3654354635', NULL, NULL, 1, 'Male', NULL, NULL, NULL, NULL, 1, 0, 0, '0', '0', '0', NULL, '', 0, '2023-06-09', '2023-06-09 03:41:59', 1, 0),
(58, 'sourav', NULL, NULL, 'sssss@gmail.com', '123456', 'sssss@gmail.com', '7878787878', NULL, NULL, 1, 'Other', NULL, NULL, NULL, NULL, 1, 0, 0, '0', '0', '0', NULL, '', 0, '2023-06-09', '2023-06-09 04:48:41', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_basic_details`
--

CREATE TABLE `user_basic_details` (
  `sno` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `department` text DEFAULT NULL,
  `designation` text DEFAULT NULL,
  `contact_no` text DEFAULT NULL,
  `official_address` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_customization`
--

CREATE TABLE `user_customization` (
  `sno` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `Meter` tinyint(1) NOT NULL DEFAULT 1,
  `Feet` tinyint(1) NOT NULL DEFAULT 0,
  `KiloMeter` tinyint(1) NOT NULL DEFAULT 0,
  `Sq_Meter` tinyint(1) NOT NULL DEFAULT 1,
  `Sq_Feet` tinyint(1) NOT NULL DEFAULT 0,
  `Sq_KiloMeter` tinyint(1) NOT NULL DEFAULT 0,
  `Sq_Mile` tinyint(1) NOT NULL DEFAULT 0,
  `Acre` tinyint(1) NOT NULL DEFAULT 0,
  `Hectare` tinyint(1) NOT NULL DEFAULT 0,
  `M_Sq_Meter` tinyint(1) NOT NULL DEFAULT 0,
  `M_Acre` tinyint(1) NOT NULL DEFAULT 0,
  `M_Hectare` tinyint(4) NOT NULL DEFAULT 0,
  `Cu_Meter` tinyint(1) NOT NULL DEFAULT 1,
  `Cu_Feet` tinyint(1) NOT NULL DEFAULT 0,
  `BCM_Cu_KiloMeter` tinyint(1) NOT NULL DEFAULT 0,
  `Acre_Feet` tinyint(1) NOT NULL DEFAULT 0,
  `Cu_Hectometer` tinyint(1) NOT NULL DEFAULT 0,
  `M_Cu_Meter` tinyint(1) NOT NULL DEFAULT 0,
  `TMC_Th_M_Cu_Ft` tinyint(1) NOT NULL DEFAULT 0,
  `MAF_M_Acre_Feet` tinyint(1) NOT NULL DEFAULT 0,
  `Cumec` tinyint(1) NOT NULL DEFAULT 1,
  `Cusec` tinyint(1) NOT NULL DEFAULT 0,
  `Rs` tinyint(4) NOT NULL DEFAULT 0,
  `Thousand` tinyint(4) NOT NULL DEFAULT 1,
  `Lakhs` tinyint(4) NOT NULL DEFAULT 0,
  `Crores` tinyint(4) NOT NULL DEFAULT 0,
  `Million` tinyint(4) NOT NULL DEFAULT 0,
  `Billion` tinyint(1) NOT NULL DEFAULT 0,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_updated` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `_state_list`
--

CREATE TABLE `_state_list` (
  `State_SNO` bigint(20) NOT NULL,
  `State_CEN_ID` int(11) DEFAULT NULL,
  `State_Name` text DEFAULT NULL,
  `State_Abbr` varchar(2) DEFAULT NULL,
  `state_counter` text DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `Date_Added` timestamp NULL DEFAULT current_timestamp(),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  `Added_By` bigint(20) NOT NULL,
  `Status` tinyint(4) NOT NULL DEFAULT 1,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `asset_health_inspection`
--
ALTER TABLE `asset_health_inspection`
  ADD PRIMARY KEY (`inspection_id`);

--
-- Indexes for table `asset_health_inspection_details`
--
ALTER TABLE `asset_health_inspection_details`
  ADD PRIMARY KEY (`ahi_id`),
  ADD KEY `inspection_id` (`inspection_id`);

--
-- Indexes for table `asset_health_inspection_photos`
--
ALTER TABLE `asset_health_inspection_photos`
  ADD PRIMARY KEY (`SNO`),
  ADD KEY `ASSET_ID` (`insp_detail_id`,`added_by`),
  ADD KEY `added_by_index` (`added_by`);

--
-- Indexes for table `asset_health_inspection_questions`
--
ALTER TABLE `asset_health_inspection_questions`
  ADD PRIMARY KEY (`ahq_id`),
  ADD KEY `node_type_id` (`node_type_id`);

--
-- Indexes for table `asset_health_inspection_remedials`
--
ALTER TABLE `asset_health_inspection_remedials`
  ADD PRIMARY KEY (`SNO`);

--
-- Indexes for table `asset_health_instrumentation`
--
ALTER TABLE `asset_health_instrumentation`
  ADD PRIMARY KEY (`SN`,`N`,`status`,`PIC`) USING BTREE,
  ADD KEY `fk_PIC` (`PIC`);

--
-- Indexes for table `asset_health_instrumentation_remarks`
--
ALTER TABLE `asset_health_instrumentation_remarks`
  ADD PRIMARY KEY (`PIC`);

--
-- Indexes for table `asset_health_instruments_list`
--
ALTER TABLE `asset_health_instruments_list`
  ADD PRIMARY KEY (`SN`,`N`);

--
-- Indexes for table `asset_health_investigation`
--
ALTER TABLE `asset_health_investigation`
  ADD PRIMARY KEY (`investigation_id`) USING BTREE;

--
-- Indexes for table `asset_health_om_budget`
--
ALTER TABLE `asset_health_om_budget`
  ADD PRIMARY KEY (`budget_id`) USING BTREE;

--
-- Indexes for table `asset_health_om_manual`
--
ALTER TABLE `asset_health_om_manual`
  ADD PRIMARY KEY (`om_id`) USING BTREE;

--
-- Indexes for table `asset_rehabilitation_details`
--
ALTER TABLE `asset_rehabilitation_details`
  ADD PRIMARY KEY (`rehabilitation_id`);

--
-- Indexes for table `asset_rehabilitation_photos`
--
ALTER TABLE `asset_rehabilitation_photos`
  ADD PRIMARY KEY (`Sno`),
  ADD KEY `ASSET_ID` (`ASSET_ID`,`Added_By`),
  ADD KEY `added_by_index` (`Added_By`),
  ADD KEY `PIC` (`PIC`);

--
-- Indexes for table `basin_state_mapping`
--
ALTER TABLE `basin_state_mapping`
  ADD PRIMARY KEY (`id`),
  ADD KEY `basin_state_mapping_ref_state_fk` (`ref_state_id`),
  ADD KEY `basin_state_mapping_ref_basin_list_fk` (`ref_basin_list_id`);

--
-- Indexes for table `connectivity_master`
--
ALTER TABLE `connectivity_master`
  ADD PRIMARY KEY (`Connectivity_SNO`),
  ADD UNIQUE KEY `Connectivity_Type` (`Connectivity_Type`,`Connectivity_Code`),
  ADD KEY `Added_By` (`Added_By`);

--
-- Indexes for table `contact_page`
--
ALTER TABLE `contact_page`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `customization_units`
--
ALTER TABLE `customization_units`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `dashboard_inspection_report`
--
ALTER TABLE `dashboard_inspection_report`
  ADD PRIMARY KEY (`dir_id`);

--
-- Indexes for table `dashboard_static_licenseewise`
--
ALTER TABLE `dashboard_static_licenseewise`
  ADD PRIMARY KEY (`sno`),
  ADD UNIQUE KEY `licensee_sno` (`licensee_sno`);

--
-- Indexes for table `dashboard_static_licenseewise_damwise`
--
ALTER TABLE `dashboard_static_licenseewise_damwise`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `licensee_sno` (`pic`);

--
-- Indexes for table `dashboard_static_licenseewise_damwise_old`
--
ALTER TABLE `dashboard_static_licenseewise_damwise_old`
  ADD PRIMARY KEY (`sno`),
  ADD UNIQUE KEY `licensee_sno` (`pic`);

--
-- Indexes for table `deficiencies`
--
ALTER TABLE `deficiencies`
  ADD PRIMARY KEY (`def_id`),
  ADD KEY `inspection_id_2` (`inspection_id`);

--
-- Indexes for table `dharma_action_log`
--
ALTER TABLE `dharma_action_log`
  ADD PRIMARY KEY (`log_sno`),
  ADD KEY `reviewed_by` (`Reviewed_By`),
  ADD KEY `added_by` (`created_by`);

--
-- Indexes for table `dharma_cms`
--
ALTER TABLE `dharma_cms`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dh_asset_health_eap`
--
ALTER TABLE `dh_asset_health_eap`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dh_asset_health_eap_ref_nrld` (`PIC`) USING BTREE;

--
-- Indexes for table `dh_asset_health_eap_answer`
--
ALTER TABLE `dh_asset_health_eap_answer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dh_asset_health_eap_answer_dh_asset_health_eap_question` (`dh_asset_health_eap_question_id`);

--
-- Indexes for table `dh_asset_health_eap_question`
--
ALTER TABLE `dh_asset_health_eap_question`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dh_asset_health_eap_ques_ans`
--
ALTER TABLE `dh_asset_health_eap_ques_ans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dh_basic_features_financials`
--
ALTER TABLE `dh_basic_features_financials`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `project_identification_code` (`project_identification_code`);

--
-- Indexes for table `dh_basic_features_fishing`
--
ALTER TABLE `dh_basic_features_fishing`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `project_identification_code` (`project_identification_code`);

--
-- Indexes for table `dh_basic_features_flood_control`
--
ALTER TABLE `dh_basic_features_flood_control`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `project_identification_code` (`project_identification_code`);

--
-- Indexes for table `dh_basic_features_general`
--
ALTER TABLE `dh_basic_features_general`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dh_basic_features_general_ref_nrld_fk` (`Project_Identification_Code`);

--
-- Indexes for table `dh_basic_features_hydropower`
--
ALTER TABLE `dh_basic_features_hydropower`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `PIC` (`project_identification_code`);

--
-- Indexes for table `dh_basic_features_industrial`
--
ALTER TABLE `dh_basic_features_industrial`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `project_identification_code` (`project_identification_code`);

--
-- Indexes for table `dh_basic_features_irrigation`
--
ALTER TABLE `dh_basic_features_irrigation`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `project_identification_code` (`project_identification_code`);

--
-- Indexes for table `dh_basic_features_location`
--
ALTER TABLE `dh_basic_features_location`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `project_identification_code` (`project_identification_code`),
  ADD KEY `district` (`basic_features_location_administrative_district`),
  ADD KEY `nearest_city` (`basic_features_location_administrative_nearest_city`),
  ADD KEY `upstream_project_identification_code` (`basic_features_loc_hydro_up_stream_project`),
  ADD KEY `downstream_project_identification_code` (`basic_features_loc_hydro_down_stream_project`),
  ADD KEY `river_basin` (`basic_features_loc_hydro_river_basin`),
  ADD KEY `main_river` (`basic_features_loc_hydro_main_river`),
  ADD KEY `nearest_airport` (`basic_features_loc_acc_nearest_airport`),
  ADD KEY `nearest_railway_station` (`basic_features_loc_acc_nearest_railway_station`),
  ADD KEY `nearest_roadways_nh` (`basic_features_loc_acc_nearest_roadways_nh`),
  ADD KEY `nearest_roadways_sh` (`basic_features_loc_acc_nearest_roadways_sh`);

--
-- Indexes for table `dh_basic_features_navigation`
--
ALTER TABLE `dh_basic_features_navigation`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `project_identification_code` (`project_identification_code`);

--
-- Indexes for table `dh_basic_features_other_benefits`
--
ALTER TABLE `dh_basic_features_other_benefits`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `project_identification_code` (`project_identification_code`);

--
-- Indexes for table `dh_basic_features_tourism`
--
ALTER TABLE `dh_basic_features_tourism`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `project_identification_code` (`project_identification_code`);

--
-- Indexes for table `dh_basic_features_water_supply`
--
ALTER TABLE `dh_basic_features_water_supply`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `project_identification_code` (`project_identification_code`);

--
-- Indexes for table `dh_dashboard_inspection_report`
--
ALTER TABLE `dh_dashboard_inspection_report`
  ADD PRIMARY KEY (`dir_id`);

--
-- Indexes for table `dh_engg_feat_access_road`
--
ALTER TABLE `dh_engg_feat_access_road`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `node_id` (`node_id`);

--
-- Indexes for table `dh_engg_feat_dam`
--
ALTER TABLE `dh_engg_feat_dam`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `node_id` (`node_id`);

--
-- Indexes for table `dh_engg_feat_dam_block_reach`
--
ALTER TABLE `dh_engg_feat_dam_block_reach`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `node_id` (`node_id`);

--
-- Indexes for table `dh_engg_feat_desilting_basin_chamber`
--
ALTER TABLE `dh_engg_feat_desilting_basin_chamber`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `node_id` (`node_id`);

--
-- Indexes for table `dh_engg_feat_drain`
--
ALTER TABLE `dh_engg_feat_drain`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `node_id` (`node_id`);

--
-- Indexes for table `dh_engg_feat_energy_dissipation_structure`
--
ALTER TABLE `dh_engg_feat_energy_dissipation_structure`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `node_id` (`node_id`);

--
-- Indexes for table `dh_engg_feat_flexi_component`
--
ALTER TABLE `dh_engg_feat_flexi_component`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `node_id` (`node_id`);

--
-- Indexes for table `dh_engg_feat_gallery_shaft`
--
ALTER TABLE `dh_engg_feat_gallery_shaft`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `node_id` (`node_id`);

--
-- Indexes for table `dh_engg_feat_hydromechanical`
--
ALTER TABLE `dh_engg_feat_hydromechanical`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `node_id` (`node_id`);

--
-- Indexes for table `dh_engg_feat_instrumentation`
--
ALTER TABLE `dh_engg_feat_instrumentation`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `node_id` (`node_id`);

--
-- Indexes for table `dh_engg_feat_intake_outlet_structure`
--
ALTER TABLE `dh_engg_feat_intake_outlet_structure`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `node_id` (`node_id`);

--
-- Indexes for table `dh_engg_feat_power_house`
--
ALTER TABLE `dh_engg_feat_power_house`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `node_id` (`node_id`);

--
-- Indexes for table `dh_engg_feat_reservoir`
--
ALTER TABLE `dh_engg_feat_reservoir`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `node_id` (`node_id`);

--
-- Indexes for table `dh_engg_feat_spillway`
--
ALTER TABLE `dh_engg_feat_spillway`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `node_id` (`node_id`);

--
-- Indexes for table `dh_engg_feat_surge_tank_chamber`
--
ALTER TABLE `dh_engg_feat_surge_tank_chamber`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `node_id` (`node_id`);

--
-- Indexes for table `dh_engg_feat_turbine_pump`
--
ALTER TABLE `dh_engg_feat_turbine_pump`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `node_id` (`node_id`);

--
-- Indexes for table `dh_engg_feat_water_conveyance_structure`
--
ALTER TABLE `dh_engg_feat_water_conveyance_structure`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `node_id` (`node_id`);

--
-- Indexes for table `dh_project_portfolio_node_type_attributes`
--
ALTER TABLE `dh_project_portfolio_node_type_attributes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `node_type_node_attributes_UK` (`node_type`,`node_attribute`);

--
-- Indexes for table `dh_project_portfolio_tree`
--
ALTER TABLE `dh_project_portfolio_tree`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pic` (`pic`);

--
-- Indexes for table `dh_project_portfolio_tree_drawings`
--
ALTER TABLE `dh_project_portfolio_tree_drawings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dh_project_portfolio_tree_id` (`pic`);

--
-- Indexes for table `dh_project_portfolio_tree_images`
--
ALTER TABLE `dh_project_portfolio_tree_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pic` (`pic`);

--
-- Indexes for table `dm_news`
--
ALTER TABLE `dm_news`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `document_library`
--
ALTER TABLE `document_library`
  ADD PRIMARY KEY (`document_id`);

--
-- Indexes for table `inspection`
--
ALTER TABLE `inspection`
  ADD PRIMARY KEY (`inspection_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD KEY `permission_role_role_id_foreign` (`role_id`) USING BTREE,
  ADD KEY `permission_role_permission_id_foreign` (`permission_id`) USING BTREE;

--
-- Indexes for table `photos_schematics_resize_log`
--
ALTER TABLE `photos_schematics_resize_log`
  ADD PRIMARY KEY (`resize_sno`),
  ADD KEY `added_by` (`created_by`) USING BTREE;

--
-- Indexes for table `ref_airport_list`
--
ALTER TABLE `ref_airport_list`
  ADD PRIMARY KEY (`airport_sno`),
  ADD UNIQUE KEY `airport_name` (`airport_name`),
  ADD KEY `added_by` (`created_by`) USING BTREE;

--
-- Indexes for table `ref_basin_list`
--
ALTER TABLE `ref_basin_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ref_dam_category`
--
ALTER TABLE `ref_dam_category`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `dam_category` (`dam_category`,`dam_code`);

--
-- Indexes for table `ref_district`
--
ALTER TABLE `ref_district`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ref_document_type`
--
ALTER TABLE `ref_document_type`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `licensee_category` (`document_type`) USING BTREE;

--
-- Indexes for table `ref_license_category`
--
ALTER TABLE `ref_license_category`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `licensee_category` (`license_category`) USING BTREE;

--
-- Indexes for table `ref_license_lists`
--
ALTER TABLE `ref_license_lists`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ref_license_type`
--
ALTER TABLE `ref_license_type`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `licensee_category` (`license_type`) USING BTREE;

--
-- Indexes for table `ref_national_highway_list`
--
ALTER TABLE `ref_national_highway_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ref_nrld`
--
ALTER TABLE `ref_nrld`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `Project_Identification_Code` (`Project_Identification_Code`);

--
-- Indexes for table `ref_railway_list`
--
ALTER TABLE `ref_railway_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ref_river_list`
--
ALTER TABLE `ref_river_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ref_state`
--
ALTER TABLE `ref_state`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `State_Abbr` (`State_Abbr`),
  ADD UNIQUE KEY `State_CEN_ID` (`State_CEN_ID`);

--
-- Indexes for table `ref_state_highway_list`
--
ALTER TABLE `ref_state_highway_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ref_state_highway_list_ref_state_fk` (`ref_state_id`);

--
-- Indexes for table `ref_status`
--
ALTER TABLE `ref_status`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `request_new_users`
--
ALTER TABLE `request_new_users`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `role_user`
--
ALTER TABLE `role_user`
  ADD KEY `role_user_user_id_foreign` (`user_id`) USING BTREE,
  ADD KEY `role_user_role_id_foreign` (`role_id`) USING BTREE;

--
-- Indexes for table `sliders`
--
ALTER TABLE `sliders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stakeholders_app_user`
--
ALTER TABLE `stakeholders_app_user`
  ADD PRIMARY KEY (`ss_sno`);

--
-- Indexes for table `stakeholders_beneficiary`
--
ALTER TABLE `stakeholders_beneficiary`
  ADD PRIMARY KEY (`ss_sno`);

--
-- Indexes for table `stakeholders_disaster_management`
--
ALTER TABLE `stakeholders_disaster_management`
  ADD PRIMARY KEY (`ss_sno`);

--
-- Indexes for table `stakeholders_staff`
--
ALTER TABLE `stakeholders_staff`
  ADD PRIMARY KEY (`ss_sno`);

--
-- Indexes for table `stakeholders_suppliers`
--
ALTER TABLE `stakeholders_suppliers`
  ADD PRIMARY KEY (`ss_sno`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_name` (`user_name`);

--
-- Indexes for table `user_basic_details`
--
ALTER TABLE `user_basic_details`
  ADD PRIMARY KEY (`sno`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `user_customization`
--
ALTER TABLE `user_customization`
  ADD PRIMARY KEY (`sno`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `_state_list`
--
ALTER TABLE `_state_list`
  ADD PRIMARY KEY (`State_SNO`),
  ADD UNIQUE KEY `State_CEN_ID` (`State_CEN_ID`),
  ADD UNIQUE KEY `State_Abbr` (`State_Abbr`),
  ADD KEY `STATE_LIST_USER` (`Added_By`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `asset_health_inspection`
--
ALTER TABLE `asset_health_inspection`
  MODIFY `inspection_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7421;

--
-- AUTO_INCREMENT for table `asset_health_inspection_details`
--
ALTER TABLE `asset_health_inspection_details`
  MODIFY `ahi_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=809221;

--
-- AUTO_INCREMENT for table `asset_health_inspection_photos`
--
ALTER TABLE `asset_health_inspection_photos`
  MODIFY `SNO` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=672;

--
-- AUTO_INCREMENT for table `asset_health_inspection_questions`
--
ALTER TABLE `asset_health_inspection_questions`
  MODIFY `ahq_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1228;

--
-- AUTO_INCREMENT for table `asset_health_inspection_remedials`
--
ALTER TABLE `asset_health_inspection_remedials`
  MODIFY `SNO` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT for table `asset_health_investigation`
--
ALTER TABLE `asset_health_investigation`
  MODIFY `investigation_id` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `asset_health_om_budget`
--
ALTER TABLE `asset_health_om_budget`
  MODIFY `budget_id` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `asset_health_om_manual`
--
ALTER TABLE `asset_health_om_manual`
  MODIFY `om_id` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=297;

--
-- AUTO_INCREMENT for table `asset_rehabilitation_details`
--
ALTER TABLE `asset_rehabilitation_details`
  MODIFY `rehabilitation_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=427;

--
-- AUTO_INCREMENT for table `asset_rehabilitation_photos`
--
ALTER TABLE `asset_rehabilitation_photos`
  MODIFY `Sno` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=658;

--
-- AUTO_INCREMENT for table `basin_state_mapping`
--
ALTER TABLE `basin_state_mapping`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=224;

--
-- AUTO_INCREMENT for table `connectivity_master`
--
ALTER TABLE `connectivity_master`
  MODIFY `Connectivity_SNO` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contact_page`
--
ALTER TABLE `contact_page`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `customization_units`
--
ALTER TABLE `customization_units`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2483;

--
-- AUTO_INCREMENT for table `dashboard_inspection_report`
--
ALTER TABLE `dashboard_inspection_report`
  MODIFY `dir_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2024;

--
-- AUTO_INCREMENT for table `dashboard_static_licenseewise`
--
ALTER TABLE `dashboard_static_licenseewise`
  MODIFY `sno` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `dashboard_static_licenseewise_damwise`
--
ALTER TABLE `dashboard_static_licenseewise_damwise`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5744;

--
-- AUTO_INCREMENT for table `dashboard_static_licenseewise_damwise_old`
--
ALTER TABLE `dashboard_static_licenseewise_damwise_old`
  MODIFY `sno` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5637;

--
-- AUTO_INCREMENT for table `deficiencies`
--
ALTER TABLE `deficiencies`
  MODIFY `def_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10846;

--
-- AUTO_INCREMENT for table `dharma_action_log`
--
ALTER TABLE `dharma_action_log`
  MODIFY `log_sno` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1116587;

--
-- AUTO_INCREMENT for table `dharma_cms`
--
ALTER TABLE `dharma_cms`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `dh_asset_health_eap`
--
ALTER TABLE `dh_asset_health_eap`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=519;

--
-- AUTO_INCREMENT for table `dh_asset_health_eap_answer`
--
ALTER TABLE `dh_asset_health_eap_answer`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dh_asset_health_eap_question`
--
ALTER TABLE `dh_asset_health_eap_question`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `dh_asset_health_eap_ques_ans`
--
ALTER TABLE `dh_asset_health_eap_ques_ans`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1837;

--
-- AUTO_INCREMENT for table `dh_basic_features_financials`
--
ALTER TABLE `dh_basic_features_financials`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8198;

--
-- AUTO_INCREMENT for table `dh_basic_features_fishing`
--
ALTER TABLE `dh_basic_features_fishing`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8198;

--
-- AUTO_INCREMENT for table `dh_basic_features_flood_control`
--
ALTER TABLE `dh_basic_features_flood_control`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8194;

--
-- AUTO_INCREMENT for table `dh_basic_features_general`
--
ALTER TABLE `dh_basic_features_general`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5908;

--
-- AUTO_INCREMENT for table `dh_basic_features_hydropower`
--
ALTER TABLE `dh_basic_features_hydropower`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8197;

--
-- AUTO_INCREMENT for table `dh_basic_features_industrial`
--
ALTER TABLE `dh_basic_features_industrial`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8197;

--
-- AUTO_INCREMENT for table `dh_basic_features_irrigation`
--
ALTER TABLE `dh_basic_features_irrigation`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8197;

--
-- AUTO_INCREMENT for table `dh_basic_features_location`
--
ALTER TABLE `dh_basic_features_location`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8196;

--
-- AUTO_INCREMENT for table `dh_basic_features_navigation`
--
ALTER TABLE `dh_basic_features_navigation`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8196;

--
-- AUTO_INCREMENT for table `dh_basic_features_other_benefits`
--
ALTER TABLE `dh_basic_features_other_benefits`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8196;

--
-- AUTO_INCREMENT for table `dh_basic_features_tourism`
--
ALTER TABLE `dh_basic_features_tourism`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8194;

--
-- AUTO_INCREMENT for table `dh_basic_features_water_supply`
--
ALTER TABLE `dh_basic_features_water_supply`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8194;

--
-- AUTO_INCREMENT for table `dh_dashboard_inspection_report`
--
ALTER TABLE `dh_dashboard_inspection_report`
  MODIFY `dir_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2024;

--
-- AUTO_INCREMENT for table `dh_engg_feat_access_road`
--
ALTER TABLE `dh_engg_feat_access_road`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=919;

--
-- AUTO_INCREMENT for table `dh_engg_feat_dam`
--
ALTER TABLE `dh_engg_feat_dam`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6328;

--
-- AUTO_INCREMENT for table `dh_engg_feat_dam_block_reach`
--
ALTER TABLE `dh_engg_feat_dam_block_reach`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1152;

--
-- AUTO_INCREMENT for table `dh_engg_feat_desilting_basin_chamber`
--
ALTER TABLE `dh_engg_feat_desilting_basin_chamber`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `dh_engg_feat_drain`
--
ALTER TABLE `dh_engg_feat_drain`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=768;

--
-- AUTO_INCREMENT for table `dh_engg_feat_energy_dissipation_structure`
--
ALTER TABLE `dh_engg_feat_energy_dissipation_structure`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=558;

--
-- AUTO_INCREMENT for table `dh_engg_feat_flexi_component`
--
ALTER TABLE `dh_engg_feat_flexi_component`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=412;

--
-- AUTO_INCREMENT for table `dh_engg_feat_gallery_shaft`
--
ALTER TABLE `dh_engg_feat_gallery_shaft`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=372;

--
-- AUTO_INCREMENT for table `dh_engg_feat_hydromechanical`
--
ALTER TABLE `dh_engg_feat_hydromechanical`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=767;

--
-- AUTO_INCREMENT for table `dh_engg_feat_instrumentation`
--
ALTER TABLE `dh_engg_feat_instrumentation`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=499;

--
-- AUTO_INCREMENT for table `dh_engg_feat_intake_outlet_structure`
--
ALTER TABLE `dh_engg_feat_intake_outlet_structure`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=989;

--
-- AUTO_INCREMENT for table `dh_engg_feat_power_house`
--
ALTER TABLE `dh_engg_feat_power_house`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=140;

--
-- AUTO_INCREMENT for table `dh_engg_feat_reservoir`
--
ALTER TABLE `dh_engg_feat_reservoir`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5861;

--
-- AUTO_INCREMENT for table `dh_engg_feat_spillway`
--
ALTER TABLE `dh_engg_feat_spillway`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1059;

--
-- AUTO_INCREMENT for table `dh_engg_feat_surge_tank_chamber`
--
ALTER TABLE `dh_engg_feat_surge_tank_chamber`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `dh_engg_feat_turbine_pump`
--
ALTER TABLE `dh_engg_feat_turbine_pump`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;

--
-- AUTO_INCREMENT for table `dh_engg_feat_water_conveyance_structure`
--
ALTER TABLE `dh_engg_feat_water_conveyance_structure`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=933;

--
-- AUTO_INCREMENT for table `dh_project_portfolio_node_type_attributes`
--
ALTER TABLE `dh_project_portfolio_node_type_attributes`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=257;

--
-- AUTO_INCREMENT for table `dh_project_portfolio_tree`
--
ALTER TABLE `dh_project_portfolio_tree`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65548;

--
-- AUTO_INCREMENT for table `dh_project_portfolio_tree_drawings`
--
ALTER TABLE `dh_project_portfolio_tree_drawings`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8197;

--
-- AUTO_INCREMENT for table `dh_project_portfolio_tree_images`
--
ALTER TABLE `dh_project_portfolio_tree_images`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16406;

--
-- AUTO_INCREMENT for table `dm_news`
--
ALTER TABLE `dm_news`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `document_library`
--
ALTER TABLE `document_library`
  MODIFY `document_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1154;

--
-- AUTO_INCREMENT for table `inspection`
--
ALTER TABLE `inspection`
  MODIFY `inspection_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4181;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=140;

--
-- AUTO_INCREMENT for table `photos_schematics_resize_log`
--
ALTER TABLE `photos_schematics_resize_log`
  MODIFY `resize_sno` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22151;

--
-- AUTO_INCREMENT for table `ref_airport_list`
--
ALTER TABLE `ref_airport_list`
  MODIFY `airport_sno` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `ref_basin_list`
--
ALTER TABLE `ref_basin_list`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=131;

--
-- AUTO_INCREMENT for table `ref_dam_category`
--
ALTER TABLE `ref_dam_category`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `ref_district`
--
ALTER TABLE `ref_district`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3632;

--
-- AUTO_INCREMENT for table `ref_document_type`
--
ALTER TABLE `ref_document_type`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `ref_license_category`
--
ALTER TABLE `ref_license_category`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `ref_license_lists`
--
ALTER TABLE `ref_license_lists`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=129;

--
-- AUTO_INCREMENT for table `ref_license_type`
--
ALTER TABLE `ref_license_type`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `ref_national_highway_list`
--
ALTER TABLE `ref_national_highway_list`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=274;

--
-- AUTO_INCREMENT for table `ref_nrld`
--
ALTER TABLE `ref_nrld`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8200;

--
-- AUTO_INCREMENT for table `ref_railway_list`
--
ALTER TABLE `ref_railway_list`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=194;

--
-- AUTO_INCREMENT for table `ref_river_list`
--
ALTER TABLE `ref_river_list`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5289;

--
-- AUTO_INCREMENT for table `ref_state`
--
ALTER TABLE `ref_state`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `ref_state_highway_list`
--
ALTER TABLE `ref_state_highway_list`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2050;

--
-- AUTO_INCREMENT for table `ref_status`
--
ALTER TABLE `ref_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `request_new_users`
--
ALTER TABLE `request_new_users`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `sliders`
--
ALTER TABLE `sliders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `stakeholders_app_user`
--
ALTER TABLE `stakeholders_app_user`
  MODIFY `ss_sno` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `stakeholders_beneficiary`
--
ALTER TABLE `stakeholders_beneficiary`
  MODIFY `ss_sno` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `stakeholders_disaster_management`
--
ALTER TABLE `stakeholders_disaster_management`
  MODIFY `ss_sno` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `stakeholders_staff`
--
ALTER TABLE `stakeholders_staff`
  MODIFY `ss_sno` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=663;

--
-- AUTO_INCREMENT for table `stakeholders_suppliers`
--
ALTER TABLE `stakeholders_suppliers`
  MODIFY `ss_sno` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=573;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `user_basic_details`
--
ALTER TABLE `user_basic_details`
  MODIFY `sno` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_customization`
--
ALTER TABLE `user_customization`
  MODIFY `sno` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2684;

--
-- AUTO_INCREMENT for table `_state_list`
--
ALTER TABLE `_state_list`
  MODIFY `State_SNO` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `asset_health_instrumentation`
--
ALTER TABLE `asset_health_instrumentation`
  ADD CONSTRAINT `fk_PIC` FOREIGN KEY (`PIC`) REFERENCES `nrld_master` (`Project_Identification_Code`),
  ADD CONSTRAINT `fk_instrument` FOREIGN KEY (`SN`,`N`) REFERENCES `asset_health_instruments_list` (`SN`, `N`);

--
-- Constraints for table `asset_health_instrumentation_remarks`
--
ALTER TABLE `asset_health_instrumentation_remarks`
  ADD CONSTRAINT `fk_remarks_PIC` FOREIGN KEY (`PIC`) REFERENCES `nrld_master` (`Project_Identification_Code`);

--
-- Constraints for table `basin_state_mapping`
--
ALTER TABLE `basin_state_mapping`
  ADD CONSTRAINT `basin_state_mapping_ref_basin_list_fk` FOREIGN KEY (`ref_basin_list_id`) REFERENCES `ref_basin_list` (`id`),
  ADD CONSTRAINT `basin_state_mapping_ref_state_fk` FOREIGN KEY (`ref_state_id`) REFERENCES `ref_state` (`id`);

--
-- Constraints for table `connectivity_master`
--
ALTER TABLE `connectivity_master`
  ADD CONSTRAINT `CONNECTIVITY_MASTER_USER_SNO_FK` FOREIGN KEY (`Added_By`) REFERENCES `user_login` (`sno`);

--
-- Constraints for table `dh_asset_health_eap`
--
ALTER TABLE `dh_asset_health_eap`
  ADD CONSTRAINT `dh_asset_health_eap_ref_nrld` FOREIGN KEY (`PIC`) REFERENCES `ref_nrld` (`Project_Identification_Code`);

--
-- Constraints for table `dh_asset_health_eap_answer`
--
ALTER TABLE `dh_asset_health_eap_answer`
  ADD CONSTRAINT `dh_asset_health_eap_answer_dh_asset_health_eap_question` FOREIGN KEY (`dh_asset_health_eap_question_id`) REFERENCES `dh_asset_health_eap_question` (`id`);

--
-- Constraints for table `dh_basic_features_financials`
--
ALTER TABLE `dh_basic_features_financials`
  ADD CONSTRAINT `dh_basic_features_financials_ref_nrld` FOREIGN KEY (`project_identification_code`) REFERENCES `ref_nrld` (`Project_Identification_Code`);

--
-- Constraints for table `dh_basic_features_fishing`
--
ALTER TABLE `dh_basic_features_fishing`
  ADD CONSTRAINT `dh_basic_features_fishing_ref_nrld` FOREIGN KEY (`project_identification_code`) REFERENCES `ref_nrld` (`Project_Identification_Code`);

--
-- Constraints for table `dh_basic_features_flood_control`
--
ALTER TABLE `dh_basic_features_flood_control`
  ADD CONSTRAINT `dh_basic_features_flood_control_ref_nrld` FOREIGN KEY (`project_identification_code`) REFERENCES `ref_nrld` (`Project_Identification_Code`);

--
-- Constraints for table `dh_basic_features_general`
--
ALTER TABLE `dh_basic_features_general`
  ADD CONSTRAINT `dh_basic_features_general_ref_nrld_fk` FOREIGN KEY (`Project_Identification_Code`) REFERENCES `ref_nrld` (`Project_Identification_Code`);

--
-- Constraints for table `dh_basic_features_hydropower`
--
ALTER TABLE `dh_basic_features_hydropower`
  ADD CONSTRAINT `dh_basic_features_hydropower_ref_nrld_fk` FOREIGN KEY (`project_identification_code`) REFERENCES `ref_nrld` (`Project_Identification_Code`);

--
-- Constraints for table `dh_basic_features_industrial`
--
ALTER TABLE `dh_basic_features_industrial`
  ADD CONSTRAINT `dh_basic_features_industrial_ref_nrld` FOREIGN KEY (`project_identification_code`) REFERENCES `ref_nrld` (`Project_Identification_Code`);

--
-- Constraints for table `dh_basic_features_irrigation`
--
ALTER TABLE `dh_basic_features_irrigation`
  ADD CONSTRAINT `dh_basic_features_irriigation_ref_nrld` FOREIGN KEY (`project_identification_code`) REFERENCES `ref_nrld` (`Project_Identification_Code`);

--
-- Constraints for table `dh_basic_features_location`
--
ALTER TABLE `dh_basic_features_location`
  ADD CONSTRAINT `dh_basic_features_location_ref_nrld` FOREIGN KEY (`project_identification_code`) REFERENCES `ref_nrld` (`Project_Identification_Code`);

--
-- Constraints for table `dh_basic_features_navigation`
--
ALTER TABLE `dh_basic_features_navigation`
  ADD CONSTRAINT `basic_features_navigation_ref_nrld_fk` FOREIGN KEY (`project_identification_code`) REFERENCES `ref_nrld` (`Project_Identification_Code`);

--
-- Constraints for table `dh_basic_features_other_benefits`
--
ALTER TABLE `dh_basic_features_other_benefits`
  ADD CONSTRAINT `dh_basic_features_other_benefits_ref_nrld` FOREIGN KEY (`project_identification_code`) REFERENCES `ref_nrld` (`Project_Identification_Code`);

--
-- Constraints for table `dh_basic_features_tourism`
--
ALTER TABLE `dh_basic_features_tourism`
  ADD CONSTRAINT `dh_basic_features_tourism_ref_nrld` FOREIGN KEY (`project_identification_code`) REFERENCES `ref_nrld` (`Project_Identification_Code`);

--
-- Constraints for table `dh_basic_features_water_supply`
--
ALTER TABLE `dh_basic_features_water_supply`
  ADD CONSTRAINT `dh_basic_features_water_supply_ref_nrld` FOREIGN KEY (`project_identification_code`) REFERENCES `ref_nrld` (`Project_Identification_Code`);

--
-- Constraints for table `dh_project_portfolio_tree_drawings`
--
ALTER TABLE `dh_project_portfolio_tree_drawings`
  ADD CONSTRAINT `dh_project_portfolio_tree_drawings_ref_nrld` FOREIGN KEY (`pic`) REFERENCES `ref_nrld` (`Project_Identification_Code`);

--
-- Constraints for table `dh_project_portfolio_tree_images`
--
ALTER TABLE `dh_project_portfolio_tree_images`
  ADD CONSTRAINT `dh_project_portfolio_tree_images_ref_nrld` FOREIGN KEY (`pic`) REFERENCES `ref_nrld` (`Project_Identification_Code`);

--
-- Constraints for table `ref_state_highway_list`
--
ALTER TABLE `ref_state_highway_list`
  ADD CONSTRAINT `ref_state_highway_list_ref_state_fk` FOREIGN KEY (`ref_state_id`) REFERENCES `ref_state` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

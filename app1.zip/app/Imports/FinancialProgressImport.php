<?php

namespace App\Imports;
use Auth;
use App\Models\TempProgress;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;

class FinancialProgressImport implements ToModel, WithValidation, WithHeadingRow
{
    public function model(array $row)
    {
        //dd($row);
        $office = '';
        $scheme = '';
        $month = '';
        $type = '';
        $year = '';
        $fin = '';

        foreach ($row as $k=>$r){
            if($row['type'] == 'Progress'){
            $fin = new TempProgress([
                'key' => $k,
                'value' => $r,
                'office' => $row['offices'],
                'scheme' => $row['scheme'],
                'month' => $row['month'],
                'type' => $row['type'],
                'year' => $row['year'],
                'created_at' => now(),
                'created_by' => Auth::user()->id,
            ]);
            $fin->save();
            }
        }
//        foreach ($row as $k => $r) {
//
//            if ($k == 'offices') {
//                $office = $r;
//            }
//            if ($k == 'scheme') {
//                $scheme = $r;
//            }
//            if ($k == 'month') {
//                $month = $r;
//            }
//            if ($k == 'type') {
//                $type = $r;
//            }
//            if ($k == 'year') {
//                $year = $r;
//            }
//            $x[] = array(
//                'key' => $k,
//                'value' => $r,
//                'office' => $office,
//                'scheme' => $scheme,
//                'month' => $month,
//                'type' => $type,
//                'year' => $year,
////                'created_at' => now(),
//                'created_by' => Auth::user()->id,
//            );
//            $fin = new TempProgress([
//                'key' => $k,
//                'value' => $r,
//                'office' => $office,
//                'scheme' => $scheme,
//                'month' => $month,
//                'type' => $type,
//                'year' => $year,
//                'created_at' => now(),
//                'created_by' => Auth::user()->id,
//            ]);
//            $fin->save();
       // }

        //return $fin;
    }

    public function rules(): array
    {
        return [
            //'Offices' => ['required'],
        ];
    }

    /*
    * @author Prashant
    * Skip top heading Data
    */
//    public function headingRow(): int
//    {
//        return 1;
//    }

    public function limit(): int
    {
        return 100000; // only take 100 rows
    }
}

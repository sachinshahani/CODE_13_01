<?php

namespace App\Imports;

use App\Models\TempProgress;
use Auth;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;

class ImportFinancialProgress implements  ToModel, WithValidation, WithHeadingRow
{
    public function model(array $row)
    {
        $office = '';
        $fin = '';

        foreach ($row as $k => $r) {
            if ($k == 'offices') {
                $office = $r;
            }
            if($row['type'] == 'Progress') {
                $fin = new TempProgress([
                    'key' => $k,
                    'value' => $r,
                    'office' => $office,
                    'scheme' => $r['scheme'],
                    'month' => $r['month'],
                    'type' => $r['type'],
                    'created_at' => now(),
                    'created_by' => Auth::user()->id,
                ]);
                $fin->save();
            }
        }

        return $fin;
    }

    public function rules(): array
    {
        return [
            //'Offices' => ['required'],
        ];
    }

    /*
    * @author Prashant
    * Skip top heading Data
    */
    public function headingRow(): int
    {
        return 1;
    }
}

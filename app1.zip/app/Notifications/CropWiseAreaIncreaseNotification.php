<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class CropWiseAreaIncreaseNotification extends Notification
{
    use Queueable;

     public $total_area;
     public $farm_name;


    public function __construct($total_area, $farm_name)
    {

        $this->total_area=$total_area;
        $this->farm_name=$farm_name;
    }


    public function via($notifiable)
    {
        return ['database'];
    }


    public function toArray($notifiable)
    {
        return [

            'message' => "The certified area $this->total_area for Farm $this->farm_name"

        ];
    }
}




<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class ScopeAmendedNotification extends Notification
{
    use Queueable;

    public $opertor_name;
    public $name_cb;

    public function __construct($opertor_name, $name_cb)
    {
        $this->opertor_name = $opertor_name;
        $this->name_cb = $name_cb;
    }

    public function via($notifiable)
    {
        return ['database'];
    }

    public function toArray($notifiable)
    {
        return [
            'message' => "Tracenet Operator $this->opertor_name has applied for an amendment to their Scope Certificate by CB $this->name_cb."
        ];
    }
}

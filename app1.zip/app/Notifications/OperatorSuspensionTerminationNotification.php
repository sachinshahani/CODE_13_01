<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class OperatorSuspensionTerminationNotification extends Notification
{
    use Queueable;

    public $status;
    public $remark;
    public $cbname;
    public $opertor_name;


   public function __construct($status, $remark, $cbname, $opertor_name)
   {

       $this->status=$status;
       $this->remark=$remark;
       $this->cbname = $cbname;
       $this->opertor_name = $opertor_name;
   }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    // public function toMail($notifiable)
    // {
    //     return (new MailMessage)
    //                 ->line('The introduction to the notification.')
    //                 ->action('Notification Action', url('/'))
    //                 ->line('Thank you for using our application!');
    // }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */

    public function toArray($notifiable)
    {

        $statusMap = [
            1 => 'Suspended',
            2 => 'Terminated',
            3 => 'Withdrawal By CB',
            4 => 'Withdrawal By Operator',
            5 => 'De-Registered'
        ];

        $statusText = $statusMap[$this->status] ?? 'Unknown Status';



        return [
            'message' => "Tracenet operator $this->opertor_name $statusText with the remarks $this->remark by CB $this->cbname"
        ];
    }
}

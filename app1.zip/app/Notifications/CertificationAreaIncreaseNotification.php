<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class CertificationAreaIncreaseNotification extends Notification
{
    // protected $cbName;
    // protected $percentageIncrease;

    public $user;


    public function __construct($user)
    {
        $this->user = $user;
        // $this->percentageIncrease = $percentageIncrease;
    }

    public function via($notifiable)
    {
        return ['database'];
    }

    public function toArray($notifiable)
    {
        return [
            // 'message' => "The certified area for name has increased by 20 %.",

           // 'user_id' => $this->user['id'],
            'message' => "20 % Area Increase  {$this->user->first_name} has increased by 20%."
            // 'message' => "The certified area for {$this->user->name} has increased by 20%."
        ];
    }
}

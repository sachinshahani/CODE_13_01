<?php

namespace App\Exceptions;

use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Illuminate\Http\Exceptions\ThrottleRequestsException;
use Illuminate\Support\Facades\Log;
use Throwable;

class Handler extends ExceptionHandler
{
    /**
     * A list of exception types with their corresponding custom log levels.
     *
     * @var array<class-string<\Throwable>, \Psr\Log\LogLevel::*>
     */
    protected $levels = [
        //
    ];

    /**
     * A list of the exception types that are not reported.
     *
     * @var array<int, class-string<\Throwable>>
     */
    protected $dontReport = [
        //
    ];

    /**
     * A list of the inputs that are never flashed to the session on validation exceptions.
     *
     * @var array<int, string>
     */
    protected $dontFlash = [
        'current_password',
        'password',
        'password_confirmation',
    ];

    /**
     * Register the exception handling callbacks for the application.
     *
     * @return void
     */

     public function render($request, Throwable $exception)
     {
         
         if ($exception instanceof ThrottleRequestsException) {
             // Log the exception or dump it for debugging
             Log::debug('ThrottleRequestsException occurred', ['exception' => $exception]);
 
             // Optionally, use dd() for debugging (it will terminate the script)
             // dd($exception);
 
             return response()->json([
                 'message' => 'Too many attempts. Please try again later.',
                 'redirectUrl' => route('429'), // Redirect to a custom 429 page
             ], 429);
         }
 
         return parent::render($request, $exception);
     } 


    public function register()
    {
        $this->reportable(function (Throwable $e) {
            //
        });
    }
}

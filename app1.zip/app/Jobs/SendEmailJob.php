<?php
namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Foundation\Bus\Dispatchable; 
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Mail;
use App\Mail\AccountStatusUpdateMail;

class SendEmailJob
{
    use Dispatchable, Queueable, SerializesModels;
    protected $mailData;
    protected $userEmail;

    /**
     * Create a new job instance.
     *
     * @param  array  $mailData
     * @param  string $userEmail
     * @return void
     */
    public function __construct($mailData, $userEmail)
    {
        $this->mailData = $mailData;
        $this->userEmail = $userEmail;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        Mail::to($this->userEmail)->send(new AccountStatusUpdateMail($this->mailData['name'], $this->mailData['first_name'], $this->mailData['statusMessage']));
    }
}
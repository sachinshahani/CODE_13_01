<?php
namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class AccountStatusUpdateMail extends Mailable
{
    use Queueable, SerializesModels;

    public $name;
    public $first_name;
    public $statusMessage;

    public function __construct($name,$first_name, $statusMessage)
    {
        $this->name = $name;
        $this->first_name = $first_name;
        $this->statusMessage = $statusMessage;
    }

    public function build()
    {
        return $this->subject('Your TraceNet Account Status Update')
                    ->view('mail.account_status_update');
    }
}
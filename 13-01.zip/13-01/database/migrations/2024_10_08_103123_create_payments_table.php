<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('at_payments', function (Blueprint $table) {
            $table->id();
            $table->string('orderId')->nullable();
            $table->string('serviceId')->nullable();
            $table->decimal('amount', 8, 2); // 8 digits total, 2 decimal places
            $table->string('paymentMode')->nullable();
            $table->string('trackId')->nullable();
            $table->string('result')->nullable();
            $table->string('errorCode')->nullable();
            $table->string('errorDescription')->nullable();
            $table->string('paymentId')->nullable();
            $table->string('currency', 3)->default('INR');
            $table->timestamps(); // created_at, updated_at
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('at_payments');
    }
};

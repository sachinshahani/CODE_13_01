<?php

return [
    'changed_success' => 'Password changed successfully!',
    'not_match' => 'Password and Confirm Password not match!',
    'both_password_same' => 'Current Password and Confirm Password is same.',
    'current_not_match' => 'Current password not match with existing password.',
    'user' => "We can't find a user with that email address.",
    'add_success' => 'Submitted Successfully!',
    'add_first_success' => 'First step complete.Please enter values in second step!',
    'add_second_success' => 'Second step complete.Please enter values in third step!',
    'add_third_success' => 'Third step complete.Please enter values in fourth step!',
    'add_fourth_success' => 'Fourth step complete.Please enter values in Next step!',
    'add_fifth_success' => 'Fifth step completed.!',
];

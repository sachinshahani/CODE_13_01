<?php
// config/dompdf.php

return [
    'font_dir' => storage_path('fonts/'),  // Directory for fonts
    'font_cache' => storage_path('fonts/'), // Font cache directory

    // Register Hindi font
    'fonts' => [
        'NotoSansDevanagari' => storage_path('fonts/NotoSansDevanagari-Regular.ttf'),
    ],

    'font_subsetting' => true, // Allow font subsetting
    'options' => [
        'isHtml5ParserEnabled' => true, // Enable HTML5 parser
        'isPhpEnabled' => true,         // Enable PHP support
        'encoding' => 'UTF-8',          // Set encoding to UTF-8
    ],
];


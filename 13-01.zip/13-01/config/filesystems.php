<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Default Filesystem Disk
    |--------------------------------------------------------------------------
    |
    | Here you may specify the default filesystem disk that should be used
    | by the framework. The "local" disk, as well as a variety of cloud
    | based disks are available to your application. Just store away!
    |
    */

    'default' => env('FILESYSTEM_DISK', 'local'),

    /*
    |--------------------------------------------------------------------------
    | Filesystem Disks
    |--------------------------------------------------------------------------
    |
    | Here you may configure as many filesystem "disks" as you wish, and you
    | may even configure multiple disks of the same driver. Defaults have
    | been set up for each driver as an example of the required values.
    |
    | Supported Drivers: "local", "ftp", "sftp", "s3"
    |
    */
    'upload_directory' => env('UPLOAD_LOCAL_ROOT', '/var/www/html/apeda_upload_documents'),

    'encrypt_files' => env('ENCRYPT_FILES', false),
    'encryption_key' => env('APP_KEY'),

    'mime_check' => env('MIME_CHECK', false),

    'fc_pattern' => env('APP_FC_PATTERN', 'YY/MM/DD'),

   'cloud' => [
        'enabled' => env('USE_CLOUD_STORAGE', false),
        'server_url' => env('CLOUD_SERVER_URL', 'https://default-cloud-url.com'),
        'api_key' => env('CLOUD_API_KEY', 'default-api-key'),
        'upload_path' => env('CLOUD_UPLOAD_PATH', '/default/path'),
    ],

    'upload' => [
        'allowed_types' => explode(',', env('UPLOAD_ALLOWED_FILE_TYPES', 'jpg,jpeg,pdf')),
        'max_size' => env('UPLOAD_MAX_FILE_SIZE', 2048),
    ],
    'ftp' => [
    'driver' => 'ftp',
    'host' => env('FTP_HOST'),
    'username' => env('FTP_USERNAME'),
    'password' => env('FTP_PASSWORD'),
    ],
    
    'sftp' => [
        'driver' => 'sftp',
        'host' => env('SFTP_HOST'),
        'username' => env('SFTP_USERNAME'),
        'password' => env('SFTP_PASSWORD'),
        'root' => env('SFTP_ROOT', '/path/to/your/root'),
    ],


    'disks' => [

        'local' => [
            'driver' => 'local',
            'root' => storage_path('app'),
            'throw' => false,
        ],

        'public' => [
            'driver' => 'local',
            'root' => storage_path('app/public'),
            'url' => env('APP_URL').'/storage',
            'visibility' => 'public',
            'throw' => false,
        ],

        's3' => [
            'driver' => 's3',
            'key' => env('AWS_ACCESS_KEY_ID'),
            'secret' => env('AWS_SECRET_ACCESS_KEY'),
            'region' => env('AWS_DEFAULT_REGION'),
            'bucket' => env('AWS_BUCKET'),
            'url' => env('AWS_URL'),
            'endpoint' => env('AWS_ENDPOINT'),
            'use_path_style_endpoint' => env('AWS_USE_PATH_STYLE_ENDPOINT', false),
            'throw' => false,
        ],

    ],

    /*
    |--------------------------------------------------------------------------
    | Symbolic Links
    |--------------------------------------------------------------------------
    |
    | Here you may configure the symbolic links that will be created when the
    | `storage:link` Artisan command is executed. The array keys should be
    | the locations of the links and the values should be their targets.
    |
    */

    'links' => [
        public_path('storage') => storage_path('app/public'),
    ],

];

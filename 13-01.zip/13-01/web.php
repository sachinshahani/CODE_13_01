    <?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\MasterManagements;
use App\Http\Controllers\Admin\UserManagementController;
use App\Http\Controllers\Admin\MandatorManagementController;
use App\Http\Controllers\Admin\TradersUserController;
use App\Http\Controllers\Admin\WhTransactionController;
use App\Http\Controllers\Admin\IcsUserController;
use App\Http\Controllers\Admin\IndividualProducerController;
use App\Http\Controllers\Admin\WildHarvestController;
use App\Http\Controllers\Admin\ProcessorUserController;
use App\Http\Controllers\Admin\ProcessorController;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\SliderController;
use App\Http\Controllers\Admin\InternalApprovalController;
use App\Http\Controllers\Admin\TransactionCbCertificateController;
use App\Http\Controllers\Admin\ExternalApprovalController;
use App\Http\Controllers\Admin\ImportedIngredientController;
use App\Http\Controllers\Admin\ScopeCertificateController;
use App\Http\Controllers\Admin\InputApprovalController;
use App\Http\Controllers\Admin\HarvestUpdateController;
use App\Http\Controllers\Admin\ICSHarvestUpdateController;
use App\Http\Controllers\Admin\IPHarvestUpdateController;
use App\Http\Controllers\Admin\ClosingStockController;
use App\Http\Controllers\Admin\TransactionCertificateController;
use App\Http\Controllers\Admin\ProvisionalTCController;
use App\Http\Controllers\Admin\NOCController;
use App\Http\Controllers\Admin\MasterController;
use App\Http\Controllers\Admin\purchase\ICSPurchaseController;
use App\Http\Controllers\Admin\purchase\ProcessorPurchaseController;
use App\Http\Controllers\Admin\AccreditationController;
use App\Http\Controllers\Admin\HelpDeskController;
use App\Http\Controllers\Admin\MisReportController;
use App\Http\Controllers\Admin\SelfConsumptionController;
use App\Http\Controllers\Admin\EsignController;
use App\Http\Controllers\Admin\DigitalSignatureController;
use App\Http\Controllers\Admin\InternalStockTransferController;
use App\Http\Controllers\Admin\LabDashboardController;
use App\Http\Controllers\Admin\StockInventoryController;
use App\Http\Controllers\Admin\LotCreationController;
use App\Http\Controllers\Admin\ApedaMisReportController;
use App\Http\Controllers\Admin\NotificationController;
use App\Http\Controllers\Admin\OrganicRCAC;
use App\Http\Controllers\Admin\LoginHistory;
use App\Http\Controllers\PaymentGateway\PaymentController;
use App\Http\Controllers\Admin\EmployeeRoleController;
use App\Http\Controllers\Admin\AboutTracenet;
use App\Http\Controllers\DigitalSignDocumentController;

//emudhra Signer 
use App\Http\Controllers\DigitalSignature\emudhraeSignController;

use App\Http\Controllers\FileController;



//use App\Models\User;


use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\Request;

Route::group(['namespace' => '\Rap2hpoutre\LaravelLogViewer'], function () use ($router) {
    $router->get('logs', 'LogViewerController@index');
});
Route::get('/429', function () {
    return view('errors.429'); // Custom 429 error page
})->name('429');




Route::get('/clear-all', function() {
    // Artisan::call('cache:clear');
     Artisan::call('optimize:clear');
     /* Artisan::call('route:cache');
     Artisan::call('route:clear');
     Artisan::call('view:clear');
     Artisan::call('config:clear');
     Artisan::call('config:cache'); */
     // return what you want
      return '<h1>Clear all</h1>';
 });
 
// File Upload
// Route::post('/upload_document', [FileController::class, 'upload'])->name('upload_document.upload');
// Route::get('/document_download/{fileId}', [FileController::class, 'download'])->name('upload_document.download');
// Route::get('/document_get_files', [FileController::class, 'index'])->name('upload_document.index');
// Route::get('/document_show_files/{fileId}', [FileController::class, 'show'])->name('upload_document.show');
// Route::put('/update_document_files/{fileId}', [FileController::class, 'update'])->name('upload_document.update');
// Route::delete('/delets_document_files/{fileId}', [FileController::class, 'delete'])->name('upload_document.delete');

// Route::get('/backup-service', function () {
//     return view('backup-service');
// });

// Route::post('/backup-service-verify-email', function (Request $request) {
//     // Validate the email address
//     $request->validate([
//         'email' => 'required|email',
//     ]);

//     // List of valid emails
//     $validEmails = [
//         'vinay@velocis.co.in',
//         'sandeep.tripathi@velocis.co.in',
//         'babloo.yadav@velocis.co.in',
//         'vipul.dubey@velocis.co.in',
//     ];

//     // Check if the email exists in the valid emails list
//     if (in_array($request->email, $validEmails)) {
//         // Log the email click event
//         Log::info("Email verified and clicked for download: " . $request->email);

//         // Serve the file for download
//         return response()->download('/var/www/html/apeda/apeda_app_db.zip');
//     }

//     // Return an error message if the email is invalid
//     return back()->withErrors(['email' => 'Invalid email address.']);
// });
// Route::get('/reset-password/{id}', function ($id) {
//     // Find the user by ID
//     $user = User::find($id);

//     if ($user) {
//         // Set a temporary plain-text password (for example: '123456')
//         $plainPassword = '123456';
//         // Hash the plain-text password
//         $hashedPassword = hash('sha256', $plainPassword);
//         // Update the user's password
//         $user->password = $hashedPassword;
//         $user->save();

//         return "The user's password has been reset to: " . $plainPassword;
//     }

//     return 'User not found';
// })->name('reset.password');

Route::controller(UserManagementController::class)->group(function () {

    Route::get('/test-sms', 'testSms')->name('testSms');
});

Route::middleware([])->group(function () {
    Route::group(['middleware' => ['XSS', 'prevent-back-history']], function () {
        Route::controller(HomeController::class)->group(function () {
            // Route::get('/', 'home')->name('home');
            Route::get('/changeLang', 'changeLang')->name('changeLang');
            Route::get('getLocations', 'getLocations')->name('getLocations');
            Route::post('/reset-password-insp', 'submitRePassInsp')->name('submitRePassInsp');
            Route::get('reset-password/{token}', 'showResetPasswordForm')->name('showResetPasswordForm');
            Route::get('Organic-Operator', 'OrganicOperator')->name('OrganicOperator');
            Route::post('Organic-Operator-save', 'OrganicOperatorPost')->name('OrganicOperatorPost');
            Route::get('Conditions', 'Conditions')->name('superadmin.Conditions');
            Route::get('Conditions-Hindi', 'ConditionsHindi')->name('superadmin.ConditionsHindi');//added by kr
            Route::post('getCBID', 'getCBID')->name('getCBID');
            Route::post('getCBIDByOperator', 'getCBIDOperator')->name('getCBIDOperator');
            Route::post('OrganicOperatorgetDetailsPan', 'OrganicOperatorgetDetailsPan')->name('OrganicOperatorgetDetailsPan');

            Route::get('index', 'AccreditationPage')->name('AccreditationPage');
            Route::post('getStateIDDistrict', 'getStateIDDistrict')->name('getStateIDDistrict');
            Route::post('getDistrict-Block-Tehsil', 'getDistBlockTehsil')->name('getDistBlockTehsil');
            Route::post('get-village', 'getBlockTehsilVillage')->name('getBlockTehsilVillage');
            Route::get('Accreditation-login', 'Accreditationlogin')->name('Accreditationlogin');

            Route::post('/send-otp-reg', 'sendOtp')->name('sendOtpReg');
            Route::post('/verify-otp-reg',  'verifyOtp')->name('verifyOtpReg');

            Route::post('email-mobile-otp-reg', 'emailMobileOTP')->name('email_mobile_OTP_reg');
            Route::post('email-mobile-otp-check-reg', 'emailMobileOTPcheck')->name('email_mobile_OTP_check_reg');
        });
    });

    Route::controller(EsignController::class)->group(function () {
        //Route::get('getesignapprove', 'getesignapprove')->name('getesignapprove');
        Route::post('getesignapprove', 'getesignapprove')->name('getesignapprove');
        Route::post('getesignreturnapprove/{insp_id}/{user_id}/{token}', 'getesignreturnapprove')->name('getesignreturnapprove');

        Route::post('pancard', 'pancard')->name('pancard');
    });

    Route::controller(AuthController::class)->group(function () {
        Route::get('/', 'apedalogin')->name('apeda');
        Route::get('/home', 'apedalogin')->name('home');
        
        // Route::get('/apeda_admin', 'apedalogin')->name('apeda');
        Route::get('/apeda_admin-roles', 'apedaloginRolesSelect')->name('apedaloginRolesSelect');
        Route::post('/apeda_roles-store', 'apedaloginRolesstore')->name('apedaloginRolesstore');
        Route::get('lab-login', 'lab_login')->name('lab_login');
        Route::get('cb_signup&login', 'cb_login')->name('cb_login');
        Route::post('login-cb', 'login_cb')->name('mis.login_cb');
        Route::post('lab/login-lab', 'login_lab')->name('lab.login_lab');
        Route::get('/register', 'apedaregister')->name('register');
        Route::post('/register', 'register')->name('register');
        Route::get('/refresh_captcha', 'refreshCaptcha')->name('refresh_captcha');
        // Route::post('apeda_login', 'login')->name('mis.login')->middleware('throttle:3,2');
        Route::post('apeda_login', 'login')->name('mis.login');

        Route::get('/forget-password', 'showForgetPasswordForm')->name('forget.password.get');
        Route::post('/sendmail-forget-password', 'sendMailForgetPassword')->name('forget.password.sendmail');
        Route::get('/change-password/{email}', 'changePassword')->name('change.password');
        Route::post('/forget-password', 'submitForgetPasswordForm')->name('forget.password.post');
    });
});

Route::group(['middleware' => ['auth:misadmin', 'prevent-back-history'], 'prefix' => 'superadmin'], function () {
    Route::controller(AuthController::class)->group(function () {
        Route::get('/apeda_logout', 'logout')->name('superadmin.logout');
    });

    Route::controller(DashboardController::class)->group(function () {
        Route::match(array('GET', 'POST'), '/dashboard', 'dashboard')->name('superadmin.dashboard');
        // Route::get('two-Step-Authentication', 'twoStepAuth')->name('superadmin.twoStepAuth');
        Route::get('/super-admin-dashboard', 'superAdminDashboard')->name('superadmin.admin.dashboard');
        Route::get('cb', 'Cbdashboard')->name('superadmin.admin.Cbdashboard');
        Route::get('/profile', 'profile')->name('superadmin.profile');
        Route::get('/userprofile', 'userprofile')->name('superadmin.userprofile');
        Route::get('/change-password', 'changePassword')->name('superadmin.changePassword');
        Route::post('/change-password', 'changePasswordPost')->name('superadmin.changePasswordPost');

        Route::get('/announcement-list', 'announcementlist')->name('superadmin.announcementlist');

        Route::get('/change-current-password', 'chnageFirstPassword')->name('superadmin.chnageFirstPassword');
        Route::post('/update-change-current-password', 'updateChnageFirstPassword')->name('superadmin.updateChnageFirstPassword');
        Route::post('/update-change-current-password-skip', 'updateChnageFirstPasswordSkip')->name('superadmin.updateChnageFirstPasswordSkip');
        Route::post('/dashboard-ajax-call', 'dashboardajaxcall')->name('superadmin.dashboardajaxcall');

        Route::group(['middleware' => ['XSS', 'prevent-back-history']], function () {

            Route::get('add-lab', 'addLab')->name('superadmin.addLab');
            Route::post('lab_save', 'lab_save')->name('superadmin.lab_save');

            Route::get('registered-lab', 'registeredLab')->name('superadmin.registeredLab');
            Route::get('active-cb', 'activecb')->name('superadmin.activecb');
            Route::post('menu_id_get', 'menu_id_get')->name('superadmin.menu_id_get');
            Route::post('cbemSignKycUpdate', 'cbemSignKycUpdate')->name('superadmin.cbemSign-kyc-update');
            Route::post('cbemSignKycData', 'cbemSignKycData')->name('superadmin.cbemSign-kyc-data');
            Route::post('menupermissionupdate', 'menupermissionupdate')->name('superadmin.menupermissionupdate');
            Route::post('menupermissionupdate-store', 'menupermissionupdateStore')->name('superadmin.menupermissionupdateStore');
            Route::post('AccountTerminated', 'AccountTerminated')->name('superadmin.AccountTerminated');
            Route::post('templatecbterminatesus-store', 'templatecbterminatesus')->name('superadmin.templatecbterminatesus');

            Route::post('getstatIdByallow', 'getstatIdByallow')->name('superadmin.getstatIdByallow');
            Route::post('getstatIdByallow-store_id', 'getstatIdByallowstore_id')->name('superadmin.getstatIdByallowstore_id');
            Route::post('getstatIdByUpdate', 'getstatIdByUpdate')->name('superadmin.getstatIdByUpdate');



            Route::post('storepermissionmenu', 'storepermissionmenu')->name('superadmin.storepermissionmenu');
             // product - permission-------//
            Route::post('getCbByidRefproductpermission', 'getCbByidRefproductpermission')->name('superadmin.getCbByidRefproductpermission');
            Route::post('getCbByidRefproductpermissionStore', 'getCbByidRefproductpermissionStore')->name('superadmin.getCbByidRefproductpermissionStore');
            Route::post('getCbByidRefproductpermissionUpdate', 'getCbByidRefproductpermissionUpdate')->name('superadmin.getCbByidRefproductpermissionUpdate');


           // category - permission-------//
           Route::post('getCbByidcategorypermission', 'getCbByidcategorypermission')->name('superadmin.getCbByidcategorypermission');
           Route::post('getCbByidcategorypermissionstore', 'getCbByidcategorypermissionstore')->name('superadmin.getCbByidcategorypermissionstore');
           Route::post('getCbByidcategorypermissionupdate', 'getCbByidcategorypermissionupdate')->name('superadmin.getCbByidcategorypermissionupdate');


            Route::get('view-lab/{id?}', 'viewLab')->name('superadmin.viewLab');
            Route::get('assign-product/{id?}', 'assingProduct')->name('superadmin.assingProduct');
            Route::post('/form/upload', 'uploadFile')->name('superadmin.upload');
            Route::post('submit', 'submitForm')->name('superadmin.submitForm');

            Route::get('cb-registration', 'CbRegister')->name('superadmin.CbRegister');
            Route::get('aad-cb', 'AddCb')->name('superadmin.AddCb');
            Route::post('register', 'AddCbSave')->name('superadmin.register');

            Route::get('lab-register-list', 'lab_register_list')->name('superadmin.lab_register_list');
            Route::get('lab-register', 'lab_register')->name('superadmin.lab_register');
            Route::post('lab_register_save', 'lab_register_save')->name('superadmin.lab_register_save');


            Route::get('reports', 'reports')->name('superadmin.reports');
            Route::get('reports-search', 'ReportsSearch')->name('superadmin.ReportsSearch');

            Route::get('grower-group', 'GrowerGroup')->name('superadmin.GrowerGroup');
            Route::get('grower-group-search', 'GrowerGroupSearch')->name('superadmin.GrowerGroupSearch');

            Route::get('Ip-operator', 'IP')->name('superadmin.IP');
            Route::get('Ip-operator-search', 'IpSearch')->name('superadmin.IpSearch');

            Route::get('WH-operator', 'Wh')->name('superadmin.Wh');
            Route::get('Wh-operator-search', 'WhSearch')->name('superadmin.WhSearch');


            Route::get('Processor-operator', 'Processor')->name('superadmin.Processor');
            Route::get('Processor-operator-search', 'ProcessorSearch')->name('superadmin.ProcessorSearch');


            Route::get('Trader-operator', 'Trader')->name('superadmin.Trader');
            Route::get('Trader-operator-search', 'TraderSearch')->name('superadmin.TraderSearch');


            Route::get('Farmers', 'Farmer')->name('superadmin.Farmer');
            Route::get('Farmer-search', 'FarmerSearch')->name('superadmin.FarmerSearch');

            Route::get('Farms', 'Farms')->name('superadmin.Farm');
            Route::get('Farm-search', 'FarmsSearch')->name('superadmin.FarmSearch');
        });

        Route::get('Products', 'Products')->name('superadmin.Products');
        Route::get('Products-search', 'ProductsSearch')->name('superadmin.ProductsSearch');
    });

    //Vinit route
    Route::group(['middleware' => ['XSS', 'prevent-back-history']], function () {
        Route::controller(LabDashboardController::class)->group(function () {
            Route::get('lab-dashboard', 'lab_dashboard')->name('superadmin.lab.dashboard');
            Route::get('lab-sampling-collection', 'sampling_collection_lot_list')->name('superadmin.lab.sampling_collection_lot_list');
            Route::get('lab-sampling-collection-view/{id?}', 'lab_sampling_collection_view')->name('superadmin.lab.lab_sampling_collection_view');
            Route::get('lab-sampling-receipt', 'sampling_receiplat_list')->name('superadmin.lab.sampling_receiplat_list');
            Route::get('lab-sampling-collection-proceed/{id?}', 'lab_sampling_collection_proceed')->name('superadmin.lab.lab_sampling_collection_proceed');
            Route::post('save-sample-details', 'save_sample_details')->name('superadmin.lab.save_sample_details');

            Route::get('lab-sampling-receipt-view/{id?}', 'lab_sampling_receiplat_view')->name('superadmin.lab.lab_sampling_receiplat_view');

            Route::post('forward-sample-details', 'forward_sample_details')->name('superadmin.lab.forward_sample_details');

            Route::get('test-rest-entry', 'test_rest_entry')->name('superadmin.lab.test_rest_entry');
            Route::get('test-rest-entry-view/{id?}', 'test_rest_entry_view')->name('superadmin.lab.test_rest_entry_view');

            Route::get('genrate-test-report', 'genrate_test_report')->name('superadmin.lab.genrate_test_report');
            Route::get('genrate-test-report-view/{id?}', 'genrate_test_report_view')->name('superadmin.lab.genrate_test_report_view');

            Route::get('superadmin/lab/test-rest-entry-generate/{id}', 'test_rest_entry_genrate')
                ->name('superadmin.lab.test_rest_entry_genrate');
            Route::post('lab-test-save', 'lab_test_save')->name('superadmin.lab.lab_test_save');
            Route::get('genrate-test-report-html-version/{id?}', 'genrate_test_report_html_version')->name('superadmin.lab.genrate_test_report_html_version');


            Route::get('test-report-summary', 'test_report_summary')->name('superadmin.lab.test_report_summary');
            Route::get('manage-test-para', 'manage_test_para')->name('superadmin.lab.manage_test_para');
            Route::get('manage-user', 'manage_user_list')->name('superadmin.lab.manage_user_list');
            Route::get('add-user', 'add_user')->name('superadmin.lab.add_user');


            Route::get('genrate_test_report_download/{id?}', 'genrate_test_report_download')->name('superadmin.lab.genrate_test_report_download');
        });
    });





    Route::resource('slider', SliderController::class);
    Route::post('slider/delete', 'App\Http\Controllers\SliderController@destroy')->name('slider.delete');
    //Route::post('schemehead/delete/{id}', 'App\Http\Controllers\Admin\SchemeHeadController@destroy')->name('schemehead.delete');

    Route::controller(MasterManagements::class)->group(function () {
        //     Route::get('/master/mastermanage', 'mastermanage')->name('superadmin.master.mastermanage');

        //     Route::get('/scheme', 'schemeindex')->name('superadmin.scheme.schemeindex');
        //     Route::get('/scheme/schemeadd', 'schemeadd')->name('superadmin.scheme.add');
        //     Route::post('/scheme/schemestore', 'schemestore')->name('admin.scheme.store');
        //     Route::get('/scheme/schemeedit/{id}', 'schemeedit')->name('superadmin.scheme.edit');
        //     Route::post('/scheme/schemeupdate/{id}', 'schemeupdate')->name('admin.scheme.update');

        //     Route::get('/master/statelist', 'statelist')->name('superadmin.master.state');
        //     Route::get('/master/activity', 'activityindex')->name('superadmin.master.activity');
        //     Route::get('/master/activityadd', 'activityadd')->name('superadmin.master.activity.add');
        //     Route::post('/master/activitystore', 'activitystore')->name('superadmin.master.activity.store');
        //     Route::post('/master/activitydelete', 'activitydelete')->name('superadmin.master.activity.delete');
        //     Route::get('/master/previewactivity/{id}/{scheme_id}', 'previewactivity')->name('superadmin.master.previewactivity');
        Route::post('/master/statelist', 'statedropdownlist')->name('admin.master.ajax.statelist');
        Route::post('master/getBlock', 'getBlock')->name('admin.master.ajax.getBlock');
        Route::post('master/getVillage', 'getVillage')->name('admin.master.ajax.getVillage');

        //     Route::post('/master/statelistAll', 'statedropdownlistAll')->name('admin.master.ajax.statelistAll');
        //     Route::post('/master/activitylist', 'activitydropdownlist')->name('admin.master.ajax.activitylist');
        //     Route::post('/master/activitylistAll', 'activitydropdownlistAll')->name('admin.master.ajax.activitylistAll');
        //     Route::post('/master/activitylistmultipleyear', 'activitydropdownlistmultipleyear')->name('admin.master.ajax.activitylistmultipleyear');
        //     Route::post('/master/getMisActivityDropDownHtml', 'getMisActivityDropDownHtml')->name('admin.mis.getMisActivityDropDown');
        //     Route::post('/master/getMisActivityPositionCode', 'getMisActivityPositionCode')->name('admin.mis.getMisActivityPositionCode');


        //     Route::get('/master/offices', 'officesIndex')->name('superadmin.master.offices');
        //     Route::get('/master/offices/add', 'officesAdd')->name('superadmin.master.officesAdd');
        //     Route::post('/master/offices/store', 'officesStore')->name('superadmin.master.officesStore');
        //     Route::get('/master/offices/edit/{id}', 'officesEdit')->name('superadmin.master.officesEdit');
        //     Route::post('/master/offices/update/{id}', 'officesUpdate')->name('superadmin.master.officesUpdate');
        //     Route::post('/master/offices/delete', 'officesDelete')->name('superadmin.master.officesDelete');
        //     Route::post('/master/officelist', 'officedropdownlist')->name('admin.master.ajax.officelist');
        //     Route::post('/master/officelistAll', 'officedropdownlistAll')->name('admin.master.ajax.officelistAll');
        //     Route::post('/master/zonelist', 'zonedropdownlist')->name('admin.master.ajax.zonelist');
        //     Route::post('/master/zonelistAll', 'zonedropdownlistAll')->name('admin.master.ajax.zonelistAll');


        //     //members master
        //     Route::get('/master/members', 'membersIndex')->name('superadmin.master.members');
        //     Route::get('/master/members/add', 'membersAdd')->name('superadmin.master.membersAdd');
        //     Route::post('/master/members/store', 'membersStore')->name('superadmin.master.membersStore');
        //     Route::get('/master/members/edit/{id}', 'membersEdit')->name('superadmin.master.membersEdit');
        //     Route::post('/master/members/update/{id}', 'membersUpdate')->name('superadmin.master.membersUpdate');
        //     Route::post('/master/members/delete', 'membersDelete')->name('superadmin.master.membersDelete');
    });

    Route::controller(ZoneMasterController::class)->group(function () {
        //     //     Route::get('/master/zone', 'index')->name('superadmin.master.zone');
        //     //     Route::get('/master/zone/add', 'add')->name('superadmin.master.zone.add');
        //     //     Route::get('/master/zone/edit/{id}', 'edit')->name('superadmin.master.zone.edit');
        //     //     Route::post('/master/zone/store', 'store')->name('superadmin.master.zone.store');
        //     //     Route::post('/master/zone/update/{id}', 'update')->name('superadmin.master.zone.update');
        //
        Route::post('/master/zone/delete', 'destroy')->name('superadmin.master.zone.delete');
        //     //     Route::post('/master/zone/changeStatus', 'changeStatus')->name('superadmin.master.zone.changeStatus');
    });

    Route::group(['middleware' => ['XSS', 'prevent-back-history']], function () {


        Route::controller(UserManagementController::class)->group(function () {

            Route::get('usermanagement/rolesList', 'rolesList')->name('superadmin.usermanagement.roles');
            Route::get('usermanagement/add-role', 'createRole')->name('superadmin.usermanagement.createRole');
            Route::post('usermanagement/store-role', 'storeRole')->name('superadmin.usermanagement.storeRole');
            Route::get('usermanagement/role/{role}', 'rolesPermissionEdit')->name('superadmin.usermanagement.permissionEdit');
            Route::post('usermanagement/roleupdate/{role}', 'roleupdate')->name('superadmin.usermanagement.roles.update');
            Route::get('usermanagement/permission', 'permission')->name('superadmin.usermanagement.permission');
            Route::get('usermanagement/deptUser/{id?}', 'deptUser')->name('superadmin.usermanagement.deptUser');
            Route::post('usermanagement/deptUserDelete', 'deptUserDelete')->name('superadmin.usermanagement.deptUser.delete');
            Route::get('usermanagement/deptUserview/{id?}', 'deptUserView')->name('superadmin.usermanagement.deptUser.view');
            Route::get('usermanagement/processorView/{id}', 'processorView')->name('superadmin.usermanagement.deptUser.proview');
            Route::post('usermanagement/previewpost', 'previewpost')->name('superadmin.usermanagement.deptUser.previewpost');

            Route::get('usermanagement/deptUseradd/{id?}', 'deptUseradd')->name('superadmin.usermanagement.deptUser.add');
            Route::post('usermanagement/deptUserstore', 'deptUserstore')->name('superadmin.usermanagement.deptUser.store');
            Route::get('usermanagement/deptUserEdit/{id}', 'deptUserEdit')->name('superadmin.usermanagement.deptUser.deptUserEdit');
            Route::post('usermanagement/deptUserUpdate/{id}', 'deptUserUpdate')->name('superadmin.usermanagement.deptUser.deptUserUpdate');

            Route::get('usermanagement/usercreatelist', 'userCreateList')->name('superadmin.usermanagement.usercreatelist');
            Route::get('usermanagement/rolelist', 'emprolelist')->name('superadmin.usermanagement.rolelist');
            Route::get('usermanagement/usercreate', 'userCreate')->name('superadmin.usermanagement.usercreate');
            Route::get('usermanagement/rolecreate', 'rolecreate')->name('superadmin.usermanagement.rolecreate');
            Route::post('usermanagement/usercreatestore', 'userCreateStore')->name('superadmin.usermanagement.usercreate.store');
            Route::get('usermanagement/usercreateedit/{id}', 'userCreateEdit')->name('superadmin.usermanagement.usercreate.edit');
            Route::post('usermanagement/usercreateupdate/{id}', 'usercreateUpdate')->name('superadmin.usermanagement.usercreate.Update');
            Route::get('usermanagement/usercreaterole/{id}', 'userCreateRole')->name('superadmin.usermanagement.usercreate.role');
            Route::post('usermanagement/usercreateupdaterole/{id}', 'usercreateUpdateRole')->name('superadmin.usermanagement.usercreate.UpdateRole');

            Route::post('usermanagement/getPermissionByRole', 'getPermissionByRole')->name('superadmin.usermanagement.getPermissionByRole');

            Route::get('usermanagement/addIcs/{id}', 'addIcs')->name('superadmin.usermanagement.deptUser.addIcs');
            Route::post('getDistrict', 'getDistrict')->name('superadmin.usermanagement.getDistrict');
            Route::post('getBlockTehsil', 'getBlockTehsil')->name('superadmin.usermanagement.getBlockTehsil');
            Route::post('getVillage', 'getVillage')->name('superadmin.usermanagement.getVillage');
            Route::get('usermanagement/archive', 'archive')->name('superadmin.usermanagement.archive');
            Route::get('usermanagement/editArchive/{id}', 'editArchive')->name('superadmin.usermanagement.archive.edit');
            Route::post('usermanagement/updateArchive/{id}', 'updateArchive')->name('superadmin.usermanagement.archive.update');

            Route::post('email-mobile-otp', 'emailMobileOTP')->name('superadmin.usermanagement.email_mobile_OTP');
            Route::post('email-mobile-otp-check', 'emailMobileOTPcheck')->name('superadmin.usermanagement.email_mobile_OTP_check');
            Route::post('getMandatorDetail', 'getMandatorDetail')->name('superadmin.usermanagement.getMandatorDetail');

            Route::get('noc-list', 'getNOCDetailList')->name('superadmin.icsuser.getNOCDetailList');
            Route::get('noc-process-approval/{id}/{at_user_id}', 'nocProcessAproval')->name('superadmin.icsuser.nocProcessAproval'); //df
            // Route::get('noc-process-approval-popup', 'nocProcessAprovalPopup')->name('superadmin.intc.details.route');//Code By Sunny
            // Route::get('noc-process-approval/{id}', 'nocProcessAproval')->name('superadmin.icsuser.nocProcessAproval');
            Route::post('noc-process-approval-store', 'nocProcessAprovalStore')->name('superadmin.icsuser.nocProcessAprovalStore');
            Route::get('noc-list-status-wise', 'getNOCDetailListStatusWise')->name('superadmin.icsuser.getNOCDetailListStatusWise');
            Route::get('noc-register', 'nocRegister')->name('superadmin.icsuser.nocRegister');
            Route::get('noc-certificate/{id}', 'nocCertificate')->name('superadmin.icsuser.nocCertificate');


            Route::get('scope-renewal', 'scopeRenewal')->name('superadmin.icsuser.scopeRenewal');

            Route::get('registration-detail', 'registrationDetail')->name('superadmin.icsuser.registrationDetail');
            Route::post('registration-detail-update/{id}', 'registrationDetailUpdate')->name('superadmin.icsuser.registrationDetailUpdate');
            Route::get('scope-farmer-detail', 'scopeFarmerDetail')->name('superadmin.icsuser.scopeFarmerDetail');
            Route::post('search-farmer', 'searchFarmer')->name('superadmin.icsuser.searchFarmer');
            Route::get('internal-inspection', 'internalInspection')->name('superadmin.icsuser.internalInspection');
            Route::get('osp-detail/{fid?}', 'ospDetail')->name('superadmin.icsuser.ospDetail');
            Route::get('scope-renewal-forword-cb/{fid?}', 'scopeRenewalForwardToCB')->name('superadmin.icsuser.scopeRenewalForwardToCB');
            Route::post('store-scope-renewal-forword-cb', 'storeScopeRenewalForwardToCB')->name('superadmin.icsuser.storeScopeRenewalForwardToCB');
            Route::post('delete-farmer', 'deleteFarmer')->name('superadmin.icsuser.deleteFarmer');
            Route::get('farm-list/{fid?}', 'farmListByFarmer')->name('superadmin.icsuser.farmList');
            Route::match(['get', 'post'], 'add-farmer-by-scope-renewal/{type?}', 'addFarmerbyScopeRenewal')->name('superadmin.icsuser.addFarmerbyScopeRenewal');
            // Route::get('add-farmer-by-scope-renewal?type=', 'addFarmerbyScopeRenewal')->name('superadmin.icsuser.addFarmerbyScopeRenewal');
            Route::post('store-farmer-by-scope-renewal', 'storeFarmerbyScopeRenewal')->name('superadmin.icsuser.storeFarmerbyScopeRenewal');
            Route::post('store-farm-by-scope-renewal', 'storeFarmbyScopeRenewal')->name('superadmin.icsuser.storeFarmbyScopeRenewal');
            Route::post('store-osp-detail', 'storeOspDetail')->name('superadmin.icsuser.storeOspDetail');
            Route::get('preview-application/{fid?}', 'previewApplication')->name('superadmin.icsuser.previewApplication');
            Route::post('app-forword-to-cb', 'applicationForwardToCB')->name('superadmin.icsuser.applicationForwardToCB');

            Route::get('superadmin/usermanagement/deptUser/export/{id}/{type}', 'export')->name('superadmin.usermanagement.export');

            Route::get('list-of-registration', 'panalty')->name('superadmin.usermanagement.panalty');
            Route::post('list-of-registration-template', 'panaltyTemplate')->name('superadmin.usermanagement.panaltyTemplate');

            Route::get('list-of-noc-operators', 'nocoperator')->name('superadmin.usermanagement.nocoperator');
            Route::get('list-of-discontinued-operators', 'discon')->name('superadmin.usermanagement.discon');
            Route::get('list-of-sanctioned-operators', 'discontinued')->name('superadmin.usermanagement.discontinued');
            Route::get('online-applications', 'operatorhome')->name('superadmin.usermanagement.operatorhome');

            Route::post('update-user-status', 'updateUserStatus')->name('superadmin.usermanagement.updateUserStatus');
            Route::post('registration-delete', 'panaltyview')->name('superadmin.usermanagement.panaltyview');
            Route::get('registration-view/panaltyview/{id?}', 'panaltyview')->name('superadmin.usermanagement.panaltyview');
            Route::post('registration-delete', 'panaltydelete')->name('superadmin.usermanagement.panaltydelete');

            Route::post('registration-status', 'registrationstatus')->name('superadmin.usermanagement.registrationstatus');


            Route::get('pending-application', 'pendingApplicationStockTransfer')->name('superadmin.usermanagement.pendingApplicationStockTransfer');
            Route::get('list-of-application', 'listApplicationStockTransfer')->name('superadmin.usermanagement.listApplicationStockTransfer');
            Route::get('Approval-batch', 'editbatch')->name('superadmin.usermanagement.editbatch');
            Route::get('batch-details/{at_user_id}', 'ProceedBatch')->name('superadmin.usermanagement.ProceedBatch');
            Route::get('edit-details/{at_user_id}', 'editDetails')->name('superadmin.usermanagement.editDetails');
            Route::post('update-details/{at_user_id}', 'batchDetailsSave')->name('superadmin.batchDetailsSave');
            Route::get('Search-STN', 'SearchSTN')->name('superadmin.SearchSTN');
            Route::get('Search-Batch/', 'BatchSearch')->name('superadmin.BatchSearch');
            Route::get('Search-Process', 'BatchProceed')->name('superadmin.BatchProceed');
            Route::get('process-application/{id}', 'ProccessApplication')->name('superadmin.ProccessApplication');
            Route::get('view-st-request-certificate/{tcid}/{userid}', 'previewSt')->name('superadmin.strequestCbcertificatepreviewst');
            Route::get('cb-st-view-application-pdf/{id}', 'StViewApplication')->name('superadmin.StViewApplication');
            Route::post('store-st-request-certificate-preview', 'storeProccessApplication')->name('superadmin.storeProccessApplication');
            Route::get('cb-view-st-application/{tcid}/{userid}', 'viewSTApplication')->name('superadmin.viewSTApplication');
            Route::post('generate-sT', 'generateST')->name('superadmin.generateST');
            Route::put('pending-application/{id}/approve', 'Status')->name('superadmin.Status');

            Route::post('/send-otp', 'sendOtp')->name('superadmin.sendOtp');
            Route::post('/verify-otp',  'verifyOtp')->name('superadmin.verifyOtp');

            Route::get('online-application-view/{id?}', 'operatorhomeview')->name('superadmin.usermanagement.operatorhomeview');
            Route::get('schedule-for-survey', 'SurveyList')->name('superadmin.usermanagement.SurveyList');
            Route::post('get-pan-details', 'GetPanDetail')->name('superadmin.GetPanDetail');

            Route::get('StViewApplicationPdf/{id?}', 'StViewApplicationPdf')->name('superadmin.StViewApplicationPdf');
            Route::any('validation-pan-number','ValidationCheck')->name('validation-pan-number');

        });
    });

    Route::group(['middleware' => ['XSS', 'prevent-back-history']], function () {
        Route::controller(InputApprovalController::class)->group(function () {
            Route::get('input-registration-list', 'registrationList')->name('superadmin.registrationList');
            Route::get('input-registration', 'newRegistration')->name('superadmin.newRegistration');
            Route::post('input-registration-save', 'storeNewRegistration')->name('superadmin.storeNewRegistration');
            Route::post('input-registration/update/{id}', 'updateRegistration')->name('superadmin.registration.update');
            Route::delete('delete-unit/{id}', 'deleteUnit')->name('superadmin.deleteUnit');
            Route::post('store-unit', 'storeApplicationUnit')->name('superadmin.storeApplicationUnit');

            Route::get('product-list', 'productList')->name('superadmin.productList');
            Route::get('add-product/{unit_id}/{renew?}', 'addProduct')->name('superadmin.addProduct');
            Route::get('edit-input/{unit_id}/{renew?}', 'editInput')->name('superadmin.editInput');
            Route::post('store-product', 'storeProduct')->name('superadmin.storeProduct');
            Route::post('get-sub-category-list', 'getSubcategory')->name('superadmin.getSubcategory');
            Route::delete('delete-product/{id}', 'deleteProduct')->name('superadmin.deleteProduct');

            Route::get('add-batch/{id}', 'addBatch')->name('superadmin.addBatch');
            Route::post('add-edit-batch', 'addEditbatch')->name('superadmin.addEditbatch');
            Route::post('store-batch', 'storeBatch')->name('superadmin.storeBatch');
            Route::delete('delete-batch/{id}', 'deleteBatch')->name('superadmin.deleteBatch');

            Route::get('add-ingredients/{id}', 'addIngredients')->name('superadmin.addIngredients');
            Route::post('add-edit-ingredients', 'addEditIngredients')->name('superadmin.addEditIngredients');
            Route::post('store-ingredients', 'storeIngredients')->name('superadmin.storeIngredients');
            Route::delete('delete-ingredients/{id}', 'deleteIngredients')->name('superadmin.deleteIngredients');

            Route::get('application-inspection', 'applicationInspectionList')->name('superadmin.applicationInspectionList');
            Route::get('add-inspection/{id}', 'newInspection')->name('superadmin.newInspection');
            Route::post('store-inspection/{id}', 'storeNewInspection')->name('superadmin.storeNewInspection');
            Route::get('view-inspection/{id}', 'viewInspection')->name('superadmin.viewInspection');
            Route::get('view-inspection-closure/{id}/{insp_master_id}', 'viewInspectionClosure')->name('superadmin.viewInspectionClosure');

            Route::get('application-generate-certificate-list', 'applicationGenerateCertificateList')->name('superadmin.applicationGenerateCertificateList');
            Route::get('application-generate-certificate-view/{id}', 'applicationGenerateCertificateview')->name('superadmin.applicationGenerateCertificateview');
            Route::get('application-generate-certificate-pdf/{id}', 'applicationGenerateCertificatePDF')->name('superadmin.applicationGenerateCertificatePDF');

            Route::get('application-renewal-list', 'applicationRenewalList')->name('superadmin.applicationRenewalList');
            Route::get('application-renewal-process/{id}', 'applicationRenewalProcess')->name('superadmin.applicationRenewalProcess');

            Route::get('application-generate-renew-certificate/{id}', 'applicationGenerateRenewalCertificate')->name('superadmin.applicationGenerateRenewalCertificate');
            Route::post('store-application-generate-renew-certificate/{id}', 'storeApplicationGenerateRenewalCertificate')->name('superadmin.storeApplicationGenerateRenewalCertificate');
        });
    });



    // ------------code by sandeeep --------
    Route::group(['middleware' => ['XSS', 'prevent-back-history']], function () {
        Route::controller(MandatorManagementController::class)->group(function () {
            Route::get('mandatormanagement/mandatorlist', 'index')->name('superadmin.mandatormanagement.mandatorlist');
            Route::get('mandatormanagement/create', 'create')->name('superadmin.mandatormanagement.create');
            Route::get('mandatormanagement/edit/{id?}', 'edit')->name('superadmin.mandatormanagement.edit');
            Route::post('mandatormanagement/mandatorstore', 'mandatorstore')->name('superadmin.mandatormanagement.mandatorstore');
            Route::post('mandatormanagement/mandatorupdate', 'mandatorUpdate')->name('superadmin.mandatormanagement.mandatorupdate');
            Route::get('mandatormanagement/delete/{id?}', 'delete')->name('superadmin.mandatormanagement.delete');
        });
        //----------End----------------------
        Route::controller(IndividualProducerController::class)->group(function () {
            Route::get('usermanagement/individualUserAdd/{id}', 'individualUserAdd')->name('superadmin.usermanagement.deptUser.individualUserAdd');
            Route::post('usermanagement/individualUserStore/{id}', 'individualUserStore')->name('superadmin.usermanagement.deptUser.individualUserStore');
            Route::get('usermanagement/individualUserAddStep2/{id}', 'individualUserAddStep2')->name('superadmin.usermanagement.deptUser.individualUserAddStep2');
            Route::post('usermanagement/individualUserStoreStep2/{id}', 'individualUserStoreStep2')->name('superadmin.usermanagement.deptUser.individualUserStoreStep2');
            Route::get('usermanagement/individualUserAddStep3/{id}', 'individualUserAddStep3')->name('superadmin.usermanagement.deptUser.individualUserAddStep3');
            Route::post('usermanagement/individualUserStoreStep3/{id}', 'individualUserStoreStep3')->name('superadmin.usermanagement.deptUser.individualUserStoreStep3');
            Route::post('usermanagement/individualUserDeleteGeoTagging', 'individualUserDeleteGeoTagging')->name('superadmin.usermanagement.deptUser.individualUserDeleteGeoTagging');
            Route::get('usermanagement/individualUserAddStep4/{id}', 'individualUserAddStep4')->name('superadmin.usermanagement.deptUser.individualUserAddStep4');
            Route::post('usermanagement/individualUserDeleteStandingCorp', 'individualUserDeleteStandingCorp')->name('superadmin.usermanagement.deptUser.individualUserDeleteStandingCorp');
            Route::post('usermanagement/individualUserStoreStep4/{id}', 'individualUserStoreStep4')->name('superadmin.usermanagement.deptUser.individualUserStoreStep4');
            Route::get('usermanagement/individualUserAddStep5/{id}', 'individualUserAddStep5')->name('superadmin.usermanagement.deptUser.individualUserAddStep5');
            Route::post('usermanagement/individualUserStoreStep5/{id}', 'individualUserStoreStep5')->name('superadmin.usermanagement.deptUser.individualUserStoreStep5');
            Route::post('usermanagement/individualUserDeleteProposedCorp', 'individualUserDeleteProposedCorp')->name('superadmin.usermanagement.deptUser.individualUserDeleteProposedCorp');
            Route::get('usermanagement/individualUserAddStep6/{id}', 'individualUserAddStep6')->name('superadmin.usermanagement.deptUser.individualUserAddStep6');
            Route::post('usermanagement/individualUserStoreStep6/{id}', 'individualUserStoreStep6')->name('superadmin.usermanagement.deptUser.individualUserStoreStep6');

            Route::get('individual-producer/preview/{id?}', 'individualProducerPreview')->name('superadmin.individualProducer.preview');

            Route::post('individual-producer/previewpost', 'individualProducerPreviewpost')->name('superadmin.individualProducer.previewpost');

            Route::post('individual-producer/preview/pdf/{id?}', 'individualProducerPreviewPdf')->name('superadmin.individualProducer.preview.pdf');

            //Code by sunny
            Route::get('IpbatchCreationindex/{at_user_id}', 'ipbatchCreationindex')->name('IpbatchCreationindex');
            Route::get('Ip-create-batch/{at_user_id}', 'ipbatchCreation')->name('superadmin.ipbatchCreation');
            Route::post('Ip-create-batch-save', 'batchCreationsave')->name('superadmin.IpCreatebatchsave');
            Route::get('ip-source-details', 'ipbatchCreationsouceDetails')->name('superadmin.ipbatchCreationsouceDetails');
            Route::post('Ip-Preview-details/{at_user_id}', 'batchCreationPreviewDetails')->name('superadmin.ipbatchCreationPreviewDetails');
            Route::post('Ip-saveQuantitySource', 'saveQuantitySource')->name('superadmin.ipsaveQuantitySource');
            Route::get('IPSearch', 'Search')->name('IPSearch');
            Route::post('IP-batch-details', 'batchCreationPreviewDetailssave')->name('superadmin.IpbatchCreationPreviewDetailssave');
            Route::get('IP-details/{at_user_id}', 'Details')->name('superadmin.IpDetails');
            Route::get('IP-history', 'History')->name('superadmin.IpHistory');
            Route::any('IP-traders/apply-for-domestic-tc/{id?}', 'applyForDomesticTC')->name('superadmin.IPtrader.applyForDomesticTCT');
            Route::any('IP-traders/store-apply-for-domestic-tc-purchase', 'storeApplyForDomesticTCT')->name('superadmin.IPtrader.storeApplyForDomesticTCT');
            Route::post('IP-ics-update/store-icsharvest-product', 'storeIcsHarvestProduct')->name('superadmin.individualproducerUpdate.storeIcsHarvestProduct');
            Route::get('IP-traders/packing-detail/{id}', 'packingDetailTC')->name('superadmin.IPtrader.packingDetailTC');
            Route::post('IP-traders/store-packing-detail', 'storePackingDetailTC')->name('superadmin.iptrader.storePackingDetailTC');
            Route::get('IP-traders/tc-detail/{id}', 'TcDetail')->name('superadmin.iptrader.TcDetail');
            // Route::get('wh-traders/packing-detail/{id}', 'packingDetailTC')->name('superadmin.whtrader.packingDetailTC');
            Route::get('IP-apply-for-domestic-tc/{id?}', 'IPapplyForDomesticTC')->name('superadmin.IPapplyForDomesticTC');
            Route::post('IP-traders/store-tc-detail', 'storeTcDetail')->name('superadmin.IPtrader.storeTcDetail');
            Route::get('IP-forward-to-cb/{id}', 'forwardToCB')->name('superadmin.IPforwardToCB');
            Route::post('IP-store-forward-to-cb', 'postForwardToCB')->name('superadmin.IPpostForwardToCB');
            Route::get('IP-list-trans-certificate-ptc', 'listOfTransCertificate')->name('superadmin.IPlistOfTransCertificate');
            Route::get('IP-view-tc-application/{id}', 'viewTCApplication')->name('superadmin.IPviewTCApplication');
            //Route::get('tc-detail/{id}', 'TcDetail')->name('superadmin.TcDetail');
            Route::get('IP-tc-issue-list', 'tsIssueList')->name('superadmin.IP.cb.tsIssueList');
            Route::get('IP-cb-tc-view-application-pdf/{id}', 'TcViewApplication')->name('superadmin.IP.cb.TcViewApplication');
            Route::get('IP-Search-Batch', 'IpBatchSearchHistory')->name('superadmin.IpBatchHistorySearch'); //Code by Sunny

        });

        Route::controller(WildHarvestController::class)->group(function () {
            Route::get('usermanagement/wildHarvestUserAdd/{id}', 'wildHarvestUserAdd')->name('superadmin.usermanagement.deptUser.wildHarvestUserAdd');
            Route::any('usermanagement/wildHarvestUserStore/{id}', 'wildHarvestUserStore')->name('superadmin.usermanagement.deptUser.wildHarvestUserStore');
            Route::get('usermanagement/wildHarvestUserAddStep2/{id}', 'wildHarvestUserAddStep2')->name('superadmin.usermanagement.deptUser.wildHarvestUserAddStep2');
            Route::any('usermanagement/wildHarvestUserStoreStep2/{id}', 'wildHarvestUserStoreStep2')->name('superadmin.usermanagement.deptUser.wildHarvestUserStoreStep2');
            Route::get('usermanagement/wildHarvestUserAddStep3/{id}', 'wildHarvestUserAddStep3')->name('superadmin.usermanagement.deptUser.wildHarvestUserAddStep3');
            Route::any('usermanagement/wildHarvestUserStoreStep3/{id}', 'wildHarvestUserStoreStep3')->name('superadmin.usermanagement.deptUser.wildHarvestUserStoreStep3');
            Route::get('usermanagement/wildHarvestUserAddStep4/{id}', 'wildHarvestUserAddStep4')->name('superadmin.usermanagement.deptUser.wildHarvestUserAddStep4');
            Route::post('usermanagement/wildHarvestUserStoreStep4/{id}', 'wildHarvestUserStoreStep4')->name('superadmin.usermanagement.deptUser.wildHarvestUserStoreStep4');
            Route::post('usermanagement/wildHarvestDeletePermittedForestArea', 'wildHarvestDeletePermittedForestArea')->name('superadmin.usermanagement.deptUser.wildHarvestDeletePermittedForestArea');
            Route::get('usermanagement/wildHarvestUserAddStep5/{id}', 'wildHarvestUserAddStep5')->name('superadmin.usermanagement.deptUser.wildHarvestUserAddStep5');
            Route::post('usermanagement/wildHarvestUserStoreStep5/{id}', 'wildHarvestUserStoreStep5')->name('superadmin.usermanagement.deptUser.wildHarvestUserStoreStep5');
            Route::post('usermanagement/wildHarvestDeleteForestProduct', 'wildHarvestDeleteForestProduct')->name('superadmin.usermanagement.deptUser.wildHarvestDeleteForestProduct');
            Route::get('usermanagement/wildHarvestUserAddStep6/{id}', 'wildHarvestUserAddStep6')->name('superadmin.usermanagement.deptUser.wildHarvestUserAddStep6');
            Route::post('usermanagement/wildHarvestUserStoreStep6/{id}', 'wildHarvestUserStoreStep6')->name('superadmin.usermanagement.deptUser.wildHarvestUserStoreStep6');

            Route::get('wild-harvest/preview/{id?}', 'wildHarvestPreview')->name('superadmin.wildHarvest.preview');
            Route::post('wild-harvest/previewpost', 'wildHarvestPreviewpost')->name('superadmin.wildHarvest.previewpost');

            // Created by Sunny
            Route::get('whbatchCreationindex/{at_user_id}', 'whbatchCreationindex')->name('whbatchCreationindex');
            Route::get('wh-create-batch/{at_user_id}/{hscode?}', 'whbatchCreation')->name('superadmin.whbatchCreation');
            Route::post('create-batch-save', 'batchCreationsave')->name('superadmin.Createbatchsave');
            Route::get('wh-source-details/{at_user_id}', 'WhbatchCreationsouceDetails')->name('superadmin.whbatchCreationsouceDetails');
            Route::get('WhSearch', 'Search')->name('WhSearch');
            Route::post('whsaveQuantitySource', 'saveQuantitySource')->name('superadmin.whsaveQuantitySource');
            Route::post('WhPreview-details/{at_user_id}', 'batchCreationPreviewDetails')->name('superadmin.WhbatchCreationPreviewDetails');
            Route::post('wh-batch-details', 'batchCreationPreviewDetailssave')->name('superadmin.WhbatchCreationPreviewDetailssave');
            Route::get('whdetails/{at_user_id}', 'Details')->name('superadmin.WhDetails');
            Route::get('whhistory', 'History')->name('superadmin.WhHistory');
            Route::get('wh-Search-Batch', 'WhBatchSearchHistory')->name('superadmin.WhBatchHistorySearch'); //Code by Sunny
        });

        Route::controller(HarvestUpdateController::class)->group(function () {
            Route::get('harvest-update/update-actual-yield', 'updateActualYield')->name('superadmin.harvestUpdate.updateActualYield');
            Route::get('harvest-update/update-actual-yield-scope', 'updateActualYieldScope')->name('superadmin.harvestUpdate.updateActualYieldScope');
            Route::get('harvest-update/update-actual-yield-products/{id}', 'updateActualYieldProduct')->name('superadmin.harvestUpdate.updateActualYieldProduct');
            Route::get('harvest-update/update-actual-yield-harvest-history', 'updateActualYieldHarvestHistory')->name('superadmin.harvestUpdate.updateActualYieldHarvestHistory');
            Route::post('harvest-update/edit-harvest-product', 'editHarvestProduct')->name('superadmin.harvestUpdate.editHarvestProduct');
            Route::post('harvest-update/store-harvest-product', 'storeHarvestProduct')->name('superadmin.harvestUpdate.storeHarvestProduct');
        });

        // ---code by siddharth sharma-------//
        Route::controller(ICSHarvestUpdateController::class)->group(function () {
            Route::get('ics-update/update-actual-yield', 'updateIcsActualYield')->name('superadmin.harvestUpdate.updateIcsActualYield');
            Route::get('ics-update/update-actual-yield-scope', 'updateIcsActualYieldScope')->name('superadmin.harvestUpdate.updateIcsActualYieldScope');
            Route::get('ics-update/update-actual-yield-farmsdetails/{id}', 'updateIcsActualYieldFarmsdetails')->name('superadmin.harvestUpdate.updateIcsActualYieldFarmsdetails');
            Route::get('ics-update/update-actual-yield-products/{id?}/{iid}', 'updateIcsActualYieldProducts')->name('superadmin.harvestUpdate.updateIcsActualYieldProducts');
            Route::post('ics-update/edit-icsharvest-product', 'editIcsHarvestProduct')->name('superadmin.harvestUpdate.editIcsHarvestProduct');
            Route::post('ics-update/store-icsharvest-product', 'storeIcsHarvestProduct')->name('superadmin.harvestUpdate.storeIcsHarvestProduct');
        });

        Route::controller(IPHarvestUpdateController::class)->group(function () {
            Route::get('ip-update/update-actual-yield', 'updateIPActualYield')->name('superadmin.harvestUpdate.updateIPActualYield');
            Route::get('ip-update/update-actual-yield-scope', 'updateIPActualYieldScope')->name('superadmin.harvestUpdate.updateIPActualYieldScope');
            Route::get('ip-update/update-actual-yield-farmsdetails/{id}', 'updateIPActualYieldFarmsdetails')->name('superadmin.harvestUpdate.updateIPActualYieldFarmsdetails');
            Route::get('ip-update/update-actual-yield-products/{id?}/{iid}', 'updateIPActualYieldProducts')->name('superadmin.harvestUpdate.updateIPActualYieldProducts');
            Route::post('ip-update/edit-ipharvest-product', 'editIPHarvestProduct')->name('superadmin.harvestUpdate.editIPHarvestProduct');
            Route::post('ip-update/store-ipharvest-product', 'storeIPHarvestProduct')->name('superadmin.harvestUpdate.storeIPHarvestProduct');
        });
        // ---end-------//

        Route::controller(ClosingStockController::class)->group(function () {

            Route::get('closing-stock/update-closing-scope', 'updateclosingestock')->name('superadmin.closingstocks.updateclosingestock');
            Route::get('closing-stock/operator-list', 'operatorDetailsClosingStock')->name('superadmin.operatorDetailsClosingStock');
            Route::get('closing-stock/update-closing-stock-scope/{id}', 'updateclosingstockscope')->name('superadmin.closingstocks.updateclosingstockscope');
            /*ICS*/
            Route::get('ics/update-closing-stock-farmsdetails/{operator_id}/{id}', 'updateicsclosingstockfarmsdetails')->name('superadmin.closingstocks.updateicsclosingstockfarmsdetails');
            Route::get('ics/update-closing-stock-productdetails/{operator_id}/{id}/{farms_id}', 'updateicsclosingstockproductdetails')->name('superadmin.closingstocks.updateicsclosingstockproductdetails');
            Route::post('ics-update/edit-closing-stock-product', 'editIcsClosingstockProduct')->name('superadmin.closingstocks.editIcsClosingstockProduct');
            Route::post('ics-update/store-closing-stock-product', 'storeIcsclosingstockProduct')->name('superadmin.closingstocks.storeIcsclosingstockProduct');
            /*WH*/
            Route::post('wh-update/edit-closing-stock-product', 'editWHClosingstockProduct')->name('superadmin.closingstocks.editWHClosingstockProduct');
            Route::post('wh-update/store-closing-stock-product', 'storeWHclosingstockProduct')->name('superadmin.closingstocks.storeWHclosingstockProduct');

            /*IP*/
            Route::get('ip/update-closing-stock-farms_details/{operator_id}/{id}', 'updateipclosingstockfarmsdetails')->name('superadmin.closingstocks.updateipclosingstockfarmsdetails');
            Route::get('ip/update-closing-stock-productdetails/{operator_id}/{id}/{farms_id}', 'updateipclosingstockproductdetails')->name('superadmin.closingstocks.updateipclosingstockproductdetails');
            Route::post('ip-update/edit-closing-stock-product', 'editipClosingstockProduct')->name('superadmin.closingstocks.editipClosingstockProduct');
            Route::post('ip-update/store-closing-stock-product', 'storeipclosingstockProduct')->name('superadmin.closingstocks.storeipclosingstockProduct');
        });


        Route::controller(IcsUserController::class)->group(function () {
            Route::get('abc', 'abc')->name('superadmin.abc');
            Route::get('icsuser/step1/{userid}', 'step1')->name('superadmin.icsuser.step1');
            Route::post('icsuser/step1post/{userid}', 'step1post')->name('superadmin.icsuser.step1post');

            Route::get('icsuser/step2/{userid}', 'step2')->name('superadmin.icsuser.step2');
            Route::post('icsuser/step2post/{userid}', 'step2post')->name('superadmin.icsuser.step2post');

            Route::get('icsuser/step3/{userid}', 'step3')->name('superadmin.icsuser.step3');
            Route::post('icsuser/step3post/{userid}', 'step3post')->name('superadmin.icsuser.step3post');
            Route::post('icsuser/step3postajax', 'step3postajax')->name('superadmin.icsuser.step3postajax');

            Route::get('icsuser/step4/{userid}', 'step4')->name('superadmin.icsuser.step4');
            Route::post('icsuser/step4post/{userid}', 'step4post')->name('superadmin.icsuser.step4post');

            Route::get('icsuser/step5/{userid}', 'step5')->name('superadmin.icsuser.step5');
            Route::post('icsuser/step5post/{userid}', 'step5post')->name('superadmin.icsuser.step5post');

            Route::get('icsuser/step6/{userid}', 'step6')->name('superadmin.icsuser.step6');
            Route::post('icsuser/step6post/{userid}', 'step6post')->name('superadmin.icsuser.step6post');
            Route::get('icsuser/preview/{id?}', 'icspreview')->name('superadmin.icsuser.preview');
            Route::post('icsuser/previewpost', 'previewpost')->name('superadmin.icsuser.previewpost');

            Route::post('icsuser/storeMedia', 'storeMedia')->name('storeMedia');
            Route::post('icsuser/deletewarehousebyid', 'deletewarehousebyid')->name('deletewarehousebyid');
            Route::post('uniqueEmailMobile', 'uniqueEmailMobile')->name('uniqueEmailMobile');
            Route::post('delete-inspector', 'deleteInspector')->name('superadmin.icsuser.deleteinspector');

            Route::get('inspector-list', 'inspectorList')->name('superadmin.icsuser.inspectorList');
            Route::get('inspector-schedule/{id}', 'inspectorSchedule')->name('superadmin.icsuser.inspectorSchedule');
            Route::post('inspector/schedulePost', 'inspectorSchedulePost')->name('superadmin.icsuser.inspectorSchedulePost');
            Route::post('delete/schedule', 'deleteSchedule')->name('superadmin.icsuser.deleteSchedule');

            Route::get('inspector-sch-list', 'inspectorSchList')->name('superadmin.icsuser.inspectorSchList');
            Route::get('inspector-insp-schedule/{id}', 'inspectorInspSchedule')->name('superadmin.icsuser.inspectorInspSchedule');
            Route::post('inspector/inspSchedulePost', 'inspSchedulePost')->name('superadmin.icsuser.inspSchedulePost');
            Route::post('delete/inspSchedule', 'deleteInspSchedule')->name('superadmin.icsuser.deleteInspSchedule');

            Route::get('farmer-list', 'farmerList')->name('superadmin.icsuser.farmerList');
            Route::get('farmer-detail/{fid}', 'farmerDetail')->name('superadmin.icsuser.farmerDetail');
            Route::post('icsuser/update-inspector/{id?}', 'updateinspector')->name('updateinspector');



            // ---code by sandeep------
            Route::get('icsfarmer-details', 'icsfarmerdetails')->name('superadmin.icsfarmerdetails');
            Route::post('icsfarmer-detailsStore', 'storeIcsFarmerDetails')->name('superadmin.icsuser.icsfarmerDetailsStore');
            

            // end-----------

            // add more route farmer details 
            Route::post('icsuser/add-more-frm', 'Addmorefrm')->name('superadmin.icsuser.Addmorefrm');
        });

        Route::controller(InternalApprovalController::class)->group(function () {
            Route::get('inspection-list', 'inspectionList')->name('superadmin.inspectionList');
            Route::get('complete-inspection-list', 'inspectionCompleteList')->name('superadmin.inspectionCompleteList');
            Route::get('complete-inspection-detail', 'inspectionCompleteDetail')->name('superadmin.inspectionCompleteDetail');
            Route::get('complete-inspection-scheduleInspector', 'scheduleInspector')->name('superadmin.scheduleInspector');
            Route::get('inspection-detail', 'inspectionDetail')->name('superadmin.inspectionDetail');
            Route::post('approvalPost', 'approvalPost')->name('superadmin.internalApprovalPost');
            Route::get('inspection-detail-pdf/{fid?}', 'generatePdf')->name('superadmin.generatePdf');
            Route::get('Schedule-for-external-inspection', 'scheduleExternalInspectionIndex')->name('superadmin.scheduleExternalInspection');
            Route::get('add-Schedule', 'scheduleAdd')->name('superadmin.scheduleAdd');
            Route::post('ExternalScheduleSave', 'schedulestore')->name('superadmin.schedulestore');
            Route::get('external-inspection-form/{id}', 'ExtinspectionForm')->name('superadmin.ext.inspectionForm');
            Route::post('ExternalScheduleSave', 'schedulestore')->name('superadmin.schedulestore');
        });

        Route::controller(ExternalApprovalController::class)->group(function () {
            Route::get('ext-inspection-list', 'inspectionList')->name('superadmin.external.inspectionList');
            Route::get('ext-inspection-reports', 'externalinspectionListReports')->name('superadmin.externalinspectionListReports');
            Route::get('ext-inspection-detail', 'inspectionDetail')->name('superadmin.external.inspectionDetail');
            Route::get('ext-inspection-form/{id}', 'inspectionForm')->name('superadmin.external.inspectionForm');

            Route::get('inspectionSchedule/{id}', 'inspectionSchedule')->name('superadmin.external.inspectionSchedule');
            Route::post('inspectionSchedule/inspectionScheduleSave', 'inspectionScheduleSave')->name('superadmin.external.inspectionScheduleSave');

            Route::post('ext-inspection-post', 'extInspectionPost')->name('superadmin.external.extInspectionPost');
            Route::post('ext-approvalPost', 'approvalPost')->name('superadmin.external.internalApprovalPost');
            Route::get('ext-inspection-closure-form/{id}', 'inspectionClosureForm')->name('superadmin.external.inspectionClosureForm');
            Route::post('ext-inspection-closure-post', 'extInspectionClosurePost')->name('superadmin.external.extInspectionClosurePost');

            Route::get('ext-risk-list', 'extRiskAssesmentList')->name('superadmin.external.extRiskAssesmentList');
            Route::get('ext-risk-form/{id}', 'extRiskAssesmentDetail')->name('superadmin.external.extRiskAssesmentDetail');
            Route::post('ext-RiskFormPost', 'extRiskFormPost')->name('superadmin.external.extRiskFormPost');

            Route::get('ext-view-inspection-list', 'viewInspectionList')->name('superadmin.external.viewInspectionList');
            Route::get('ip-inspection-report/{id}/{opertye?}', 'inspectionReportIdBy')->name('superadmin.inspectionReportIdBy');

        });

        Route::controller(TradersUserController::class)->group(function () {
            Route::get('traders-edit/{id}', 'tradersDeptUserEdit')->name('superadmin.tradersUseredit');
            Route::post('traders-edit/stepsave/{id}', 'tradersEditStepSave')->name('superadmin.tradersUseredit.stepsave');


            Route::get('traders-edit/step1/{userid}', 'tradersEditStep1')->name('superadmin.tradersUseredit.step1');

            Route::post('traders-edit/step1save/{id}', 'tradersEditStep1Save')->name('superadmin.tradersUseredit.step1save');
            Route::get('traders-edit/step2/{userid}', 'tradersEditStep2')->name('superadmin.tradersUseredit.step2');

            Route::post('traders-edit/step2save/{id}', 'tradersEditStep2Save')->name('superadmin.tradersUseredit.step2save');
            Route::get('traders-edit/step3/{userid}', 'tradersEditStep3')->name('superadmin.tradersUseredit.step3');

            Route::post('traders-edit/save-all/{id}', 'tradersEditFinalSave')->name('superadmin.tradersUseredit.finalSave');

            Route::get('traders/preview/{id?}', 'traderview')->name('superadmin.traders.preview');
            Route::post('wild-harvest/previewpost', 'traderPreviewpost')->name('superadmin.trader.previewpost');
            Route::post('wild-harvest/getFSSAIDetails', 'getFSSAIDetails')->name('superadmin.trader.getFSSAIDetails');

            Route::get('batch-create', 'batchCreate')->name('superadmin.batchCreate');
            Route::get('batch-history', 'BatchHistory')->name('superadmin.BatchHistory');
            Route::get('processed-details/{at_user_id}', 'processedbatch')->name('superadmin.processedbatch');
            Route::post('processed-save', 'processedbatchsave')->name('superadmin.processedbatchsave');
            Route::get('source-detail/{at_user_id}', 'batchSouceDetails')->name('superadmin.batchSouceDetails');
            Route::post('preview-details/{at_user_id}', 'SouceDetail')->name('superadmin.SouceDetail');
            Route::post('Detailsave', 'Detailsave')->name('superadmin.Detailsave');
            Route::get('batchdetails/{at_user_id}', 'batchdetails')->name('superadmin.batchdetails');
            Route::post('search-source', 'search_source')->name('search_source');
            Route::post('saveQuantity', 'saveQuantity')->name('superadmin.saveQuantity');

            Route::post('delete-batch', 'batch_Delete')->name('superadmin.usermanagement.batch_Delete');
            Route::delete('delete-batchS', 'batch_DeleteS')->name('superadmin.usermanagement.batch_DeleteS');


            Route::any('traders/apply-for-domestic-tc/{id?}', 'applyForDomesticTC')->name('superadmin.trader.applyForDomesticTCT');
            Route::any('traders/list-trans-certificate-ptc', 'listOfTransCertificate')->name('superadmin.trader.listOfTransCertificate');
            Route::any('traders/store-apply-for-domestic-tc-purchase', 'storeApplyForDomesticTCT')->name('superadmin.trader.storeApplyForDomesticTCT');

            Route::get('traders/packing-detail/{id}', 'packingDetailTC')->name('superadmin.trader.packingDetailTC');
            Route::post('traders/store-packing-detail', 'storePackingDetailTC')->name('superadmin.trader.storePackingDetailTC');
            Route::get('traders/tc-detail/{id}', 'TcDetail')->name('superadmin.trader.TcDetail');
            Route::post('traders/store-tc-detail', 'storeTcDetail')->name('superadmin.trader.storeTcDetail');
            Route::get('T-Search-Batch', 'TBatchSearchHistory')->name('superadmin.TBatchHistorySearch'); //Code by Sunny
        });

        //code by sunny
        Route::controller(WhTransactionController::class)->group(function () {
            Route::any('whtraders/apply-for-domestic-tc/{id?}', 'applyForDomesticTC')->name('superadmin.whtrader.applyForDomesticTCT');
            Route::any('whtraders/store-apply-for-domestic-tc-purchase', 'storeApplyForDomesticTCT')->name('superadmin.whtrader.storeApplyForDomesticTCT');
            Route::post('wh-ics-update/store-icsharvest-product', 'storeIcsHarvestProduct')->name('superadmin.wildharvestUpdate.storeIcsHarvestProduct');
            Route::get('wh-traders/packing-detail/{id}', 'packingDetailTC')->name('superadmin.whtrader.packingDetailTC');
            Route::post('wh-traders/store-packing-detail', 'storePackingDetailTC')->name('superadmin.whtrader.storePackingDetailTC');
            Route::get('wh-traders/tc-detail/{id}', 'TcDetail')->name('superadmin.whtrader.TcDetail');
            Route::get('wh-apply-for-domestic-tc/{id?}', 'WhapplyForDomesticTC')->name('superadmin.wh-applyForDomesticTC');
            Route::post('wh-traders/store-tc-detail', 'storeTcDetail')->name('superadmin.whtrader.storeTcDetail');
            Route::get('wh-forward-to-cb/{id}', 'forwardToCB')->name('superadmin.whforwardToCB');

            //Route::any('traders/list-trans-certificate-ptc', 'listOfTransCertificate')->name('superadmin.trader.listOfTransCertificate');

            //Route::get('wh-packing-detail', 'whpackingDetailTC')->name('superadmin.whpackingDetailTC');
            Route::get('wh-packing-detail/{id}', 'whpackingDetailTC')->name('superadmin.whpackingDetailTC');
            Route::post('wh-store-apply-for-domestic-tc', 'storeApplyForDomesticTC')->name('superadmin.whstoreApplyForDomesticTC');
            Route::post('wh-store-forward-to-cb', 'postForwardToCB')->name('superadmin.whpostForwardToCB');
            Route::get('wh-list-trans-certificate-tc', 'listOfTransCertificate')->name('superadmin.whlistOfTransCertificate');
            Route::get('wh-view-tc-application/{id}', 'viewTCApplication')->name('superadmin.whviewTCApplication');
            Route::post('wh-store-packing-detail', 'whstorePackingDetailTC')->name('superadmin.whstorePackingDetailTC');
            Route::get('wh-tc-issue-list', 'tsIssueList')->name('superadmin.wh.cb.tsIssueList');
            Route::get('wh-cb-tc-view-application-pdf/{id}', 'TcViewApplication')->name('superadmin.wh.cb.TcViewApplication');
        });

        //code by sunny
        Route::controller(ProcessorController::class)->group(function () {
            Route::any('P-traders/apply-for-domestic-tc/{id?}', 'applyForDomesticTC')->name('superadmin.P-trader.applyForDomesticTCT');
            Route::any('P-traders/store-apply-for-domestic-tc-purchase', 'storeApplyForDomesticTCT')->name('superadmin.P-trader.storeApplyForDomesticTCT');
            Route::get('P-traders/packing-detail/{id}', 'packingDetailTC')->name('superadmin.P-trader.packingDetailTC');
            Route::post('P-ics-update/store-icsharvest-product', 'storeIcsHarvestProduct')->name('superadmin.ProcessorUpdate.storeIcsHarvestProduct');
            Route::post('P-traders/store-packing-detail', 'storePackingDetailTC')->name('superadmin.P-trader.storePackingDetailTC');
            Route::get('P-traders/tc-detail/{id}', 'TcDetail')->name('superadmin.P-trader.TcDetail');
            //Route::get('apply-for-domestic-tc/{id?}', 'applyForDomesticTC')->name('superadmin.applyForDomesticTC');
            Route::post('P-traders/store-tc-detail', 'storeTcDetail')->name('superadmin.P-trader.storeTcDetail');
            Route::get('P-forward-to-cb/{id}', 'forwardToCB')->name('superadmin.P-forwardToCB');
            Route::get('P-packing-detail/{id}', 'whpackingDetailTC')->name('superadmin.P-packingDetailTC');
            //Route::post('store-packing-detail', 'storePackingDetailTC')->name('superadmin.storePackingDetailTC');
            Route::post('P-store-forward-to-cb', 'postForwardToCB')->name('superadmin.P-postForwardToCB');
            Route::get('P-list-trans-certificate-tc', 'listOfTransCertificate')->name('superadmin.P-listOfTransCertificate');
            Route::get('P-view-tc-application/{id}', 'viewTCApplication')->name('superadmin.P-viewTCApplication');
            Route::get('P-tc-issue-list', 'tsIssueList')->name('superadmin.P.cb.tsIssueList');
            Route::get('P-cb-tc-view-application-pdf/{id}', 'TcViewApplication')->name('superadmin.P.cb.TcViewApplication');
        });

        Route::controller(ProcessorUserController::class)->group(function () {
            Route::get('processor-edit/{id}', 'processorDeptUserEdit')->name('superadmin.processorUseredit');
            Route::post('processor-edit/stepsave/{id}', 'processorEditStepSave')->name('superadmin.processorUseredit.stepsave');
            Route::get('processor-edit/step1/{userid}', 'processorEditStep1')->name('superadmin.processorUseredit.step1');
            Route::post('processor-edit/step1save/{id}', 'processorEditStep1Save')->name('superadmin.processorUseredit.step1save');
            Route::get('processor-edit/step2/{userid}', 'processorEditStep2')->name('superadmin.processorUseredit.step2');
            Route::post('processor-edit/step2save/{id}', 'processorEditStep2Save')->name('superadmin.processorUseredit.step2save');
            Route::get('processor-edit/step3/{userid}', 'processorEditStep3')->name('superadmin.processorUseredit.step3');
            Route::post('processor-edit/save-all/{id}', 'processorEditFinalSave')->name('superadmin.processorUseredit.finalSave');
            Route::post('delete-geo-tagging-processor', 'deleteGeoTaggingProcessor')->name('superadmin.processorUseredit.deleteGeoProcessor');
            Route::post('delete-product-processor', 'deleteProductProcessor')->name('superadmin.processorUseredit.deleteProductProcessor');
            Route::post('getHscodeProduct', 'getHscodeProduct')->name('superadmin.getHscodeProduct');
            Route::get('batch-creation/{at_user_id}', 'batchCreation')->name('superadmin.batchCreation');
            Route::get('history', 'History')->name('superadmin.History');
            Route::get('create-batch/{at_user_id}', 'batchCreationindex')->name('superadmin.batchCreationindex');
            Route::post('create-batch', 'batchCreationsave')->name('superadmin.batchCreationsave');
            Route::get('source-details/{at_user_id}', 'batchCreationsouceDetails')->name('superadmin.batchCreationsouceDetails');
            Route::post('Preview-details/{at_user_id}', 'batchCreationPreviewDetails')->name('superadmin.batchCreationPreviewDetails');
            Route::post('batch-details', 'batchCreationPreviewDetailssave')->name('superadmin.batchCreationPreviewDetailssave');
            Route::get('details/{at_user_id}', 'Details')->name('superadmin.Details');
            Route::get('Search', 'Search')->name('Search');
            Route::post('saveQuantitySource', 'saveQuantitySource')->name('superadmin.saveQuantitySource');
            Route::post('batch-delete', 'batchDelete')->name('superadmin.usermanagement.batchDelete');
            Route::get('P-Search-Batch', 'PBatchSearchHistory')->name('superadmin.PBatchHistorySearch'); //Code by Sunny
        });


        Route::controller(ImportedIngredientController::class)->group(function () {
            Route::get('apply-import-list', 'ImportIngredientList')->name('superadmin.importIngredientList');
            Route::get('apply-import-ingredient', 'applyImportIngredient')->name('superadmin.applyImportIngredient');

            Route::get('edit-apply-import-ingredient/{id}', 'editImportIngredient')->name('superadmin.editapplyImportIngredient');

            Route::post('apply-import-ingredient-save', 'applyImportIngredientSave')->name('superadmin.applyImportIngredientSave');

            Route::post('apply-import-ingredient-update/{id}', 'applyImportIngredientUpdate')->name('superadmin.applyImportIngredientUpdate');

            Route::get('appliedImportedIngredientList', 'appliedImportedIngredientList')->name('superadmin.appliedImportedIngredientList');

            Route::get('previewImportIngredient/{id}', 'previewImportIngredient')->name('superadmin.previewImportIngredient');

            Route::post('ImportIngredientStatusUpdate/{id}', 'ImportIngredientStatusUpdate')->name('superadmin.ImportIngredientStatusUpdate');
        });

        Route::controller(ScopeCertificateController::class)->group(function () {

            Route::get('apply-scope-certificate', 'applyScopeCertificate')->name('superadmin.applyScopeCertificate');
            Route::post('preview-of-applocation', 'previewOfApplication')->name('superadmin.previewOfApplication');
            Route::get('preview-scope-certificate/{id}', 'previewScopeCertificate')->name('superadmin.previewScopeCertificate');
            Route::post('apply-scope-certificate-save', 'applyScopeCertificateSave')->name('superadmin.applyScopeCertificateSave');
            Route::get('issued-scope-certificate-list', 'issuedScopeCertificateList')->name('superadmin.issuedScopeCertificateList');
            Route::get('scope-certificate-list', 'scopeCertificateList')->name('superadmin.scopeCertificateList');
            Route::get('scope-certificate-generate/{id}', 'scopeCertificateGenerate')->name('superadmin.scopeCertificateGenerate');
            // CB Side
            Route::post('apply-scope-certificate-generate-save', 'scopeCertificateGenerateSave')->name('superadmin.scopeCertificateGenerateSave');
            Route::post('save-view-certificate-preview', 'saveViewCertificatePreview')->name('superadmin.saveViewCertificatePreview');
            Route::get('view-certificate-preview/{id}', 'viewCertificatePreview')->name('superadmin.viewCertificatePreview');
            Route::get('cb-preview-scope-certificate/{id}', 'CBpreviewScopeCertificate')->name('superadmin.CBpreviewScopeCertificate');
            Route::get('renewal-scope-certificate-list', 'renewalScopeCertificateList')->name('superadmin.renewalScopeCertificateList');
        });



        // Route::controller(ActivityNameMasterController::class)->group(function () {

        //     Route::post('/master/activity-name/delete', 'destroy')->name('superadmin.master.activityName.delete');
        // });



        Route::controller(ICSPurchaseController::class)->group(function () {
            Route::get('purchaseList', 'purchaseList')->name('superadmin.purchaseList');

            Route::get('purchaseProduct/{id}', 'purchaseProduct')->name('superadmin.purchaseProduct');
            Route::post('storePurchaseProduct', 'storePurchaseProduct')->name('superadmin.storePurchaseProduct');
            Route::get('storageStock/{id}', 'storageStock')->name('superadmin.storageStock');
            Route::post('store-storageStock', 'storeStorageStock')->name('superadmin.storeStorageStock');
            Route::get('closingOfStock/{id}', 'closingOfStock')->name('superadmin.closingOfStock');
            Route::post('store-closingOfStock', 'storeClosingOfStock')->name('superadmin.storeClosingOfStock');
        });



        Route::controller(ProcessorPurchaseController::class)->group(function () {
            Route::get('purchaseRequestList', 'purchaseRequestList')->name('superadmin.purchaseRequestList');
            Route::get('purchaseRequestPage', 'purchaseRequestPage')->name('superadmin.purchaseRequestPage');
            Route::post('checkRemainingQuantityInStock', 'checkRemainingQuantityInStock')->name('superadmin.checkRemainingQuantityInStock');
            Route::post('addpurchaseRequest', 'addpurchaseRequest')->name('superadmin.addpurchaseRequest');
            Route::get('purchaseRequestview/{id}', 'purchaseRequestView')->name('superadmin.purchaseRequestView');
            Route::post('purchaseReqPost', 'purchaseReqPost')->name('superadmin.purchaseReqPost');
            Route::post('afterOrderAcceptPost', 'afterOrderAcceptPost')->name('superadmin.afterOrderAcceptPost');
            Route::post('afterOrderRejectPost', 'afterOrderRejectPost')->name('superadmin.afterOrderRejectPost');
            Route::get('accept-purchase/{id}', 'acceptPurchase')->name('superadmin.acceptPurchase');
            Route::get('reject-purchase/{id}', 'rejectPurchase')->name('superadmin.rejectPurchase');
            Route::get('tc-apply/{id?}', 'domestictc')->name('superadmin.domestictc');

            Route::post('store-apply-for-domestic-tc-purchase', 'storeApplyForDomesticTC')->name('superadmin.storeApplyForDomesticTCPurchase');
            Route::get('packing-details-for-domestic-tc-purchase', 'packingDetailDomesticTC')->name('superadmin.packingDetailsForDomesticTCPurchase');

            Route::get('packing-detail', 'packingDetailTC')->name('superadmin.packingDetailTC');
            Route::post('store-packing-detail', 'storePackingDetailTC')->name('superadmin.storePackingDetailTC');
            Route::get('tc-detail/{id}', 'TcDetail')->name('superadmin.TcDetail');
            Route::post('store-tc-detail', 'storeTcDetail')->name('superadmin.storeTcDetail');
        });


        Route::controller(TransactionCertificateController::class)->group(function () {
            Route::get('approvedPurchaseList', 'index')->name('superadmin.approvedPurchaseList');
            Route::get('apply-for-domestic-tc/{id?}', 'applyForDomesticTC')->name('superadmin.applyForDomesticTC');
            Route::post('store-apply-for-domestic-tc', 'storeApplyForDomesticTC')->name('superadmin.storeApplyForDomesticTC');
            Route::get('packing-detail/{id}', 'packingDetailTC')->name('superadmin.packingDetailTC');
            Route::post('store-packing-detail', 'storePackingDetailTC')->name('superadmin.storePackingDetailTC');
            Route::get('tc-detail/{id}', 'TcDetail')->name('superadmin.TcDetail');
            Route::post('store-tc-detail', 'storeTcDetail')->name('superadmin.storeTcDetail');
            Route::get('forward-to-cb/{id}', 'forwardToCB')->name('superadmin.forwardToCB');
            Route::get('view-tc-application/{id}', 'viewTCApplication')->name('superadmin.viewTCApplication');
            Route::post('store-forward-to-cb', 'postForwardToCB')->name('superadmin.postForwardToCB');
            Route::get('list-trans-certificate-ptc', 'listOfTransCertificate')->name('superadmin.listOfTransCertificate');
        });

        Route::controller(ProvisionalTCController::class)->group(function () {
            Route::get('apply-for-provisional-tc', 'applyForProvisionalTC')->name('superadmin.applyForProvisionalTC');
            Route::post('apply-for-provisional-tc-store', 'applyForProvisionalTCStore')->name('superadmin.applyForProvisionalTCStore');
            Route::get('ptc/add-product', 'addProduct')->name('superadmin.step2');
            Route::post('ptc/add-product', 'addProductStore')->name('superadmin.addProductStore');
            Route::get('ptc/packing-details/{id}', 'packingDetails')->name('superadmin.step3');
            Route::post('ptc/packing-details-store', 'storePackingDetail')->name('superadmin.storePackingDetail');
            Route::get('ptc/tc-details/{id}', 'TCDetails')->name('superadmin.step4');
            Route::post('ptc/tc-details-store', 'storeTcDetail')->name('superadmin.storeTcDetailptc');
            Route::get('ptc-forward-to-cb/{id}', 'ptcForwardToCB')->name('superadmin.ptcForwardToCB');
            Route::get('view-ptc-application/{id}', 'viewPTCApplication')->name('superadmin.viewPTCApplication');
            Route::post('store-ptc-forward-to-cb', 'postForwardToCB')->name('superadmin.postPTCForwardToCB');
            Route::get('list-trans-certificate', 'listOfPTC')->name('superadmin.listOfPTC');
        });

        Route::controller(TransactionCbCertificateController::class)->group(function () {



            Route::get('tc-request-certificate', 'index')->name('superadmin.tcrequestCbcertificate');
            Route::get('tc-request-certificate-process/{id}', 'process')->name('superadmin.tcrequestCbcertificateprocess');
            Route::post('tc-request-certificate-preview/{id}', 'tcrequestcertificatepreview')->name('superadmin.tcrequestcertificatepreview');
            Route::post('store-tc-request-certificate-preview', 'storeTcrequestcertificatepreview')->name('superadmin.storeTcrequestcertificatepreview');
            Route::get('view-tc-request-certificate/{tcid}/{userid}', 'previewtc')->name('superadmin.tcrequestCbcertificatepreviewtc');
            Route::get('tc-request-certificate-send-labtest/{id}', 'SendforLabTest')->name('superadmin.tcrequestCbcertificateSendforLabTest');
            Route::get('send-lab-test/product-test-information/{id}', 'producttestinformation')->name('superadmin.SendforLabTestproducttestinformation');
            Route::post('product-test-information-store', 'producttestinformationStore')->name('superadmin.producttestinformationStore');
            Route::get('cb-view-tc-application/{tcid}/{userid}', 'viewTCApplication')->name('superadmin.cb.viewTCApplication');
            Route::get('tc-application-pdf', 'pdfTcApplication')->name('superadmin.cb.pdfTcApplication');
            Route::post('generate-tc', 'generateTC')->name('superadmin.cb.generateTC');





            // Route::get('tc-request-certificate', 'index')->name('superadmin.tcrequestCbcertificate');
            // Route::get('tc-request-certificate-process/{id}', 'process')->name('superadmin.tcrequestCbcertificateprocess');
            // Route::post('tc-request-certificate-preview/{id}', 'tcrequestcertificatepreview')->name('superadmin.tcrequestcertificatepreview');
            // Route::post('store-tc-request-certificate-preview', 'storeTcrequestcertificatepreview')->name('superadmin.storeTcrequestcertificatepreview');
            // Route::get('view-tc-request-certificate/{tcid}/{userid}', 'previewtc')->name('superadmin.tcrequestCbcertificatepreviewtc');
            // Route::get('tc-request-certificate-send-labtest/{id}', 'SendforLabTest')->name('superadmin.tcrequestCbcertificateSendforLabTest');
            // Route::get('send-lab-test/product-test-information/{id}', 'producttestinformation')->name('superadmin.SendforLabTestproducttestinformation');
            // Route::post('product-test-information-store', 'producttestinformationStore')->name('superadmin.producttestinformationStore');
            // Route::get('cb-view-tc-application/{tcid}/{userid}', 'viewTCApplication')->name('superadmin.cb.viewTCApplication');
            // Route::get('tc-application-pdf', 'pdfTcApplication')->name('superadmin.cb.pdfTcApplication');
            Route::get('cb-tc-view-application-pdf/{id}', 'TcViewApplication')->name('superadmin.cb.TcViewApplication');
            Route::get('cb-tc-viewpdf-application-pdf/{id}', 'TcViewApplicationPdf')->name('superadmin.cb.TcViewApplication.pdf');
            // Route::post('generate-tc', 'generateTC')->name('superadmin.cb.generateTC');
            Route::get('tc-issue-list', 'tsIssueList')->name('superadmin.cb.tsIssueList');

            ///PTC

            Route::get('ptc-request-certificate', 'ptcindex')->name('superadmin.ptcrequestCbcertificate');
            Route::get('cb-view-ptc-application/{ptcid}/{userid}', 'viewPTCApplication')->name('superadmin.cb.viewPTCApplication');
            Route::get('ptc-request-certificate-process/{id}', 'ptcprocess')->name('superadmin.ptcrequestCbcertificateprocess');
            Route::post('store-ptc-process', 'storePTCProcess')->name('superadmin.storePTCProcess');
            Route::get('ptc-request-certificate-reject/{id}', 'ptcCancelApplication')->name('superadmin.ptcCancelApplication');
            Route::post('cancel-reject-application/{id}', 'ptcCancelApplicationPost')->name('superadmin.ptcCancelApplicationPost');
            Route::get('ptc-view/{id}', 'ptcView')->name('superadmin.ptcView');
            Route::get('trace-application/{id}', 'traceApplication')->name('superadmin.traceApplication');
        });

        Route::controller(NOCController::class)->group(function () {
            Route::get('apply-noc', 'applyNOC')->name('superadmin.applyNOC');
            Route::post('save-apply-noc', 'saveApplyNOC')->name('superadmin.saveApplyNOC');
            Route::get('split-noc', 'splitNOC')->name('superadmin.splitNOC');
            Route::post('noc-splt-farmer', 'nocSpltFarmer')->name('superadmin.nocSpltFarmer');
            Route::post('noc-splt-farm-store', 'nocSpltFarmStore')->name('superadmin.nocSpltFarmStore');
        });

        Route::controller(AccreditationController::class)->group(function () {
            Route::get('process-application-list', 'processApplication')->name('superadmin.processApplication');
            Route::get('process-application-form/{id?}', 'processApplicationForm')->name('superadmin.processApplicationForm');
            Route::post('application-form', 'processApplicationFormSubmit')->name('superadmin.processApplicationFormSubmit');
            Route::post('/upload',  'upload')->name('file.upload');
            Route::post('delete-file',  'deleteFile')->name('superadmin.deleteFile');
            Route::post('bioDataDelete',  'bioDataDelete')->name('superadmin.bioDataDelete');
            Route::get('accr-renewal', 'accrRenewal')->name('superadmin.accrRenewal');
            Route::get('accr-amendment', 'accrAmendment')->name('superadmin.accrAmendment');
            Route::post('accr-amendment', 'accrAmendmentSave')->name('superadmin.accrAmendmentSave');
            // Route::post('/accrAmendmentupload', 'accrAmendmentupload')->name('accrAmendmentupload');



            Route::get('accr-certificate-list', 'accrCertificateList')->name('superadmin.accrCertificateList');
            Route::get('accr-annual-report', 'accrAnnualReport')->name('superadmin.accrAnnualReport');
        });


        //------Code By  Gaurav----//

        Route::controller(HelpDeskController::class)->group(function () {
            Route::get('help-desk', 'index')->name('superadmin.help_desk');
            Route::get('ip-ticket', 'ticketIP')->name('ticketIP');
            Route::get('search', 'search')->name('superadmin.search');
            Route::post('searchstore', 'searchstore')->name('superadmin.searchstore');
            Route::get('ticket-list', 'ticketlist')->name('superadmin.ticketlist');
            Route::get('getticket-list', 'getTicketlistCb')->name('superadmin.getTicketlistCb');
            Route::get('view-ticket/{id}', 'viewticket')->name('superadmin.viewticket');
            Route::get('ticket/{id}', 'ticket')->name('superadmin.ticket');
            Route::post('superadmin.help_desk.cbhelpdesksave', 'cbhelpdesksave')->name('superadmin.help_desk.cbhelpdesksave');
            Route::post('getSubIssueType', 'getSubIssueType')->name('superadmin.help_desk.getSubIssueType');
            Route::get('/help-desk/ticket-list', 'getTicketList')->name('help_desk.ticket_list');
            Route::get('/help-desk/download-file/{filePath}', 'downloadFile')->name('help_desk.download_file');
            Route::get('help-desk-tickets', 'helpdesktickets')->name('superadmin.helpdesktickets');
            // Route::post('getReqDoc', 'getReqDoc')->name('superadmin.help_desk.getReqDoc');

            Route::get('gethelp-desk-tickets', 'getHelpdesktickets')->name('getSuperadmin.helpdesktickets');
            Route::get('superadmin/ticketEdit/{id}', 'editHelpdesktickets')->name('getSuperadmin.helpdesktickets.edit');



            Route::get('pan-index', 'pansendRequestindex')->name('superadmin.pansendRequestindex');
            Route::post('sendRequest', 'sendRequest')->name('superadmin.sendRequest');

            Route::get('pan', 'getPanDetails');
            // Add by Sachin
            Route::post('ticket-close', 'ticketClose')->name('superadmin.ticketClose');

            Route::get('mytickethelp-desk-tickets', 'myHelpdesktickets')->name('mySuperadmin.helpdesktickets');
        });



        Route::controller(MasterController::class)->group(function () {
            /////*  State master */////
            Route::get('master-state-list', 'index')->name('superadmin.master.statelist');
            Route::get('master-state-create', 'create')->name('superadmin.master.statecreate');
            Route::post('master-state-store', 'store')->name('superadmin.master.statestore');
            Route::get('master-state-edit/{id}', 'edit')->name('superadmin.master.stateedit');
            Route::post('master-state-update/{id}', 'update')->name('superadmin.master.stateupdate');
            Route::post('master-state-delete/{id}', 'delete')->name('superadmin.master.statedelete');

            /////*  district master */////
            Route::get('master-district-list', 'districtList')->name('superadmin.master.districtlist');
            Route::get('master-district-create', 'districtcreate')->name('superadmin.master.districtcreate');
            Route::post('master-district-store', 'districtStore')->name('superadmin.master.districtstore');
            Route::get('master-district-edit/{id}', 'districtedit')->name('superadmin.master.districtedit');
            Route::post('master-district-update/{id}', 'districtupdate')->name('superadmin.master.districtupdate');
            Route::post('master-district-delete/{id}', 'districtdelete')->name('superadmin.master.districtdelete');
        });


        //------Code By Kumar Gaurav----//

        Route::controller(MisReportController::class)->group(function () {

            Route::get('country-wise-exports', 'CountryWiseExports')->name('superadmin.country-wise-exports');
            Route::post('CountryWiseExportsSearch', 'CountryWiseExportsSearch')->name('CountryWiseExportsSearch');
            Route::get('scope-issued-mis', 'scopeissue')->name('superadmin.scope-issued-mis');
            Route::post('scopeissuesearch', 'scopeissuesearch')->name('scopeissuesearch');
            Route::get('list-of-register-operator', 'listofregisteroperator')->name('superadmin.list-of-register-operator');
            Route::post('search', 'listofregisteroperatorsearch')->name('listofregisteroperatorsearch');
            Route::get('state-wise-area', 'stateWiseArea')->name('superadmin.state-wise-area');
            Route::post('stateWiseAreaSearch', 'stateWiseAreaSearch')->name('stateWiseAreaSearch');
            Route::get('total-farmer', 'totalFarmer')->name('superadmin.total-farmer');
            Route::post('totalFarmerSearch', 'totalFarmerSearch')->name('totalFarmerSearch');
            Route::get('list-of-tc-issue', 'listOfTc')->name('superadmin.list-of-tc-issue');
            Route::post('listOfTcSearch', 'listOfTcSearch')->name('listOfTcSearch');
            Route::post('listOfPtcSearch', 'listOfPtcSearch')->name('listOfPtcSearch');
            Route::get('list-of-ptc-issue', 'listOfPtc')->name('superadmin.list-of-ptctc-issue');
            Route::get('view-operator-osp', 'viewoperatorOsp')->name('superadmin.view-operator-osp');
            Route::post('viewoperatorOspSearch', 'viewoperatorOspSearch')->name('viewoperatorOspSearch');
            Route::get('osp-view', 'ospview')->name('ospview');
            Route::get('scope-pending-for-renewal', 'scopePendingForRenewal')->name('superadmin.scope-pending-for-renewal');
            Route::post('scopePendingForRenewalSearch', 'scopePendingForRenewalSearch')->name('scopePendingForRenewalSearch');
            Route::get('Process-unit-pending-for-license-renewal', 'unitPendingForLicenseRenewal')->name('superadmin.unit-pending-for-license-renewal');
            Route::post('unitPendingForLicenseRenewalSearch', 'unitPendingForLicenseRenewalSearch')->name('unitPendingForLicenseRenewalSearch');
            Route::get('view-products-details', 'viewProductDetails')->name('superadmin.view-products-details');
            Route::post('viewProductDetailsSearch', 'viewProductDetailsSearch')->name('viewProductDetailsSearch');
            Route::get('scope-nearby-for-discontinuation', 'scopeNearby')->name('superadmin.scope-nearby-for-discontinuation');
            Route::post('scopeNearbySearch', 'scopeNearbySearch')->name('scopeNearbySearch');
            Route::get('activity-history', 'ActivityHistory')->name('superadmin.ActivityHistory');

            Route::get('view-data', 'viewData')->name('superadmin.viewData');
            Route::get('farmer-data/{at_user_id}', 'farmer')->name('superadmin.farmer');
        });


        Route::controller(SelfConsumptionController::class)->group(function () {

            Route::get('consumption-for-batch-details', 'listbatchdetails')->name('superadmin.consumption-for-batch-details');

            Route::post('listofregistersearch', 'listofregistersearch')->name('listofregistersearch');
            Route::post('listofregistersearchTc', 'listofregistersearchTc')->name('listofregistersearchTc');
            Route::post('save', 'save')->name('superadmin.save');
            Route::get('consumption-for-tc', 'listconsumptionfortc')->name('superadmin.consumption-for-tc');
            Route::post('consumptionsave', 'consumptionsave')->name('superadmin.consumptionsave');
            Route::get('view-tc-list-self-consumed', 'viewtclistselfconsumed')->name('superadmin.view-tc-list-self-consumed');
            Route::get('view-lot-batch-list-self-consume', 'viewlotbatchlistselfconsume')->name('superadmin.view-lot-batch-list-self-consume');
            Route::post('listofregistersearchLot', 'listofregistersearchLot')->name('listofregistersearchLot');
            Route::post('listofregistersearchTcConsumption', 'listofregistersearchTcConsumption')->name('listofregistersearchTcConsumption'); //Code By Sunny
            Route::get('/alerts', 'getAlerts')->name('alerts.get');
            Route::post('/alerts/{id}/read', 'markAlertAsRead')->name('superadmin.markAlertAsRead');
            Route::post('/alertstc/{id}/read', 'markAlertAsReadTc')->name('superadmin.markAlertAsReadTc');

            Route::post('consumptionsavefortc', 'consumptionsavefortc')->name('superadmin.consumptionsavefortc');
            Route::get('/cbalerts', 'getAlertsforCb')->name('cbalerts.get');

            Route::get('/admin/self_consumption/alert-detail/{self_qty_consumed}/{remark}/{org_status}/{created_at}', 'show')->name('alerts.show');
        });


        // Route::controller(DigitalSignatureController::class)->group(function () {


        //     Route::get('/signature/form', 'showForm')->name('superadmin.showForm');
        //     Route::post('/signature/sign-and-verify', 'signAndVerify')->name('superadmin.sign-and-verify');
        // });



        Route::controller(InternalStockTransferController::class)->group(function () {


            Route::get('Apply-for-Internal-Stock-Transfer', 'applyforinternalstocktransfer')->name('superadmin.applyforinternalstocktransfer');
            Route::get('Pending-for-Internal-Stock-Transfer', 'pendingforinternalstocktransfer')->name('superadmin.pendingforinternalstocktransfer');
            Route::get('List-of-Internal-Stock-Transfer', 'listforinternalstocktransfer')->name('superadmin.listforinternalstocktransfer');
            Route::get('internal-stock-add-product/{id}', 'AddProduct')->name('superadmin.InternalStockAddProduct');
            Route::post('internal-stock-packing-details/{id}', 'PackingDetail')->name('superadmin.InternalStockPackingDetail');
            Route::get('internal-stock-details/{id}', 'InternalStockDetail')->name('superadmin.InternalStockDetail');
            Route::get('view-application/{id}', 'viewApplication')->name('superadmin.viewApplication');
            Route::get('view-cb-application/{id}', 'viewCBApplication')->name('superadmin.viewCBApplication');
            Route::get('internal-stock-detail/{id}', 'InternalStockDetail1')->name('superadmin.InternalStockDetail1');
            Route::post('internal-stock-details-save/{id}', 'InternalStockDetailSave')->name('superadmin.InternalStockDetailSave');
            Route::get('packing-details-addupdate/{id}', 'PackingDetailAddUpdate')->name('superadmin.PackingDetailAddUpdate');
            Route::post('packing-details-save/{id}', 'PackingDetailSave')->name('superadmin.PackingDetailSave');
            Route::post('internal-stock-save-product', 'saveProduct')->name('superadmin.InternalStockSaveProduct');
            Route::get('internal-stock-forwadToCb/{id}', 'forwadToCb')->name('superadmin.forwadToCb');
            Route::post('internal-stock-forwadToCbSave', 'forwadToCbSave')->name('superadmin.forwadToCbSave');
            Route::get('Search-ST', 'SearchST')->name('superadmin.SearchST');
        });


        Route::controller(StockInventoryController::class)->group(function () {


            Route::get('ics-tc-Stock', 'BatchStock')->name('superadmin.BatchStock');
            Route::get('ics-tc-Stock-search', 'ICSSearch')->name('superadmin.ICSSearch');

            Route::get('ics-lot-Stock', 'LotStock')->name('superadmin.LotStock');
            Route::get('ics-lot-Stock-search', 'LotStockSearch')->name('superadmin.LotStockSearch');


            Route::get('ip-tc-Stock', 'IpbatchStock')->name('superadmin.IpbatchStock');
            Route::get('ip-tc-Stock-search', 'IPSearch')->name('superadmin.IPSearch');

            Route::get('ip-lot-Stock', 'IplotStock')->name('superadmin.IplotStock');
            Route::get('ip-lot-Stock-search', 'IPLotStockSearch')->name('superadmin.IPLotStockSearch');

            Route::get('wh-batch-Stock', 'WHlotStock')->name('superadmin.WHlotStock');
            Route::get('wh-batch-Stock-search', 'WHlotStockSearch')->name('superadmin.WHlotStockSearch');

            Route::get('trader-batch-Stock', 'TrbatchStock')->name('superadmin.TrbatchStock');
            Route::get('trader-batch-Stock-search', 'TrbatchStockSearch')->name('superadmin.TrbatchStockSearch');
            Route::get('trader-tc-Stock', 'TrTcStock')->name('superadmin.TrTcStock');
            Route::get('trader-tc-Stock-search', 'TrTcStockSearch')->name('superadmin.TrTcStockSearch');

            Route::get('processor-batch-Stock', 'processorbatchStock')->name('superadmin.processorbatchStock');
            Route::get('processor-batch-Stock-search', 'processorbatchStockSearch')->name('superadmin.processorbatchStockSearch');

            Route::get('processor-tc-Stock', 'processorTcStock')->name('superadmin.processorTcStock');
            Route::get('processor-tc-Stock-search', 'processorTcStockSearch')->name('superadmin.processorTcStockSearch');


            Route::get('lot-Stock', 'CbLotStock')->name('superadmin.CbLotStock');
            Route::get('lot-Stock-search', 'CbLotStockSearch')->name('superadmin.CbLotStockSearch');

            Route::get('Batch-Stock', 'CbBatchStock')->name('superadmin.CbBatchStock');
            Route::get('Batch-Stock-Search', 'CbBatchStockSearch')->name('superadmin.CbBatchStockSearch');

            Route::get('Tc-Stock', 'CbTcStock')->name('superadmin.CbTcStock');
            Route::get('Tc-Stock-Search', 'CbTcStockSearch')->name('superadmin.CbTcStockSearch');
        });


        Route::controller(LotCreationController::class)->group(function () {


            Route::get('lot-creation', 'lotcreation')->name('superadmin.lotcreation');
            Route::get('lot-creation-yield-scope', 'LotCreationYieldScope')->name('superadmin.LotCreationYieldScope');
            Route::get('procurement-entry/{id}', 'Step2')->name('superadmin.Step2');
            Route::get('procurement-entry-save', 'Step3')->name('superadmin.Step3');
            Route::get('Step3Save', 'Step3Save')->name('superadmin.Step3Save');
            Route::get('ICS-Search-Lots', 'icsearchlots')->name('superadmin.ICSSearchlots'); //Code by Sunny
            Route::post('/save-lot-details', 'saveLotDetails')->name('superadmin.saveLotDetails'); //Code by Sunny
            Route::post('/generate-lot-number', 'generateLotNumber')->name('superadmin.generateLotNumber'); //Code by Sunny
            Route::get('/lot-details/{id}', 'LotDetails')->name('superadmin.LotDetails'); //Code by Sunny
            Route::post('/delete-entry/{id}', 'delete')->name('superadmin.delete-entry'); //Code by Sunny
            Route::get('ViewLotsDetail', 'ViewLotsDetail')->name('superadmin.ViewLotsDetail'); //Code by Sunny

            Route::get('IP-lot-creation', 'IPlotcreation')->name('superadmin.IPlotcreation');
            Route::get('IP-lot-creation-yield-scope', 'IPLotCreationYieldScope')->name('superadmin.IPLotCreationYieldScope');
            Route::get('IP-procurement-entry/{id}', 'IPStep2')->name('superadmin.IPStep2');
            Route::post('/IP-save-lot-details', 'saveIPLotDetails')->name('superadmin.saveIPLotDetails'); //Code by Sunny
            Route::post('/generate-IP-lot-number', 'generateIPLotNumber')->name('superadmin.generateIPLotNumber'); //Code by Sunny
            Route::get('/IP-lot-details/{id}', 'IPLotDetails')->name('superadmin.IPLotDetails'); //Code by Sunny
            Route::post('/IP-delete-entry/{id}', 'IPdelete')->name('superadmin.ip-delete-entry'); //Code by Sunny
            Route::get('IP-ViewLotsDetail', 'IPViewLotsDetail')->name('superadmin.IPViewLotsDetail'); //Code by Sunny

        });



        Route::controller(ApedaMisReportController::class)->group(function () {

            //------------------------------------CB & Operator--------------------------------//

            Route::get('state-wise-active-cb', 'ActivCb')->name('superadmin.ActivCb');
            Route::get('list-of-operator', 'ListofOperator')->name('superadmin.ListofOperator');
            Route::get('list-of-mandatator', 'ListofMandatator')->name('superadmin.ListofMandatator');
            Route::get('farmer-count', 'FarmerCount')->name('superadmin.FarmerCount');
            Route::get('Wild-Collectors-Count', 'WildCollectorsCount')->name('superadmin.WildCollectorsCount');
            Route::get('Scope-Certificate-NPOP', 'ScopeCertificateNPOP')->name('superadmin.ScopeCertificateNPOP');
            Route::get('Ammendment-Annexure', 'AmmendmentAnnexure')->name('superadmin.AmmendmentAnnexure');
            Route::get('Details-of-operators', 'Detailsofoperators')->name('superadmin.Detailsofoperators');
            Route::get('Operator-NOC-Details', 'OperatorNOCDetails')->name('superadmin.OperatorNOCDetails');
            Route::get('Details-of-Approved-Inputs', 'ApprovedInputs')->name('superadmin.ApprovedInputs');
            Route::get('Suspended-Terminated-operator', 'Suspended')->name('superadmin.Suspended');
            Route::get('TC-Lot-Batch-SelfConsumption', 'TCLotBatchSelfConsumption')->name('superadmin.TCLotBatchSelfConsumption');
            Route::get('Certification-Body-Activity', 'CertificationBodyActivity')->name('superadmin.CertificationBodyActivity');
            Route::get('Farm-Value-Added-Product', 'FarmValueAddedProduct')->name('superadmin.FarmValueAddedProduct');
            Route::get('Product-Wise-ClosingStock', 'ProductWiseClosingStock')->name('superadmin.ProductWiseClosingStock');
            Route::get('Split-Farm', 'SplitFarm')->name('superadmin.SplitFarm');
            Route::get('Inspectors-Of-Certification-Body', 'InspectorsOfCertificationBody')->name('superadmin.InspectorsOfCertificationBody');
            Route::get('Approved-Inputs-Manufacturer', 'ApprovedInputsManufacturer')->name('superadmin.ApprovedInputsManufacturer');
            Route::get('Tracenet-Product-Master', 'TracenetProductMaster')->name('superadmin.TracenetProductMaster');
            Route::get('Stock-Inventory-of-Individual-Producer-Grower-Group-Wild-Processor-Trader', 'DetailsOfOperatorsStock')->name('superadmin.DetailsOfOperatorsStock');
            Route::get('List-of-Operator-while-Adding-INTC', 'AddingINTC')->name('superadmin.AddingINTC');
            Route::get('INTC-Report-after-added', 'INTCReport')->name('superadmin.INTCReport');
            Route::get('Trader-Warehouse-Details', 'TraderWarehouseDetails')->name('superadmin.TraderWarehouseDetails');

            Route::get('state-wise-active-cb-list', 'ActivCbList')->name('superadmin.statewiseActiveCB'); //Code by Sunny
            Route::get('report-on-operator-list', 'ReportOnOperatorList')->name('superadmin.report-on-operator-list'); //Code by Sunny
            Route::get('report-mandator-list', 'ReportOnMandatorList')->name('superadmin.report-on-mandator-list'); //Code by Sunny
            Route::get('/get-districts', 'getDistrictsByStateId')->name('getDistrictsByStateId'); //Code by Sunny
            Route::get('state-district-farmer-list', 'FarmerCountList')->name('superadmin.state-district-farmer-list'); //Code by Sunny
            Route::get('wh-state-district-farmer-list', 'WildCollectorsCountList')->name('superadmin.wild-harvest-district-farmer-list'); //Code by Sunny
            Route::get('report-on-scope-certificate', 'ReportOnScopeCertificate')->name('superadmin.report-on-scope-certificate'); //Code by Sunny
            Route::get('report-on-Ammendment', 'Ammendment')->name('superadmin.report-on-Ammendment'); //Code by Sunny
            Route::get('detail-of-id-proof-operator', 'IdProof')->name('superadmin.detail-id-proof-operator'); //Code by Sunny
            Route::get('report-on-operator-noc', 'OperatorNoc')->name('superadmin.report-on-operator-noc'); //Code by Sunny
            Route::get('report-on-suspended-terminated', 'Terminated')->name('superadmin.report-on-suspended-terminated'); //Code by Sunny
            Route::get('report-on-lot-batch-self-consumption', 'selfConsumption')->name('superadmin.report-on-lot-batch-self-consumption'); //Code by Sunny
            Route::get('report-certification-body-activity', 'CertificateBodyActivity')->name('superadmin.report-certification-body-activity'); //Code by Sunny


            //------------------------------------Export Report by Gaurav--------------------------------//

            Route::get('State-Wise-Including-Exporter', 'StateWiseIncludingExporter')->name('superadmin.StateWiseIncludingExporter');
            Route::get('State-Wise-Including-Exporter-list', 'StateWiseIncludingExporterSearch')->name('superadmin.StateWiseIncludingExporterSearch');

            Route::get('State-Wise-Only', 'StateWiseOnly')->name('superadmin.StateWiseOnly');
            Route::get('State-Wise-Only-list', 'StateWiseOnlySearch')->name('superadmin.StateWiseOnlySearch');

            Route::get('Country-Wise-Export-Including', 'CountryWiseExportIncluding')->name('superadmin.CountryWiseExportIncluding');
            Route::get('Country-Wise-Export-Including-list', 'CountryWiseExportIncludingSearch')->name('superadmin.CountryWiseExportIncludingSearch');

            Route::get('Country-Wise-Only', 'CountryWiseOnly')->name('superadmin.CountryWiseOnly');
            Route::get('Country-Wise-list', 'CountryWiseOnlySearch')->name('superadmin.CountryWiseOnlySearch');

            Route::get('Product-Wise', 'ProductWise')->name('superadmin.ProductWise');
            Route::get('Product-Wise-list', 'ProductWiseSearch')->name('superadmin.ProductWiseSearch');

            Route::get('Category-Wise', 'CategoryWise')->name('superadmin.CategoryWise');
            Route::get('Category-Wise-list', 'CategoryWiseSearch')->name('superadmin.CategoryWiseSearch');


            Route::get('CB-Wise', 'CBWise')->name('superadmin.CBWise');
            Route::get('CB-Wise-list', 'CBWiseSearch')->name('superadmin.CBWiseSearch');


            Route::get('Monthly-Comparative-Statement', 'MonthlyComparativeStatement')->name('superadmin.MonthlyComparativeStatement');
            Route::get('Monthly-Comparative-Statement-list', 'MonthlyComparativeStatementSearch')->name('superadmin.MonthlyComparativeStatementSearch');

            Route::get('Category-Wise-Comparative', 'CategoryWiseComparative')->name('superadmin.CategoryWiseComparative');
            Route::get('Category-Wise-Comparative-list', 'CategoryWiseComparativeSearch')->name('superadmin.CategoryWiseComparativeSearch');



            Route::get('Country-Wise-Comparative', 'CountryWiseComparative')->name('superadmin.CountryWiseComparative');
            Route::get('Country-Wise-Comparative-list', 'CountryWiseComparativeSearch')->name('superadmin.CountryWiseComparativeSearch');


            Route::get('Product-Wise-Comparative', 'ProductWiseComparative')->name('superadmin.ProductWiseComparative');
            Route::get('Product-Wise-Comparative-list', 'ProductWiseComparativeSearch')->name('superadmin.ProductWiseComparativeSearch');

            Route::get('Category-Wise-last-5-Years', 'CategoryWise5Years')->name('superadmin.CategoryWise5Years');
            Route::get('Category-Wise-last-5-Years-list', 'CategoryWise5YearsSearch')->name('superadmin.CategoryWise5YearsSearch');


            Route::get('Country-Wise-last-5-Years', 'CountryWise5Years')->name('superadmin.CountryWise5Years');
            Route::get('Country-Wise-last-5-Years-list', 'CountryWise5YearsSearch')->name('superadmin.CountryWise5YearsSearch');

            Route::get('Product-Wise-last-5-Years', 'ProductWise5Years')->name('superadmin.ProductWise5Years');
            Route::get('Product-Wise-last-5-Years-list', 'ProductWise5YearsSearch')->name('superadmin.ProductWise5YearsSearch');


            Route::get('State-Wise-last-5-Years', 'StateWise5Years')->name('superadmin.StateWise5Years');
            Route::get('State-Wise-last-5-Years-list', 'StateWise5YearsSearch')->name('superadmin.StateWise5YearsSearch');


            Route::get('CB-Wise-last-5-Years', 'CBWise5Years')->name('superadmin.CBWise5Years');
            Route::get('CB-Wise-last-5-Years-list', 'CBWise5YearsSearch')->name('superadmin.CBWise5YearsSearch');

            Route::get('Organic-Area', 'OrganicArea')->name('superadmin.OrganicArea');
            Route::get('Organic-Area-list', 'OrganicAreaSearch')->name('superadmin.OrganicAreaSearch');

            Route::get('Wild-Organic-Area', 'WildOrganicArea')->name('superadmin.WildOrganicArea');
            Route::get('Wild-Organic-Area-list', 'WildOrganicAreaSearch')->name('superadmin.WildOrganicAreaSearch');

            Route::get('Production', 'Production')->name('superadmin.Production');
            Route::get('Production-list', 'ProductionSearch')->name('superadmin.ProductionSearch');

            Route::get('Wild-Organic-Production', 'WildOrganicProduction')->name('superadmin.WildOrganicProduction');
            Route::get('Wild-Organic-Production-list', 'WildOrganicProductionSearch')->name('superadmin.WildOrganicProductionSearch');


            Route::get('Organic-Trade', 'OrganicTrade')->name('superadmin.OrganicTrade');
            Route::get('Organic-Trade-list', 'OrganicTradeSearch')->name('superadmin.OrganicTradeSearch');

            Route::get('List-Issued-TC', 'ListIssuedTC')->name('superadmin.ListIssuedTC');
            Route::get('List-Issued-TC-list', 'ListIssuedTCSearch')->name('superadmin.ListIssuedTCSearch');

            Route::get('Production-And-Export', 'ProductionAndExport')->name('superadmin.ProductionAndExport');
            Route::get('Production-And-Export-list', 'ProductionAndExportSearch')->name('superadmin.ProductionAndExportSearch');


            Route::get('External-Inspction', 'ExternalInspction')->name('superadmin.ExternalInspction');
            Route::get('External-Inspction-list', 'ExternalInspctionSearch')->name('superadmin.ExternalInspctionSearch');

            Route::get('Risk-Assessment', 'RiskAssessment')->name('superadmin.RiskAssessment');
            Route::get('Risk-Assessment-list', 'RiskAssessmentSearch')->name('superadmin.RiskAssessmentSearch');


            //------------------------------------Export Report end by Gaurav-----------------------------------------//
        });


        Route::controller(OrganicRCAC::class)->group(function () {

            Route::get('LC/Contract-Detail-Entry', 'LcEntry')->name('LcEntry');
            Route::get('LC/Contract-Detail-add', 'LcEntryAdd')->name('LcEntryAdd');
            Route::post('LC/Contract-Detail-save', 'LcEntrySave')->name('LcEntrySave');

            Route::get('edit/{id}', 'Edit')->name('Edit');
            Route::post('LC/Contract-Detail-edit', 'LcEntryEdit')->name('LcEntryEdit');
            Route::get('delete/{id}', 'Delete')->name('Delete');

            Route::get('Apply-for-RCAC/{id}', 'ApllyForRCAC')->name('ApllyForRCAC');
            Route::post('Apply-for-RCAC-save/{id}', 'ApllyForRCACSave')->name('ApllyForRCACSave');
            Route::get('Application-for-RCAC/{id}', 'ApplicationForRCAC')->name('ApplicationForRCAC');
            Route::post('Application-for-RCAC-save', 'ApplicationForRCACSave')->name('ApplicationForRCACSave');
            Route::get('payment-process/{created_by}', 'PaymentProcess')->name('PaymentProcees');

            Route::post('/process-payment',  'processPayment')->name('process.payment');

            Route::get('Apply-for-RCAC-Pending-for-payment', 'PendingPayment')->name('PendingPayment');
            Route::get('Trader-Pending-for-payment-Search', 'PendingPaymentSearch')->name('PendingPaymentSearch');
            Route::get('View-Status', 'ViewStatusTrader')->name('ViewStatusTrader');
            Route::get('Trader-View-Status-of-RCAC-Search', 'ViewStatusTraderSearch')->name('ViewStatusTraderSearch');

            //-------------processor------------------------------------------------//

            Route::get('Contract-LC-Detail-Entry', 'index')->name('index');
            Route::get('add', 'Add')->name('Add');
            Route::post('save', 'Save')->name('Save');


            Route::get('Edit/{id}', 'ProcessorEdit')->name('ProcessorEdit');
            Route::post('edit', 'Update')->name('Update');
            Route::get('Delete/{id}', 'DeleteRecord')->name('DeleteRecord');

            Route::get('Apply-for-RCAC-Processor/{id}', 'ApllyForRCACProcessor')->name('ApllyForRCACProcessor');
            Route::post('Apply-for-RCAC-Processor-save/{id}', 'ApllyForRCACProcessorSave')->name('ApllyForRCACProcessorSave');
            Route::get('Application-for-RCAC-processor/{id}', 'ApplicationForRCACProcessor')->name('ApplicationForRCACProcessor');
            Route::post('Application-for-RCAC-processor-save', 'ApplicationForRCACProcessorSave')->name('ApplicationForRCACProcessorSave');
            Route::get('payment-processor/{created_by}', 'PaymentProcessor')->name('PaymentProcessor');


            Route::get('Pending-for-payment', 'PendingPaymentProcessor')->name('PendingPaymentProcessor');
            Route::get('View-Status-of-RCAC', 'ViewStatusProcessor')->name('ViewStatusProcessor');

            Route::get('Pending-for-payment-Search', 'PendingPaymentProcessorSearch')->name('PendingPaymentProcessorSearch');
            Route::get('View-Status-of-RCAC-Search', 'ViewStatusProcessorSearch')->name('ViewStatusProcessorSearch');
        });

        Route::controller(NotificationController::class)->group(function () {


            Route::get('/notify', 'notify');
            Route::get('/notifications/read/{id}', 'markAsRead')->name('notifications.read');
            Route::get('/notification/index', 'index')->name('superadmin.notification_index');;
            Route::post('/notification/save', 'notificationsave')->name('superadmin.notification.save');
        });
    });


    Route::controller(LoginHistory::class)->group(function () {


        Route::get('/login-details', 'loginhistory')->name('superadmin.loginhistory');
    });

    Route::controller(AboutTracenet::class)->group(function () {


        Route::get('Organic-Division', 'OrganicDivision')->name('superadmin.OrganicDivision');
        Route::get('Technical-Support', 'TechnicalSupport')->name('superadmin.TechnicalSupport');
        Route::get('Announcement-Notification', 'Announcement')->name('superadmin.Announcement');
        Route::post('Announcement-Notification-save', 'Announcementstore')->name('superadmin.Announcementstore');
    });
    //DigitalSignDocument

    Route::controller(emudhraeSignController::class)->group(function () {
        Route::post('/generate-digital-sign-document', 'initiateSign')->name('generate.digital.sign');
    });
});

Route::controller(emudhraeSignController::class)->group(function () {
    Route::post('/digital-eSign/Redirect', 'digitaleSignRedirect')->name('eSign.digital.redirect');
    Route::get('/digital-eSign/Response', 'handleDigitalSignResponse')->name('eSign.digital.Response');
});

Route::group(['prefix' => 'superadmin/usermanagement', 'as' => 'superadmin.usermanagement.', 'middleware' => ['auth:misadmin', 'XSS', 'prevent-back-history']], function () {
    Route::post('rolecreatestore', [EmployeeRoleController::class, 'store'])->name('usercreate_role.store'); // Store role
    Route::get('roleedit/{id}', [EmployeeRoleController::class, 'edit'])->name('useredit_role'); // Edit role
    Route::put('roleupdate/{id}', [EmployeeRoleController::class, 'update'])->name('userupdate_role'); // Update role
    Route::delete('roledelete/{id}', [EmployeeRoleController::class, 'destroy'])->name('userdelete_role'); // Delete role
});

//PaymentGateway
Route::group(['middleware' => ['payment.protect']], function () {
    Route::get('/payment/test-create', [PaymentController::class, 'index'])->name('payment.test_create');
    Route::post('/payment/create', [PaymentController::class, 'createPayment'])->name('payment.create');
    Route::get('/payment/callback', [PaymentController::class, 'paymentCallback'])->name('payment.callback');
    Route::get('/payment/status/{result}', [PaymentController::class, 'paymentStatus'])->name('payment.payment_status');
});
